// ADIR-MEMBER packages
// alu_core_m0_pkg: the exact-arithmetic functions of mode 0 (1xint16_twos_complement)
package alu_core_m0_pkg;

  // ---- m0: V = {special[1:0], sign, exp[8] (signed), sig[17]}
  //           X = {special[1:0], sign, exp[8] (signed), sig[38], sticky}
  localparam int m0_SW = 17, m0_EW = 8, m0_XW = 38;
  localparam int m0_VW = 28, m0_XT = 50;
  function automatic [27:0] m0_mkv(input [1:0] sp, input s, input signed [7:0] e, input [16:0] sig);
    m0_mkv = {sp, s, e, sig};
  endfunction
  function automatic [49:0] m0_mkx(input [1:0] sp, input s, input signed [7:0] e, input [37:0] sig, input st);
    m0_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [49:0] m0_x(input [27:0] v);   // widen V to X
    m0_x = {v[27:27-1], v[27-2], v[27-3 -: 8], {{(38-17){1'b0}}, v[16:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [49:0] m0_norm(input [49:0] x);
    logic [37:0] s; logic signed [7:0] e; integer k;
    s = x[38:1]; e = x[38+8:38+1];
    if (s != 0) begin
      for (k = 32; k >= 1; k = k / 2) begin
        if (k < 38) begin
          if (s[37 -: 1] == 1'b0 && (s >> (38 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m0_norm = {x[49:49-1], x[49-2], e, s, x[0]};
  endfunction

  function automatic m0_rup(input [2:0] rnd, input s, input inexact, input [38:0] rest, input [38:0] halfv,
                             input st, input lsb, input [38+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m0_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m0_rup = 1'b0;
      3'd2: m0_rup = inexact && s;
      3'd3: m0_rup = inexact && !s;
      3'd4: m0_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m0_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [49:0] m0_add(input [49:0] a, input [49:0] b, input sub);
    logic [49:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [7:0] ea, eb, d; logic [38:0] ms, mb, r; logic st, stb; integer sh;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1];
    sa = na[49-2]; sb = nb[49-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m0_add = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m0_add = (sa == sb) ? m0_mkx(2'd2, sa, 0, 0, 1'b0) : m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_add = m0_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m0_add = m0_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[38:1] == 0 && !na[0]) m0_add = {nb[49:49-1], sb, nb[49-3:0]};
    else if (nb[38:1] == 0 && !nb[0]) m0_add = na;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[38:1] >= nb[38:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[38+8:38+1] - sml[38+8:38+1];
      ms = {1'b0, sml[38:1]}; stb = sml[0];
      if (d > 38 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 38 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[38:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[38]) begin st = st | r[0]; r = r >> 1; m0_add = m0_mkx(2'd0, sr, big[38+8:38+1] + 1, r[37:0], st); end
      else m0_add = m0_mkx(2'd0, sr, big[38+8:38+1], r[37:0], st);
    end
  endfunction
  function automatic [49:0] m0_mul(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38-1:0] pr; logic st; integer k;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m0_mul = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[38:1] == 0 && !na[0]) || (spb == 2'd0 && nb[38:1] == 0 && !nb[0]))
        m0_mul = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m0_mul = m0_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[38:1] * nb[38:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[37:0] != 0);
      m0_mul = m0_mkx(2'd0, s, na[38+8:38+1] + nb[38+8:38+1] + 38, pr[2*38-1:38], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*38+1:0] m0_udiv(input [37:0] a, input [37:0] dv);
    logic [38+1:0] r; logic [38:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 38; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[37:0], ge};
      if (i > 0) r = {r[38:0], 1'b0};
    end
    m0_udiv = {q, r[38:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*38+8+2:0] m0_mulx(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*38-1:0] pr;
    na = m0_norm(a); nb = m0_norm(b);
    pr = na[38:1] * nb[38:1];
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[38:1] == 0) || (spb == 2'd0 && nb[38:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m0_mulx = {sp, s, na[38+8:38+1] + nb[38+8:38+1], pr};
  endfunction
  function automatic [49:0] m0_div(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38+1:0] qr; logic [38:0] q, r;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_div = m0_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m0_div = m0_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[38:1] == 0 && !nb[0]) begin
      if (na[38:1] == 0 && !na[0]) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m0_div = m0_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[38:1] == 0 && !na[0]) m0_div = m0_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m0_udiv(na[38:1], nb[38:1]);     // both normalized: nonzero finite
      q = qr[2*38+1:38+1]; r = qr[38:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[38]) m0_div = m0_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38 + 1, q[38:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m0_div = m0_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38, q[37:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [49:0] m0_sqrt(input [49:0] a);
    logic [49:0] na; logic [1:0] spa; logic signed [7:0] e; logic [38:0] m; logic [2*38+3:0] rad;
    logic [38+2:0] rem, trial; logic [38:0] root; logic ge; integer i;
    na = m0_norm(a); spa = na[49:49-1];
    if (spa == 2'd1) m0_sqrt = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_sqrt = na[49-2] ? m0_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[38:1] == 0 && !na[0]) m0_sqrt = na;
    else if (na[49-2]) m0_sqrt = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[38+8:38+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[38:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[38:1]};
      rad = {{(38+3){1'b0}}, m} << 38;
      rem = 0; root = 0;
      for (i = 38; i >= 0; i = i - 1) begin
        rem = {rem[38:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[37:0], ge};
      end
      m0_sqrt = m0_mkx(2'd0, 1'b0, (e >>> 1) - 19 + 1, root[38:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m0_lt(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [7:0] ea, eb;
    na = m0_norm(a); nb = m0_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    sa = na[49-2] && !za; sb = nb[49-2] && !zb;
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m0_lt = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2) begin
      if (na[49:49-1] == 2'd2 && nb[49:49-1] == 2'd2) m0_lt = na[49-2] && !nb[49-2];
      else if (na[49:49-1] == 2'd2) m0_lt = na[49-2];
      else m0_lt = !nb[49-2];
    end else if (za && zb) m0_lt = 1'b0;
    else if (sa != sb) m0_lt = sa;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[38:1] < nb[38:1] || (na[38:1] == nb[38:1] && !na[0] && nb[0])));
      m0_lt = sa ? !mag_lt && !(za && zb) && !m0_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m0_eq(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb;
    na = m0_norm(a); nb = m0_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m0_eq = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2)
      m0_eq = (na[49:49-1] == nb[49:49-1]) && (na[49-2] == nb[49-2]);
    else if (za || zb) m0_eq = za && zb;
    else m0_eq = (na[49-2] == nb[49-2]) && (na[38+8:38+1] == nb[38+8:38+1]) && (na[38:1] == nb[38:1]) && (na[0] == nb[0]);
  endfunction

  function automatic [28:0] m0_unpack_s(input [15:0] b, input daz);
    logic s; logic [15:0] mag; integer i;
    s = b[15]; mag = s ? (~b + 1'b1) : b;
    m0_unpack_s = {1'b0, m0_mkv(2'd0, s && (mag != 0), -0, {{(17-16){1'b0}}, mag})};
  endfunction

  function automatic [15:0] m0_enc(input signed [34:0] v); m0_enc = v[15:0]; endfunction
  function automatic [15:0] m0_wrap(input signed [34:0] v); m0_wrap = v[15:0]; endfunction
  function automatic [15:0] m0_sat(input signed [34:0] v);
    m0_sat = (v > 35'sd32767) ? {1'b0, {15{1'b1}}} : (v < -35'sd32768) ? {1'b1, {15{1'b0}}} : v[15:0];
  endfunction

  // round v / 2^f under rnd (the SR word applies to the fraction bits)
  function automatic signed [34:0] m0_rshift(input signed [34:0] v, input integer f, input [2:0] rnd, input [7:0] word);
    logic s; logic [34:0] mag, keep, rest, halfv; logic [43:0] fint; logic up, inexact;
    s = v < 0; mag = s ? -v : v;
    if (f <= 0) m0_rshift = v;
    else begin
      keep = mag >> f; rest = mag & (((35'd1) << f) - 1); halfv = (35'd1) << (f - 1);
      inexact = rest != 0;
      fint = (f >= 8) ? (rest >> (f - 8)) : (rest << (8 - f));
      case (rnd)
        3'd0: up = (rest > halfv) || (rest == halfv && keep[0]);
        3'd1: up = 1'b0;
        3'd2: up = inexact && s;
        3'd3: up = inexact && !s;
        3'd4: up = inexact && (0 ? (fint >= word) : (fint > word));
        default: up = inexact;
      endcase
      keep = keep + up;
      m0_rshift = s ? -$signed(keep) : $signed(keep);
    end
  endfunction
  // the SR word of a division: floor(|r| * 2^sb / |b|)
  function automatic [7:0] m0_divfrac(input [34:0] r, input [34:0] b);
    logic [43:0] t;
    t = ({{9{1'b0}}, r} << 8) / {{9{1'b0}}, b};
    m0_divfrac = t[7:0];
  endfunction
endpackage

// alu_core_m1_pkg: the exact-arithmetic functions of mode 1 (1xint16_unsigned)
package alu_core_m1_pkg;

  // ---- m1: V = {special[1:0], sign, exp[8] (signed), sig[17]}
  //           X = {special[1:0], sign, exp[8] (signed), sig[38], sticky}
  localparam int m1_SW = 17, m1_EW = 8, m1_XW = 38;
  localparam int m1_VW = 28, m1_XT = 50;
  function automatic [27:0] m1_mkv(input [1:0] sp, input s, input signed [7:0] e, input [16:0] sig);
    m1_mkv = {sp, s, e, sig};
  endfunction
  function automatic [49:0] m1_mkx(input [1:0] sp, input s, input signed [7:0] e, input [37:0] sig, input st);
    m1_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [49:0] m1_x(input [27:0] v);   // widen V to X
    m1_x = {v[27:27-1], v[27-2], v[27-3 -: 8], {{(38-17){1'b0}}, v[16:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [49:0] m1_norm(input [49:0] x);
    logic [37:0] s; logic signed [7:0] e; integer k;
    s = x[38:1]; e = x[38+8:38+1];
    if (s != 0) begin
      for (k = 32; k >= 1; k = k / 2) begin
        if (k < 38) begin
          if (s[37 -: 1] == 1'b0 && (s >> (38 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m1_norm = {x[49:49-1], x[49-2], e, s, x[0]};
  endfunction

  function automatic m1_rup(input [2:0] rnd, input s, input inexact, input [38:0] rest, input [38:0] halfv,
                             input st, input lsb, input [38+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m1_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m1_rup = 1'b0;
      3'd2: m1_rup = inexact && s;
      3'd3: m1_rup = inexact && !s;
      3'd4: m1_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m1_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [49:0] m1_add(input [49:0] a, input [49:0] b, input sub);
    logic [49:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [7:0] ea, eb, d; logic [38:0] ms, mb, r; logic st, stb; integer sh;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1];
    sa = na[49-2]; sb = nb[49-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m1_add = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m1_add = (sa == sb) ? m1_mkx(2'd2, sa, 0, 0, 1'b0) : m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_add = m1_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m1_add = m1_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[38:1] == 0 && !na[0]) m1_add = {nb[49:49-1], sb, nb[49-3:0]};
    else if (nb[38:1] == 0 && !nb[0]) m1_add = na;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[38:1] >= nb[38:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[38+8:38+1] - sml[38+8:38+1];
      ms = {1'b0, sml[38:1]}; stb = sml[0];
      if (d > 38 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 38 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[38:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[38]) begin st = st | r[0]; r = r >> 1; m1_add = m1_mkx(2'd0, sr, big[38+8:38+1] + 1, r[37:0], st); end
      else m1_add = m1_mkx(2'd0, sr, big[38+8:38+1], r[37:0], st);
    end
  endfunction
  function automatic [49:0] m1_mul(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38-1:0] pr; logic st; integer k;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m1_mul = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[38:1] == 0 && !na[0]) || (spb == 2'd0 && nb[38:1] == 0 && !nb[0]))
        m1_mul = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m1_mul = m1_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[38:1] * nb[38:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[37:0] != 0);
      m1_mul = m1_mkx(2'd0, s, na[38+8:38+1] + nb[38+8:38+1] + 38, pr[2*38-1:38], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*38+1:0] m1_udiv(input [37:0] a, input [37:0] dv);
    logic [38+1:0] r; logic [38:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 38; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[37:0], ge};
      if (i > 0) r = {r[38:0], 1'b0};
    end
    m1_udiv = {q, r[38:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*38+8+2:0] m1_mulx(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*38-1:0] pr;
    na = m1_norm(a); nb = m1_norm(b);
    pr = na[38:1] * nb[38:1];
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[38:1] == 0) || (spb == 2'd0 && nb[38:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m1_mulx = {sp, s, na[38+8:38+1] + nb[38+8:38+1], pr};
  endfunction
  function automatic [49:0] m1_div(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38+1:0] qr; logic [38:0] q, r;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_div = m1_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m1_div = m1_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[38:1] == 0 && !nb[0]) begin
      if (na[38:1] == 0 && !na[0]) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m1_div = m1_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[38:1] == 0 && !na[0]) m1_div = m1_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m1_udiv(na[38:1], nb[38:1]);     // both normalized: nonzero finite
      q = qr[2*38+1:38+1]; r = qr[38:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[38]) m1_div = m1_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38 + 1, q[38:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m1_div = m1_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38, q[37:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [49:0] m1_sqrt(input [49:0] a);
    logic [49:0] na; logic [1:0] spa; logic signed [7:0] e; logic [38:0] m; logic [2*38+3:0] rad;
    logic [38+2:0] rem, trial; logic [38:0] root; logic ge; integer i;
    na = m1_norm(a); spa = na[49:49-1];
    if (spa == 2'd1) m1_sqrt = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_sqrt = na[49-2] ? m1_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[38:1] == 0 && !na[0]) m1_sqrt = na;
    else if (na[49-2]) m1_sqrt = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[38+8:38+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[38:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[38:1]};
      rad = {{(38+3){1'b0}}, m} << 38;
      rem = 0; root = 0;
      for (i = 38; i >= 0; i = i - 1) begin
        rem = {rem[38:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[37:0], ge};
      end
      m1_sqrt = m1_mkx(2'd0, 1'b0, (e >>> 1) - 19 + 1, root[38:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m1_lt(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [7:0] ea, eb;
    na = m1_norm(a); nb = m1_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    sa = na[49-2] && !za; sb = nb[49-2] && !zb;
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m1_lt = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2) begin
      if (na[49:49-1] == 2'd2 && nb[49:49-1] == 2'd2) m1_lt = na[49-2] && !nb[49-2];
      else if (na[49:49-1] == 2'd2) m1_lt = na[49-2];
      else m1_lt = !nb[49-2];
    end else if (za && zb) m1_lt = 1'b0;
    else if (sa != sb) m1_lt = sa;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[38:1] < nb[38:1] || (na[38:1] == nb[38:1] && !na[0] && nb[0])));
      m1_lt = sa ? !mag_lt && !(za && zb) && !m1_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m1_eq(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb;
    na = m1_norm(a); nb = m1_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m1_eq = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2)
      m1_eq = (na[49:49-1] == nb[49:49-1]) && (na[49-2] == nb[49-2]);
    else if (za || zb) m1_eq = za && zb;
    else m1_eq = (na[49-2] == nb[49-2]) && (na[38+8:38+1] == nb[38+8:38+1]) && (na[38:1] == nb[38:1]) && (na[0] == nb[0]);
  endfunction

  function automatic [28:0] m1_unpack_s(input [15:0] b, input daz);
    logic s; logic [15:0] mag; integer i;
    s = 1'b0; mag = b;
    m1_unpack_s = {1'b0, m1_mkv(2'd0, s && (mag != 0), -0, {{(17-16){1'b0}}, mag})};
  endfunction

  function automatic [15:0] m1_enc(input signed [34:0] v); m1_enc = v[15:0]; endfunction
  function automatic [15:0] m1_wrap(input signed [34:0] v); m1_wrap = v[15:0]; endfunction
  function automatic [15:0] m1_sat(input signed [34:0] v);
    m1_sat = (v > 35'sd65535) ? {16{1'b1}} : (v < 0) ? 16'd0 : v[15:0];
  endfunction

  // round v / 2^f under rnd (the SR word applies to the fraction bits)
  function automatic signed [34:0] m1_rshift(input signed [34:0] v, input integer f, input [2:0] rnd, input [7:0] word);
    logic s; logic [34:0] mag, keep, rest, halfv; logic [43:0] fint; logic up, inexact;
    s = v < 0; mag = s ? -v : v;
    if (f <= 0) m1_rshift = v;
    else begin
      keep = mag >> f; rest = mag & (((35'd1) << f) - 1); halfv = (35'd1) << (f - 1);
      inexact = rest != 0;
      fint = (f >= 8) ? (rest >> (f - 8)) : (rest << (8 - f));
      case (rnd)
        3'd0: up = (rest > halfv) || (rest == halfv && keep[0]);
        3'd1: up = 1'b0;
        3'd2: up = inexact && s;
        3'd3: up = inexact && !s;
        3'd4: up = inexact && (0 ? (fint >= word) : (fint > word));
        default: up = inexact;
      endcase
      keep = keep + up;
      m1_rshift = s ? -$signed(keep) : $signed(keep);
    end
  endfunction
  // the SR word of a division: floor(|r| * 2^sb / |b|)
  function automatic [7:0] m1_divfrac(input [34:0] r, input [34:0] b);
    logic [43:0] t;
    t = ({{9{1'b0}}, r} << 8) / {{9{1'b0}}, b};
    m1_divfrac = t[7:0];
  endfunction
endpackage

// alu_core_m2_pkg: the exact-arithmetic functions of mode 2 (2xint8_twos_complement)
package alu_core_m2_pkg;

  // ---- m2: V = {special[1:0], sign, exp[8] (signed), sig[9]}
  //           X = {special[1:0], sign, exp[8] (signed), sig[22], sticky}
  localparam int m2_SW = 9, m2_EW = 8, m2_XW = 22;
  localparam int m2_VW = 20, m2_XT = 34;
  function automatic [19:0] m2_mkv(input [1:0] sp, input s, input signed [7:0] e, input [8:0] sig);
    m2_mkv = {sp, s, e, sig};
  endfunction
  function automatic [33:0] m2_mkx(input [1:0] sp, input s, input signed [7:0] e, input [21:0] sig, input st);
    m2_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [33:0] m2_x(input [19:0] v);   // widen V to X
    m2_x = {v[19:19-1], v[19-2], v[19-3 -: 8], {{(22-9){1'b0}}, v[8:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [33:0] m2_norm(input [33:0] x);
    logic [21:0] s; logic signed [7:0] e; integer k;
    s = x[22:1]; e = x[22+8:22+1];
    if (s != 0) begin
      for (k = 16; k >= 1; k = k / 2) begin
        if (k < 22) begin
          if (s[21 -: 1] == 1'b0 && (s >> (22 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m2_norm = {x[33:33-1], x[33-2], e, s, x[0]};
  endfunction

  function automatic m2_rup(input [2:0] rnd, input s, input inexact, input [22:0] rest, input [22:0] halfv,
                             input st, input lsb, input [22+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m2_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m2_rup = 1'b0;
      3'd2: m2_rup = inexact && s;
      3'd3: m2_rup = inexact && !s;
      3'd4: m2_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m2_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [33:0] m2_add(input [33:0] a, input [33:0] b, input sub);
    logic [33:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [7:0] ea, eb, d; logic [22:0] ms, mb, r; logic st, stb; integer sh;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[33:33-1]; spb = nb[33:33-1];
    sa = na[33-2]; sb = nb[33-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m2_add = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m2_add = (sa == sb) ? m2_mkx(2'd2, sa, 0, 0, 1'b0) : m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_add = m2_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m2_add = m2_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[22:1] == 0 && !na[0]) m2_add = {nb[33:33-1], sb, nb[33-3:0]};
    else if (nb[22:1] == 0 && !nb[0]) m2_add = na;
    else begin
      ea = na[22+8:22+1]; eb = nb[22+8:22+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[22:1] >= nb[22:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[22+8:22+1] - sml[22+8:22+1];
      ms = {1'b0, sml[22:1]}; stb = sml[0];
      if (d > 22 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 22 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[22:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[22]) begin st = st | r[0]; r = r >> 1; m2_add = m2_mkx(2'd0, sr, big[22+8:22+1] + 1, r[21:0], st); end
      else m2_add = m2_mkx(2'd0, sr, big[22+8:22+1], r[21:0], st);
    end
  endfunction
  function automatic [33:0] m2_mul(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*22-1:0] pr; logic st; integer k;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[33:33-1]; spb = nb[33:33-1]; s = na[33-2] ^ nb[33-2];
    if (spa == 2'd1 || spb == 2'd1) m2_mul = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[22:1] == 0 && !na[0]) || (spb == 2'd0 && nb[22:1] == 0 && !nb[0]))
        m2_mul = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m2_mul = m2_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[22:1] * nb[22:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[21:0] != 0);
      m2_mul = m2_mkx(2'd0, s, na[22+8:22+1] + nb[22+8:22+1] + 22, pr[2*22-1:22], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*22+1:0] m2_udiv(input [21:0] a, input [21:0] dv);
    logic [22+1:0] r; logic [22:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 22; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[21:0], ge};
      if (i > 0) r = {r[22:0], 1'b0};
    end
    m2_udiv = {q, r[22:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*22+8+2:0] m2_mulx(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*22-1:0] pr;
    na = m2_norm(a); nb = m2_norm(b);
    pr = na[22:1] * nb[22:1];
    spa = na[33:33-1]; spb = nb[33:33-1]; s = na[33-2] ^ nb[33-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[22:1] == 0) || (spb == 2'd0 && nb[22:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m2_mulx = {sp, s, na[22+8:22+1] + nb[22+8:22+1], pr};
  endfunction
  function automatic [33:0] m2_div(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*22+1:0] qr; logic [22:0] q, r;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[33:33-1]; spb = nb[33:33-1]; s = na[33-2] ^ nb[33-2];
    if (spa == 2'd1 || spb == 2'd1) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_div = m2_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m2_div = m2_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[22:1] == 0 && !nb[0]) begin
      if (na[22:1] == 0 && !na[0]) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m2_div = m2_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[22:1] == 0 && !na[0]) m2_div = m2_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m2_udiv(na[22:1], nb[22:1]);     // both normalized: nonzero finite
      q = qr[2*22+1:22+1]; r = qr[22:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[22]) m2_div = m2_mkx(2'd0, s, na[22+8:22+1] - nb[22+8:22+1] - 22 + 1, q[22:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m2_div = m2_mkx(2'd0, s, na[22+8:22+1] - nb[22+8:22+1] - 22, q[21:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [33:0] m2_sqrt(input [33:0] a);
    logic [33:0] na; logic [1:0] spa; logic signed [7:0] e; logic [22:0] m; logic [2*22+3:0] rad;
    logic [22+2:0] rem, trial; logic [22:0] root; logic ge; integer i;
    na = m2_norm(a); spa = na[33:33-1];
    if (spa == 2'd1) m2_sqrt = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_sqrt = na[33-2] ? m2_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[22:1] == 0 && !na[0]) m2_sqrt = na;
    else if (na[33-2]) m2_sqrt = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[22+8:22+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[22:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[22:1]};
      rad = {{(22+3){1'b0}}, m} << 22;
      rem = 0; root = 0;
      for (i = 22; i >= 0; i = i - 1) begin
        rem = {rem[22:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[21:0], ge};
      end
      m2_sqrt = m2_mkx(2'd0, 1'b0, (e >>> 1) - 11 + 1, root[22:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m2_lt(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [7:0] ea, eb;
    na = m2_norm(a); nb = m2_norm(b);
    za = (na[22:1] == 0) && !na[0]; zb = (nb[22:1] == 0) && !nb[0];
    sa = na[33-2] && !za; sb = nb[33-2] && !zb;
    if (na[33:33-1] == 2'd1 || nb[33:33-1] == 2'd1) m2_lt = 1'b0;
    else if (na[33:33-1] == 2'd2 || nb[33:33-1] == 2'd2) begin
      if (na[33:33-1] == 2'd2 && nb[33:33-1] == 2'd2) m2_lt = na[33-2] && !nb[33-2];
      else if (na[33:33-1] == 2'd2) m2_lt = na[33-2];
      else m2_lt = !nb[33-2];
    end else if (za && zb) m2_lt = 1'b0;
    else if (sa != sb) m2_lt = sa;
    else begin
      ea = na[22+8:22+1]; eb = nb[22+8:22+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[22:1] < nb[22:1] || (na[22:1] == nb[22:1] && !na[0] && nb[0])));
      m2_lt = sa ? !mag_lt && !(za && zb) && !m2_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m2_eq(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic za, zb;
    na = m2_norm(a); nb = m2_norm(b);
    za = (na[22:1] == 0) && !na[0]; zb = (nb[22:1] == 0) && !nb[0];
    if (na[33:33-1] == 2'd1 || nb[33:33-1] == 2'd1) m2_eq = 1'b0;
    else if (na[33:33-1] == 2'd2 || nb[33:33-1] == 2'd2)
      m2_eq = (na[33:33-1] == nb[33:33-1]) && (na[33-2] == nb[33-2]);
    else if (za || zb) m2_eq = za && zb;
    else m2_eq = (na[33-2] == nb[33-2]) && (na[22+8:22+1] == nb[22+8:22+1]) && (na[22:1] == nb[22:1]) && (na[0] == nb[0]);
  endfunction

  function automatic [20:0] m2_unpack_s(input [7:0] b, input daz);
    logic s; logic [7:0] mag; integer i;
    s = b[7]; mag = s ? (~b + 1'b1) : b;
    m2_unpack_s = {1'b0, m2_mkv(2'd0, s && (mag != 0), -0, {{(9-8){1'b0}}, mag})};
  endfunction

  function automatic [7:0] m2_enc(input signed [18:0] v); m2_enc = v[7:0]; endfunction
  function automatic [7:0] m2_wrap(input signed [18:0] v); m2_wrap = v[7:0]; endfunction
  function automatic [7:0] m2_sat(input signed [18:0] v);
    m2_sat = (v > 19'sd127) ? {1'b0, {7{1'b1}}} : (v < -19'sd128) ? {1'b1, {7{1'b0}}} : v[7:0];
  endfunction

  // round v / 2^f under rnd (the SR word applies to the fraction bits)
  function automatic signed [18:0] m2_rshift(input signed [18:0] v, input integer f, input [2:0] rnd, input [7:0] word);
    logic s; logic [18:0] mag, keep, rest, halfv; logic [27:0] fint; logic up, inexact;
    s = v < 0; mag = s ? -v : v;
    if (f <= 0) m2_rshift = v;
    else begin
      keep = mag >> f; rest = mag & (((19'd1) << f) - 1); halfv = (19'd1) << (f - 1);
      inexact = rest != 0;
      fint = (f >= 8) ? (rest >> (f - 8)) : (rest << (8 - f));
      case (rnd)
        3'd0: up = (rest > halfv) || (rest == halfv && keep[0]);
        3'd1: up = 1'b0;
        3'd2: up = inexact && s;
        3'd3: up = inexact && !s;
        3'd4: up = inexact && (0 ? (fint >= word) : (fint > word));
        default: up = inexact;
      endcase
      keep = keep + up;
      m2_rshift = s ? -$signed(keep) : $signed(keep);
    end
  endfunction
  // the SR word of a division: floor(|r| * 2^sb / |b|)
  function automatic [7:0] m2_divfrac(input [18:0] r, input [18:0] b);
    logic [27:0] t;
    t = ({{9{1'b0}}, r} << 8) / {{9{1'b0}}, b};
    m2_divfrac = t[7:0];
  endfunction
endpackage
// ADIR-MEMBER top
// EVOLVE-BLOCK-START
// ADIR-DECL v1
// VAR core.adder.m0.family=carry_lookahead
// VAR core.adder.m0.group_size=6
// VAR core.adder.m0.intergroup_carry=lookahead
// VAR core.multiplier.m0.family=redundant_binary_multiplier
// VAR core.multiplier.m0.rb_encoding=plus_minus_pair
// VAR core.multiplier.m0.final_converter.family=prefix_synthesis_nonuniform_arrival
// VAR core.multiplier.m0.final_converter.arrival_profile=lsb_late
// VAR core.multiplier.m1.family=booth_recoded_parallel
// VAR core.multiplier.m1.booth_radix=16
// VAR core.multiplier.m1.hard_multiple_gen=specialized_3m_cpa
// VAR core.multiplier.m1.sign_extension=full_extension
// VAR core.multiplier.m1.negative_pp_encoding=twos_complement_row
// VAR core.multiplier.m1.reduction.family=compressor_4_2_tree
// VAR core.multiplier.m1.reduction.compressor_kind=5_2
// VAR core.multiplier.m1.reduction.cpa.family=hybrid_arrival_driven
// VAR core.multiplier.m1.reduction.cpa.region_count=4
// VAR core.multiplier.m1.reduction.cpa.region_adder_mix=uniform_cla
// VAR core.multiplier.m1.reduction.cpa.arrival_model=measured_tree_profile
// VAR core.multiplier.m1.reduction.cpa.boundary_search=delay_bound_boundary_enumeration
// VAR core.multiplier.m1.hard_multiple_adder.family=ling_prefix
// VAR core.multiplier.m1.hard_multiple_adder.pseudo_carry_group=3
// VAR core.multiplier.m2.family=segmented_grid
// VAR core.multiplier.m2.num_seg=4
// VAR core.multiplier.m2.merge_form=shift_add_tree
// VAR core.multiplier.m2.segment.group_bits=2
// VAR core.multiplier.m2.segment.signed_scheme=sign_extension
// VAR core.multiplier.m2.segment.reduction.family=tiled_cpa_reduction_tree
// VAR core.multiplier.m2.segment.reduction.adder_width=8
// VAR core.multiplier.m2.segment.reduction.terminal_reduction=compressor_9_2
// VAR core.multiplier.m2.segment.reduction.cpa.adder.family=ling_prefix
// VAR core.multiplier.m2.segment.reduction.cpa.adder.topology=han_carlson
// VAR core.multiplier.m2.segment.reduction.tile_adder.family=compound_flagged_prefix
// VAR core.multiplier.m2.segment.reduction.tile_adder.topology=kogge_stone
// VAR core.multiplier.m2.segment.reduction.tile_adder.implementation=flag_row
// VAR core.multiplier.m2.segment.reduction.tile_adder.late_carry_in=true
// VAR core.multiplier.m2.segment.hard_multiple_adder.family=compound_flagged_prefix
// VAR core.multiplier.m2.segment.hard_multiple_adder.topology=ladner_fischer
// VAR core.multiplier.m2.segment.hard_multiple_adder.implementation=flag_row
// VAR core.multiplier.m2.merge_adder.family=sparse_prefix_hybrid
// VAR core.multiplier.m2.merge_adder.log2_sparsity=1
// VAR core.multiplier.m2.merge_adder.tree_topology=han_carlson
// VAR core.multiplier.m2.merge_adder.sum_block.family=parallel_prefix
// VAR core.multiplier.m2.merge_adder.sum_block.topology=han_carlson
// VAR core.multiplier.m2.merge_tree.family=tiled_cpa_reduction_tree
// VAR core.multiplier.m2.merge_tree.adder_width=8
// VAR core.multiplier.m2.merge_tree.carry_assimilation=staggered_tiling
// VAR core.multiplier.m2.merge_tree.terminal_reduction=compressor_4_2
// VAR core.multiplier.m2.merge_tree.cpa.adder.family=end_around_carry
// VAR core.multiplier.m2.merge_tree.cpa.adder.modulus=mod_2n_plus_1_diminished_one
// VAR core.multiplier.m2.merge_tree.cpa.adder.recirculation=cyclic_prefix_level
// VAR core.multiplier.m2.merge_tree.tile_adder.family=compound_flagged_prefix
// VAR core.multiplier.m2.merge_tree.tile_adder.topology=kogge_stone
// VAR core.multiplier.m2.merge_tree.tile_adder.implementation=flag_row
// VAR core.multiplier.m2.merge_tree.tile_adder.late_carry_in=true
// VAR core.shifter.m0.family=butterfly_network
// VAR core.shifter.m0.sticky_collect=true
// VAR core.shifter.m0.network=butterfly
// VAR core.shifter.m1.stage_radix=full_width_single_stage
// VAR core.shifter.m1.select_encoding=one_hot_decoded
// VAR core.shifter.m1.stage_order=large_shift_first
// VAR core.shifter.m1.direction_handling=amount_negation
// VAR core.shifter.m1.sticky_collect=true
// VAR core.shifter.m2.stage_radix=8
// VAR core.shifter.m2.stage_order=large_shift_first
// VAR core.bitcount.m0.family=priority_encoder
// VAR core.bitcount.m0.output_form=one_hot_then_encode
// VAR core.bitcount.m0.lookahead_group=12
// VAR core.bitcount.m1.family=trailing_zero
// VAR core.bitcount.m1.lzd.family=prefix_lzc
// VAR core.bitcount.m1.lzd.prefix_topology=sklansky
// VAR core.bitcount.m1.lzd.counter.counter_primitive=lut_rom
// VAR core.bitcount.m1.lzd.counter.tree_shape=linear_chain
// VAR core.bitcount.m1.lzd.counter.final_adder.family=carry_increment
// VAR core.bitcount.m1.lzd.counter.final_adder.intergroup_carry=lookahead_tree
// VAR core.bitcount.m1.lzd.counter.final_adder.block_sizing=variable_ramp
// VAR core.bitcount.m1.lzd.counter.final_adder.block_adder.family=parallel_prefix
// VAR core.bitcount.m1.lzd.counter.final_adder.block_adder.topology=knowles_mixed
// VAR core.bitcount.m1.lzd.counter.final_adder.increment_stage.structure=select_blocks
// VAR core.bitcount.m1.negation_incrementer.structure=prefix_and_tree
// VAR core.bitcount.m1.negation_incrementer.topology=kogge_stone
// VAR core.bitcount.m2.family=lzd_cell_tree
// VAR core.bitcount.m2.output_form=one_hot_shift_controls
// VAR core.comparator.m1.family=subtractor_comparator
// VAR core.comparator.m1.subtractor.family=parallel_prefix
// VAR core.comparator.m1.subtractor.topology=ladner_fischer
// VAR core.comparator.m2.family=subtractor_comparator
// VAR core.comparator.m2.subtractor.family=manchester_carry_chain
// VAR core.comparator.m2.subtractor.chain_segment_length=4
// VAR core.comparator.m2.subtractor.variable_skip=true
// VAR core.adder.m1.family=carry_lookahead
// VAR core.adder.m1.group_size=6
// VAR core.adder.m1.intergroup_carry=lookahead
// VAR core.adder.m2.family=carry_lookahead
// VAR core.adder.m2.group_size=6
// VAR core.adder.m2.intergroup_carry=lookahead
// STRUCTURE m0.l0.adder kind=adder slot=adder mode=0 lane=0 width=16 format=int16_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m0_l0_adder
// STRUCTURE m0.l0.multiplier kind=multiplier slot=multiplier mode=0 lane=0 width=16 format=int16_twos_complement ops=mul,mul_high sv=alu_core_u_m0_l0_multiplier
// STRUCTURE m0.l0.comparator kind=comparator slot=comparator mode=0 lane=0 width=16 format=int16_twos_complement ops=min,max,cmp sv=alu_core_u_m0_l0_comparator
// STRUCTURE m0.l0.shifter kind=shifter slot=shifter mode=0 lane=0 width=16 format=int16_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m0_l0_shifter
// STRUCTURE m0.l0.logic kind=logic slot=logic mode=0 lane=0 width=16 format=int16_twos_complement ops=and,or,xor,not sv=alu_core_u_m0_l0_logic
// STRUCTURE m0.l0.bitcount kind=bitcount slot=bitcount mode=0 lane=0 width=16 format=int16_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m0_l0_bitcount
// STRUCTURE m1.l0.adder kind=adder slot=adder mode=1 lane=0 width=16 format=int16_unsigned ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m1_l0_adder
// STRUCTURE m1.l0.multiplier kind=multiplier slot=multiplier mode=1 lane=0 width=16 format=int16_unsigned ops=mul,mul_high sv=alu_core_u_m1_l0_multiplier
// STRUCTURE m1.l0.comparator kind=comparator slot=comparator mode=1 lane=0 width=16 format=int16_unsigned ops=min,max,cmp sv=alu_core_u_m1_l0_comparator
// STRUCTURE m1.l0.shifter kind=shifter slot=shifter mode=1 lane=0 width=16 format=int16_unsigned ops=shl,shr_arith,rol sv=alu_core_u_m1_l0_shifter
// STRUCTURE m1.l0.logic kind=logic slot=logic mode=1 lane=0 width=16 format=int16_unsigned ops=and,or,xor,not sv=alu_core_u_m1_l0_logic
// STRUCTURE m1.l0.bitcount kind=bitcount slot=bitcount mode=1 lane=0 width=16 format=int16_unsigned ops=popcount,clz,ctz sv=alu_core_u_m1_l0_bitcount
// STRUCTURE m2.l0.adder kind=adder slot=adder mode=2 lane=0 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m2_l0_adder
// STRUCTURE m2.l1.adder kind=adder slot=adder mode=2 lane=1 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m2_l1_adder
// STRUCTURE m2.l0.multiplier kind=multiplier slot=multiplier mode=2 lane=0 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_m2_l0_multiplier
// STRUCTURE m2.l1.multiplier kind=multiplier slot=multiplier mode=2 lane=1 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_m2_l1_multiplier
// STRUCTURE m2.l0.comparator kind=comparator slot=comparator mode=2 lane=0 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_m2_l0_comparator
// STRUCTURE m2.l1.comparator kind=comparator slot=comparator mode=2 lane=1 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_m2_l1_comparator
// STRUCTURE m2.l0.shifter kind=shifter slot=shifter mode=2 lane=0 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l0_shifter
// STRUCTURE m2.l1.shifter kind=shifter slot=shifter mode=2 lane=1 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l1_shifter
// STRUCTURE m2.l0.logic kind=logic slot=logic mode=2 lane=0 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_m2_l0_logic
// STRUCTURE m2.l1.logic kind=logic slot=logic mode=2 lane=1 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_m2_l1_logic
// STRUCTURE m2.l0.bitcount kind=bitcount slot=bitcount mode=2 lane=0 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l0_bitcount
// STRUCTURE m2.l1.bitcount kind=bitcount slot=bitcount mode=2 lane=1 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l1_bitcount
// ADIR-END
module alu_core (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  output logic [15:0] y,
  output logic [3:0] flags
);
  // alu_core: behavioral reference derived from the instance (modes 1xint16_twos_complement, 1xint16_unsigned, 2xint8_twos_complement; ops add, sub, adc, neg, abs, add_sat, mul, mul_high, min, max, cmp, shl, shr_arith, rol, and, or, xor, not, popcount, clz, ctz). Every (mode, op) pair computes the verify layer's exact semantics.
  // HIERARCHY: 24 physical structure modules instantiated by alu_core, built from 18 lane modules (one per mode and kind, parameter LANE) and 3 packages of engine functions (one per mode); a float mode's datapath is split into an unpacker (the xa/xb/den buses), the arithmetic and converter structures (unrounded results on the x bus) and a rounder (y and the flags); 0 misc lane modules and 0 block-conversion group modules
  // UNIT m0.l0.adder module=alu_core_u_m0_l0_adder kind=adder members=m0.l0.adder
  // UNIT m0.l0.multiplier module=alu_core_u_m0_l0_multiplier kind=multiplier members=m0.l0.multiplier
  // UNIT m0.l0.comparator module=alu_core_u_m0_l0_comparator kind=comparator members=m0.l0.comparator
  // UNIT m0.l0.shifter module=alu_core_u_m0_l0_shifter kind=shifter members=m0.l0.shifter
  // UNIT m0.l0.logic module=alu_core_u_m0_l0_logic kind=logic members=m0.l0.logic
  // UNIT m0.l0.bitcount module=alu_core_u_m0_l0_bitcount kind=bitcount members=m0.l0.bitcount
  // UNIT m1.l0.adder module=alu_core_u_m1_l0_adder kind=adder members=m1.l0.adder
  // UNIT m1.l0.multiplier module=alu_core_u_m1_l0_multiplier kind=multiplier members=m1.l0.multiplier
  // UNIT m1.l0.comparator module=alu_core_u_m1_l0_comparator kind=comparator members=m1.l0.comparator
  // UNIT m1.l0.shifter module=alu_core_u_m1_l0_shifter kind=shifter members=m1.l0.shifter
  // UNIT m1.l0.logic module=alu_core_u_m1_l0_logic kind=logic members=m1.l0.logic
  // UNIT m1.l0.bitcount module=alu_core_u_m1_l0_bitcount kind=bitcount members=m1.l0.bitcount
  // UNIT m2.l0.adder module=alu_core_u_m2_l0_adder kind=adder members=m2.l0.adder
  // UNIT m2.l1.adder module=alu_core_u_m2_l1_adder kind=adder members=m2.l1.adder
  // UNIT m2.l0.multiplier module=alu_core_u_m2_l0_multiplier kind=multiplier members=m2.l0.multiplier
  // UNIT m2.l1.multiplier module=alu_core_u_m2_l1_multiplier kind=multiplier members=m2.l1.multiplier
  // UNIT m2.l0.comparator module=alu_core_u_m2_l0_comparator kind=comparator members=m2.l0.comparator
  // UNIT m2.l1.comparator module=alu_core_u_m2_l1_comparator kind=comparator members=m2.l1.comparator
  // UNIT m2.l0.shifter module=alu_core_u_m2_l0_shifter kind=shifter members=m2.l0.shifter
  // UNIT m2.l1.shifter module=alu_core_u_m2_l1_shifter kind=shifter members=m2.l1.shifter
  // UNIT m2.l0.logic module=alu_core_u_m2_l0_logic kind=logic members=m2.l0.logic
  // UNIT m2.l1.logic module=alu_core_u_m2_l1_logic kind=logic members=m2.l1.logic
  // UNIT m2.l0.bitcount module=alu_core_u_m2_l0_bitcount kind=bitcount members=m2.l0.bitcount
  // UNIT m2.l1.bitcount module=alu_core_u_m2_l1_bitcount kind=bitcount members=m2.l1.bitcount
  // // STRUCTURE m0.l0.adder kind=adder slot=adder mode=0 lane=0 width=16 format=int16_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m0_l0_adder
  // // STRUCTURE m0.l0.multiplier kind=multiplier slot=multiplier mode=0 lane=0 width=16 format=int16_twos_complement ops=mul,mul_high sv=alu_core_u_m0_l0_multiplier
  // // STRUCTURE m0.l0.comparator kind=comparator slot=comparator mode=0 lane=0 width=16 format=int16_twos_complement ops=min,max,cmp sv=alu_core_u_m0_l0_comparator
  // // STRUCTURE m0.l0.shifter kind=shifter slot=shifter mode=0 lane=0 width=16 format=int16_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m0_l0_shifter
  // // STRUCTURE m0.l0.logic kind=logic slot=logic mode=0 lane=0 width=16 format=int16_twos_complement ops=and,or,xor,not sv=alu_core_u_m0_l0_logic
  // // STRUCTURE m0.l0.bitcount kind=bitcount slot=bitcount mode=0 lane=0 width=16 format=int16_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m0_l0_bitcount
  // // STRUCTURE m1.l0.adder kind=adder slot=adder mode=1 lane=0 width=16 format=int16_unsigned ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m1_l0_adder
  // // STRUCTURE m1.l0.multiplier kind=multiplier slot=multiplier mode=1 lane=0 width=16 format=int16_unsigned ops=mul,mul_high sv=alu_core_u_m1_l0_multiplier
  // // STRUCTURE m1.l0.comparator kind=comparator slot=comparator mode=1 lane=0 width=16 format=int16_unsigned ops=min,max,cmp sv=alu_core_u_m1_l0_comparator
  // // STRUCTURE m1.l0.shifter kind=shifter slot=shifter mode=1 lane=0 width=16 format=int16_unsigned ops=shl,shr_arith,rol sv=alu_core_u_m1_l0_shifter
  // // STRUCTURE m1.l0.logic kind=logic slot=logic mode=1 lane=0 width=16 format=int16_unsigned ops=and,or,xor,not sv=alu_core_u_m1_l0_logic
  // // STRUCTURE m1.l0.bitcount kind=bitcount slot=bitcount mode=1 lane=0 width=16 format=int16_unsigned ops=popcount,clz,ctz sv=alu_core_u_m1_l0_bitcount
  // // STRUCTURE m2.l0.adder kind=adder slot=adder mode=2 lane=0 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m2_l0_adder
  // // STRUCTURE m2.l1.adder kind=adder slot=adder mode=2 lane=1 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m2_l1_adder
  // // STRUCTURE m2.l0.multiplier kind=multiplier slot=multiplier mode=2 lane=0 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_m2_l0_multiplier
  // // STRUCTURE m2.l1.multiplier kind=multiplier slot=multiplier mode=2 lane=1 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_m2_l1_multiplier
  // // STRUCTURE m2.l0.comparator kind=comparator slot=comparator mode=2 lane=0 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_m2_l0_comparator
  // // STRUCTURE m2.l1.comparator kind=comparator slot=comparator mode=2 lane=1 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_m2_l1_comparator
  // // STRUCTURE m2.l0.shifter kind=shifter slot=shifter mode=2 lane=0 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l0_shifter
  // // STRUCTURE m2.l1.shifter kind=shifter slot=shifter mode=2 lane=1 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l1_shifter
  // // STRUCTURE m2.l0.logic kind=logic slot=logic mode=2 lane=0 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_m2_l0_logic
  // // STRUCTURE m2.l1.logic kind=logic slot=logic mode=2 lane=1 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_m2_l1_logic
  // // STRUCTURE m2.l0.bitcount kind=bitcount slot=bitcount mode=2 lane=0 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l0_bitcount
  // // STRUCTURE m2.l1.bitcount kind=bitcount slot=bitcount mode=2 lane=1 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l1_bitcount
  // LIBRARY: fam_add_partitioned_w16_16_carry_kill_gate_a34218975ba5, fam_add_partitioned_w16_8_carry_kill_gate_a34218975ba5, fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w3, fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w3_component_block_adder_adder_w1, fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w3_component_block_adder_adder_w2, fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w3_component_increment_stage_incrementer_w1, fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w3_component_increment_stage_incrementer_w2, fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w4, fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w4_component_block_adder_adder_w2, fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w4_component_increment_stage_incrementer_w2, fam_adder_carry_lookahead, fam_adder_cla_level, fam_adder_manchester_carry_chain, fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18, fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2, fam_cmp_prefix_comparator, fam_cmp_subtractor_manchester_carry_chain_pfc941ade37d4d8c30fe18473b17948ce924f25b19ce7c1959c47b46481c36035_sum_or_tree_s_w8, fam_cmp_subtractor_parallel_prefix_pbd9960fbdb60817a7cbc141202d9c0f14994f73526a859cb772052971be31631_sum_or_tree_u_w16, fam_count_lzd_pair_cell_one_hot_shift_controls_vflat_w8, fam_count_popcount_linear_chain_lut_rom_carry_increment_pc143e_w16, fam_count_prefix_lzc_sklansky_pcomp_pct_p79e35_w16, fam_count_priority_encoder_g12_l1_one_hot_then_encode_w16, fam_count_tzc_reverse_prefix_lzc_pdd7b3_w16, fam_incr_prefix_and, fam_logic_gate_row, fam_mul_booth16_dadda_3_2_w16_u_p20e537ff, fam_mul_direct_dadda_3_2_w2_u_p8dfaf87b, fam_mul_direct_dadda_3_2_w3_s_p8dfaf87b, fam_mul_redundant_binary_multiplier_w16_s_pcc746478, fam_mul_segmented_grid_w8_s_pf90d0475, fam_prefix_arrival_6_6_6_5_5_5_5_5_5_4_4_4_4_4_3_3_3_3_3_3_2_2_2_2_2_1_1_1_1_1_1_0_0_0_w34, fam_prefix_han_carlson_w2, fam_prefix_han_carlson_w4_ling_sel, fam_prefix_han_carlson_w6_ling_sel, fam_prefix_knowles_mixed_w1, fam_prefix_knowles_mixed_w2, fam_prefix_ladner_fischer_w16, fam_prefix_ladner_fischer_w5_flag, fam_prefix_net_han_carlson_w9, fam_shift_barrel_mux_tree, fam_shift_butterfly_network, fam_shift_keep_mask, fam_shift_stage (chialu.targets.rtl.families: the modules of the declared families the lane modules instantiate; their text follows the generated modules)
  logic [2:0] rnd_sel;
  logic [2:0] rnd;
  logic daz;
  logic ftz;
  logic dual;
  logic [15:0] y_m0_m0_l0_adder;
  logic [19:0] fl_m0_m0_l0_adder;
  logic [15:0] y_m0_m0_l0_multiplier;
  logic [19:0] fl_m0_m0_l0_multiplier;
  logic [15:0] y_m0_m0_l0_comparator;
  logic [19:0] fl_m0_m0_l0_comparator;
  logic [15:0] y_m0_m0_l0_shifter;
  logic [19:0] fl_m0_m0_l0_shifter;
  logic [15:0] y_m0_m0_l0_logic;
  logic [19:0] fl_m0_m0_l0_logic;
  logic [15:0] y_m0_m0_l0_bitcount;
  logic [19:0] fl_m0_m0_l0_bitcount;
  logic [15:0] y_m0;
  logic [19:0] fl_m0;
  logic [15:0] y_m1_m1_l0_adder;
  logic [19:0] fl_m1_m1_l0_adder;
  logic [15:0] y_m1_m1_l0_multiplier;
  logic [19:0] fl_m1_m1_l0_multiplier;
  logic [15:0] y_m1_m1_l0_comparator;
  logic [19:0] fl_m1_m1_l0_comparator;
  logic [15:0] y_m1_m1_l0_shifter;
  logic [19:0] fl_m1_m1_l0_shifter;
  logic [15:0] y_m1_m1_l0_logic;
  logic [19:0] fl_m1_m1_l0_logic;
  logic [15:0] y_m1_m1_l0_bitcount;
  logic [19:0] fl_m1_m1_l0_bitcount;
  logic [15:0] y_m1;
  logic [19:0] fl_m1;
  logic [15:0] y_m2_m2_l0_adder;
  logic [19:0] fl_m2_m2_l0_adder;
  logic [15:0] y_m2_m2_l1_adder;
  logic [19:0] fl_m2_m2_l1_adder;
  logic [15:0] y_m2_m2_l0_multiplier;
  logic [19:0] fl_m2_m2_l0_multiplier;
  logic [15:0] y_m2_m2_l1_multiplier;
  logic [19:0] fl_m2_m2_l1_multiplier;
  logic [15:0] y_m2_m2_l0_comparator;
  logic [19:0] fl_m2_m2_l0_comparator;
  logic [15:0] y_m2_m2_l1_comparator;
  logic [19:0] fl_m2_m2_l1_comparator;
  logic [15:0] y_m2_m2_l0_shifter;
  logic [19:0] fl_m2_m2_l0_shifter;
  logic [15:0] y_m2_m2_l1_shifter;
  logic [19:0] fl_m2_m2_l1_shifter;
  logic [15:0] y_m2_m2_l0_logic;
  logic [19:0] fl_m2_m2_l0_logic;
  logic [15:0] y_m2_m2_l1_logic;
  logic [19:0] fl_m2_m2_l1_logic;
  logic [15:0] y_m2_m2_l0_bitcount;
  logic [19:0] fl_m2_m2_l0_bitcount;
  logic [15:0] y_m2_m2_l1_bitcount;
  logic [19:0] fl_m2_m2_l1_bitcount;
  logic [15:0] y_m2;
  logic [19:0] fl_m2;
  logic [19:0] fl_all;
  assign rnd_sel = 3'd0;
  assign rnd = rnd_sel;
  assign daz = 1'b0;
  assign ftz = 1'b0;
  assign dual = 1'b0;
  assign y_m0 = y_m0_m0_l0_adder | y_m0_m0_l0_multiplier | y_m0_m0_l0_comparator | y_m0_m0_l0_shifter | y_m0_m0_l0_logic | y_m0_m0_l0_bitcount;
  assign fl_m0 = fl_m0_m0_l0_adder | fl_m0_m0_l0_multiplier | fl_m0_m0_l0_comparator | fl_m0_m0_l0_shifter | fl_m0_m0_l0_logic | fl_m0_m0_l0_bitcount;
  assign y_m1 = y_m1_m1_l0_adder | y_m1_m1_l0_multiplier | y_m1_m1_l0_comparator | y_m1_m1_l0_shifter | y_m1_m1_l0_logic | y_m1_m1_l0_bitcount;
  assign fl_m1 = fl_m1_m1_l0_adder | fl_m1_m1_l0_multiplier | fl_m1_m1_l0_comparator | fl_m1_m1_l0_shifter | fl_m1_m1_l0_logic | fl_m1_m1_l0_bitcount;
  assign y_m2 = y_m2_m2_l0_adder | y_m2_m2_l1_adder | y_m2_m2_l0_multiplier | y_m2_m2_l1_multiplier | y_m2_m2_l0_comparator | y_m2_m2_l1_comparator | y_m2_m2_l0_shifter | y_m2_m2_l1_shifter | y_m2_m2_l0_logic | y_m2_m2_l1_logic | y_m2_m2_l0_bitcount | y_m2_m2_l1_bitcount;
  assign fl_m2 = fl_m2_m2_l0_adder | fl_m2_m2_l1_adder | fl_m2_m2_l0_multiplier | fl_m2_m2_l1_multiplier | fl_m2_m2_l0_comparator | fl_m2_m2_l1_comparator | fl_m2_m2_l0_shifter | fl_m2_m2_l1_shifter | fl_m2_m2_l0_logic | fl_m2_m2_l1_logic | fl_m2_m2_l0_bitcount | fl_m2_m2_l1_bitcount;
  alu_core_u_m0_l0_adder u_m0_l0_adder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_adder), .fl_m0(fl_m0_m0_l0_adder));
  alu_core_u_m0_l0_multiplier u_m0_l0_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_multiplier), .fl_m0(fl_m0_m0_l0_multiplier));
  alu_core_u_m0_l0_comparator u_m0_l0_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_comparator), .fl_m0(fl_m0_m0_l0_comparator));
  alu_core_u_m0_l0_shifter u_m0_l0_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_shifter), .fl_m0(fl_m0_m0_l0_shifter));
  alu_core_u_m0_l0_logic u_m0_l0_logic (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_logic), .fl_m0(fl_m0_m0_l0_logic));
  alu_core_u_m0_l0_bitcount u_m0_l0_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_bitcount), .fl_m0(fl_m0_m0_l0_bitcount));
  alu_core_u_m1_l0_adder u_m1_l0_adder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_adder), .fl_m1(fl_m1_m1_l0_adder));
  alu_core_u_m1_l0_multiplier u_m1_l0_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_multiplier), .fl_m1(fl_m1_m1_l0_multiplier));
  alu_core_u_m1_l0_comparator u_m1_l0_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_comparator), .fl_m1(fl_m1_m1_l0_comparator));
  alu_core_u_m1_l0_shifter u_m1_l0_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_shifter), .fl_m1(fl_m1_m1_l0_shifter));
  alu_core_u_m1_l0_logic u_m1_l0_logic (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_logic), .fl_m1(fl_m1_m1_l0_logic));
  alu_core_u_m1_l0_bitcount u_m1_l0_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_bitcount), .fl_m1(fl_m1_m1_l0_bitcount));
  alu_core_u_m2_l0_adder u_m2_l0_adder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_adder), .fl_m2(fl_m2_m2_l0_adder));
  alu_core_u_m2_l1_adder u_m2_l1_adder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_adder), .fl_m2(fl_m2_m2_l1_adder));
  alu_core_u_m2_l0_multiplier u_m2_l0_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_multiplier), .fl_m2(fl_m2_m2_l0_multiplier));
  alu_core_u_m2_l1_multiplier u_m2_l1_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_multiplier), .fl_m2(fl_m2_m2_l1_multiplier));
  alu_core_u_m2_l0_comparator u_m2_l0_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_comparator), .fl_m2(fl_m2_m2_l0_comparator));
  alu_core_u_m2_l1_comparator u_m2_l1_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_comparator), .fl_m2(fl_m2_m2_l1_comparator));
  alu_core_u_m2_l0_shifter u_m2_l0_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_shifter), .fl_m2(fl_m2_m2_l0_shifter));
  alu_core_u_m2_l1_shifter u_m2_l1_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_shifter), .fl_m2(fl_m2_m2_l1_shifter));
  alu_core_u_m2_l0_logic u_m2_l0_logic (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_logic), .fl_m2(fl_m2_m2_l0_logic));
  alu_core_u_m2_l1_logic u_m2_l1_logic (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_logic), .fl_m2(fl_m2_m2_l1_logic));
  alu_core_u_m2_l0_bitcount u_m2_l0_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_bitcount), .fl_m2(fl_m2_m2_l0_bitcount));
  alu_core_u_m2_l1_bitcount u_m2_l1_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_bitcount), .fl_m2(fl_m2_m2_l1_bitcount));
  always_comb begin
    case (mode)
      2'd0: begin y = y_m0; fl_all = fl_m0; end
      2'd1: begin y = y_m1; fl_all = fl_m1; end
      2'd2: begin y = y_m2; fl_all = fl_m2; end
      default: begin y = '0; fl_all = '0; end
    endcase
  end
  assign flags[0] = fl_all[7];
  assign flags[1] = fl_all[8];
  assign flags[2] = fl_all[17];
  assign flags[3] = fl_all[18];
endmodule
// EVOLVE-BLOCK-END

module alu_core_m0_adder_sh #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0,
  output logic [15:0] pc_a_m0,
  output logic [15:0] pc_b_m0,
  output logic [0:0] pc_cin_m0,
  input  logic [15:0] pc_s_m0,
  input  logic [0:0] pc_co_m0
);
  // alu_core_m0_adder_sh: lane LANE of mode 0 (int16_twos_complement) for the adder ops add, sub, adc, neg, abs, add_sat; the result buses are the mode's, with only this lane's bits written; the unit's shared adder serve this lane through the pc_/tp_ buses
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_add_sLANE;
  logic m0_add_coutLANE;
  logic signed [34:0] m0_o0ex0_LANE;
  logic signed [34:0] m0_o1ex0_LANE;
  logic signed [34:0] m0_o2ex0_LANE;
  logic signed [34:0] m0_o3ex0_LANE;
  logic signed [34:0] m0_o4ex0_LANE;
  logic signed [34:0] m0_o5ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.adder.m0: the unit's shared partitioned adder (subword partitioned_carry_chain)
  assign m0_add_sLANE = pc_s_m0[(LANE)*16 +: 16];
  assign m0_add_coutLANE = pc_co_m0[(LANE+1)*1-1];
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_o0ex0_LANE = 'x; m0_o1ex0_LANE = 'x; m0_o2ex0_LANE = 'x; m0_o3ex0_LANE = 'x; m0_o4ex0_LANE = 'x; m0_o5ex0_LANE = 'x;
    pc_a_m0 = '0; pc_b_m0 = '0; pc_cin_m0 = '0;
    case (op)
      5'd0: begin
        pc_a_m0[(LANE)*16 +: 16] = m0_aLANE; pc_b_m0[(LANE)*16 +: 16] = m0_bLANE; pc_cin_m0[(LANE)*1] = 1'b0;
        m0_o0ex0_LANE = $signed({(m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o0ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (m0_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd1: begin
        pc_a_m0[(LANE)*16 +: 16] = m0_aLANE; pc_b_m0[(LANE)*16 +: 16] = ~m0_bLANE; pc_cin_m0[(LANE)*1] = 1'b1;
        m0_o1ex0_LANE = $signed({(m0_aLANE[15] ^ ~m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o1ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ ~m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ ~m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (~m0_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd2: begin
        pc_a_m0[(LANE)*16 +: 16] = m0_aLANE; pc_b_m0[(LANE)*16 +: 16] = m0_bLANE; pc_cin_m0[(LANE)*1] = 1'b1;
        m0_o2ex0_LANE = $signed({(m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o2ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (m0_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd3: begin
        pc_a_m0[(LANE)*16 +: 16] = 16'd0; pc_b_m0[(LANE)*16 +: 16] = ~m0_aLANE; pc_cin_m0[(LANE)*1] = 1'b1;
        m0_o3ex0_LANE = $signed({(1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o3ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (m0_aLANE != 0 ? (10'd1 << 7) : 10'd0);
      end
      5'd4: begin
        pc_a_m0[(LANE)*16 +: 16] = 16'd0; pc_b_m0[(LANE)*16 +: 16] = ~m0_aLANE; pc_cin_m0[(LANE)*1] = 1'b1;
        m0_o4ex0_LANE = (m0_aLANE[15] ? $signed({(1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE), m0_add_sLANE}) : $signed({1'b0, m0_aLANE}));
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o4ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = ((m0_aLANE[15] & ((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15])) ? (10'd1 << 8) : 10'd0) | ((m0_aLANE[15] & ((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15])) ? (10'd1 << 2) : 10'd0);
      end
      5'd5: begin
        pc_a_m0[(LANE)*16 +: 16] = m0_aLANE; pc_b_m0[(LANE)*16 +: 16] = m0_bLANE; pc_cin_m0[(LANE)*1] = 1'b0;
        m0_o5ex0_LANE = $signed({(m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_sat(m0_o5ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_bitcount #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_bitcount: lane LANE of mode 0 (int16_twos_complement) for the bitcount ops popcount, clz, ctz; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_clz_aLANE;
  logic [4:0] m0_clz_nLANE;
  logic signed [34:0] m0_o18ex0_LANE;
  logic signed [34:0] m0_o19ex0_LANE;
  logic signed [34:0] m0_o20ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.bitcount.m0: family priority_encoder realized by the library module fam_count_priority_encoder_g12_l1_one_hot_then_encode_w16 (clz)
  fam_count_priority_encoder_g12_l1_one_hot_then_encode_w16 u_m0_clzLANE (.a(m0_clz_aLANE), .n(m0_clz_nLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_clz_aLANE = 'x; m0_o18ex0_LANE = 'x; m0_o19ex0_LANE = 'x; m0_o20ex0_LANE = 'x;
    case (op)
      5'd18: begin
        y_m0[((LANE*16)+0) +: 16] = m0_aLANE[0] + m0_aLANE[1] + m0_aLANE[2] + m0_aLANE[3] + m0_aLANE[4] + m0_aLANE[5] + m0_aLANE[6] + m0_aLANE[7] + m0_aLANE[8] + m0_aLANE[9] + m0_aLANE[10] + m0_aLANE[11] + m0_aLANE[12] + m0_aLANE[13] + m0_aLANE[14] + m0_aLANE[15];
      end
      5'd19: begin
        m0_clz_aLANE = m0_aLANE;
        y_m0[((LANE*16)+0) +: 16] = {{11{1'b0}}, m0_clz_nLANE};
      end
      5'd20: begin
        y_m0[((LANE*16)+0) +: 16] = m0_aLANE[0] ? 16'd0 : m0_aLANE[1] ? 16'd1 : m0_aLANE[2] ? 16'd2 : m0_aLANE[3] ? 16'd3 : m0_aLANE[4] ? 16'd4 : m0_aLANE[5] ? 16'd5 : m0_aLANE[6] ? 16'd6 : m0_aLANE[7] ? 16'd7 : m0_aLANE[8] ? 16'd8 : m0_aLANE[9] ? 16'd9 : m0_aLANE[10] ? 16'd10 : m0_aLANE[11] ? 16'd11 : m0_aLANE[12] ? 16'd12 : m0_aLANE[13] ? 16'd13 : m0_aLANE[14] ? 16'd14 : m0_aLANE[15] ? 16'd15 : 16'd16;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_comparator #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_comparator: lane LANE of mode 0 (int16_twos_complement) for the comparator ops min, max, cmp; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_cmp_aLANE;
  logic [15:0] m0_cmp_bLANE;
  logic m0_cmp_ltLANE;
  logic m0_cmp_eqLANE;
  logic signed [34:0] m0_o8ex0_LANE;
  logic signed [34:0] m0_o9ex0_LANE;
  logic signed [34:0] m0_o10ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.comparator.m0: family prefix_comparator realized by the library module fam_cmp_prefix_comparator
  fam_cmp_prefix_comparator #(.W(16), .SIGNED(1), .STRUCTURE(0), .RADIX(2)) u_m0_cmpLANE (.a(m0_cmp_aLANE), .b(m0_cmp_bLANE), .lt(m0_cmp_ltLANE), .eq(m0_cmp_eqLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_cmp_aLANE = 'x; m0_cmp_bLANE = 'x; m0_o8ex0_LANE = 'x; m0_o9ex0_LANE = 'x; m0_o10ex0_LANE = 'x;
    case (op)
      5'd8: begin
        m0_cmp_aLANE = m0_aLANE; m0_cmp_bLANE = m0_bLANE;
        y_m0[((LANE*16)+0) +: 16] = (m0_cmp_ltLANE | m0_cmp_eqLANE) ? m0_aLANE : m0_bLANE;
      end
      5'd9: begin
        m0_cmp_aLANE = m0_aLANE; m0_cmp_bLANE = m0_bLANE;
        y_m0[((LANE*16)+0) +: 16] = (~m0_cmp_ltLANE) ? m0_aLANE : m0_bLANE;
      end
      5'd10: begin
        m0_cmp_aLANE = m0_aLANE; m0_cmp_bLANE = m0_bLANE;
        y_m0[((LANE*16)+0) +: 16] = {{13{1'b0}}, (~m0_cmp_ltLANE & ~m0_cmp_eqLANE), m0_cmp_eqLANE, m0_cmp_ltLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_logic #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_logic: lane LANE of mode 0 (int16_twos_complement) for the logic ops and, or, xor, not; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_lg_aLANE;
  logic [15:0] m0_lg_bLANE;
  logic [1:0] m0_lg_opLANE;
  logic [15:0] m0_lg_yLANE;
  logic signed [34:0] m0_o14ex0_LANE;
  logic signed [34:0] m0_o15ex0_LANE;
  logic signed [34:0] m0_o16ex0_LANE;
  logic signed [34:0] m0_o17ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.logic.m0: family lane_replicated_gates realized by the library module fam_logic_gate_row
  fam_logic_gate_row #(.W(16), .NOT_VIA_XOR(0)) u_m0_logicLANE (.a(m0_lg_aLANE), .b(m0_lg_bLANE), .op(m0_lg_opLANE), .y(m0_lg_yLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_lg_aLANE = 'x; m0_lg_bLANE = 'x; m0_lg_opLANE = 'x; m0_o14ex0_LANE = 'x; m0_o15ex0_LANE = 'x; m0_o16ex0_LANE = 'x;
    m0_o17ex0_LANE = 'x;
    case (op)
      5'd14: begin
        m0_lg_aLANE = m0_aLANE; m0_lg_bLANE = m0_bLANE; m0_lg_opLANE = 2'd0;
        y_m0[((LANE*16)+0) +: 16] = m0_lg_yLANE;
      end
      5'd15: begin
        m0_lg_aLANE = m0_aLANE; m0_lg_bLANE = m0_bLANE; m0_lg_opLANE = 2'd1;
        y_m0[((LANE*16)+0) +: 16] = m0_lg_yLANE;
      end
      5'd16: begin
        m0_lg_aLANE = m0_aLANE; m0_lg_bLANE = m0_bLANE; m0_lg_opLANE = 2'd2;
        y_m0[((LANE*16)+0) +: 16] = m0_lg_yLANE;
      end
      5'd17: begin
        m0_lg_aLANE = m0_aLANE; m0_lg_bLANE = m0_bLANE; m0_lg_opLANE = 2'd3;
        y_m0[((LANE*16)+0) +: 16] = m0_lg_yLANE;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_multiplier #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_multiplier: lane LANE of mode 0 (int16_twos_complement) for the multiplier ops mul, mul_high; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_mul_aLANE;
  logic [15:0] m0_mul_bLANE;
  logic [31:0] m0_mul_pLANE;
  logic signed [34:0] m0_o6ex0_LANE;
  logic signed [34:0] m0_o7ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.multiplier.m0: family redundant_binary_multiplier realized by the library module fam_mul_redundant_binary_multiplier_w16_s_pcc746478
  fam_mul_redundant_binary_multiplier_w16_s_pcc746478 u_m0_mulLANE (.a(m0_mul_aLANE), .b(m0_mul_bLANE), .p(m0_mul_pLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_mul_aLANE = 'x; m0_mul_bLANE = 'x; m0_o6ex0_LANE = 'x; m0_o7ex0_LANE = 'x;
    case (op)
      5'd6: begin
        m0_mul_aLANE = m0_aLANE; m0_mul_bLANE = m0_bLANE;
        m0_o6ex0_LANE = $signed({{3{m0_mul_pLANE[31]}}, m0_mul_pLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o6ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (m0_o6ex0_LANE > 35'sd32767 || m0_o6ex0_LANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m0_o6ex0_LANE > 35'sd32767 || m0_o6ex0_LANE < -35'sd32768 ? (10'd1 << 2) : 10'd0);
      end
      5'd7: begin
        m0_mul_aLANE = m0_aLANE; m0_mul_bLANE = m0_bLANE;
        m0_o7ex0_LANE = $signed({{3{m0_mul_pLANE[31]}}, m0_mul_pLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o7ex0_LANE >>> 16);
        fl_m0[(0+LANE)*10 +: 10] = (m0_o7ex0_LANE > 35'sd32767 || m0_o7ex0_LANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m0_o7ex0_LANE > 35'sd32767 || m0_o7ex0_LANE < -35'sd32768 ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_shifter #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_shifter: lane LANE of mode 0 (int16_twos_complement) for the shifter ops shl, shr_arith, rol; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_sh_aLANE;
  logic [3:0] m0_sh_amtLANE;
  logic [2:0] m0_sh_opLANE;
  logic [15:0] m0_sh_yLANE;
  logic signed [34:0] m0_o11ex0_LANE;
  logic signed [34:0] m0_o12ex0_LANE;
  logic signed [34:0] m0_o13ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.shifter.m0: family butterfly_network realized by the library module fam_shift_butterfly_network
  fam_shift_butterfly_network #(.W(16), .NETWORK(1), .STICKY(1)) u_m0_shifterLANE (.a(m0_sh_aLANE), .amt(m0_sh_amtLANE), .op(m0_sh_opLANE), .y(m0_sh_yLANE), .sticky());
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_sh_aLANE = 'x; m0_sh_amtLANE = 'x; m0_sh_opLANE = 'x; m0_o11ex0_LANE = 'x; m0_o12ex0_LANE = 'x; m0_o13ex0_LANE = 'x;
    case (op)
      5'd11: begin
        m0_sh_aLANE = m0_aLANE; m0_sh_amtLANE = 4'(m0_bLANE % 16'd16); m0_sh_opLANE = 3'd0;
        y_m0[((LANE*16)+0) +: 16] = m0_sh_yLANE;
      end
      5'd12: begin
        m0_sh_aLANE = m0_aLANE; m0_sh_amtLANE = 4'(m0_bLANE % 16'd16); m0_sh_opLANE = 3'd2;
        y_m0[((LANE*16)+0) +: 16] = m0_sh_yLANE;
      end
      5'd13: begin
        m0_sh_aLANE = m0_aLANE; m0_sh_amtLANE = 4'(m0_bLANE % 16'd16); m0_sh_opLANE = 3'd3;
        y_m0[((LANE*16)+0) +: 16] = m0_sh_yLANE;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_adder_sh #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1,
  output logic [15:0] pc_a_m1,
  output logic [15:0] pc_b_m1,
  output logic [0:0] pc_cin_m1,
  input  logic [15:0] pc_s_m1,
  input  logic [0:0] pc_co_m1
);
  // alu_core_m1_adder_sh: lane LANE of mode 1 (int16_unsigned) for the adder ops add, sub, adc, neg, abs, add_sat; the result buses are the mode's, with only this lane's bits written; the unit's shared adder serve this lane through the pc_/tp_ buses
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_add_sLANE;
  logic m1_add_coutLANE;
  logic signed [34:0] m1_o0ex0_LANE;
  logic signed [34:0] m1_o1ex0_LANE;
  logic signed [34:0] m1_o2ex0_LANE;
  logic signed [34:0] m1_o3ex0_LANE;
  logic signed [34:0] m1_o4ex0_LANE;
  logic signed [34:0] m1_o4sx0_LANE;
  logic signed [34:0] m1_o5ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.adder.m1: the unit's shared partitioned adder (subword partitioned_carry_chain)
  assign m1_add_sLANE = pc_s_m1[(LANE)*16 +: 16];
  assign m1_add_coutLANE = pc_co_m1[(LANE+1)*1-1];
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_o0ex0_LANE = 'x; m1_o1ex0_LANE = 'x; m1_o2ex0_LANE = 'x; m1_o3ex0_LANE = 'x; m1_o4ex0_LANE = 'x; m1_o4sx0_LANE = 'x;
    m1_o5ex0_LANE = 'x;
    pc_a_m1 = '0; pc_b_m1 = '0; pc_cin_m1 = '0;
    case (op)
      5'd0: begin
        pc_a_m1[(LANE)*16 +: 16] = m1_aLANE; pc_b_m1[(LANE)*16 +: 16] = m1_bLANE; pc_cin_m1[(LANE)*1] = 1'b0;
        m1_o0ex0_LANE = $signed({1'b0, m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o0ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (m1_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd1: begin
        pc_a_m1[(LANE)*16 +: 16] = m1_aLANE; pc_b_m1[(LANE)*16 +: 16] = ~m1_bLANE; pc_cin_m1[(LANE)*1] = 1'b1;
        m1_o1ex0_LANE = $signed({~m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o1ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (~m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ ~m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (~m1_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd2: begin
        pc_a_m1[(LANE)*16 +: 16] = m1_aLANE; pc_b_m1[(LANE)*16 +: 16] = m1_bLANE; pc_cin_m1[(LANE)*1] = 1'b1;
        m1_o2ex0_LANE = $signed({1'b0, m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o2ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (m1_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd3: begin
        pc_a_m1[(LANE)*16 +: 16] = 16'd0; pc_b_m1[(LANE)*16 +: 16] = ~m1_aLANE; pc_cin_m1[(LANE)*1] = 1'b1;
        m1_o3ex0_LANE = $signed({~m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o3ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (~m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((1'b0 ^ ~m1_aLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (m1_aLANE != 0 ? (10'd1 << 7) : 10'd0);
      end
      5'd4: begin
        m1_o4ex0_LANE = (m1_vaLANE < 0) ? -m1_vaLANE : m1_vaLANE;
        m1_o4sx0_LANE = (($signed({m1_aLANE[15], m1_aLANE}) < 0) ? -$signed({m1_aLANE[15], m1_aLANE}) : $signed({m1_aLANE[15], m1_aLANE}));
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o4ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_o4sx0_LANE > 35'sd32767 || m1_o4sx0_LANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m1_o4ex0_LANE > 35'sd65535 || m1_o4ex0_LANE < 0 ? (10'd1 << 2) : 10'd0);
      end
      5'd5: begin
        pc_a_m1[(LANE)*16 +: 16] = m1_aLANE; pc_b_m1[(LANE)*16 +: 16] = m1_bLANE; pc_cin_m1[(LANE)*1] = 1'b0;
        m1_o5ex0_LANE = $signed({1'b0, m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_sat(m1_o5ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_bitcount #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_bitcount: lane LANE of mode 1 (int16_unsigned) for the bitcount ops popcount, clz, ctz; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_ctz_aLANE;
  logic [4:0] m1_ctz_nLANE;
  logic signed [34:0] m1_o18ex0_LANE;
  logic signed [34:0] m1_o19ex0_LANE;
  logic signed [34:0] m1_o20ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.bitcount.m1: family trailing_zero realized by the library module fam_count_tzc_reverse_prefix_lzc_pdd7b3_w16 (ctz)
  fam_count_tzc_reverse_prefix_lzc_pdd7b3_w16 u_m1_ctzLANE (.a(m1_ctz_aLANE), .n(m1_ctz_nLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_ctz_aLANE = 'x; m1_o18ex0_LANE = 'x; m1_o19ex0_LANE = 'x; m1_o20ex0_LANE = 'x;
    case (op)
      5'd18: begin
        y_m1[((LANE*16)+0) +: 16] = m1_aLANE[0] + m1_aLANE[1] + m1_aLANE[2] + m1_aLANE[3] + m1_aLANE[4] + m1_aLANE[5] + m1_aLANE[6] + m1_aLANE[7] + m1_aLANE[8] + m1_aLANE[9] + m1_aLANE[10] + m1_aLANE[11] + m1_aLANE[12] + m1_aLANE[13] + m1_aLANE[14] + m1_aLANE[15];
      end
      5'd19: begin
        y_m1[((LANE*16)+0) +: 16] = m1_aLANE[15] ? 16'd0 : m1_aLANE[14] ? 16'd1 : m1_aLANE[13] ? 16'd2 : m1_aLANE[12] ? 16'd3 : m1_aLANE[11] ? 16'd4 : m1_aLANE[10] ? 16'd5 : m1_aLANE[9] ? 16'd6 : m1_aLANE[8] ? 16'd7 : m1_aLANE[7] ? 16'd8 : m1_aLANE[6] ? 16'd9 : m1_aLANE[5] ? 16'd10 : m1_aLANE[4] ? 16'd11 : m1_aLANE[3] ? 16'd12 : m1_aLANE[2] ? 16'd13 : m1_aLANE[1] ? 16'd14 : m1_aLANE[0] ? 16'd15 : 16'd16;
      end
      5'd20: begin
        m1_ctz_aLANE = m1_aLANE;
        y_m1[((LANE*16)+0) +: 16] = {{11{1'b0}}, m1_ctz_nLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_comparator #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_comparator: lane LANE of mode 1 (int16_unsigned) for the comparator ops min, max, cmp; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_cmp_aLANE;
  logic [15:0] m1_cmp_bLANE;
  logic m1_cmp_ltLANE;
  logic m1_cmp_eqLANE;
  logic signed [34:0] m1_o8ex0_LANE;
  logic signed [34:0] m1_o9ex0_LANE;
  logic signed [34:0] m1_o10ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.comparator.m1: family subtractor_comparator realized by the library module fam_cmp_subtractor_parallel_prefix_pbd9960fbdb60817a7cbc141202d9c0f14994f73526a859cb772052971be31631_sum_or_tree_u_w16
  fam_cmp_subtractor_parallel_prefix_pbd9960fbdb60817a7cbc141202d9c0f14994f73526a859cb772052971be31631_sum_or_tree_u_w16 u_m1_cmpLANE (.a(m1_cmp_aLANE), .b(m1_cmp_bLANE), .lt(m1_cmp_ltLANE), .eq(m1_cmp_eqLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_cmp_aLANE = 'x; m1_cmp_bLANE = 'x; m1_o8ex0_LANE = 'x; m1_o9ex0_LANE = 'x; m1_o10ex0_LANE = 'x;
    case (op)
      5'd8: begin
        m1_cmp_aLANE = m1_aLANE; m1_cmp_bLANE = m1_bLANE;
        y_m1[((LANE*16)+0) +: 16] = (m1_cmp_ltLANE | m1_cmp_eqLANE) ? m1_aLANE : m1_bLANE;
      end
      5'd9: begin
        m1_cmp_aLANE = m1_aLANE; m1_cmp_bLANE = m1_bLANE;
        y_m1[((LANE*16)+0) +: 16] = (~m1_cmp_ltLANE) ? m1_aLANE : m1_bLANE;
      end
      5'd10: begin
        m1_cmp_aLANE = m1_aLANE; m1_cmp_bLANE = m1_bLANE;
        y_m1[((LANE*16)+0) +: 16] = {{13{1'b0}}, (~m1_cmp_ltLANE & ~m1_cmp_eqLANE), m1_cmp_eqLANE, m1_cmp_ltLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_logic #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_logic: lane LANE of mode 1 (int16_unsigned) for the logic ops and, or, xor, not; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_lg_aLANE;
  logic [15:0] m1_lg_bLANE;
  logic [1:0] m1_lg_opLANE;
  logic [15:0] m1_lg_yLANE;
  logic signed [34:0] m1_o14ex0_LANE;
  logic signed [34:0] m1_o15ex0_LANE;
  logic signed [34:0] m1_o16ex0_LANE;
  logic signed [34:0] m1_o17ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.logic.m1: family lane_replicated_gates realized by the library module fam_logic_gate_row
  fam_logic_gate_row #(.W(16), .NOT_VIA_XOR(0)) u_m1_logicLANE (.a(m1_lg_aLANE), .b(m1_lg_bLANE), .op(m1_lg_opLANE), .y(m1_lg_yLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_lg_aLANE = 'x; m1_lg_bLANE = 'x; m1_lg_opLANE = 'x; m1_o14ex0_LANE = 'x; m1_o15ex0_LANE = 'x; m1_o16ex0_LANE = 'x;
    m1_o17ex0_LANE = 'x;
    case (op)
      5'd14: begin
        m1_lg_aLANE = m1_aLANE; m1_lg_bLANE = m1_bLANE; m1_lg_opLANE = 2'd0;
        y_m1[((LANE*16)+0) +: 16] = m1_lg_yLANE;
      end
      5'd15: begin
        m1_lg_aLANE = m1_aLANE; m1_lg_bLANE = m1_bLANE; m1_lg_opLANE = 2'd1;
        y_m1[((LANE*16)+0) +: 16] = m1_lg_yLANE;
      end
      5'd16: begin
        m1_lg_aLANE = m1_aLANE; m1_lg_bLANE = m1_bLANE; m1_lg_opLANE = 2'd2;
        y_m1[((LANE*16)+0) +: 16] = m1_lg_yLANE;
      end
      5'd17: begin
        m1_lg_aLANE = m1_aLANE; m1_lg_bLANE = m1_bLANE; m1_lg_opLANE = 2'd3;
        y_m1[((LANE*16)+0) +: 16] = m1_lg_yLANE;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_multiplier #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_multiplier: lane LANE of mode 1 (int16_unsigned) for the multiplier ops mul, mul_high; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_mul_aLANE;
  logic [15:0] m1_mul_bLANE;
  logic [31:0] m1_mul_pLANE;
  logic signed [34:0] m1_o6ex0_LANE;
  logic signed [34:0] m1_o6sx0_ANE;
  logic signed [34:0] m1_o7ex0_LANE;
  logic signed [34:0] m1_o7sx0_ANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.multiplier.m1: family booth_recoded_parallel realized by the library module fam_mul_booth16_dadda_3_2_w16_u_p20e537ff
  fam_mul_booth16_dadda_3_2_w16_u_p20e537ff u_m1_mulLANE (.a(m1_mul_aLANE), .b(m1_mul_bLANE), .p(m1_mul_pLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_mul_aLANE = 'x; m1_mul_bLANE = 'x; m1_o6ex0_LANE = 'x; m1_o6sx0_ANE = 'x; m1_o7ex0_LANE = 'x; m1_o7sx0_ANE = 'x;
    case (op)
      5'd6: begin
        m1_mul_aLANE = m1_aLANE; m1_mul_bLANE = m1_bLANE;
        m1_o6ex0_LANE = $signed({{3{1'b0}}, m1_mul_pLANE});
        m1_o6sx0_ANE = m1_o6ex0_LANE - (m1_aLANE[15] ? ($signed(m1_vbLANE) <<< 16) : 35'sd0) - (m1_bLANE[15] ? ($signed(m1_vaLANE) <<< 16) : 35'sd0) + ((m1_aLANE[15] & m1_bLANE[15]) ? 35'sd4294967296 : 35'sd0);
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o6ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_o6sx0_ANE > 35'sd32767 || m1_o6sx0_ANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m1_o6ex0_LANE > 35'sd65535 || m1_o6ex0_LANE < 0 ? (10'd1 << 2) : 10'd0);
      end
      5'd7: begin
        m1_mul_aLANE = m1_aLANE; m1_mul_bLANE = m1_bLANE;
        m1_o7ex0_LANE = $signed({{3{1'b0}}, m1_mul_pLANE});
        m1_o7sx0_ANE = m1_o7ex0_LANE - (m1_aLANE[15] ? ($signed(m1_vbLANE) <<< 16) : 35'sd0) - (m1_bLANE[15] ? ($signed(m1_vaLANE) <<< 16) : 35'sd0) + ((m1_aLANE[15] & m1_bLANE[15]) ? 35'sd4294967296 : 35'sd0);
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o7ex0_LANE >>> 16);
        fl_m1[(0+LANE)*10 +: 10] = (m1_o7sx0_ANE > 35'sd32767 || m1_o7sx0_ANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m1_o7ex0_LANE > 35'sd65535 || m1_o7ex0_LANE < 0 ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_shifter #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_shifter: lane LANE of mode 1 (int16_unsigned) for the shifter ops shl, shr_arith, rol; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_sh_aLANE;
  logic [3:0] m1_sh_amtLANE;
  logic [2:0] m1_sh_opLANE;
  logic [15:0] m1_sh_yLANE;
  logic signed [34:0] m1_o11ex0_LANE;
  logic signed [34:0] m1_o12ex0_LANE;
  logic signed [34:0] m1_o13ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.shifter.m1: family barrel_mux_tree realized by the library module fam_shift_barrel_mux_tree
  fam_shift_barrel_mux_tree #(.W(16), .RADIX_LOG2(0), .ONE_HOT(1), .DIR(2), .ORDER(1), .STICKY(1)) u_m1_shifterLANE (.a(m1_sh_aLANE), .amt(m1_sh_amtLANE), .op(m1_sh_opLANE), .y(m1_sh_yLANE), .sticky());
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_sh_aLANE = 'x; m1_sh_amtLANE = 'x; m1_sh_opLANE = 'x; m1_o11ex0_LANE = 'x; m1_o12ex0_LANE = 'x; m1_o13ex0_LANE = 'x;
    case (op)
      5'd11: begin
        m1_sh_aLANE = m1_aLANE; m1_sh_amtLANE = 4'(m1_bLANE % 16'd16); m1_sh_opLANE = 3'd0;
        y_m1[((LANE*16)+0) +: 16] = m1_sh_yLANE;
      end
      5'd12: begin
        m1_sh_aLANE = m1_aLANE; m1_sh_amtLANE = 4'(m1_bLANE % 16'd16); m1_sh_opLANE = 3'd2;
        y_m1[((LANE*16)+0) +: 16] = m1_sh_yLANE;
      end
      5'd13: begin
        m1_sh_aLANE = m1_aLANE; m1_sh_amtLANE = 4'(m1_bLANE % 16'd16); m1_sh_opLANE = 3'd3;
        y_m1[((LANE*16)+0) +: 16] = m1_sh_yLANE;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_adder_sh #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2,
  output logic [15:0] pc_a_m2,
  output logic [15:0] pc_b_m2,
  output logic [1:0] pc_cin_m2,
  input  logic [15:0] pc_s_m2,
  input  logic [1:0] pc_co_m2
);
  // alu_core_m2_adder_sh: lane LANE of mode 2 (int8_twos_complement) for the adder ops add, sub, adc, neg, abs, add_sat; the result buses are the mode's, with only this lane's bits written; the unit's shared adder serve this lane through the pc_/tp_ buses
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_add_sLANE;
  logic m2_add_coutLANE;
  logic signed [18:0] m2_o0ex0_LANE;
  logic signed [18:0] m2_o1ex0_LANE;
  logic signed [18:0] m2_o2ex0_LANE;
  logic signed [18:0] m2_o3ex0_LANE;
  logic signed [18:0] m2_o4ex0_LANE;
  logic signed [18:0] m2_o5ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.adder.m2: the unit's shared partitioned adder (subword partitioned_carry_chain)
  assign m2_add_sLANE = pc_s_m2[(LANE)*8 +: 8];
  assign m2_add_coutLANE = pc_co_m2[(LANE+1)*1-1];
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_o0ex0_LANE = 'x; m2_o1ex0_LANE = 'x; m2_o2ex0_LANE = 'x; m2_o3ex0_LANE = 'x; m2_o4ex0_LANE = 'x; m2_o5ex0_LANE = 'x;
    pc_a_m2 = '0; pc_b_m2 = '0; pc_cin_m2 = '0;
    case (op)
      5'd0: begin
        pc_a_m2[(LANE)*8 +: 8] = m2_aLANE; pc_b_m2[(LANE)*8 +: 8] = m2_bLANE; pc_cin_m2[(LANE)*1] = 1'b0;
        m2_o0ex0_LANE = $signed({(m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o0ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (m2_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd1: begin
        pc_a_m2[(LANE)*8 +: 8] = m2_aLANE; pc_b_m2[(LANE)*8 +: 8] = ~m2_bLANE; pc_cin_m2[(LANE)*1] = 1'b1;
        m2_o1ex0_LANE = $signed({(m2_aLANE[7] ^ ~m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o1ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ ~m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ ~m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (~m2_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd2: begin
        pc_a_m2[(LANE)*8 +: 8] = m2_aLANE; pc_b_m2[(LANE)*8 +: 8] = m2_bLANE; pc_cin_m2[(LANE)*1] = 1'b1;
        m2_o2ex0_LANE = $signed({(m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o2ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (m2_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd3: begin
        pc_a_m2[(LANE)*8 +: 8] = 8'd0; pc_b_m2[(LANE)*8 +: 8] = ~m2_aLANE; pc_cin_m2[(LANE)*1] = 1'b1;
        m2_o3ex0_LANE = $signed({(1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o3ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (m2_aLANE != 0 ? (10'd1 << 7) : 10'd0);
      end
      5'd4: begin
        pc_a_m2[(LANE)*8 +: 8] = 8'd0; pc_b_m2[(LANE)*8 +: 8] = ~m2_aLANE; pc_cin_m2[(LANE)*1] = 1'b1;
        m2_o4ex0_LANE = (m2_aLANE[7] ? $signed({(1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE), m2_add_sLANE}) : $signed({1'b0, m2_aLANE}));
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o4ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = ((m2_aLANE[7] & ((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7])) ? (10'd1 << 8) : 10'd0) | ((m2_aLANE[7] & ((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7])) ? (10'd1 << 2) : 10'd0);
      end
      5'd5: begin
        pc_a_m2[(LANE)*8 +: 8] = m2_aLANE; pc_b_m2[(LANE)*8 +: 8] = m2_bLANE; pc_cin_m2[(LANE)*1] = 1'b0;
        m2_o5ex0_LANE = $signed({(m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_sat(m2_o5ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_bitcount #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_bitcount: lane LANE of mode 2 (int8_twos_complement) for the bitcount ops popcount, clz, ctz; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_clz_aLANE;
  logic [3:0] m2_clz_nLANE;
  logic signed [18:0] m2_o18ex0_LANE;
  logic signed [18:0] m2_o19ex0_LANE;
  logic signed [18:0] m2_o20ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.bitcount.m2: family lzd_cell_tree realized by the library module fam_count_lzd_pair_cell_one_hot_shift_controls_vflat_w8 (clz)
  fam_count_lzd_pair_cell_one_hot_shift_controls_vflat_w8 u_m2_clzLANE (.a(m2_clz_aLANE), .n(m2_clz_nLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_clz_aLANE = 'x; m2_o18ex0_LANE = 'x; m2_o19ex0_LANE = 'x; m2_o20ex0_LANE = 'x;
    case (op)
      5'd18: begin
        y_m2[((LANE*8)+0) +: 8] = m2_aLANE[0] + m2_aLANE[1] + m2_aLANE[2] + m2_aLANE[3] + m2_aLANE[4] + m2_aLANE[5] + m2_aLANE[6] + m2_aLANE[7];
      end
      5'd19: begin
        m2_clz_aLANE = m2_aLANE;
        y_m2[((LANE*8)+0) +: 8] = {{4{1'b0}}, m2_clz_nLANE};
      end
      5'd20: begin
        y_m2[((LANE*8)+0) +: 8] = m2_aLANE[0] ? 8'd0 : m2_aLANE[1] ? 8'd1 : m2_aLANE[2] ? 8'd2 : m2_aLANE[3] ? 8'd3 : m2_aLANE[4] ? 8'd4 : m2_aLANE[5] ? 8'd5 : m2_aLANE[6] ? 8'd6 : m2_aLANE[7] ? 8'd7 : 8'd8;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_comparator #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_comparator: lane LANE of mode 2 (int8_twos_complement) for the comparator ops min, max, cmp; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_cmp_aLANE;
  logic [7:0] m2_cmp_bLANE;
  logic m2_cmp_ltLANE;
  logic m2_cmp_eqLANE;
  logic signed [18:0] m2_o8ex0_LANE;
  logic signed [18:0] m2_o9ex0_LANE;
  logic signed [18:0] m2_o10ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.comparator.m2: family subtractor_comparator realized by the library module fam_cmp_subtractor_manchester_carry_chain_pfc941ade37d4d8c30fe18473b17948ce924f25b19ce7c1959c47b46481c36035_sum_or_tree_s_w8
  fam_cmp_subtractor_manchester_carry_chain_pfc941ade37d4d8c30fe18473b17948ce924f25b19ce7c1959c47b46481c36035_sum_or_tree_s_w8 u_m2_cmpLANE (.a(m2_cmp_aLANE), .b(m2_cmp_bLANE), .lt(m2_cmp_ltLANE), .eq(m2_cmp_eqLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_cmp_aLANE = 'x; m2_cmp_bLANE = 'x; m2_o8ex0_LANE = 'x; m2_o9ex0_LANE = 'x; m2_o10ex0_LANE = 'x;
    case (op)
      5'd8: begin
        m2_cmp_aLANE = m2_aLANE; m2_cmp_bLANE = m2_bLANE;
        y_m2[((LANE*8)+0) +: 8] = (m2_cmp_ltLANE | m2_cmp_eqLANE) ? m2_aLANE : m2_bLANE;
      end
      5'd9: begin
        m2_cmp_aLANE = m2_aLANE; m2_cmp_bLANE = m2_bLANE;
        y_m2[((LANE*8)+0) +: 8] = (~m2_cmp_ltLANE) ? m2_aLANE : m2_bLANE;
      end
      5'd10: begin
        m2_cmp_aLANE = m2_aLANE; m2_cmp_bLANE = m2_bLANE;
        y_m2[((LANE*8)+0) +: 8] = {{5{1'b0}}, (~m2_cmp_ltLANE & ~m2_cmp_eqLANE), m2_cmp_eqLANE, m2_cmp_ltLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_logic #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_logic: lane LANE of mode 2 (int8_twos_complement) for the logic ops and, or, xor, not; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_lg_aLANE;
  logic [7:0] m2_lg_bLANE;
  logic [1:0] m2_lg_opLANE;
  logic [7:0] m2_lg_yLANE;
  logic signed [18:0] m2_o14ex0_LANE;
  logic signed [18:0] m2_o15ex0_LANE;
  logic signed [18:0] m2_o16ex0_LANE;
  logic signed [18:0] m2_o17ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.logic.m2: family lane_replicated_gates realized by the library module fam_logic_gate_row
  fam_logic_gate_row #(.W(8), .NOT_VIA_XOR(0)) u_m2_logicLANE (.a(m2_lg_aLANE), .b(m2_lg_bLANE), .op(m2_lg_opLANE), .y(m2_lg_yLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_lg_aLANE = 'x; m2_lg_bLANE = 'x; m2_lg_opLANE = 'x; m2_o14ex0_LANE = 'x; m2_o15ex0_LANE = 'x; m2_o16ex0_LANE = 'x;
    m2_o17ex0_LANE = 'x;
    case (op)
      5'd14: begin
        m2_lg_aLANE = m2_aLANE; m2_lg_bLANE = m2_bLANE; m2_lg_opLANE = 2'd0;
        y_m2[((LANE*8)+0) +: 8] = m2_lg_yLANE;
      end
      5'd15: begin
        m2_lg_aLANE = m2_aLANE; m2_lg_bLANE = m2_bLANE; m2_lg_opLANE = 2'd1;
        y_m2[((LANE*8)+0) +: 8] = m2_lg_yLANE;
      end
      5'd16: begin
        m2_lg_aLANE = m2_aLANE; m2_lg_bLANE = m2_bLANE; m2_lg_opLANE = 2'd2;
        y_m2[((LANE*8)+0) +: 8] = m2_lg_yLANE;
      end
      5'd17: begin
        m2_lg_aLANE = m2_aLANE; m2_lg_bLANE = m2_bLANE; m2_lg_opLANE = 2'd3;
        y_m2[((LANE*8)+0) +: 8] = m2_lg_yLANE;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_multiplier #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_multiplier: lane LANE of mode 2 (int8_twos_complement) for the multiplier ops mul, mul_high; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_mul_aLANE;
  logic [7:0] m2_mul_bLANE;
  logic [15:0] m2_mul_pLANE;
  logic signed [18:0] m2_o6ex0_LANE;
  logic signed [18:0] m2_o7ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.multiplier.m2: family segmented_grid realized by the library module fam_mul_segmented_grid_w8_s_pf90d0475
  fam_mul_segmented_grid_w8_s_pf90d0475 u_m2_mulLANE (.a(m2_mul_aLANE), .b(m2_mul_bLANE), .p(m2_mul_pLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_mul_aLANE = 'x; m2_mul_bLANE = 'x; m2_o6ex0_LANE = 'x; m2_o7ex0_LANE = 'x;
    case (op)
      5'd6: begin
        m2_mul_aLANE = m2_aLANE; m2_mul_bLANE = m2_bLANE;
        m2_o6ex0_LANE = $signed({{3{m2_mul_pLANE[15]}}, m2_mul_pLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o6ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (m2_o6ex0_LANE > 19'sd127 || m2_o6ex0_LANE < -19'sd128 ? (10'd1 << 8) : 10'd0) | (m2_o6ex0_LANE > 19'sd127 || m2_o6ex0_LANE < -19'sd128 ? (10'd1 << 2) : 10'd0);
      end
      5'd7: begin
        m2_mul_aLANE = m2_aLANE; m2_mul_bLANE = m2_bLANE;
        m2_o7ex0_LANE = $signed({{3{m2_mul_pLANE[15]}}, m2_mul_pLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o7ex0_LANE >>> 8);
        fl_m2[(0+LANE)*10 +: 10] = (m2_o7ex0_LANE > 19'sd127 || m2_o7ex0_LANE < -19'sd128 ? (10'd1 << 8) : 10'd0) | (m2_o7ex0_LANE > 19'sd127 || m2_o7ex0_LANE < -19'sd128 ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_shifter #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_shifter: lane LANE of mode 2 (int8_twos_complement) for the shifter ops shl, shr_arith, rol; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_sh_aLANE;
  logic [2:0] m2_sh_amtLANE;
  logic [2:0] m2_sh_opLANE;
  logic [7:0] m2_sh_yLANE;
  logic signed [18:0] m2_o11ex0_LANE;
  logic signed [18:0] m2_o12ex0_LANE;
  logic signed [18:0] m2_o13ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.shifter.m2: family barrel_mux_tree realized by the library module fam_shift_barrel_mux_tree
  fam_shift_barrel_mux_tree #(.W(8), .RADIX_LOG2(3), .ONE_HOT(0), .DIR(0), .ORDER(1), .STICKY(0)) u_m2_shifterLANE (.a(m2_sh_aLANE), .amt(m2_sh_amtLANE), .op(m2_sh_opLANE), .y(m2_sh_yLANE), .sticky());
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_sh_aLANE = 'x; m2_sh_amtLANE = 'x; m2_sh_opLANE = 'x; m2_o11ex0_LANE = 'x; m2_o12ex0_LANE = 'x; m2_o13ex0_LANE = 'x;
    case (op)
      5'd11: begin
        m2_sh_aLANE = m2_aLANE; m2_sh_amtLANE = 3'(m2_bLANE % 8'd8); m2_sh_opLANE = 3'd0;
        y_m2[((LANE*8)+0) +: 8] = m2_sh_yLANE;
      end
      5'd12: begin
        m2_sh_aLANE = m2_aLANE; m2_sh_amtLANE = 3'(m2_bLANE % 8'd8); m2_sh_opLANE = 3'd2;
        y_m2[((LANE*8)+0) +: 8] = m2_sh_yLANE;
      end
      5'd13: begin
        m2_sh_aLANE = m2_aLANE; m2_sh_amtLANE = 3'(m2_bLANE % 8'd8); m2_sh_opLANE = 3'd3;
        y_m2[((LANE*8)+0) +: 8] = m2_sh_yLANE;
      end
      default: ;
    endcase
  end
endmodule
// ADIR-MEMBER m0_l0_adder
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_adder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_adder: physical structure `m0.l0.adder` (kind adder, slot adder); realizes m0.l0.adder: adder, mode 0 lane 0, int16_twos_complement, ops add, sub, adc, neg, abs, add_sat
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] pc_a_m0;
  logic [15:0] pc_b_m0;
  logic pc_cin_m0;
  logic [15:0] pc_s_m0;
  logic pc_co_m0;
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  logic [15:0] pc_a_m0_l0;
  logic [15:0] pc_b_m0_l0;
  logic pc_cin_m0_l0;
  logic pc_sel;
  logic [15:0] pc_a;
  logic [15:0] pc_b;
  logic pc_cin;
  logic [15:0] pc_s;
  logic pc_co;
  alu_core_m0_adder_sh #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0), .pc_a_m0(pc_a_m0_l0), .pc_b_m0(pc_b_m0_l0), .pc_cin_m0(pc_cin_m0_l0), .pc_s_m0(pc_s_m0), .pc_co_m0(pc_co_m0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
  assign pc_a_m0 = pc_a_m0_l0;
  assign pc_b_m0 = pc_b_m0_l0;
  assign pc_cin_m0 = pc_cin_m0_l0;
  assign pc_sel = (mode == 2'd0) ? 1'd0 : '0;
  assign pc_a = (mode == 2'd0) ? pc_a_m0 : '0;
  assign pc_b = (mode == 2'd0) ? pc_b_m0 : '0;
  assign pc_cin = (mode == 2'd0) ? pc_cin_m0 : '0;
  // subword partitioned_carry_chain: one library adder over the whole word, its carries cut at the selected packing's lane boundaries (1 x int16_twos_complement)
  fam_add_partitioned_w16_16_carry_kill_gate_a34218975ba5 u_part (.a(pc_a), .b(pc_b), .cin(pc_cin), .sel(pc_sel), .s(pc_s), .cout(pc_co));
  assign pc_s_m0 = pc_s;
  assign pc_co_m0 = pc_co;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_multiplier: physical structure `m0.l0.multiplier` (kind multiplier, slot multiplier); realizes m0.l0.multiplier: multiplier, mode 0 lane 0, int16_twos_complement, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_multiplier #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_comparator: physical structure `m0.l0.comparator` (kind comparator, slot comparator); realizes m0.l0.comparator: comparator, mode 0 lane 0, int16_twos_complement, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_comparator #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_shifter: physical structure `m0.l0.shifter` (kind shifter, slot shifter); realizes m0.l0.shifter: shifter, mode 0 lane 0, int16_twos_complement, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_shifter #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_logic
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_logic (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_logic: physical structure `m0.l0.logic` (kind logic, slot logic); realizes m0.l0.logic: logic, mode 0 lane 0, int16_twos_complement, ops and, or, xor, not
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_logic #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_bitcount: physical structure `m0.l0.bitcount` (kind bitcount, slot bitcount); realizes m0.l0.bitcount: bitcount, mode 0 lane 0, int16_twos_complement, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_bitcount #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_adder
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_adder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_adder: physical structure `m1.l0.adder` (kind adder, slot adder); realizes m1.l0.adder: adder, mode 1 lane 0, int16_unsigned, ops add, sub, adc, neg, abs, add_sat
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] pc_a_m1;
  logic [15:0] pc_b_m1;
  logic pc_cin_m1;
  logic [15:0] pc_s_m1;
  logic pc_co_m1;
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  logic [15:0] pc_a_m1_l0;
  logic [15:0] pc_b_m1_l0;
  logic pc_cin_m1_l0;
  logic pc_sel;
  logic [15:0] pc_a;
  logic [15:0] pc_b;
  logic pc_cin;
  logic [15:0] pc_s;
  logic pc_co;
  alu_core_m1_adder_sh #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0), .pc_a_m1(pc_a_m1_l0), .pc_b_m1(pc_b_m1_l0), .pc_cin_m1(pc_cin_m1_l0), .pc_s_m1(pc_s_m1), .pc_co_m1(pc_co_m1));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
  assign pc_a_m1 = pc_a_m1_l0;
  assign pc_b_m1 = pc_b_m1_l0;
  assign pc_cin_m1 = pc_cin_m1_l0;
  assign pc_sel = (mode == 2'd1) ? 1'd0 : '0;
  assign pc_a = (mode == 2'd1) ? pc_a_m1 : '0;
  assign pc_b = (mode == 2'd1) ? pc_b_m1 : '0;
  assign pc_cin = (mode == 2'd1) ? pc_cin_m1 : '0;
  // subword partitioned_carry_chain: one library adder over the whole word, its carries cut at the selected packing's lane boundaries (1 x int16_unsigned)
  fam_add_partitioned_w16_16_carry_kill_gate_a34218975ba5 u_part (.a(pc_a), .b(pc_b), .cin(pc_cin), .sel(pc_sel), .s(pc_s), .cout(pc_co));
  assign pc_s_m1 = pc_s;
  assign pc_co_m1 = pc_co;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_multiplier: physical structure `m1.l0.multiplier` (kind multiplier, slot multiplier); realizes m1.l0.multiplier: multiplier, mode 1 lane 0, int16_unsigned, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_multiplier #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_comparator: physical structure `m1.l0.comparator` (kind comparator, slot comparator); realizes m1.l0.comparator: comparator, mode 1 lane 0, int16_unsigned, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_comparator #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_shifter: physical structure `m1.l0.shifter` (kind shifter, slot shifter); realizes m1.l0.shifter: shifter, mode 1 lane 0, int16_unsigned, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_shifter #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_logic
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_logic (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_logic: physical structure `m1.l0.logic` (kind logic, slot logic); realizes m1.l0.logic: logic, mode 1 lane 0, int16_unsigned, ops and, or, xor, not
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_logic #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_bitcount: physical structure `m1.l0.bitcount` (kind bitcount, slot bitcount); realizes m1.l0.bitcount: bitcount, mode 1 lane 0, int16_unsigned, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_bitcount #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_adder
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_adder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_adder: physical structure `m2.l0.adder` (kind adder, slot adder); realizes m2.l0.adder: adder, mode 2 lane 0, int8_twos_complement, ops add, sub, adc, neg, abs, add_sat
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] pc_a_m2;
  logic [15:0] pc_b_m2;
  logic [1:0] pc_cin_m2;
  logic [15:0] pc_s_m2;
  logic [1:0] pc_co_m2;
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  logic [15:0] pc_a_m2_l0;
  logic [15:0] pc_b_m2_l0;
  logic [1:0] pc_cin_m2_l0;
  logic pc_sel;
  logic [15:0] pc_a;
  logic [15:0] pc_b;
  logic [1:0] pc_cin;
  logic [15:0] pc_s;
  logic [1:0] pc_co;
  alu_core_m2_adder_sh #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0), .pc_a_m2(pc_a_m2_l0), .pc_b_m2(pc_b_m2_l0), .pc_cin_m2(pc_cin_m2_l0), .pc_s_m2(pc_s_m2), .pc_co_m2(pc_co_m2));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
  assign pc_a_m2 = pc_a_m2_l0;
  assign pc_b_m2 = pc_b_m2_l0;
  assign pc_cin_m2 = pc_cin_m2_l0;
  assign pc_sel = (mode == 2'd2) ? 1'd0 : '0;
  assign pc_a = (mode == 2'd2) ? pc_a_m2 : '0;
  assign pc_b = (mode == 2'd2) ? pc_b_m2 : '0;
  assign pc_cin = (mode == 2'd2) ? pc_cin_m2 : '0;
  // subword partitioned_carry_chain: one library adder over the whole word, its carries cut at the selected packing's lane boundaries (2 x int8_twos_complement)
  fam_add_partitioned_w16_8_carry_kill_gate_a34218975ba5 u_part (.a(pc_a), .b(pc_b), .cin(pc_cin), .sel(pc_sel), .s(pc_s), .cout(pc_co));
  assign pc_s_m2 = pc_s;
  assign pc_co_m2 = pc_co;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_adder
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_adder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_adder: physical structure `m2.l1.adder` (kind adder, slot adder); realizes m2.l1.adder: adder, mode 2 lane 1, int8_twos_complement, ops add, sub, adc, neg, abs, add_sat
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] pc_a_m2;
  logic [15:0] pc_b_m2;
  logic [1:0] pc_cin_m2;
  logic [15:0] pc_s_m2;
  logic [1:0] pc_co_m2;
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  logic [15:0] pc_a_m2_l1;
  logic [15:0] pc_b_m2_l1;
  logic [1:0] pc_cin_m2_l1;
  logic pc_sel;
  logic [15:0] pc_a;
  logic [15:0] pc_b;
  logic [1:0] pc_cin;
  logic [15:0] pc_s;
  logic [1:0] pc_co;
  alu_core_m2_adder_sh #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1), .pc_a_m2(pc_a_m2_l1), .pc_b_m2(pc_b_m2_l1), .pc_cin_m2(pc_cin_m2_l1), .pc_s_m2(pc_s_m2), .pc_co_m2(pc_co_m2));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
  assign pc_a_m2 = pc_a_m2_l1;
  assign pc_b_m2 = pc_b_m2_l1;
  assign pc_cin_m2 = pc_cin_m2_l1;
  assign pc_sel = (mode == 2'd2) ? 1'd0 : '0;
  assign pc_a = (mode == 2'd2) ? pc_a_m2 : '0;
  assign pc_b = (mode == 2'd2) ? pc_b_m2 : '0;
  assign pc_cin = (mode == 2'd2) ? pc_cin_m2 : '0;
  // subword partitioned_carry_chain: one library adder over the whole word, its carries cut at the selected packing's lane boundaries (2 x int8_twos_complement)
  fam_add_partitioned_w16_8_carry_kill_gate_a34218975ba5 u_part (.a(pc_a), .b(pc_b), .cin(pc_cin), .sel(pc_sel), .s(pc_s), .cout(pc_co));
  assign pc_s_m2 = pc_s;
  assign pc_co_m2 = pc_co;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_multiplier: physical structure `m2.l0.multiplier` (kind multiplier, slot multiplier); realizes m2.l0.multiplier: multiplier, mode 2 lane 0, int8_twos_complement, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_multiplier #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_multiplier: physical structure `m2.l1.multiplier` (kind multiplier, slot multiplier); realizes m2.l1.multiplier: multiplier, mode 2 lane 1, int8_twos_complement, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_multiplier #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_comparator: physical structure `m2.l0.comparator` (kind comparator, slot comparator); realizes m2.l0.comparator: comparator, mode 2 lane 0, int8_twos_complement, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_comparator #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_comparator: physical structure `m2.l1.comparator` (kind comparator, slot comparator); realizes m2.l1.comparator: comparator, mode 2 lane 1, int8_twos_complement, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_comparator #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_shifter: physical structure `m2.l0.shifter` (kind shifter, slot shifter); realizes m2.l0.shifter: shifter, mode 2 lane 0, int8_twos_complement, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_shifter #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_shifter: physical structure `m2.l1.shifter` (kind shifter, slot shifter); realizes m2.l1.shifter: shifter, mode 2 lane 1, int8_twos_complement, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_shifter #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_logic
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_logic (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_logic: physical structure `m2.l0.logic` (kind logic, slot logic); realizes m2.l0.logic: logic, mode 2 lane 0, int8_twos_complement, ops and, or, xor, not
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_logic #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_logic
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_logic (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_logic: physical structure `m2.l1.logic` (kind logic, slot logic); realizes m2.l1.logic: logic, mode 2 lane 1, int8_twos_complement, ops and, or, xor, not
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_logic #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_bitcount: physical structure `m2.l0.bitcount` (kind bitcount, slot bitcount); realizes m2.l0.bitcount: bitcount, mode 2 lane 0, int8_twos_complement, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_bitcount #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_bitcount: physical structure `m2.l1.bitcount` (kind bitcount, slot bitcount); realizes m2.l1.bitcount: bitcount, mode 2 lane 1, int8_twos_complement, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_bitcount #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER library
// ---- the family library modules the lane modules instantiate (chialu/targets/rtl/families; fixed text, replaced by editing the instances)
// partitioned_carry_chain (carry_kill_gate, carry_lookahead segments of 16 bits): one adder for the lane packings 1 x 16, the carry cut at the selected mode's lane boundaries
module fam_add_partitioned_w16_16_carry_kill_gate_a34218975ba5 (input logic [15:0] a, input logic [15:0] b, input logic [0:0] cin, input logic [0:0] sel, output logic [15:0] s, output logic [0:0] cout);
  logic [1:0] c;
  assign c[0] = cin[0];
  logic co0;
  fam_adder_carry_lookahead #(.W(16), .G(6), .INTER(1), .LEVELS(1)) u0 (.a(a[15:0]), .b(b[15:0]), .cin(c[0]), .s(s[15:0]), .cout(co0));
  assign cout[0] = co0;
  assign c[1] = co0;
endmodule


// partitioned_carry_chain (carry_kill_gate, carry_lookahead segments of 8 bits): one adder for the lane packings 2 x 8, the carry cut at the selected mode's lane boundaries
module fam_add_partitioned_w16_8_carry_kill_gate_a34218975ba5 (input logic [15:0] a, input logic [15:0] b, input logic [1:0] cin, input logic [0:0] sel, output logic [15:0] s, output logic [1:0] cout);
  logic [2:0] c;
  assign c[0] = cin[0];
  logic co0;
  fam_adder_carry_lookahead #(.W(8), .G(6), .INTER(1), .LEVELS(1)) u0 (.a(a[7:0]), .b(b[7:0]), .cin(c[0]), .s(s[7:0]), .cout(co0));
  assign cout[0] = co0;
  logic bnd1; assign bnd1 = (sel == 1'd0);
  assign c[1] = (co0 & ~bnd1) | (cin[1] & bnd1);
  logic co1;
  fam_adder_carry_lookahead #(.W(8), .G(6), .INTER(1), .LEVELS(1)) u1 (.a(a[15:8]), .b(b[15:8]), .cin(c[1]), .s(s[15:8]), .cout(co1));
  assign cout[1] = co1;
  assign c[2] = co1;
endmodule



// carry_increment: blocks [2, 1] (variable_ramp), group carries lookahead_tree, 1 increment level
module fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w3 (input logic [2:0] a, input logic [2:0] b, input logic cin, output logic [2:0] s, output logic cout);
  logic [1:0] s0;
  logic co0;
  // block 0 (2 bits), carry-in 0
  fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w3_component_block_adder_adder_w2 u1 (.a(a[1:0]), .b(b[1:0]), .cin(1'b0), .s(s0), .cout(co0));
  logic bp0; assign bp0 = &(a[1:0] ^ b[1:0]);
  logic s1;
  logic co1;
  // block 1 (1 bits), carry-in 0
  fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w3_component_block_adder_adder_w1 u2 (.a(a[2:2]), .b(b[2:2]), .cin(1'b0), .s(s1), .cout(co1));
  logic bp1; assign bp1 = &(a[2:2] ^ b[2:2]);
  logic la_t0_0; assign la_t0_0 = co0 | (bp0 & cin);
  logic la_t1_0; assign la_t1_0 = co0 | (bp0 & cin);
  logic la_t1_1; assign la_t1_1 = co1 | (bp1 & la_t1_0);
  logic [1:0] si0;
  logic ico0;
  // block 0: the carry-in through the increment stage
  fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w3_component_increment_stage_incrementer_w2 u3 (.a(s0), .cin(cin), .s(si0), .cout(ico0));
  assign s[1:0] = si0;
  logic si1;
  logic ico1;
  // block 1: the carry-in through the increment stage
  fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w3_component_increment_stage_incrementer_w1 u4 (.a(s1), .cin(la_t0_0), .s(si1), .cout(ico1));
  assign s[2:2] = si1;
  assign cout = la_t1_1;
endmodule





module fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w3_component_block_adder_adder_w1(input wire [0:0] a, input wire [0:0] b, input wire [0:0] cin, output wire [0:0] s, output wire [0:0] cout);
fam_prefix_knowles_mixed_w1 implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w3_component_block_adder_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_prefix_knowles_mixed_w2 implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule





module fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w3_component_increment_stage_incrementer_w1(input wire [0:0] a, input wire [0:0] cin, output wire [0:0] s, output wire [0:0] cout);
fam_incr_prefix_and #(.W(1), .STRUCTURE(2), .B(4), .TOPO(0)) implementation(.a(a), .cin(cin), .s(s), .cout(cout));
endmodule





module fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w3_component_increment_stage_incrementer_w2(input wire [1:0] a, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_incr_prefix_and #(.W(2), .STRUCTURE(2), .B(4), .TOPO(0)) implementation(.a(a), .cin(cin), .s(s), .cout(cout));
endmodule


// carry_increment: blocks [2, 2] (variable_ramp), group carries lookahead_tree, 1 increment level
module fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w4 (input logic [3:0] a, input logic [3:0] b, input logic cin, output logic [3:0] s, output logic cout);
  logic [1:0] s0;
  logic co0;
  // block 0 (2 bits), carry-in 0
  fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w4_component_block_adder_adder_w2 u1 (.a(a[1:0]), .b(b[1:0]), .cin(1'b0), .s(s0), .cout(co0));
  logic bp0; assign bp0 = &(a[1:0] ^ b[1:0]);
  logic [1:0] s1;
  logic co1;
  // block 1 (2 bits), carry-in 0
  fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w4_component_block_adder_adder_w2 u2 (.a(a[3:2]), .b(b[3:2]), .cin(1'b0), .s(s1), .cout(co1));
  logic bp1; assign bp1 = &(a[3:2] ^ b[3:2]);
  logic la_t0_0; assign la_t0_0 = co0 | (bp0 & cin);
  logic la_t1_0; assign la_t1_0 = co0 | (bp0 & cin);
  logic la_t1_1; assign la_t1_1 = co1 | (bp1 & la_t1_0);
  logic [1:0] si0;
  logic ico0;
  // block 0: the carry-in through the increment stage
  fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w4_component_increment_stage_incrementer_w2 u3 (.a(s0), .cin(cin), .s(si0), .cout(ico0));
  assign s[1:0] = si0;
  logic [1:0] si1;
  logic ico1;
  // block 1: the carry-in through the increment stage
  fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w4_component_increment_stage_incrementer_w2 u4 (.a(s1), .cin(la_t0_0), .s(si1), .cout(ico1));
  assign s[3:2] = si1;
  assign cout = la_t1_1;
endmodule




module fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w4_component_block_adder_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_prefix_knowles_mixed_w2 implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule








module fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w4_component_increment_stage_incrementer_w2(input wire [1:0] a, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_incr_prefix_and #(.W(2), .STRUCTURE(2), .B(4), .TOPO(0)) implementation(.a(a), .cin(cin), .s(s), .cout(cout));
endmodule




// ------------------------------------------------------------ prefix_and_incrementer
// s = a + cin: the carry into bit i is cin AND every lower bit, a prefix AND
// (STRUCTURE 0 a ripple AND chain, 1 a prefix AND tree of topology TOPO, 2
// select blocks of B bits whose block carry is the AND of the block)







// -------------------------------------------------------------- carry_lookahead
// groups of G bits with a one-level lookahead inside the group (the carries of
// the group from its bit generates and propagates and the group carry-in); the
// group carries come from LEVELS levels of lookahead over the group generates
// and propagates (fam_adder_cla_level): rippled (INTER = 0), looked ahead
// (INTER = 1), or selected (INTER = 2: every group's sum is formed for both
// carry-ins and the rippled group carry selects it, the carry-select stage
// above lookahead blocks).
module fam_adder_carry_lookahead #(parameter int W = 16, parameter int G = 4, parameter int INTER = 0, parameter int LEVELS = 1)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  localparam int NG = (W + G - 1) / G;
  logic [W-1:0] g, p;
  assign g = a & b;
  assign p = a ^ b;
  logic [NG-1:0] gc;                  // the carry into each group
  logic [NG-1:0] GG, GP;              // group generate and propagate
  genvar k, i;
  generate
    for (k = 0; k < NG; k = k + 1) begin : grp
      localparam int LO = k * G;
      localparam int HI = (LO + G > W) ? W : LO + G;
      localparam int NB = HI - LO;
      // the group's generate and propagate from its bits
      logic [NB:0] lg, lp;
      assign lg[0] = 1'b0;
      assign lp[0] = 1'b1;
      for (i = 0; i < NB; i = i + 1) begin : acc
        assign lg[i+1] = g[LO+i] | (p[LO+i] & lg[i]);
        assign lp[i+1] = p[LO+i] & lp[i];
      end
      assign GG[k] = lg[NB];
      assign GP[k] = lp[NB];
      if (INTER == 2) begin : select
        // both sums of the group, selected by the group carry
        logic [NB-1:0] c0, c1;
        for (i = 0; i < NB; i = i + 1) begin : cc
          assign c0[i] = lg[i];
          assign c1[i] = lg[i] | lp[i];
          assign s[LO+i] = p[LO+i] ^ (gc[k] ? c1[i] : c0[i]);
        end
      end else begin : direct
        for (i = 0; i < NB; i = i + 1) begin : cc
          assign s[LO+i] = p[LO+i] ^ (lg[i] | (lp[i] & gc[k]));
        end
      end
    end
    begin : levels
      fam_adder_cla_level #(.N(NG), .G(G), .LEVELS(LEVELS), .INTER(INTER))
        u_lvl (.gg(GG), .gp(GP), .cin(cin), .c(gc), .cout(cout));
    end
  endgenerate
endmodule



// ------------------------------------------------------------ the lookahead levels
// The carries into N elements from their generate and propagate pairs and a
// carry-in: LEVELS = 1 resolves the N elements flat, the element carries
// rippled (INTER = 0) or looked ahead (INTER = 1); LEVELS > 1 groups G
// elements into super-groups, resolves the super-group carries with the same
// structure one level up, and looks ahead inside every super-group.
module fam_adder_cla_level #(parameter int N = 4, parameter int G = 4, parameter int LEVELS = 1, parameter int INTER = 0)
  (input logic [N-1:0] gg, input logic [N-1:0] gp, input logic cin, output logic [N-1:0] c, output logic cout);
  genvar k, i;
  generate
    if (LEVELS <= 1 || N <= G) begin : flat
      if (INTER == 1) begin : lookahead
        for (k = 0; k < N; k = k + 1) begin : lg
          logic [k+1:0] t;
          assign t[0] = cin;
          for (i = 0; i <= k; i = i + 1) begin : tt
            assign t[i+1] = gg[i] | (gp[i] & t[i]);
          end
          assign c[k] = t[k];
          if (k == N - 1) begin : last
            assign cout = t[k+1];
          end
        end
      end else if (INTER == 2) begin : select
        logic [N:0] r;
        assign r[0] = cin;
        for (k = 0; k < N; k = k + 1) begin : rg
          assign r[k+1] = r[k] ? (gg[k] | gp[k]) : gg[k];
          assign c[k] = r[k];
        end
        assign cout = r[N];
      end else begin : ripple
        logic [N:0] r;
        assign r[0] = cin;
        for (k = 0; k < N; k = k + 1) begin : rg
          assign r[k+1] = gg[k] | (gp[k] & r[k]);
          assign c[k] = r[k];
        end
        assign cout = r[N];
      end
    end else begin : hier
      localparam int NS = (N + G - 1) / G;
      logic [NS-1:0] sgg, sgp, sc;
      for (k = 0; k < NS; k = k + 1) begin : sg
        localparam int LO = k * G;
        localparam int HI = (LO + G > N) ? N : LO + G;
        // the super-group's generate and propagate from its elements
        logic [HI-LO:0] lg, lp;
        assign lg[0] = 1'b0;
        assign lp[0] = 1'b1;
        for (i = 0; i < HI - LO; i = i + 1) begin : acc
          assign lg[i+1] = gg[LO+i] | (gp[LO+i] & lg[i]);
          assign lp[i+1] = gp[LO+i] & lp[i];
          // the lookahead carry into element LO+i from the super-group carry-in
          if (INTER == 2) begin : select
            assign c[LO+i] = sc[k] ? (lg[i] | lp[i]) : lg[i];
          end else begin : lookahead
            assign c[LO+i] = lg[i] | (lp[i] & sc[k]);
          end
        end
        assign sgg[k] = lg[HI-LO];
        assign sgp[k] = lp[HI-LO];
      end
      fam_adder_cla_level #(.N(NS), .G(G), .LEVELS(LEVELS - 1), .INTER(INTER))
        u_up (.gg(sgg), .gp(sgp), .cin(cin), .c(sc), .cout(cout));
    end
  endgenerate
endmodule



// -------------------------------------------------------- manchester_carry_chain
// the pass-device carry chain in its synthesizable form: per bit a kill, a
// propagate and a generate, the carry passing through the chain in segments of
// SEG bits (chain_segment_length). VARSKIP = 1 (variable_skip) bypasses a
// segment whose bits all propagate: the segment's carry-out is its carry-in.
module fam_adder_manchester_carry_chain #(parameter int W = 16, parameter int SEG = 4, parameter int VARSKIP = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  localparam int NS = (W + SEG - 1) / SEG;
  logic [W-1:0] g, p, k, pass;
  assign g = a & b;
  assign p = a ^ b;
  assign k = ~(a | b);
  assign pass = ~g & ~k;              // the carry passes when neither killed nor generated
  logic [NS:0] sc;                    // the carry into each segment
  assign sc[0] = cin;
  genvar j, i;
  generate
    for (j = 0; j < NS; j = j + 1) begin : seg
      localparam int LO = j * SEG;
      localparam int HI = (LO + SEG > W) ? W : LO + SEG;
      logic [HI-LO:0] c;
      assign c[0] = sc[j];
      for (i = 0; i < HI - LO; i = i + 1) begin : bit_
        assign c[i+1] = (pass[LO+i] & c[i]) | g[LO+i];
        assign s[LO+i] = p[LO+i] ^ c[i];
      end
      if (VARSKIP) begin : skip
        wire allpass = &pass[HI-1:LO];
        assign sc[j+1] = allpass ? sc[j] : c[HI-LO];
      end else begin : chain
        assign sc[j+1] = c[HI-LO];
      end
    end
  endgenerate
  assign cout = sc[NS];
endmodule



















































// sparse_prefix_hybrid: a han_carlson prefix network over blocks of 2 bits, the sums by carry_select
module fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18 (input logic [17:0] a, input logic [17:0] b, input logic cin, output logic [17:0] s, output logic cout);
  logic [17:0] g; assign g = a & b;
  logic [17:0] p; assign p = a ^ b;
  logic BG0; assign BG0 = (g[1] | (p[1] & g[0]));
  logic BP0; assign BP0 = (p[1] & p[0]);
  logic BG1; assign BG1 = (g[3] | (p[3] & g[2]));
  logic BP1; assign BP1 = (p[3] & p[2]);
  logic BG2; assign BG2 = (g[5] | (p[5] & g[4]));
  logic BP2; assign BP2 = (p[5] & p[4]);
  logic BG3; assign BG3 = (g[7] | (p[7] & g[6]));
  logic BP3; assign BP3 = (p[7] & p[6]);
  logic BG4; assign BG4 = (g[9] | (p[9] & g[8]));
  logic BP4; assign BP4 = (p[9] & p[8]);
  logic BG5; assign BG5 = (g[11] | (p[11] & g[10]));
  logic BP5; assign BP5 = (p[11] & p[10]);
  logic BG6; assign BG6 = (g[13] | (p[13] & g[12]));
  logic BP6; assign BP6 = (p[13] & p[12]);
  logic BG7; assign BG7 = (g[15] | (p[15] & g[14]));
  logic BP7; assign BP7 = (p[15] & p[14]);
  logic BG8; assign BG8 = (g[17] | (p[17] & g[16]));
  logic BP8; assign BP8 = (p[17] & p[16]);
  logic [8:0] net_g; assign net_g = {BG8, BG7, BG6, BG5, BG4, BG3, BG2, BG1, BG0};
  logic [8:0] net_p; assign net_p = {BP8, BP7, BP6, BP5, BP4, BP3, BP2, BP1, BP0};
  logic [8:0] net_c;
  logic net_co;
  // the prefix network over the blocks (han_carlson)
  fam_prefix_net_han_carlson_w9 u1 (.g(net_g), .p(net_p), .cin(cin), .c(net_c), .cout(net_co));
  logic [1:0] s0_0;
  logic [1:0] s0_1;
  logic x0_0;
  logic x0_1;
  // block 0: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u2 (.a(a[1:0]), .b(b[1:0]), .cin(1'b0), .s(s0_0), .cout(x0_0));
  // block 0: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u3 (.a(a[1:0]), .b(b[1:0]), .cin(1'b1), .s(s0_1), .cout(x0_1));
  assign s[1:0] = net_c[0] ? s0_1 : s0_0;
  logic [1:0] s1_0;
  logic [1:0] s1_1;
  logic x1_0;
  logic x1_1;
  // block 1: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u4 (.a(a[3:2]), .b(b[3:2]), .cin(1'b0), .s(s1_0), .cout(x1_0));
  // block 1: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u5 (.a(a[3:2]), .b(b[3:2]), .cin(1'b1), .s(s1_1), .cout(x1_1));
  assign s[3:2] = net_c[1] ? s1_1 : s1_0;
  logic [1:0] s2_0;
  logic [1:0] s2_1;
  logic x2_0;
  logic x2_1;
  // block 2: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u6 (.a(a[5:4]), .b(b[5:4]), .cin(1'b0), .s(s2_0), .cout(x2_0));
  // block 2: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u7 (.a(a[5:4]), .b(b[5:4]), .cin(1'b1), .s(s2_1), .cout(x2_1));
  assign s[5:4] = net_c[2] ? s2_1 : s2_0;
  logic [1:0] s3_0;
  logic [1:0] s3_1;
  logic x3_0;
  logic x3_1;
  // block 3: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u8 (.a(a[7:6]), .b(b[7:6]), .cin(1'b0), .s(s3_0), .cout(x3_0));
  // block 3: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u9 (.a(a[7:6]), .b(b[7:6]), .cin(1'b1), .s(s3_1), .cout(x3_1));
  assign s[7:6] = net_c[3] ? s3_1 : s3_0;
  logic [1:0] s4_0;
  logic [1:0] s4_1;
  logic x4_0;
  logic x4_1;
  // block 4: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u10 (.a(a[9:8]), .b(b[9:8]), .cin(1'b0), .s(s4_0), .cout(x4_0));
  // block 4: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u11 (.a(a[9:8]), .b(b[9:8]), .cin(1'b1), .s(s4_1), .cout(x4_1));
  assign s[9:8] = net_c[4] ? s4_1 : s4_0;
  logic [1:0] s5_0;
  logic [1:0] s5_1;
  logic x5_0;
  logic x5_1;
  // block 5: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u12 (.a(a[11:10]), .b(b[11:10]), .cin(1'b0), .s(s5_0), .cout(x5_0));
  // block 5: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u13 (.a(a[11:10]), .b(b[11:10]), .cin(1'b1), .s(s5_1), .cout(x5_1));
  assign s[11:10] = net_c[5] ? s5_1 : s5_0;
  logic [1:0] s6_0;
  logic [1:0] s6_1;
  logic x6_0;
  logic x6_1;
  // block 6: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u14 (.a(a[13:12]), .b(b[13:12]), .cin(1'b0), .s(s6_0), .cout(x6_0));
  // block 6: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u15 (.a(a[13:12]), .b(b[13:12]), .cin(1'b1), .s(s6_1), .cout(x6_1));
  assign s[13:12] = net_c[6] ? s6_1 : s6_0;
  logic [1:0] s7_0;
  logic [1:0] s7_1;
  logic x7_0;
  logic x7_1;
  // block 7: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u16 (.a(a[15:14]), .b(b[15:14]), .cin(1'b0), .s(s7_0), .cout(x7_0));
  // block 7: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u17 (.a(a[15:14]), .b(b[15:14]), .cin(1'b1), .s(s7_1), .cout(x7_1));
  assign s[15:14] = net_c[7] ? s7_1 : s7_0;
  logic [1:0] s8_0;
  logic [1:0] s8_1;
  logic x8_0;
  logic x8_1;
  // block 8: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u18 (.a(a[17:16]), .b(b[17:16]), .cin(1'b0), .s(s8_0), .cout(x8_0));
  // block 8: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2 u19 (.a(a[17:16]), .b(b[17:16]), .cin(1'b1), .s(s8_1), .cout(x8_1));
  assign s[17:16] = net_c[8] ? s8_1 : s8_0;
  assign cout = net_co;
endmodule




module fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18_component_sum_block_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_prefix_han_carlson_w2 implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule

// The comparator family of chiALU realized in parametric SystemVerilog:
//   fam_cmp_prefix_comparator #(W, SIGNED, STRUCTURE, RADIX) (input [W-1:0] a, b, output lt, eq)
// The subtractor form (subtractor_comparator) is generated by families/comparator.py around
// the adder of its `subtractor` slot.

// ------------------------------------------------------------ prefix_comparator
// STRUCTURE: 0 msb_first_prefix (a scan from the msb over groups of RADIX bits:
// each group gives (equal, less) flat, the groups are chained msb first), 1
// tree_reduction (a balanced tree of RADIX-ary nodes over the (equal, less)
// pairs). SIGNED flips the sign bits. RADIX is the bits a scan step groups, or
// the arity of a tree node.
module fam_cmp_prefix_comparator #(parameter int W = 16, parameter int SIGNED = 1, parameter int STRUCTURE = 0, parameter int RADIX = 2)
  (input logic [W-1:0] a, input logic [W-1:0] b, output logic lt, output logic eq);
  localparam int R = (RADIX < 2) ? 2 : RADIX;
  localparam int NG = (W + R - 1) / R;                 // the groups of R bits, group g at [g*R +: R] from the lsb
  // ceil(log_r n): the levels of an r-ary tree over n entries
  function automatic int clogr(input int n, input int r);
    int l, p;
    l = 0; p = 1;
    while (p < n) begin p = p * r; l = l + 1; end
    return l;
  endfunction
  // ceil(n / r^l): the entries of level l
  function automatic int entries(input int n, input int r, input int l);
    int m, i;
    m = n;
    for (i = 0; i < l; i = i + 1) m = (m + r - 1) / r;
    return m;
  endfunction
  logic [W-1:0] ax, bx;
  // a signed compare is an unsigned one with the sign bits inverted
  assign ax = {a[W-1] ^ (SIGNED != 0), a[W-2:0]};
  assign bx = {b[W-1] ^ (SIGNED != 0), b[W-2:0]};
  // per bit: equal, less
  logic [W-1:0] e0, l0;
  genvar i, g, l, k;
  generate
    for (i = 0; i < W; i = i + 1) begin : bit_
      assign e0[i] = (ax[i] == bx[i]);
      assign l0[i] = ~ax[i] & bx[i];
    end
    // per group of R bits (flat): equal = every bit equal; less = the first unequal bit from the top is less
    logic [NG-1:0] eg, lg;
    for (g = 0; g < NG; g = g + 1) begin : grp
      localparam int LO = g * R;
      localparam int HI = (LO + R - 1 < W - 1) ? LO + R - 1 : W - 1;
      localparam int N = HI - LO + 1;
      logic [N-1:0] ge, gl;
      assign ge = e0[HI:LO];
      assign gl = l0[HI:LO];
      assign eg[g] = &ge;
      logic [N-1:0] t;
      for (k = 0; k < N; k = k + 1) begin : tk
        // bit LO+k decides when the bits above it in the group are equal
        if (k == N - 1) begin : top
          assign t[k] = gl[k];
        end else begin : low
          assign t[k] = gl[k] & (&ge[N-1:k+1]);
        end
      end
      assign lg[g] = |t;
    end
    if (STRUCTURE == 0) begin : msb_first
      // the scan from the msb group down: e[g]: groups NG-1..g equal; ls[g]: a < b decided within them
      logic [NG:0] e, ls;
      assign e[NG] = 1'b1;
      assign ls[NG] = 1'b0;
      for (g = NG - 1; g >= 0; g = g - 1) begin : scan
        assign e[g] = e[g+1] & eg[g];
        assign ls[g] = ls[g+1] | (e[g+1] & lg[g]);
      end
      assign lt = ls[0];
      assign eq = e[0];
    end else begin : tree
      // a balanced R-ary tree over the group pairs: a node's (equal, less) from its children
      // (child c is more significant than child c-1): equal = AND of the children's equal, less =
      // OR over c of (less_c AND the children above c equal); level l holds ceil(NG / R^l) entries
      localparam int LV = (NG <= 1) ? 1 : clogr(NG, R);
      logic [NG-1:0] E [0:LV];
      logic [NG-1:0] LT [0:LV];
      assign E[0] = eg;
      assign LT[0] = lg;
      for (l = 0; l < LV; l = l + 1) begin : lvl
        localparam int MIN = entries(NG, R, l);       // the entries of the level below
        for (g = 0; g < NG; g = g + 1) begin : node
          if (g * R < MIN) begin : real_
            logic [R-1:0] ce, cl;
            for (k = 0; k < R; k = k + 1) begin : ck
              if (g * R + k < MIN) begin : in_
                assign ce[k] = E[l][g*R + k];
                assign cl[k] = LT[l][g*R + k];
              end else begin : pad
                assign ce[k] = 1'b1;
                assign cl[k] = 1'b0;
              end
            end
            assign E[l+1][g] = &ce;
            logic [R-1:0] t;
            for (k = 0; k < R; k = k + 1) begin : tk
              if (k == R - 1) begin : top
                assign t[k] = cl[k];
              end else begin : low
                assign t[k] = cl[k] & (&ce[R-1:k+1]);
              end
            end
            assign LT[l+1][g] = |t;
          end else begin : pad
            assign E[l+1][g] = 1'b1;
            assign LT[l+1][g] = 1'b0;
          end
        end
      end
      assign lt = LT[LV][0];
      assign eq = E[LV][0];
    end
  endgenerate
endmodule


// subtractor_comparator (manchester_carry_chain, sum_or_tree, signed): a - b through the adder's carry-out, the sum path unused
module fam_cmp_subtractor_manchester_carry_chain_pfc941ade37d4d8c30fe18473b17948ce924f25b19ce7c1959c47b46481c36035_sum_or_tree_s_w8 (input logic [7:0] a, input logic [7:0] b, output logic lt, output logic eq);
  logic [7:0] ax, bx, nb, s;
  logic co;
  assign ax = {a[7] ^ 1'b1, a[6:0]};
  assign bx = {b[7] ^ 1'b1, b[6:0]};
  assign nb = ~bx;
  // the subtractor: the adder (manchester_carry_chain) on a and ~b with a carry in; no carry out means a < b
  fam_adder_manchester_carry_chain #(.W(8), .SEG(4), .VARSKIP(1)) u_sub (.a(ax), .b(nb), .cin(1'b1), .s(s), .cout(co));
  assign lt = ~co;
  assign eq = (s == '0);       // the difference is zero
endmodule


// subtractor_comparator (parallel_prefix, sum_or_tree, unsigned): a - b through the adder's carry-out, the sum path unused
module fam_cmp_subtractor_parallel_prefix_pbd9960fbdb60817a7cbc141202d9c0f14994f73526a859cb772052971be31631_sum_or_tree_u_w16 (input logic [15:0] a, input logic [15:0] b, output logic lt, output logic eq);
  logic [15:0] ax, bx, nb, s;
  logic co;
  assign ax = {a[15] ^ 1'b0, a[14:0]};
  assign bx = {b[15] ^ 1'b0, b[14:0]};
  assign nb = ~bx;
  // the subtractor: the adder (parallel_prefix) on a and ~b with a carry in; no carry out means a < b
  fam_prefix_ladner_fischer_w16 u_sub (.a(ax), .b(nb), .cin(1'b1), .s(s), .cout(co));
  assign lt = ~co;
  assign eq = (s == '0);       // the difference is zero
endmodule

// lzd_cell_tree (pair_cell, one_hot_shift_controls, valid flags flat): the leading zeros of a 8-bit word
module fam_count_lzd_pair_cell_one_hot_shift_controls_vflat_w8 (input logic [7:0] a, output logic [3:0] n);
  logic [7:0] f;
  assign f[0] = a[7] & ~(1'b0);
  assign f[1] = a[6] & ~(a[7]);
  assign f[2] = a[5] & ~(a[7] | a[6]);
  assign f[3] = a[4] & ~(a[7] | a[6] | a[5]);
  assign f[4] = a[3] & ~(a[7] | a[6] | a[5] | a[4]);
  assign f[5] = a[2] & ~(a[7] | a[6] | a[5] | a[4] | a[3]);
  assign f[6] = a[1] & ~(a[7] | a[6] | a[5] | a[4] | a[3] | a[2]);
  assign f[7] = a[0] & ~(a[7] | a[6] | a[5] | a[4] | a[3] | a[2] | a[1]);
  logic v; assign v = |a;
  logic [3:0] enc;
  // the one-hot vector encoded to the count
  assign enc[0] = f[1] | f[3] | f[5] | f[7];
  assign enc[1] = f[2] | f[3] | f[6] | f[7];
  assign enc[2] = f[4] | f[5] | f[6] | f[7];
  assign enc[3] = 1'b0;
  assign n = v ? enc : 4'd8;
endmodule



// popcount_counter_tree (linear_chain, lut_rom, adders carry_increment): the count of the ones of a 16-bit word
module fam_count_popcount_linear_chain_lut_rom_carry_increment_pc143e_w16 (input logic [15:0] a, output logic [4:0] n);
  logic [2:0] g0_rom1;
  always_comb begin case ({a[5], a[4], a[3], a[2], a[1], a[0]})
    6'd0: g0_rom1 = 3'd0;
    6'd1: g0_rom1 = 3'd1;
    6'd2: g0_rom1 = 3'd1;
    6'd3: g0_rom1 = 3'd2;
    6'd4: g0_rom1 = 3'd1;
    6'd5: g0_rom1 = 3'd2;
    6'd6: g0_rom1 = 3'd2;
    6'd7: g0_rom1 = 3'd3;
    6'd8: g0_rom1 = 3'd1;
    6'd9: g0_rom1 = 3'd2;
    6'd10: g0_rom1 = 3'd2;
    6'd11: g0_rom1 = 3'd3;
    6'd12: g0_rom1 = 3'd2;
    6'd13: g0_rom1 = 3'd3;
    6'd14: g0_rom1 = 3'd3;
    6'd15: g0_rom1 = 3'd4;
    6'd16: g0_rom1 = 3'd1;
    6'd17: g0_rom1 = 3'd2;
    6'd18: g0_rom1 = 3'd2;
    6'd19: g0_rom1 = 3'd3;
    6'd20: g0_rom1 = 3'd2;
    6'd21: g0_rom1 = 3'd3;
    6'd22: g0_rom1 = 3'd3;
    6'd23: g0_rom1 = 3'd4;
    6'd24: g0_rom1 = 3'd2;
    6'd25: g0_rom1 = 3'd3;
    6'd26: g0_rom1 = 3'd3;
    6'd27: g0_rom1 = 3'd4;
    6'd28: g0_rom1 = 3'd3;
    6'd29: g0_rom1 = 3'd4;
    6'd30: g0_rom1 = 3'd4;
    6'd31: g0_rom1 = 3'd5;
    6'd32: g0_rom1 = 3'd1;
    6'd33: g0_rom1 = 3'd2;
    6'd34: g0_rom1 = 3'd2;
    6'd35: g0_rom1 = 3'd3;
    6'd36: g0_rom1 = 3'd2;
    6'd37: g0_rom1 = 3'd3;
    6'd38: g0_rom1 = 3'd3;
    6'd39: g0_rom1 = 3'd4;
    6'd40: g0_rom1 = 3'd2;
    6'd41: g0_rom1 = 3'd3;
    6'd42: g0_rom1 = 3'd3;
    6'd43: g0_rom1 = 3'd4;
    6'd44: g0_rom1 = 3'd3;
    6'd45: g0_rom1 = 3'd4;
    6'd46: g0_rom1 = 3'd4;
    6'd47: g0_rom1 = 3'd5;
    6'd48: g0_rom1 = 3'd2;
    6'd49: g0_rom1 = 3'd3;
    6'd50: g0_rom1 = 3'd3;
    6'd51: g0_rom1 = 3'd4;
    6'd52: g0_rom1 = 3'd3;
    6'd53: g0_rom1 = 3'd4;
    6'd54: g0_rom1 = 3'd4;
    6'd55: g0_rom1 = 3'd5;
    6'd56: g0_rom1 = 3'd3;
    6'd57: g0_rom1 = 3'd4;
    6'd58: g0_rom1 = 3'd4;
    6'd59: g0_rom1 = 3'd5;
    6'd60: g0_rom1 = 3'd4;
    6'd61: g0_rom1 = 3'd5;
    6'd62: g0_rom1 = 3'd5;
    6'd63: g0_rom1 = 3'd6;
    default: g0_rom1 = 3'd0;
  endcase end
  logic [2:0] gc0; assign gc0 = {g0_rom1[2], g0_rom1[1], g0_rom1[0]};
  logic [2:0] g1_rom2;
  always_comb begin case ({a[11], a[10], a[9], a[8], a[7], a[6]})
    6'd0: g1_rom2 = 3'd0;
    6'd1: g1_rom2 = 3'd1;
    6'd2: g1_rom2 = 3'd1;
    6'd3: g1_rom2 = 3'd2;
    6'd4: g1_rom2 = 3'd1;
    6'd5: g1_rom2 = 3'd2;
    6'd6: g1_rom2 = 3'd2;
    6'd7: g1_rom2 = 3'd3;
    6'd8: g1_rom2 = 3'd1;
    6'd9: g1_rom2 = 3'd2;
    6'd10: g1_rom2 = 3'd2;
    6'd11: g1_rom2 = 3'd3;
    6'd12: g1_rom2 = 3'd2;
    6'd13: g1_rom2 = 3'd3;
    6'd14: g1_rom2 = 3'd3;
    6'd15: g1_rom2 = 3'd4;
    6'd16: g1_rom2 = 3'd1;
    6'd17: g1_rom2 = 3'd2;
    6'd18: g1_rom2 = 3'd2;
    6'd19: g1_rom2 = 3'd3;
    6'd20: g1_rom2 = 3'd2;
    6'd21: g1_rom2 = 3'd3;
    6'd22: g1_rom2 = 3'd3;
    6'd23: g1_rom2 = 3'd4;
    6'd24: g1_rom2 = 3'd2;
    6'd25: g1_rom2 = 3'd3;
    6'd26: g1_rom2 = 3'd3;
    6'd27: g1_rom2 = 3'd4;
    6'd28: g1_rom2 = 3'd3;
    6'd29: g1_rom2 = 3'd4;
    6'd30: g1_rom2 = 3'd4;
    6'd31: g1_rom2 = 3'd5;
    6'd32: g1_rom2 = 3'd1;
    6'd33: g1_rom2 = 3'd2;
    6'd34: g1_rom2 = 3'd2;
    6'd35: g1_rom2 = 3'd3;
    6'd36: g1_rom2 = 3'd2;
    6'd37: g1_rom2 = 3'd3;
    6'd38: g1_rom2 = 3'd3;
    6'd39: g1_rom2 = 3'd4;
    6'd40: g1_rom2 = 3'd2;
    6'd41: g1_rom2 = 3'd3;
    6'd42: g1_rom2 = 3'd3;
    6'd43: g1_rom2 = 3'd4;
    6'd44: g1_rom2 = 3'd3;
    6'd45: g1_rom2 = 3'd4;
    6'd46: g1_rom2 = 3'd4;
    6'd47: g1_rom2 = 3'd5;
    6'd48: g1_rom2 = 3'd2;
    6'd49: g1_rom2 = 3'd3;
    6'd50: g1_rom2 = 3'd3;
    6'd51: g1_rom2 = 3'd4;
    6'd52: g1_rom2 = 3'd3;
    6'd53: g1_rom2 = 3'd4;
    6'd54: g1_rom2 = 3'd4;
    6'd55: g1_rom2 = 3'd5;
    6'd56: g1_rom2 = 3'd3;
    6'd57: g1_rom2 = 3'd4;
    6'd58: g1_rom2 = 3'd4;
    6'd59: g1_rom2 = 3'd5;
    6'd60: g1_rom2 = 3'd4;
    6'd61: g1_rom2 = 3'd5;
    6'd62: g1_rom2 = 3'd5;
    6'd63: g1_rom2 = 3'd6;
    default: g1_rom2 = 3'd0;
  endcase end
  logic [2:0] gc1; assign gc1 = {g1_rom2[2], g1_rom2[1], g1_rom2[0]};
  logic [2:0] g2_rom3;
  always_comb begin case ({a[15], a[14], a[13], a[12]})
    4'd0: g2_rom3 = 3'd0;
    4'd1: g2_rom3 = 3'd1;
    4'd2: g2_rom3 = 3'd1;
    4'd3: g2_rom3 = 3'd2;
    4'd4: g2_rom3 = 3'd1;
    4'd5: g2_rom3 = 3'd2;
    4'd6: g2_rom3 = 3'd2;
    4'd7: g2_rom3 = 3'd3;
    4'd8: g2_rom3 = 3'd1;
    4'd9: g2_rom3 = 3'd2;
    4'd10: g2_rom3 = 3'd2;
    4'd11: g2_rom3 = 3'd3;
    4'd12: g2_rom3 = 3'd2;
    4'd13: g2_rom3 = 3'd3;
    4'd14: g2_rom3 = 3'd3;
    4'd15: g2_rom3 = 3'd4;
    default: g2_rom3 = 3'd0;
  endcase end
  logic [2:0] gc2; assign gc2 = {g2_rom3[2], g2_rom3[1], g2_rom3[0]};
  logic [2:0] s1;
  logic co1;
  // count adder 1 (carry_increment, 3 bits)
  fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w3 u1 (.a(gc0), .b(gc1), .cin(1'b0), .s(s1), .cout(co1));
  logic [3:0] t1; assign t1 = {co1, s1};
  logic [3:0] s2;
  logic co2;
  // count adder 2 (carry_increment, 4 bits)
  fam_adder_carry_increment_pfa5bb866178c96dd2b2c5fe83fc63a630441f33ec2d941ce2151d1722581e5c0_w4 u2 (.a(t1), .b({1'd0, gc2}), .cin(1'b0), .s(s2), .cout(co2));
  logic [4:0] t2; assign t2 = {co2, s2};
  assign n = t2[4:0];
endmodule


// prefix_lzc (sklansky prefix OR, popcount_of_complement): the leading zeros of a 16-bit word
module fam_count_prefix_lzc_sklansky_pcomp_pct_p79e35_w16 (input logic [15:0] a, output logic [4:0] n);
  logic x0; assign x0 = a[15];
  logic x1; assign x1 = a[14];
  logic x2; assign x2 = a[13];
  logic x3; assign x3 = a[12];
  logic x4; assign x4 = a[11];
  logic x5; assign x5 = a[10];
  logic x6; assign x6 = a[9];
  logic x7; assign x7 = a[8];
  logic x8; assign x8 = a[7];
  logic x9; assign x9 = a[6];
  logic x10; assign x10 = a[5];
  logic x11; assign x11 = a[4];
  logic x12; assign x12 = a[3];
  logic x13; assign x13 = a[2];
  logic x14; assign x14 = a[1];
  logic x15; assign x15 = a[0];
  logic p_sk0_1; assign p_sk0_1 = x1 | x0;
  logic p_sk0_3; assign p_sk0_3 = x3 | x2;
  logic p_sk0_5; assign p_sk0_5 = x5 | x4;
  logic p_sk0_7; assign p_sk0_7 = x7 | x6;
  logic p_sk0_9; assign p_sk0_9 = x9 | x8;
  logic p_sk0_11; assign p_sk0_11 = x11 | x10;
  logic p_sk0_13; assign p_sk0_13 = x13 | x12;
  logic p_sk0_15; assign p_sk0_15 = x15 | x14;
  logic p_sk1_2; assign p_sk1_2 = x2 | p_sk0_1;
  logic p_sk1_3; assign p_sk1_3 = p_sk0_3 | p_sk0_1;
  logic p_sk1_6; assign p_sk1_6 = x6 | p_sk0_5;
  logic p_sk1_7; assign p_sk1_7 = p_sk0_7 | p_sk0_5;
  logic p_sk1_10; assign p_sk1_10 = x10 | p_sk0_9;
  logic p_sk1_11; assign p_sk1_11 = p_sk0_11 | p_sk0_9;
  logic p_sk1_14; assign p_sk1_14 = x14 | p_sk0_13;
  logic p_sk1_15; assign p_sk1_15 = p_sk0_15 | p_sk0_13;
  logic p_sk2_4; assign p_sk2_4 = x4 | p_sk1_3;
  logic p_sk2_5; assign p_sk2_5 = p_sk0_5 | p_sk1_3;
  logic p_sk2_6; assign p_sk2_6 = p_sk1_6 | p_sk1_3;
  logic p_sk2_7; assign p_sk2_7 = p_sk1_7 | p_sk1_3;
  logic p_sk2_12; assign p_sk2_12 = x12 | p_sk1_11;
  logic p_sk2_13; assign p_sk2_13 = p_sk0_13 | p_sk1_11;
  logic p_sk2_14; assign p_sk2_14 = p_sk1_14 | p_sk1_11;
  logic p_sk2_15; assign p_sk2_15 = p_sk1_15 | p_sk1_11;
  logic p_sk3_8; assign p_sk3_8 = x8 | p_sk2_7;
  logic p_sk3_9; assign p_sk3_9 = p_sk0_9 | p_sk2_7;
  logic p_sk3_10; assign p_sk3_10 = p_sk1_10 | p_sk2_7;
  logic p_sk3_11; assign p_sk3_11 = p_sk1_11 | p_sk2_7;
  logic p_sk3_12; assign p_sk3_12 = p_sk2_12 | p_sk2_7;
  logic p_sk3_13; assign p_sk3_13 = p_sk2_13 | p_sk2_7;
  logic p_sk3_14; assign p_sk3_14 = p_sk2_14 | p_sk2_7;
  logic p_sk3_15; assign p_sk3_15 = p_sk2_15 | p_sk2_7;
  logic [15:0] zeros; assign zeros = {~x0, ~p_sk0_1, ~p_sk1_2, ~p_sk1_3, ~p_sk2_4, ~p_sk2_5, ~p_sk2_6, ~p_sk2_7, ~p_sk3_8, ~p_sk3_9, ~p_sk3_10, ~p_sk3_11, ~p_sk3_12, ~p_sk3_13, ~p_sk3_14, ~p_sk3_15};
  // the count of the positions above the leading one (popcount_counter_tree)
  fam_count_popcount_linear_chain_lut_rom_carry_increment_pc143e_w16 u1 (.a(zeros), .n(n));
endmodule

// priority_encoder (groups of 12, 1 lookahead level, one_hot_then_encode): the leading zeros of a 16-bit word
module fam_count_priority_encoder_g12_l1_one_hot_then_encode_w16 (input logic [15:0] a, output logic [4:0] n);
  logic any0; assign any0 = a[15] | a[14] | a[13] | a[12] | a[11] | a[10] | a[9] | a[8] | a[7] | a[6] | a[5] | a[4];
  logic any1; assign any1 = a[3] | a[2] | a[1] | a[0];
  logic kg0; assign kg0 = 1'b0;
  logic kg1; assign kg1 = any0;
  logic fg0; assign fg0 = any0 & ~kg0;
  logic fg1; assign fg1 = any1 & ~kg1;
  logic kb0; assign kb0 = 1'b0;
  logic oh0; assign oh0 = a[15] & ~kb0 & fg0;
  logic kc0; assign kc0 = kb0 | a[15];
  logic kb1; assign kb1 = kc0;
  logic oh1; assign oh1 = a[14] & ~kb1 & fg0;
  logic kc1; assign kc1 = kb1 | a[14];
  logic kb2; assign kb2 = kc1;
  logic oh2; assign oh2 = a[13] & ~kb2 & fg0;
  logic kc2; assign kc2 = kb2 | a[13];
  logic kb3; assign kb3 = kc2;
  logic oh3; assign oh3 = a[12] & ~kb3 & fg0;
  logic kc3; assign kc3 = kb3 | a[12];
  logic kb4; assign kb4 = kc3;
  logic oh4; assign oh4 = a[11] & ~kb4 & fg0;
  logic kc4; assign kc4 = kb4 | a[11];
  logic kb5; assign kb5 = kc4;
  logic oh5; assign oh5 = a[10] & ~kb5 & fg0;
  logic kc5; assign kc5 = kb5 | a[10];
  logic kb6; assign kb6 = kc5;
  logic oh6; assign oh6 = a[9] & ~kb6 & fg0;
  logic kc6; assign kc6 = kb6 | a[9];
  logic kb7; assign kb7 = kc6;
  logic oh7; assign oh7 = a[8] & ~kb7 & fg0;
  logic kc7; assign kc7 = kb7 | a[8];
  logic kb8; assign kb8 = kc7;
  logic oh8; assign oh8 = a[7] & ~kb8 & fg0;
  logic kc8; assign kc8 = kb8 | a[7];
  logic kb9; assign kb9 = kc8;
  logic oh9; assign oh9 = a[6] & ~kb9 & fg0;
  logic kc9; assign kc9 = kb9 | a[6];
  logic kb10; assign kb10 = kc9;
  logic oh10; assign oh10 = a[5] & ~kb10 & fg0;
  logic kc10; assign kc10 = kb10 | a[5];
  logic kb11; assign kb11 = kc10;
  logic oh11; assign oh11 = a[4] & ~kb11 & fg0;
  logic kc11; assign kc11 = kb11 | a[4];
  logic kb12; assign kb12 = 1'b0;
  logic oh12; assign oh12 = a[3] & ~kb12 & fg1;
  logic kc12; assign kc12 = kb12 | a[3];
  logic kb13; assign kb13 = kc12;
  logic oh13; assign oh13 = a[2] & ~kb13 & fg1;
  logic kc13; assign kc13 = kb13 | a[2];
  logic kb14; assign kb14 = kc13;
  logic oh14; assign oh14 = a[1] & ~kb14 & fg1;
  logic kc14; assign kc14 = kb14 | a[1];
  logic kb15; assign kb15 = kc14;
  logic oh15; assign oh15 = a[0] & ~kb15 & fg1;
  logic kc15; assign kc15 = kb15 | a[0];
  logic v; assign v = any0 | any1;
  logic [4:0] enc;
  // the one-hot leading-one vector encoded to the count
  assign enc[0] = oh1 | oh3 | oh5 | oh7 | oh9 | oh11 | oh13 | oh15;
  assign enc[1] = oh2 | oh3 | oh6 | oh7 | oh10 | oh11 | oh14 | oh15;
  assign enc[2] = oh4 | oh5 | oh6 | oh7 | oh12 | oh13 | oh14 | oh15;
  assign enc[3] = oh8 | oh9 | oh10 | oh11 | oh12 | oh13 | oh14 | oh15;
  assign enc[4] = 1'b0;
  assign n = v ? enc : 5'd16;
endmodule


// trailing_zero (reverse_then_lzd over prefix_lzc): the word reversed into the leading-zero detector
module fam_count_tzc_reverse_prefix_lzc_pdd7b3_w16 (input logic [15:0] a, output logic [4:0] n);
  logic [15:0] r; assign r = {a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12], a[13], a[14], a[15]};
  // the leading-zero detector (prefix_lzc) on the reversed word
  fam_count_prefix_lzc_sklansky_pcomp_pct_p79e35_w16 u1 (.a(r), .n(n));
endmodule



// ------------------------------------------------------------ prefix_and_incrementer
// s = a + cin: the carry into bit i is cin AND every lower bit, a prefix AND
// (STRUCTURE 0 a ripple AND chain, 1 a prefix AND tree of topology TOPO, 2
// select blocks of B bits whose block carry is the AND of the block)
module fam_incr_prefix_and #(parameter int W = 16, parameter int STRUCTURE = 1, parameter int B = 4, parameter int TOPO = 0)
  (input logic [W-1:0] a, input logic cin, output logic [W-1:0] s, output logic cout);
  // STRUCTURE: 0 ripple_and_chain, 1 prefix_and_tree (TOPO: 0 sklansky, 1 brent_kung, 2 kogge_stone),
  // 2 select_blocks of B bits
  logic [W:0] c;
  assign c[0] = cin;
  genvar i, l;
  generate
    if (STRUCTURE == 0) begin : ripple
      for (i = 0; i < W; i = i + 1) begin : ch
        assign c[i+1] = c[i] & a[i];
      end
    end else if (STRUCTURE == 1) begin : tree
      localparam int L = (W <= 1) ? 1 : $clog2(W);
      if (TOPO == 2) begin : kogge_stone
        // p[l][i]: AND of a[i] down to a[i - 2^l + 1]
        logic [W-1:0] p [0:L];
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : lvl
          for (i = 0; i < W; i = i + 1) begin : pos
            if (i >= (1 << l)) begin : comb
              assign p[l+1][i] = p[l][i] & p[l][i - (1 << l)];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[L][i];
        end
      end else if (TOPO == 1) begin : brent_kung
        // an up-sweep over the odd positions of each level, then a down-sweep filling the rest
        logic [W-1:0] p [0:2*L];
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : up
          for (i = 0; i < W; i = i + 1) begin : pos
            if (((i + 1) % (2 << l)) == 0) begin : comb
              assign p[l+1][i] = p[l][i] & p[l][i - (1 << l)];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (l = 0; l < L; l = l + 1) begin : down
          localparam int D = 1 << (L - 1 - l);
          for (i = 0; i < W; i = i + 1) begin : pos
            if (((i + 1) % (2 * D)) == D && (i + 1) > D) begin : comb
              assign p[L+l+1][i] = p[L+l][i] & p[L+l][i - D];
            end else begin : keep
              assign p[L+l+1][i] = p[L+l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[2*L][i];
        end
      end else begin : sklansky
        logic [W-1:0] p [0:L];           // p[l][i]: AND of a[i] down to a[i - 2^l + 1]
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : lvl
          for (i = 0; i < W; i = i + 1) begin : pos
            if ((i / (1 << l)) % 2 == 1) begin : comb   // the upper half of every block takes the lower half's end
              assign p[l+1][i] = p[l][i] & p[l][(i / (1 << l)) * (1 << l) - 1];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[L][i];
        end
      end
    end else begin : blocks
      localparam int NB = (W + B - 1) / B;
      logic [NB:0] bc;                  // the carry into each block
      assign bc[0] = cin;
      for (i = 0; i < NB; i = i + 1) begin : blk
        localparam int LO = i * B;
        localparam int HI = (LO + B - 1 < W - 1) ? LO + B - 1 : W - 1;
        logic all1;
        assign all1 = &a[HI:LO];
        assign bc[i+1] = bc[i] & all1;
        genvar j;
        for (j = LO; j <= HI; j = j + 1) begin : bit_
          if (j == LO) begin : first
            assign c[j+1] = bc[i] & a[j];
          end else begin : rest
            assign c[j+1] = c[j] & a[j];
          end
        end
      end
    end
  endgenerate
  assign s = a ^ c[W-1:0];
  assign cout = c[W];
endmodule


// The logic family library: the bitwise gate row of lane_replicated_gates and wide_gate_row.
//   fam_logic_gate_row #(W, NOT_VIA_XOR) (input [W-1:0] a, b, input [1:0] op, output [W-1:0] y)
//   op: 0 and, 1 or, 2 xor, 3 not (of a)
// NOT_VIA_XOR = 1 forms the not as a xor with ones, so the row is three gate types and a
// two-way operand select instead of four gate types under a four-way result mux.
module fam_logic_gate_row #(parameter int W = 16, parameter int NOT_VIA_XOR = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic [1:0] op, output logic [W-1:0] y);
  generate
    if (NOT_VIA_XOR) begin : via_xor
      logic [W-1:0] bx;
      assign bx = (op == 2'd3) ? {W{1'b1}} : b;
      assign y = (op == 2'd0) ? (a & b) : (op == 2'd1) ? (a | b) : (a ^ bx);
    end else begin : plain
      assign y = (op == 2'd0) ? (a & b) : (op == 2'd1) ? (a | b) : (op == 2'd2) ? (a ^ b) : ~a;
    end
  endgenerate
endmodule


module fam_mul_booth16_dadda_3_2_w16_u_p20e537ff (input logic [15:0] a, input logic [15:0] b, output logic [31:0] p);
  // booth_recoded_parallel: {'pp_bits': 120, 'full_adders': 57, 'half_adders': 3, 'cells': 0, 'tree_depth': 3}
  logic neg1, sel3, sel4, sel5, sel6, sel7, sel8, sel9, sel10, hg11, hg12, hg13, hg14, hg15, hg16, hg17, hg18, hg19, hg20, hg21, hg22, hg23, hg24, hg25, hg26, hg27, hg28, hg29, hg30, hg31, hp32, hp33, hp34, hp35, hp36, hp37, hp38, hp39, hp40, hp41, hp42, hp43, hp44, hp45, hp46, hp47, hp48, hp49, hp50, hp51, hp52, hc53, hc54, hc55, hc56, hc57, hc58, hc59, hc60, hc61, hc62, hc63, hc64, hc65, hc66, hc67, hc68, hc69, hc70, hc71, hc72, hc73, hs74, hs75, hs76, hs77, hs78, hs79, hs80, hs81, hs82, hs83, hs84, hs85, hs86, hs87, hs88, hs89, hs90, hs91, hs92, hs93, hs94, hg95, hg96, hg97, hg98, hg99, hg100, hg101, hg102, hg103, hg104, hg105, hg106, hg107, hg108, hg109, hg110, hg111, hg112, hg113, hg114, hg115, hp116, hp117, hp118, hp119, hp120, hp121, hp122, hp123, hp124, hp125, hp126, hp127, hp128, hp129, hp130, hp131, hp132, hp133, hp134, hp135, hp136, hc137, hc138, hc139, hc140, hc141, hc142, hc143, hc144, hc145, hc146, hc147, hc148, hc149, hc150, hc151, hc152, hc153, hc154, hc155, hc156, hc157, hs158, hs159, hs160, hs161, hs162, hs163, hs164, hs165, hs166, hs167, hs168, hs169, hs170, hs171, hs172, hs173, hs174, hs175, hs176, hs177, hs178, hg179, hg180, hg181, hg182, hg183, hg184, hg185, hg186, hg187, hg188, hg189, hg190, hg191, hg192, hg193, hg194, hg195, hg196, hg197, hg198, hg199, hp200, hp201, hp202, hp203, hp204, hp205, hp206, hp207, hp208, hp209, hp210, hp211, hp212, hp213, hp214, hp215, hp216, hp217, hp218, hp219, hp220, hc221, hc222, hc223, hc224, hc225, hc226, hc227, hc228, hc229, hc230, hc231, hc232, hc233, hc234, hc235, hc236, hc237, hc238, hc239, hc240, hc241, hs242, hs243, hs244, hs245, hs246, hs247, hs248, hs249, hs250, hs251, hs252, hs253, hs254, hs255, hs256, hs257, hs258, hs259, hs260, hs261, hs262, pp263, pp264, pp265, pp266, pp267, pp268, pp269, pp270, pp271, pp272, pp273, pp274, pp275, pp276, pp277, pp278, pp279, pp280, pp281, pp282, pp283, pp284, pp285, pp286, pp287, pp288, pp289, pp290, pp291, pp292, pp293, pp294, pp295, pp296, pp297, pp298, pp299, pp300, pp301, pp302, pp303, pp304, pp305, pp306, pp307, pp308, pp309, pp310, pp311, pp312, pp313, pp314, pp315, pp316, pp317, pp318, pp319, pp320, pp321, pp322, pp323, pp324, pp325, neg327, sel329, sel330, sel331, sel332, sel333, sel334, sel335, sel336, pp337, pp338, pp339, pp340, pp341, pp342, pp343, pp344, pp345, pp346, pp347, pp348, pp349, pp350, pp351, pp352, pp353, pp354, pp355, pp356, pp357, pp358, pp359, pp360, pp361, pp362, pp363, pp364, pp365, pp366, pp367, pp368, pp369, pp370, pp371, pp372, pp373, pp374, pp375, pp376, pp377, pp378, pp379, pp380, pp381, pp382, pp383, pp384, pp385, pp386, pp387, pp388, pp389, pp390, pp391, pp392, pp393, pp394, pp395, pp396, pp397, pp398, pp399, neg401, sel403, sel404, sel405, sel406, sel407, sel408, sel409, sel410, pp411, pp412, pp413, pp414, pp415, pp416, pp417, pp418, pp419, pp420, pp421, pp422, pp423, pp424, pp425, pp426, pp427, pp428, pp429, pp430, pp431, pp432, pp433, pp434, pp435, pp436, pp437, pp438, pp439, pp440, pp441, pp442, pp443, pp444, pp445, pp446, pp447, pp448, pp449, pp450, pp451, pp452, pp453, pp454, pp455, pp456, pp457, pp458, pp459, pp460, pp461, pp462, pp463, pp464, pp465, pp466, pp467, pp468, pp469, pp470, pp471, pp472, pp473, neg475, sel477, sel478, sel479, sel480, sel481, sel482, sel483, sel484, pp485, pp486, pp487, pp488, pp489, pp490, pp491, pp492, pp493, pp494, pp495, pp496, pp497, pp498, pp499, pp500, pp501, pp502, pp503, pp504, pp505, pp506, pp507, pp508, pp509, pp510, pp511, pp512, pp513, pp514, pp515, pp516, pp517, pp518, pp519, pp520, pp521, pp522, pp523, pp524, pp525, pp526, pp527, pp528, pp529, pp530, pp531, pp532, pp533, pp534, pp535, pp536, pp537, pp538, pp539, pp540, pp541, pp542, pp543, pp544, pp545, pp546, pp547, neg549, sel551, sel552, sel553, sel554, sel555, sel556, sel557, sel558, pp559, pp560, pp561, pp562, pp563, pp564, pp565, pp566, pp567, pp568, pp569, pp570, pp571, pp572, pp573, pp574, pp575, pp576, pp577, pp578, pp579, pp580, pp581, pp582, pp583, pp584, pp585, pp586, pp587, pp588, pp589, pp590, pp591, pp592, pp593, pp594, pp595, pp596, pp597, pp598, pp599, pp600, pp601, pp602, pp603, pp604, pp605, pp606, pp607, pp608, pp609, pp610, pp611, pp612, pp613, pp614, pp615, pp616, pp617, pp618, pp619, pp620, pp621, t622, t623, t624, t625, t626, t627, t628, t629, t630, t631, t632, t633, t634, t635, t636, t637, t638, t639, t640, t641, t642, t643, t644, t645, t646, t647, t648, t649, t650, t651, t652, t653, t654, t655, t656, t657, t658, t659, t660, t661, t662, t663, t664, t665, t666, t667, t668, t669, t670, t671, t672, t673, t674, t675, t676, t677, t678, t679, t680, t681, t682, t683, t684, t685, t686, t687, t688, t689, t690, t691, t692, t693, t694, t695, t696, t697, t698, t699, t700, t701, t702, t703, t704, t705, t706, t707, t708, t709, t710, t711, t712, t713, t714, t715, t716, t717, t718, t719, t720, t721, t722, t723, t724, t725, t726, t727, t728, t729, t730, t731, t732, t733, t734, t735, t736, t737, t738, t739, t740, t741;
  logic [20:0] a_ext;
  logic [3:0] lo0;
  logic [3:0] mg2;
  logic [20:0] m2;
  logic [20:0] m3;
  logic [20:0] m4;
  logic [20:0] m5;
  logic [20:0] m6;
  logic [20:0] m8;
  logic [20:0] m7;
  logic [20:0] nm1_i;
  logic [20:0] nm2_i;
  logic [20:0] nm3_i;
  logic [20:0] nm4_i;
  logic [20:0] nm5_i;
  logic [20:0] nm6_i;
  logic [20:0] nm7_i;
  logic [20:0] nm8_i;
  logic [3:0] lo326;
  logic [3:0] mg328;
  logic [3:0] lo400;
  logic [3:0] mg402;
  logic [3:0] lo474;
  logic [3:0] mg476;
  logic [3:0] lo548;
  logic [3:0] mg550;
  logic [20:0] nm1; logic nm1_co;
  // -1a = ~(1a) + 1 through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(21), .STRUCTURE(0), .B(4), .TOPO(0)) u_i1 (.a(nm1_i), .cin(1'b1), .s(nm1), .cout(nm1_co));
  logic [20:0] nm2; logic nm2_co;
  // -2a = ~(2a) + 1 through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(21), .STRUCTURE(0), .B(4), .TOPO(0)) u_i2 (.a(nm2_i), .cin(1'b1), .s(nm2), .cout(nm2_co));
  logic [20:0] nm3; logic nm3_co;
  // -3a = ~(3a) + 1 through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(21), .STRUCTURE(0), .B(4), .TOPO(0)) u_i3 (.a(nm3_i), .cin(1'b1), .s(nm3), .cout(nm3_co));
  logic [20:0] nm4; logic nm4_co;
  // -4a = ~(4a) + 1 through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(21), .STRUCTURE(0), .B(4), .TOPO(0)) u_i4 (.a(nm4_i), .cin(1'b1), .s(nm4), .cout(nm4_co));
  logic [20:0] nm5; logic nm5_co;
  // -5a = ~(5a) + 1 through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(21), .STRUCTURE(0), .B(4), .TOPO(0)) u_i5 (.a(nm5_i), .cin(1'b1), .s(nm5), .cout(nm5_co));
  logic [20:0] nm6; logic nm6_co;
  // -6a = ~(6a) + 1 through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(21), .STRUCTURE(0), .B(4), .TOPO(0)) u_i6 (.a(nm6_i), .cin(1'b1), .s(nm6), .cout(nm6_co));
  logic [20:0] nm7; logic nm7_co;
  // -7a = ~(7a) + 1 through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(21), .STRUCTURE(0), .B(4), .TOPO(0)) u_i7 (.a(nm7_i), .cin(1'b1), .s(nm7), .cout(nm7_co));
  logic [20:0] nm8; logic nm8_co;
  // -8a = ~(8a) + 1 through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(21), .STRUCTURE(0), .B(4), .TOPO(0)) u_i8 (.a(nm8_i), .cin(1'b1), .s(nm8), .cout(nm8_co));
  assign a_ext = {{5{1'b0}}, a};
  assign lo0 = {1'b0, {b[2], b[1], b[0]}} + {{3{1'b0}}, 1'b0};
  assign neg1 = b[3] & ~(1'b0 & b[0] & b[1] & b[2]);
  assign mg2 = b[3] ? (4'd8 - lo0) : lo0;
  assign sel3 = (mg2 == 4'd1);
  assign sel4 = (mg2 == 4'd2);
  assign sel5 = (mg2 == 4'd3);
  assign sel6 = (mg2 == 4'd4);
  assign sel7 = (mg2 == 4'd5);
  assign sel8 = (mg2 == 4'd6);
  assign sel9 = (mg2 == 4'd7);
  assign sel10 = (mg2 == 4'd8);
  assign m2 = {a_ext[19:0], 1'd0};
  assign hg11 = m2[0] & a_ext[0];
  assign hg12 = m2[1] & a_ext[1];
  assign hg13 = m2[2] & a_ext[2];
  assign hg14 = m2[3] & a_ext[3];
  assign hg15 = m2[4] & a_ext[4];
  assign hg16 = m2[5] & a_ext[5];
  assign hg17 = m2[6] & a_ext[6];
  assign hg18 = m2[7] & a_ext[7];
  assign hg19 = m2[8] & a_ext[8];
  assign hg20 = m2[9] & a_ext[9];
  assign hg21 = m2[10] & a_ext[10];
  assign hg22 = m2[11] & a_ext[11];
  assign hg23 = m2[12] & a_ext[12];
  assign hg24 = m2[13] & a_ext[13];
  assign hg25 = m2[14] & a_ext[14];
  assign hg26 = m2[15] & a_ext[15];
  assign hg27 = m2[16] & a_ext[16];
  assign hg28 = m2[17] & a_ext[17];
  assign hg29 = m2[18] & a_ext[18];
  assign hg30 = m2[19] & a_ext[19];
  assign hg31 = m2[20] & a_ext[20];
  assign hp32 = m2[0] ^ a_ext[0];
  assign hp33 = m2[1] ^ a_ext[1];
  assign hp34 = m2[2] ^ a_ext[2];
  assign hp35 = m2[3] ^ a_ext[3];
  assign hp36 = m2[4] ^ a_ext[4];
  assign hp37 = m2[5] ^ a_ext[5];
  assign hp38 = m2[6] ^ a_ext[6];
  assign hp39 = m2[7] ^ a_ext[7];
  assign hp40 = m2[8] ^ a_ext[8];
  assign hp41 = m2[9] ^ a_ext[9];
  assign hp42 = m2[10] ^ a_ext[10];
  assign hp43 = m2[11] ^ a_ext[11];
  assign hp44 = m2[12] ^ a_ext[12];
  assign hp45 = m2[13] ^ a_ext[13];
  assign hp46 = m2[14] ^ a_ext[14];
  assign hp47 = m2[15] ^ a_ext[15];
  assign hp48 = m2[16] ^ a_ext[16];
  assign hp49 = m2[17] ^ a_ext[17];
  assign hp50 = m2[18] ^ a_ext[18];
  assign hp51 = m2[19] ^ a_ext[19];
  assign hp52 = m2[20] ^ a_ext[20];
  assign hc53 = hg11 | (hp32 & 1'b0);
  assign hc54 = hg12 | (hg11 & hp33) | (hp32 & hp33 & 1'b0);
  assign hc55 = hg13 | (hg12 & hp34) | (hg11 & hp33 & hp34) | (hp32 & hp33 & hp34 & 1'b0);
  assign hc56 = hg14 | (hg13 & hp35) | (hg12 & hp34 & hp35) | (hg11 & hp33 & hp34 & hp35) | (hp32 & hp33 & hp34 & hp35 & 1'b0);
  assign hc57 = hg15 | (hp36 & hc56);
  assign hc58 = hg16 | (hg15 & hp37) | (hp36 & hp37 & hc56);
  assign hc59 = hg17 | (hg16 & hp38) | (hg15 & hp37 & hp38) | (hp36 & hp37 & hp38 & hc56);
  assign hc60 = hg18 | (hg17 & hp39) | (hg16 & hp38 & hp39) | (hg15 & hp37 & hp38 & hp39) | (hp36 & hp37 & hp38 & hp39 & hc56);
  assign hc61 = hg19 | (hp40 & hc60);
  assign hc62 = hg20 | (hg19 & hp41) | (hp40 & hp41 & hc60);
  assign hc63 = hg21 | (hg20 & hp42) | (hg19 & hp41 & hp42) | (hp40 & hp41 & hp42 & hc60);
  assign hc64 = hg22 | (hg21 & hp43) | (hg20 & hp42 & hp43) | (hg19 & hp41 & hp42 & hp43) | (hp40 & hp41 & hp42 & hp43 & hc60);
  assign hc65 = hg23 | (hp44 & hc64);
  assign hc66 = hg24 | (hg23 & hp45) | (hp44 & hp45 & hc64);
  assign hc67 = hg25 | (hg24 & hp46) | (hg23 & hp45 & hp46) | (hp44 & hp45 & hp46 & hc64);
  assign hc68 = hg26 | (hg25 & hp47) | (hg24 & hp46 & hp47) | (hg23 & hp45 & hp46 & hp47) | (hp44 & hp45 & hp46 & hp47 & hc64);
  assign hc69 = hg27 | (hp48 & hc68);
  assign hc70 = hg28 | (hg27 & hp49) | (hp48 & hp49 & hc68);
  assign hc71 = hg29 | (hg28 & hp50) | (hg27 & hp49 & hp50) | (hp48 & hp49 & hp50 & hc68);
  assign hc72 = hg30 | (hg29 & hp51) | (hg28 & hp50 & hp51) | (hg27 & hp49 & hp50 & hp51) | (hp48 & hp49 & hp50 & hp51 & hc68);
  assign hc73 = hg31 | (hp52 & hc72);
  assign hs74 = hp32 ^ 1'b0;
  assign hs75 = hp33 ^ hc53;
  assign hs76 = hp34 ^ hc54;
  assign hs77 = hp35 ^ hc55;
  assign hs78 = hp36 ^ hc56;
  assign hs79 = hp37 ^ hc57;
  assign hs80 = hp38 ^ hc58;
  assign hs81 = hp39 ^ hc59;
  assign hs82 = hp40 ^ hc60;
  assign hs83 = hp41 ^ hc61;
  assign hs84 = hp42 ^ hc62;
  assign hs85 = hp43 ^ hc63;
  assign hs86 = hp44 ^ hc64;
  assign hs87 = hp45 ^ hc65;
  assign hs88 = hp46 ^ hc66;
  assign hs89 = hp47 ^ hc67;
  assign hs90 = hp48 ^ hc68;
  assign hs91 = hp49 ^ hc69;
  assign hs92 = hp50 ^ hc70;
  assign hs93 = hp51 ^ hc71;
  assign hs94 = hp52 ^ hc72;
  assign m3 = {hs94, hs93, hs92, hs91, hs90, hs89, hs88, hs87, hs86, hs85, hs84, hs83, hs82, hs81, hs80, hs79, hs78, hs77, hs76, hs75, hs74};
  assign m4 = {a_ext[18:0], 2'd0};
  assign hg95 = m4[0] & a_ext[0];
  assign hg96 = m4[1] & a_ext[1];
  assign hg97 = m4[2] & a_ext[2];
  assign hg98 = m4[3] & a_ext[3];
  assign hg99 = m4[4] & a_ext[4];
  assign hg100 = m4[5] & a_ext[5];
  assign hg101 = m4[6] & a_ext[6];
  assign hg102 = m4[7] & a_ext[7];
  assign hg103 = m4[8] & a_ext[8];
  assign hg104 = m4[9] & a_ext[9];
  assign hg105 = m4[10] & a_ext[10];
  assign hg106 = m4[11] & a_ext[11];
  assign hg107 = m4[12] & a_ext[12];
  assign hg108 = m4[13] & a_ext[13];
  assign hg109 = m4[14] & a_ext[14];
  assign hg110 = m4[15] & a_ext[15];
  assign hg111 = m4[16] & a_ext[16];
  assign hg112 = m4[17] & a_ext[17];
  assign hg113 = m4[18] & a_ext[18];
  assign hg114 = m4[19] & a_ext[19];
  assign hg115 = m4[20] & a_ext[20];
  assign hp116 = m4[0] ^ a_ext[0];
  assign hp117 = m4[1] ^ a_ext[1];
  assign hp118 = m4[2] ^ a_ext[2];
  assign hp119 = m4[3] ^ a_ext[3];
  assign hp120 = m4[4] ^ a_ext[4];
  assign hp121 = m4[5] ^ a_ext[5];
  assign hp122 = m4[6] ^ a_ext[6];
  assign hp123 = m4[7] ^ a_ext[7];
  assign hp124 = m4[8] ^ a_ext[8];
  assign hp125 = m4[9] ^ a_ext[9];
  assign hp126 = m4[10] ^ a_ext[10];
  assign hp127 = m4[11] ^ a_ext[11];
  assign hp128 = m4[12] ^ a_ext[12];
  assign hp129 = m4[13] ^ a_ext[13];
  assign hp130 = m4[14] ^ a_ext[14];
  assign hp131 = m4[15] ^ a_ext[15];
  assign hp132 = m4[16] ^ a_ext[16];
  assign hp133 = m4[17] ^ a_ext[17];
  assign hp134 = m4[18] ^ a_ext[18];
  assign hp135 = m4[19] ^ a_ext[19];
  assign hp136 = m4[20] ^ a_ext[20];
  assign hc137 = hg95 | (hp116 & 1'b0);
  assign hc138 = hg96 | (hg95 & hp117) | (hp116 & hp117 & 1'b0);
  assign hc139 = hg97 | (hg96 & hp118) | (hg95 & hp117 & hp118) | (hp116 & hp117 & hp118 & 1'b0);
  assign hc140 = hg98 | (hg97 & hp119) | (hg96 & hp118 & hp119) | (hg95 & hp117 & hp118 & hp119) | (hp116 & hp117 & hp118 & hp119 & 1'b0);
  assign hc141 = hg99 | (hp120 & hc140);
  assign hc142 = hg100 | (hg99 & hp121) | (hp120 & hp121 & hc140);
  assign hc143 = hg101 | (hg100 & hp122) | (hg99 & hp121 & hp122) | (hp120 & hp121 & hp122 & hc140);
  assign hc144 = hg102 | (hg101 & hp123) | (hg100 & hp122 & hp123) | (hg99 & hp121 & hp122 & hp123) | (hp120 & hp121 & hp122 & hp123 & hc140);
  assign hc145 = hg103 | (hp124 & hc144);
  assign hc146 = hg104 | (hg103 & hp125) | (hp124 & hp125 & hc144);
  assign hc147 = hg105 | (hg104 & hp126) | (hg103 & hp125 & hp126) | (hp124 & hp125 & hp126 & hc144);
  assign hc148 = hg106 | (hg105 & hp127) | (hg104 & hp126 & hp127) | (hg103 & hp125 & hp126 & hp127) | (hp124 & hp125 & hp126 & hp127 & hc144);
  assign hc149 = hg107 | (hp128 & hc148);
  assign hc150 = hg108 | (hg107 & hp129) | (hp128 & hp129 & hc148);
  assign hc151 = hg109 | (hg108 & hp130) | (hg107 & hp129 & hp130) | (hp128 & hp129 & hp130 & hc148);
  assign hc152 = hg110 | (hg109 & hp131) | (hg108 & hp130 & hp131) | (hg107 & hp129 & hp130 & hp131) | (hp128 & hp129 & hp130 & hp131 & hc148);
  assign hc153 = hg111 | (hp132 & hc152);
  assign hc154 = hg112 | (hg111 & hp133) | (hp132 & hp133 & hc152);
  assign hc155 = hg113 | (hg112 & hp134) | (hg111 & hp133 & hp134) | (hp132 & hp133 & hp134 & hc152);
  assign hc156 = hg114 | (hg113 & hp135) | (hg112 & hp134 & hp135) | (hg111 & hp133 & hp134 & hp135) | (hp132 & hp133 & hp134 & hp135 & hc152);
  assign hc157 = hg115 | (hp136 & hc156);
  assign hs158 = hp116 ^ 1'b0;
  assign hs159 = hp117 ^ hc137;
  assign hs160 = hp118 ^ hc138;
  assign hs161 = hp119 ^ hc139;
  assign hs162 = hp120 ^ hc140;
  assign hs163 = hp121 ^ hc141;
  assign hs164 = hp122 ^ hc142;
  assign hs165 = hp123 ^ hc143;
  assign hs166 = hp124 ^ hc144;
  assign hs167 = hp125 ^ hc145;
  assign hs168 = hp126 ^ hc146;
  assign hs169 = hp127 ^ hc147;
  assign hs170 = hp128 ^ hc148;
  assign hs171 = hp129 ^ hc149;
  assign hs172 = hp130 ^ hc150;
  assign hs173 = hp131 ^ hc151;
  assign hs174 = hp132 ^ hc152;
  assign hs175 = hp133 ^ hc153;
  assign hs176 = hp134 ^ hc154;
  assign hs177 = hp135 ^ hc155;
  assign hs178 = hp136 ^ hc156;
  assign m5 = {hs178, hs177, hs176, hs175, hs174, hs173, hs172, hs171, hs170, hs169, hs168, hs167, hs166, hs165, hs164, hs163, hs162, hs161, hs160, hs159, hs158};
  assign m6 = {m3[19:0], 1'd0};
  assign m8 = {a_ext[17:0], 3'd0};
  assign hg179 = m8[0] & ~a_ext[0];
  assign hg180 = m8[1] & ~a_ext[1];
  assign hg181 = m8[2] & ~a_ext[2];
  assign hg182 = m8[3] & ~a_ext[3];
  assign hg183 = m8[4] & ~a_ext[4];
  assign hg184 = m8[5] & ~a_ext[5];
  assign hg185 = m8[6] & ~a_ext[6];
  assign hg186 = m8[7] & ~a_ext[7];
  assign hg187 = m8[8] & ~a_ext[8];
  assign hg188 = m8[9] & ~a_ext[9];
  assign hg189 = m8[10] & ~a_ext[10];
  assign hg190 = m8[11] & ~a_ext[11];
  assign hg191 = m8[12] & ~a_ext[12];
  assign hg192 = m8[13] & ~a_ext[13];
  assign hg193 = m8[14] & ~a_ext[14];
  assign hg194 = m8[15] & ~a_ext[15];
  assign hg195 = m8[16] & ~a_ext[16];
  assign hg196 = m8[17] & ~a_ext[17];
  assign hg197 = m8[18] & ~a_ext[18];
  assign hg198 = m8[19] & ~a_ext[19];
  assign hg199 = m8[20] & ~a_ext[20];
  assign hp200 = m8[0] ^ ~a_ext[0];
  assign hp201 = m8[1] ^ ~a_ext[1];
  assign hp202 = m8[2] ^ ~a_ext[2];
  assign hp203 = m8[3] ^ ~a_ext[3];
  assign hp204 = m8[4] ^ ~a_ext[4];
  assign hp205 = m8[5] ^ ~a_ext[5];
  assign hp206 = m8[6] ^ ~a_ext[6];
  assign hp207 = m8[7] ^ ~a_ext[7];
  assign hp208 = m8[8] ^ ~a_ext[8];
  assign hp209 = m8[9] ^ ~a_ext[9];
  assign hp210 = m8[10] ^ ~a_ext[10];
  assign hp211 = m8[11] ^ ~a_ext[11];
  assign hp212 = m8[12] ^ ~a_ext[12];
  assign hp213 = m8[13] ^ ~a_ext[13];
  assign hp214 = m8[14] ^ ~a_ext[14];
  assign hp215 = m8[15] ^ ~a_ext[15];
  assign hp216 = m8[16] ^ ~a_ext[16];
  assign hp217 = m8[17] ^ ~a_ext[17];
  assign hp218 = m8[18] ^ ~a_ext[18];
  assign hp219 = m8[19] ^ ~a_ext[19];
  assign hp220 = m8[20] ^ ~a_ext[20];
  assign hc221 = hg179 | (hp200 & 1'b1);
  assign hc222 = hg180 | (hg179 & hp201) | (hp200 & hp201 & 1'b1);
  assign hc223 = hg181 | (hg180 & hp202) | (hg179 & hp201 & hp202) | (hp200 & hp201 & hp202 & 1'b1);
  assign hc224 = hg182 | (hg181 & hp203) | (hg180 & hp202 & hp203) | (hg179 & hp201 & hp202 & hp203) | (hp200 & hp201 & hp202 & hp203 & 1'b1);
  assign hc225 = hg183 | (hp204 & hc224);
  assign hc226 = hg184 | (hg183 & hp205) | (hp204 & hp205 & hc224);
  assign hc227 = hg185 | (hg184 & hp206) | (hg183 & hp205 & hp206) | (hp204 & hp205 & hp206 & hc224);
  assign hc228 = hg186 | (hg185 & hp207) | (hg184 & hp206 & hp207) | (hg183 & hp205 & hp206 & hp207) | (hp204 & hp205 & hp206 & hp207 & hc224);
  assign hc229 = hg187 | (hp208 & hc228);
  assign hc230 = hg188 | (hg187 & hp209) | (hp208 & hp209 & hc228);
  assign hc231 = hg189 | (hg188 & hp210) | (hg187 & hp209 & hp210) | (hp208 & hp209 & hp210 & hc228);
  assign hc232 = hg190 | (hg189 & hp211) | (hg188 & hp210 & hp211) | (hg187 & hp209 & hp210 & hp211) | (hp208 & hp209 & hp210 & hp211 & hc228);
  assign hc233 = hg191 | (hp212 & hc232);
  assign hc234 = hg192 | (hg191 & hp213) | (hp212 & hp213 & hc232);
  assign hc235 = hg193 | (hg192 & hp214) | (hg191 & hp213 & hp214) | (hp212 & hp213 & hp214 & hc232);
  assign hc236 = hg194 | (hg193 & hp215) | (hg192 & hp214 & hp215) | (hg191 & hp213 & hp214 & hp215) | (hp212 & hp213 & hp214 & hp215 & hc232);
  assign hc237 = hg195 | (hp216 & hc236);
  assign hc238 = hg196 | (hg195 & hp217) | (hp216 & hp217 & hc236);
  assign hc239 = hg197 | (hg196 & hp218) | (hg195 & hp217 & hp218) | (hp216 & hp217 & hp218 & hc236);
  assign hc240 = hg198 | (hg197 & hp219) | (hg196 & hp218 & hp219) | (hg195 & hp217 & hp218 & hp219) | (hp216 & hp217 & hp218 & hp219 & hc236);
  assign hc241 = hg199 | (hp220 & hc240);
  assign hs242 = hp200 ^ 1'b1;
  assign hs243 = hp201 ^ hc221;
  assign hs244 = hp202 ^ hc222;
  assign hs245 = hp203 ^ hc223;
  assign hs246 = hp204 ^ hc224;
  assign hs247 = hp205 ^ hc225;
  assign hs248 = hp206 ^ hc226;
  assign hs249 = hp207 ^ hc227;
  assign hs250 = hp208 ^ hc228;
  assign hs251 = hp209 ^ hc229;
  assign hs252 = hp210 ^ hc230;
  assign hs253 = hp211 ^ hc231;
  assign hs254 = hp212 ^ hc232;
  assign hs255 = hp213 ^ hc233;
  assign hs256 = hp214 ^ hc234;
  assign hs257 = hp215 ^ hc235;
  assign hs258 = hp216 ^ hc236;
  assign hs259 = hp217 ^ hc237;
  assign hs260 = hp218 ^ hc238;
  assign hs261 = hp219 ^ hc239;
  assign hs262 = hp220 ^ hc240;
  assign m7 = {hs262, hs261, hs260, hs259, hs258, hs257, hs256, hs255, hs254, hs253, hs252, hs251, hs250, hs249, hs248, hs247, hs246, hs245, hs244, hs243, hs242};
  assign pp263 = (sel3 & a_ext[0]) | (sel4 & m2[0]) | (sel5 & m3[0]) | (sel6 & m4[0]) | (sel7 & m5[0]) | (sel8 & m6[0]) | (sel9 & m7[0]) | (sel10 & m8[0]);
  assign nm1_i = ~a_ext;
  assign nm2_i = ~m2;
  assign nm3_i = ~m3;
  assign nm4_i = ~m4;
  assign nm5_i = ~m5;
  assign nm6_i = ~m6;
  assign nm7_i = ~m7;
  assign nm8_i = ~m8;
  assign pp264 = (sel3 & nm1[0]) | (sel4 & nm2[0]) | (sel5 & nm3[0]) | (sel6 & nm4[0]) | (sel7 & nm5[0]) | (sel8 & nm6[0]) | (sel9 & nm7[0]) | (sel10 & nm8[0]);
  assign pp265 = neg1 ? pp264 : pp263;
  assign pp266 = (sel3 & a_ext[1]) | (sel4 & m2[1]) | (sel5 & m3[1]) | (sel6 & m4[1]) | (sel7 & m5[1]) | (sel8 & m6[1]) | (sel9 & m7[1]) | (sel10 & m8[1]);
  assign pp267 = (sel3 & nm1[1]) | (sel4 & nm2[1]) | (sel5 & nm3[1]) | (sel6 & nm4[1]) | (sel7 & nm5[1]) | (sel8 & nm6[1]) | (sel9 & nm7[1]) | (sel10 & nm8[1]);
  assign pp268 = neg1 ? pp267 : pp266;
  assign pp269 = (sel3 & a_ext[2]) | (sel4 & m2[2]) | (sel5 & m3[2]) | (sel6 & m4[2]) | (sel7 & m5[2]) | (sel8 & m6[2]) | (sel9 & m7[2]) | (sel10 & m8[2]);
  assign pp270 = (sel3 & nm1[2]) | (sel4 & nm2[2]) | (sel5 & nm3[2]) | (sel6 & nm4[2]) | (sel7 & nm5[2]) | (sel8 & nm6[2]) | (sel9 & nm7[2]) | (sel10 & nm8[2]);
  assign pp271 = neg1 ? pp270 : pp269;
  assign pp272 = (sel3 & a_ext[3]) | (sel4 & m2[3]) | (sel5 & m3[3]) | (sel6 & m4[3]) | (sel7 & m5[3]) | (sel8 & m6[3]) | (sel9 & m7[3]) | (sel10 & m8[3]);
  assign pp273 = (sel3 & nm1[3]) | (sel4 & nm2[3]) | (sel5 & nm3[3]) | (sel6 & nm4[3]) | (sel7 & nm5[3]) | (sel8 & nm6[3]) | (sel9 & nm7[3]) | (sel10 & nm8[3]);
  assign pp274 = neg1 ? pp273 : pp272;
  assign pp275 = (sel3 & a_ext[4]) | (sel4 & m2[4]) | (sel5 & m3[4]) | (sel6 & m4[4]) | (sel7 & m5[4]) | (sel8 & m6[4]) | (sel9 & m7[4]) | (sel10 & m8[4]);
  assign pp276 = (sel3 & nm1[4]) | (sel4 & nm2[4]) | (sel5 & nm3[4]) | (sel6 & nm4[4]) | (sel7 & nm5[4]) | (sel8 & nm6[4]) | (sel9 & nm7[4]) | (sel10 & nm8[4]);
  assign pp277 = neg1 ? pp276 : pp275;
  assign pp278 = (sel3 & a_ext[5]) | (sel4 & m2[5]) | (sel5 & m3[5]) | (sel6 & m4[5]) | (sel7 & m5[5]) | (sel8 & m6[5]) | (sel9 & m7[5]) | (sel10 & m8[5]);
  assign pp279 = (sel3 & nm1[5]) | (sel4 & nm2[5]) | (sel5 & nm3[5]) | (sel6 & nm4[5]) | (sel7 & nm5[5]) | (sel8 & nm6[5]) | (sel9 & nm7[5]) | (sel10 & nm8[5]);
  assign pp280 = neg1 ? pp279 : pp278;
  assign pp281 = (sel3 & a_ext[6]) | (sel4 & m2[6]) | (sel5 & m3[6]) | (sel6 & m4[6]) | (sel7 & m5[6]) | (sel8 & m6[6]) | (sel9 & m7[6]) | (sel10 & m8[6]);
  assign pp282 = (sel3 & nm1[6]) | (sel4 & nm2[6]) | (sel5 & nm3[6]) | (sel6 & nm4[6]) | (sel7 & nm5[6]) | (sel8 & nm6[6]) | (sel9 & nm7[6]) | (sel10 & nm8[6]);
  assign pp283 = neg1 ? pp282 : pp281;
  assign pp284 = (sel3 & a_ext[7]) | (sel4 & m2[7]) | (sel5 & m3[7]) | (sel6 & m4[7]) | (sel7 & m5[7]) | (sel8 & m6[7]) | (sel9 & m7[7]) | (sel10 & m8[7]);
  assign pp285 = (sel3 & nm1[7]) | (sel4 & nm2[7]) | (sel5 & nm3[7]) | (sel6 & nm4[7]) | (sel7 & nm5[7]) | (sel8 & nm6[7]) | (sel9 & nm7[7]) | (sel10 & nm8[7]);
  assign pp286 = neg1 ? pp285 : pp284;
  assign pp287 = (sel3 & a_ext[8]) | (sel4 & m2[8]) | (sel5 & m3[8]) | (sel6 & m4[8]) | (sel7 & m5[8]) | (sel8 & m6[8]) | (sel9 & m7[8]) | (sel10 & m8[8]);
  assign pp288 = (sel3 & nm1[8]) | (sel4 & nm2[8]) | (sel5 & nm3[8]) | (sel6 & nm4[8]) | (sel7 & nm5[8]) | (sel8 & nm6[8]) | (sel9 & nm7[8]) | (sel10 & nm8[8]);
  assign pp289 = neg1 ? pp288 : pp287;
  assign pp290 = (sel3 & a_ext[9]) | (sel4 & m2[9]) | (sel5 & m3[9]) | (sel6 & m4[9]) | (sel7 & m5[9]) | (sel8 & m6[9]) | (sel9 & m7[9]) | (sel10 & m8[9]);
  assign pp291 = (sel3 & nm1[9]) | (sel4 & nm2[9]) | (sel5 & nm3[9]) | (sel6 & nm4[9]) | (sel7 & nm5[9]) | (sel8 & nm6[9]) | (sel9 & nm7[9]) | (sel10 & nm8[9]);
  assign pp292 = neg1 ? pp291 : pp290;
  assign pp293 = (sel3 & a_ext[10]) | (sel4 & m2[10]) | (sel5 & m3[10]) | (sel6 & m4[10]) | (sel7 & m5[10]) | (sel8 & m6[10]) | (sel9 & m7[10]) | (sel10 & m8[10]);
  assign pp294 = (sel3 & nm1[10]) | (sel4 & nm2[10]) | (sel5 & nm3[10]) | (sel6 & nm4[10]) | (sel7 & nm5[10]) | (sel8 & nm6[10]) | (sel9 & nm7[10]) | (sel10 & nm8[10]);
  assign pp295 = neg1 ? pp294 : pp293;
  assign pp296 = (sel3 & a_ext[11]) | (sel4 & m2[11]) | (sel5 & m3[11]) | (sel6 & m4[11]) | (sel7 & m5[11]) | (sel8 & m6[11]) | (sel9 & m7[11]) | (sel10 & m8[11]);
  assign pp297 = (sel3 & nm1[11]) | (sel4 & nm2[11]) | (sel5 & nm3[11]) | (sel6 & nm4[11]) | (sel7 & nm5[11]) | (sel8 & nm6[11]) | (sel9 & nm7[11]) | (sel10 & nm8[11]);
  assign pp298 = neg1 ? pp297 : pp296;
  assign pp299 = (sel3 & a_ext[12]) | (sel4 & m2[12]) | (sel5 & m3[12]) | (sel6 & m4[12]) | (sel7 & m5[12]) | (sel8 & m6[12]) | (sel9 & m7[12]) | (sel10 & m8[12]);
  assign pp300 = (sel3 & nm1[12]) | (sel4 & nm2[12]) | (sel5 & nm3[12]) | (sel6 & nm4[12]) | (sel7 & nm5[12]) | (sel8 & nm6[12]) | (sel9 & nm7[12]) | (sel10 & nm8[12]);
  assign pp301 = neg1 ? pp300 : pp299;
  assign pp302 = (sel3 & a_ext[13]) | (sel4 & m2[13]) | (sel5 & m3[13]) | (sel6 & m4[13]) | (sel7 & m5[13]) | (sel8 & m6[13]) | (sel9 & m7[13]) | (sel10 & m8[13]);
  assign pp303 = (sel3 & nm1[13]) | (sel4 & nm2[13]) | (sel5 & nm3[13]) | (sel6 & nm4[13]) | (sel7 & nm5[13]) | (sel8 & nm6[13]) | (sel9 & nm7[13]) | (sel10 & nm8[13]);
  assign pp304 = neg1 ? pp303 : pp302;
  assign pp305 = (sel3 & a_ext[14]) | (sel4 & m2[14]) | (sel5 & m3[14]) | (sel6 & m4[14]) | (sel7 & m5[14]) | (sel8 & m6[14]) | (sel9 & m7[14]) | (sel10 & m8[14]);
  assign pp306 = (sel3 & nm1[14]) | (sel4 & nm2[14]) | (sel5 & nm3[14]) | (sel6 & nm4[14]) | (sel7 & nm5[14]) | (sel8 & nm6[14]) | (sel9 & nm7[14]) | (sel10 & nm8[14]);
  assign pp307 = neg1 ? pp306 : pp305;
  assign pp308 = (sel3 & a_ext[15]) | (sel4 & m2[15]) | (sel5 & m3[15]) | (sel6 & m4[15]) | (sel7 & m5[15]) | (sel8 & m6[15]) | (sel9 & m7[15]) | (sel10 & m8[15]);
  assign pp309 = (sel3 & nm1[15]) | (sel4 & nm2[15]) | (sel5 & nm3[15]) | (sel6 & nm4[15]) | (sel7 & nm5[15]) | (sel8 & nm6[15]) | (sel9 & nm7[15]) | (sel10 & nm8[15]);
  assign pp310 = neg1 ? pp309 : pp308;
  assign pp311 = (sel3 & a_ext[16]) | (sel4 & m2[16]) | (sel5 & m3[16]) | (sel6 & m4[16]) | (sel7 & m5[16]) | (sel8 & m6[16]) | (sel9 & m7[16]) | (sel10 & m8[16]);
  assign pp312 = (sel3 & nm1[16]) | (sel4 & nm2[16]) | (sel5 & nm3[16]) | (sel6 & nm4[16]) | (sel7 & nm5[16]) | (sel8 & nm6[16]) | (sel9 & nm7[16]) | (sel10 & nm8[16]);
  assign pp313 = neg1 ? pp312 : pp311;
  assign pp314 = (sel3 & a_ext[17]) | (sel4 & m2[17]) | (sel5 & m3[17]) | (sel6 & m4[17]) | (sel7 & m5[17]) | (sel8 & m6[17]) | (sel9 & m7[17]) | (sel10 & m8[17]);
  assign pp315 = (sel3 & nm1[17]) | (sel4 & nm2[17]) | (sel5 & nm3[17]) | (sel6 & nm4[17]) | (sel7 & nm5[17]) | (sel8 & nm6[17]) | (sel9 & nm7[17]) | (sel10 & nm8[17]);
  assign pp316 = neg1 ? pp315 : pp314;
  assign pp317 = (sel3 & a_ext[18]) | (sel4 & m2[18]) | (sel5 & m3[18]) | (sel6 & m4[18]) | (sel7 & m5[18]) | (sel8 & m6[18]) | (sel9 & m7[18]) | (sel10 & m8[18]);
  assign pp318 = (sel3 & nm1[18]) | (sel4 & nm2[18]) | (sel5 & nm3[18]) | (sel6 & nm4[18]) | (sel7 & nm5[18]) | (sel8 & nm6[18]) | (sel9 & nm7[18]) | (sel10 & nm8[18]);
  assign pp319 = neg1 ? pp318 : pp317;
  assign pp320 = (sel3 & a_ext[19]) | (sel4 & m2[19]) | (sel5 & m3[19]) | (sel6 & m4[19]) | (sel7 & m5[19]) | (sel8 & m6[19]) | (sel9 & m7[19]) | (sel10 & m8[19]);
  assign pp321 = (sel3 & nm1[19]) | (sel4 & nm2[19]) | (sel5 & nm3[19]) | (sel6 & nm4[19]) | (sel7 & nm5[19]) | (sel8 & nm6[19]) | (sel9 & nm7[19]) | (sel10 & nm8[19]);
  assign pp322 = neg1 ? pp321 : pp320;
  assign pp323 = (sel3 & a_ext[20]) | (sel4 & m2[20]) | (sel5 & m3[20]) | (sel6 & m4[20]) | (sel7 & m5[20]) | (sel8 & m6[20]) | (sel9 & m7[20]) | (sel10 & m8[20]);
  assign pp324 = (sel3 & nm1[20]) | (sel4 & nm2[20]) | (sel5 & nm3[20]) | (sel6 & nm4[20]) | (sel7 & nm5[20]) | (sel8 & nm6[20]) | (sel9 & nm7[20]) | (sel10 & nm8[20]);
  assign pp325 = neg1 ? pp324 : pp323;
  assign lo326 = {1'b0, {b[6], b[5], b[4]}} + {{3{1'b0}}, b[3]};
  assign neg327 = b[7] & ~(b[3] & b[4] & b[5] & b[6]);
  assign mg328 = b[7] ? (4'd8 - lo326) : lo326;
  assign sel329 = (mg328 == 4'd1);
  assign sel330 = (mg328 == 4'd2);
  assign sel331 = (mg328 == 4'd3);
  assign sel332 = (mg328 == 4'd4);
  assign sel333 = (mg328 == 4'd5);
  assign sel334 = (mg328 == 4'd6);
  assign sel335 = (mg328 == 4'd7);
  assign sel336 = (mg328 == 4'd8);
  assign pp337 = (sel329 & a_ext[0]) | (sel330 & m2[0]) | (sel331 & m3[0]) | (sel332 & m4[0]) | (sel333 & m5[0]) | (sel334 & m6[0]) | (sel335 & m7[0]) | (sel336 & m8[0]);
  assign pp338 = (sel329 & nm1[0]) | (sel330 & nm2[0]) | (sel331 & nm3[0]) | (sel332 & nm4[0]) | (sel333 & nm5[0]) | (sel334 & nm6[0]) | (sel335 & nm7[0]) | (sel336 & nm8[0]);
  assign pp339 = neg327 ? pp338 : pp337;
  assign pp340 = (sel329 & a_ext[1]) | (sel330 & m2[1]) | (sel331 & m3[1]) | (sel332 & m4[1]) | (sel333 & m5[1]) | (sel334 & m6[1]) | (sel335 & m7[1]) | (sel336 & m8[1]);
  assign pp341 = (sel329 & nm1[1]) | (sel330 & nm2[1]) | (sel331 & nm3[1]) | (sel332 & nm4[1]) | (sel333 & nm5[1]) | (sel334 & nm6[1]) | (sel335 & nm7[1]) | (sel336 & nm8[1]);
  assign pp342 = neg327 ? pp341 : pp340;
  assign pp343 = (sel329 & a_ext[2]) | (sel330 & m2[2]) | (sel331 & m3[2]) | (sel332 & m4[2]) | (sel333 & m5[2]) | (sel334 & m6[2]) | (sel335 & m7[2]) | (sel336 & m8[2]);
  assign pp344 = (sel329 & nm1[2]) | (sel330 & nm2[2]) | (sel331 & nm3[2]) | (sel332 & nm4[2]) | (sel333 & nm5[2]) | (sel334 & nm6[2]) | (sel335 & nm7[2]) | (sel336 & nm8[2]);
  assign pp345 = neg327 ? pp344 : pp343;
  assign pp346 = (sel329 & a_ext[3]) | (sel330 & m2[3]) | (sel331 & m3[3]) | (sel332 & m4[3]) | (sel333 & m5[3]) | (sel334 & m6[3]) | (sel335 & m7[3]) | (sel336 & m8[3]);
  assign pp347 = (sel329 & nm1[3]) | (sel330 & nm2[3]) | (sel331 & nm3[3]) | (sel332 & nm4[3]) | (sel333 & nm5[3]) | (sel334 & nm6[3]) | (sel335 & nm7[3]) | (sel336 & nm8[3]);
  assign pp348 = neg327 ? pp347 : pp346;
  assign pp349 = (sel329 & a_ext[4]) | (sel330 & m2[4]) | (sel331 & m3[4]) | (sel332 & m4[4]) | (sel333 & m5[4]) | (sel334 & m6[4]) | (sel335 & m7[4]) | (sel336 & m8[4]);
  assign pp350 = (sel329 & nm1[4]) | (sel330 & nm2[4]) | (sel331 & nm3[4]) | (sel332 & nm4[4]) | (sel333 & nm5[4]) | (sel334 & nm6[4]) | (sel335 & nm7[4]) | (sel336 & nm8[4]);
  assign pp351 = neg327 ? pp350 : pp349;
  assign pp352 = (sel329 & a_ext[5]) | (sel330 & m2[5]) | (sel331 & m3[5]) | (sel332 & m4[5]) | (sel333 & m5[5]) | (sel334 & m6[5]) | (sel335 & m7[5]) | (sel336 & m8[5]);
  assign pp353 = (sel329 & nm1[5]) | (sel330 & nm2[5]) | (sel331 & nm3[5]) | (sel332 & nm4[5]) | (sel333 & nm5[5]) | (sel334 & nm6[5]) | (sel335 & nm7[5]) | (sel336 & nm8[5]);
  assign pp354 = neg327 ? pp353 : pp352;
  assign pp355 = (sel329 & a_ext[6]) | (sel330 & m2[6]) | (sel331 & m3[6]) | (sel332 & m4[6]) | (sel333 & m5[6]) | (sel334 & m6[6]) | (sel335 & m7[6]) | (sel336 & m8[6]);
  assign pp356 = (sel329 & nm1[6]) | (sel330 & nm2[6]) | (sel331 & nm3[6]) | (sel332 & nm4[6]) | (sel333 & nm5[6]) | (sel334 & nm6[6]) | (sel335 & nm7[6]) | (sel336 & nm8[6]);
  assign pp357 = neg327 ? pp356 : pp355;
  assign pp358 = (sel329 & a_ext[7]) | (sel330 & m2[7]) | (sel331 & m3[7]) | (sel332 & m4[7]) | (sel333 & m5[7]) | (sel334 & m6[7]) | (sel335 & m7[7]) | (sel336 & m8[7]);
  assign pp359 = (sel329 & nm1[7]) | (sel330 & nm2[7]) | (sel331 & nm3[7]) | (sel332 & nm4[7]) | (sel333 & nm5[7]) | (sel334 & nm6[7]) | (sel335 & nm7[7]) | (sel336 & nm8[7]);
  assign pp360 = neg327 ? pp359 : pp358;
  assign pp361 = (sel329 & a_ext[8]) | (sel330 & m2[8]) | (sel331 & m3[8]) | (sel332 & m4[8]) | (sel333 & m5[8]) | (sel334 & m6[8]) | (sel335 & m7[8]) | (sel336 & m8[8]);
  assign pp362 = (sel329 & nm1[8]) | (sel330 & nm2[8]) | (sel331 & nm3[8]) | (sel332 & nm4[8]) | (sel333 & nm5[8]) | (sel334 & nm6[8]) | (sel335 & nm7[8]) | (sel336 & nm8[8]);
  assign pp363 = neg327 ? pp362 : pp361;
  assign pp364 = (sel329 & a_ext[9]) | (sel330 & m2[9]) | (sel331 & m3[9]) | (sel332 & m4[9]) | (sel333 & m5[9]) | (sel334 & m6[9]) | (sel335 & m7[9]) | (sel336 & m8[9]);
  assign pp365 = (sel329 & nm1[9]) | (sel330 & nm2[9]) | (sel331 & nm3[9]) | (sel332 & nm4[9]) | (sel333 & nm5[9]) | (sel334 & nm6[9]) | (sel335 & nm7[9]) | (sel336 & nm8[9]);
  assign pp366 = neg327 ? pp365 : pp364;
  assign pp367 = (sel329 & a_ext[10]) | (sel330 & m2[10]) | (sel331 & m3[10]) | (sel332 & m4[10]) | (sel333 & m5[10]) | (sel334 & m6[10]) | (sel335 & m7[10]) | (sel336 & m8[10]);
  assign pp368 = (sel329 & nm1[10]) | (sel330 & nm2[10]) | (sel331 & nm3[10]) | (sel332 & nm4[10]) | (sel333 & nm5[10]) | (sel334 & nm6[10]) | (sel335 & nm7[10]) | (sel336 & nm8[10]);
  assign pp369 = neg327 ? pp368 : pp367;
  assign pp370 = (sel329 & a_ext[11]) | (sel330 & m2[11]) | (sel331 & m3[11]) | (sel332 & m4[11]) | (sel333 & m5[11]) | (sel334 & m6[11]) | (sel335 & m7[11]) | (sel336 & m8[11]);
  assign pp371 = (sel329 & nm1[11]) | (sel330 & nm2[11]) | (sel331 & nm3[11]) | (sel332 & nm4[11]) | (sel333 & nm5[11]) | (sel334 & nm6[11]) | (sel335 & nm7[11]) | (sel336 & nm8[11]);
  assign pp372 = neg327 ? pp371 : pp370;
  assign pp373 = (sel329 & a_ext[12]) | (sel330 & m2[12]) | (sel331 & m3[12]) | (sel332 & m4[12]) | (sel333 & m5[12]) | (sel334 & m6[12]) | (sel335 & m7[12]) | (sel336 & m8[12]);
  assign pp374 = (sel329 & nm1[12]) | (sel330 & nm2[12]) | (sel331 & nm3[12]) | (sel332 & nm4[12]) | (sel333 & nm5[12]) | (sel334 & nm6[12]) | (sel335 & nm7[12]) | (sel336 & nm8[12]);
  assign pp375 = neg327 ? pp374 : pp373;
  assign pp376 = (sel329 & a_ext[13]) | (sel330 & m2[13]) | (sel331 & m3[13]) | (sel332 & m4[13]) | (sel333 & m5[13]) | (sel334 & m6[13]) | (sel335 & m7[13]) | (sel336 & m8[13]);
  assign pp377 = (sel329 & nm1[13]) | (sel330 & nm2[13]) | (sel331 & nm3[13]) | (sel332 & nm4[13]) | (sel333 & nm5[13]) | (sel334 & nm6[13]) | (sel335 & nm7[13]) | (sel336 & nm8[13]);
  assign pp378 = neg327 ? pp377 : pp376;
  assign pp379 = (sel329 & a_ext[14]) | (sel330 & m2[14]) | (sel331 & m3[14]) | (sel332 & m4[14]) | (sel333 & m5[14]) | (sel334 & m6[14]) | (sel335 & m7[14]) | (sel336 & m8[14]);
  assign pp380 = (sel329 & nm1[14]) | (sel330 & nm2[14]) | (sel331 & nm3[14]) | (sel332 & nm4[14]) | (sel333 & nm5[14]) | (sel334 & nm6[14]) | (sel335 & nm7[14]) | (sel336 & nm8[14]);
  assign pp381 = neg327 ? pp380 : pp379;
  assign pp382 = (sel329 & a_ext[15]) | (sel330 & m2[15]) | (sel331 & m3[15]) | (sel332 & m4[15]) | (sel333 & m5[15]) | (sel334 & m6[15]) | (sel335 & m7[15]) | (sel336 & m8[15]);
  assign pp383 = (sel329 & nm1[15]) | (sel330 & nm2[15]) | (sel331 & nm3[15]) | (sel332 & nm4[15]) | (sel333 & nm5[15]) | (sel334 & nm6[15]) | (sel335 & nm7[15]) | (sel336 & nm8[15]);
  assign pp384 = neg327 ? pp383 : pp382;
  assign pp385 = (sel329 & a_ext[16]) | (sel330 & m2[16]) | (sel331 & m3[16]) | (sel332 & m4[16]) | (sel333 & m5[16]) | (sel334 & m6[16]) | (sel335 & m7[16]) | (sel336 & m8[16]);
  assign pp386 = (sel329 & nm1[16]) | (sel330 & nm2[16]) | (sel331 & nm3[16]) | (sel332 & nm4[16]) | (sel333 & nm5[16]) | (sel334 & nm6[16]) | (sel335 & nm7[16]) | (sel336 & nm8[16]);
  assign pp387 = neg327 ? pp386 : pp385;
  assign pp388 = (sel329 & a_ext[17]) | (sel330 & m2[17]) | (sel331 & m3[17]) | (sel332 & m4[17]) | (sel333 & m5[17]) | (sel334 & m6[17]) | (sel335 & m7[17]) | (sel336 & m8[17]);
  assign pp389 = (sel329 & nm1[17]) | (sel330 & nm2[17]) | (sel331 & nm3[17]) | (sel332 & nm4[17]) | (sel333 & nm5[17]) | (sel334 & nm6[17]) | (sel335 & nm7[17]) | (sel336 & nm8[17]);
  assign pp390 = neg327 ? pp389 : pp388;
  assign pp391 = (sel329 & a_ext[18]) | (sel330 & m2[18]) | (sel331 & m3[18]) | (sel332 & m4[18]) | (sel333 & m5[18]) | (sel334 & m6[18]) | (sel335 & m7[18]) | (sel336 & m8[18]);
  assign pp392 = (sel329 & nm1[18]) | (sel330 & nm2[18]) | (sel331 & nm3[18]) | (sel332 & nm4[18]) | (sel333 & nm5[18]) | (sel334 & nm6[18]) | (sel335 & nm7[18]) | (sel336 & nm8[18]);
  assign pp393 = neg327 ? pp392 : pp391;
  assign pp394 = (sel329 & a_ext[19]) | (sel330 & m2[19]) | (sel331 & m3[19]) | (sel332 & m4[19]) | (sel333 & m5[19]) | (sel334 & m6[19]) | (sel335 & m7[19]) | (sel336 & m8[19]);
  assign pp395 = (sel329 & nm1[19]) | (sel330 & nm2[19]) | (sel331 & nm3[19]) | (sel332 & nm4[19]) | (sel333 & nm5[19]) | (sel334 & nm6[19]) | (sel335 & nm7[19]) | (sel336 & nm8[19]);
  assign pp396 = neg327 ? pp395 : pp394;
  assign pp397 = (sel329 & a_ext[20]) | (sel330 & m2[20]) | (sel331 & m3[20]) | (sel332 & m4[20]) | (sel333 & m5[20]) | (sel334 & m6[20]) | (sel335 & m7[20]) | (sel336 & m8[20]);
  assign pp398 = (sel329 & nm1[20]) | (sel330 & nm2[20]) | (sel331 & nm3[20]) | (sel332 & nm4[20]) | (sel333 & nm5[20]) | (sel334 & nm6[20]) | (sel335 & nm7[20]) | (sel336 & nm8[20]);
  assign pp399 = neg327 ? pp398 : pp397;
  assign lo400 = {1'b0, {b[10], b[9], b[8]}} + {{3{1'b0}}, b[7]};
  assign neg401 = b[11] & ~(b[7] & b[8] & b[9] & b[10]);
  assign mg402 = b[11] ? (4'd8 - lo400) : lo400;
  assign sel403 = (mg402 == 4'd1);
  assign sel404 = (mg402 == 4'd2);
  assign sel405 = (mg402 == 4'd3);
  assign sel406 = (mg402 == 4'd4);
  assign sel407 = (mg402 == 4'd5);
  assign sel408 = (mg402 == 4'd6);
  assign sel409 = (mg402 == 4'd7);
  assign sel410 = (mg402 == 4'd8);
  assign pp411 = (sel403 & a_ext[0]) | (sel404 & m2[0]) | (sel405 & m3[0]) | (sel406 & m4[0]) | (sel407 & m5[0]) | (sel408 & m6[0]) | (sel409 & m7[0]) | (sel410 & m8[0]);
  assign pp412 = (sel403 & nm1[0]) | (sel404 & nm2[0]) | (sel405 & nm3[0]) | (sel406 & nm4[0]) | (sel407 & nm5[0]) | (sel408 & nm6[0]) | (sel409 & nm7[0]) | (sel410 & nm8[0]);
  assign pp413 = neg401 ? pp412 : pp411;
  assign pp414 = (sel403 & a_ext[1]) | (sel404 & m2[1]) | (sel405 & m3[1]) | (sel406 & m4[1]) | (sel407 & m5[1]) | (sel408 & m6[1]) | (sel409 & m7[1]) | (sel410 & m8[1]);
  assign pp415 = (sel403 & nm1[1]) | (sel404 & nm2[1]) | (sel405 & nm3[1]) | (sel406 & nm4[1]) | (sel407 & nm5[1]) | (sel408 & nm6[1]) | (sel409 & nm7[1]) | (sel410 & nm8[1]);
  assign pp416 = neg401 ? pp415 : pp414;
  assign pp417 = (sel403 & a_ext[2]) | (sel404 & m2[2]) | (sel405 & m3[2]) | (sel406 & m4[2]) | (sel407 & m5[2]) | (sel408 & m6[2]) | (sel409 & m7[2]) | (sel410 & m8[2]);
  assign pp418 = (sel403 & nm1[2]) | (sel404 & nm2[2]) | (sel405 & nm3[2]) | (sel406 & nm4[2]) | (sel407 & nm5[2]) | (sel408 & nm6[2]) | (sel409 & nm7[2]) | (sel410 & nm8[2]);
  assign pp419 = neg401 ? pp418 : pp417;
  assign pp420 = (sel403 & a_ext[3]) | (sel404 & m2[3]) | (sel405 & m3[3]) | (sel406 & m4[3]) | (sel407 & m5[3]) | (sel408 & m6[3]) | (sel409 & m7[3]) | (sel410 & m8[3]);
  assign pp421 = (sel403 & nm1[3]) | (sel404 & nm2[3]) | (sel405 & nm3[3]) | (sel406 & nm4[3]) | (sel407 & nm5[3]) | (sel408 & nm6[3]) | (sel409 & nm7[3]) | (sel410 & nm8[3]);
  assign pp422 = neg401 ? pp421 : pp420;
  assign pp423 = (sel403 & a_ext[4]) | (sel404 & m2[4]) | (sel405 & m3[4]) | (sel406 & m4[4]) | (sel407 & m5[4]) | (sel408 & m6[4]) | (sel409 & m7[4]) | (sel410 & m8[4]);
  assign pp424 = (sel403 & nm1[4]) | (sel404 & nm2[4]) | (sel405 & nm3[4]) | (sel406 & nm4[4]) | (sel407 & nm5[4]) | (sel408 & nm6[4]) | (sel409 & nm7[4]) | (sel410 & nm8[4]);
  assign pp425 = neg401 ? pp424 : pp423;
  assign pp426 = (sel403 & a_ext[5]) | (sel404 & m2[5]) | (sel405 & m3[5]) | (sel406 & m4[5]) | (sel407 & m5[5]) | (sel408 & m6[5]) | (sel409 & m7[5]) | (sel410 & m8[5]);
  assign pp427 = (sel403 & nm1[5]) | (sel404 & nm2[5]) | (sel405 & nm3[5]) | (sel406 & nm4[5]) | (sel407 & nm5[5]) | (sel408 & nm6[5]) | (sel409 & nm7[5]) | (sel410 & nm8[5]);
  assign pp428 = neg401 ? pp427 : pp426;
  assign pp429 = (sel403 & a_ext[6]) | (sel404 & m2[6]) | (sel405 & m3[6]) | (sel406 & m4[6]) | (sel407 & m5[6]) | (sel408 & m6[6]) | (sel409 & m7[6]) | (sel410 & m8[6]);
  assign pp430 = (sel403 & nm1[6]) | (sel404 & nm2[6]) | (sel405 & nm3[6]) | (sel406 & nm4[6]) | (sel407 & nm5[6]) | (sel408 & nm6[6]) | (sel409 & nm7[6]) | (sel410 & nm8[6]);
  assign pp431 = neg401 ? pp430 : pp429;
  assign pp432 = (sel403 & a_ext[7]) | (sel404 & m2[7]) | (sel405 & m3[7]) | (sel406 & m4[7]) | (sel407 & m5[7]) | (sel408 & m6[7]) | (sel409 & m7[7]) | (sel410 & m8[7]);
  assign pp433 = (sel403 & nm1[7]) | (sel404 & nm2[7]) | (sel405 & nm3[7]) | (sel406 & nm4[7]) | (sel407 & nm5[7]) | (sel408 & nm6[7]) | (sel409 & nm7[7]) | (sel410 & nm8[7]);
  assign pp434 = neg401 ? pp433 : pp432;
  assign pp435 = (sel403 & a_ext[8]) | (sel404 & m2[8]) | (sel405 & m3[8]) | (sel406 & m4[8]) | (sel407 & m5[8]) | (sel408 & m6[8]) | (sel409 & m7[8]) | (sel410 & m8[8]);
  assign pp436 = (sel403 & nm1[8]) | (sel404 & nm2[8]) | (sel405 & nm3[8]) | (sel406 & nm4[8]) | (sel407 & nm5[8]) | (sel408 & nm6[8]) | (sel409 & nm7[8]) | (sel410 & nm8[8]);
  assign pp437 = neg401 ? pp436 : pp435;
  assign pp438 = (sel403 & a_ext[9]) | (sel404 & m2[9]) | (sel405 & m3[9]) | (sel406 & m4[9]) | (sel407 & m5[9]) | (sel408 & m6[9]) | (sel409 & m7[9]) | (sel410 & m8[9]);
  assign pp439 = (sel403 & nm1[9]) | (sel404 & nm2[9]) | (sel405 & nm3[9]) | (sel406 & nm4[9]) | (sel407 & nm5[9]) | (sel408 & nm6[9]) | (sel409 & nm7[9]) | (sel410 & nm8[9]);
  assign pp440 = neg401 ? pp439 : pp438;
  assign pp441 = (sel403 & a_ext[10]) | (sel404 & m2[10]) | (sel405 & m3[10]) | (sel406 & m4[10]) | (sel407 & m5[10]) | (sel408 & m6[10]) | (sel409 & m7[10]) | (sel410 & m8[10]);
  assign pp442 = (sel403 & nm1[10]) | (sel404 & nm2[10]) | (sel405 & nm3[10]) | (sel406 & nm4[10]) | (sel407 & nm5[10]) | (sel408 & nm6[10]) | (sel409 & nm7[10]) | (sel410 & nm8[10]);
  assign pp443 = neg401 ? pp442 : pp441;
  assign pp444 = (sel403 & a_ext[11]) | (sel404 & m2[11]) | (sel405 & m3[11]) | (sel406 & m4[11]) | (sel407 & m5[11]) | (sel408 & m6[11]) | (sel409 & m7[11]) | (sel410 & m8[11]);
  assign pp445 = (sel403 & nm1[11]) | (sel404 & nm2[11]) | (sel405 & nm3[11]) | (sel406 & nm4[11]) | (sel407 & nm5[11]) | (sel408 & nm6[11]) | (sel409 & nm7[11]) | (sel410 & nm8[11]);
  assign pp446 = neg401 ? pp445 : pp444;
  assign pp447 = (sel403 & a_ext[12]) | (sel404 & m2[12]) | (sel405 & m3[12]) | (sel406 & m4[12]) | (sel407 & m5[12]) | (sel408 & m6[12]) | (sel409 & m7[12]) | (sel410 & m8[12]);
  assign pp448 = (sel403 & nm1[12]) | (sel404 & nm2[12]) | (sel405 & nm3[12]) | (sel406 & nm4[12]) | (sel407 & nm5[12]) | (sel408 & nm6[12]) | (sel409 & nm7[12]) | (sel410 & nm8[12]);
  assign pp449 = neg401 ? pp448 : pp447;
  assign pp450 = (sel403 & a_ext[13]) | (sel404 & m2[13]) | (sel405 & m3[13]) | (sel406 & m4[13]) | (sel407 & m5[13]) | (sel408 & m6[13]) | (sel409 & m7[13]) | (sel410 & m8[13]);
  assign pp451 = (sel403 & nm1[13]) | (sel404 & nm2[13]) | (sel405 & nm3[13]) | (sel406 & nm4[13]) | (sel407 & nm5[13]) | (sel408 & nm6[13]) | (sel409 & nm7[13]) | (sel410 & nm8[13]);
  assign pp452 = neg401 ? pp451 : pp450;
  assign pp453 = (sel403 & a_ext[14]) | (sel404 & m2[14]) | (sel405 & m3[14]) | (sel406 & m4[14]) | (sel407 & m5[14]) | (sel408 & m6[14]) | (sel409 & m7[14]) | (sel410 & m8[14]);
  assign pp454 = (sel403 & nm1[14]) | (sel404 & nm2[14]) | (sel405 & nm3[14]) | (sel406 & nm4[14]) | (sel407 & nm5[14]) | (sel408 & nm6[14]) | (sel409 & nm7[14]) | (sel410 & nm8[14]);
  assign pp455 = neg401 ? pp454 : pp453;
  assign pp456 = (sel403 & a_ext[15]) | (sel404 & m2[15]) | (sel405 & m3[15]) | (sel406 & m4[15]) | (sel407 & m5[15]) | (sel408 & m6[15]) | (sel409 & m7[15]) | (sel410 & m8[15]);
  assign pp457 = (sel403 & nm1[15]) | (sel404 & nm2[15]) | (sel405 & nm3[15]) | (sel406 & nm4[15]) | (sel407 & nm5[15]) | (sel408 & nm6[15]) | (sel409 & nm7[15]) | (sel410 & nm8[15]);
  assign pp458 = neg401 ? pp457 : pp456;
  assign pp459 = (sel403 & a_ext[16]) | (sel404 & m2[16]) | (sel405 & m3[16]) | (sel406 & m4[16]) | (sel407 & m5[16]) | (sel408 & m6[16]) | (sel409 & m7[16]) | (sel410 & m8[16]);
  assign pp460 = (sel403 & nm1[16]) | (sel404 & nm2[16]) | (sel405 & nm3[16]) | (sel406 & nm4[16]) | (sel407 & nm5[16]) | (sel408 & nm6[16]) | (sel409 & nm7[16]) | (sel410 & nm8[16]);
  assign pp461 = neg401 ? pp460 : pp459;
  assign pp462 = (sel403 & a_ext[17]) | (sel404 & m2[17]) | (sel405 & m3[17]) | (sel406 & m4[17]) | (sel407 & m5[17]) | (sel408 & m6[17]) | (sel409 & m7[17]) | (sel410 & m8[17]);
  assign pp463 = (sel403 & nm1[17]) | (sel404 & nm2[17]) | (sel405 & nm3[17]) | (sel406 & nm4[17]) | (sel407 & nm5[17]) | (sel408 & nm6[17]) | (sel409 & nm7[17]) | (sel410 & nm8[17]);
  assign pp464 = neg401 ? pp463 : pp462;
  assign pp465 = (sel403 & a_ext[18]) | (sel404 & m2[18]) | (sel405 & m3[18]) | (sel406 & m4[18]) | (sel407 & m5[18]) | (sel408 & m6[18]) | (sel409 & m7[18]) | (sel410 & m8[18]);
  assign pp466 = (sel403 & nm1[18]) | (sel404 & nm2[18]) | (sel405 & nm3[18]) | (sel406 & nm4[18]) | (sel407 & nm5[18]) | (sel408 & nm6[18]) | (sel409 & nm7[18]) | (sel410 & nm8[18]);
  assign pp467 = neg401 ? pp466 : pp465;
  assign pp468 = (sel403 & a_ext[19]) | (sel404 & m2[19]) | (sel405 & m3[19]) | (sel406 & m4[19]) | (sel407 & m5[19]) | (sel408 & m6[19]) | (sel409 & m7[19]) | (sel410 & m8[19]);
  assign pp469 = (sel403 & nm1[19]) | (sel404 & nm2[19]) | (sel405 & nm3[19]) | (sel406 & nm4[19]) | (sel407 & nm5[19]) | (sel408 & nm6[19]) | (sel409 & nm7[19]) | (sel410 & nm8[19]);
  assign pp470 = neg401 ? pp469 : pp468;
  assign pp471 = (sel403 & a_ext[20]) | (sel404 & m2[20]) | (sel405 & m3[20]) | (sel406 & m4[20]) | (sel407 & m5[20]) | (sel408 & m6[20]) | (sel409 & m7[20]) | (sel410 & m8[20]);
  assign pp472 = (sel403 & nm1[20]) | (sel404 & nm2[20]) | (sel405 & nm3[20]) | (sel406 & nm4[20]) | (sel407 & nm5[20]) | (sel408 & nm6[20]) | (sel409 & nm7[20]) | (sel410 & nm8[20]);
  assign pp473 = neg401 ? pp472 : pp471;
  assign lo474 = {1'b0, {b[14], b[13], b[12]}} + {{3{1'b0}}, b[11]};
  assign neg475 = b[15] & ~(b[11] & b[12] & b[13] & b[14]);
  assign mg476 = b[15] ? (4'd8 - lo474) : lo474;
  assign sel477 = (mg476 == 4'd1);
  assign sel478 = (mg476 == 4'd2);
  assign sel479 = (mg476 == 4'd3);
  assign sel480 = (mg476 == 4'd4);
  assign sel481 = (mg476 == 4'd5);
  assign sel482 = (mg476 == 4'd6);
  assign sel483 = (mg476 == 4'd7);
  assign sel484 = (mg476 == 4'd8);
  assign pp485 = (sel477 & a_ext[0]) | (sel478 & m2[0]) | (sel479 & m3[0]) | (sel480 & m4[0]) | (sel481 & m5[0]) | (sel482 & m6[0]) | (sel483 & m7[0]) | (sel484 & m8[0]);
  assign pp486 = (sel477 & nm1[0]) | (sel478 & nm2[0]) | (sel479 & nm3[0]) | (sel480 & nm4[0]) | (sel481 & nm5[0]) | (sel482 & nm6[0]) | (sel483 & nm7[0]) | (sel484 & nm8[0]);
  assign pp487 = neg475 ? pp486 : pp485;
  assign pp488 = (sel477 & a_ext[1]) | (sel478 & m2[1]) | (sel479 & m3[1]) | (sel480 & m4[1]) | (sel481 & m5[1]) | (sel482 & m6[1]) | (sel483 & m7[1]) | (sel484 & m8[1]);
  assign pp489 = (sel477 & nm1[1]) | (sel478 & nm2[1]) | (sel479 & nm3[1]) | (sel480 & nm4[1]) | (sel481 & nm5[1]) | (sel482 & nm6[1]) | (sel483 & nm7[1]) | (sel484 & nm8[1]);
  assign pp490 = neg475 ? pp489 : pp488;
  assign pp491 = (sel477 & a_ext[2]) | (sel478 & m2[2]) | (sel479 & m3[2]) | (sel480 & m4[2]) | (sel481 & m5[2]) | (sel482 & m6[2]) | (sel483 & m7[2]) | (sel484 & m8[2]);
  assign pp492 = (sel477 & nm1[2]) | (sel478 & nm2[2]) | (sel479 & nm3[2]) | (sel480 & nm4[2]) | (sel481 & nm5[2]) | (sel482 & nm6[2]) | (sel483 & nm7[2]) | (sel484 & nm8[2]);
  assign pp493 = neg475 ? pp492 : pp491;
  assign pp494 = (sel477 & a_ext[3]) | (sel478 & m2[3]) | (sel479 & m3[3]) | (sel480 & m4[3]) | (sel481 & m5[3]) | (sel482 & m6[3]) | (sel483 & m7[3]) | (sel484 & m8[3]);
  assign pp495 = (sel477 & nm1[3]) | (sel478 & nm2[3]) | (sel479 & nm3[3]) | (sel480 & nm4[3]) | (sel481 & nm5[3]) | (sel482 & nm6[3]) | (sel483 & nm7[3]) | (sel484 & nm8[3]);
  assign pp496 = neg475 ? pp495 : pp494;
  assign pp497 = (sel477 & a_ext[4]) | (sel478 & m2[4]) | (sel479 & m3[4]) | (sel480 & m4[4]) | (sel481 & m5[4]) | (sel482 & m6[4]) | (sel483 & m7[4]) | (sel484 & m8[4]);
  assign pp498 = (sel477 & nm1[4]) | (sel478 & nm2[4]) | (sel479 & nm3[4]) | (sel480 & nm4[4]) | (sel481 & nm5[4]) | (sel482 & nm6[4]) | (sel483 & nm7[4]) | (sel484 & nm8[4]);
  assign pp499 = neg475 ? pp498 : pp497;
  assign pp500 = (sel477 & a_ext[5]) | (sel478 & m2[5]) | (sel479 & m3[5]) | (sel480 & m4[5]) | (sel481 & m5[5]) | (sel482 & m6[5]) | (sel483 & m7[5]) | (sel484 & m8[5]);
  assign pp501 = (sel477 & nm1[5]) | (sel478 & nm2[5]) | (sel479 & nm3[5]) | (sel480 & nm4[5]) | (sel481 & nm5[5]) | (sel482 & nm6[5]) | (sel483 & nm7[5]) | (sel484 & nm8[5]);
  assign pp502 = neg475 ? pp501 : pp500;
  assign pp503 = (sel477 & a_ext[6]) | (sel478 & m2[6]) | (sel479 & m3[6]) | (sel480 & m4[6]) | (sel481 & m5[6]) | (sel482 & m6[6]) | (sel483 & m7[6]) | (sel484 & m8[6]);
  assign pp504 = (sel477 & nm1[6]) | (sel478 & nm2[6]) | (sel479 & nm3[6]) | (sel480 & nm4[6]) | (sel481 & nm5[6]) | (sel482 & nm6[6]) | (sel483 & nm7[6]) | (sel484 & nm8[6]);
  assign pp505 = neg475 ? pp504 : pp503;
  assign pp506 = (sel477 & a_ext[7]) | (sel478 & m2[7]) | (sel479 & m3[7]) | (sel480 & m4[7]) | (sel481 & m5[7]) | (sel482 & m6[7]) | (sel483 & m7[7]) | (sel484 & m8[7]);
  assign pp507 = (sel477 & nm1[7]) | (sel478 & nm2[7]) | (sel479 & nm3[7]) | (sel480 & nm4[7]) | (sel481 & nm5[7]) | (sel482 & nm6[7]) | (sel483 & nm7[7]) | (sel484 & nm8[7]);
  assign pp508 = neg475 ? pp507 : pp506;
  assign pp509 = (sel477 & a_ext[8]) | (sel478 & m2[8]) | (sel479 & m3[8]) | (sel480 & m4[8]) | (sel481 & m5[8]) | (sel482 & m6[8]) | (sel483 & m7[8]) | (sel484 & m8[8]);
  assign pp510 = (sel477 & nm1[8]) | (sel478 & nm2[8]) | (sel479 & nm3[8]) | (sel480 & nm4[8]) | (sel481 & nm5[8]) | (sel482 & nm6[8]) | (sel483 & nm7[8]) | (sel484 & nm8[8]);
  assign pp511 = neg475 ? pp510 : pp509;
  assign pp512 = (sel477 & a_ext[9]) | (sel478 & m2[9]) | (sel479 & m3[9]) | (sel480 & m4[9]) | (sel481 & m5[9]) | (sel482 & m6[9]) | (sel483 & m7[9]) | (sel484 & m8[9]);
  assign pp513 = (sel477 & nm1[9]) | (sel478 & nm2[9]) | (sel479 & nm3[9]) | (sel480 & nm4[9]) | (sel481 & nm5[9]) | (sel482 & nm6[9]) | (sel483 & nm7[9]) | (sel484 & nm8[9]);
  assign pp514 = neg475 ? pp513 : pp512;
  assign pp515 = (sel477 & a_ext[10]) | (sel478 & m2[10]) | (sel479 & m3[10]) | (sel480 & m4[10]) | (sel481 & m5[10]) | (sel482 & m6[10]) | (sel483 & m7[10]) | (sel484 & m8[10]);
  assign pp516 = (sel477 & nm1[10]) | (sel478 & nm2[10]) | (sel479 & nm3[10]) | (sel480 & nm4[10]) | (sel481 & nm5[10]) | (sel482 & nm6[10]) | (sel483 & nm7[10]) | (sel484 & nm8[10]);
  assign pp517 = neg475 ? pp516 : pp515;
  assign pp518 = (sel477 & a_ext[11]) | (sel478 & m2[11]) | (sel479 & m3[11]) | (sel480 & m4[11]) | (sel481 & m5[11]) | (sel482 & m6[11]) | (sel483 & m7[11]) | (sel484 & m8[11]);
  assign pp519 = (sel477 & nm1[11]) | (sel478 & nm2[11]) | (sel479 & nm3[11]) | (sel480 & nm4[11]) | (sel481 & nm5[11]) | (sel482 & nm6[11]) | (sel483 & nm7[11]) | (sel484 & nm8[11]);
  assign pp520 = neg475 ? pp519 : pp518;
  assign pp521 = (sel477 & a_ext[12]) | (sel478 & m2[12]) | (sel479 & m3[12]) | (sel480 & m4[12]) | (sel481 & m5[12]) | (sel482 & m6[12]) | (sel483 & m7[12]) | (sel484 & m8[12]);
  assign pp522 = (sel477 & nm1[12]) | (sel478 & nm2[12]) | (sel479 & nm3[12]) | (sel480 & nm4[12]) | (sel481 & nm5[12]) | (sel482 & nm6[12]) | (sel483 & nm7[12]) | (sel484 & nm8[12]);
  assign pp523 = neg475 ? pp522 : pp521;
  assign pp524 = (sel477 & a_ext[13]) | (sel478 & m2[13]) | (sel479 & m3[13]) | (sel480 & m4[13]) | (sel481 & m5[13]) | (sel482 & m6[13]) | (sel483 & m7[13]) | (sel484 & m8[13]);
  assign pp525 = (sel477 & nm1[13]) | (sel478 & nm2[13]) | (sel479 & nm3[13]) | (sel480 & nm4[13]) | (sel481 & nm5[13]) | (sel482 & nm6[13]) | (sel483 & nm7[13]) | (sel484 & nm8[13]);
  assign pp526 = neg475 ? pp525 : pp524;
  assign pp527 = (sel477 & a_ext[14]) | (sel478 & m2[14]) | (sel479 & m3[14]) | (sel480 & m4[14]) | (sel481 & m5[14]) | (sel482 & m6[14]) | (sel483 & m7[14]) | (sel484 & m8[14]);
  assign pp528 = (sel477 & nm1[14]) | (sel478 & nm2[14]) | (sel479 & nm3[14]) | (sel480 & nm4[14]) | (sel481 & nm5[14]) | (sel482 & nm6[14]) | (sel483 & nm7[14]) | (sel484 & nm8[14]);
  assign pp529 = neg475 ? pp528 : pp527;
  assign pp530 = (sel477 & a_ext[15]) | (sel478 & m2[15]) | (sel479 & m3[15]) | (sel480 & m4[15]) | (sel481 & m5[15]) | (sel482 & m6[15]) | (sel483 & m7[15]) | (sel484 & m8[15]);
  assign pp531 = (sel477 & nm1[15]) | (sel478 & nm2[15]) | (sel479 & nm3[15]) | (sel480 & nm4[15]) | (sel481 & nm5[15]) | (sel482 & nm6[15]) | (sel483 & nm7[15]) | (sel484 & nm8[15]);
  assign pp532 = neg475 ? pp531 : pp530;
  assign pp533 = (sel477 & a_ext[16]) | (sel478 & m2[16]) | (sel479 & m3[16]) | (sel480 & m4[16]) | (sel481 & m5[16]) | (sel482 & m6[16]) | (sel483 & m7[16]) | (sel484 & m8[16]);
  assign pp534 = (sel477 & nm1[16]) | (sel478 & nm2[16]) | (sel479 & nm3[16]) | (sel480 & nm4[16]) | (sel481 & nm5[16]) | (sel482 & nm6[16]) | (sel483 & nm7[16]) | (sel484 & nm8[16]);
  assign pp535 = neg475 ? pp534 : pp533;
  assign pp536 = (sel477 & a_ext[17]) | (sel478 & m2[17]) | (sel479 & m3[17]) | (sel480 & m4[17]) | (sel481 & m5[17]) | (sel482 & m6[17]) | (sel483 & m7[17]) | (sel484 & m8[17]);
  assign pp537 = (sel477 & nm1[17]) | (sel478 & nm2[17]) | (sel479 & nm3[17]) | (sel480 & nm4[17]) | (sel481 & nm5[17]) | (sel482 & nm6[17]) | (sel483 & nm7[17]) | (sel484 & nm8[17]);
  assign pp538 = neg475 ? pp537 : pp536;
  assign pp539 = (sel477 & a_ext[18]) | (sel478 & m2[18]) | (sel479 & m3[18]) | (sel480 & m4[18]) | (sel481 & m5[18]) | (sel482 & m6[18]) | (sel483 & m7[18]) | (sel484 & m8[18]);
  assign pp540 = (sel477 & nm1[18]) | (sel478 & nm2[18]) | (sel479 & nm3[18]) | (sel480 & nm4[18]) | (sel481 & nm5[18]) | (sel482 & nm6[18]) | (sel483 & nm7[18]) | (sel484 & nm8[18]);
  assign pp541 = neg475 ? pp540 : pp539;
  assign pp542 = (sel477 & a_ext[19]) | (sel478 & m2[19]) | (sel479 & m3[19]) | (sel480 & m4[19]) | (sel481 & m5[19]) | (sel482 & m6[19]) | (sel483 & m7[19]) | (sel484 & m8[19]);
  assign pp543 = (sel477 & nm1[19]) | (sel478 & nm2[19]) | (sel479 & nm3[19]) | (sel480 & nm4[19]) | (sel481 & nm5[19]) | (sel482 & nm6[19]) | (sel483 & nm7[19]) | (sel484 & nm8[19]);
  assign pp544 = neg475 ? pp543 : pp542;
  assign pp545 = (sel477 & a_ext[20]) | (sel478 & m2[20]) | (sel479 & m3[20]) | (sel480 & m4[20]) | (sel481 & m5[20]) | (sel482 & m6[20]) | (sel483 & m7[20]) | (sel484 & m8[20]);
  assign pp546 = (sel477 & nm1[20]) | (sel478 & nm2[20]) | (sel479 & nm3[20]) | (sel480 & nm4[20]) | (sel481 & nm5[20]) | (sel482 & nm6[20]) | (sel483 & nm7[20]) | (sel484 & nm8[20]);
  assign pp547 = neg475 ? pp546 : pp545;
  assign lo548 = {1'b0, {1'b0, 1'b0, 1'b0}} + {{3{1'b0}}, b[15]};
  assign neg549 = 1'b0 & ~(b[15] & 1'b0 & 1'b0 & 1'b0);
  assign mg550 = 1'b0 ? (4'd8 - lo548) : lo548;
  assign sel551 = (mg550 == 4'd1);
  assign sel552 = (mg550 == 4'd2);
  assign sel553 = (mg550 == 4'd3);
  assign sel554 = (mg550 == 4'd4);
  assign sel555 = (mg550 == 4'd5);
  assign sel556 = (mg550 == 4'd6);
  assign sel557 = (mg550 == 4'd7);
  assign sel558 = (mg550 == 4'd8);
  assign pp559 = (sel551 & a_ext[0]) | (sel552 & m2[0]) | (sel553 & m3[0]) | (sel554 & m4[0]) | (sel555 & m5[0]) | (sel556 & m6[0]) | (sel557 & m7[0]) | (sel558 & m8[0]);
  assign pp560 = (sel551 & nm1[0]) | (sel552 & nm2[0]) | (sel553 & nm3[0]) | (sel554 & nm4[0]) | (sel555 & nm5[0]) | (sel556 & nm6[0]) | (sel557 & nm7[0]) | (sel558 & nm8[0]);
  assign pp561 = neg549 ? pp560 : pp559;
  assign pp562 = (sel551 & a_ext[1]) | (sel552 & m2[1]) | (sel553 & m3[1]) | (sel554 & m4[1]) | (sel555 & m5[1]) | (sel556 & m6[1]) | (sel557 & m7[1]) | (sel558 & m8[1]);
  assign pp563 = (sel551 & nm1[1]) | (sel552 & nm2[1]) | (sel553 & nm3[1]) | (sel554 & nm4[1]) | (sel555 & nm5[1]) | (sel556 & nm6[1]) | (sel557 & nm7[1]) | (sel558 & nm8[1]);
  assign pp564 = neg549 ? pp563 : pp562;
  assign pp565 = (sel551 & a_ext[2]) | (sel552 & m2[2]) | (sel553 & m3[2]) | (sel554 & m4[2]) | (sel555 & m5[2]) | (sel556 & m6[2]) | (sel557 & m7[2]) | (sel558 & m8[2]);
  assign pp566 = (sel551 & nm1[2]) | (sel552 & nm2[2]) | (sel553 & nm3[2]) | (sel554 & nm4[2]) | (sel555 & nm5[2]) | (sel556 & nm6[2]) | (sel557 & nm7[2]) | (sel558 & nm8[2]);
  assign pp567 = neg549 ? pp566 : pp565;
  assign pp568 = (sel551 & a_ext[3]) | (sel552 & m2[3]) | (sel553 & m3[3]) | (sel554 & m4[3]) | (sel555 & m5[3]) | (sel556 & m6[3]) | (sel557 & m7[3]) | (sel558 & m8[3]);
  assign pp569 = (sel551 & nm1[3]) | (sel552 & nm2[3]) | (sel553 & nm3[3]) | (sel554 & nm4[3]) | (sel555 & nm5[3]) | (sel556 & nm6[3]) | (sel557 & nm7[3]) | (sel558 & nm8[3]);
  assign pp570 = neg549 ? pp569 : pp568;
  assign pp571 = (sel551 & a_ext[4]) | (sel552 & m2[4]) | (sel553 & m3[4]) | (sel554 & m4[4]) | (sel555 & m5[4]) | (sel556 & m6[4]) | (sel557 & m7[4]) | (sel558 & m8[4]);
  assign pp572 = (sel551 & nm1[4]) | (sel552 & nm2[4]) | (sel553 & nm3[4]) | (sel554 & nm4[4]) | (sel555 & nm5[4]) | (sel556 & nm6[4]) | (sel557 & nm7[4]) | (sel558 & nm8[4]);
  assign pp573 = neg549 ? pp572 : pp571;
  assign pp574 = (sel551 & a_ext[5]) | (sel552 & m2[5]) | (sel553 & m3[5]) | (sel554 & m4[5]) | (sel555 & m5[5]) | (sel556 & m6[5]) | (sel557 & m7[5]) | (sel558 & m8[5]);
  assign pp575 = (sel551 & nm1[5]) | (sel552 & nm2[5]) | (sel553 & nm3[5]) | (sel554 & nm4[5]) | (sel555 & nm5[5]) | (sel556 & nm6[5]) | (sel557 & nm7[5]) | (sel558 & nm8[5]);
  assign pp576 = neg549 ? pp575 : pp574;
  assign pp577 = (sel551 & a_ext[6]) | (sel552 & m2[6]) | (sel553 & m3[6]) | (sel554 & m4[6]) | (sel555 & m5[6]) | (sel556 & m6[6]) | (sel557 & m7[6]) | (sel558 & m8[6]);
  assign pp578 = (sel551 & nm1[6]) | (sel552 & nm2[6]) | (sel553 & nm3[6]) | (sel554 & nm4[6]) | (sel555 & nm5[6]) | (sel556 & nm6[6]) | (sel557 & nm7[6]) | (sel558 & nm8[6]);
  assign pp579 = neg549 ? pp578 : pp577;
  assign pp580 = (sel551 & a_ext[7]) | (sel552 & m2[7]) | (sel553 & m3[7]) | (sel554 & m4[7]) | (sel555 & m5[7]) | (sel556 & m6[7]) | (sel557 & m7[7]) | (sel558 & m8[7]);
  assign pp581 = (sel551 & nm1[7]) | (sel552 & nm2[7]) | (sel553 & nm3[7]) | (sel554 & nm4[7]) | (sel555 & nm5[7]) | (sel556 & nm6[7]) | (sel557 & nm7[7]) | (sel558 & nm8[7]);
  assign pp582 = neg549 ? pp581 : pp580;
  assign pp583 = (sel551 & a_ext[8]) | (sel552 & m2[8]) | (sel553 & m3[8]) | (sel554 & m4[8]) | (sel555 & m5[8]) | (sel556 & m6[8]) | (sel557 & m7[8]) | (sel558 & m8[8]);
  assign pp584 = (sel551 & nm1[8]) | (sel552 & nm2[8]) | (sel553 & nm3[8]) | (sel554 & nm4[8]) | (sel555 & nm5[8]) | (sel556 & nm6[8]) | (sel557 & nm7[8]) | (sel558 & nm8[8]);
  assign pp585 = neg549 ? pp584 : pp583;
  assign pp586 = (sel551 & a_ext[9]) | (sel552 & m2[9]) | (sel553 & m3[9]) | (sel554 & m4[9]) | (sel555 & m5[9]) | (sel556 & m6[9]) | (sel557 & m7[9]) | (sel558 & m8[9]);
  assign pp587 = (sel551 & nm1[9]) | (sel552 & nm2[9]) | (sel553 & nm3[9]) | (sel554 & nm4[9]) | (sel555 & nm5[9]) | (sel556 & nm6[9]) | (sel557 & nm7[9]) | (sel558 & nm8[9]);
  assign pp588 = neg549 ? pp587 : pp586;
  assign pp589 = (sel551 & a_ext[10]) | (sel552 & m2[10]) | (sel553 & m3[10]) | (sel554 & m4[10]) | (sel555 & m5[10]) | (sel556 & m6[10]) | (sel557 & m7[10]) | (sel558 & m8[10]);
  assign pp590 = (sel551 & nm1[10]) | (sel552 & nm2[10]) | (sel553 & nm3[10]) | (sel554 & nm4[10]) | (sel555 & nm5[10]) | (sel556 & nm6[10]) | (sel557 & nm7[10]) | (sel558 & nm8[10]);
  assign pp591 = neg549 ? pp590 : pp589;
  assign pp592 = (sel551 & a_ext[11]) | (sel552 & m2[11]) | (sel553 & m3[11]) | (sel554 & m4[11]) | (sel555 & m5[11]) | (sel556 & m6[11]) | (sel557 & m7[11]) | (sel558 & m8[11]);
  assign pp593 = (sel551 & nm1[11]) | (sel552 & nm2[11]) | (sel553 & nm3[11]) | (sel554 & nm4[11]) | (sel555 & nm5[11]) | (sel556 & nm6[11]) | (sel557 & nm7[11]) | (sel558 & nm8[11]);
  assign pp594 = neg549 ? pp593 : pp592;
  assign pp595 = (sel551 & a_ext[12]) | (sel552 & m2[12]) | (sel553 & m3[12]) | (sel554 & m4[12]) | (sel555 & m5[12]) | (sel556 & m6[12]) | (sel557 & m7[12]) | (sel558 & m8[12]);
  assign pp596 = (sel551 & nm1[12]) | (sel552 & nm2[12]) | (sel553 & nm3[12]) | (sel554 & nm4[12]) | (sel555 & nm5[12]) | (sel556 & nm6[12]) | (sel557 & nm7[12]) | (sel558 & nm8[12]);
  assign pp597 = neg549 ? pp596 : pp595;
  assign pp598 = (sel551 & a_ext[13]) | (sel552 & m2[13]) | (sel553 & m3[13]) | (sel554 & m4[13]) | (sel555 & m5[13]) | (sel556 & m6[13]) | (sel557 & m7[13]) | (sel558 & m8[13]);
  assign pp599 = (sel551 & nm1[13]) | (sel552 & nm2[13]) | (sel553 & nm3[13]) | (sel554 & nm4[13]) | (sel555 & nm5[13]) | (sel556 & nm6[13]) | (sel557 & nm7[13]) | (sel558 & nm8[13]);
  assign pp600 = neg549 ? pp599 : pp598;
  assign pp601 = (sel551 & a_ext[14]) | (sel552 & m2[14]) | (sel553 & m3[14]) | (sel554 & m4[14]) | (sel555 & m5[14]) | (sel556 & m6[14]) | (sel557 & m7[14]) | (sel558 & m8[14]);
  assign pp602 = (sel551 & nm1[14]) | (sel552 & nm2[14]) | (sel553 & nm3[14]) | (sel554 & nm4[14]) | (sel555 & nm5[14]) | (sel556 & nm6[14]) | (sel557 & nm7[14]) | (sel558 & nm8[14]);
  assign pp603 = neg549 ? pp602 : pp601;
  assign pp604 = (sel551 & a_ext[15]) | (sel552 & m2[15]) | (sel553 & m3[15]) | (sel554 & m4[15]) | (sel555 & m5[15]) | (sel556 & m6[15]) | (sel557 & m7[15]) | (sel558 & m8[15]);
  assign pp605 = (sel551 & nm1[15]) | (sel552 & nm2[15]) | (sel553 & nm3[15]) | (sel554 & nm4[15]) | (sel555 & nm5[15]) | (sel556 & nm6[15]) | (sel557 & nm7[15]) | (sel558 & nm8[15]);
  assign pp606 = neg549 ? pp605 : pp604;
  assign pp607 = (sel551 & a_ext[16]) | (sel552 & m2[16]) | (sel553 & m3[16]) | (sel554 & m4[16]) | (sel555 & m5[16]) | (sel556 & m6[16]) | (sel557 & m7[16]) | (sel558 & m8[16]);
  assign pp608 = (sel551 & nm1[16]) | (sel552 & nm2[16]) | (sel553 & nm3[16]) | (sel554 & nm4[16]) | (sel555 & nm5[16]) | (sel556 & nm6[16]) | (sel557 & nm7[16]) | (sel558 & nm8[16]);
  assign pp609 = neg549 ? pp608 : pp607;
  assign pp610 = (sel551 & a_ext[17]) | (sel552 & m2[17]) | (sel553 & m3[17]) | (sel554 & m4[17]) | (sel555 & m5[17]) | (sel556 & m6[17]) | (sel557 & m7[17]) | (sel558 & m8[17]);
  assign pp611 = (sel551 & nm1[17]) | (sel552 & nm2[17]) | (sel553 & nm3[17]) | (sel554 & nm4[17]) | (sel555 & nm5[17]) | (sel556 & nm6[17]) | (sel557 & nm7[17]) | (sel558 & nm8[17]);
  assign pp612 = neg549 ? pp611 : pp610;
  assign pp613 = (sel551 & a_ext[18]) | (sel552 & m2[18]) | (sel553 & m3[18]) | (sel554 & m4[18]) | (sel555 & m5[18]) | (sel556 & m6[18]) | (sel557 & m7[18]) | (sel558 & m8[18]);
  assign pp614 = (sel551 & nm1[18]) | (sel552 & nm2[18]) | (sel553 & nm3[18]) | (sel554 & nm4[18]) | (sel555 & nm5[18]) | (sel556 & nm6[18]) | (sel557 & nm7[18]) | (sel558 & nm8[18]);
  assign pp615 = neg549 ? pp614 : pp613;
  assign pp616 = (sel551 & a_ext[19]) | (sel552 & m2[19]) | (sel553 & m3[19]) | (sel554 & m4[19]) | (sel555 & m5[19]) | (sel556 & m6[19]) | (sel557 & m7[19]) | (sel558 & m8[19]);
  assign pp617 = (sel551 & nm1[19]) | (sel552 & nm2[19]) | (sel553 & nm3[19]) | (sel554 & nm4[19]) | (sel555 & nm5[19]) | (sel556 & nm6[19]) | (sel557 & nm7[19]) | (sel558 & nm8[19]);
  assign pp618 = neg549 ? pp617 : pp616;
  assign pp619 = (sel551 & a_ext[20]) | (sel552 & m2[20]) | (sel553 & m3[20]) | (sel554 & m4[20]) | (sel555 & m5[20]) | (sel556 & m6[20]) | (sel557 & m7[20]) | (sel558 & m8[20]);
  assign pp620 = (sel551 & nm1[20]) | (sel552 & nm2[20]) | (sel553 & nm3[20]) | (sel554 & nm4[20]) | (sel555 & nm5[20]) | (sel556 & nm6[20]) | (sel557 & nm7[20]) | (sel558 & nm8[20]);
  assign pp621 = neg549 ? pp620 : pp619;
  assign t622 = pp313 ^ pp375;
  assign t623 = pp313 & pp375;
  assign t624 = pp316 ^ pp378 ^ pp440;
  assign t625 = (pp316 & pp378) | (pp316 & pp440) | (pp378 & pp440);
  assign t626 = pp319 ^ pp381 ^ pp443;
  assign t627 = (pp319 & pp381) | (pp319 & pp443) | (pp381 & pp443);
  assign t628 = pp322 ^ pp384 ^ pp446;
  assign t629 = (pp322 & pp384) | (pp322 & pp446) | (pp384 & pp446);
  assign t630 = pp325 ^ pp387 ^ pp449;
  assign t631 = (pp325 & pp387) | (pp325 & pp449) | (pp387 & pp449);
  assign t632 = pp325 ^ pp390 ^ pp452;
  assign t633 = (pp325 & pp390) | (pp325 & pp452) | (pp390 & pp452);
  assign t634 = pp325 ^ pp393 ^ pp455;
  assign t635 = (pp325 & pp393) | (pp325 & pp455) | (pp393 & pp455);
  assign t636 = pp325 ^ pp396 ^ pp458;
  assign t637 = (pp325 & pp396) | (pp325 & pp458) | (pp396 & pp458);
  assign t638 = pp325 ^ pp399 ^ pp461;
  assign t639 = (pp325 & pp399) | (pp325 & pp461) | (pp399 & pp461);
  assign t640 = pp325 ^ pp399 ^ pp464;
  assign t641 = (pp325 & pp399) | (pp325 & pp464) | (pp399 & pp464);
  assign t642 = pp325 ^ pp399 ^ pp467;
  assign t643 = (pp325 & pp399) | (pp325 & pp467) | (pp399 & pp467);
  assign t644 = pp325 ^ pp399 ^ pp470;
  assign t645 = (pp325 & pp399) | (pp325 & pp470) | (pp399 & pp470);
  assign t646 = pp325 ^ pp399 ^ pp473;
  assign t647 = (pp325 & pp399) | (pp325 & pp473) | (pp399 & pp473);
  assign t648 = pp325 ^ pp399 ^ pp473;
  assign t649 = (pp325 & pp399) | (pp325 & pp473) | (pp399 & pp473);
  assign t650 = pp325 ^ pp399 ^ pp473;
  assign t651 = (pp325 & pp399) | (pp325 & pp473) | (pp399 & pp473);
  assign t652 = pp325 ^ pp399 ^ pp473;
  assign t653 = (pp325 & pp399) | (pp325 & pp473) | (pp399 & pp473);
  assign t654 = pp301 ^ pp363;
  assign t655 = pp301 & pp363;
  assign t656 = pp304 ^ pp366 ^ pp428;
  assign t657 = (pp304 & pp366) | (pp304 & pp428) | (pp366 & pp428);
  assign t658 = pp307 ^ pp369 ^ pp431;
  assign t659 = (pp307 & pp369) | (pp307 & pp431) | (pp369 & pp431);
  assign t660 = pp310 ^ pp372 ^ pp434;
  assign t661 = (pp310 & pp372) | (pp310 & pp434) | (pp372 & pp434);
  assign t662 = pp437 ^ pp499 ^ pp561;
  assign t663 = (pp437 & pp499) | (pp437 & pp561) | (pp499 & pp561);
  assign t664 = pp502 ^ pp564 ^ t623;
  assign t665 = (pp502 & pp564) | (pp502 & t623) | (pp564 & t623);
  assign t666 = pp505 ^ pp567 ^ t625;
  assign t667 = (pp505 & pp567) | (pp505 & t625) | (pp567 & t625);
  assign t668 = pp508 ^ pp570 ^ t627;
  assign t669 = (pp508 & pp570) | (pp508 & t627) | (pp570 & t627);
  assign t670 = pp511 ^ pp573 ^ t629;
  assign t671 = (pp511 & pp573) | (pp511 & t629) | (pp573 & t629);
  assign t672 = pp514 ^ pp576 ^ t631;
  assign t673 = (pp514 & pp576) | (pp514 & t631) | (pp576 & t631);
  assign t674 = pp517 ^ pp579 ^ t633;
  assign t675 = (pp517 & pp579) | (pp517 & t633) | (pp579 & t633);
  assign t676 = pp520 ^ pp582 ^ t635;
  assign t677 = (pp520 & pp582) | (pp520 & t635) | (pp582 & t635);
  assign t678 = pp523 ^ pp585 ^ t637;
  assign t679 = (pp523 & pp585) | (pp523 & t637) | (pp585 & t637);
  assign t680 = pp526 ^ pp588 ^ t639;
  assign t681 = (pp526 & pp588) | (pp526 & t639) | (pp588 & t639);
  assign t682 = pp529 ^ pp591 ^ t641;
  assign t683 = (pp529 & pp591) | (pp529 & t641) | (pp591 & t641);
  assign t684 = pp532 ^ pp594 ^ t643;
  assign t685 = (pp532 & pp594) | (pp532 & t643) | (pp594 & t643);
  assign t686 = pp535 ^ pp597 ^ t645;
  assign t687 = (pp535 & pp597) | (pp535 & t645) | (pp597 & t645);
  assign t688 = pp538 ^ pp600 ^ t647;
  assign t689 = (pp538 & pp600) | (pp538 & t647) | (pp600 & t647);
  assign t690 = pp541 ^ pp603 ^ t649;
  assign t691 = (pp541 & pp603) | (pp541 & t649) | (pp603 & t649);
  assign t692 = pp544 ^ pp606 ^ t651;
  assign t693 = (pp544 & pp606) | (pp544 & t651) | (pp606 & t651);
  assign t694 = pp289 ^ pp351;
  assign t695 = pp289 & pp351;
  assign t696 = pp292 ^ pp354 ^ pp416;
  assign t697 = (pp292 & pp354) | (pp292 & pp416) | (pp354 & pp416);
  assign t698 = pp295 ^ pp357 ^ pp419;
  assign t699 = (pp295 & pp357) | (pp295 & pp419) | (pp357 & pp419);
  assign t700 = pp298 ^ pp360 ^ pp422;
  assign t701 = (pp298 & pp360) | (pp298 & pp422) | (pp360 & pp422);
  assign t702 = pp425 ^ pp487 ^ t654;
  assign t703 = (pp425 & pp487) | (pp425 & t654) | (pp487 & t654);
  assign t704 = pp490 ^ t655 ^ t656;
  assign t705 = (pp490 & t655) | (pp490 & t656) | (t655 & t656);
  assign t706 = pp493 ^ t657 ^ t658;
  assign t707 = (pp493 & t657) | (pp493 & t658) | (t657 & t658);
  assign t708 = pp496 ^ t659 ^ t660;
  assign t709 = (pp496 & t659) | (pp496 & t660) | (t659 & t660);
  assign t710 = t622 ^ t661 ^ t662;
  assign t711 = (t622 & t661) | (t622 & t662) | (t661 & t662);
  assign t712 = t624 ^ t663 ^ t664;
  assign t713 = (t624 & t663) | (t624 & t664) | (t663 & t664);
  assign t714 = t626 ^ t665 ^ t666;
  assign t715 = (t626 & t665) | (t626 & t666) | (t665 & t666);
  assign t716 = t628 ^ t667 ^ t668;
  assign t717 = (t628 & t667) | (t628 & t668) | (t667 & t668);
  assign t718 = t630 ^ t669 ^ t670;
  assign t719 = (t630 & t669) | (t630 & t670) | (t669 & t670);
  assign t720 = t632 ^ t671 ^ t672;
  assign t721 = (t632 & t671) | (t632 & t672) | (t671 & t672);
  assign t722 = t634 ^ t673 ^ t674;
  assign t723 = (t634 & t673) | (t634 & t674) | (t673 & t674);
  assign t724 = t636 ^ t675 ^ t676;
  assign t725 = (t636 & t675) | (t636 & t676) | (t675 & t676);
  assign t726 = t638 ^ t677 ^ t678;
  assign t727 = (t638 & t677) | (t638 & t678) | (t677 & t678);
  assign t728 = t640 ^ t679 ^ t680;
  assign t729 = (t640 & t679) | (t640 & t680) | (t679 & t680);
  assign t730 = t642 ^ t681 ^ t682;
  assign t731 = (t642 & t681) | (t642 & t682) | (t681 & t682);
  assign t732 = t644 ^ t683 ^ t684;
  assign t733 = (t644 & t683) | (t644 & t684) | (t683 & t684);
  assign t734 = t646 ^ t685 ^ t686;
  assign t735 = (t646 & t685) | (t646 & t686) | (t685 & t686);
  assign t736 = t648 ^ t687 ^ t688;
  assign t737 = (t648 & t687) | (t648 & t688) | (t687 & t688);
  assign t738 = t650 ^ t689 ^ t690;
  assign t739 = (t650 & t689) | (t650 & t690) | (t689 & t690);
  assign t740 = t652 ^ t691 ^ t692;
  assign t741 = (t652 & t691) | (t652 & t692) | (t691 & t692);
  logic [31:0] row_s, row_c;
  assign row_s = {t739, t737, t735, t733, t731, t729, t727, t725, t723, t721, t719, t717, t715, t713, t711, t709, t707, t705, t703, t701, t699, t697, t695, pp413, pp286, pp283, pp280, pp277, pp274, pp271, pp268, pp265};
  assign row_c = {t740, t738, t736, t734, t732, t730, t728, t726, t724, t722, t720, t718, t716, t714, t712, t710, t708, t706, t704, t702, t700, t698, t696, t694, pp348, pp345, pp342, pp339, 1'b0, 1'b0, 1'b0, 1'b0};
  // hybrid final adder: regions [0, 8, 16, 24, 32] of kinds ['cla', 'cla', 'cla', 'cla'] on the measured_tree_profile profile (delay_bound_boundary_enumeration)
  logic rg0_co;
  fam_adder_carry_lookahead #(.W(8), .G(4), .INTER(0), .LEVELS(1)) u_rg0 (.a(row_s[7:0]), .b(row_c[7:0]), .cin(1'b0), .s(p[7:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_lookahead #(.W(8), .G(4), .INTER(0), .LEVELS(1)) u_rg1 (.a(row_s[15:8]), .b(row_c[15:8]), .cin(rg0_co), .s(p[15:8]), .cout(rg1_co));
  logic rg2_co;
  fam_adder_carry_lookahead #(.W(8), .G(4), .INTER(0), .LEVELS(1)) u_rg2 (.a(row_s[23:16]), .b(row_c[23:16]), .cin(rg1_co), .s(p[23:16]), .cout(rg2_co));
  logic rg3_co;
  fam_adder_carry_lookahead #(.W(8), .G(4), .INTER(0), .LEVELS(1)) u_rg3 (.a(row_s[31:24]), .b(row_c[31:24]), .cin(rg2_co), .s(p[31:24]), .cout(rg3_co));
endmodule



module fam_mul_direct_dadda_3_2_w2_u_p8dfaf87b (input logic [1:0] a, input logic [1:0] b, output logic [3:0] p);
  // direct_pp_parallel: {'pp_bits': 6, 'full_adders': 0, 'half_adders': 0, 'cells': 0, 'tree_depth': 0}
  logic sel0, sel1, sel2, pp3, pp4, pp5, pp6, pp7, sel8, sel9, sel10, pp11, pp12, pp13, pp14, pp15;
  logic [4:0] a_ext;
  logic [4:0] m2;
  logic [4:0] m3; logic m3_co;
  // the hard multiple 3a = 2a + a through the adder (compound_flagged_prefix)
  fam_prefix_ladner_fischer_w5_flag u_i1 (.a(m2), .b(a_ext), .cin(1'b0), .s(m3), .cout(m3_co));
  assign a_ext = {{3{1'b0}}, a};
  assign sel0 = b[0] & ~b[1];
  assign sel1 = ~b[0] & b[1];
  assign sel2 = b[0] & b[1];
  assign m2 = {a_ext[3:0], 1'd0};
  assign pp3 = (sel0 & a_ext[0]) | (sel1 & m2[0]) | (sel2 & m3[0]);
  assign pp4 = (sel0 & a_ext[1]) | (sel1 & m2[1]) | (sel2 & m3[1]);
  assign pp5 = (sel0 & a_ext[2]) | (sel1 & m2[2]) | (sel2 & m3[2]);
  assign pp6 = (sel0 & a_ext[3]) | (sel1 & m2[3]) | (sel2 & m3[3]);
  assign pp7 = (sel0 & a_ext[4]) | (sel1 & m2[4]) | (sel2 & m3[4]);
  assign sel8 = 1'b0 & ~1'b0;
  assign sel9 = ~1'b0 & 1'b0;
  assign sel10 = 1'b0 & 1'b0;
  assign pp11 = (sel8 & a_ext[0]) | (sel9 & m2[0]) | (sel10 & m3[0]);
  assign pp12 = (sel8 & a_ext[1]) | (sel9 & m2[1]) | (sel10 & m3[1]);
  assign pp13 = (sel8 & a_ext[2]) | (sel9 & m2[2]) | (sel10 & m3[2]);
  assign pp14 = (sel8 & a_ext[3]) | (sel9 & m2[3]) | (sel10 & m3[3]);
  assign pp15 = (sel8 & a_ext[4]) | (sel9 & m2[4]) | (sel10 & m3[4]);
  logic [3:0] row_s, row_c;
  assign row_s = {pp6, pp5, pp4, pp3};
  assign row_c = {pp12, pp11, 1'b0, 1'b0};
  fam_prefix_han_carlson_w4_ling_sel u_cpa (.a(row_s), .b(row_c), .cin(1'b0), .s(p), .cout());
endmodule











module fam_mul_direct_dadda_3_2_w3_s_p8dfaf87b (input logic [2:0] a, input logic [2:0] b, output logic [5:0] p);
  // direct_pp_parallel: {'pp_bits': 11, 'full_adders': 0, 'half_adders': 2, 'cells': 0, 'tree_depth': 1}
  logic sel0, sel1, sel2, pp3, pp4, pp5, pp6, pp7, sel8, sel9, sel10, pp11, pp12, pp13, pp14, pp15, ns16, t17, t18, t19, t20;
  logic [4:0] a_ext;
  logic [4:0] m2;
  logic [4:0] m3; logic m3_co;
  // the hard multiple 3a = 2a + a through the adder (compound_flagged_prefix)
  fam_prefix_ladner_fischer_w5_flag u_i1 (.a(m2), .b(a_ext), .cin(1'b0), .s(m3), .cout(m3_co));
  assign a_ext = {{2{a[2]}}, a};
  assign sel0 = b[0] & ~b[1];
  assign sel1 = ~b[0] & b[1];
  assign sel2 = b[0] & b[1];
  assign m2 = {a_ext[3:0], 1'd0};
  assign pp3 = (sel0 & a_ext[0]) | (sel1 & m2[0]) | (sel2 & m3[0]);
  assign pp4 = (sel0 & a_ext[1]) | (sel1 & m2[1]) | (sel2 & m3[1]);
  assign pp5 = (sel0 & a_ext[2]) | (sel1 & m2[2]) | (sel2 & m3[2]);
  assign pp6 = (sel0 & a_ext[3]) | (sel1 & m2[3]) | (sel2 & m3[3]);
  assign pp7 = (sel0 & a_ext[4]) | (sel1 & m2[4]) | (sel2 & m3[4]);
  assign sel8 = b[2] & ~b[2];
  assign sel9 = ~b[2] & b[2];
  assign sel10 = b[2] & b[2];
  assign pp11 = (sel8 & a_ext[0]) | (sel9 & m2[0]) | (sel10 & m3[0]);
  assign pp12 = (sel8 & a_ext[1]) | (sel9 & m2[1]) | (sel10 & m3[1]);
  assign pp13 = (sel8 & a_ext[2]) | (sel9 & m2[2]) | (sel10 & m3[2]);
  assign pp14 = (sel8 & a_ext[3]) | (sel9 & m2[3]) | (sel10 & m3[3]);
  assign pp15 = (sel8 & a_ext[4]) | (sel9 & m2[4]) | (sel10 & m3[4]);
  assign ns16 = ~pp7;
  assign t17 = ns16 ^ pp13;
  assign t18 = ns16 & pp13;
  assign t19 = pp14 ^ 1'b1;
  assign t20 = pp14 & 1'b1;
  logic [5:0] row_s, row_c;
  assign row_s = {t18, 1'b1, pp6, pp5, pp4, pp3};
  assign row_c = {t19, t17, pp12, pp11, 1'b0, 1'b0};
  fam_prefix_han_carlson_w6_ling_sel u_cpa (.a(row_s), .b(row_c), .cin(1'b0), .s(p), .cout());
endmodule

// redundant_binary_multiplier: Booth radix-4 rows as signed digits in the plus_minus_pair code (the pair (p, n) of the positive and negative bits), a 4-level tree of carry-free redundant adders, converted by cpa
module fam_mul_redundant_binary_multiplier_w16_s_pcc746478 (input logic [15:0] a, input logic [15:0] b, output logic [31:0] p);
  logic neg1, sel3, sel4, pp5, pp6, pp7, pp8, pp9, pp10, pp11, pp12, pp13, pp14, pp15, pp16, pp17, pp18, pp19, pp20, pp21, pp22, neg24, sel26, sel27, pp28, pp29, pp30, pp31, pp32, pp33, pp34, pp35, pp36, pp37, pp38, pp39, pp40, pp41, pp42, pp43, pp44, pp45, neg47, sel49, sel50, pp51, pp52, pp53, pp54, pp55, pp56, pp57, pp58, pp59, pp60, pp61, pp62, pp63, pp64, pp65, pp66, pp67, pp68, neg70, sel72, sel73, pp74, pp75, pp76, pp77, pp78, pp79, pp80, pp81, pp82, pp83, pp84, pp85, pp86, pp87, pp88, pp89, pp90, pp91, neg93, sel95, sel96, pp97, pp98, pp99, pp100, pp101, pp102, pp103, pp104, pp105, pp106, pp107, pp108, pp109, pp110, pp111, pp112, pp113, pp114, neg116, sel118, sel119, pp120, pp121, pp122, pp123, pp124, pp125, pp126, pp127, pp128, pp129, pp130, pp131, pp132, pp133, pp134, pp135, pp136, pp137, neg139, sel141, sel142, pp143, pp144, pp145, pp146, pp147, pp148, pp149, pp150, pp151, pp152, pp153, pp154, pp155, pp156, pp157, pp158, pp159, pp160, neg162, sel164, sel165, pp166, pp167, pp168, pp169, pp170, pp171, pp172, pp173, pp174, pp175, pp176, pp177, pp178, pp179, pp180, pp181, pp182, pp183, ns184, ns185, ns186, ns187, ns188, ns189, ns190, ns191, rb192, rb193, rb194, rb195, rb196, rb197, rb198, rb199, rb200, rb201, rb202, rb203, rb204, rb205, rb206, rb207, rb208, rb209, rb210, rb211, rb212, rb213, rb214, rb215, rb216, rb217, rb218, rb219, rb220, rb221, rb222, rb223, rb224, rb225, rb226, rb227, rb228, rb229, rb230, rb231, rb232, rb233, rb234, rb235, rb236, rb237, rb238, rb239, rb240, rb241, rb242, rb243, rb244, rb245, rb246, rb247, rb248, rb249, rb250, rb251, rb252, rb253, rb254, rb255, rb256, rb257, rb258, rb259, rb260, rb261, rb262, rb263, rb264, rb265, rb266, rb267, rb268, rb269, rb270, rb271, rb272, rb273, rb274, rb275, rb276, rb277, rb278, rb279, rb280, rb281, rb282, rb283, rb284, rb285, rb286, rb287, rb288, rb289, rb290, rb291, rb292, rb293, rb294, rb295, rb296, rb297, rb298, rb299, rb300, rb301, rb302, rb303, rb304, rb305, rb306, rb307, rb308, rb309, rb310, rb311, rb312, rb313, rb314, rb315, rb316, rb317, rb318, rb319, rb320, rb321, rb322, rb323, rb324, rb325, rb326, rb327, rb328, rb329, rb330, rb331, rb332, rb333, rb334, rb335, rb336, rb337, rb338, rb339, rb340, rb341, rb342, rb343, rb344, rb345, rb346, rb347, rb348, rb349, rb350, rb351, rb352, rb353, rb354, rb355, rb356, rb357, rb358, rb359, rb360, rb361, rb362, rb363, rb364, rb365, rb366, rb367, rb368, rb369, rb370, rb371, rb372, rb373, rb374, rb375, rb376, rb377, rb378, rb379, rb380, rb381, rb382, rb383, rb384, rb385, rb386, rb387, rb388, rb389, rb390, rb391, rb392, rb393, rb394, rb395, rb396, rb397, rb398, rb399, rb400, rb401, rb402, rb403, rb404, rb405, rb406, rb407, rb408, rb409, rb410, rb411, rb412, rb413, rb414, rb415, rb416, rb417, rb418, rb419, rb420, rb421, rb422, rb423, rb424, rb425, rb426, rb427, rb428, rb429, rb430, rb431, rb432, rb433, rb434, rb435, rb436, rb437, rb438, rb439, rb440, rb441, rb442, rb443, rb444, rb445, rb446, rb447, rb448, rb449, rb450, rb451, rb452, rb453, rb454, rb455, rb456, rb457, rb458, rb459, rb460, rb461, rb462, rb463, rb464, rb465, rb466, rb467, rb468, rb469, rb470, rb471, rb472, rb473, rb474, rb475, rb476, rb477, rb478, rb479, rb480, rb481, rb482, rb483, rb484, rb485, rb486, rb487, rb488, rb489, rb490, rb491, rb492, rb493, rb494, rb495, rb496, rb497, rb498, rb499, rb500, rb501, rb502, rb503, rb504, rb505, rb506, rb507, rb508, rb509, rb510, rb511, rb512, rb513, rb514, rb515, rb516, rb517, rb518, rb519, rb520, rb521, rb522, rb523, rb524, rb525, rb526, rb527, rb528, rb529, rb530, rb531, rb532, rb533, rb534, rb535, rb536, rb537, rb538, rb539, rb540, rb541, rb542, rb543, rb544, rb545, rb546, rb547, rb548, rb549, rb550, rb551, rb552, rb553, rb554, rb555, rb556, rb557, rb558, rb559, rb560, rb561, rb562, rb563, rb564, rb565, rb566, rb567, rb568, rb569, rb570, rb571, rb572, rb573, rb574, rb575, rb576, rb577, rb578, rb579, rb580, rb581, rb582, rb583, rb584, rb585, rb586, rb587, rb588, rb589, rb590, rb591, rb592, rb593, rb594, rb595, rb596, rb597, rb598, rb599, rb600, rb601, rb602, rb603, rb604, rb605, rb606, rb607, rb608, rb609, rb610, rb611, rb612, rb613, rb614, rb615, rb616, rb617, rb618, rb619, rb620, rb621, rb622, rb623, rb624, rb625, rb626, rb627, rb628, rb629, rb630, rb631, rb632, rb633, rb634, rb635, rb636, rb637, rb638, rb639, rb640, rb641, rb642, rb643, rb644, rb645, rb646, rb647, rb648, rb649, rb650, rb651, rb652, rb653, rb654, rb655, rb656, rb657, rb658, rb659, rb660, rb661, rb662, rb663, rb664, rb665, rb666, rb667, rb668, rb669, rb670, rb671, rb672, rb673, rb674, rb675, rb676, rb677, rb678, rb679, rb680, rb681, rb682, rb683, rb684, rb685, rb686, rb687, rb688, rb689, rb690, rb691, rb692, rb693, rb694, rb695, rb696, rb697, rb698, rb699, rb700, rb701, rb702, rb703, rb704, rb705, rb706, rb707, rb708, rb709, rb710, rb711, rb712, rb713, rb714, rb715, rb716, rb717, rb718, rb719, rb720, rb721, rb722, rb723, rb724, rb725, rb726, rb727, rb728, rb729, rb730, rb731, rb732, rb733, rb734, rb735, rb736, rb737, rb738, rb739, rb740, rb741, rb742, rb743, rb744, rb745, rb746, rb747, rb748, rb749, rb750, rb751, rb752, rb753, rb754, rb755, rb756, rb757, rb758, rb759, rb760, rb761, rb762, rb763, rb764, rb765, rb766, rb767, rb768, rb769, rb770, rb771, rb772, rb773, rb774, rb775, rb776, rb777, rb778, rb779, rb780, rb781, rb782, rb783, rb784, rb785, rb786, rb787, rb788, rb789, rb790, rb791, rb792, rb793, rb794, rb795, rb796, rb797, rb798, rb799, rb800, rb801, rb802, rb803, rb804, rb805, rb806, rb807, rb808, rb809, rb810, rb811, rb812, rb813, rb814, rb815, rb816, rb817, rb818, rb819, rb820, rb821, rb822, rb823, rb824, rb825, rb826, rb827, rb828, rb829, rb830, rb831, rb832, rb833, rb834, rb835, rb836, rb837, rb838, rb839, rb840, rb841, rb842, rb843, rb844, rb845, rb846, rb847, rb848, rb849, rb850, rb851, rb852, rb853, rb854, rb855, rb856, rb857, rb858, rb859, rb860, rb861, rb862, rb863, rb864, rb865, rb866, rb867, rb868, rb869, rb870, rb871, rb872, rb873, rb874, rb875, rb876, rb877, rb878, rb879, rb880, rb881, rb882, rb883, rb884, rb885, rb886, rb887, rb888, rb889, rb890, rb891, rb892, rb893, rb894, rb895, rb896, rb897, rb898, rb899, rb900, rb901, rb902, rb903, rb904, rb905, rb906, rb907, rb908, rb909, rb910, rb911, rb912, rb913, rb914, rb915, rb916, rb917, rb918, rb919, rb920, rb921, rb922, rb923, rb924, rb925, rb926, rb927, rb928, rb929, rb930, rb931, rb932, rb933, rb934, rb935, rb936, rb937, rb938, rb939, rb940, rb941, rb942, rb943, rb944, rb945, rb946, rb947, rb948, rb949, rb950, rb951, rb952, rb953, rb954, rb955, rb956, rb957, rb958, rb959, rb960, rb961, rb962, rb963, rb964, rb965, rb966, rb967, rb968, rb969, rb970, rb971, rb972, rb973, rb974, rb975, rb976, rb977, rb978, rb979, rb980, rb981, rb982, rb983, rb984, rb985, rb986, rb987, rb988, rb989, rb990, rb991, rb992, rb993, rb994, rb995, rb996, rb997, rb998, rb999, rb1000, rb1001, rb1002, rb1003, rb1004, rb1005, rb1006, rb1007, rb1008, rb1009, rb1010, rb1011, rb1012, rb1013, rb1014, rb1015, rb1016, rb1017, rb1018, rb1019, rb1020, rb1021, rb1022, rb1023, rb1024, rb1025, rb1026, rb1027, rb1028, rb1029, rb1030, rb1031, rb1032, rb1033, rb1034, rb1035, rb1036, rb1037, rb1038, rb1039, rb1040, rb1041, rb1042, rb1043, rb1044, rb1045, rb1046, rb1047, rb1048, rb1049, rb1050, rb1051, rb1052, rb1053, rb1054, rb1055, rb1056, rb1057, rb1058, rb1059, rb1060, rb1061, rb1062, rb1063, rb1064, rb1065, rb1066, rb1067, rb1068, rb1069, rb1070, rb1071, rb1072, rb1073, rb1074, rb1075, rb1076, rb1077, rb1078, rb1079, rb1080, rb1081, rb1082, rb1083, rb1084, rb1085, rb1086, rb1087, rb1088, rb1089, rb1090, rb1091, rb1092, rb1093, rb1094, rb1095, rb1096, rb1097, rb1098, rb1099, rb1100, rb1101, rb1102, rb1103, rb1104, rb1105, rb1106, rb1107, rb1108, rb1109, rb1110, rb1111, rb1112, rb1113, rb1114, rb1115, rb1116, rb1117, rb1118, rb1119, rb1120, rb1121, rb1122, rb1123, rb1124, rb1125, rb1126, rb1127, rb1128, rb1129, rb1130, rb1131, rb1132, rb1133, rb1134, rb1135, rb1136, rb1137, rb1138, rb1139, rb1140, rb1141, rb1142, rb1143, rb1144, rb1145, rb1146, rb1147, rb1148, rb1149, rb1150, rb1151, rb1152, rb1153, rb1154, rb1155, rb1156, rb1157, rb1158, rb1159, rb1160, rb1161, rb1162, rb1163, rb1164, rb1165, rb1166, rb1167, rb1168, rb1169, rb1170, rb1171, rb1172, rb1173, rb1174, rb1175, rb1176, rb1177, rb1178, rb1179, rb1180, rb1181, rb1182, rb1183, rb1184, rb1185, rb1186, rb1187, rb1188, rb1189, rb1190, rb1191, rb1192, rb1193, rb1194, rb1195, rb1196, rb1197, rb1198, rb1199, rb1200, rb1201, rb1202, rb1203, rb1204, rb1205, rb1206, rb1207, rb1208, rb1209, rb1210, rb1211, rb1212, rb1213, rb1214, rb1215, rb1216, rb1217, rb1218, rb1219, rb1220, rb1221, rb1222, rb1223, rb1224, rb1225, rb1226, rb1227, rb1228, rb1229, rb1230, rb1231, rb1232, rb1233, rb1234, rb1235, rb1236, rb1237, rb1238, rb1239, rb1240, rb1241, rb1242, rb1243, rb1244, rb1245, rb1246, rb1247, rb1248, rb1249, rb1250, rb1251, rb1252, rb1253, rb1254, rb1255, rb1256, rb1257, rb1258, rb1259, rb1260, rb1261, rb1262, rb1263, rb1264, rb1265, rb1266, rb1267, rb1268, rb1269, rb1270, rb1271, rb1272, rb1273, rb1274, rb1275, rb1276, rb1277, rb1278, rb1279, rb1280, rb1281, rb1282, rb1283, rb1284, rb1285, rb1286, rb1287, rb1288, rb1289, rb1290, rb1291, rb1292, rb1293, rb1294, rb1295, rb1296, rb1297, rb1298, rb1299, rb1300, rb1301, rb1302, rb1303, rb1304, rb1305, rb1306, rb1307, rb1308, rb1309, rb1310, rb1311, rb1312, rb1313, rb1314, rb1315, rb1316, rb1317, rb1318, rb1319, rb1320, rb1321, rb1322, rb1323, rb1324, rb1325, rb1326, rb1327, rb1328, rb1329, rb1330, rb1331, rb1332, rb1333, rb1334, rb1335, rb1336, rb1337, rb1338, rb1339, rb1340, rb1341, rb1342, rb1343, rb1344, rb1345, rb1346, rb1347, rb1348, rb1349, rb1350, rb1351, rb1352, rb1353, rb1354, rb1355, rb1356, rb1357, rb1358, rb1359, rb1360, rb1361, rb1362, rb1363, rb1364, rb1365, rb1366, rb1367, rb1368, rb1369, rb1370, rb1371, rb1372, rb1373, rb1374, rb1375, rb1376, rb1377, rb1378, rb1379, rb1380, rb1381, rb1382, rb1383, rb1384, rb1385, rb1386, rb1387, rb1388, rb1389, rb1390, rb1391, rb1392, rb1393, rb1394, rb1395, rb1396, rb1397, rb1398, rb1399, rb1400, rb1401, rb1402, rb1403, rb1404, rb1405, rb1406, rb1407, rb1408, rb1409, rb1410, rb1411, rb1412, rb1413, rb1414, rb1415, rb1416, rb1417, rb1418, rb1419, rb1420, rb1421, rb1422, rb1423, rb1424, rb1425, rb1426, rb1427, rb1428, rb1429, rb1430, rb1431, rb1432, rb1433, rb1434, rb1435, rb1436, rb1437, rb1438, rb1439, rb1440, rb1441, rb1442, rb1443, rb1444, rb1445, rb1446, rb1447, rb1448, rb1449, rb1450, rb1451, rb1452, rb1453, rb1454, rb1455, rb1456, rb1457, rb1458, rb1459, rb1460, rb1461, rb1462, rb1463, rb1464, rb1465, rb1466, rb1467, rb1468, rb1469, rb1470, rb1471, rb1472, rb1473, rb1474, rb1475, rb1476, rb1477, rb1478, rb1479, rb1480, rb1481, rb1482, rb1483, rb1484, rb1485, rb1486, rb1487, rb1488, rb1489, rb1490, rb1491, rb1492, rb1493, rb1494, rb1495, rb1496, rb1497, rb1498, rb1499, rb1500, rb1501, rb1502, rb1503, rb1504, rb1505, rb1506, rb1507, rb1508, rb1509, rb1510, rb1511, rb1512, rb1513, rb1514, rb1515, rb1516, rb1517, rb1518, rb1519, rb1520, rb1521, rb1522, rb1523, rb1524, rb1525, rb1526, rb1527, rb1528, rb1529, rb1530, rb1531, rb1532, rb1533, rb1534, rb1535, rb1536, rb1537, rb1538, rb1539, rb1540, rb1541, rb1542, rb1543, rb1544, rb1545, rb1546, rb1547, rb1548, rb1549, rb1550, rb1551, rb1552, rb1553, rb1554, rb1555, rb1556, rb1557, rb1558, rb1559, rb1560, rb1561, rb1562, rb1563, rb1564, rb1565, rb1566, rb1567, rb1568, rb1569, rb1570, rb1571, rb1572, rb1573, rb1574, rb1575, rb1576, rb1577, rb1578, rb1579, rb1580, rb1581, rb1582, rb1583, rb1584, rb1585, rb1586, rb1587, rb1588, rb1589, rb1590, rb1591, rb1592, rb1593, rb1594, rb1595, rb1596, rb1597, rb1598, rb1599, rb1600, rb1601, rb1602, rb1603, rb1604, rb1605, rb1606, rb1607, rb1608, rb1609, rb1610, rb1611, rb1612, rb1613, rb1614, rb1615, rb1616, rb1617, rb1618, rb1619, rb1620, rb1621, rb1622, rb1623, rb1624, rb1625, rb1626, rb1627, rb1628, rb1629, rb1630, rb1631, rb1632, rb1633, rb1634, rb1635, rb1636, rb1637, rb1638, rb1639, rb1640, rb1641, rb1642, rb1643, rb1644, rb1645, rb1646, rb1647, rb1648, rb1649, rb1650, rb1651, rb1652, rb1653, rb1654, rb1655, rb1656, rb1657, rb1658, rb1659, rb1660, rb1661, rb1662, rb1663, rb1664, rb1665, rb1666, rb1667, rb1668, rb1669, rb1670, rb1671, rb1672, rb1673, rb1674, rb1675, rb1676, rb1677, rb1678, rb1679, rb1680, rb1681, rb1682, rb1683, rb1684, rb1685, rb1686, rb1687, rb1688, rb1689, rb1690, rb1691, rb1692, rb1693, rb1694, rb1695, rb1696, rb1697, rb1698, rb1699, rb1700, rb1701, rb1702, rb1703, rb1704, rb1705, rb1706, rb1707, rb1708, rb1709, rb1710, rb1711, rb1712, rb1713, rb1714, rb1715, rb1716, rb1717, rb1718, rb1719, rb1720, rb1721, rb1722, rb1723, rb1724, rb1725, rb1726, rb1727, rb1728, rb1729, rb1730, rb1731, rb1732, rb1733, rb1734, rb1735, rb1736, rb1737, rb1738, rb1739, rb1740, rb1741, rb1742, rb1743, rb1744, rb1745, rb1746, rb1747, rb1748, rb1749, rb1750, rb1751, rb1752, rb1753, rb1754, rb1755, rb1756, rb1757, rb1758, rb1759, rb1760, rb1761, rb1762, rb1763, rb1764, rb1765, rb1766, rb1767, rb1768, rb1769, rb1770, rb1771, rb1772, rb1773, rb1774, rb1775, rb1776, rb1777, rb1778, rb1779, rb1780, rb1781, rb1782, rb1783, rb1784, rb1785, rb1786, rb1787, rb1788, rb1789, rb1790, rb1791, rb1792, rb1793, rb1794, rb1795, rb1796, rb1797, rb1798, rb1799, rb1800, rb1801, rb1802, rb1803, rb1804, rb1805, rb1806, rb1807, rb1808, rb1809, rb1810, rb1811, rb1812, rb1813, rb1814, rb1815, rb1816, rb1817, rb1818, rb1819, rb1820, rb1821, rb1822, rb1823, rb1824, rb1825, rb1826, rb1827, rb1828, rb1829, rb1830, rb1831, rb1832, rb1833, rb1834, rb1835, rb1836, rb1837, rb1838, rb1839, rb1840, rb1841, rb1842, rb1843, rb1844, rb1845, rb1846, rb1847, rb1848, rb1849, rb1850, rb1851, rb1852, rb1853, rb1854, rb1855, rb1856, rb1857, rb1858, rb1859, rb1860, rb1861, rb1862, rb1863, rb1864, rb1865, rb1866, rb1867, rb1868, rb1869, rb1870, rb1871, rb1872, rb1873, rb1874, rb1875, rb1876, rb1877, rb1878, rb1879, rb1880, rb1881, rb1882, rb1883, rb1884, rb1885, rb1886, rb1887, rb1888, rb1889, rb1890, rb1891, rb1892, rb1893, rb1894, rb1895, rb1896, rb1897, rb1898, rb1899, rb1900, rb1901, rb1902, rb1903, rb1904, rb1905, rb1906, rb1907, rb1908, rb1909, rb1910, rb1911, rb1912, rb1913, rb1914, rb1915, rb1916, rb1917, rb1918, rb1919, rb1920, rb1921, rb1922, rb1923, rb1924, rb1925, rb1926, rb1927, rb1928, rb1929, rb1930, rb1931, rb1932, rb1933, rb1934, rb1935, rb1936, rb1937, rb1938, rb1939, rb1940, rb1941, rb1942, rb1943, rb1944, rb1945, rb1946, rb1947, rb1948, rb1949, rb1950, rb1951, rb1952, rb1953, rb1954, rb1955, rb1956, rb1957, rb1958, rb1959, rb1960, rb1961, rb1962, rb1963, rb1964, rb1965, rb1966, rb1967, rb1968, rb1969, rb1970, rb1971, rb1972, rb1973, rb1974, rb1975, rb1976, rb1977, rb1978, rb1979, rb1980, rb1981, rb1982, rb1983, rb1984, rb1985, rb1986, rb1987, rb1988, rb1989, rb1990, rb1991, rb1992, rb1993, rb1994, rb1995, rb1996, rb1997, rb1998, rb1999, rb2000, rb2001, rb2002, rb2003, rb2004, rb2005, rb2006, rb2007, rb2008, rb2009, rb2010, rb2011, rb2012, rb2013, rb2014, rb2015, rb2016, rb2017, rb2018, rb2019, rb2020, rb2021, rb2022, rb2023, rb2024, rb2025, rb2026, rb2027, rb2028, rb2029, rb2030, rb2031, rb2032, rb2033, rb2034, rb2035, rb2036, rb2037, rb2038, rb2039, rb2040, rb2041, rb2042, rb2043, rb2044, rb2045, rb2046, rb2047, rb2048, rb2049, rb2050, rb2051, rb2052, rb2053, rb2054, rb2055, rb2056, rb2057, rb2058, rb2059, rb2060, rb2061, rb2062, rb2063, rb2064, rb2065, rb2066, rb2067, rb2068, rb2069, rb2070, rb2071, rb2072, rb2073, rb2074, rb2075, rb2076, rb2077, rb2078, rb2079, rb2080, rb2081, rb2082, rb2083, rb2084, rb2085, rb2086, rb2087, rb2088, rb2089, rb2090, rb2091, rb2092, rb2093, rb2094, rb2095, rb2096, rb2097, rb2098, rb2099, rb2100, rb2101, rb2102, rb2103, rb2104, rb2105, rb2106, rb2107, rb2108, rb2109, rb2110, rb2111, rb2112, rb2113, rb2114, rb2115, rb2116, rb2117, rb2118, rb2119, rb2120, rb2121, rb2122, rb2123, rb2124, rb2125, rb2126, rb2127, rb2128, rb2129, rb2130, rb2131, rb2132, rb2133, rb2134, rb2135, rb2136, rb2137, rb2138, rb2139, rb2140, rb2141, rb2142, rb2143, rb2144, rb2145, rb2146, rb2147, rb2148, rb2149, rb2150, rb2151, rb2152, rb2153, rb2154, rb2155, rb2156, rb2157, rb2158, rb2159, rb2160, rb2161, rb2162, rb2163, rb2164, rb2165, rb2166, rb2167, rb2168, rb2169, rb2170, rb2171, rb2172, rb2173, rb2174, rb2175, rb2176, rb2177, rb2178, rb2179, rb2180, rb2181, rb2182, rb2183, rb2184, rb2185, rb2186, rb2187, rb2188, rb2189, rb2190, rb2191, rb2192, rb2193, rb2194, rb2195, rb2196, rb2197, rb2198, rb2199, rb2200, rb2201, rb2202, rb2203, rb2204, rb2205, rb2206, rb2207, rb2208, rb2209, rb2210, rb2211, rb2212, rb2213, rb2214, rb2215, rb2216, rb2217, rb2218, rb2219, rb2220, rb2221, rb2222, rb2223, rb2224, rb2225, rb2226, rb2227, rb2228, rb2229, rb2230, rb2231, rb2232, rb2233, rb2234, rb2235, rb2236, rb2237, rb2238, rb2239, rb2240, rb2241, rb2242, rb2243, rb2244, rb2245, rb2246, rb2247, rb2248, rb2249, rb2250, rb2251, rb2252, rb2253, rb2254, rb2255, rb2256, rb2257, rb2258, rb2259, rb2260, rb2261, rb2262, rb2263, rb2264, rb2265, rb2266, rb2267, rb2268, rb2269, rb2270, rb2271, rb2272, rb2273, rb2274, rb2275, rb2276, rb2277, rb2278, rb2279, rb2280, rb2281, rb2282, rb2283, rb2284, rb2285, rb2286, rb2287, rb2288, rb2289, rb2290, rb2291, rb2292, rb2293, rb2294, rb2295, rb2296, rb2297, rb2298, rb2299, rb2300, rb2301, rb2302, rb2303, rb2304, rb2305, rb2306, rb2307, rb2308, rb2309, rb2310, rb2311, rb2312, rb2313, rb2314, rb2315, rb2316, rb2317, rb2318, rb2319, rb2320, rb2321, rb2322, rb2323, rb2324, rb2325, rb2326, rb2327, rb2328, rb2329, rb2330, rb2331, rb2332, rb2333, rb2334, rb2335, rb2336, rb2337, rb2338, rb2339, rb2340, rb2341, rb2342, rb2343, rb2344, rb2345, rb2346, rb2347, rb2348, rb2349, rb2350, rb2351, rb2352, rb2353, rb2354, rb2355, rb2356, rb2357, rb2358, rb2359, rb2360, rb2361, rb2362, rb2363, rb2364, rb2365, rb2366, rb2367, rb2368, rb2369, rb2370, rb2371, rb2372, rb2373, rb2374, rb2375, rb2376, rb2377, rb2378, rb2379, rb2380, rb2381, rb2382, rb2383, rb2384, rb2385, rb2386, rb2387, rb2388, rb2389, rb2390, rb2391, rb2392, rb2393, rb2394, rb2395, rb2396, rb2397, rb2398, rb2399, rb2400, rb2401, rb2402, rb2403, rb2404, rb2405, rb2406, rb2407, rb2408, rb2409, rb2410, rb2411, rb2412, rb2413, rb2414, rb2415, rb2416, rb2417, rb2418, rb2419, rb2420, rb2421, rb2422, rb2423, rb2424, rb2425, rb2426, rb2427, rb2428, rb2429, rb2430, rb2431, rb2432, rb2433, rb2434, rb2435, rb2436, rb2437, rb2438, rb2439, rb2440, rb2441, rb2442, rb2443, rb2444, rb2445, rb2446, rb2447, rb2448, rb2449, rb2450, rb2451, rb2452, rb2453, rb2454, rb2455, rb2456, rb2457, rb2458, rb2459, rb2460, rb2461, rb2462, rb2463, rb2464, rb2465, rb2466, rb2467, rb2468, rb2469, rb2470, rb2471, rb2472, rb2473, rb2474, rb2475, rb2476, rb2477, rb2478, rb2479, rb2480, rb2481, rb2482, rb2483, rb2484, rb2485, rb2486, rb2487, rb2488, rb2489, rb2490, rb2491, rb2492, rb2493, rb2494, rb2495, rb2496, rb2497, rb2498, rb2499, rb2500, rb2501, rb2502, rb2503, rb2504, rb2505, rb2506, rb2507, rb2508, rb2509, rb2510, rb2511, rb2512, rb2513, rb2514, rb2515, rb2516, rb2517, rb2518, rb2519, rb2520, rb2521, rb2522, rb2523, rb2524, rb2525, rb2526, rb2527, rb2528, rb2529, rb2530, rb2531, rb2532, rb2533, rb2534, rb2535, rb2536, rb2537, rb2538, rb2539, rb2540, rb2541, rb2542, rb2543, rb2544, rb2545, rb2546, rb2547, rb2548, rb2549, rb2550, rb2551, rb2552, rb2553, rb2554, rb2555, rb2556, rb2557, rb2558, rb2559, rb2560, rb2561, rb2562, rb2563, rb2564, rb2565, rb2566, rb2567, rb2568, rb2569, rb2570, rb2571, rb2572, rb2573, rb2574, rb2575, rb2576, rb2577, rb2578, rb2579, rb2580, rb2581, rb2582, rb2583, rb2584, rb2585, rb2586, rb2587, rb2588, rb2589, rb2590, rb2591, rb2592, rb2593, rb2594, rb2595, rb2596, rb2597, rb2598, rb2599, rb2600, rb2601, rb2602, rb2603, rb2604, rb2605, rb2606, rb2607, rb2608, rb2609, rb2610, rb2611, rb2612, rb2613, rb2614, rb2615, rb2616, rb2617, rb2618, rb2619, rb2620, rb2621, rb2622, rb2623, rb2624, rb2625, rb2626, rb2627, rb2628, rb2629, rb2630, rb2631, rb2632, rb2633, rb2634, rb2635, rb2636, rb2637, rb2638, rb2639, rb2640, rb2641, rb2642, rb2643, rb2644, rb2645, rb2646, rb2647, rb2648, rb2649, rb2650, rb2651, rb2652, rb2653, rb2654, rb2655, rb2656, rb2657, rb2658, rb2659, rb2660, rb2661, rb2662, rb2663, rb2664, rb2665, rb2666, rb2667, rb2668, rb2669, rb2670, rb2671, rb2672, rb2673, rb2674, rb2675, rb2676, rb2677, rb2678, rb2679, rb2680, rb2681, rb2682, rb2683, rb2684, rb2685, rb2686, rb2687, rb2688, rb2689, rb2690, rb2691, rb2692, rb2693, rb2694, rb2695, rb2696, rb2697, rb2698, rb2699, rb2700, rb2701, rb2702, rb2703, rb2704, rb2705, rb2706, rb2707, rb2708, rb2709, rb2710, rb2711, rb2712, rb2713, rb2714, rb2715, rb2716, rb2717, rb2718, rb2719, rb2720, rb2721, rb2722, rb2723, rb2724, rb2725, rb2726, rb2727, rb2728, rb2729, rb2730, rb2731, rb2732, rb2733, rb2734, rb2735, rb2736, rb2737, rb2738, rb2739, rb2740, rb2741, rb2742, rb2743, rb2744, rb2745, rb2746, rb2747, rb2748, rb2749, rb2750, rb2751, rb2752, rb2753, rb2754, rb2755, rb2756, rb2757, rb2758, rb2759, rb2760, rb2761, rb2762, rb2763, rb2764, rb2765, rb2766, rb2767, rb2768, rb2769, rb2770, rb2771, rb2772, rb2773, rb2774, rb2775, rb2776, rb2777, rb2778, rb2779, rb2780, rb2781, rb2782, rb2783, rb2784, rb2785, rb2786, rb2787, rb2788, rb2789, rb2790, rb2791, rb2792, rb2793, rb2794, rb2795, rb2796, rb2797, rb2798, rb2799, rb2800, rb2801, rb2802, rb2803, rb2804, rb2805, rb2806, rb2807, rb2808, rb2809, rb2810, rb2811, rb2812, rb2813, rb2814, rb2815, rb2816, rb2817, rb2818, rb2819, rb2820, rb2821, rb2822, rb2823, rb2824, rb2825, rb2826, rb2827, rb2828, rb2829, rb2830, rb2831, rb2832, rb2833, rb2834, rb2835, rb2836, rb2837, rb2838, rb2839, rb2840, rb2841, rb2842, rb2843, rb2844, rb2845, rb2846, rb2847, rb2848, rb2849, rb2850, rb2851, rb2852, rb2853, rb2854, rb2855, rb2856, rb2857, rb2858, rb2859, rb2860, rb2861, rb2862, rb2863, rb2864, rb2865, rb2866, rb2867, rb2868, rb2869, rb2870, rb2871, rb2872, rb2873, rb2874, rb2875, rb2876, rb2877, rb2878, rb2879, rb2880, rb2881, rb2882, rb2883, rb2884, rb2885, rb2886, rb2887, rb2888, rb2889, rb2890, rb2891, rb2892, rb2893, rb2894, rb2895, rb2896, rb2897, rb2898, rb2899, rb2900, rb2901, rb2902, rb2903, rb2904, rb2905, rb2906, rb2907, rb2908, rb2909, rb2910, rb2911, rb2912, rb2913, rb2914, rb2915, rb2916, rb2917, rb2918, rb2919, rb2920, rb2921, rb2922, rb2923, rb2924, rb2925, rb2926, rb2927, rb2928, rb2929, rb2930, rb2931, rb2932, rb2933, rb2934, rb2935, rb2936, rb2937, rb2938, rb2939, rb2940, rb2941, rb2942, rb2943, rb2944, rb2945, rb2946, rb2947, rb2948, rb2949, rb2950, rb2951, rb2952, rb2953, rb2954, rb2955, rb2956, rb2957, rb2958, rb2959, rb2960, rb2961, rb2962, rb2963, rb2964, rb2965, rb2966, rb2967, rb2968, rb2969, rb2970, rb2971, rb2972, rb2973, rb2974, rb2975, rb2976, rb2977, rb2978, rb2979, rb2980, rb2981, rb2982, rb2983, rb2984, rb2985, rb2986, rb2987, rb2988, rb2989, rb2990, rb2991, rb2992, rb2993, rb2994, rb2995, rb2996, rb2997, rb2998, rb2999, rb3000, rb3001, rb3002, rb3003, rb3004, rb3005, rb3006, rb3007, rb3008, rb3009, rb3010, rb3011, rb3012, rb3013, rb3014, rb3015, rb3016, rb3017, rb3018, rb3019, rb3020, rb3021, rb3022, rb3023, rb3024, rb3025, rb3026, rb3027, rb3028, rb3029, rb3030, rb3031, rb3032, rb3033, rb3034, rb3035, rb3036, rb3037, rb3038, rb3039, rb3040, rb3041, rb3042, rb3043, rb3044, rb3045, rb3046, rb3047, rb3048, rb3049, rb3050, rb3051, rb3052, rb3053, rb3054, rb3055, rb3056, rb3057, rb3058, rb3059, rb3060, rb3061, rb3062, rb3063, rb3064, rb3065, rb3066, rb3067, rb3068, rb3069, rb3070, rb3071, rb3072, rb3073, rb3074, rb3075, rb3076, rb3077, rb3078, rb3079, rb3080, rb3081, rb3082, rb3083, rb3084, rb3085, rb3086, rb3087, rb3088, rb3089, rb3090, rb3091, rb3092, rb3093, rb3094, rb3095, rb3096, rb3097, rb3098, rb3099, rb3100, rb3101, rb3102, rb3103, rb3104, rb3105, rb3106, rb3107, rb3108, rb3109, rb3110, rb3111, rb3112, rb3113, rb3114, rb3115, rb3116, rb3117, rb3118, rb3119, rb3120, rb3121, rb3122, rb3123, rb3124, rb3125, rb3126, rb3127, rb3128, rb3129, rb3130, rb3131, rb3132, rb3133, rb3134, rb3135, rb3136, rb3137, rb3138, rb3139, rb3140, rb3141, rb3142, rb3143, rb3144, rb3145, rb3146, rb3147, rb3148, rb3149, rb3150, rb3151, rb3152, rb3153, rb3154, rb3155, rb3156, rb3157, rb3158, rb3159, rb3160, rb3161, rb3162, rb3163, rb3164, rb3165, rb3166, rb3167, rb3168, rb3169, rb3170, rb3171, rb3172, rb3173, rb3174, rb3175, rb3176, rb3177, rb3178, rb3179, rb3180, rb3181, rb3182, rb3183, rb3184, rb3185, rb3186, rb3187, rb3188, rb3189, rb3190, rb3191, rb3192, rb3193, rb3194, rb3195, rb3196, rb3197, rb3198, rb3199, rb3200, rb3201, rb3202, rb3203, rb3204, rb3205, rb3206, rb3207, rb3208, rb3209, rb3210, rb3211, rb3212, rb3213, rb3214, rb3215, rb3216, rb3217, rb3218, rb3219, rb3220, rb3221, rb3222, rb3223, rb3224, rb3225, rb3226, rb3227, rb3228, rb3229, rb3230, rb3231, rb3232, rb3233, rb3234, rb3235, rb3236, rb3237, rb3238, rb3239, rb3240, rb3241, rb3242, rb3243, rb3244, rb3245, rb3246, rb3247, rb3248, rb3249, rb3250, rb3251, rb3252, rb3253, rb3254, rb3255, rb3256, rb3257, rb3258, rb3259, rb3260, rb3261, rb3262, rb3263, rb3264, rb3265, rb3266, rb3267, rb3268, rb3269, rb3270, rb3271, rb3272, rb3273, rb3274, rb3275, rb3276, rb3277, rb3278, rb3279, rb3280, rb3281, rb3282, rb3283, rb3284, rb3285, rb3286, rb3287, rb3288, rb3289, rb3290, rb3291, rb3292, rb3293, rb3294, rb3295, rb3296, rb3297, rb3298, rb3299, rb3300, rb3301, rb3302, rb3303, rb3304, rb3305, rb3306, rb3307, rb3308, rb3309, rb3310, rb3311, rb3312, rb3313, rb3314, rb3315, rb3316, rb3317, rb3318, rb3319, rb3320, rb3321, rb3322, rb3323, rb3324, rb3325, rb3326, rb3327, rb3328, rb3329, rb3330, rb3331, rb3332, rb3333, rb3334, rb3335, rb3336, rb3337, rb3338, rb3339, rb3340, rb3341, rb3342, rb3343, rb3344, rb3345, rb3346, rb3347, rb3348, rb3349, rb3350, rb3351, rb3352, rb3353, rb3354, rb3355, rb3356, rb3357, rb3358, rb3359, rb3360, rb3361, rb3362, rb3363, rb3364, rb3365, rb3366, rb3367, rb3368, rb3369, rb3370, rb3371, rb3372, rb3373, rb3374, rb3375, rb3376, rb3377, rb3378, rb3379, rb3380, rb3381, rb3382, rb3383, rb3384, rb3385, rb3386, rb3387, rb3388, rb3389, rb3390, rb3391, rb3392, rb3393, rb3394, rb3395, rb3396, rb3397, rb3398, rb3399, rb3400, rb3401, rb3402, rb3403, rb3404, rb3405, rb3406, rb3407, rb3408, rb3409, rb3410, rb3411, rb3412, rb3413, rb3414, rb3415, rb3416, rb3417, rb3418, rb3419, rb3420, rb3421, rb3422, rb3423, rb3424, rb3425, rb3426, rb3427, rb3428, rb3429, rb3430, rb3431, rb3432, rb3433, rb3434, rb3435, rb3436, rb3437, rb3438, rb3439, rb3440, rb3441, rb3442, rb3443, rb3444, rb3445, rb3446, rb3447, rb3448, rb3449, rb3450, rb3451, rb3452, rb3453, rb3454, rb3455, rb3456, rb3457, rb3458, rb3459, rb3460, rb3461, rb3462, rb3463, rb3464, rb3465, rb3466, rb3467, rb3468, rb3469, rb3470, rb3471, rb3472, rb3473, rb3474, rb3475, rb3476, rb3477, rb3478, rb3479, rb3480, rb3481, rb3482, rb3483, rb3484, rb3485, rb3486, rb3487, rb3488, rb3489, rb3490, rb3491, rb3492, rb3493, rb3494, rb3495, rb3496, rb3497, rb3498, rb3499, rb3500, rb3501, rb3502, rb3503, rb3504, rb3505, rb3506, rb3507, rb3508, rb3509, rb3510, rb3511, rb3512, rb3513, rb3514, rb3515, rb3516, rb3517, rb3518, rb3519, rb3520, rb3521, rb3522, rb3523, rb3524, rb3525, rb3526, rb3527, rb3528, rb3529, rb3530, rb3531, rb3532, rb3533, rb3534, rb3535, rb3536, rb3537, rb3538, rb3539, rb3540, rb3541, rb3542, rb3543, rb3544, rb3545, rb3546, rb3547, rb3548, rb3549, rb3550, rb3551, rb3552, rb3553, rb3554, rb3555, rb3556, rb3557, rb3558, rb3559, rb3560, rb3561, rb3562, rb3563, rb3564, rb3565, rb3566, rb3567, rb3568, rb3569, rb3570, rb3571, rb3572, rb3573, rb3574, rb3575, rb3576, rb3577, rb3578, rb3579, rb3580, rb3581, rb3582, rb3583, rb3584, rb3585, rb3586, rb3587, rb3588, rb3589, rb3590, rb3591, rb3592, rb3593, rb3594, rb3595, rb3596, rb3597, rb3598, rb3599, rb3600, rb3601, rb3602, rb3603, rb3604, rb3605, rb3606, rb3607, rb3608, rb3609, rb3610, rb3611, rb3612, rb3613, rb3614, rb3615, rb3616, rb3617, rb3618, rb3619, rb3620, rb3621, rb3622, rb3623, rb3624, rb3625, rb3626, rb3627, rb3628, rb3629, rb3630, rb3631, rb3632, rb3633, rb3634, rb3635, rb3636, rb3637, rb3638, rb3639, rb3640, rb3641, rb3642, rb3643, rb3644, rb3645, rb3646, rb3647, rb3648, rb3649, rb3650, rb3651, rb3652, rb3653, rb3654, rb3655, rb3656, rb3657, rb3658, rb3659, rb3660, rb3661, rb3662, rb3663, rb3664, rb3665, rb3666, rb3667, rb3668, rb3669, rb3670, rb3671, rb3672, rb3673, rb3674, rb3675, rb3676, rb3677, rb3678, rb3679, rb3680, rb3681, rb3682, rb3683, rb3684, rb3685, rb3686, rb3687, rb3688, rb3689, rb3690, rb3691, rb3692, rb3693, rb3694, rb3695, rb3696, rb3697, rb3698, rb3699, rb3700, rb3701, rb3702, rb3703, rb3704, rb3705, rb3706, rb3707, rb3708, rb3709, rb3710, rb3711, rb3712, rb3713, rb3714, rb3715, rb3716, rb3717, rb3718, rb3719, rb3720, rb3721, rb3722, rb3723, rb3724, rb3725, rb3726, rb3727, rb3728, rb3729, rb3730, rb3731, rb3732, rb3733, rb3734, rb3735, rb3736, rb3737, rb3738, rb3739, rb3740, rb3741, rb3742, rb3743, rb3744, rb3745, rb3746, rb3747, rb3748, rb3749, rb3750, rb3751, rb3752, rb3753, rb3754, rb3755, rb3756, rb3757, rb3758, rb3759, rb3760, rb3761, rb3762, rb3763, rb3764, rb3765, rb3766, rb3767, rb3768, rb3769, rb3770, rb3771, rb3772, rb3773, rb3774, rb3775, rb3776, rb3777, rb3778, rb3779, rb3780, rb3781, rb3782, rb3783, rb3784, rb3785, rb3786, rb3787, rb3788, rb3789, rb3790, rb3791, rb3792, rb3793, rb3794, rb3795, rb3796, rb3797, rb3798, rb3799, rb3800, rb3801, rb3802, rb3803, rb3804, rb3805, rb3806, rb3807, rb3808, rb3809, rb3810, rb3811, rb3812, rb3813, rb3814, rb3815, rb3816, rb3817, rb3818, rb3819, rb3820, rb3821, rb3822, rb3823, rb3824, rb3825, rb3826, rb3827, rb3828, rb3829, rb3830, rb3831, rb3832, rb3833, rb3834, rb3835, rb3836, rb3837, rb3838, rb3839, rb3840, rb3841, rb3842, rb3843, rb3844, rb3845, rb3846, rb3847, rb3848, rb3849, rb3850, rb3851, rb3852, rb3853, rb3854, rb3855, rb3856, rb3857, rb3858, rb3859, rb3860, rb3861, rb3862, rb3863, rb3864, rb3865, rb3866, rb3867, rb3868, rb3869, rb3870, rb3871, rb3872, rb3873, rb3874, rb3875, rb3876, rb3877, rb3878, rb3879, rb3880, rb3881, rb3882, rb3883, rb3884, rb3885, rb3886, rb3887, rb3888, rb3889, rb3890, rb3891, rb3892, rb3893, rb3894, rb3895, rb3896, rb3897, rb3898, rb3899, rb3900, rb3901, rb3902, rb3903, rb3904, rb3905, rb3906, rb3907, rb3908, rb3909, rb3910, rb3911, rb3912, rb3913, rb3914, rb3915, rb3916, rb3917, rb3918, rb3919, rb3920, rb3921, rb3922, rb3923, rb3924, rb3925, rb3926, rb3927, rb3928, rb3929, rb3930, rb3931, rb3932, rb3933, rb3934, rb3935, rb3936, rb3937, rb3938, rb3939, rb3940, rb3941, rb3942, rb3943, rb3944, rb3945, rb3946, rb3947, rb3948, rb3949, rb3950, rb3951, rb3952, rb3953, rb3954, rb3955, rb3956, rb3957, rb3958, rb3959, rb3960, rb3961, rb3962, rb3963, rb3964, rb3965, rb3966, rb3967, rb3968, rb3969, rb3970, rb3971, rb3972, rb3973, rb3974, rb3975, rb3976, rb3977, rb3978, rb3979, rb3980, rb3981, rb3982, rb3983, rb3984, rb3985, rb3986, rb3987, rb3988, rb3989, rb3990, rb3991, rb3992, rb3993, rb3994, rb3995, rb3996, rb3997, rb3998, rb3999, rb4000, rb4001, rb4002, rb4003, rb4004, rb4005, rb4006, rb4007, rb4008, rb4009, rb4010, rb4011, rb4012, rb4013, rb4014, rb4015, rb4016, rb4017, rb4018, rb4019, rb4020, rb4021, rb4022, rb4023, rb4024, rb4025, rb4026, rb4027, rb4028, rb4029, rb4030, rb4031, rb4032, rb4033, rb4034, rb4035, rb4036, rb4037, rb4038, rb4039, rb4040, rb4041, rb4042, rb4043, rb4044, rb4045, rb4046, rb4047, rb4048, rb4049, rb4050, rb4051, rb4052, rb4053, rb4054, rb4055, rb4056, rb4057, rb4058, rb4059, rb4060, rb4061, rb4062, rb4063, rb4064, rb4065, rb4066, rb4067, rb4068, rb4069, rb4070, rb4071, rb4072, rb4073, rb4074, rb4075, rb4076, rb4077, rb4078, rb4079, rb4080, rb4081, rb4082, rb4083, rb4084, rb4085, rb4086, rb4087, rb4088, rb4089, rb4090, rb4091, rb4092, rb4093, rb4094, rb4095, rb4096, rb4097, rb4098, rb4099, rb4100, rb4101, rb4102, rb4103, rb4104, rb4105, rb4106, rb4107, rb4108, rb4109, rb4110, rb4111, rb4112, rb4113, rb4114, rb4115, rb4116, rb4117, rb4118, rb4119, rb4120, rb4121, rb4122, rb4123, rb4124, rb4125, rb4126, rb4127, rb4128, rb4129, rb4130, rb4131, rb4132, rb4133, rb4134, rb4135, rb4136, rb4137, rb4138, rb4139, rb4140, rb4141, rb4142, rb4143, rb4144, rb4145, rb4146, rb4147, rb4148, rb4149, rb4150, rb4151, rb4152, rb4153, rb4154, rb4155, rb4156, rb4157, rb4158, rb4159, rb4160, rb4161, rb4162, rb4163, rb4164, rb4165, rb4166, rb4167, rb4168, rb4169, rb4170, rb4171, rb4172, rb4173, rb4174, rb4175, rb4176, rb4177, rb4178, rb4179, rb4180, rb4181, rb4182, rb4183, rb4184, rb4185, rb4186, rb4187, rb4188, rb4189, rb4190, rb4191, rb4192, rb4193, rb4194, rb4195, rb4196, rb4197, rb4198, rb4199, rb4200, rb4201, rb4202, rb4203, rb4204, rb4205, rb4206, rb4207, rb4208, rb4209, rb4210, rb4211, rb4212, rb4213, rb4214, rb4215, rb4216, rb4217, rb4218, rb4219, rb4220, rb4221, rb4222, rb4223, rb4224, rb4225, rb4226, rb4227, rb4228, rb4229, rb4230, rb4231, rb4232, rb4233, rb4234, rb4235, rb4236, rb4237, rb4238, rb4239, rb4240, rb4241, rb4242, rb4243, rb4244, rb4245, rb4246, rb4247, rb4248, rb4249, rb4250, rb4251, rb4252, rb4253, rb4254, rb4255, rb4256, rb4257, rb4258, rb4259, rb4260, rb4261, rb4262, rb4263, rb4264, rb4265, rb4266, rb4267, rb4268, rb4269, rb4270, rb4271, rb4272, rb4273, rb4274, rb4275, rb4276, rb4277, rb4278, rb4279, rb4280, rb4281, rb4282, rb4283, rb4284, rb4285, rb4286, rb4287, rb4288, rb4289, rb4290, rb4291, rb4292, rb4293, rb4294, rb4295, rb4296, rb4297, rb4298, rb4299, rb4300, rb4301, rb4302, rb4303, rb4304, rb4305, rb4306, rb4307, rb4308, rb4309, rb4310, rb4311, rb4312, rb4313, rb4314, rb4315, rb4316, rb4317, rb4318, rb4319, rb4320, rb4321, rb4322, rb4323, rb4324, rb4325, rb4326, rb4327, rb4328, rb4329, rb4330, rb4331, rb4332, rb4333, rb4334, rb4335, rb4336, rb4337, rb4338, rb4339, rb4340, rb4341, rb4342, rb4343, rb4344, rb4345, rb4346, rb4347;
  logic [17:0] a_ext;
  logic [1:0] lo0;
  logic [1:0] mg2;
  logic [17:0] m2;
  logic [1:0] lo23;
  logic [1:0] mg25;
  logic [1:0] lo46;
  logic [1:0] mg48;
  logic [1:0] lo69;
  logic [1:0] mg71;
  logic [1:0] lo92;
  logic [1:0] mg94;
  logic [1:0] lo115;
  logic [1:0] mg117;
  logic [1:0] lo138;
  logic [1:0] mg140;
  logic [1:0] lo161;
  logic [1:0] mg163;
  assign a_ext = {{2{a[15]}}, a};
  assign lo0 = {1'b0, {b[0]}} + {{1{1'b0}}, 1'b0};
  assign neg1 = b[1] & ~(1'b0 & b[0]);
  assign mg2 = b[1] ? (2'd2 - lo0) : lo0;
  assign sel3 = (mg2 == 2'd1);
  assign sel4 = (mg2 == 2'd2);
  assign m2 = {a_ext[16:0], 1'd0};
  assign pp5 = ((sel3 & a_ext[0]) | (sel4 & m2[0])) ^ neg1;
  assign pp6 = ((sel3 & a_ext[1]) | (sel4 & m2[1])) ^ neg1;
  assign pp7 = ((sel3 & a_ext[2]) | (sel4 & m2[2])) ^ neg1;
  assign pp8 = ((sel3 & a_ext[3]) | (sel4 & m2[3])) ^ neg1;
  assign pp9 = ((sel3 & a_ext[4]) | (sel4 & m2[4])) ^ neg1;
  assign pp10 = ((sel3 & a_ext[5]) | (sel4 & m2[5])) ^ neg1;
  assign pp11 = ((sel3 & a_ext[6]) | (sel4 & m2[6])) ^ neg1;
  assign pp12 = ((sel3 & a_ext[7]) | (sel4 & m2[7])) ^ neg1;
  assign pp13 = ((sel3 & a_ext[8]) | (sel4 & m2[8])) ^ neg1;
  assign pp14 = ((sel3 & a_ext[9]) | (sel4 & m2[9])) ^ neg1;
  assign pp15 = ((sel3 & a_ext[10]) | (sel4 & m2[10])) ^ neg1;
  assign pp16 = ((sel3 & a_ext[11]) | (sel4 & m2[11])) ^ neg1;
  assign pp17 = ((sel3 & a_ext[12]) | (sel4 & m2[12])) ^ neg1;
  assign pp18 = ((sel3 & a_ext[13]) | (sel4 & m2[13])) ^ neg1;
  assign pp19 = ((sel3 & a_ext[14]) | (sel4 & m2[14])) ^ neg1;
  assign pp20 = ((sel3 & a_ext[15]) | (sel4 & m2[15])) ^ neg1;
  assign pp21 = ((sel3 & a_ext[16]) | (sel4 & m2[16])) ^ neg1;
  assign pp22 = ((sel3 & a_ext[17]) | (sel4 & m2[17])) ^ neg1;
  assign lo23 = {1'b0, {b[2]}} + {{1{1'b0}}, b[1]};
  assign neg24 = b[3] & ~(b[1] & b[2]);
  assign mg25 = b[3] ? (2'd2 - lo23) : lo23;
  assign sel26 = (mg25 == 2'd1);
  assign sel27 = (mg25 == 2'd2);
  assign pp28 = ((sel26 & a_ext[0]) | (sel27 & m2[0])) ^ neg24;
  assign pp29 = ((sel26 & a_ext[1]) | (sel27 & m2[1])) ^ neg24;
  assign pp30 = ((sel26 & a_ext[2]) | (sel27 & m2[2])) ^ neg24;
  assign pp31 = ((sel26 & a_ext[3]) | (sel27 & m2[3])) ^ neg24;
  assign pp32 = ((sel26 & a_ext[4]) | (sel27 & m2[4])) ^ neg24;
  assign pp33 = ((sel26 & a_ext[5]) | (sel27 & m2[5])) ^ neg24;
  assign pp34 = ((sel26 & a_ext[6]) | (sel27 & m2[6])) ^ neg24;
  assign pp35 = ((sel26 & a_ext[7]) | (sel27 & m2[7])) ^ neg24;
  assign pp36 = ((sel26 & a_ext[8]) | (sel27 & m2[8])) ^ neg24;
  assign pp37 = ((sel26 & a_ext[9]) | (sel27 & m2[9])) ^ neg24;
  assign pp38 = ((sel26 & a_ext[10]) | (sel27 & m2[10])) ^ neg24;
  assign pp39 = ((sel26 & a_ext[11]) | (sel27 & m2[11])) ^ neg24;
  assign pp40 = ((sel26 & a_ext[12]) | (sel27 & m2[12])) ^ neg24;
  assign pp41 = ((sel26 & a_ext[13]) | (sel27 & m2[13])) ^ neg24;
  assign pp42 = ((sel26 & a_ext[14]) | (sel27 & m2[14])) ^ neg24;
  assign pp43 = ((sel26 & a_ext[15]) | (sel27 & m2[15])) ^ neg24;
  assign pp44 = ((sel26 & a_ext[16]) | (sel27 & m2[16])) ^ neg24;
  assign pp45 = ((sel26 & a_ext[17]) | (sel27 & m2[17])) ^ neg24;
  assign lo46 = {1'b0, {b[4]}} + {{1{1'b0}}, b[3]};
  assign neg47 = b[5] & ~(b[3] & b[4]);
  assign mg48 = b[5] ? (2'd2 - lo46) : lo46;
  assign sel49 = (mg48 == 2'd1);
  assign sel50 = (mg48 == 2'd2);
  assign pp51 = ((sel49 & a_ext[0]) | (sel50 & m2[0])) ^ neg47;
  assign pp52 = ((sel49 & a_ext[1]) | (sel50 & m2[1])) ^ neg47;
  assign pp53 = ((sel49 & a_ext[2]) | (sel50 & m2[2])) ^ neg47;
  assign pp54 = ((sel49 & a_ext[3]) | (sel50 & m2[3])) ^ neg47;
  assign pp55 = ((sel49 & a_ext[4]) | (sel50 & m2[4])) ^ neg47;
  assign pp56 = ((sel49 & a_ext[5]) | (sel50 & m2[5])) ^ neg47;
  assign pp57 = ((sel49 & a_ext[6]) | (sel50 & m2[6])) ^ neg47;
  assign pp58 = ((sel49 & a_ext[7]) | (sel50 & m2[7])) ^ neg47;
  assign pp59 = ((sel49 & a_ext[8]) | (sel50 & m2[8])) ^ neg47;
  assign pp60 = ((sel49 & a_ext[9]) | (sel50 & m2[9])) ^ neg47;
  assign pp61 = ((sel49 & a_ext[10]) | (sel50 & m2[10])) ^ neg47;
  assign pp62 = ((sel49 & a_ext[11]) | (sel50 & m2[11])) ^ neg47;
  assign pp63 = ((sel49 & a_ext[12]) | (sel50 & m2[12])) ^ neg47;
  assign pp64 = ((sel49 & a_ext[13]) | (sel50 & m2[13])) ^ neg47;
  assign pp65 = ((sel49 & a_ext[14]) | (sel50 & m2[14])) ^ neg47;
  assign pp66 = ((sel49 & a_ext[15]) | (sel50 & m2[15])) ^ neg47;
  assign pp67 = ((sel49 & a_ext[16]) | (sel50 & m2[16])) ^ neg47;
  assign pp68 = ((sel49 & a_ext[17]) | (sel50 & m2[17])) ^ neg47;
  assign lo69 = {1'b0, {b[6]}} + {{1{1'b0}}, b[5]};
  assign neg70 = b[7] & ~(b[5] & b[6]);
  assign mg71 = b[7] ? (2'd2 - lo69) : lo69;
  assign sel72 = (mg71 == 2'd1);
  assign sel73 = (mg71 == 2'd2);
  assign pp74 = ((sel72 & a_ext[0]) | (sel73 & m2[0])) ^ neg70;
  assign pp75 = ((sel72 & a_ext[1]) | (sel73 & m2[1])) ^ neg70;
  assign pp76 = ((sel72 & a_ext[2]) | (sel73 & m2[2])) ^ neg70;
  assign pp77 = ((sel72 & a_ext[3]) | (sel73 & m2[3])) ^ neg70;
  assign pp78 = ((sel72 & a_ext[4]) | (sel73 & m2[4])) ^ neg70;
  assign pp79 = ((sel72 & a_ext[5]) | (sel73 & m2[5])) ^ neg70;
  assign pp80 = ((sel72 & a_ext[6]) | (sel73 & m2[6])) ^ neg70;
  assign pp81 = ((sel72 & a_ext[7]) | (sel73 & m2[7])) ^ neg70;
  assign pp82 = ((sel72 & a_ext[8]) | (sel73 & m2[8])) ^ neg70;
  assign pp83 = ((sel72 & a_ext[9]) | (sel73 & m2[9])) ^ neg70;
  assign pp84 = ((sel72 & a_ext[10]) | (sel73 & m2[10])) ^ neg70;
  assign pp85 = ((sel72 & a_ext[11]) | (sel73 & m2[11])) ^ neg70;
  assign pp86 = ((sel72 & a_ext[12]) | (sel73 & m2[12])) ^ neg70;
  assign pp87 = ((sel72 & a_ext[13]) | (sel73 & m2[13])) ^ neg70;
  assign pp88 = ((sel72 & a_ext[14]) | (sel73 & m2[14])) ^ neg70;
  assign pp89 = ((sel72 & a_ext[15]) | (sel73 & m2[15])) ^ neg70;
  assign pp90 = ((sel72 & a_ext[16]) | (sel73 & m2[16])) ^ neg70;
  assign pp91 = ((sel72 & a_ext[17]) | (sel73 & m2[17])) ^ neg70;
  assign lo92 = {1'b0, {b[8]}} + {{1{1'b0}}, b[7]};
  assign neg93 = b[9] & ~(b[7] & b[8]);
  assign mg94 = b[9] ? (2'd2 - lo92) : lo92;
  assign sel95 = (mg94 == 2'd1);
  assign sel96 = (mg94 == 2'd2);
  assign pp97 = ((sel95 & a_ext[0]) | (sel96 & m2[0])) ^ neg93;
  assign pp98 = ((sel95 & a_ext[1]) | (sel96 & m2[1])) ^ neg93;
  assign pp99 = ((sel95 & a_ext[2]) | (sel96 & m2[2])) ^ neg93;
  assign pp100 = ((sel95 & a_ext[3]) | (sel96 & m2[3])) ^ neg93;
  assign pp101 = ((sel95 & a_ext[4]) | (sel96 & m2[4])) ^ neg93;
  assign pp102 = ((sel95 & a_ext[5]) | (sel96 & m2[5])) ^ neg93;
  assign pp103 = ((sel95 & a_ext[6]) | (sel96 & m2[6])) ^ neg93;
  assign pp104 = ((sel95 & a_ext[7]) | (sel96 & m2[7])) ^ neg93;
  assign pp105 = ((sel95 & a_ext[8]) | (sel96 & m2[8])) ^ neg93;
  assign pp106 = ((sel95 & a_ext[9]) | (sel96 & m2[9])) ^ neg93;
  assign pp107 = ((sel95 & a_ext[10]) | (sel96 & m2[10])) ^ neg93;
  assign pp108 = ((sel95 & a_ext[11]) | (sel96 & m2[11])) ^ neg93;
  assign pp109 = ((sel95 & a_ext[12]) | (sel96 & m2[12])) ^ neg93;
  assign pp110 = ((sel95 & a_ext[13]) | (sel96 & m2[13])) ^ neg93;
  assign pp111 = ((sel95 & a_ext[14]) | (sel96 & m2[14])) ^ neg93;
  assign pp112 = ((sel95 & a_ext[15]) | (sel96 & m2[15])) ^ neg93;
  assign pp113 = ((sel95 & a_ext[16]) | (sel96 & m2[16])) ^ neg93;
  assign pp114 = ((sel95 & a_ext[17]) | (sel96 & m2[17])) ^ neg93;
  assign lo115 = {1'b0, {b[10]}} + {{1{1'b0}}, b[9]};
  assign neg116 = b[11] & ~(b[9] & b[10]);
  assign mg117 = b[11] ? (2'd2 - lo115) : lo115;
  assign sel118 = (mg117 == 2'd1);
  assign sel119 = (mg117 == 2'd2);
  assign pp120 = ((sel118 & a_ext[0]) | (sel119 & m2[0])) ^ neg116;
  assign pp121 = ((sel118 & a_ext[1]) | (sel119 & m2[1])) ^ neg116;
  assign pp122 = ((sel118 & a_ext[2]) | (sel119 & m2[2])) ^ neg116;
  assign pp123 = ((sel118 & a_ext[3]) | (sel119 & m2[3])) ^ neg116;
  assign pp124 = ((sel118 & a_ext[4]) | (sel119 & m2[4])) ^ neg116;
  assign pp125 = ((sel118 & a_ext[5]) | (sel119 & m2[5])) ^ neg116;
  assign pp126 = ((sel118 & a_ext[6]) | (sel119 & m2[6])) ^ neg116;
  assign pp127 = ((sel118 & a_ext[7]) | (sel119 & m2[7])) ^ neg116;
  assign pp128 = ((sel118 & a_ext[8]) | (sel119 & m2[8])) ^ neg116;
  assign pp129 = ((sel118 & a_ext[9]) | (sel119 & m2[9])) ^ neg116;
  assign pp130 = ((sel118 & a_ext[10]) | (sel119 & m2[10])) ^ neg116;
  assign pp131 = ((sel118 & a_ext[11]) | (sel119 & m2[11])) ^ neg116;
  assign pp132 = ((sel118 & a_ext[12]) | (sel119 & m2[12])) ^ neg116;
  assign pp133 = ((sel118 & a_ext[13]) | (sel119 & m2[13])) ^ neg116;
  assign pp134 = ((sel118 & a_ext[14]) | (sel119 & m2[14])) ^ neg116;
  assign pp135 = ((sel118 & a_ext[15]) | (sel119 & m2[15])) ^ neg116;
  assign pp136 = ((sel118 & a_ext[16]) | (sel119 & m2[16])) ^ neg116;
  assign pp137 = ((sel118 & a_ext[17]) | (sel119 & m2[17])) ^ neg116;
  assign lo138 = {1'b0, {b[12]}} + {{1{1'b0}}, b[11]};
  assign neg139 = b[13] & ~(b[11] & b[12]);
  assign mg140 = b[13] ? (2'd2 - lo138) : lo138;
  assign sel141 = (mg140 == 2'd1);
  assign sel142 = (mg140 == 2'd2);
  assign pp143 = ((sel141 & a_ext[0]) | (sel142 & m2[0])) ^ neg139;
  assign pp144 = ((sel141 & a_ext[1]) | (sel142 & m2[1])) ^ neg139;
  assign pp145 = ((sel141 & a_ext[2]) | (sel142 & m2[2])) ^ neg139;
  assign pp146 = ((sel141 & a_ext[3]) | (sel142 & m2[3])) ^ neg139;
  assign pp147 = ((sel141 & a_ext[4]) | (sel142 & m2[4])) ^ neg139;
  assign pp148 = ((sel141 & a_ext[5]) | (sel142 & m2[5])) ^ neg139;
  assign pp149 = ((sel141 & a_ext[6]) | (sel142 & m2[6])) ^ neg139;
  assign pp150 = ((sel141 & a_ext[7]) | (sel142 & m2[7])) ^ neg139;
  assign pp151 = ((sel141 & a_ext[8]) | (sel142 & m2[8])) ^ neg139;
  assign pp152 = ((sel141 & a_ext[9]) | (sel142 & m2[9])) ^ neg139;
  assign pp153 = ((sel141 & a_ext[10]) | (sel142 & m2[10])) ^ neg139;
  assign pp154 = ((sel141 & a_ext[11]) | (sel142 & m2[11])) ^ neg139;
  assign pp155 = ((sel141 & a_ext[12]) | (sel142 & m2[12])) ^ neg139;
  assign pp156 = ((sel141 & a_ext[13]) | (sel142 & m2[13])) ^ neg139;
  assign pp157 = ((sel141 & a_ext[14]) | (sel142 & m2[14])) ^ neg139;
  assign pp158 = ((sel141 & a_ext[15]) | (sel142 & m2[15])) ^ neg139;
  assign pp159 = ((sel141 & a_ext[16]) | (sel142 & m2[16])) ^ neg139;
  assign pp160 = ((sel141 & a_ext[17]) | (sel142 & m2[17])) ^ neg139;
  assign lo161 = {1'b0, {b[14]}} + {{1{1'b0}}, b[13]};
  assign neg162 = b[15] & ~(b[13] & b[14]);
  assign mg163 = b[15] ? (2'd2 - lo161) : lo161;
  assign sel164 = (mg163 == 2'd1);
  assign sel165 = (mg163 == 2'd2);
  assign pp166 = ((sel164 & a_ext[0]) | (sel165 & m2[0])) ^ neg162;
  assign pp167 = ((sel164 & a_ext[1]) | (sel165 & m2[1])) ^ neg162;
  assign pp168 = ((sel164 & a_ext[2]) | (sel165 & m2[2])) ^ neg162;
  assign pp169 = ((sel164 & a_ext[3]) | (sel165 & m2[3])) ^ neg162;
  assign pp170 = ((sel164 & a_ext[4]) | (sel165 & m2[4])) ^ neg162;
  assign pp171 = ((sel164 & a_ext[5]) | (sel165 & m2[5])) ^ neg162;
  assign pp172 = ((sel164 & a_ext[6]) | (sel165 & m2[6])) ^ neg162;
  assign pp173 = ((sel164 & a_ext[7]) | (sel165 & m2[7])) ^ neg162;
  assign pp174 = ((sel164 & a_ext[8]) | (sel165 & m2[8])) ^ neg162;
  assign pp175 = ((sel164 & a_ext[9]) | (sel165 & m2[9])) ^ neg162;
  assign pp176 = ((sel164 & a_ext[10]) | (sel165 & m2[10])) ^ neg162;
  assign pp177 = ((sel164 & a_ext[11]) | (sel165 & m2[11])) ^ neg162;
  assign pp178 = ((sel164 & a_ext[12]) | (sel165 & m2[12])) ^ neg162;
  assign pp179 = ((sel164 & a_ext[13]) | (sel165 & m2[13])) ^ neg162;
  assign pp180 = ((sel164 & a_ext[14]) | (sel165 & m2[14])) ^ neg162;
  assign pp181 = ((sel164 & a_ext[15]) | (sel165 & m2[15])) ^ neg162;
  assign pp182 = ((sel164 & a_ext[16]) | (sel165 & m2[16])) ^ neg162;
  assign pp183 = ((sel164 & a_ext[17]) | (sel165 & m2[17])) ^ neg162;
  assign ns184 = ~pp22;
  assign ns185 = ~pp45;
  assign ns186 = ~pp68;
  assign ns187 = ~pp91;
  assign ns188 = ~pp114;
  assign ns189 = ~pp137;
  assign ns190 = ~pp160;
  assign ns191 = ~pp183;
  assign rb192 = pp5;
  assign rb193 = 1'b0;
  assign rb194 = neg1;
  assign rb195 = 1'b0;
  assign rb196 = rb192 & rb194;
  assign rb197 = rb193 & rb195;
  assign rb198 = (rb192 & ~rb194 & ~rb195) | (rb194 & ~rb192 & ~rb193);
  assign rb199 = (rb193 & ~rb194 & ~rb195) | (rb195 & ~rb192 & ~rb193);
  assign rb200 = rb196 | (rb198 & ~1'b0);
  assign rb201 = rb197 | (rb199 & 1'b0);
  assign rb202 = (rb198 | rb199) & 1'b0;
  assign rb203 = (rb198 | rb199) & ~1'b0;
  assign rb204 = pp6;
  assign rb205 = 1'b0;
  assign rb206 = 1'b0;
  assign rb207 = 1'b0;
  assign rb208 = 1'b0 | 1'b0;
  assign rb209 = rb204 & rb206;
  assign rb210 = rb205 & rb207;
  assign rb211 = (rb204 & ~rb206 & ~rb207) | (rb206 & ~rb204 & ~rb205);
  assign rb212 = (rb205 & ~rb206 & ~rb207) | (rb207 & ~rb204 & ~rb205);
  assign rb213 = rb209 | (rb211 & ~rb208);
  assign rb214 = rb210 | (rb212 & rb208);
  assign rb215 = (rb211 | rb212) & rb208;
  assign rb216 = (rb211 | rb212) & ~rb208;
  assign rb217 = pp7;
  assign rb218 = 1'b0;
  assign rb219 = pp28;
  assign rb220 = 1'b0;
  assign rb221 = 1'b0 | 1'b0;
  assign rb222 = rb217 & rb219;
  assign rb223 = rb218 & rb220;
  assign rb224 = (rb217 & ~rb219 & ~rb220) | (rb219 & ~rb217 & ~rb218);
  assign rb225 = (rb218 & ~rb219 & ~rb220) | (rb220 & ~rb217 & ~rb218);
  assign rb226 = rb222 | (rb224 & ~rb221);
  assign rb227 = rb223 | (rb225 & rb221);
  assign rb228 = (rb224 | rb225) & rb221;
  assign rb229 = (rb224 | rb225) & ~rb221;
  assign rb230 = pp8;
  assign rb231 = 1'b0;
  assign rb232 = pp29;
  assign rb233 = 1'b0;
  assign rb234 = 1'b0 | 1'b0;
  assign rb235 = rb230 & rb232;
  assign rb236 = rb231 & rb233;
  assign rb237 = (rb230 & ~rb232 & ~rb233) | (rb232 & ~rb230 & ~rb231);
  assign rb238 = (rb231 & ~rb232 & ~rb233) | (rb233 & ~rb230 & ~rb231);
  assign rb239 = rb235 | (rb237 & ~rb234);
  assign rb240 = rb236 | (rb238 & rb234);
  assign rb241 = (rb237 | rb238) & rb234;
  assign rb242 = (rb237 | rb238) & ~rb234;
  assign rb243 = pp9;
  assign rb244 = 1'b0;
  assign rb245 = pp30;
  assign rb246 = 1'b0;
  assign rb247 = 1'b0 | 1'b0;
  assign rb248 = rb243 & rb245;
  assign rb249 = rb244 & rb246;
  assign rb250 = (rb243 & ~rb245 & ~rb246) | (rb245 & ~rb243 & ~rb244);
  assign rb251 = (rb244 & ~rb245 & ~rb246) | (rb246 & ~rb243 & ~rb244);
  assign rb252 = rb248 | (rb250 & ~rb247);
  assign rb253 = rb249 | (rb251 & rb247);
  assign rb254 = (rb250 | rb251) & rb247;
  assign rb255 = (rb250 | rb251) & ~rb247;
  assign rb256 = pp10;
  assign rb257 = 1'b0;
  assign rb258 = pp31;
  assign rb259 = 1'b0;
  assign rb260 = 1'b0 | 1'b0;
  assign rb261 = rb256 & rb258;
  assign rb262 = rb257 & rb259;
  assign rb263 = (rb256 & ~rb258 & ~rb259) | (rb258 & ~rb256 & ~rb257);
  assign rb264 = (rb257 & ~rb258 & ~rb259) | (rb259 & ~rb256 & ~rb257);
  assign rb265 = rb261 | (rb263 & ~rb260);
  assign rb266 = rb262 | (rb264 & rb260);
  assign rb267 = (rb263 | rb264) & rb260;
  assign rb268 = (rb263 | rb264) & ~rb260;
  assign rb269 = pp11;
  assign rb270 = 1'b0;
  assign rb271 = pp32;
  assign rb272 = 1'b0;
  assign rb273 = 1'b0 | 1'b0;
  assign rb274 = rb269 & rb271;
  assign rb275 = rb270 & rb272;
  assign rb276 = (rb269 & ~rb271 & ~rb272) | (rb271 & ~rb269 & ~rb270);
  assign rb277 = (rb270 & ~rb271 & ~rb272) | (rb272 & ~rb269 & ~rb270);
  assign rb278 = rb274 | (rb276 & ~rb273);
  assign rb279 = rb275 | (rb277 & rb273);
  assign rb280 = (rb276 | rb277) & rb273;
  assign rb281 = (rb276 | rb277) & ~rb273;
  assign rb282 = pp12;
  assign rb283 = 1'b0;
  assign rb284 = pp33;
  assign rb285 = 1'b0;
  assign rb286 = 1'b0 | 1'b0;
  assign rb287 = rb282 & rb284;
  assign rb288 = rb283 & rb285;
  assign rb289 = (rb282 & ~rb284 & ~rb285) | (rb284 & ~rb282 & ~rb283);
  assign rb290 = (rb283 & ~rb284 & ~rb285) | (rb285 & ~rb282 & ~rb283);
  assign rb291 = rb287 | (rb289 & ~rb286);
  assign rb292 = rb288 | (rb290 & rb286);
  assign rb293 = (rb289 | rb290) & rb286;
  assign rb294 = (rb289 | rb290) & ~rb286;
  assign rb295 = pp13;
  assign rb296 = 1'b0;
  assign rb297 = pp34;
  assign rb298 = 1'b0;
  assign rb299 = 1'b0 | 1'b0;
  assign rb300 = rb295 & rb297;
  assign rb301 = rb296 & rb298;
  assign rb302 = (rb295 & ~rb297 & ~rb298) | (rb297 & ~rb295 & ~rb296);
  assign rb303 = (rb296 & ~rb297 & ~rb298) | (rb298 & ~rb295 & ~rb296);
  assign rb304 = rb300 | (rb302 & ~rb299);
  assign rb305 = rb301 | (rb303 & rb299);
  assign rb306 = (rb302 | rb303) & rb299;
  assign rb307 = (rb302 | rb303) & ~rb299;
  assign rb308 = pp14;
  assign rb309 = 1'b0;
  assign rb310 = pp35;
  assign rb311 = 1'b0;
  assign rb312 = 1'b0 | 1'b0;
  assign rb313 = rb308 & rb310;
  assign rb314 = rb309 & rb311;
  assign rb315 = (rb308 & ~rb310 & ~rb311) | (rb310 & ~rb308 & ~rb309);
  assign rb316 = (rb309 & ~rb310 & ~rb311) | (rb311 & ~rb308 & ~rb309);
  assign rb317 = rb313 | (rb315 & ~rb312);
  assign rb318 = rb314 | (rb316 & rb312);
  assign rb319 = (rb315 | rb316) & rb312;
  assign rb320 = (rb315 | rb316) & ~rb312;
  assign rb321 = pp15;
  assign rb322 = 1'b0;
  assign rb323 = pp36;
  assign rb324 = 1'b0;
  assign rb325 = 1'b0 | 1'b0;
  assign rb326 = rb321 & rb323;
  assign rb327 = rb322 & rb324;
  assign rb328 = (rb321 & ~rb323 & ~rb324) | (rb323 & ~rb321 & ~rb322);
  assign rb329 = (rb322 & ~rb323 & ~rb324) | (rb324 & ~rb321 & ~rb322);
  assign rb330 = rb326 | (rb328 & ~rb325);
  assign rb331 = rb327 | (rb329 & rb325);
  assign rb332 = (rb328 | rb329) & rb325;
  assign rb333 = (rb328 | rb329) & ~rb325;
  assign rb334 = pp16;
  assign rb335 = 1'b0;
  assign rb336 = pp37;
  assign rb337 = 1'b0;
  assign rb338 = 1'b0 | 1'b0;
  assign rb339 = rb334 & rb336;
  assign rb340 = rb335 & rb337;
  assign rb341 = (rb334 & ~rb336 & ~rb337) | (rb336 & ~rb334 & ~rb335);
  assign rb342 = (rb335 & ~rb336 & ~rb337) | (rb337 & ~rb334 & ~rb335);
  assign rb343 = rb339 | (rb341 & ~rb338);
  assign rb344 = rb340 | (rb342 & rb338);
  assign rb345 = (rb341 | rb342) & rb338;
  assign rb346 = (rb341 | rb342) & ~rb338;
  assign rb347 = pp17;
  assign rb348 = 1'b0;
  assign rb349 = pp38;
  assign rb350 = 1'b0;
  assign rb351 = 1'b0 | 1'b0;
  assign rb352 = rb347 & rb349;
  assign rb353 = rb348 & rb350;
  assign rb354 = (rb347 & ~rb349 & ~rb350) | (rb349 & ~rb347 & ~rb348);
  assign rb355 = (rb348 & ~rb349 & ~rb350) | (rb350 & ~rb347 & ~rb348);
  assign rb356 = rb352 | (rb354 & ~rb351);
  assign rb357 = rb353 | (rb355 & rb351);
  assign rb358 = (rb354 | rb355) & rb351;
  assign rb359 = (rb354 | rb355) & ~rb351;
  assign rb360 = pp18;
  assign rb361 = 1'b0;
  assign rb362 = pp39;
  assign rb363 = 1'b0;
  assign rb364 = 1'b0 | 1'b0;
  assign rb365 = rb360 & rb362;
  assign rb366 = rb361 & rb363;
  assign rb367 = (rb360 & ~rb362 & ~rb363) | (rb362 & ~rb360 & ~rb361);
  assign rb368 = (rb361 & ~rb362 & ~rb363) | (rb363 & ~rb360 & ~rb361);
  assign rb369 = rb365 | (rb367 & ~rb364);
  assign rb370 = rb366 | (rb368 & rb364);
  assign rb371 = (rb367 | rb368) & rb364;
  assign rb372 = (rb367 | rb368) & ~rb364;
  assign rb373 = pp19;
  assign rb374 = 1'b0;
  assign rb375 = pp40;
  assign rb376 = 1'b0;
  assign rb377 = 1'b0 | 1'b0;
  assign rb378 = rb373 & rb375;
  assign rb379 = rb374 & rb376;
  assign rb380 = (rb373 & ~rb375 & ~rb376) | (rb375 & ~rb373 & ~rb374);
  assign rb381 = (rb374 & ~rb375 & ~rb376) | (rb376 & ~rb373 & ~rb374);
  assign rb382 = rb378 | (rb380 & ~rb377);
  assign rb383 = rb379 | (rb381 & rb377);
  assign rb384 = (rb380 | rb381) & rb377;
  assign rb385 = (rb380 | rb381) & ~rb377;
  assign rb386 = pp20;
  assign rb387 = 1'b0;
  assign rb388 = pp41;
  assign rb389 = 1'b0;
  assign rb390 = 1'b0 | 1'b0;
  assign rb391 = rb386 & rb388;
  assign rb392 = rb387 & rb389;
  assign rb393 = (rb386 & ~rb388 & ~rb389) | (rb388 & ~rb386 & ~rb387);
  assign rb394 = (rb387 & ~rb388 & ~rb389) | (rb389 & ~rb386 & ~rb387);
  assign rb395 = rb391 | (rb393 & ~rb390);
  assign rb396 = rb392 | (rb394 & rb390);
  assign rb397 = (rb393 | rb394) & rb390;
  assign rb398 = (rb393 | rb394) & ~rb390;
  assign rb399 = pp21;
  assign rb400 = 1'b0;
  assign rb401 = pp42;
  assign rb402 = 1'b0;
  assign rb403 = 1'b0 | 1'b0;
  assign rb404 = rb399 & rb401;
  assign rb405 = rb400 & rb402;
  assign rb406 = (rb399 & ~rb401 & ~rb402) | (rb401 & ~rb399 & ~rb400);
  assign rb407 = (rb400 & ~rb401 & ~rb402) | (rb402 & ~rb399 & ~rb400);
  assign rb408 = rb404 | (rb406 & ~rb403);
  assign rb409 = rb405 | (rb407 & rb403);
  assign rb410 = (rb406 | rb407) & rb403;
  assign rb411 = (rb406 | rb407) & ~rb403;
  assign rb412 = ns184;
  assign rb413 = 1'b0;
  assign rb414 = pp43;
  assign rb415 = 1'b0;
  assign rb416 = 1'b0 | 1'b0;
  assign rb417 = rb412 & rb414;
  assign rb418 = rb413 & rb415;
  assign rb419 = (rb412 & ~rb414 & ~rb415) | (rb414 & ~rb412 & ~rb413);
  assign rb420 = (rb413 & ~rb414 & ~rb415) | (rb415 & ~rb412 & ~rb413);
  assign rb421 = rb417 | (rb419 & ~rb416);
  assign rb422 = rb418 | (rb420 & rb416);
  assign rb423 = (rb419 | rb420) & rb416;
  assign rb424 = (rb419 | rb420) & ~rb416;
  assign rb425 = pp44;
  assign rb426 = 1'b0;
  assign rb427 = pp65;
  assign rb428 = 1'b0;
  assign rb429 = 1'b0 | 1'b0;
  assign rb430 = rb425 & rb427;
  assign rb431 = rb426 & rb428;
  assign rb432 = (rb425 & ~rb427 & ~rb428) | (rb427 & ~rb425 & ~rb426);
  assign rb433 = (rb426 & ~rb427 & ~rb428) | (rb428 & ~rb425 & ~rb426);
  assign rb434 = rb430 | (rb432 & ~rb429);
  assign rb435 = rb431 | (rb433 & rb429);
  assign rb436 = (rb432 | rb433) & rb429;
  assign rb437 = (rb432 | rb433) & ~rb429;
  assign rb438 = ns185;
  assign rb439 = 1'b0;
  assign rb440 = pp66;
  assign rb441 = 1'b0;
  assign rb442 = 1'b0 | 1'b0;
  assign rb443 = rb438 & rb440;
  assign rb444 = rb439 & rb441;
  assign rb445 = (rb438 & ~rb440 & ~rb441) | (rb440 & ~rb438 & ~rb439);
  assign rb446 = (rb439 & ~rb440 & ~rb441) | (rb441 & ~rb438 & ~rb439);
  assign rb447 = rb443 | (rb445 & ~rb442);
  assign rb448 = rb444 | (rb446 & rb442);
  assign rb449 = (rb445 | rb446) & rb442;
  assign rb450 = (rb445 | rb446) & ~rb442;
  assign rb451 = pp67;
  assign rb452 = 1'b0;
  assign rb453 = pp88;
  assign rb454 = 1'b0;
  assign rb455 = 1'b0 | 1'b0;
  assign rb456 = rb451 & rb453;
  assign rb457 = rb452 & rb454;
  assign rb458 = (rb451 & ~rb453 & ~rb454) | (rb453 & ~rb451 & ~rb452);
  assign rb459 = (rb452 & ~rb453 & ~rb454) | (rb454 & ~rb451 & ~rb452);
  assign rb460 = rb456 | (rb458 & ~rb455);
  assign rb461 = rb457 | (rb459 & rb455);
  assign rb462 = (rb458 | rb459) & rb455;
  assign rb463 = (rb458 | rb459) & ~rb455;
  assign rb464 = ns186;
  assign rb465 = 1'b0;
  assign rb466 = pp89;
  assign rb467 = 1'b0;
  assign rb468 = 1'b0 | 1'b0;
  assign rb469 = rb464 & rb466;
  assign rb470 = rb465 & rb467;
  assign rb471 = (rb464 & ~rb466 & ~rb467) | (rb466 & ~rb464 & ~rb465);
  assign rb472 = (rb465 & ~rb466 & ~rb467) | (rb467 & ~rb464 & ~rb465);
  assign rb473 = rb469 | (rb471 & ~rb468);
  assign rb474 = rb470 | (rb472 & rb468);
  assign rb475 = (rb471 | rb472) & rb468;
  assign rb476 = (rb471 | rb472) & ~rb468;
  assign rb477 = pp90;
  assign rb478 = 1'b0;
  assign rb479 = pp111;
  assign rb480 = 1'b0;
  assign rb481 = 1'b0 | 1'b0;
  assign rb482 = rb477 & rb479;
  assign rb483 = rb478 & rb480;
  assign rb484 = (rb477 & ~rb479 & ~rb480) | (rb479 & ~rb477 & ~rb478);
  assign rb485 = (rb478 & ~rb479 & ~rb480) | (rb480 & ~rb477 & ~rb478);
  assign rb486 = rb482 | (rb484 & ~rb481);
  assign rb487 = rb483 | (rb485 & rb481);
  assign rb488 = (rb484 | rb485) & rb481;
  assign rb489 = (rb484 | rb485) & ~rb481;
  assign rb490 = ns187;
  assign rb491 = 1'b0;
  assign rb492 = pp112;
  assign rb493 = 1'b0;
  assign rb494 = 1'b0 | 1'b0;
  assign rb495 = rb490 & rb492;
  assign rb496 = rb491 & rb493;
  assign rb497 = (rb490 & ~rb492 & ~rb493) | (rb492 & ~rb490 & ~rb491);
  assign rb498 = (rb491 & ~rb492 & ~rb493) | (rb493 & ~rb490 & ~rb491);
  assign rb499 = rb495 | (rb497 & ~rb494);
  assign rb500 = rb496 | (rb498 & rb494);
  assign rb501 = (rb497 | rb498) & rb494;
  assign rb502 = (rb497 | rb498) & ~rb494;
  assign rb503 = pp113;
  assign rb504 = 1'b0;
  assign rb505 = pp134;
  assign rb506 = 1'b0;
  assign rb507 = 1'b0 | 1'b0;
  assign rb508 = rb503 & rb505;
  assign rb509 = rb504 & rb506;
  assign rb510 = (rb503 & ~rb505 & ~rb506) | (rb505 & ~rb503 & ~rb504);
  assign rb511 = (rb504 & ~rb505 & ~rb506) | (rb506 & ~rb503 & ~rb504);
  assign rb512 = rb508 | (rb510 & ~rb507);
  assign rb513 = rb509 | (rb511 & rb507);
  assign rb514 = (rb510 | rb511) & rb507;
  assign rb515 = (rb510 | rb511) & ~rb507;
  assign rb516 = ns188;
  assign rb517 = 1'b0;
  assign rb518 = pp135;
  assign rb519 = 1'b0;
  assign rb520 = 1'b0 | 1'b0;
  assign rb521 = rb516 & rb518;
  assign rb522 = rb517 & rb519;
  assign rb523 = (rb516 & ~rb518 & ~rb519) | (rb518 & ~rb516 & ~rb517);
  assign rb524 = (rb517 & ~rb518 & ~rb519) | (rb519 & ~rb516 & ~rb517);
  assign rb525 = rb521 | (rb523 & ~rb520);
  assign rb526 = rb522 | (rb524 & rb520);
  assign rb527 = (rb523 | rb524) & rb520;
  assign rb528 = (rb523 | rb524) & ~rb520;
  assign rb529 = pp136;
  assign rb530 = 1'b0;
  assign rb531 = pp157;
  assign rb532 = 1'b0;
  assign rb533 = 1'b0 | 1'b0;
  assign rb534 = rb529 & rb531;
  assign rb535 = rb530 & rb532;
  assign rb536 = (rb529 & ~rb531 & ~rb532) | (rb531 & ~rb529 & ~rb530);
  assign rb537 = (rb530 & ~rb531 & ~rb532) | (rb532 & ~rb529 & ~rb530);
  assign rb538 = rb534 | (rb536 & ~rb533);
  assign rb539 = rb535 | (rb537 & rb533);
  assign rb540 = (rb536 | rb537) & rb533;
  assign rb541 = (rb536 | rb537) & ~rb533;
  assign rb542 = ns189;
  assign rb543 = 1'b0;
  assign rb544 = pp158;
  assign rb545 = 1'b0;
  assign rb546 = 1'b0 | 1'b0;
  assign rb547 = rb542 & rb544;
  assign rb548 = rb543 & rb545;
  assign rb549 = (rb542 & ~rb544 & ~rb545) | (rb544 & ~rb542 & ~rb543);
  assign rb550 = (rb543 & ~rb544 & ~rb545) | (rb545 & ~rb542 & ~rb543);
  assign rb551 = rb547 | (rb549 & ~rb546);
  assign rb552 = rb548 | (rb550 & rb546);
  assign rb553 = (rb549 | rb550) & rb546;
  assign rb554 = (rb549 | rb550) & ~rb546;
  assign rb555 = pp159;
  assign rb556 = 1'b0;
  assign rb557 = pp180;
  assign rb558 = 1'b0;
  assign rb559 = 1'b0 | 1'b0;
  assign rb560 = rb555 & rb557;
  assign rb561 = rb556 & rb558;
  assign rb562 = (rb555 & ~rb557 & ~rb558) | (rb557 & ~rb555 & ~rb556);
  assign rb563 = (rb556 & ~rb557 & ~rb558) | (rb558 & ~rb555 & ~rb556);
  assign rb564 = rb560 | (rb562 & ~rb559);
  assign rb565 = rb561 | (rb563 & rb559);
  assign rb566 = (rb562 | rb563) & rb559;
  assign rb567 = (rb562 | rb563) & ~rb559;
  assign rb568 = ns190;
  assign rb569 = 1'b0;
  assign rb570 = pp181;
  assign rb571 = 1'b0;
  assign rb572 = 1'b0 | 1'b0;
  assign rb573 = rb568 & rb570;
  assign rb574 = rb569 & rb571;
  assign rb575 = (rb568 & ~rb570 & ~rb571) | (rb570 & ~rb568 & ~rb569);
  assign rb576 = (rb569 & ~rb570 & ~rb571) | (rb571 & ~rb568 & ~rb569);
  assign rb577 = rb573 | (rb575 & ~rb572);
  assign rb578 = rb574 | (rb576 & rb572);
  assign rb579 = (rb575 | rb576) & rb572;
  assign rb580 = (rb575 | rb576) & ~rb572;
  assign rb581 = pp182;
  assign rb582 = 1'b0;
  assign rb583 = 1'b1;
  assign rb584 = 1'b0;
  assign rb585 = 1'b0 | 1'b0;
  assign rb586 = rb581 & rb583;
  assign rb587 = rb582 & rb584;
  assign rb588 = (rb581 & ~rb583 & ~rb584) | (rb583 & ~rb581 & ~rb582);
  assign rb589 = (rb582 & ~rb583 & ~rb584) | (rb584 & ~rb581 & ~rb582);
  assign rb590 = rb586 | (rb588 & ~rb585);
  assign rb591 = rb587 | (rb589 & rb585);
  assign rb592 = (rb588 | rb589) & rb585;
  assign rb593 = (rb588 | rb589) & ~rb585;
  assign rb594 = ns191;
  assign rb595 = 1'b0;
  assign rb596 = 1'b0;
  assign rb597 = 1'b0;
  assign rb598 = 1'b0 | 1'b0;
  assign rb599 = rb594 & rb596;
  assign rb600 = rb595 & rb597;
  assign rb601 = (rb594 & ~rb596 & ~rb597) | (rb596 & ~rb594 & ~rb595);
  assign rb602 = (rb595 & ~rb596 & ~rb597) | (rb597 & ~rb594 & ~rb595);
  assign rb603 = rb599 | (rb601 & ~rb598);
  assign rb604 = rb600 | (rb602 & rb598);
  assign rb605 = (rb601 | rb602) & rb598;
  assign rb606 = (rb601 | rb602) & ~rb598;
  assign rb607 = 1'b0;
  assign rb608 = 1'b0;
  assign rb609 = 1'b0;
  assign rb610 = 1'b0;
  assign rb611 = 1'b0 | 1'b0;
  assign rb612 = rb607 & rb609;
  assign rb613 = rb608 & rb610;
  assign rb614 = (rb607 & ~rb609 & ~rb610) | (rb609 & ~rb607 & ~rb608);
  assign rb615 = (rb608 & ~rb609 & ~rb610) | (rb610 & ~rb607 & ~rb608);
  assign rb616 = rb612 | (rb614 & ~rb611);
  assign rb617 = rb613 | (rb615 & rb611);
  assign rb618 = (rb614 | rb615) & rb611;
  assign rb619 = (rb614 | rb615) & ~rb611;
  assign rb620 = 1'b0;
  assign rb621 = 1'b0;
  assign rb622 = 1'b0;
  assign rb623 = 1'b0;
  assign rb624 = 1'b0 | 1'b0;
  assign rb625 = rb620 & rb622;
  assign rb626 = rb621 & rb623;
  assign rb627 = (rb620 & ~rb622 & ~rb623) | (rb622 & ~rb620 & ~rb621);
  assign rb628 = (rb621 & ~rb622 & ~rb623) | (rb623 & ~rb620 & ~rb621);
  assign rb629 = rb625 | (rb627 & ~rb624);
  assign rb630 = rb626 | (rb628 & rb624);
  assign rb631 = (rb627 | rb628) & rb624;
  assign rb632 = (rb627 | rb628) & ~rb624;
  assign rb633 = (rb202 & ~1'b0) | (1'b0 & ~rb203);
  assign rb634 = (rb203 & ~1'b0) | (1'b0 & ~rb202);
  assign rb635 = (rb215 & ~rb201) | (rb200 & ~rb216);
  assign rb636 = (rb216 & ~rb200) | (rb201 & ~rb215);
  assign rb637 = (rb228 & ~rb214) | (rb213 & ~rb229);
  assign rb638 = (rb229 & ~rb213) | (rb214 & ~rb228);
  assign rb639 = (rb241 & ~rb227) | (rb226 & ~rb242);
  assign rb640 = (rb242 & ~rb226) | (rb227 & ~rb241);
  assign rb641 = (rb254 & ~rb240) | (rb239 & ~rb255);
  assign rb642 = (rb255 & ~rb239) | (rb240 & ~rb254);
  assign rb643 = (rb267 & ~rb253) | (rb252 & ~rb268);
  assign rb644 = (rb268 & ~rb252) | (rb253 & ~rb267);
  assign rb645 = (rb280 & ~rb266) | (rb265 & ~rb281);
  assign rb646 = (rb281 & ~rb265) | (rb266 & ~rb280);
  assign rb647 = (rb293 & ~rb279) | (rb278 & ~rb294);
  assign rb648 = (rb294 & ~rb278) | (rb279 & ~rb293);
  assign rb649 = (rb306 & ~rb292) | (rb291 & ~rb307);
  assign rb650 = (rb307 & ~rb291) | (rb292 & ~rb306);
  assign rb651 = (rb319 & ~rb305) | (rb304 & ~rb320);
  assign rb652 = (rb320 & ~rb304) | (rb305 & ~rb319);
  assign rb653 = (rb332 & ~rb318) | (rb317 & ~rb333);
  assign rb654 = (rb333 & ~rb317) | (rb318 & ~rb332);
  assign rb655 = (rb345 & ~rb331) | (rb330 & ~rb346);
  assign rb656 = (rb346 & ~rb330) | (rb331 & ~rb345);
  assign rb657 = (rb358 & ~rb344) | (rb343 & ~rb359);
  assign rb658 = (rb359 & ~rb343) | (rb344 & ~rb358);
  assign rb659 = (rb371 & ~rb357) | (rb356 & ~rb372);
  assign rb660 = (rb372 & ~rb356) | (rb357 & ~rb371);
  assign rb661 = (rb384 & ~rb370) | (rb369 & ~rb385);
  assign rb662 = (rb385 & ~rb369) | (rb370 & ~rb384);
  assign rb663 = (rb397 & ~rb383) | (rb382 & ~rb398);
  assign rb664 = (rb398 & ~rb382) | (rb383 & ~rb397);
  assign rb665 = (rb410 & ~rb396) | (rb395 & ~rb411);
  assign rb666 = (rb411 & ~rb395) | (rb396 & ~rb410);
  assign rb667 = (rb423 & ~rb409) | (rb408 & ~rb424);
  assign rb668 = (rb424 & ~rb408) | (rb409 & ~rb423);
  assign rb669 = (rb436 & ~rb422) | (rb421 & ~rb437);
  assign rb670 = (rb437 & ~rb421) | (rb422 & ~rb436);
  assign rb671 = (rb449 & ~rb435) | (rb434 & ~rb450);
  assign rb672 = (rb450 & ~rb434) | (rb435 & ~rb449);
  assign rb673 = (rb462 & ~rb448) | (rb447 & ~rb463);
  assign rb674 = (rb463 & ~rb447) | (rb448 & ~rb462);
  assign rb675 = (rb475 & ~rb461) | (rb460 & ~rb476);
  assign rb676 = (rb476 & ~rb460) | (rb461 & ~rb475);
  assign rb677 = (rb488 & ~rb474) | (rb473 & ~rb489);
  assign rb678 = (rb489 & ~rb473) | (rb474 & ~rb488);
  assign rb679 = (rb501 & ~rb487) | (rb486 & ~rb502);
  assign rb680 = (rb502 & ~rb486) | (rb487 & ~rb501);
  assign rb681 = (rb514 & ~rb500) | (rb499 & ~rb515);
  assign rb682 = (rb515 & ~rb499) | (rb500 & ~rb514);
  assign rb683 = (rb527 & ~rb513) | (rb512 & ~rb528);
  assign rb684 = (rb528 & ~rb512) | (rb513 & ~rb527);
  assign rb685 = (rb540 & ~rb526) | (rb525 & ~rb541);
  assign rb686 = (rb541 & ~rb525) | (rb526 & ~rb540);
  assign rb687 = (rb553 & ~rb539) | (rb538 & ~rb554);
  assign rb688 = (rb554 & ~rb538) | (rb539 & ~rb553);
  assign rb689 = (rb566 & ~rb552) | (rb551 & ~rb567);
  assign rb690 = (rb567 & ~rb551) | (rb552 & ~rb566);
  assign rb691 = (rb579 & ~rb565) | (rb564 & ~rb580);
  assign rb692 = (rb580 & ~rb564) | (rb565 & ~rb579);
  assign rb693 = (rb592 & ~rb578) | (rb577 & ~rb593);
  assign rb694 = (rb593 & ~rb577) | (rb578 & ~rb592);
  assign rb695 = (rb605 & ~rb591) | (rb590 & ~rb606);
  assign rb696 = (rb606 & ~rb590) | (rb591 & ~rb605);
  assign rb697 = (rb618 & ~rb604) | (rb603 & ~rb619);
  assign rb698 = (rb619 & ~rb603) | (rb604 & ~rb618);
  assign rb699 = (rb631 & ~rb617) | (rb616 & ~rb632);
  assign rb700 = (rb632 & ~rb616) | (rb617 & ~rb631);
  assign rb701 = (1'b0 & ~rb630) | (rb629 & ~1'b0);
  assign rb702 = (1'b0 & ~rb629) | (rb630 & ~1'b0);
  assign rb703 = 1'b0;
  assign rb704 = 1'b0;
  assign rb705 = 1'b0;
  assign rb706 = 1'b0;
  assign rb707 = rb703 & rb705;
  assign rb708 = rb704 & rb706;
  assign rb709 = (rb703 & ~rb705 & ~rb706) | (rb705 & ~rb703 & ~rb704);
  assign rb710 = (rb704 & ~rb705 & ~rb706) | (rb706 & ~rb703 & ~rb704);
  assign rb711 = rb707 | (rb709 & ~1'b0);
  assign rb712 = rb708 | (rb710 & 1'b0);
  assign rb713 = (rb709 | rb710) & 1'b0;
  assign rb714 = (rb709 | rb710) & ~1'b0;
  assign rb715 = 1'b0;
  assign rb716 = 1'b0;
  assign rb717 = 1'b0;
  assign rb718 = 1'b0;
  assign rb719 = 1'b0 | 1'b0;
  assign rb720 = rb715 & rb717;
  assign rb721 = rb716 & rb718;
  assign rb722 = (rb715 & ~rb717 & ~rb718) | (rb717 & ~rb715 & ~rb716);
  assign rb723 = (rb716 & ~rb717 & ~rb718) | (rb718 & ~rb715 & ~rb716);
  assign rb724 = rb720 | (rb722 & ~rb719);
  assign rb725 = rb721 | (rb723 & rb719);
  assign rb726 = (rb722 | rb723) & rb719;
  assign rb727 = (rb722 | rb723) & ~rb719;
  assign rb728 = neg24;
  assign rb729 = 1'b0;
  assign rb730 = 1'b0;
  assign rb731 = 1'b0;
  assign rb732 = 1'b0 | 1'b0;
  assign rb733 = rb728 & rb730;
  assign rb734 = rb729 & rb731;
  assign rb735 = (rb728 & ~rb730 & ~rb731) | (rb730 & ~rb728 & ~rb729);
  assign rb736 = (rb729 & ~rb730 & ~rb731) | (rb731 & ~rb728 & ~rb729);
  assign rb737 = rb733 | (rb735 & ~rb732);
  assign rb738 = rb734 | (rb736 & rb732);
  assign rb739 = (rb735 | rb736) & rb732;
  assign rb740 = (rb735 | rb736) & ~rb732;
  assign rb741 = 1'b0;
  assign rb742 = 1'b0;
  assign rb743 = 1'b0;
  assign rb744 = 1'b0;
  assign rb745 = 1'b0 | 1'b0;
  assign rb746 = rb741 & rb743;
  assign rb747 = rb742 & rb744;
  assign rb748 = (rb741 & ~rb743 & ~rb744) | (rb743 & ~rb741 & ~rb742);
  assign rb749 = (rb742 & ~rb743 & ~rb744) | (rb744 & ~rb741 & ~rb742);
  assign rb750 = rb746 | (rb748 & ~rb745);
  assign rb751 = rb747 | (rb749 & rb745);
  assign rb752 = (rb748 | rb749) & rb745;
  assign rb753 = (rb748 | rb749) & ~rb745;
  assign rb754 = pp51;
  assign rb755 = 1'b0;
  assign rb756 = neg47;
  assign rb757 = 1'b0;
  assign rb758 = 1'b0 | 1'b0;
  assign rb759 = rb754 & rb756;
  assign rb760 = rb755 & rb757;
  assign rb761 = (rb754 & ~rb756 & ~rb757) | (rb756 & ~rb754 & ~rb755);
  assign rb762 = (rb755 & ~rb756 & ~rb757) | (rb757 & ~rb754 & ~rb755);
  assign rb763 = rb759 | (rb761 & ~rb758);
  assign rb764 = rb760 | (rb762 & rb758);
  assign rb765 = (rb761 | rb762) & rb758;
  assign rb766 = (rb761 | rb762) & ~rb758;
  assign rb767 = pp52;
  assign rb768 = 1'b0;
  assign rb769 = 1'b0;
  assign rb770 = 1'b0;
  assign rb771 = 1'b0 | 1'b0;
  assign rb772 = rb767 & rb769;
  assign rb773 = rb768 & rb770;
  assign rb774 = (rb767 & ~rb769 & ~rb770) | (rb769 & ~rb767 & ~rb768);
  assign rb775 = (rb768 & ~rb769 & ~rb770) | (rb770 & ~rb767 & ~rb768);
  assign rb776 = rb772 | (rb774 & ~rb771);
  assign rb777 = rb773 | (rb775 & rb771);
  assign rb778 = (rb774 | rb775) & rb771;
  assign rb779 = (rb774 | rb775) & ~rb771;
  assign rb780 = pp53;
  assign rb781 = 1'b0;
  assign rb782 = pp74;
  assign rb783 = 1'b0;
  assign rb784 = 1'b0 | 1'b0;
  assign rb785 = rb780 & rb782;
  assign rb786 = rb781 & rb783;
  assign rb787 = (rb780 & ~rb782 & ~rb783) | (rb782 & ~rb780 & ~rb781);
  assign rb788 = (rb781 & ~rb782 & ~rb783) | (rb783 & ~rb780 & ~rb781);
  assign rb789 = rb785 | (rb787 & ~rb784);
  assign rb790 = rb786 | (rb788 & rb784);
  assign rb791 = (rb787 | rb788) & rb784;
  assign rb792 = (rb787 | rb788) & ~rb784;
  assign rb793 = pp54;
  assign rb794 = 1'b0;
  assign rb795 = pp75;
  assign rb796 = 1'b0;
  assign rb797 = 1'b0 | 1'b0;
  assign rb798 = rb793 & rb795;
  assign rb799 = rb794 & rb796;
  assign rb800 = (rb793 & ~rb795 & ~rb796) | (rb795 & ~rb793 & ~rb794);
  assign rb801 = (rb794 & ~rb795 & ~rb796) | (rb796 & ~rb793 & ~rb794);
  assign rb802 = rb798 | (rb800 & ~rb797);
  assign rb803 = rb799 | (rb801 & rb797);
  assign rb804 = (rb800 | rb801) & rb797;
  assign rb805 = (rb800 | rb801) & ~rb797;
  assign rb806 = pp55;
  assign rb807 = 1'b0;
  assign rb808 = pp76;
  assign rb809 = 1'b0;
  assign rb810 = 1'b0 | 1'b0;
  assign rb811 = rb806 & rb808;
  assign rb812 = rb807 & rb809;
  assign rb813 = (rb806 & ~rb808 & ~rb809) | (rb808 & ~rb806 & ~rb807);
  assign rb814 = (rb807 & ~rb808 & ~rb809) | (rb809 & ~rb806 & ~rb807);
  assign rb815 = rb811 | (rb813 & ~rb810);
  assign rb816 = rb812 | (rb814 & rb810);
  assign rb817 = (rb813 | rb814) & rb810;
  assign rb818 = (rb813 | rb814) & ~rb810;
  assign rb819 = pp56;
  assign rb820 = 1'b0;
  assign rb821 = pp77;
  assign rb822 = 1'b0;
  assign rb823 = 1'b0 | 1'b0;
  assign rb824 = rb819 & rb821;
  assign rb825 = rb820 & rb822;
  assign rb826 = (rb819 & ~rb821 & ~rb822) | (rb821 & ~rb819 & ~rb820);
  assign rb827 = (rb820 & ~rb821 & ~rb822) | (rb822 & ~rb819 & ~rb820);
  assign rb828 = rb824 | (rb826 & ~rb823);
  assign rb829 = rb825 | (rb827 & rb823);
  assign rb830 = (rb826 | rb827) & rb823;
  assign rb831 = (rb826 | rb827) & ~rb823;
  assign rb832 = pp57;
  assign rb833 = 1'b0;
  assign rb834 = pp78;
  assign rb835 = 1'b0;
  assign rb836 = 1'b0 | 1'b0;
  assign rb837 = rb832 & rb834;
  assign rb838 = rb833 & rb835;
  assign rb839 = (rb832 & ~rb834 & ~rb835) | (rb834 & ~rb832 & ~rb833);
  assign rb840 = (rb833 & ~rb834 & ~rb835) | (rb835 & ~rb832 & ~rb833);
  assign rb841 = rb837 | (rb839 & ~rb836);
  assign rb842 = rb838 | (rb840 & rb836);
  assign rb843 = (rb839 | rb840) & rb836;
  assign rb844 = (rb839 | rb840) & ~rb836;
  assign rb845 = pp58;
  assign rb846 = 1'b0;
  assign rb847 = pp79;
  assign rb848 = 1'b0;
  assign rb849 = 1'b0 | 1'b0;
  assign rb850 = rb845 & rb847;
  assign rb851 = rb846 & rb848;
  assign rb852 = (rb845 & ~rb847 & ~rb848) | (rb847 & ~rb845 & ~rb846);
  assign rb853 = (rb846 & ~rb847 & ~rb848) | (rb848 & ~rb845 & ~rb846);
  assign rb854 = rb850 | (rb852 & ~rb849);
  assign rb855 = rb851 | (rb853 & rb849);
  assign rb856 = (rb852 | rb853) & rb849;
  assign rb857 = (rb852 | rb853) & ~rb849;
  assign rb858 = pp59;
  assign rb859 = 1'b0;
  assign rb860 = pp80;
  assign rb861 = 1'b0;
  assign rb862 = 1'b0 | 1'b0;
  assign rb863 = rb858 & rb860;
  assign rb864 = rb859 & rb861;
  assign rb865 = (rb858 & ~rb860 & ~rb861) | (rb860 & ~rb858 & ~rb859);
  assign rb866 = (rb859 & ~rb860 & ~rb861) | (rb861 & ~rb858 & ~rb859);
  assign rb867 = rb863 | (rb865 & ~rb862);
  assign rb868 = rb864 | (rb866 & rb862);
  assign rb869 = (rb865 | rb866) & rb862;
  assign rb870 = (rb865 | rb866) & ~rb862;
  assign rb871 = pp60;
  assign rb872 = 1'b0;
  assign rb873 = pp81;
  assign rb874 = 1'b0;
  assign rb875 = 1'b0 | 1'b0;
  assign rb876 = rb871 & rb873;
  assign rb877 = rb872 & rb874;
  assign rb878 = (rb871 & ~rb873 & ~rb874) | (rb873 & ~rb871 & ~rb872);
  assign rb879 = (rb872 & ~rb873 & ~rb874) | (rb874 & ~rb871 & ~rb872);
  assign rb880 = rb876 | (rb878 & ~rb875);
  assign rb881 = rb877 | (rb879 & rb875);
  assign rb882 = (rb878 | rb879) & rb875;
  assign rb883 = (rb878 | rb879) & ~rb875;
  assign rb884 = pp61;
  assign rb885 = 1'b0;
  assign rb886 = pp82;
  assign rb887 = 1'b0;
  assign rb888 = 1'b0 | 1'b0;
  assign rb889 = rb884 & rb886;
  assign rb890 = rb885 & rb887;
  assign rb891 = (rb884 & ~rb886 & ~rb887) | (rb886 & ~rb884 & ~rb885);
  assign rb892 = (rb885 & ~rb886 & ~rb887) | (rb887 & ~rb884 & ~rb885);
  assign rb893 = rb889 | (rb891 & ~rb888);
  assign rb894 = rb890 | (rb892 & rb888);
  assign rb895 = (rb891 | rb892) & rb888;
  assign rb896 = (rb891 | rb892) & ~rb888;
  assign rb897 = pp62;
  assign rb898 = 1'b0;
  assign rb899 = pp83;
  assign rb900 = 1'b0;
  assign rb901 = 1'b0 | 1'b0;
  assign rb902 = rb897 & rb899;
  assign rb903 = rb898 & rb900;
  assign rb904 = (rb897 & ~rb899 & ~rb900) | (rb899 & ~rb897 & ~rb898);
  assign rb905 = (rb898 & ~rb899 & ~rb900) | (rb900 & ~rb897 & ~rb898);
  assign rb906 = rb902 | (rb904 & ~rb901);
  assign rb907 = rb903 | (rb905 & rb901);
  assign rb908 = (rb904 | rb905) & rb901;
  assign rb909 = (rb904 | rb905) & ~rb901;
  assign rb910 = pp63;
  assign rb911 = 1'b0;
  assign rb912 = pp84;
  assign rb913 = 1'b0;
  assign rb914 = 1'b0 | 1'b0;
  assign rb915 = rb910 & rb912;
  assign rb916 = rb911 & rb913;
  assign rb917 = (rb910 & ~rb912 & ~rb913) | (rb912 & ~rb910 & ~rb911);
  assign rb918 = (rb911 & ~rb912 & ~rb913) | (rb913 & ~rb910 & ~rb911);
  assign rb919 = rb915 | (rb917 & ~rb914);
  assign rb920 = rb916 | (rb918 & rb914);
  assign rb921 = (rb917 | rb918) & rb914;
  assign rb922 = (rb917 | rb918) & ~rb914;
  assign rb923 = pp64;
  assign rb924 = 1'b0;
  assign rb925 = pp85;
  assign rb926 = 1'b0;
  assign rb927 = 1'b0 | 1'b0;
  assign rb928 = rb923 & rb925;
  assign rb929 = rb924 & rb926;
  assign rb930 = (rb923 & ~rb925 & ~rb926) | (rb925 & ~rb923 & ~rb924);
  assign rb931 = (rb924 & ~rb925 & ~rb926) | (rb926 & ~rb923 & ~rb924);
  assign rb932 = rb928 | (rb930 & ~rb927);
  assign rb933 = rb929 | (rb931 & rb927);
  assign rb934 = (rb930 | rb931) & rb927;
  assign rb935 = (rb930 | rb931) & ~rb927;
  assign rb936 = pp86;
  assign rb937 = 1'b0;
  assign rb938 = pp107;
  assign rb939 = 1'b0;
  assign rb940 = 1'b0 | 1'b0;
  assign rb941 = rb936 & rb938;
  assign rb942 = rb937 & rb939;
  assign rb943 = (rb936 & ~rb938 & ~rb939) | (rb938 & ~rb936 & ~rb937);
  assign rb944 = (rb937 & ~rb938 & ~rb939) | (rb939 & ~rb936 & ~rb937);
  assign rb945 = rb941 | (rb943 & ~rb940);
  assign rb946 = rb942 | (rb944 & rb940);
  assign rb947 = (rb943 | rb944) & rb940;
  assign rb948 = (rb943 | rb944) & ~rb940;
  assign rb949 = pp87;
  assign rb950 = 1'b0;
  assign rb951 = pp108;
  assign rb952 = 1'b0;
  assign rb953 = 1'b0 | 1'b0;
  assign rb954 = rb949 & rb951;
  assign rb955 = rb950 & rb952;
  assign rb956 = (rb949 & ~rb951 & ~rb952) | (rb951 & ~rb949 & ~rb950);
  assign rb957 = (rb950 & ~rb951 & ~rb952) | (rb952 & ~rb949 & ~rb950);
  assign rb958 = rb954 | (rb956 & ~rb953);
  assign rb959 = rb955 | (rb957 & rb953);
  assign rb960 = (rb956 | rb957) & rb953;
  assign rb961 = (rb956 | rb957) & ~rb953;
  assign rb962 = pp109;
  assign rb963 = 1'b0;
  assign rb964 = pp130;
  assign rb965 = 1'b0;
  assign rb966 = 1'b0 | 1'b0;
  assign rb967 = rb962 & rb964;
  assign rb968 = rb963 & rb965;
  assign rb969 = (rb962 & ~rb964 & ~rb965) | (rb964 & ~rb962 & ~rb963);
  assign rb970 = (rb963 & ~rb964 & ~rb965) | (rb965 & ~rb962 & ~rb963);
  assign rb971 = rb967 | (rb969 & ~rb966);
  assign rb972 = rb968 | (rb970 & rb966);
  assign rb973 = (rb969 | rb970) & rb966;
  assign rb974 = (rb969 | rb970) & ~rb966;
  assign rb975 = pp110;
  assign rb976 = 1'b0;
  assign rb977 = pp131;
  assign rb978 = 1'b0;
  assign rb979 = 1'b0 | 1'b0;
  assign rb980 = rb975 & rb977;
  assign rb981 = rb976 & rb978;
  assign rb982 = (rb975 & ~rb977 & ~rb978) | (rb977 & ~rb975 & ~rb976);
  assign rb983 = (rb976 & ~rb977 & ~rb978) | (rb978 & ~rb975 & ~rb976);
  assign rb984 = rb980 | (rb982 & ~rb979);
  assign rb985 = rb981 | (rb983 & rb979);
  assign rb986 = (rb982 | rb983) & rb979;
  assign rb987 = (rb982 | rb983) & ~rb979;
  assign rb988 = pp132;
  assign rb989 = 1'b0;
  assign rb990 = pp153;
  assign rb991 = 1'b0;
  assign rb992 = 1'b0 | 1'b0;
  assign rb993 = rb988 & rb990;
  assign rb994 = rb989 & rb991;
  assign rb995 = (rb988 & ~rb990 & ~rb991) | (rb990 & ~rb988 & ~rb989);
  assign rb996 = (rb989 & ~rb990 & ~rb991) | (rb991 & ~rb988 & ~rb989);
  assign rb997 = rb993 | (rb995 & ~rb992);
  assign rb998 = rb994 | (rb996 & rb992);
  assign rb999 = (rb995 | rb996) & rb992;
  assign rb1000 = (rb995 | rb996) & ~rb992;
  assign rb1001 = pp133;
  assign rb1002 = 1'b0;
  assign rb1003 = pp154;
  assign rb1004 = 1'b0;
  assign rb1005 = 1'b0 | 1'b0;
  assign rb1006 = rb1001 & rb1003;
  assign rb1007 = rb1002 & rb1004;
  assign rb1008 = (rb1001 & ~rb1003 & ~rb1004) | (rb1003 & ~rb1001 & ~rb1002);
  assign rb1009 = (rb1002 & ~rb1003 & ~rb1004) | (rb1004 & ~rb1001 & ~rb1002);
  assign rb1010 = rb1006 | (rb1008 & ~rb1005);
  assign rb1011 = rb1007 | (rb1009 & rb1005);
  assign rb1012 = (rb1008 | rb1009) & rb1005;
  assign rb1013 = (rb1008 | rb1009) & ~rb1005;
  assign rb1014 = pp155;
  assign rb1015 = 1'b0;
  assign rb1016 = pp176;
  assign rb1017 = 1'b0;
  assign rb1018 = 1'b0 | 1'b0;
  assign rb1019 = rb1014 & rb1016;
  assign rb1020 = rb1015 & rb1017;
  assign rb1021 = (rb1014 & ~rb1016 & ~rb1017) | (rb1016 & ~rb1014 & ~rb1015);
  assign rb1022 = (rb1015 & ~rb1016 & ~rb1017) | (rb1017 & ~rb1014 & ~rb1015);
  assign rb1023 = rb1019 | (rb1021 & ~rb1018);
  assign rb1024 = rb1020 | (rb1022 & rb1018);
  assign rb1025 = (rb1021 | rb1022) & rb1018;
  assign rb1026 = (rb1021 | rb1022) & ~rb1018;
  assign rb1027 = pp156;
  assign rb1028 = 1'b0;
  assign rb1029 = pp177;
  assign rb1030 = 1'b0;
  assign rb1031 = 1'b0 | 1'b0;
  assign rb1032 = rb1027 & rb1029;
  assign rb1033 = rb1028 & rb1030;
  assign rb1034 = (rb1027 & ~rb1029 & ~rb1030) | (rb1029 & ~rb1027 & ~rb1028);
  assign rb1035 = (rb1028 & ~rb1029 & ~rb1030) | (rb1030 & ~rb1027 & ~rb1028);
  assign rb1036 = rb1032 | (rb1034 & ~rb1031);
  assign rb1037 = rb1033 | (rb1035 & rb1031);
  assign rb1038 = (rb1034 | rb1035) & rb1031;
  assign rb1039 = (rb1034 | rb1035) & ~rb1031;
  assign rb1040 = pp178;
  assign rb1041 = 1'b0;
  assign rb1042 = 1'b1;
  assign rb1043 = 1'b0;
  assign rb1044 = 1'b0 | 1'b0;
  assign rb1045 = rb1040 & rb1042;
  assign rb1046 = rb1041 & rb1043;
  assign rb1047 = (rb1040 & ~rb1042 & ~rb1043) | (rb1042 & ~rb1040 & ~rb1041);
  assign rb1048 = (rb1041 & ~rb1042 & ~rb1043) | (rb1043 & ~rb1040 & ~rb1041);
  assign rb1049 = rb1045 | (rb1047 & ~rb1044);
  assign rb1050 = rb1046 | (rb1048 & rb1044);
  assign rb1051 = (rb1047 | rb1048) & rb1044;
  assign rb1052 = (rb1047 | rb1048) & ~rb1044;
  assign rb1053 = pp179;
  assign rb1054 = 1'b0;
  assign rb1055 = 1'b0;
  assign rb1056 = 1'b0;
  assign rb1057 = 1'b0 | 1'b0;
  assign rb1058 = rb1053 & rb1055;
  assign rb1059 = rb1054 & rb1056;
  assign rb1060 = (rb1053 & ~rb1055 & ~rb1056) | (rb1055 & ~rb1053 & ~rb1054);
  assign rb1061 = (rb1054 & ~rb1055 & ~rb1056) | (rb1056 & ~rb1053 & ~rb1054);
  assign rb1062 = rb1058 | (rb1060 & ~rb1057);
  assign rb1063 = rb1059 | (rb1061 & rb1057);
  assign rb1064 = (rb1060 | rb1061) & rb1057;
  assign rb1065 = (rb1060 | rb1061) & ~rb1057;
  assign rb1066 = 1'b1;
  assign rb1067 = 1'b0;
  assign rb1068 = 1'b0;
  assign rb1069 = 1'b0;
  assign rb1070 = 1'b0 | 1'b0;
  assign rb1071 = rb1066 & rb1068;
  assign rb1072 = rb1067 & rb1069;
  assign rb1073 = (rb1066 & ~rb1068 & ~rb1069) | (rb1068 & ~rb1066 & ~rb1067);
  assign rb1074 = (rb1067 & ~rb1068 & ~rb1069) | (rb1069 & ~rb1066 & ~rb1067);
  assign rb1075 = rb1071 | (rb1073 & ~rb1070);
  assign rb1076 = rb1072 | (rb1074 & rb1070);
  assign rb1077 = (rb1073 | rb1074) & rb1070;
  assign rb1078 = (rb1073 | rb1074) & ~rb1070;
  assign rb1079 = 1'b0;
  assign rb1080 = 1'b0;
  assign rb1081 = 1'b0;
  assign rb1082 = 1'b0;
  assign rb1083 = 1'b0 | 1'b0;
  assign rb1084 = rb1079 & rb1081;
  assign rb1085 = rb1080 & rb1082;
  assign rb1086 = (rb1079 & ~rb1081 & ~rb1082) | (rb1081 & ~rb1079 & ~rb1080);
  assign rb1087 = (rb1080 & ~rb1081 & ~rb1082) | (rb1082 & ~rb1079 & ~rb1080);
  assign rb1088 = rb1084 | (rb1086 & ~rb1083);
  assign rb1089 = rb1085 | (rb1087 & rb1083);
  assign rb1090 = (rb1086 | rb1087) & rb1083;
  assign rb1091 = (rb1086 | rb1087) & ~rb1083;
  assign rb1092 = 1'b0;
  assign rb1093 = 1'b0;
  assign rb1094 = 1'b0;
  assign rb1095 = 1'b0;
  assign rb1096 = 1'b0 | 1'b0;
  assign rb1097 = rb1092 & rb1094;
  assign rb1098 = rb1093 & rb1095;
  assign rb1099 = (rb1092 & ~rb1094 & ~rb1095) | (rb1094 & ~rb1092 & ~rb1093);
  assign rb1100 = (rb1093 & ~rb1094 & ~rb1095) | (rb1095 & ~rb1092 & ~rb1093);
  assign rb1101 = rb1097 | (rb1099 & ~rb1096);
  assign rb1102 = rb1098 | (rb1100 & rb1096);
  assign rb1103 = (rb1099 | rb1100) & rb1096;
  assign rb1104 = (rb1099 | rb1100) & ~rb1096;
  assign rb1105 = 1'b0;
  assign rb1106 = 1'b0;
  assign rb1107 = 1'b0;
  assign rb1108 = 1'b0;
  assign rb1109 = 1'b0 | 1'b0;
  assign rb1110 = rb1105 & rb1107;
  assign rb1111 = rb1106 & rb1108;
  assign rb1112 = (rb1105 & ~rb1107 & ~rb1108) | (rb1107 & ~rb1105 & ~rb1106);
  assign rb1113 = (rb1106 & ~rb1107 & ~rb1108) | (rb1108 & ~rb1105 & ~rb1106);
  assign rb1114 = rb1110 | (rb1112 & ~rb1109);
  assign rb1115 = rb1111 | (rb1113 & rb1109);
  assign rb1116 = (rb1112 | rb1113) & rb1109;
  assign rb1117 = (rb1112 | rb1113) & ~rb1109;
  assign rb1118 = 1'b0;
  assign rb1119 = 1'b0;
  assign rb1120 = 1'b0;
  assign rb1121 = 1'b0;
  assign rb1122 = 1'b0 | 1'b0;
  assign rb1123 = rb1118 & rb1120;
  assign rb1124 = rb1119 & rb1121;
  assign rb1125 = (rb1118 & ~rb1120 & ~rb1121) | (rb1120 & ~rb1118 & ~rb1119);
  assign rb1126 = (rb1119 & ~rb1120 & ~rb1121) | (rb1121 & ~rb1118 & ~rb1119);
  assign rb1127 = rb1123 | (rb1125 & ~rb1122);
  assign rb1128 = rb1124 | (rb1126 & rb1122);
  assign rb1129 = (rb1125 | rb1126) & rb1122;
  assign rb1130 = (rb1125 | rb1126) & ~rb1122;
  assign rb1131 = 1'b0;
  assign rb1132 = 1'b0;
  assign rb1133 = 1'b0;
  assign rb1134 = 1'b0;
  assign rb1135 = 1'b0 | 1'b0;
  assign rb1136 = rb1131 & rb1133;
  assign rb1137 = rb1132 & rb1134;
  assign rb1138 = (rb1131 & ~rb1133 & ~rb1134) | (rb1133 & ~rb1131 & ~rb1132);
  assign rb1139 = (rb1132 & ~rb1133 & ~rb1134) | (rb1134 & ~rb1131 & ~rb1132);
  assign rb1140 = rb1136 | (rb1138 & ~rb1135);
  assign rb1141 = rb1137 | (rb1139 & rb1135);
  assign rb1142 = (rb1138 | rb1139) & rb1135;
  assign rb1143 = (rb1138 | rb1139) & ~rb1135;
  assign rb1144 = (rb713 & ~1'b0) | (1'b0 & ~rb714);
  assign rb1145 = (rb714 & ~1'b0) | (1'b0 & ~rb713);
  assign rb1146 = (rb726 & ~rb712) | (rb711 & ~rb727);
  assign rb1147 = (rb727 & ~rb711) | (rb712 & ~rb726);
  assign rb1148 = (rb739 & ~rb725) | (rb724 & ~rb740);
  assign rb1149 = (rb740 & ~rb724) | (rb725 & ~rb739);
  assign rb1150 = (rb752 & ~rb738) | (rb737 & ~rb753);
  assign rb1151 = (rb753 & ~rb737) | (rb738 & ~rb752);
  assign rb1152 = (rb765 & ~rb751) | (rb750 & ~rb766);
  assign rb1153 = (rb766 & ~rb750) | (rb751 & ~rb765);
  assign rb1154 = (rb778 & ~rb764) | (rb763 & ~rb779);
  assign rb1155 = (rb779 & ~rb763) | (rb764 & ~rb778);
  assign rb1156 = (rb791 & ~rb777) | (rb776 & ~rb792);
  assign rb1157 = (rb792 & ~rb776) | (rb777 & ~rb791);
  assign rb1158 = (rb804 & ~rb790) | (rb789 & ~rb805);
  assign rb1159 = (rb805 & ~rb789) | (rb790 & ~rb804);
  assign rb1160 = (rb817 & ~rb803) | (rb802 & ~rb818);
  assign rb1161 = (rb818 & ~rb802) | (rb803 & ~rb817);
  assign rb1162 = (rb830 & ~rb816) | (rb815 & ~rb831);
  assign rb1163 = (rb831 & ~rb815) | (rb816 & ~rb830);
  assign rb1164 = (rb843 & ~rb829) | (rb828 & ~rb844);
  assign rb1165 = (rb844 & ~rb828) | (rb829 & ~rb843);
  assign rb1166 = (rb856 & ~rb842) | (rb841 & ~rb857);
  assign rb1167 = (rb857 & ~rb841) | (rb842 & ~rb856);
  assign rb1168 = (rb869 & ~rb855) | (rb854 & ~rb870);
  assign rb1169 = (rb870 & ~rb854) | (rb855 & ~rb869);
  assign rb1170 = (rb882 & ~rb868) | (rb867 & ~rb883);
  assign rb1171 = (rb883 & ~rb867) | (rb868 & ~rb882);
  assign rb1172 = (rb895 & ~rb881) | (rb880 & ~rb896);
  assign rb1173 = (rb896 & ~rb880) | (rb881 & ~rb895);
  assign rb1174 = (rb908 & ~rb894) | (rb893 & ~rb909);
  assign rb1175 = (rb909 & ~rb893) | (rb894 & ~rb908);
  assign rb1176 = (rb921 & ~rb907) | (rb906 & ~rb922);
  assign rb1177 = (rb922 & ~rb906) | (rb907 & ~rb921);
  assign rb1178 = (rb934 & ~rb920) | (rb919 & ~rb935);
  assign rb1179 = (rb935 & ~rb919) | (rb920 & ~rb934);
  assign rb1180 = (rb947 & ~rb933) | (rb932 & ~rb948);
  assign rb1181 = (rb948 & ~rb932) | (rb933 & ~rb947);
  assign rb1182 = (rb960 & ~rb946) | (rb945 & ~rb961);
  assign rb1183 = (rb961 & ~rb945) | (rb946 & ~rb960);
  assign rb1184 = (rb973 & ~rb959) | (rb958 & ~rb974);
  assign rb1185 = (rb974 & ~rb958) | (rb959 & ~rb973);
  assign rb1186 = (rb986 & ~rb972) | (rb971 & ~rb987);
  assign rb1187 = (rb987 & ~rb971) | (rb972 & ~rb986);
  assign rb1188 = (rb999 & ~rb985) | (rb984 & ~rb1000);
  assign rb1189 = (rb1000 & ~rb984) | (rb985 & ~rb999);
  assign rb1190 = (rb1012 & ~rb998) | (rb997 & ~rb1013);
  assign rb1191 = (rb1013 & ~rb997) | (rb998 & ~rb1012);
  assign rb1192 = (rb1025 & ~rb1011) | (rb1010 & ~rb1026);
  assign rb1193 = (rb1026 & ~rb1010) | (rb1011 & ~rb1025);
  assign rb1194 = (rb1038 & ~rb1024) | (rb1023 & ~rb1039);
  assign rb1195 = (rb1039 & ~rb1023) | (rb1024 & ~rb1038);
  assign rb1196 = (rb1051 & ~rb1037) | (rb1036 & ~rb1052);
  assign rb1197 = (rb1052 & ~rb1036) | (rb1037 & ~rb1051);
  assign rb1198 = (rb1064 & ~rb1050) | (rb1049 & ~rb1065);
  assign rb1199 = (rb1065 & ~rb1049) | (rb1050 & ~rb1064);
  assign rb1200 = (rb1077 & ~rb1063) | (rb1062 & ~rb1078);
  assign rb1201 = (rb1078 & ~rb1062) | (rb1063 & ~rb1077);
  assign rb1202 = (rb1090 & ~rb1076) | (rb1075 & ~rb1091);
  assign rb1203 = (rb1091 & ~rb1075) | (rb1076 & ~rb1090);
  assign rb1204 = (rb1103 & ~rb1089) | (rb1088 & ~rb1104);
  assign rb1205 = (rb1104 & ~rb1088) | (rb1089 & ~rb1103);
  assign rb1206 = (rb1116 & ~rb1102) | (rb1101 & ~rb1117);
  assign rb1207 = (rb1117 & ~rb1101) | (rb1102 & ~rb1116);
  assign rb1208 = (rb1129 & ~rb1115) | (rb1114 & ~rb1130);
  assign rb1209 = (rb1130 & ~rb1114) | (rb1115 & ~rb1129);
  assign rb1210 = (rb1142 & ~rb1128) | (rb1127 & ~rb1143);
  assign rb1211 = (rb1143 & ~rb1127) | (rb1128 & ~rb1142);
  assign rb1212 = (1'b0 & ~rb1141) | (rb1140 & ~1'b0);
  assign rb1213 = (1'b0 & ~rb1140) | (rb1141 & ~1'b0);
  assign rb1214 = 1'b0;
  assign rb1215 = 1'b0;
  assign rb1216 = 1'b0;
  assign rb1217 = 1'b0;
  assign rb1218 = rb1214 & rb1216;
  assign rb1219 = rb1215 & rb1217;
  assign rb1220 = (rb1214 & ~rb1216 & ~rb1217) | (rb1216 & ~rb1214 & ~rb1215);
  assign rb1221 = (rb1215 & ~rb1216 & ~rb1217) | (rb1217 & ~rb1214 & ~rb1215);
  assign rb1222 = rb1218 | (rb1220 & ~1'b0);
  assign rb1223 = rb1219 | (rb1221 & 1'b0);
  assign rb1224 = (rb1220 | rb1221) & 1'b0;
  assign rb1225 = (rb1220 | rb1221) & ~1'b0;
  assign rb1226 = 1'b0;
  assign rb1227 = 1'b0;
  assign rb1228 = 1'b0;
  assign rb1229 = 1'b0;
  assign rb1230 = 1'b0 | 1'b0;
  assign rb1231 = rb1226 & rb1228;
  assign rb1232 = rb1227 & rb1229;
  assign rb1233 = (rb1226 & ~rb1228 & ~rb1229) | (rb1228 & ~rb1226 & ~rb1227);
  assign rb1234 = (rb1227 & ~rb1228 & ~rb1229) | (rb1229 & ~rb1226 & ~rb1227);
  assign rb1235 = rb1231 | (rb1233 & ~rb1230);
  assign rb1236 = rb1232 | (rb1234 & rb1230);
  assign rb1237 = (rb1233 | rb1234) & rb1230;
  assign rb1238 = (rb1233 | rb1234) & ~rb1230;
  assign rb1239 = 1'b0;
  assign rb1240 = 1'b0;
  assign rb1241 = 1'b0;
  assign rb1242 = 1'b0;
  assign rb1243 = 1'b0 | 1'b0;
  assign rb1244 = rb1239 & rb1241;
  assign rb1245 = rb1240 & rb1242;
  assign rb1246 = (rb1239 & ~rb1241 & ~rb1242) | (rb1241 & ~rb1239 & ~rb1240);
  assign rb1247 = (rb1240 & ~rb1241 & ~rb1242) | (rb1242 & ~rb1239 & ~rb1240);
  assign rb1248 = rb1244 | (rb1246 & ~rb1243);
  assign rb1249 = rb1245 | (rb1247 & rb1243);
  assign rb1250 = (rb1246 | rb1247) & rb1243;
  assign rb1251 = (rb1246 | rb1247) & ~rb1243;
  assign rb1252 = 1'b0;
  assign rb1253 = 1'b0;
  assign rb1254 = 1'b0;
  assign rb1255 = 1'b0;
  assign rb1256 = 1'b0 | 1'b0;
  assign rb1257 = rb1252 & rb1254;
  assign rb1258 = rb1253 & rb1255;
  assign rb1259 = (rb1252 & ~rb1254 & ~rb1255) | (rb1254 & ~rb1252 & ~rb1253);
  assign rb1260 = (rb1253 & ~rb1254 & ~rb1255) | (rb1255 & ~rb1252 & ~rb1253);
  assign rb1261 = rb1257 | (rb1259 & ~rb1256);
  assign rb1262 = rb1258 | (rb1260 & rb1256);
  assign rb1263 = (rb1259 | rb1260) & rb1256;
  assign rb1264 = (rb1259 | rb1260) & ~rb1256;
  assign rb1265 = 1'b0;
  assign rb1266 = 1'b0;
  assign rb1267 = 1'b0;
  assign rb1268 = 1'b0;
  assign rb1269 = 1'b0 | 1'b0;
  assign rb1270 = rb1265 & rb1267;
  assign rb1271 = rb1266 & rb1268;
  assign rb1272 = (rb1265 & ~rb1267 & ~rb1268) | (rb1267 & ~rb1265 & ~rb1266);
  assign rb1273 = (rb1266 & ~rb1267 & ~rb1268) | (rb1268 & ~rb1265 & ~rb1266);
  assign rb1274 = rb1270 | (rb1272 & ~rb1269);
  assign rb1275 = rb1271 | (rb1273 & rb1269);
  assign rb1276 = (rb1272 | rb1273) & rb1269;
  assign rb1277 = (rb1272 | rb1273) & ~rb1269;
  assign rb1278 = 1'b0;
  assign rb1279 = 1'b0;
  assign rb1280 = 1'b0;
  assign rb1281 = 1'b0;
  assign rb1282 = 1'b0 | 1'b0;
  assign rb1283 = rb1278 & rb1280;
  assign rb1284 = rb1279 & rb1281;
  assign rb1285 = (rb1278 & ~rb1280 & ~rb1281) | (rb1280 & ~rb1278 & ~rb1279);
  assign rb1286 = (rb1279 & ~rb1280 & ~rb1281) | (rb1281 & ~rb1278 & ~rb1279);
  assign rb1287 = rb1283 | (rb1285 & ~rb1282);
  assign rb1288 = rb1284 | (rb1286 & rb1282);
  assign rb1289 = (rb1285 | rb1286) & rb1282;
  assign rb1290 = (rb1285 | rb1286) & ~rb1282;
  assign rb1291 = neg70;
  assign rb1292 = 1'b0;
  assign rb1293 = 1'b0;
  assign rb1294 = 1'b0;
  assign rb1295 = 1'b0 | 1'b0;
  assign rb1296 = rb1291 & rb1293;
  assign rb1297 = rb1292 & rb1294;
  assign rb1298 = (rb1291 & ~rb1293 & ~rb1294) | (rb1293 & ~rb1291 & ~rb1292);
  assign rb1299 = (rb1292 & ~rb1293 & ~rb1294) | (rb1294 & ~rb1291 & ~rb1292);
  assign rb1300 = rb1296 | (rb1298 & ~rb1295);
  assign rb1301 = rb1297 | (rb1299 & rb1295);
  assign rb1302 = (rb1298 | rb1299) & rb1295;
  assign rb1303 = (rb1298 | rb1299) & ~rb1295;
  assign rb1304 = 1'b0;
  assign rb1305 = 1'b0;
  assign rb1306 = 1'b0;
  assign rb1307 = 1'b0;
  assign rb1308 = 1'b0 | 1'b0;
  assign rb1309 = rb1304 & rb1306;
  assign rb1310 = rb1305 & rb1307;
  assign rb1311 = (rb1304 & ~rb1306 & ~rb1307) | (rb1306 & ~rb1304 & ~rb1305);
  assign rb1312 = (rb1305 & ~rb1306 & ~rb1307) | (rb1307 & ~rb1304 & ~rb1305);
  assign rb1313 = rb1309 | (rb1311 & ~rb1308);
  assign rb1314 = rb1310 | (rb1312 & rb1308);
  assign rb1315 = (rb1311 | rb1312) & rb1308;
  assign rb1316 = (rb1311 | rb1312) & ~rb1308;
  assign rb1317 = pp97;
  assign rb1318 = 1'b0;
  assign rb1319 = neg93;
  assign rb1320 = 1'b0;
  assign rb1321 = 1'b0 | 1'b0;
  assign rb1322 = rb1317 & rb1319;
  assign rb1323 = rb1318 & rb1320;
  assign rb1324 = (rb1317 & ~rb1319 & ~rb1320) | (rb1319 & ~rb1317 & ~rb1318);
  assign rb1325 = (rb1318 & ~rb1319 & ~rb1320) | (rb1320 & ~rb1317 & ~rb1318);
  assign rb1326 = rb1322 | (rb1324 & ~rb1321);
  assign rb1327 = rb1323 | (rb1325 & rb1321);
  assign rb1328 = (rb1324 | rb1325) & rb1321;
  assign rb1329 = (rb1324 | rb1325) & ~rb1321;
  assign rb1330 = pp98;
  assign rb1331 = 1'b0;
  assign rb1332 = 1'b0;
  assign rb1333 = 1'b0;
  assign rb1334 = 1'b0 | 1'b0;
  assign rb1335 = rb1330 & rb1332;
  assign rb1336 = rb1331 & rb1333;
  assign rb1337 = (rb1330 & ~rb1332 & ~rb1333) | (rb1332 & ~rb1330 & ~rb1331);
  assign rb1338 = (rb1331 & ~rb1332 & ~rb1333) | (rb1333 & ~rb1330 & ~rb1331);
  assign rb1339 = rb1335 | (rb1337 & ~rb1334);
  assign rb1340 = rb1336 | (rb1338 & rb1334);
  assign rb1341 = (rb1337 | rb1338) & rb1334;
  assign rb1342 = (rb1337 | rb1338) & ~rb1334;
  assign rb1343 = pp99;
  assign rb1344 = 1'b0;
  assign rb1345 = pp120;
  assign rb1346 = 1'b0;
  assign rb1347 = 1'b0 | 1'b0;
  assign rb1348 = rb1343 & rb1345;
  assign rb1349 = rb1344 & rb1346;
  assign rb1350 = (rb1343 & ~rb1345 & ~rb1346) | (rb1345 & ~rb1343 & ~rb1344);
  assign rb1351 = (rb1344 & ~rb1345 & ~rb1346) | (rb1346 & ~rb1343 & ~rb1344);
  assign rb1352 = rb1348 | (rb1350 & ~rb1347);
  assign rb1353 = rb1349 | (rb1351 & rb1347);
  assign rb1354 = (rb1350 | rb1351) & rb1347;
  assign rb1355 = (rb1350 | rb1351) & ~rb1347;
  assign rb1356 = pp100;
  assign rb1357 = 1'b0;
  assign rb1358 = pp121;
  assign rb1359 = 1'b0;
  assign rb1360 = 1'b0 | 1'b0;
  assign rb1361 = rb1356 & rb1358;
  assign rb1362 = rb1357 & rb1359;
  assign rb1363 = (rb1356 & ~rb1358 & ~rb1359) | (rb1358 & ~rb1356 & ~rb1357);
  assign rb1364 = (rb1357 & ~rb1358 & ~rb1359) | (rb1359 & ~rb1356 & ~rb1357);
  assign rb1365 = rb1361 | (rb1363 & ~rb1360);
  assign rb1366 = rb1362 | (rb1364 & rb1360);
  assign rb1367 = (rb1363 | rb1364) & rb1360;
  assign rb1368 = (rb1363 | rb1364) & ~rb1360;
  assign rb1369 = pp101;
  assign rb1370 = 1'b0;
  assign rb1371 = pp122;
  assign rb1372 = 1'b0;
  assign rb1373 = 1'b0 | 1'b0;
  assign rb1374 = rb1369 & rb1371;
  assign rb1375 = rb1370 & rb1372;
  assign rb1376 = (rb1369 & ~rb1371 & ~rb1372) | (rb1371 & ~rb1369 & ~rb1370);
  assign rb1377 = (rb1370 & ~rb1371 & ~rb1372) | (rb1372 & ~rb1369 & ~rb1370);
  assign rb1378 = rb1374 | (rb1376 & ~rb1373);
  assign rb1379 = rb1375 | (rb1377 & rb1373);
  assign rb1380 = (rb1376 | rb1377) & rb1373;
  assign rb1381 = (rb1376 | rb1377) & ~rb1373;
  assign rb1382 = pp102;
  assign rb1383 = 1'b0;
  assign rb1384 = pp123;
  assign rb1385 = 1'b0;
  assign rb1386 = 1'b0 | 1'b0;
  assign rb1387 = rb1382 & rb1384;
  assign rb1388 = rb1383 & rb1385;
  assign rb1389 = (rb1382 & ~rb1384 & ~rb1385) | (rb1384 & ~rb1382 & ~rb1383);
  assign rb1390 = (rb1383 & ~rb1384 & ~rb1385) | (rb1385 & ~rb1382 & ~rb1383);
  assign rb1391 = rb1387 | (rb1389 & ~rb1386);
  assign rb1392 = rb1388 | (rb1390 & rb1386);
  assign rb1393 = (rb1389 | rb1390) & rb1386;
  assign rb1394 = (rb1389 | rb1390) & ~rb1386;
  assign rb1395 = pp103;
  assign rb1396 = 1'b0;
  assign rb1397 = pp124;
  assign rb1398 = 1'b0;
  assign rb1399 = 1'b0 | 1'b0;
  assign rb1400 = rb1395 & rb1397;
  assign rb1401 = rb1396 & rb1398;
  assign rb1402 = (rb1395 & ~rb1397 & ~rb1398) | (rb1397 & ~rb1395 & ~rb1396);
  assign rb1403 = (rb1396 & ~rb1397 & ~rb1398) | (rb1398 & ~rb1395 & ~rb1396);
  assign rb1404 = rb1400 | (rb1402 & ~rb1399);
  assign rb1405 = rb1401 | (rb1403 & rb1399);
  assign rb1406 = (rb1402 | rb1403) & rb1399;
  assign rb1407 = (rb1402 | rb1403) & ~rb1399;
  assign rb1408 = pp104;
  assign rb1409 = 1'b0;
  assign rb1410 = pp125;
  assign rb1411 = 1'b0;
  assign rb1412 = 1'b0 | 1'b0;
  assign rb1413 = rb1408 & rb1410;
  assign rb1414 = rb1409 & rb1411;
  assign rb1415 = (rb1408 & ~rb1410 & ~rb1411) | (rb1410 & ~rb1408 & ~rb1409);
  assign rb1416 = (rb1409 & ~rb1410 & ~rb1411) | (rb1411 & ~rb1408 & ~rb1409);
  assign rb1417 = rb1413 | (rb1415 & ~rb1412);
  assign rb1418 = rb1414 | (rb1416 & rb1412);
  assign rb1419 = (rb1415 | rb1416) & rb1412;
  assign rb1420 = (rb1415 | rb1416) & ~rb1412;
  assign rb1421 = pp105;
  assign rb1422 = 1'b0;
  assign rb1423 = pp126;
  assign rb1424 = 1'b0;
  assign rb1425 = 1'b0 | 1'b0;
  assign rb1426 = rb1421 & rb1423;
  assign rb1427 = rb1422 & rb1424;
  assign rb1428 = (rb1421 & ~rb1423 & ~rb1424) | (rb1423 & ~rb1421 & ~rb1422);
  assign rb1429 = (rb1422 & ~rb1423 & ~rb1424) | (rb1424 & ~rb1421 & ~rb1422);
  assign rb1430 = rb1426 | (rb1428 & ~rb1425);
  assign rb1431 = rb1427 | (rb1429 & rb1425);
  assign rb1432 = (rb1428 | rb1429) & rb1425;
  assign rb1433 = (rb1428 | rb1429) & ~rb1425;
  assign rb1434 = pp106;
  assign rb1435 = 1'b0;
  assign rb1436 = pp127;
  assign rb1437 = 1'b0;
  assign rb1438 = 1'b0 | 1'b0;
  assign rb1439 = rb1434 & rb1436;
  assign rb1440 = rb1435 & rb1437;
  assign rb1441 = (rb1434 & ~rb1436 & ~rb1437) | (rb1436 & ~rb1434 & ~rb1435);
  assign rb1442 = (rb1435 & ~rb1436 & ~rb1437) | (rb1437 & ~rb1434 & ~rb1435);
  assign rb1443 = rb1439 | (rb1441 & ~rb1438);
  assign rb1444 = rb1440 | (rb1442 & rb1438);
  assign rb1445 = (rb1441 | rb1442) & rb1438;
  assign rb1446 = (rb1441 | rb1442) & ~rb1438;
  assign rb1447 = pp128;
  assign rb1448 = 1'b0;
  assign rb1449 = pp149;
  assign rb1450 = 1'b0;
  assign rb1451 = 1'b0 | 1'b0;
  assign rb1452 = rb1447 & rb1449;
  assign rb1453 = rb1448 & rb1450;
  assign rb1454 = (rb1447 & ~rb1449 & ~rb1450) | (rb1449 & ~rb1447 & ~rb1448);
  assign rb1455 = (rb1448 & ~rb1449 & ~rb1450) | (rb1450 & ~rb1447 & ~rb1448);
  assign rb1456 = rb1452 | (rb1454 & ~rb1451);
  assign rb1457 = rb1453 | (rb1455 & rb1451);
  assign rb1458 = (rb1454 | rb1455) & rb1451;
  assign rb1459 = (rb1454 | rb1455) & ~rb1451;
  assign rb1460 = pp129;
  assign rb1461 = 1'b0;
  assign rb1462 = pp150;
  assign rb1463 = 1'b0;
  assign rb1464 = 1'b0 | 1'b0;
  assign rb1465 = rb1460 & rb1462;
  assign rb1466 = rb1461 & rb1463;
  assign rb1467 = (rb1460 & ~rb1462 & ~rb1463) | (rb1462 & ~rb1460 & ~rb1461);
  assign rb1468 = (rb1461 & ~rb1462 & ~rb1463) | (rb1463 & ~rb1460 & ~rb1461);
  assign rb1469 = rb1465 | (rb1467 & ~rb1464);
  assign rb1470 = rb1466 | (rb1468 & rb1464);
  assign rb1471 = (rb1467 | rb1468) & rb1464;
  assign rb1472 = (rb1467 | rb1468) & ~rb1464;
  assign rb1473 = pp151;
  assign rb1474 = 1'b0;
  assign rb1475 = pp172;
  assign rb1476 = 1'b0;
  assign rb1477 = 1'b0 | 1'b0;
  assign rb1478 = rb1473 & rb1475;
  assign rb1479 = rb1474 & rb1476;
  assign rb1480 = (rb1473 & ~rb1475 & ~rb1476) | (rb1475 & ~rb1473 & ~rb1474);
  assign rb1481 = (rb1474 & ~rb1475 & ~rb1476) | (rb1476 & ~rb1473 & ~rb1474);
  assign rb1482 = rb1478 | (rb1480 & ~rb1477);
  assign rb1483 = rb1479 | (rb1481 & rb1477);
  assign rb1484 = (rb1480 | rb1481) & rb1477;
  assign rb1485 = (rb1480 | rb1481) & ~rb1477;
  assign rb1486 = pp152;
  assign rb1487 = 1'b0;
  assign rb1488 = pp173;
  assign rb1489 = 1'b0;
  assign rb1490 = 1'b0 | 1'b0;
  assign rb1491 = rb1486 & rb1488;
  assign rb1492 = rb1487 & rb1489;
  assign rb1493 = (rb1486 & ~rb1488 & ~rb1489) | (rb1488 & ~rb1486 & ~rb1487);
  assign rb1494 = (rb1487 & ~rb1488 & ~rb1489) | (rb1489 & ~rb1486 & ~rb1487);
  assign rb1495 = rb1491 | (rb1493 & ~rb1490);
  assign rb1496 = rb1492 | (rb1494 & rb1490);
  assign rb1497 = (rb1493 | rb1494) & rb1490;
  assign rb1498 = (rb1493 | rb1494) & ~rb1490;
  assign rb1499 = pp174;
  assign rb1500 = 1'b0;
  assign rb1501 = 1'b1;
  assign rb1502 = 1'b0;
  assign rb1503 = 1'b0 | 1'b0;
  assign rb1504 = rb1499 & rb1501;
  assign rb1505 = rb1500 & rb1502;
  assign rb1506 = (rb1499 & ~rb1501 & ~rb1502) | (rb1501 & ~rb1499 & ~rb1500);
  assign rb1507 = (rb1500 & ~rb1501 & ~rb1502) | (rb1502 & ~rb1499 & ~rb1500);
  assign rb1508 = rb1504 | (rb1506 & ~rb1503);
  assign rb1509 = rb1505 | (rb1507 & rb1503);
  assign rb1510 = (rb1506 | rb1507) & rb1503;
  assign rb1511 = (rb1506 | rb1507) & ~rb1503;
  assign rb1512 = pp175;
  assign rb1513 = 1'b0;
  assign rb1514 = 1'b0;
  assign rb1515 = 1'b0;
  assign rb1516 = 1'b0 | 1'b0;
  assign rb1517 = rb1512 & rb1514;
  assign rb1518 = rb1513 & rb1515;
  assign rb1519 = (rb1512 & ~rb1514 & ~rb1515) | (rb1514 & ~rb1512 & ~rb1513);
  assign rb1520 = (rb1513 & ~rb1514 & ~rb1515) | (rb1515 & ~rb1512 & ~rb1513);
  assign rb1521 = rb1517 | (rb1519 & ~rb1516);
  assign rb1522 = rb1518 | (rb1520 & rb1516);
  assign rb1523 = (rb1519 | rb1520) & rb1516;
  assign rb1524 = (rb1519 | rb1520) & ~rb1516;
  assign rb1525 = 1'b1;
  assign rb1526 = 1'b0;
  assign rb1527 = 1'b0;
  assign rb1528 = 1'b0;
  assign rb1529 = 1'b0 | 1'b0;
  assign rb1530 = rb1525 & rb1527;
  assign rb1531 = rb1526 & rb1528;
  assign rb1532 = (rb1525 & ~rb1527 & ~rb1528) | (rb1527 & ~rb1525 & ~rb1526);
  assign rb1533 = (rb1526 & ~rb1527 & ~rb1528) | (rb1528 & ~rb1525 & ~rb1526);
  assign rb1534 = rb1530 | (rb1532 & ~rb1529);
  assign rb1535 = rb1531 | (rb1533 & rb1529);
  assign rb1536 = (rb1532 | rb1533) & rb1529;
  assign rb1537 = (rb1532 | rb1533) & ~rb1529;
  assign rb1538 = 1'b0;
  assign rb1539 = 1'b0;
  assign rb1540 = 1'b0;
  assign rb1541 = 1'b0;
  assign rb1542 = 1'b0 | 1'b0;
  assign rb1543 = rb1538 & rb1540;
  assign rb1544 = rb1539 & rb1541;
  assign rb1545 = (rb1538 & ~rb1540 & ~rb1541) | (rb1540 & ~rb1538 & ~rb1539);
  assign rb1546 = (rb1539 & ~rb1540 & ~rb1541) | (rb1541 & ~rb1538 & ~rb1539);
  assign rb1547 = rb1543 | (rb1545 & ~rb1542);
  assign rb1548 = rb1544 | (rb1546 & rb1542);
  assign rb1549 = (rb1545 | rb1546) & rb1542;
  assign rb1550 = (rb1545 | rb1546) & ~rb1542;
  assign rb1551 = 1'b0;
  assign rb1552 = 1'b0;
  assign rb1553 = 1'b0;
  assign rb1554 = 1'b0;
  assign rb1555 = 1'b0 | 1'b0;
  assign rb1556 = rb1551 & rb1553;
  assign rb1557 = rb1552 & rb1554;
  assign rb1558 = (rb1551 & ~rb1553 & ~rb1554) | (rb1553 & ~rb1551 & ~rb1552);
  assign rb1559 = (rb1552 & ~rb1553 & ~rb1554) | (rb1554 & ~rb1551 & ~rb1552);
  assign rb1560 = rb1556 | (rb1558 & ~rb1555);
  assign rb1561 = rb1557 | (rb1559 & rb1555);
  assign rb1562 = (rb1558 | rb1559) & rb1555;
  assign rb1563 = (rb1558 | rb1559) & ~rb1555;
  assign rb1564 = 1'b0;
  assign rb1565 = 1'b0;
  assign rb1566 = 1'b0;
  assign rb1567 = 1'b0;
  assign rb1568 = 1'b0 | 1'b0;
  assign rb1569 = rb1564 & rb1566;
  assign rb1570 = rb1565 & rb1567;
  assign rb1571 = (rb1564 & ~rb1566 & ~rb1567) | (rb1566 & ~rb1564 & ~rb1565);
  assign rb1572 = (rb1565 & ~rb1566 & ~rb1567) | (rb1567 & ~rb1564 & ~rb1565);
  assign rb1573 = rb1569 | (rb1571 & ~rb1568);
  assign rb1574 = rb1570 | (rb1572 & rb1568);
  assign rb1575 = (rb1571 | rb1572) & rb1568;
  assign rb1576 = (rb1571 | rb1572) & ~rb1568;
  assign rb1577 = 1'b0;
  assign rb1578 = 1'b0;
  assign rb1579 = 1'b0;
  assign rb1580 = 1'b0;
  assign rb1581 = 1'b0 | 1'b0;
  assign rb1582 = rb1577 & rb1579;
  assign rb1583 = rb1578 & rb1580;
  assign rb1584 = (rb1577 & ~rb1579 & ~rb1580) | (rb1579 & ~rb1577 & ~rb1578);
  assign rb1585 = (rb1578 & ~rb1579 & ~rb1580) | (rb1580 & ~rb1577 & ~rb1578);
  assign rb1586 = rb1582 | (rb1584 & ~rb1581);
  assign rb1587 = rb1583 | (rb1585 & rb1581);
  assign rb1588 = (rb1584 | rb1585) & rb1581;
  assign rb1589 = (rb1584 | rb1585) & ~rb1581;
  assign rb1590 = 1'b0;
  assign rb1591 = 1'b0;
  assign rb1592 = 1'b0;
  assign rb1593 = 1'b0;
  assign rb1594 = 1'b0 | 1'b0;
  assign rb1595 = rb1590 & rb1592;
  assign rb1596 = rb1591 & rb1593;
  assign rb1597 = (rb1590 & ~rb1592 & ~rb1593) | (rb1592 & ~rb1590 & ~rb1591);
  assign rb1598 = (rb1591 & ~rb1592 & ~rb1593) | (rb1593 & ~rb1590 & ~rb1591);
  assign rb1599 = rb1595 | (rb1597 & ~rb1594);
  assign rb1600 = rb1596 | (rb1598 & rb1594);
  assign rb1601 = (rb1597 | rb1598) & rb1594;
  assign rb1602 = (rb1597 | rb1598) & ~rb1594;
  assign rb1603 = 1'b0;
  assign rb1604 = 1'b0;
  assign rb1605 = 1'b0;
  assign rb1606 = 1'b0;
  assign rb1607 = 1'b0 | 1'b0;
  assign rb1608 = rb1603 & rb1605;
  assign rb1609 = rb1604 & rb1606;
  assign rb1610 = (rb1603 & ~rb1605 & ~rb1606) | (rb1605 & ~rb1603 & ~rb1604);
  assign rb1611 = (rb1604 & ~rb1605 & ~rb1606) | (rb1606 & ~rb1603 & ~rb1604);
  assign rb1612 = rb1608 | (rb1610 & ~rb1607);
  assign rb1613 = rb1609 | (rb1611 & rb1607);
  assign rb1614 = (rb1610 | rb1611) & rb1607;
  assign rb1615 = (rb1610 | rb1611) & ~rb1607;
  assign rb1616 = 1'b0;
  assign rb1617 = 1'b0;
  assign rb1618 = 1'b0;
  assign rb1619 = 1'b0;
  assign rb1620 = 1'b0 | 1'b0;
  assign rb1621 = rb1616 & rb1618;
  assign rb1622 = rb1617 & rb1619;
  assign rb1623 = (rb1616 & ~rb1618 & ~rb1619) | (rb1618 & ~rb1616 & ~rb1617);
  assign rb1624 = (rb1617 & ~rb1618 & ~rb1619) | (rb1619 & ~rb1616 & ~rb1617);
  assign rb1625 = rb1621 | (rb1623 & ~rb1620);
  assign rb1626 = rb1622 | (rb1624 & rb1620);
  assign rb1627 = (rb1623 | rb1624) & rb1620;
  assign rb1628 = (rb1623 | rb1624) & ~rb1620;
  assign rb1629 = 1'b0;
  assign rb1630 = 1'b0;
  assign rb1631 = 1'b0;
  assign rb1632 = 1'b0;
  assign rb1633 = 1'b0 | 1'b0;
  assign rb1634 = rb1629 & rb1631;
  assign rb1635 = rb1630 & rb1632;
  assign rb1636 = (rb1629 & ~rb1631 & ~rb1632) | (rb1631 & ~rb1629 & ~rb1630);
  assign rb1637 = (rb1630 & ~rb1631 & ~rb1632) | (rb1632 & ~rb1629 & ~rb1630);
  assign rb1638 = rb1634 | (rb1636 & ~rb1633);
  assign rb1639 = rb1635 | (rb1637 & rb1633);
  assign rb1640 = (rb1636 | rb1637) & rb1633;
  assign rb1641 = (rb1636 | rb1637) & ~rb1633;
  assign rb1642 = 1'b0;
  assign rb1643 = 1'b0;
  assign rb1644 = 1'b0;
  assign rb1645 = 1'b0;
  assign rb1646 = 1'b0 | 1'b0;
  assign rb1647 = rb1642 & rb1644;
  assign rb1648 = rb1643 & rb1645;
  assign rb1649 = (rb1642 & ~rb1644 & ~rb1645) | (rb1644 & ~rb1642 & ~rb1643);
  assign rb1650 = (rb1643 & ~rb1644 & ~rb1645) | (rb1645 & ~rb1642 & ~rb1643);
  assign rb1651 = rb1647 | (rb1649 & ~rb1646);
  assign rb1652 = rb1648 | (rb1650 & rb1646);
  assign rb1653 = (rb1649 | rb1650) & rb1646;
  assign rb1654 = (rb1649 | rb1650) & ~rb1646;
  assign rb1655 = (rb1224 & ~1'b0) | (1'b0 & ~rb1225);
  assign rb1656 = (rb1225 & ~1'b0) | (1'b0 & ~rb1224);
  assign rb1657 = (rb1237 & ~rb1223) | (rb1222 & ~rb1238);
  assign rb1658 = (rb1238 & ~rb1222) | (rb1223 & ~rb1237);
  assign rb1659 = (rb1250 & ~rb1236) | (rb1235 & ~rb1251);
  assign rb1660 = (rb1251 & ~rb1235) | (rb1236 & ~rb1250);
  assign rb1661 = (rb1263 & ~rb1249) | (rb1248 & ~rb1264);
  assign rb1662 = (rb1264 & ~rb1248) | (rb1249 & ~rb1263);
  assign rb1663 = (rb1276 & ~rb1262) | (rb1261 & ~rb1277);
  assign rb1664 = (rb1277 & ~rb1261) | (rb1262 & ~rb1276);
  assign rb1665 = (rb1289 & ~rb1275) | (rb1274 & ~rb1290);
  assign rb1666 = (rb1290 & ~rb1274) | (rb1275 & ~rb1289);
  assign rb1667 = (rb1302 & ~rb1288) | (rb1287 & ~rb1303);
  assign rb1668 = (rb1303 & ~rb1287) | (rb1288 & ~rb1302);
  assign rb1669 = (rb1315 & ~rb1301) | (rb1300 & ~rb1316);
  assign rb1670 = (rb1316 & ~rb1300) | (rb1301 & ~rb1315);
  assign rb1671 = (rb1328 & ~rb1314) | (rb1313 & ~rb1329);
  assign rb1672 = (rb1329 & ~rb1313) | (rb1314 & ~rb1328);
  assign rb1673 = (rb1341 & ~rb1327) | (rb1326 & ~rb1342);
  assign rb1674 = (rb1342 & ~rb1326) | (rb1327 & ~rb1341);
  assign rb1675 = (rb1354 & ~rb1340) | (rb1339 & ~rb1355);
  assign rb1676 = (rb1355 & ~rb1339) | (rb1340 & ~rb1354);
  assign rb1677 = (rb1367 & ~rb1353) | (rb1352 & ~rb1368);
  assign rb1678 = (rb1368 & ~rb1352) | (rb1353 & ~rb1367);
  assign rb1679 = (rb1380 & ~rb1366) | (rb1365 & ~rb1381);
  assign rb1680 = (rb1381 & ~rb1365) | (rb1366 & ~rb1380);
  assign rb1681 = (rb1393 & ~rb1379) | (rb1378 & ~rb1394);
  assign rb1682 = (rb1394 & ~rb1378) | (rb1379 & ~rb1393);
  assign rb1683 = (rb1406 & ~rb1392) | (rb1391 & ~rb1407);
  assign rb1684 = (rb1407 & ~rb1391) | (rb1392 & ~rb1406);
  assign rb1685 = (rb1419 & ~rb1405) | (rb1404 & ~rb1420);
  assign rb1686 = (rb1420 & ~rb1404) | (rb1405 & ~rb1419);
  assign rb1687 = (rb1432 & ~rb1418) | (rb1417 & ~rb1433);
  assign rb1688 = (rb1433 & ~rb1417) | (rb1418 & ~rb1432);
  assign rb1689 = (rb1445 & ~rb1431) | (rb1430 & ~rb1446);
  assign rb1690 = (rb1446 & ~rb1430) | (rb1431 & ~rb1445);
  assign rb1691 = (rb1458 & ~rb1444) | (rb1443 & ~rb1459);
  assign rb1692 = (rb1459 & ~rb1443) | (rb1444 & ~rb1458);
  assign rb1693 = (rb1471 & ~rb1457) | (rb1456 & ~rb1472);
  assign rb1694 = (rb1472 & ~rb1456) | (rb1457 & ~rb1471);
  assign rb1695 = (rb1484 & ~rb1470) | (rb1469 & ~rb1485);
  assign rb1696 = (rb1485 & ~rb1469) | (rb1470 & ~rb1484);
  assign rb1697 = (rb1497 & ~rb1483) | (rb1482 & ~rb1498);
  assign rb1698 = (rb1498 & ~rb1482) | (rb1483 & ~rb1497);
  assign rb1699 = (rb1510 & ~rb1496) | (rb1495 & ~rb1511);
  assign rb1700 = (rb1511 & ~rb1495) | (rb1496 & ~rb1510);
  assign rb1701 = (rb1523 & ~rb1509) | (rb1508 & ~rb1524);
  assign rb1702 = (rb1524 & ~rb1508) | (rb1509 & ~rb1523);
  assign rb1703 = (rb1536 & ~rb1522) | (rb1521 & ~rb1537);
  assign rb1704 = (rb1537 & ~rb1521) | (rb1522 & ~rb1536);
  assign rb1705 = (rb1549 & ~rb1535) | (rb1534 & ~rb1550);
  assign rb1706 = (rb1550 & ~rb1534) | (rb1535 & ~rb1549);
  assign rb1707 = (rb1562 & ~rb1548) | (rb1547 & ~rb1563);
  assign rb1708 = (rb1563 & ~rb1547) | (rb1548 & ~rb1562);
  assign rb1709 = (rb1575 & ~rb1561) | (rb1560 & ~rb1576);
  assign rb1710 = (rb1576 & ~rb1560) | (rb1561 & ~rb1575);
  assign rb1711 = (rb1588 & ~rb1574) | (rb1573 & ~rb1589);
  assign rb1712 = (rb1589 & ~rb1573) | (rb1574 & ~rb1588);
  assign rb1713 = (rb1601 & ~rb1587) | (rb1586 & ~rb1602);
  assign rb1714 = (rb1602 & ~rb1586) | (rb1587 & ~rb1601);
  assign rb1715 = (rb1614 & ~rb1600) | (rb1599 & ~rb1615);
  assign rb1716 = (rb1615 & ~rb1599) | (rb1600 & ~rb1614);
  assign rb1717 = (rb1627 & ~rb1613) | (rb1612 & ~rb1628);
  assign rb1718 = (rb1628 & ~rb1612) | (rb1613 & ~rb1627);
  assign rb1719 = (rb1640 & ~rb1626) | (rb1625 & ~rb1641);
  assign rb1720 = (rb1641 & ~rb1625) | (rb1626 & ~rb1640);
  assign rb1721 = (rb1653 & ~rb1639) | (rb1638 & ~rb1654);
  assign rb1722 = (rb1654 & ~rb1638) | (rb1639 & ~rb1653);
  assign rb1723 = (1'b0 & ~rb1652) | (rb1651 & ~1'b0);
  assign rb1724 = (1'b0 & ~rb1651) | (rb1652 & ~1'b0);
  assign rb1725 = 1'b0;
  assign rb1726 = 1'b0;
  assign rb1727 = 1'b0;
  assign rb1728 = 1'b0;
  assign rb1729 = rb1725 & rb1727;
  assign rb1730 = rb1726 & rb1728;
  assign rb1731 = (rb1725 & ~rb1727 & ~rb1728) | (rb1727 & ~rb1725 & ~rb1726);
  assign rb1732 = (rb1726 & ~rb1727 & ~rb1728) | (rb1728 & ~rb1725 & ~rb1726);
  assign rb1733 = rb1729 | (rb1731 & ~1'b0);
  assign rb1734 = rb1730 | (rb1732 & 1'b0);
  assign rb1735 = (rb1731 | rb1732) & 1'b0;
  assign rb1736 = (rb1731 | rb1732) & ~1'b0;
  assign rb1737 = 1'b0;
  assign rb1738 = 1'b0;
  assign rb1739 = 1'b0;
  assign rb1740 = 1'b0;
  assign rb1741 = 1'b0 | 1'b0;
  assign rb1742 = rb1737 & rb1739;
  assign rb1743 = rb1738 & rb1740;
  assign rb1744 = (rb1737 & ~rb1739 & ~rb1740) | (rb1739 & ~rb1737 & ~rb1738);
  assign rb1745 = (rb1738 & ~rb1739 & ~rb1740) | (rb1740 & ~rb1737 & ~rb1738);
  assign rb1746 = rb1742 | (rb1744 & ~rb1741);
  assign rb1747 = rb1743 | (rb1745 & rb1741);
  assign rb1748 = (rb1744 | rb1745) & rb1741;
  assign rb1749 = (rb1744 | rb1745) & ~rb1741;
  assign rb1750 = 1'b0;
  assign rb1751 = 1'b0;
  assign rb1752 = 1'b0;
  assign rb1753 = 1'b0;
  assign rb1754 = 1'b0 | 1'b0;
  assign rb1755 = rb1750 & rb1752;
  assign rb1756 = rb1751 & rb1753;
  assign rb1757 = (rb1750 & ~rb1752 & ~rb1753) | (rb1752 & ~rb1750 & ~rb1751);
  assign rb1758 = (rb1751 & ~rb1752 & ~rb1753) | (rb1753 & ~rb1750 & ~rb1751);
  assign rb1759 = rb1755 | (rb1757 & ~rb1754);
  assign rb1760 = rb1756 | (rb1758 & rb1754);
  assign rb1761 = (rb1757 | rb1758) & rb1754;
  assign rb1762 = (rb1757 | rb1758) & ~rb1754;
  assign rb1763 = 1'b0;
  assign rb1764 = 1'b0;
  assign rb1765 = 1'b0;
  assign rb1766 = 1'b0;
  assign rb1767 = 1'b0 | 1'b0;
  assign rb1768 = rb1763 & rb1765;
  assign rb1769 = rb1764 & rb1766;
  assign rb1770 = (rb1763 & ~rb1765 & ~rb1766) | (rb1765 & ~rb1763 & ~rb1764);
  assign rb1771 = (rb1764 & ~rb1765 & ~rb1766) | (rb1766 & ~rb1763 & ~rb1764);
  assign rb1772 = rb1768 | (rb1770 & ~rb1767);
  assign rb1773 = rb1769 | (rb1771 & rb1767);
  assign rb1774 = (rb1770 | rb1771) & rb1767;
  assign rb1775 = (rb1770 | rb1771) & ~rb1767;
  assign rb1776 = 1'b0;
  assign rb1777 = 1'b0;
  assign rb1778 = 1'b0;
  assign rb1779 = 1'b0;
  assign rb1780 = 1'b0 | 1'b0;
  assign rb1781 = rb1776 & rb1778;
  assign rb1782 = rb1777 & rb1779;
  assign rb1783 = (rb1776 & ~rb1778 & ~rb1779) | (rb1778 & ~rb1776 & ~rb1777);
  assign rb1784 = (rb1777 & ~rb1778 & ~rb1779) | (rb1779 & ~rb1776 & ~rb1777);
  assign rb1785 = rb1781 | (rb1783 & ~rb1780);
  assign rb1786 = rb1782 | (rb1784 & rb1780);
  assign rb1787 = (rb1783 | rb1784) & rb1780;
  assign rb1788 = (rb1783 | rb1784) & ~rb1780;
  assign rb1789 = 1'b0;
  assign rb1790 = 1'b0;
  assign rb1791 = 1'b0;
  assign rb1792 = 1'b0;
  assign rb1793 = 1'b0 | 1'b0;
  assign rb1794 = rb1789 & rb1791;
  assign rb1795 = rb1790 & rb1792;
  assign rb1796 = (rb1789 & ~rb1791 & ~rb1792) | (rb1791 & ~rb1789 & ~rb1790);
  assign rb1797 = (rb1790 & ~rb1791 & ~rb1792) | (rb1792 & ~rb1789 & ~rb1790);
  assign rb1798 = rb1794 | (rb1796 & ~rb1793);
  assign rb1799 = rb1795 | (rb1797 & rb1793);
  assign rb1800 = (rb1796 | rb1797) & rb1793;
  assign rb1801 = (rb1796 | rb1797) & ~rb1793;
  assign rb1802 = 1'b0;
  assign rb1803 = 1'b0;
  assign rb1804 = 1'b0;
  assign rb1805 = 1'b0;
  assign rb1806 = 1'b0 | 1'b0;
  assign rb1807 = rb1802 & rb1804;
  assign rb1808 = rb1803 & rb1805;
  assign rb1809 = (rb1802 & ~rb1804 & ~rb1805) | (rb1804 & ~rb1802 & ~rb1803);
  assign rb1810 = (rb1803 & ~rb1804 & ~rb1805) | (rb1805 & ~rb1802 & ~rb1803);
  assign rb1811 = rb1807 | (rb1809 & ~rb1806);
  assign rb1812 = rb1808 | (rb1810 & rb1806);
  assign rb1813 = (rb1809 | rb1810) & rb1806;
  assign rb1814 = (rb1809 | rb1810) & ~rb1806;
  assign rb1815 = 1'b0;
  assign rb1816 = 1'b0;
  assign rb1817 = 1'b0;
  assign rb1818 = 1'b0;
  assign rb1819 = 1'b0 | 1'b0;
  assign rb1820 = rb1815 & rb1817;
  assign rb1821 = rb1816 & rb1818;
  assign rb1822 = (rb1815 & ~rb1817 & ~rb1818) | (rb1817 & ~rb1815 & ~rb1816);
  assign rb1823 = (rb1816 & ~rb1817 & ~rb1818) | (rb1818 & ~rb1815 & ~rb1816);
  assign rb1824 = rb1820 | (rb1822 & ~rb1819);
  assign rb1825 = rb1821 | (rb1823 & rb1819);
  assign rb1826 = (rb1822 | rb1823) & rb1819;
  assign rb1827 = (rb1822 | rb1823) & ~rb1819;
  assign rb1828 = 1'b0;
  assign rb1829 = 1'b0;
  assign rb1830 = 1'b0;
  assign rb1831 = 1'b0;
  assign rb1832 = 1'b0 | 1'b0;
  assign rb1833 = rb1828 & rb1830;
  assign rb1834 = rb1829 & rb1831;
  assign rb1835 = (rb1828 & ~rb1830 & ~rb1831) | (rb1830 & ~rb1828 & ~rb1829);
  assign rb1836 = (rb1829 & ~rb1830 & ~rb1831) | (rb1831 & ~rb1828 & ~rb1829);
  assign rb1837 = rb1833 | (rb1835 & ~rb1832);
  assign rb1838 = rb1834 | (rb1836 & rb1832);
  assign rb1839 = (rb1835 | rb1836) & rb1832;
  assign rb1840 = (rb1835 | rb1836) & ~rb1832;
  assign rb1841 = 1'b0;
  assign rb1842 = 1'b0;
  assign rb1843 = 1'b0;
  assign rb1844 = 1'b0;
  assign rb1845 = 1'b0 | 1'b0;
  assign rb1846 = rb1841 & rb1843;
  assign rb1847 = rb1842 & rb1844;
  assign rb1848 = (rb1841 & ~rb1843 & ~rb1844) | (rb1843 & ~rb1841 & ~rb1842);
  assign rb1849 = (rb1842 & ~rb1843 & ~rb1844) | (rb1844 & ~rb1841 & ~rb1842);
  assign rb1850 = rb1846 | (rb1848 & ~rb1845);
  assign rb1851 = rb1847 | (rb1849 & rb1845);
  assign rb1852 = (rb1848 | rb1849) & rb1845;
  assign rb1853 = (rb1848 | rb1849) & ~rb1845;
  assign rb1854 = neg116;
  assign rb1855 = 1'b0;
  assign rb1856 = 1'b0;
  assign rb1857 = 1'b0;
  assign rb1858 = 1'b0 | 1'b0;
  assign rb1859 = rb1854 & rb1856;
  assign rb1860 = rb1855 & rb1857;
  assign rb1861 = (rb1854 & ~rb1856 & ~rb1857) | (rb1856 & ~rb1854 & ~rb1855);
  assign rb1862 = (rb1855 & ~rb1856 & ~rb1857) | (rb1857 & ~rb1854 & ~rb1855);
  assign rb1863 = rb1859 | (rb1861 & ~rb1858);
  assign rb1864 = rb1860 | (rb1862 & rb1858);
  assign rb1865 = (rb1861 | rb1862) & rb1858;
  assign rb1866 = (rb1861 | rb1862) & ~rb1858;
  assign rb1867 = 1'b0;
  assign rb1868 = 1'b0;
  assign rb1869 = 1'b0;
  assign rb1870 = 1'b0;
  assign rb1871 = 1'b0 | 1'b0;
  assign rb1872 = rb1867 & rb1869;
  assign rb1873 = rb1868 & rb1870;
  assign rb1874 = (rb1867 & ~rb1869 & ~rb1870) | (rb1869 & ~rb1867 & ~rb1868);
  assign rb1875 = (rb1868 & ~rb1869 & ~rb1870) | (rb1870 & ~rb1867 & ~rb1868);
  assign rb1876 = rb1872 | (rb1874 & ~rb1871);
  assign rb1877 = rb1873 | (rb1875 & rb1871);
  assign rb1878 = (rb1874 | rb1875) & rb1871;
  assign rb1879 = (rb1874 | rb1875) & ~rb1871;
  assign rb1880 = pp143;
  assign rb1881 = 1'b0;
  assign rb1882 = neg139;
  assign rb1883 = 1'b0;
  assign rb1884 = 1'b0 | 1'b0;
  assign rb1885 = rb1880 & rb1882;
  assign rb1886 = rb1881 & rb1883;
  assign rb1887 = (rb1880 & ~rb1882 & ~rb1883) | (rb1882 & ~rb1880 & ~rb1881);
  assign rb1888 = (rb1881 & ~rb1882 & ~rb1883) | (rb1883 & ~rb1880 & ~rb1881);
  assign rb1889 = rb1885 | (rb1887 & ~rb1884);
  assign rb1890 = rb1886 | (rb1888 & rb1884);
  assign rb1891 = (rb1887 | rb1888) & rb1884;
  assign rb1892 = (rb1887 | rb1888) & ~rb1884;
  assign rb1893 = pp144;
  assign rb1894 = 1'b0;
  assign rb1895 = 1'b0;
  assign rb1896 = 1'b0;
  assign rb1897 = 1'b0 | 1'b0;
  assign rb1898 = rb1893 & rb1895;
  assign rb1899 = rb1894 & rb1896;
  assign rb1900 = (rb1893 & ~rb1895 & ~rb1896) | (rb1895 & ~rb1893 & ~rb1894);
  assign rb1901 = (rb1894 & ~rb1895 & ~rb1896) | (rb1896 & ~rb1893 & ~rb1894);
  assign rb1902 = rb1898 | (rb1900 & ~rb1897);
  assign rb1903 = rb1899 | (rb1901 & rb1897);
  assign rb1904 = (rb1900 | rb1901) & rb1897;
  assign rb1905 = (rb1900 | rb1901) & ~rb1897;
  assign rb1906 = pp145;
  assign rb1907 = 1'b0;
  assign rb1908 = pp166;
  assign rb1909 = 1'b0;
  assign rb1910 = 1'b0 | 1'b0;
  assign rb1911 = rb1906 & rb1908;
  assign rb1912 = rb1907 & rb1909;
  assign rb1913 = (rb1906 & ~rb1908 & ~rb1909) | (rb1908 & ~rb1906 & ~rb1907);
  assign rb1914 = (rb1907 & ~rb1908 & ~rb1909) | (rb1909 & ~rb1906 & ~rb1907);
  assign rb1915 = rb1911 | (rb1913 & ~rb1910);
  assign rb1916 = rb1912 | (rb1914 & rb1910);
  assign rb1917 = (rb1913 | rb1914) & rb1910;
  assign rb1918 = (rb1913 | rb1914) & ~rb1910;
  assign rb1919 = pp146;
  assign rb1920 = 1'b0;
  assign rb1921 = pp167;
  assign rb1922 = 1'b0;
  assign rb1923 = 1'b0 | 1'b0;
  assign rb1924 = rb1919 & rb1921;
  assign rb1925 = rb1920 & rb1922;
  assign rb1926 = (rb1919 & ~rb1921 & ~rb1922) | (rb1921 & ~rb1919 & ~rb1920);
  assign rb1927 = (rb1920 & ~rb1921 & ~rb1922) | (rb1922 & ~rb1919 & ~rb1920);
  assign rb1928 = rb1924 | (rb1926 & ~rb1923);
  assign rb1929 = rb1925 | (rb1927 & rb1923);
  assign rb1930 = (rb1926 | rb1927) & rb1923;
  assign rb1931 = (rb1926 | rb1927) & ~rb1923;
  assign rb1932 = pp147;
  assign rb1933 = 1'b0;
  assign rb1934 = pp168;
  assign rb1935 = 1'b0;
  assign rb1936 = 1'b0 | 1'b0;
  assign rb1937 = rb1932 & rb1934;
  assign rb1938 = rb1933 & rb1935;
  assign rb1939 = (rb1932 & ~rb1934 & ~rb1935) | (rb1934 & ~rb1932 & ~rb1933);
  assign rb1940 = (rb1933 & ~rb1934 & ~rb1935) | (rb1935 & ~rb1932 & ~rb1933);
  assign rb1941 = rb1937 | (rb1939 & ~rb1936);
  assign rb1942 = rb1938 | (rb1940 & rb1936);
  assign rb1943 = (rb1939 | rb1940) & rb1936;
  assign rb1944 = (rb1939 | rb1940) & ~rb1936;
  assign rb1945 = pp148;
  assign rb1946 = 1'b0;
  assign rb1947 = pp169;
  assign rb1948 = 1'b0;
  assign rb1949 = 1'b0 | 1'b0;
  assign rb1950 = rb1945 & rb1947;
  assign rb1951 = rb1946 & rb1948;
  assign rb1952 = (rb1945 & ~rb1947 & ~rb1948) | (rb1947 & ~rb1945 & ~rb1946);
  assign rb1953 = (rb1946 & ~rb1947 & ~rb1948) | (rb1948 & ~rb1945 & ~rb1946);
  assign rb1954 = rb1950 | (rb1952 & ~rb1949);
  assign rb1955 = rb1951 | (rb1953 & rb1949);
  assign rb1956 = (rb1952 | rb1953) & rb1949;
  assign rb1957 = (rb1952 | rb1953) & ~rb1949;
  assign rb1958 = pp170;
  assign rb1959 = 1'b0;
  assign rb1960 = 1'b1;
  assign rb1961 = 1'b0;
  assign rb1962 = 1'b0 | 1'b0;
  assign rb1963 = rb1958 & rb1960;
  assign rb1964 = rb1959 & rb1961;
  assign rb1965 = (rb1958 & ~rb1960 & ~rb1961) | (rb1960 & ~rb1958 & ~rb1959);
  assign rb1966 = (rb1959 & ~rb1960 & ~rb1961) | (rb1961 & ~rb1958 & ~rb1959);
  assign rb1967 = rb1963 | (rb1965 & ~rb1962);
  assign rb1968 = rb1964 | (rb1966 & rb1962);
  assign rb1969 = (rb1965 | rb1966) & rb1962;
  assign rb1970 = (rb1965 | rb1966) & ~rb1962;
  assign rb1971 = pp171;
  assign rb1972 = 1'b0;
  assign rb1973 = 1'b0;
  assign rb1974 = 1'b0;
  assign rb1975 = 1'b0 | 1'b0;
  assign rb1976 = rb1971 & rb1973;
  assign rb1977 = rb1972 & rb1974;
  assign rb1978 = (rb1971 & ~rb1973 & ~rb1974) | (rb1973 & ~rb1971 & ~rb1972);
  assign rb1979 = (rb1972 & ~rb1973 & ~rb1974) | (rb1974 & ~rb1971 & ~rb1972);
  assign rb1980 = rb1976 | (rb1978 & ~rb1975);
  assign rb1981 = rb1977 | (rb1979 & rb1975);
  assign rb1982 = (rb1978 | rb1979) & rb1975;
  assign rb1983 = (rb1978 | rb1979) & ~rb1975;
  assign rb1984 = 1'b1;
  assign rb1985 = 1'b0;
  assign rb1986 = 1'b0;
  assign rb1987 = 1'b0;
  assign rb1988 = 1'b0 | 1'b0;
  assign rb1989 = rb1984 & rb1986;
  assign rb1990 = rb1985 & rb1987;
  assign rb1991 = (rb1984 & ~rb1986 & ~rb1987) | (rb1986 & ~rb1984 & ~rb1985);
  assign rb1992 = (rb1985 & ~rb1986 & ~rb1987) | (rb1987 & ~rb1984 & ~rb1985);
  assign rb1993 = rb1989 | (rb1991 & ~rb1988);
  assign rb1994 = rb1990 | (rb1992 & rb1988);
  assign rb1995 = (rb1991 | rb1992) & rb1988;
  assign rb1996 = (rb1991 | rb1992) & ~rb1988;
  assign rb1997 = 1'b0;
  assign rb1998 = 1'b0;
  assign rb1999 = 1'b0;
  assign rb2000 = 1'b0;
  assign rb2001 = 1'b0 | 1'b0;
  assign rb2002 = rb1997 & rb1999;
  assign rb2003 = rb1998 & rb2000;
  assign rb2004 = (rb1997 & ~rb1999 & ~rb2000) | (rb1999 & ~rb1997 & ~rb1998);
  assign rb2005 = (rb1998 & ~rb1999 & ~rb2000) | (rb2000 & ~rb1997 & ~rb1998);
  assign rb2006 = rb2002 | (rb2004 & ~rb2001);
  assign rb2007 = rb2003 | (rb2005 & rb2001);
  assign rb2008 = (rb2004 | rb2005) & rb2001;
  assign rb2009 = (rb2004 | rb2005) & ~rb2001;
  assign rb2010 = 1'b0;
  assign rb2011 = 1'b0;
  assign rb2012 = 1'b0;
  assign rb2013 = 1'b0;
  assign rb2014 = 1'b0 | 1'b0;
  assign rb2015 = rb2010 & rb2012;
  assign rb2016 = rb2011 & rb2013;
  assign rb2017 = (rb2010 & ~rb2012 & ~rb2013) | (rb2012 & ~rb2010 & ~rb2011);
  assign rb2018 = (rb2011 & ~rb2012 & ~rb2013) | (rb2013 & ~rb2010 & ~rb2011);
  assign rb2019 = rb2015 | (rb2017 & ~rb2014);
  assign rb2020 = rb2016 | (rb2018 & rb2014);
  assign rb2021 = (rb2017 | rb2018) & rb2014;
  assign rb2022 = (rb2017 | rb2018) & ~rb2014;
  assign rb2023 = 1'b0;
  assign rb2024 = 1'b0;
  assign rb2025 = 1'b0;
  assign rb2026 = 1'b0;
  assign rb2027 = 1'b0 | 1'b0;
  assign rb2028 = rb2023 & rb2025;
  assign rb2029 = rb2024 & rb2026;
  assign rb2030 = (rb2023 & ~rb2025 & ~rb2026) | (rb2025 & ~rb2023 & ~rb2024);
  assign rb2031 = (rb2024 & ~rb2025 & ~rb2026) | (rb2026 & ~rb2023 & ~rb2024);
  assign rb2032 = rb2028 | (rb2030 & ~rb2027);
  assign rb2033 = rb2029 | (rb2031 & rb2027);
  assign rb2034 = (rb2030 | rb2031) & rb2027;
  assign rb2035 = (rb2030 | rb2031) & ~rb2027;
  assign rb2036 = 1'b0;
  assign rb2037 = 1'b0;
  assign rb2038 = 1'b0;
  assign rb2039 = 1'b0;
  assign rb2040 = 1'b0 | 1'b0;
  assign rb2041 = rb2036 & rb2038;
  assign rb2042 = rb2037 & rb2039;
  assign rb2043 = (rb2036 & ~rb2038 & ~rb2039) | (rb2038 & ~rb2036 & ~rb2037);
  assign rb2044 = (rb2037 & ~rb2038 & ~rb2039) | (rb2039 & ~rb2036 & ~rb2037);
  assign rb2045 = rb2041 | (rb2043 & ~rb2040);
  assign rb2046 = rb2042 | (rb2044 & rb2040);
  assign rb2047 = (rb2043 | rb2044) & rb2040;
  assign rb2048 = (rb2043 | rb2044) & ~rb2040;
  assign rb2049 = 1'b0;
  assign rb2050 = 1'b0;
  assign rb2051 = 1'b0;
  assign rb2052 = 1'b0;
  assign rb2053 = 1'b0 | 1'b0;
  assign rb2054 = rb2049 & rb2051;
  assign rb2055 = rb2050 & rb2052;
  assign rb2056 = (rb2049 & ~rb2051 & ~rb2052) | (rb2051 & ~rb2049 & ~rb2050);
  assign rb2057 = (rb2050 & ~rb2051 & ~rb2052) | (rb2052 & ~rb2049 & ~rb2050);
  assign rb2058 = rb2054 | (rb2056 & ~rb2053);
  assign rb2059 = rb2055 | (rb2057 & rb2053);
  assign rb2060 = (rb2056 | rb2057) & rb2053;
  assign rb2061 = (rb2056 | rb2057) & ~rb2053;
  assign rb2062 = 1'b0;
  assign rb2063 = 1'b0;
  assign rb2064 = 1'b0;
  assign rb2065 = 1'b0;
  assign rb2066 = 1'b0 | 1'b0;
  assign rb2067 = rb2062 & rb2064;
  assign rb2068 = rb2063 & rb2065;
  assign rb2069 = (rb2062 & ~rb2064 & ~rb2065) | (rb2064 & ~rb2062 & ~rb2063);
  assign rb2070 = (rb2063 & ~rb2064 & ~rb2065) | (rb2065 & ~rb2062 & ~rb2063);
  assign rb2071 = rb2067 | (rb2069 & ~rb2066);
  assign rb2072 = rb2068 | (rb2070 & rb2066);
  assign rb2073 = (rb2069 | rb2070) & rb2066;
  assign rb2074 = (rb2069 | rb2070) & ~rb2066;
  assign rb2075 = 1'b0;
  assign rb2076 = 1'b0;
  assign rb2077 = 1'b0;
  assign rb2078 = 1'b0;
  assign rb2079 = 1'b0 | 1'b0;
  assign rb2080 = rb2075 & rb2077;
  assign rb2081 = rb2076 & rb2078;
  assign rb2082 = (rb2075 & ~rb2077 & ~rb2078) | (rb2077 & ~rb2075 & ~rb2076);
  assign rb2083 = (rb2076 & ~rb2077 & ~rb2078) | (rb2078 & ~rb2075 & ~rb2076);
  assign rb2084 = rb2080 | (rb2082 & ~rb2079);
  assign rb2085 = rb2081 | (rb2083 & rb2079);
  assign rb2086 = (rb2082 | rb2083) & rb2079;
  assign rb2087 = (rb2082 | rb2083) & ~rb2079;
  assign rb2088 = 1'b0;
  assign rb2089 = 1'b0;
  assign rb2090 = 1'b0;
  assign rb2091 = 1'b0;
  assign rb2092 = 1'b0 | 1'b0;
  assign rb2093 = rb2088 & rb2090;
  assign rb2094 = rb2089 & rb2091;
  assign rb2095 = (rb2088 & ~rb2090 & ~rb2091) | (rb2090 & ~rb2088 & ~rb2089);
  assign rb2096 = (rb2089 & ~rb2090 & ~rb2091) | (rb2091 & ~rb2088 & ~rb2089);
  assign rb2097 = rb2093 | (rb2095 & ~rb2092);
  assign rb2098 = rb2094 | (rb2096 & rb2092);
  assign rb2099 = (rb2095 | rb2096) & rb2092;
  assign rb2100 = (rb2095 | rb2096) & ~rb2092;
  assign rb2101 = 1'b0;
  assign rb2102 = 1'b0;
  assign rb2103 = 1'b0;
  assign rb2104 = 1'b0;
  assign rb2105 = 1'b0 | 1'b0;
  assign rb2106 = rb2101 & rb2103;
  assign rb2107 = rb2102 & rb2104;
  assign rb2108 = (rb2101 & ~rb2103 & ~rb2104) | (rb2103 & ~rb2101 & ~rb2102);
  assign rb2109 = (rb2102 & ~rb2103 & ~rb2104) | (rb2104 & ~rb2101 & ~rb2102);
  assign rb2110 = rb2106 | (rb2108 & ~rb2105);
  assign rb2111 = rb2107 | (rb2109 & rb2105);
  assign rb2112 = (rb2108 | rb2109) & rb2105;
  assign rb2113 = (rb2108 | rb2109) & ~rb2105;
  assign rb2114 = 1'b0;
  assign rb2115 = 1'b0;
  assign rb2116 = 1'b0;
  assign rb2117 = 1'b0;
  assign rb2118 = 1'b0 | 1'b0;
  assign rb2119 = rb2114 & rb2116;
  assign rb2120 = rb2115 & rb2117;
  assign rb2121 = (rb2114 & ~rb2116 & ~rb2117) | (rb2116 & ~rb2114 & ~rb2115);
  assign rb2122 = (rb2115 & ~rb2116 & ~rb2117) | (rb2117 & ~rb2114 & ~rb2115);
  assign rb2123 = rb2119 | (rb2121 & ~rb2118);
  assign rb2124 = rb2120 | (rb2122 & rb2118);
  assign rb2125 = (rb2121 | rb2122) & rb2118;
  assign rb2126 = (rb2121 | rb2122) & ~rb2118;
  assign rb2127 = 1'b0;
  assign rb2128 = 1'b0;
  assign rb2129 = 1'b0;
  assign rb2130 = 1'b0;
  assign rb2131 = 1'b0 | 1'b0;
  assign rb2132 = rb2127 & rb2129;
  assign rb2133 = rb2128 & rb2130;
  assign rb2134 = (rb2127 & ~rb2129 & ~rb2130) | (rb2129 & ~rb2127 & ~rb2128);
  assign rb2135 = (rb2128 & ~rb2129 & ~rb2130) | (rb2130 & ~rb2127 & ~rb2128);
  assign rb2136 = rb2132 | (rb2134 & ~rb2131);
  assign rb2137 = rb2133 | (rb2135 & rb2131);
  assign rb2138 = (rb2134 | rb2135) & rb2131;
  assign rb2139 = (rb2134 | rb2135) & ~rb2131;
  assign rb2140 = 1'b0;
  assign rb2141 = 1'b0;
  assign rb2142 = 1'b0;
  assign rb2143 = 1'b0;
  assign rb2144 = 1'b0 | 1'b0;
  assign rb2145 = rb2140 & rb2142;
  assign rb2146 = rb2141 & rb2143;
  assign rb2147 = (rb2140 & ~rb2142 & ~rb2143) | (rb2142 & ~rb2140 & ~rb2141);
  assign rb2148 = (rb2141 & ~rb2142 & ~rb2143) | (rb2143 & ~rb2140 & ~rb2141);
  assign rb2149 = rb2145 | (rb2147 & ~rb2144);
  assign rb2150 = rb2146 | (rb2148 & rb2144);
  assign rb2151 = (rb2147 | rb2148) & rb2144;
  assign rb2152 = (rb2147 | rb2148) & ~rb2144;
  assign rb2153 = 1'b0;
  assign rb2154 = 1'b0;
  assign rb2155 = 1'b0;
  assign rb2156 = 1'b0;
  assign rb2157 = 1'b0 | 1'b0;
  assign rb2158 = rb2153 & rb2155;
  assign rb2159 = rb2154 & rb2156;
  assign rb2160 = (rb2153 & ~rb2155 & ~rb2156) | (rb2155 & ~rb2153 & ~rb2154);
  assign rb2161 = (rb2154 & ~rb2155 & ~rb2156) | (rb2156 & ~rb2153 & ~rb2154);
  assign rb2162 = rb2158 | (rb2160 & ~rb2157);
  assign rb2163 = rb2159 | (rb2161 & rb2157);
  assign rb2164 = (rb2160 | rb2161) & rb2157;
  assign rb2165 = (rb2160 | rb2161) & ~rb2157;
  assign rb2166 = (rb1735 & ~1'b0) | (1'b0 & ~rb1736);
  assign rb2167 = (rb1736 & ~1'b0) | (1'b0 & ~rb1735);
  assign rb2168 = (rb1748 & ~rb1734) | (rb1733 & ~rb1749);
  assign rb2169 = (rb1749 & ~rb1733) | (rb1734 & ~rb1748);
  assign rb2170 = (rb1761 & ~rb1747) | (rb1746 & ~rb1762);
  assign rb2171 = (rb1762 & ~rb1746) | (rb1747 & ~rb1761);
  assign rb2172 = (rb1774 & ~rb1760) | (rb1759 & ~rb1775);
  assign rb2173 = (rb1775 & ~rb1759) | (rb1760 & ~rb1774);
  assign rb2174 = (rb1787 & ~rb1773) | (rb1772 & ~rb1788);
  assign rb2175 = (rb1788 & ~rb1772) | (rb1773 & ~rb1787);
  assign rb2176 = (rb1800 & ~rb1786) | (rb1785 & ~rb1801);
  assign rb2177 = (rb1801 & ~rb1785) | (rb1786 & ~rb1800);
  assign rb2178 = (rb1813 & ~rb1799) | (rb1798 & ~rb1814);
  assign rb2179 = (rb1814 & ~rb1798) | (rb1799 & ~rb1813);
  assign rb2180 = (rb1826 & ~rb1812) | (rb1811 & ~rb1827);
  assign rb2181 = (rb1827 & ~rb1811) | (rb1812 & ~rb1826);
  assign rb2182 = (rb1839 & ~rb1825) | (rb1824 & ~rb1840);
  assign rb2183 = (rb1840 & ~rb1824) | (rb1825 & ~rb1839);
  assign rb2184 = (rb1852 & ~rb1838) | (rb1837 & ~rb1853);
  assign rb2185 = (rb1853 & ~rb1837) | (rb1838 & ~rb1852);
  assign rb2186 = (rb1865 & ~rb1851) | (rb1850 & ~rb1866);
  assign rb2187 = (rb1866 & ~rb1850) | (rb1851 & ~rb1865);
  assign rb2188 = (rb1878 & ~rb1864) | (rb1863 & ~rb1879);
  assign rb2189 = (rb1879 & ~rb1863) | (rb1864 & ~rb1878);
  assign rb2190 = (rb1891 & ~rb1877) | (rb1876 & ~rb1892);
  assign rb2191 = (rb1892 & ~rb1876) | (rb1877 & ~rb1891);
  assign rb2192 = (rb1904 & ~rb1890) | (rb1889 & ~rb1905);
  assign rb2193 = (rb1905 & ~rb1889) | (rb1890 & ~rb1904);
  assign rb2194 = (rb1917 & ~rb1903) | (rb1902 & ~rb1918);
  assign rb2195 = (rb1918 & ~rb1902) | (rb1903 & ~rb1917);
  assign rb2196 = (rb1930 & ~rb1916) | (rb1915 & ~rb1931);
  assign rb2197 = (rb1931 & ~rb1915) | (rb1916 & ~rb1930);
  assign rb2198 = (rb1943 & ~rb1929) | (rb1928 & ~rb1944);
  assign rb2199 = (rb1944 & ~rb1928) | (rb1929 & ~rb1943);
  assign rb2200 = (rb1956 & ~rb1942) | (rb1941 & ~rb1957);
  assign rb2201 = (rb1957 & ~rb1941) | (rb1942 & ~rb1956);
  assign rb2202 = (rb1969 & ~rb1955) | (rb1954 & ~rb1970);
  assign rb2203 = (rb1970 & ~rb1954) | (rb1955 & ~rb1969);
  assign rb2204 = (rb1982 & ~rb1968) | (rb1967 & ~rb1983);
  assign rb2205 = (rb1983 & ~rb1967) | (rb1968 & ~rb1982);
  assign rb2206 = (rb1995 & ~rb1981) | (rb1980 & ~rb1996);
  assign rb2207 = (rb1996 & ~rb1980) | (rb1981 & ~rb1995);
  assign rb2208 = (rb2008 & ~rb1994) | (rb1993 & ~rb2009);
  assign rb2209 = (rb2009 & ~rb1993) | (rb1994 & ~rb2008);
  assign rb2210 = (rb2021 & ~rb2007) | (rb2006 & ~rb2022);
  assign rb2211 = (rb2022 & ~rb2006) | (rb2007 & ~rb2021);
  assign rb2212 = (rb2034 & ~rb2020) | (rb2019 & ~rb2035);
  assign rb2213 = (rb2035 & ~rb2019) | (rb2020 & ~rb2034);
  assign rb2214 = (rb2047 & ~rb2033) | (rb2032 & ~rb2048);
  assign rb2215 = (rb2048 & ~rb2032) | (rb2033 & ~rb2047);
  assign rb2216 = (rb2060 & ~rb2046) | (rb2045 & ~rb2061);
  assign rb2217 = (rb2061 & ~rb2045) | (rb2046 & ~rb2060);
  assign rb2218 = (rb2073 & ~rb2059) | (rb2058 & ~rb2074);
  assign rb2219 = (rb2074 & ~rb2058) | (rb2059 & ~rb2073);
  assign rb2220 = (rb2086 & ~rb2072) | (rb2071 & ~rb2087);
  assign rb2221 = (rb2087 & ~rb2071) | (rb2072 & ~rb2086);
  assign rb2222 = (rb2099 & ~rb2085) | (rb2084 & ~rb2100);
  assign rb2223 = (rb2100 & ~rb2084) | (rb2085 & ~rb2099);
  assign rb2224 = (rb2112 & ~rb2098) | (rb2097 & ~rb2113);
  assign rb2225 = (rb2113 & ~rb2097) | (rb2098 & ~rb2112);
  assign rb2226 = (rb2125 & ~rb2111) | (rb2110 & ~rb2126);
  assign rb2227 = (rb2126 & ~rb2110) | (rb2111 & ~rb2125);
  assign rb2228 = (rb2138 & ~rb2124) | (rb2123 & ~rb2139);
  assign rb2229 = (rb2139 & ~rb2123) | (rb2124 & ~rb2138);
  assign rb2230 = (rb2151 & ~rb2137) | (rb2136 & ~rb2152);
  assign rb2231 = (rb2152 & ~rb2136) | (rb2137 & ~rb2151);
  assign rb2232 = (rb2164 & ~rb2150) | (rb2149 & ~rb2165);
  assign rb2233 = (rb2165 & ~rb2149) | (rb2150 & ~rb2164);
  assign rb2234 = (1'b0 & ~rb2163) | (rb2162 & ~1'b0);
  assign rb2235 = (1'b0 & ~rb2162) | (rb2163 & ~1'b0);
  assign rb2236 = rb633;
  assign rb2237 = rb634;
  assign rb2238 = rb1144;
  assign rb2239 = rb1145;
  assign rb2240 = rb2236 & rb2238;
  assign rb2241 = rb2237 & rb2239;
  assign rb2242 = (rb2236 & ~rb2238 & ~rb2239) | (rb2238 & ~rb2236 & ~rb2237);
  assign rb2243 = (rb2237 & ~rb2238 & ~rb2239) | (rb2239 & ~rb2236 & ~rb2237);
  assign rb2244 = rb2240 | (rb2242 & ~1'b0);
  assign rb2245 = rb2241 | (rb2243 & 1'b0);
  assign rb2246 = (rb2242 | rb2243) & 1'b0;
  assign rb2247 = (rb2242 | rb2243) & ~1'b0;
  assign rb2248 = rb635;
  assign rb2249 = rb636;
  assign rb2250 = rb1146;
  assign rb2251 = rb1147;
  assign rb2252 = rb634 | rb1145;
  assign rb2253 = rb2248 & rb2250;
  assign rb2254 = rb2249 & rb2251;
  assign rb2255 = (rb2248 & ~rb2250 & ~rb2251) | (rb2250 & ~rb2248 & ~rb2249);
  assign rb2256 = (rb2249 & ~rb2250 & ~rb2251) | (rb2251 & ~rb2248 & ~rb2249);
  assign rb2257 = rb2253 | (rb2255 & ~rb2252);
  assign rb2258 = rb2254 | (rb2256 & rb2252);
  assign rb2259 = (rb2255 | rb2256) & rb2252;
  assign rb2260 = (rb2255 | rb2256) & ~rb2252;
  assign rb2261 = rb637;
  assign rb2262 = rb638;
  assign rb2263 = rb1148;
  assign rb2264 = rb1149;
  assign rb2265 = rb636 | rb1147;
  assign rb2266 = rb2261 & rb2263;
  assign rb2267 = rb2262 & rb2264;
  assign rb2268 = (rb2261 & ~rb2263 & ~rb2264) | (rb2263 & ~rb2261 & ~rb2262);
  assign rb2269 = (rb2262 & ~rb2263 & ~rb2264) | (rb2264 & ~rb2261 & ~rb2262);
  assign rb2270 = rb2266 | (rb2268 & ~rb2265);
  assign rb2271 = rb2267 | (rb2269 & rb2265);
  assign rb2272 = (rb2268 | rb2269) & rb2265;
  assign rb2273 = (rb2268 | rb2269) & ~rb2265;
  assign rb2274 = rb639;
  assign rb2275 = rb640;
  assign rb2276 = rb1150;
  assign rb2277 = rb1151;
  assign rb2278 = rb638 | rb1149;
  assign rb2279 = rb2274 & rb2276;
  assign rb2280 = rb2275 & rb2277;
  assign rb2281 = (rb2274 & ~rb2276 & ~rb2277) | (rb2276 & ~rb2274 & ~rb2275);
  assign rb2282 = (rb2275 & ~rb2276 & ~rb2277) | (rb2277 & ~rb2274 & ~rb2275);
  assign rb2283 = rb2279 | (rb2281 & ~rb2278);
  assign rb2284 = rb2280 | (rb2282 & rb2278);
  assign rb2285 = (rb2281 | rb2282) & rb2278;
  assign rb2286 = (rb2281 | rb2282) & ~rb2278;
  assign rb2287 = rb641;
  assign rb2288 = rb642;
  assign rb2289 = rb1152;
  assign rb2290 = rb1153;
  assign rb2291 = rb640 | rb1151;
  assign rb2292 = rb2287 & rb2289;
  assign rb2293 = rb2288 & rb2290;
  assign rb2294 = (rb2287 & ~rb2289 & ~rb2290) | (rb2289 & ~rb2287 & ~rb2288);
  assign rb2295 = (rb2288 & ~rb2289 & ~rb2290) | (rb2290 & ~rb2287 & ~rb2288);
  assign rb2296 = rb2292 | (rb2294 & ~rb2291);
  assign rb2297 = rb2293 | (rb2295 & rb2291);
  assign rb2298 = (rb2294 | rb2295) & rb2291;
  assign rb2299 = (rb2294 | rb2295) & ~rb2291;
  assign rb2300 = rb643;
  assign rb2301 = rb644;
  assign rb2302 = rb1154;
  assign rb2303 = rb1155;
  assign rb2304 = rb642 | rb1153;
  assign rb2305 = rb2300 & rb2302;
  assign rb2306 = rb2301 & rb2303;
  assign rb2307 = (rb2300 & ~rb2302 & ~rb2303) | (rb2302 & ~rb2300 & ~rb2301);
  assign rb2308 = (rb2301 & ~rb2302 & ~rb2303) | (rb2303 & ~rb2300 & ~rb2301);
  assign rb2309 = rb2305 | (rb2307 & ~rb2304);
  assign rb2310 = rb2306 | (rb2308 & rb2304);
  assign rb2311 = (rb2307 | rb2308) & rb2304;
  assign rb2312 = (rb2307 | rb2308) & ~rb2304;
  assign rb2313 = rb645;
  assign rb2314 = rb646;
  assign rb2315 = rb1156;
  assign rb2316 = rb1157;
  assign rb2317 = rb644 | rb1155;
  assign rb2318 = rb2313 & rb2315;
  assign rb2319 = rb2314 & rb2316;
  assign rb2320 = (rb2313 & ~rb2315 & ~rb2316) | (rb2315 & ~rb2313 & ~rb2314);
  assign rb2321 = (rb2314 & ~rb2315 & ~rb2316) | (rb2316 & ~rb2313 & ~rb2314);
  assign rb2322 = rb2318 | (rb2320 & ~rb2317);
  assign rb2323 = rb2319 | (rb2321 & rb2317);
  assign rb2324 = (rb2320 | rb2321) & rb2317;
  assign rb2325 = (rb2320 | rb2321) & ~rb2317;
  assign rb2326 = rb647;
  assign rb2327 = rb648;
  assign rb2328 = rb1158;
  assign rb2329 = rb1159;
  assign rb2330 = rb646 | rb1157;
  assign rb2331 = rb2326 & rb2328;
  assign rb2332 = rb2327 & rb2329;
  assign rb2333 = (rb2326 & ~rb2328 & ~rb2329) | (rb2328 & ~rb2326 & ~rb2327);
  assign rb2334 = (rb2327 & ~rb2328 & ~rb2329) | (rb2329 & ~rb2326 & ~rb2327);
  assign rb2335 = rb2331 | (rb2333 & ~rb2330);
  assign rb2336 = rb2332 | (rb2334 & rb2330);
  assign rb2337 = (rb2333 | rb2334) & rb2330;
  assign rb2338 = (rb2333 | rb2334) & ~rb2330;
  assign rb2339 = rb649;
  assign rb2340 = rb650;
  assign rb2341 = rb1160;
  assign rb2342 = rb1161;
  assign rb2343 = rb648 | rb1159;
  assign rb2344 = rb2339 & rb2341;
  assign rb2345 = rb2340 & rb2342;
  assign rb2346 = (rb2339 & ~rb2341 & ~rb2342) | (rb2341 & ~rb2339 & ~rb2340);
  assign rb2347 = (rb2340 & ~rb2341 & ~rb2342) | (rb2342 & ~rb2339 & ~rb2340);
  assign rb2348 = rb2344 | (rb2346 & ~rb2343);
  assign rb2349 = rb2345 | (rb2347 & rb2343);
  assign rb2350 = (rb2346 | rb2347) & rb2343;
  assign rb2351 = (rb2346 | rb2347) & ~rb2343;
  assign rb2352 = rb651;
  assign rb2353 = rb652;
  assign rb2354 = rb1162;
  assign rb2355 = rb1163;
  assign rb2356 = rb650 | rb1161;
  assign rb2357 = rb2352 & rb2354;
  assign rb2358 = rb2353 & rb2355;
  assign rb2359 = (rb2352 & ~rb2354 & ~rb2355) | (rb2354 & ~rb2352 & ~rb2353);
  assign rb2360 = (rb2353 & ~rb2354 & ~rb2355) | (rb2355 & ~rb2352 & ~rb2353);
  assign rb2361 = rb2357 | (rb2359 & ~rb2356);
  assign rb2362 = rb2358 | (rb2360 & rb2356);
  assign rb2363 = (rb2359 | rb2360) & rb2356;
  assign rb2364 = (rb2359 | rb2360) & ~rb2356;
  assign rb2365 = rb653;
  assign rb2366 = rb654;
  assign rb2367 = rb1164;
  assign rb2368 = rb1165;
  assign rb2369 = rb652 | rb1163;
  assign rb2370 = rb2365 & rb2367;
  assign rb2371 = rb2366 & rb2368;
  assign rb2372 = (rb2365 & ~rb2367 & ~rb2368) | (rb2367 & ~rb2365 & ~rb2366);
  assign rb2373 = (rb2366 & ~rb2367 & ~rb2368) | (rb2368 & ~rb2365 & ~rb2366);
  assign rb2374 = rb2370 | (rb2372 & ~rb2369);
  assign rb2375 = rb2371 | (rb2373 & rb2369);
  assign rb2376 = (rb2372 | rb2373) & rb2369;
  assign rb2377 = (rb2372 | rb2373) & ~rb2369;
  assign rb2378 = rb655;
  assign rb2379 = rb656;
  assign rb2380 = rb1166;
  assign rb2381 = rb1167;
  assign rb2382 = rb654 | rb1165;
  assign rb2383 = rb2378 & rb2380;
  assign rb2384 = rb2379 & rb2381;
  assign rb2385 = (rb2378 & ~rb2380 & ~rb2381) | (rb2380 & ~rb2378 & ~rb2379);
  assign rb2386 = (rb2379 & ~rb2380 & ~rb2381) | (rb2381 & ~rb2378 & ~rb2379);
  assign rb2387 = rb2383 | (rb2385 & ~rb2382);
  assign rb2388 = rb2384 | (rb2386 & rb2382);
  assign rb2389 = (rb2385 | rb2386) & rb2382;
  assign rb2390 = (rb2385 | rb2386) & ~rb2382;
  assign rb2391 = rb657;
  assign rb2392 = rb658;
  assign rb2393 = rb1168;
  assign rb2394 = rb1169;
  assign rb2395 = rb656 | rb1167;
  assign rb2396 = rb2391 & rb2393;
  assign rb2397 = rb2392 & rb2394;
  assign rb2398 = (rb2391 & ~rb2393 & ~rb2394) | (rb2393 & ~rb2391 & ~rb2392);
  assign rb2399 = (rb2392 & ~rb2393 & ~rb2394) | (rb2394 & ~rb2391 & ~rb2392);
  assign rb2400 = rb2396 | (rb2398 & ~rb2395);
  assign rb2401 = rb2397 | (rb2399 & rb2395);
  assign rb2402 = (rb2398 | rb2399) & rb2395;
  assign rb2403 = (rb2398 | rb2399) & ~rb2395;
  assign rb2404 = rb659;
  assign rb2405 = rb660;
  assign rb2406 = rb1170;
  assign rb2407 = rb1171;
  assign rb2408 = rb658 | rb1169;
  assign rb2409 = rb2404 & rb2406;
  assign rb2410 = rb2405 & rb2407;
  assign rb2411 = (rb2404 & ~rb2406 & ~rb2407) | (rb2406 & ~rb2404 & ~rb2405);
  assign rb2412 = (rb2405 & ~rb2406 & ~rb2407) | (rb2407 & ~rb2404 & ~rb2405);
  assign rb2413 = rb2409 | (rb2411 & ~rb2408);
  assign rb2414 = rb2410 | (rb2412 & rb2408);
  assign rb2415 = (rb2411 | rb2412) & rb2408;
  assign rb2416 = (rb2411 | rb2412) & ~rb2408;
  assign rb2417 = rb661;
  assign rb2418 = rb662;
  assign rb2419 = rb1172;
  assign rb2420 = rb1173;
  assign rb2421 = rb660 | rb1171;
  assign rb2422 = rb2417 & rb2419;
  assign rb2423 = rb2418 & rb2420;
  assign rb2424 = (rb2417 & ~rb2419 & ~rb2420) | (rb2419 & ~rb2417 & ~rb2418);
  assign rb2425 = (rb2418 & ~rb2419 & ~rb2420) | (rb2420 & ~rb2417 & ~rb2418);
  assign rb2426 = rb2422 | (rb2424 & ~rb2421);
  assign rb2427 = rb2423 | (rb2425 & rb2421);
  assign rb2428 = (rb2424 | rb2425) & rb2421;
  assign rb2429 = (rb2424 | rb2425) & ~rb2421;
  assign rb2430 = rb663;
  assign rb2431 = rb664;
  assign rb2432 = rb1174;
  assign rb2433 = rb1175;
  assign rb2434 = rb662 | rb1173;
  assign rb2435 = rb2430 & rb2432;
  assign rb2436 = rb2431 & rb2433;
  assign rb2437 = (rb2430 & ~rb2432 & ~rb2433) | (rb2432 & ~rb2430 & ~rb2431);
  assign rb2438 = (rb2431 & ~rb2432 & ~rb2433) | (rb2433 & ~rb2430 & ~rb2431);
  assign rb2439 = rb2435 | (rb2437 & ~rb2434);
  assign rb2440 = rb2436 | (rb2438 & rb2434);
  assign rb2441 = (rb2437 | rb2438) & rb2434;
  assign rb2442 = (rb2437 | rb2438) & ~rb2434;
  assign rb2443 = rb665;
  assign rb2444 = rb666;
  assign rb2445 = rb1176;
  assign rb2446 = rb1177;
  assign rb2447 = rb664 | rb1175;
  assign rb2448 = rb2443 & rb2445;
  assign rb2449 = rb2444 & rb2446;
  assign rb2450 = (rb2443 & ~rb2445 & ~rb2446) | (rb2445 & ~rb2443 & ~rb2444);
  assign rb2451 = (rb2444 & ~rb2445 & ~rb2446) | (rb2446 & ~rb2443 & ~rb2444);
  assign rb2452 = rb2448 | (rb2450 & ~rb2447);
  assign rb2453 = rb2449 | (rb2451 & rb2447);
  assign rb2454 = (rb2450 | rb2451) & rb2447;
  assign rb2455 = (rb2450 | rb2451) & ~rb2447;
  assign rb2456 = rb667;
  assign rb2457 = rb668;
  assign rb2458 = rb1178;
  assign rb2459 = rb1179;
  assign rb2460 = rb666 | rb1177;
  assign rb2461 = rb2456 & rb2458;
  assign rb2462 = rb2457 & rb2459;
  assign rb2463 = (rb2456 & ~rb2458 & ~rb2459) | (rb2458 & ~rb2456 & ~rb2457);
  assign rb2464 = (rb2457 & ~rb2458 & ~rb2459) | (rb2459 & ~rb2456 & ~rb2457);
  assign rb2465 = rb2461 | (rb2463 & ~rb2460);
  assign rb2466 = rb2462 | (rb2464 & rb2460);
  assign rb2467 = (rb2463 | rb2464) & rb2460;
  assign rb2468 = (rb2463 | rb2464) & ~rb2460;
  assign rb2469 = rb669;
  assign rb2470 = rb670;
  assign rb2471 = rb1180;
  assign rb2472 = rb1181;
  assign rb2473 = rb668 | rb1179;
  assign rb2474 = rb2469 & rb2471;
  assign rb2475 = rb2470 & rb2472;
  assign rb2476 = (rb2469 & ~rb2471 & ~rb2472) | (rb2471 & ~rb2469 & ~rb2470);
  assign rb2477 = (rb2470 & ~rb2471 & ~rb2472) | (rb2472 & ~rb2469 & ~rb2470);
  assign rb2478 = rb2474 | (rb2476 & ~rb2473);
  assign rb2479 = rb2475 | (rb2477 & rb2473);
  assign rb2480 = (rb2476 | rb2477) & rb2473;
  assign rb2481 = (rb2476 | rb2477) & ~rb2473;
  assign rb2482 = rb671;
  assign rb2483 = rb672;
  assign rb2484 = rb1182;
  assign rb2485 = rb1183;
  assign rb2486 = rb670 | rb1181;
  assign rb2487 = rb2482 & rb2484;
  assign rb2488 = rb2483 & rb2485;
  assign rb2489 = (rb2482 & ~rb2484 & ~rb2485) | (rb2484 & ~rb2482 & ~rb2483);
  assign rb2490 = (rb2483 & ~rb2484 & ~rb2485) | (rb2485 & ~rb2482 & ~rb2483);
  assign rb2491 = rb2487 | (rb2489 & ~rb2486);
  assign rb2492 = rb2488 | (rb2490 & rb2486);
  assign rb2493 = (rb2489 | rb2490) & rb2486;
  assign rb2494 = (rb2489 | rb2490) & ~rb2486;
  assign rb2495 = rb673;
  assign rb2496 = rb674;
  assign rb2497 = rb1184;
  assign rb2498 = rb1185;
  assign rb2499 = rb672 | rb1183;
  assign rb2500 = rb2495 & rb2497;
  assign rb2501 = rb2496 & rb2498;
  assign rb2502 = (rb2495 & ~rb2497 & ~rb2498) | (rb2497 & ~rb2495 & ~rb2496);
  assign rb2503 = (rb2496 & ~rb2497 & ~rb2498) | (rb2498 & ~rb2495 & ~rb2496);
  assign rb2504 = rb2500 | (rb2502 & ~rb2499);
  assign rb2505 = rb2501 | (rb2503 & rb2499);
  assign rb2506 = (rb2502 | rb2503) & rb2499;
  assign rb2507 = (rb2502 | rb2503) & ~rb2499;
  assign rb2508 = rb675;
  assign rb2509 = rb676;
  assign rb2510 = rb1186;
  assign rb2511 = rb1187;
  assign rb2512 = rb674 | rb1185;
  assign rb2513 = rb2508 & rb2510;
  assign rb2514 = rb2509 & rb2511;
  assign rb2515 = (rb2508 & ~rb2510 & ~rb2511) | (rb2510 & ~rb2508 & ~rb2509);
  assign rb2516 = (rb2509 & ~rb2510 & ~rb2511) | (rb2511 & ~rb2508 & ~rb2509);
  assign rb2517 = rb2513 | (rb2515 & ~rb2512);
  assign rb2518 = rb2514 | (rb2516 & rb2512);
  assign rb2519 = (rb2515 | rb2516) & rb2512;
  assign rb2520 = (rb2515 | rb2516) & ~rb2512;
  assign rb2521 = rb677;
  assign rb2522 = rb678;
  assign rb2523 = rb1188;
  assign rb2524 = rb1189;
  assign rb2525 = rb676 | rb1187;
  assign rb2526 = rb2521 & rb2523;
  assign rb2527 = rb2522 & rb2524;
  assign rb2528 = (rb2521 & ~rb2523 & ~rb2524) | (rb2523 & ~rb2521 & ~rb2522);
  assign rb2529 = (rb2522 & ~rb2523 & ~rb2524) | (rb2524 & ~rb2521 & ~rb2522);
  assign rb2530 = rb2526 | (rb2528 & ~rb2525);
  assign rb2531 = rb2527 | (rb2529 & rb2525);
  assign rb2532 = (rb2528 | rb2529) & rb2525;
  assign rb2533 = (rb2528 | rb2529) & ~rb2525;
  assign rb2534 = rb679;
  assign rb2535 = rb680;
  assign rb2536 = rb1190;
  assign rb2537 = rb1191;
  assign rb2538 = rb678 | rb1189;
  assign rb2539 = rb2534 & rb2536;
  assign rb2540 = rb2535 & rb2537;
  assign rb2541 = (rb2534 & ~rb2536 & ~rb2537) | (rb2536 & ~rb2534 & ~rb2535);
  assign rb2542 = (rb2535 & ~rb2536 & ~rb2537) | (rb2537 & ~rb2534 & ~rb2535);
  assign rb2543 = rb2539 | (rb2541 & ~rb2538);
  assign rb2544 = rb2540 | (rb2542 & rb2538);
  assign rb2545 = (rb2541 | rb2542) & rb2538;
  assign rb2546 = (rb2541 | rb2542) & ~rb2538;
  assign rb2547 = rb681;
  assign rb2548 = rb682;
  assign rb2549 = rb1192;
  assign rb2550 = rb1193;
  assign rb2551 = rb680 | rb1191;
  assign rb2552 = rb2547 & rb2549;
  assign rb2553 = rb2548 & rb2550;
  assign rb2554 = (rb2547 & ~rb2549 & ~rb2550) | (rb2549 & ~rb2547 & ~rb2548);
  assign rb2555 = (rb2548 & ~rb2549 & ~rb2550) | (rb2550 & ~rb2547 & ~rb2548);
  assign rb2556 = rb2552 | (rb2554 & ~rb2551);
  assign rb2557 = rb2553 | (rb2555 & rb2551);
  assign rb2558 = (rb2554 | rb2555) & rb2551;
  assign rb2559 = (rb2554 | rb2555) & ~rb2551;
  assign rb2560 = rb683;
  assign rb2561 = rb684;
  assign rb2562 = rb1194;
  assign rb2563 = rb1195;
  assign rb2564 = rb682 | rb1193;
  assign rb2565 = rb2560 & rb2562;
  assign rb2566 = rb2561 & rb2563;
  assign rb2567 = (rb2560 & ~rb2562 & ~rb2563) | (rb2562 & ~rb2560 & ~rb2561);
  assign rb2568 = (rb2561 & ~rb2562 & ~rb2563) | (rb2563 & ~rb2560 & ~rb2561);
  assign rb2569 = rb2565 | (rb2567 & ~rb2564);
  assign rb2570 = rb2566 | (rb2568 & rb2564);
  assign rb2571 = (rb2567 | rb2568) & rb2564;
  assign rb2572 = (rb2567 | rb2568) & ~rb2564;
  assign rb2573 = rb685;
  assign rb2574 = rb686;
  assign rb2575 = rb1196;
  assign rb2576 = rb1197;
  assign rb2577 = rb684 | rb1195;
  assign rb2578 = rb2573 & rb2575;
  assign rb2579 = rb2574 & rb2576;
  assign rb2580 = (rb2573 & ~rb2575 & ~rb2576) | (rb2575 & ~rb2573 & ~rb2574);
  assign rb2581 = (rb2574 & ~rb2575 & ~rb2576) | (rb2576 & ~rb2573 & ~rb2574);
  assign rb2582 = rb2578 | (rb2580 & ~rb2577);
  assign rb2583 = rb2579 | (rb2581 & rb2577);
  assign rb2584 = (rb2580 | rb2581) & rb2577;
  assign rb2585 = (rb2580 | rb2581) & ~rb2577;
  assign rb2586 = rb687;
  assign rb2587 = rb688;
  assign rb2588 = rb1198;
  assign rb2589 = rb1199;
  assign rb2590 = rb686 | rb1197;
  assign rb2591 = rb2586 & rb2588;
  assign rb2592 = rb2587 & rb2589;
  assign rb2593 = (rb2586 & ~rb2588 & ~rb2589) | (rb2588 & ~rb2586 & ~rb2587);
  assign rb2594 = (rb2587 & ~rb2588 & ~rb2589) | (rb2589 & ~rb2586 & ~rb2587);
  assign rb2595 = rb2591 | (rb2593 & ~rb2590);
  assign rb2596 = rb2592 | (rb2594 & rb2590);
  assign rb2597 = (rb2593 | rb2594) & rb2590;
  assign rb2598 = (rb2593 | rb2594) & ~rb2590;
  assign rb2599 = rb689;
  assign rb2600 = rb690;
  assign rb2601 = rb1200;
  assign rb2602 = rb1201;
  assign rb2603 = rb688 | rb1199;
  assign rb2604 = rb2599 & rb2601;
  assign rb2605 = rb2600 & rb2602;
  assign rb2606 = (rb2599 & ~rb2601 & ~rb2602) | (rb2601 & ~rb2599 & ~rb2600);
  assign rb2607 = (rb2600 & ~rb2601 & ~rb2602) | (rb2602 & ~rb2599 & ~rb2600);
  assign rb2608 = rb2604 | (rb2606 & ~rb2603);
  assign rb2609 = rb2605 | (rb2607 & rb2603);
  assign rb2610 = (rb2606 | rb2607) & rb2603;
  assign rb2611 = (rb2606 | rb2607) & ~rb2603;
  assign rb2612 = rb691;
  assign rb2613 = rb692;
  assign rb2614 = rb1202;
  assign rb2615 = rb1203;
  assign rb2616 = rb690 | rb1201;
  assign rb2617 = rb2612 & rb2614;
  assign rb2618 = rb2613 & rb2615;
  assign rb2619 = (rb2612 & ~rb2614 & ~rb2615) | (rb2614 & ~rb2612 & ~rb2613);
  assign rb2620 = (rb2613 & ~rb2614 & ~rb2615) | (rb2615 & ~rb2612 & ~rb2613);
  assign rb2621 = rb2617 | (rb2619 & ~rb2616);
  assign rb2622 = rb2618 | (rb2620 & rb2616);
  assign rb2623 = (rb2619 | rb2620) & rb2616;
  assign rb2624 = (rb2619 | rb2620) & ~rb2616;
  assign rb2625 = rb693;
  assign rb2626 = rb694;
  assign rb2627 = rb1204;
  assign rb2628 = rb1205;
  assign rb2629 = rb692 | rb1203;
  assign rb2630 = rb2625 & rb2627;
  assign rb2631 = rb2626 & rb2628;
  assign rb2632 = (rb2625 & ~rb2627 & ~rb2628) | (rb2627 & ~rb2625 & ~rb2626);
  assign rb2633 = (rb2626 & ~rb2627 & ~rb2628) | (rb2628 & ~rb2625 & ~rb2626);
  assign rb2634 = rb2630 | (rb2632 & ~rb2629);
  assign rb2635 = rb2631 | (rb2633 & rb2629);
  assign rb2636 = (rb2632 | rb2633) & rb2629;
  assign rb2637 = (rb2632 | rb2633) & ~rb2629;
  assign rb2638 = rb695;
  assign rb2639 = rb696;
  assign rb2640 = rb1206;
  assign rb2641 = rb1207;
  assign rb2642 = rb694 | rb1205;
  assign rb2643 = rb2638 & rb2640;
  assign rb2644 = rb2639 & rb2641;
  assign rb2645 = (rb2638 & ~rb2640 & ~rb2641) | (rb2640 & ~rb2638 & ~rb2639);
  assign rb2646 = (rb2639 & ~rb2640 & ~rb2641) | (rb2641 & ~rb2638 & ~rb2639);
  assign rb2647 = rb2643 | (rb2645 & ~rb2642);
  assign rb2648 = rb2644 | (rb2646 & rb2642);
  assign rb2649 = (rb2645 | rb2646) & rb2642;
  assign rb2650 = (rb2645 | rb2646) & ~rb2642;
  assign rb2651 = rb697;
  assign rb2652 = rb698;
  assign rb2653 = rb1208;
  assign rb2654 = rb1209;
  assign rb2655 = rb696 | rb1207;
  assign rb2656 = rb2651 & rb2653;
  assign rb2657 = rb2652 & rb2654;
  assign rb2658 = (rb2651 & ~rb2653 & ~rb2654) | (rb2653 & ~rb2651 & ~rb2652);
  assign rb2659 = (rb2652 & ~rb2653 & ~rb2654) | (rb2654 & ~rb2651 & ~rb2652);
  assign rb2660 = rb2656 | (rb2658 & ~rb2655);
  assign rb2661 = rb2657 | (rb2659 & rb2655);
  assign rb2662 = (rb2658 | rb2659) & rb2655;
  assign rb2663 = (rb2658 | rb2659) & ~rb2655;
  assign rb2664 = rb699;
  assign rb2665 = rb700;
  assign rb2666 = rb1210;
  assign rb2667 = rb1211;
  assign rb2668 = rb698 | rb1209;
  assign rb2669 = rb2664 & rb2666;
  assign rb2670 = rb2665 & rb2667;
  assign rb2671 = (rb2664 & ~rb2666 & ~rb2667) | (rb2666 & ~rb2664 & ~rb2665);
  assign rb2672 = (rb2665 & ~rb2666 & ~rb2667) | (rb2667 & ~rb2664 & ~rb2665);
  assign rb2673 = rb2669 | (rb2671 & ~rb2668);
  assign rb2674 = rb2670 | (rb2672 & rb2668);
  assign rb2675 = (rb2671 | rb2672) & rb2668;
  assign rb2676 = (rb2671 | rb2672) & ~rb2668;
  assign rb2677 = (rb2246 & ~1'b0) | (1'b0 & ~rb2247);
  assign rb2678 = (rb2247 & ~1'b0) | (1'b0 & ~rb2246);
  assign rb2679 = (rb2259 & ~rb2245) | (rb2244 & ~rb2260);
  assign rb2680 = (rb2260 & ~rb2244) | (rb2245 & ~rb2259);
  assign rb2681 = (rb2272 & ~rb2258) | (rb2257 & ~rb2273);
  assign rb2682 = (rb2273 & ~rb2257) | (rb2258 & ~rb2272);
  assign rb2683 = (rb2285 & ~rb2271) | (rb2270 & ~rb2286);
  assign rb2684 = (rb2286 & ~rb2270) | (rb2271 & ~rb2285);
  assign rb2685 = (rb2298 & ~rb2284) | (rb2283 & ~rb2299);
  assign rb2686 = (rb2299 & ~rb2283) | (rb2284 & ~rb2298);
  assign rb2687 = (rb2311 & ~rb2297) | (rb2296 & ~rb2312);
  assign rb2688 = (rb2312 & ~rb2296) | (rb2297 & ~rb2311);
  assign rb2689 = (rb2324 & ~rb2310) | (rb2309 & ~rb2325);
  assign rb2690 = (rb2325 & ~rb2309) | (rb2310 & ~rb2324);
  assign rb2691 = (rb2337 & ~rb2323) | (rb2322 & ~rb2338);
  assign rb2692 = (rb2338 & ~rb2322) | (rb2323 & ~rb2337);
  assign rb2693 = (rb2350 & ~rb2336) | (rb2335 & ~rb2351);
  assign rb2694 = (rb2351 & ~rb2335) | (rb2336 & ~rb2350);
  assign rb2695 = (rb2363 & ~rb2349) | (rb2348 & ~rb2364);
  assign rb2696 = (rb2364 & ~rb2348) | (rb2349 & ~rb2363);
  assign rb2697 = (rb2376 & ~rb2362) | (rb2361 & ~rb2377);
  assign rb2698 = (rb2377 & ~rb2361) | (rb2362 & ~rb2376);
  assign rb2699 = (rb2389 & ~rb2375) | (rb2374 & ~rb2390);
  assign rb2700 = (rb2390 & ~rb2374) | (rb2375 & ~rb2389);
  assign rb2701 = (rb2402 & ~rb2388) | (rb2387 & ~rb2403);
  assign rb2702 = (rb2403 & ~rb2387) | (rb2388 & ~rb2402);
  assign rb2703 = (rb2415 & ~rb2401) | (rb2400 & ~rb2416);
  assign rb2704 = (rb2416 & ~rb2400) | (rb2401 & ~rb2415);
  assign rb2705 = (rb2428 & ~rb2414) | (rb2413 & ~rb2429);
  assign rb2706 = (rb2429 & ~rb2413) | (rb2414 & ~rb2428);
  assign rb2707 = (rb2441 & ~rb2427) | (rb2426 & ~rb2442);
  assign rb2708 = (rb2442 & ~rb2426) | (rb2427 & ~rb2441);
  assign rb2709 = (rb2454 & ~rb2440) | (rb2439 & ~rb2455);
  assign rb2710 = (rb2455 & ~rb2439) | (rb2440 & ~rb2454);
  assign rb2711 = (rb2467 & ~rb2453) | (rb2452 & ~rb2468);
  assign rb2712 = (rb2468 & ~rb2452) | (rb2453 & ~rb2467);
  assign rb2713 = (rb2480 & ~rb2466) | (rb2465 & ~rb2481);
  assign rb2714 = (rb2481 & ~rb2465) | (rb2466 & ~rb2480);
  assign rb2715 = (rb2493 & ~rb2479) | (rb2478 & ~rb2494);
  assign rb2716 = (rb2494 & ~rb2478) | (rb2479 & ~rb2493);
  assign rb2717 = (rb2506 & ~rb2492) | (rb2491 & ~rb2507);
  assign rb2718 = (rb2507 & ~rb2491) | (rb2492 & ~rb2506);
  assign rb2719 = (rb2519 & ~rb2505) | (rb2504 & ~rb2520);
  assign rb2720 = (rb2520 & ~rb2504) | (rb2505 & ~rb2519);
  assign rb2721 = (rb2532 & ~rb2518) | (rb2517 & ~rb2533);
  assign rb2722 = (rb2533 & ~rb2517) | (rb2518 & ~rb2532);
  assign rb2723 = (rb2545 & ~rb2531) | (rb2530 & ~rb2546);
  assign rb2724 = (rb2546 & ~rb2530) | (rb2531 & ~rb2545);
  assign rb2725 = (rb2558 & ~rb2544) | (rb2543 & ~rb2559);
  assign rb2726 = (rb2559 & ~rb2543) | (rb2544 & ~rb2558);
  assign rb2727 = (rb2571 & ~rb2557) | (rb2556 & ~rb2572);
  assign rb2728 = (rb2572 & ~rb2556) | (rb2557 & ~rb2571);
  assign rb2729 = (rb2584 & ~rb2570) | (rb2569 & ~rb2585);
  assign rb2730 = (rb2585 & ~rb2569) | (rb2570 & ~rb2584);
  assign rb2731 = (rb2597 & ~rb2583) | (rb2582 & ~rb2598);
  assign rb2732 = (rb2598 & ~rb2582) | (rb2583 & ~rb2597);
  assign rb2733 = (rb2610 & ~rb2596) | (rb2595 & ~rb2611);
  assign rb2734 = (rb2611 & ~rb2595) | (rb2596 & ~rb2610);
  assign rb2735 = (rb2623 & ~rb2609) | (rb2608 & ~rb2624);
  assign rb2736 = (rb2624 & ~rb2608) | (rb2609 & ~rb2623);
  assign rb2737 = (rb2636 & ~rb2622) | (rb2621 & ~rb2637);
  assign rb2738 = (rb2637 & ~rb2621) | (rb2622 & ~rb2636);
  assign rb2739 = (rb2649 & ~rb2635) | (rb2634 & ~rb2650);
  assign rb2740 = (rb2650 & ~rb2634) | (rb2635 & ~rb2649);
  assign rb2741 = (rb2662 & ~rb2648) | (rb2647 & ~rb2663);
  assign rb2742 = (rb2663 & ~rb2647) | (rb2648 & ~rb2662);
  assign rb2743 = (rb2675 & ~rb2661) | (rb2660 & ~rb2676);
  assign rb2744 = (rb2676 & ~rb2660) | (rb2661 & ~rb2675);
  assign rb2745 = (1'b0 & ~rb2674) | (rb2673 & ~1'b0);
  assign rb2746 = (1'b0 & ~rb2673) | (rb2674 & ~1'b0);
  assign rb2747 = rb1655;
  assign rb2748 = rb1656;
  assign rb2749 = rb2166;
  assign rb2750 = rb2167;
  assign rb2751 = rb2747 & rb2749;
  assign rb2752 = rb2748 & rb2750;
  assign rb2753 = (rb2747 & ~rb2749 & ~rb2750) | (rb2749 & ~rb2747 & ~rb2748);
  assign rb2754 = (rb2748 & ~rb2749 & ~rb2750) | (rb2750 & ~rb2747 & ~rb2748);
  assign rb2755 = rb2751 | (rb2753 & ~1'b0);
  assign rb2756 = rb2752 | (rb2754 & 1'b0);
  assign rb2757 = (rb2753 | rb2754) & 1'b0;
  assign rb2758 = (rb2753 | rb2754) & ~1'b0;
  assign rb2759 = rb1657;
  assign rb2760 = rb1658;
  assign rb2761 = rb2168;
  assign rb2762 = rb2169;
  assign rb2763 = rb1656 | rb2167;
  assign rb2764 = rb2759 & rb2761;
  assign rb2765 = rb2760 & rb2762;
  assign rb2766 = (rb2759 & ~rb2761 & ~rb2762) | (rb2761 & ~rb2759 & ~rb2760);
  assign rb2767 = (rb2760 & ~rb2761 & ~rb2762) | (rb2762 & ~rb2759 & ~rb2760);
  assign rb2768 = rb2764 | (rb2766 & ~rb2763);
  assign rb2769 = rb2765 | (rb2767 & rb2763);
  assign rb2770 = (rb2766 | rb2767) & rb2763;
  assign rb2771 = (rb2766 | rb2767) & ~rb2763;
  assign rb2772 = rb1659;
  assign rb2773 = rb1660;
  assign rb2774 = rb2170;
  assign rb2775 = rb2171;
  assign rb2776 = rb1658 | rb2169;
  assign rb2777 = rb2772 & rb2774;
  assign rb2778 = rb2773 & rb2775;
  assign rb2779 = (rb2772 & ~rb2774 & ~rb2775) | (rb2774 & ~rb2772 & ~rb2773);
  assign rb2780 = (rb2773 & ~rb2774 & ~rb2775) | (rb2775 & ~rb2772 & ~rb2773);
  assign rb2781 = rb2777 | (rb2779 & ~rb2776);
  assign rb2782 = rb2778 | (rb2780 & rb2776);
  assign rb2783 = (rb2779 | rb2780) & rb2776;
  assign rb2784 = (rb2779 | rb2780) & ~rb2776;
  assign rb2785 = rb1661;
  assign rb2786 = rb1662;
  assign rb2787 = rb2172;
  assign rb2788 = rb2173;
  assign rb2789 = rb1660 | rb2171;
  assign rb2790 = rb2785 & rb2787;
  assign rb2791 = rb2786 & rb2788;
  assign rb2792 = (rb2785 & ~rb2787 & ~rb2788) | (rb2787 & ~rb2785 & ~rb2786);
  assign rb2793 = (rb2786 & ~rb2787 & ~rb2788) | (rb2788 & ~rb2785 & ~rb2786);
  assign rb2794 = rb2790 | (rb2792 & ~rb2789);
  assign rb2795 = rb2791 | (rb2793 & rb2789);
  assign rb2796 = (rb2792 | rb2793) & rb2789;
  assign rb2797 = (rb2792 | rb2793) & ~rb2789;
  assign rb2798 = rb1663;
  assign rb2799 = rb1664;
  assign rb2800 = rb2174;
  assign rb2801 = rb2175;
  assign rb2802 = rb1662 | rb2173;
  assign rb2803 = rb2798 & rb2800;
  assign rb2804 = rb2799 & rb2801;
  assign rb2805 = (rb2798 & ~rb2800 & ~rb2801) | (rb2800 & ~rb2798 & ~rb2799);
  assign rb2806 = (rb2799 & ~rb2800 & ~rb2801) | (rb2801 & ~rb2798 & ~rb2799);
  assign rb2807 = rb2803 | (rb2805 & ~rb2802);
  assign rb2808 = rb2804 | (rb2806 & rb2802);
  assign rb2809 = (rb2805 | rb2806) & rb2802;
  assign rb2810 = (rb2805 | rb2806) & ~rb2802;
  assign rb2811 = rb1665;
  assign rb2812 = rb1666;
  assign rb2813 = rb2176;
  assign rb2814 = rb2177;
  assign rb2815 = rb1664 | rb2175;
  assign rb2816 = rb2811 & rb2813;
  assign rb2817 = rb2812 & rb2814;
  assign rb2818 = (rb2811 & ~rb2813 & ~rb2814) | (rb2813 & ~rb2811 & ~rb2812);
  assign rb2819 = (rb2812 & ~rb2813 & ~rb2814) | (rb2814 & ~rb2811 & ~rb2812);
  assign rb2820 = rb2816 | (rb2818 & ~rb2815);
  assign rb2821 = rb2817 | (rb2819 & rb2815);
  assign rb2822 = (rb2818 | rb2819) & rb2815;
  assign rb2823 = (rb2818 | rb2819) & ~rb2815;
  assign rb2824 = rb1667;
  assign rb2825 = rb1668;
  assign rb2826 = rb2178;
  assign rb2827 = rb2179;
  assign rb2828 = rb1666 | rb2177;
  assign rb2829 = rb2824 & rb2826;
  assign rb2830 = rb2825 & rb2827;
  assign rb2831 = (rb2824 & ~rb2826 & ~rb2827) | (rb2826 & ~rb2824 & ~rb2825);
  assign rb2832 = (rb2825 & ~rb2826 & ~rb2827) | (rb2827 & ~rb2824 & ~rb2825);
  assign rb2833 = rb2829 | (rb2831 & ~rb2828);
  assign rb2834 = rb2830 | (rb2832 & rb2828);
  assign rb2835 = (rb2831 | rb2832) & rb2828;
  assign rb2836 = (rb2831 | rb2832) & ~rb2828;
  assign rb2837 = rb1669;
  assign rb2838 = rb1670;
  assign rb2839 = rb2180;
  assign rb2840 = rb2181;
  assign rb2841 = rb1668 | rb2179;
  assign rb2842 = rb2837 & rb2839;
  assign rb2843 = rb2838 & rb2840;
  assign rb2844 = (rb2837 & ~rb2839 & ~rb2840) | (rb2839 & ~rb2837 & ~rb2838);
  assign rb2845 = (rb2838 & ~rb2839 & ~rb2840) | (rb2840 & ~rb2837 & ~rb2838);
  assign rb2846 = rb2842 | (rb2844 & ~rb2841);
  assign rb2847 = rb2843 | (rb2845 & rb2841);
  assign rb2848 = (rb2844 | rb2845) & rb2841;
  assign rb2849 = (rb2844 | rb2845) & ~rb2841;
  assign rb2850 = rb1671;
  assign rb2851 = rb1672;
  assign rb2852 = rb2182;
  assign rb2853 = rb2183;
  assign rb2854 = rb1670 | rb2181;
  assign rb2855 = rb2850 & rb2852;
  assign rb2856 = rb2851 & rb2853;
  assign rb2857 = (rb2850 & ~rb2852 & ~rb2853) | (rb2852 & ~rb2850 & ~rb2851);
  assign rb2858 = (rb2851 & ~rb2852 & ~rb2853) | (rb2853 & ~rb2850 & ~rb2851);
  assign rb2859 = rb2855 | (rb2857 & ~rb2854);
  assign rb2860 = rb2856 | (rb2858 & rb2854);
  assign rb2861 = (rb2857 | rb2858) & rb2854;
  assign rb2862 = (rb2857 | rb2858) & ~rb2854;
  assign rb2863 = rb1673;
  assign rb2864 = rb1674;
  assign rb2865 = rb2184;
  assign rb2866 = rb2185;
  assign rb2867 = rb1672 | rb2183;
  assign rb2868 = rb2863 & rb2865;
  assign rb2869 = rb2864 & rb2866;
  assign rb2870 = (rb2863 & ~rb2865 & ~rb2866) | (rb2865 & ~rb2863 & ~rb2864);
  assign rb2871 = (rb2864 & ~rb2865 & ~rb2866) | (rb2866 & ~rb2863 & ~rb2864);
  assign rb2872 = rb2868 | (rb2870 & ~rb2867);
  assign rb2873 = rb2869 | (rb2871 & rb2867);
  assign rb2874 = (rb2870 | rb2871) & rb2867;
  assign rb2875 = (rb2870 | rb2871) & ~rb2867;
  assign rb2876 = rb1675;
  assign rb2877 = rb1676;
  assign rb2878 = rb2186;
  assign rb2879 = rb2187;
  assign rb2880 = rb1674 | rb2185;
  assign rb2881 = rb2876 & rb2878;
  assign rb2882 = rb2877 & rb2879;
  assign rb2883 = (rb2876 & ~rb2878 & ~rb2879) | (rb2878 & ~rb2876 & ~rb2877);
  assign rb2884 = (rb2877 & ~rb2878 & ~rb2879) | (rb2879 & ~rb2876 & ~rb2877);
  assign rb2885 = rb2881 | (rb2883 & ~rb2880);
  assign rb2886 = rb2882 | (rb2884 & rb2880);
  assign rb2887 = (rb2883 | rb2884) & rb2880;
  assign rb2888 = (rb2883 | rb2884) & ~rb2880;
  assign rb2889 = rb1677;
  assign rb2890 = rb1678;
  assign rb2891 = rb2188;
  assign rb2892 = rb2189;
  assign rb2893 = rb1676 | rb2187;
  assign rb2894 = rb2889 & rb2891;
  assign rb2895 = rb2890 & rb2892;
  assign rb2896 = (rb2889 & ~rb2891 & ~rb2892) | (rb2891 & ~rb2889 & ~rb2890);
  assign rb2897 = (rb2890 & ~rb2891 & ~rb2892) | (rb2892 & ~rb2889 & ~rb2890);
  assign rb2898 = rb2894 | (rb2896 & ~rb2893);
  assign rb2899 = rb2895 | (rb2897 & rb2893);
  assign rb2900 = (rb2896 | rb2897) & rb2893;
  assign rb2901 = (rb2896 | rb2897) & ~rb2893;
  assign rb2902 = rb1679;
  assign rb2903 = rb1680;
  assign rb2904 = rb2190;
  assign rb2905 = rb2191;
  assign rb2906 = rb1678 | rb2189;
  assign rb2907 = rb2902 & rb2904;
  assign rb2908 = rb2903 & rb2905;
  assign rb2909 = (rb2902 & ~rb2904 & ~rb2905) | (rb2904 & ~rb2902 & ~rb2903);
  assign rb2910 = (rb2903 & ~rb2904 & ~rb2905) | (rb2905 & ~rb2902 & ~rb2903);
  assign rb2911 = rb2907 | (rb2909 & ~rb2906);
  assign rb2912 = rb2908 | (rb2910 & rb2906);
  assign rb2913 = (rb2909 | rb2910) & rb2906;
  assign rb2914 = (rb2909 | rb2910) & ~rb2906;
  assign rb2915 = rb1681;
  assign rb2916 = rb1682;
  assign rb2917 = rb2192;
  assign rb2918 = rb2193;
  assign rb2919 = rb1680 | rb2191;
  assign rb2920 = rb2915 & rb2917;
  assign rb2921 = rb2916 & rb2918;
  assign rb2922 = (rb2915 & ~rb2917 & ~rb2918) | (rb2917 & ~rb2915 & ~rb2916);
  assign rb2923 = (rb2916 & ~rb2917 & ~rb2918) | (rb2918 & ~rb2915 & ~rb2916);
  assign rb2924 = rb2920 | (rb2922 & ~rb2919);
  assign rb2925 = rb2921 | (rb2923 & rb2919);
  assign rb2926 = (rb2922 | rb2923) & rb2919;
  assign rb2927 = (rb2922 | rb2923) & ~rb2919;
  assign rb2928 = rb1683;
  assign rb2929 = rb1684;
  assign rb2930 = rb2194;
  assign rb2931 = rb2195;
  assign rb2932 = rb1682 | rb2193;
  assign rb2933 = rb2928 & rb2930;
  assign rb2934 = rb2929 & rb2931;
  assign rb2935 = (rb2928 & ~rb2930 & ~rb2931) | (rb2930 & ~rb2928 & ~rb2929);
  assign rb2936 = (rb2929 & ~rb2930 & ~rb2931) | (rb2931 & ~rb2928 & ~rb2929);
  assign rb2937 = rb2933 | (rb2935 & ~rb2932);
  assign rb2938 = rb2934 | (rb2936 & rb2932);
  assign rb2939 = (rb2935 | rb2936) & rb2932;
  assign rb2940 = (rb2935 | rb2936) & ~rb2932;
  assign rb2941 = rb1685;
  assign rb2942 = rb1686;
  assign rb2943 = rb2196;
  assign rb2944 = rb2197;
  assign rb2945 = rb1684 | rb2195;
  assign rb2946 = rb2941 & rb2943;
  assign rb2947 = rb2942 & rb2944;
  assign rb2948 = (rb2941 & ~rb2943 & ~rb2944) | (rb2943 & ~rb2941 & ~rb2942);
  assign rb2949 = (rb2942 & ~rb2943 & ~rb2944) | (rb2944 & ~rb2941 & ~rb2942);
  assign rb2950 = rb2946 | (rb2948 & ~rb2945);
  assign rb2951 = rb2947 | (rb2949 & rb2945);
  assign rb2952 = (rb2948 | rb2949) & rb2945;
  assign rb2953 = (rb2948 | rb2949) & ~rb2945;
  assign rb2954 = rb1687;
  assign rb2955 = rb1688;
  assign rb2956 = rb2198;
  assign rb2957 = rb2199;
  assign rb2958 = rb1686 | rb2197;
  assign rb2959 = rb2954 & rb2956;
  assign rb2960 = rb2955 & rb2957;
  assign rb2961 = (rb2954 & ~rb2956 & ~rb2957) | (rb2956 & ~rb2954 & ~rb2955);
  assign rb2962 = (rb2955 & ~rb2956 & ~rb2957) | (rb2957 & ~rb2954 & ~rb2955);
  assign rb2963 = rb2959 | (rb2961 & ~rb2958);
  assign rb2964 = rb2960 | (rb2962 & rb2958);
  assign rb2965 = (rb2961 | rb2962) & rb2958;
  assign rb2966 = (rb2961 | rb2962) & ~rb2958;
  assign rb2967 = rb1689;
  assign rb2968 = rb1690;
  assign rb2969 = rb2200;
  assign rb2970 = rb2201;
  assign rb2971 = rb1688 | rb2199;
  assign rb2972 = rb2967 & rb2969;
  assign rb2973 = rb2968 & rb2970;
  assign rb2974 = (rb2967 & ~rb2969 & ~rb2970) | (rb2969 & ~rb2967 & ~rb2968);
  assign rb2975 = (rb2968 & ~rb2969 & ~rb2970) | (rb2970 & ~rb2967 & ~rb2968);
  assign rb2976 = rb2972 | (rb2974 & ~rb2971);
  assign rb2977 = rb2973 | (rb2975 & rb2971);
  assign rb2978 = (rb2974 | rb2975) & rb2971;
  assign rb2979 = (rb2974 | rb2975) & ~rb2971;
  assign rb2980 = rb1691;
  assign rb2981 = rb1692;
  assign rb2982 = rb2202;
  assign rb2983 = rb2203;
  assign rb2984 = rb1690 | rb2201;
  assign rb2985 = rb2980 & rb2982;
  assign rb2986 = rb2981 & rb2983;
  assign rb2987 = (rb2980 & ~rb2982 & ~rb2983) | (rb2982 & ~rb2980 & ~rb2981);
  assign rb2988 = (rb2981 & ~rb2982 & ~rb2983) | (rb2983 & ~rb2980 & ~rb2981);
  assign rb2989 = rb2985 | (rb2987 & ~rb2984);
  assign rb2990 = rb2986 | (rb2988 & rb2984);
  assign rb2991 = (rb2987 | rb2988) & rb2984;
  assign rb2992 = (rb2987 | rb2988) & ~rb2984;
  assign rb2993 = rb1693;
  assign rb2994 = rb1694;
  assign rb2995 = rb2204;
  assign rb2996 = rb2205;
  assign rb2997 = rb1692 | rb2203;
  assign rb2998 = rb2993 & rb2995;
  assign rb2999 = rb2994 & rb2996;
  assign rb3000 = (rb2993 & ~rb2995 & ~rb2996) | (rb2995 & ~rb2993 & ~rb2994);
  assign rb3001 = (rb2994 & ~rb2995 & ~rb2996) | (rb2996 & ~rb2993 & ~rb2994);
  assign rb3002 = rb2998 | (rb3000 & ~rb2997);
  assign rb3003 = rb2999 | (rb3001 & rb2997);
  assign rb3004 = (rb3000 | rb3001) & rb2997;
  assign rb3005 = (rb3000 | rb3001) & ~rb2997;
  assign rb3006 = rb1695;
  assign rb3007 = rb1696;
  assign rb3008 = rb2206;
  assign rb3009 = rb2207;
  assign rb3010 = rb1694 | rb2205;
  assign rb3011 = rb3006 & rb3008;
  assign rb3012 = rb3007 & rb3009;
  assign rb3013 = (rb3006 & ~rb3008 & ~rb3009) | (rb3008 & ~rb3006 & ~rb3007);
  assign rb3014 = (rb3007 & ~rb3008 & ~rb3009) | (rb3009 & ~rb3006 & ~rb3007);
  assign rb3015 = rb3011 | (rb3013 & ~rb3010);
  assign rb3016 = rb3012 | (rb3014 & rb3010);
  assign rb3017 = (rb3013 | rb3014) & rb3010;
  assign rb3018 = (rb3013 | rb3014) & ~rb3010;
  assign rb3019 = rb1697;
  assign rb3020 = rb1698;
  assign rb3021 = rb2208;
  assign rb3022 = rb2209;
  assign rb3023 = rb1696 | rb2207;
  assign rb3024 = rb3019 & rb3021;
  assign rb3025 = rb3020 & rb3022;
  assign rb3026 = (rb3019 & ~rb3021 & ~rb3022) | (rb3021 & ~rb3019 & ~rb3020);
  assign rb3027 = (rb3020 & ~rb3021 & ~rb3022) | (rb3022 & ~rb3019 & ~rb3020);
  assign rb3028 = rb3024 | (rb3026 & ~rb3023);
  assign rb3029 = rb3025 | (rb3027 & rb3023);
  assign rb3030 = (rb3026 | rb3027) & rb3023;
  assign rb3031 = (rb3026 | rb3027) & ~rb3023;
  assign rb3032 = rb1699;
  assign rb3033 = rb1700;
  assign rb3034 = rb2210;
  assign rb3035 = rb2211;
  assign rb3036 = rb1698 | rb2209;
  assign rb3037 = rb3032 & rb3034;
  assign rb3038 = rb3033 & rb3035;
  assign rb3039 = (rb3032 & ~rb3034 & ~rb3035) | (rb3034 & ~rb3032 & ~rb3033);
  assign rb3040 = (rb3033 & ~rb3034 & ~rb3035) | (rb3035 & ~rb3032 & ~rb3033);
  assign rb3041 = rb3037 | (rb3039 & ~rb3036);
  assign rb3042 = rb3038 | (rb3040 & rb3036);
  assign rb3043 = (rb3039 | rb3040) & rb3036;
  assign rb3044 = (rb3039 | rb3040) & ~rb3036;
  assign rb3045 = rb1701;
  assign rb3046 = rb1702;
  assign rb3047 = rb2212;
  assign rb3048 = rb2213;
  assign rb3049 = rb1700 | rb2211;
  assign rb3050 = rb3045 & rb3047;
  assign rb3051 = rb3046 & rb3048;
  assign rb3052 = (rb3045 & ~rb3047 & ~rb3048) | (rb3047 & ~rb3045 & ~rb3046);
  assign rb3053 = (rb3046 & ~rb3047 & ~rb3048) | (rb3048 & ~rb3045 & ~rb3046);
  assign rb3054 = rb3050 | (rb3052 & ~rb3049);
  assign rb3055 = rb3051 | (rb3053 & rb3049);
  assign rb3056 = (rb3052 | rb3053) & rb3049;
  assign rb3057 = (rb3052 | rb3053) & ~rb3049;
  assign rb3058 = rb1703;
  assign rb3059 = rb1704;
  assign rb3060 = rb2214;
  assign rb3061 = rb2215;
  assign rb3062 = rb1702 | rb2213;
  assign rb3063 = rb3058 & rb3060;
  assign rb3064 = rb3059 & rb3061;
  assign rb3065 = (rb3058 & ~rb3060 & ~rb3061) | (rb3060 & ~rb3058 & ~rb3059);
  assign rb3066 = (rb3059 & ~rb3060 & ~rb3061) | (rb3061 & ~rb3058 & ~rb3059);
  assign rb3067 = rb3063 | (rb3065 & ~rb3062);
  assign rb3068 = rb3064 | (rb3066 & rb3062);
  assign rb3069 = (rb3065 | rb3066) & rb3062;
  assign rb3070 = (rb3065 | rb3066) & ~rb3062;
  assign rb3071 = rb1705;
  assign rb3072 = rb1706;
  assign rb3073 = rb2216;
  assign rb3074 = rb2217;
  assign rb3075 = rb1704 | rb2215;
  assign rb3076 = rb3071 & rb3073;
  assign rb3077 = rb3072 & rb3074;
  assign rb3078 = (rb3071 & ~rb3073 & ~rb3074) | (rb3073 & ~rb3071 & ~rb3072);
  assign rb3079 = (rb3072 & ~rb3073 & ~rb3074) | (rb3074 & ~rb3071 & ~rb3072);
  assign rb3080 = rb3076 | (rb3078 & ~rb3075);
  assign rb3081 = rb3077 | (rb3079 & rb3075);
  assign rb3082 = (rb3078 | rb3079) & rb3075;
  assign rb3083 = (rb3078 | rb3079) & ~rb3075;
  assign rb3084 = rb1707;
  assign rb3085 = rb1708;
  assign rb3086 = rb2218;
  assign rb3087 = rb2219;
  assign rb3088 = rb1706 | rb2217;
  assign rb3089 = rb3084 & rb3086;
  assign rb3090 = rb3085 & rb3087;
  assign rb3091 = (rb3084 & ~rb3086 & ~rb3087) | (rb3086 & ~rb3084 & ~rb3085);
  assign rb3092 = (rb3085 & ~rb3086 & ~rb3087) | (rb3087 & ~rb3084 & ~rb3085);
  assign rb3093 = rb3089 | (rb3091 & ~rb3088);
  assign rb3094 = rb3090 | (rb3092 & rb3088);
  assign rb3095 = (rb3091 | rb3092) & rb3088;
  assign rb3096 = (rb3091 | rb3092) & ~rb3088;
  assign rb3097 = rb1709;
  assign rb3098 = rb1710;
  assign rb3099 = rb2220;
  assign rb3100 = rb2221;
  assign rb3101 = rb1708 | rb2219;
  assign rb3102 = rb3097 & rb3099;
  assign rb3103 = rb3098 & rb3100;
  assign rb3104 = (rb3097 & ~rb3099 & ~rb3100) | (rb3099 & ~rb3097 & ~rb3098);
  assign rb3105 = (rb3098 & ~rb3099 & ~rb3100) | (rb3100 & ~rb3097 & ~rb3098);
  assign rb3106 = rb3102 | (rb3104 & ~rb3101);
  assign rb3107 = rb3103 | (rb3105 & rb3101);
  assign rb3108 = (rb3104 | rb3105) & rb3101;
  assign rb3109 = (rb3104 | rb3105) & ~rb3101;
  assign rb3110 = rb1711;
  assign rb3111 = rb1712;
  assign rb3112 = rb2222;
  assign rb3113 = rb2223;
  assign rb3114 = rb1710 | rb2221;
  assign rb3115 = rb3110 & rb3112;
  assign rb3116 = rb3111 & rb3113;
  assign rb3117 = (rb3110 & ~rb3112 & ~rb3113) | (rb3112 & ~rb3110 & ~rb3111);
  assign rb3118 = (rb3111 & ~rb3112 & ~rb3113) | (rb3113 & ~rb3110 & ~rb3111);
  assign rb3119 = rb3115 | (rb3117 & ~rb3114);
  assign rb3120 = rb3116 | (rb3118 & rb3114);
  assign rb3121 = (rb3117 | rb3118) & rb3114;
  assign rb3122 = (rb3117 | rb3118) & ~rb3114;
  assign rb3123 = rb1713;
  assign rb3124 = rb1714;
  assign rb3125 = rb2224;
  assign rb3126 = rb2225;
  assign rb3127 = rb1712 | rb2223;
  assign rb3128 = rb3123 & rb3125;
  assign rb3129 = rb3124 & rb3126;
  assign rb3130 = (rb3123 & ~rb3125 & ~rb3126) | (rb3125 & ~rb3123 & ~rb3124);
  assign rb3131 = (rb3124 & ~rb3125 & ~rb3126) | (rb3126 & ~rb3123 & ~rb3124);
  assign rb3132 = rb3128 | (rb3130 & ~rb3127);
  assign rb3133 = rb3129 | (rb3131 & rb3127);
  assign rb3134 = (rb3130 | rb3131) & rb3127;
  assign rb3135 = (rb3130 | rb3131) & ~rb3127;
  assign rb3136 = rb1715;
  assign rb3137 = rb1716;
  assign rb3138 = rb2226;
  assign rb3139 = rb2227;
  assign rb3140 = rb1714 | rb2225;
  assign rb3141 = rb3136 & rb3138;
  assign rb3142 = rb3137 & rb3139;
  assign rb3143 = (rb3136 & ~rb3138 & ~rb3139) | (rb3138 & ~rb3136 & ~rb3137);
  assign rb3144 = (rb3137 & ~rb3138 & ~rb3139) | (rb3139 & ~rb3136 & ~rb3137);
  assign rb3145 = rb3141 | (rb3143 & ~rb3140);
  assign rb3146 = rb3142 | (rb3144 & rb3140);
  assign rb3147 = (rb3143 | rb3144) & rb3140;
  assign rb3148 = (rb3143 | rb3144) & ~rb3140;
  assign rb3149 = rb1717;
  assign rb3150 = rb1718;
  assign rb3151 = rb2228;
  assign rb3152 = rb2229;
  assign rb3153 = rb1716 | rb2227;
  assign rb3154 = rb3149 & rb3151;
  assign rb3155 = rb3150 & rb3152;
  assign rb3156 = (rb3149 & ~rb3151 & ~rb3152) | (rb3151 & ~rb3149 & ~rb3150);
  assign rb3157 = (rb3150 & ~rb3151 & ~rb3152) | (rb3152 & ~rb3149 & ~rb3150);
  assign rb3158 = rb3154 | (rb3156 & ~rb3153);
  assign rb3159 = rb3155 | (rb3157 & rb3153);
  assign rb3160 = (rb3156 | rb3157) & rb3153;
  assign rb3161 = (rb3156 | rb3157) & ~rb3153;
  assign rb3162 = rb1719;
  assign rb3163 = rb1720;
  assign rb3164 = rb2230;
  assign rb3165 = rb2231;
  assign rb3166 = rb1718 | rb2229;
  assign rb3167 = rb3162 & rb3164;
  assign rb3168 = rb3163 & rb3165;
  assign rb3169 = (rb3162 & ~rb3164 & ~rb3165) | (rb3164 & ~rb3162 & ~rb3163);
  assign rb3170 = (rb3163 & ~rb3164 & ~rb3165) | (rb3165 & ~rb3162 & ~rb3163);
  assign rb3171 = rb3167 | (rb3169 & ~rb3166);
  assign rb3172 = rb3168 | (rb3170 & rb3166);
  assign rb3173 = (rb3169 | rb3170) & rb3166;
  assign rb3174 = (rb3169 | rb3170) & ~rb3166;
  assign rb3175 = rb1721;
  assign rb3176 = rb1722;
  assign rb3177 = rb2232;
  assign rb3178 = rb2233;
  assign rb3179 = rb1720 | rb2231;
  assign rb3180 = rb3175 & rb3177;
  assign rb3181 = rb3176 & rb3178;
  assign rb3182 = (rb3175 & ~rb3177 & ~rb3178) | (rb3177 & ~rb3175 & ~rb3176);
  assign rb3183 = (rb3176 & ~rb3177 & ~rb3178) | (rb3178 & ~rb3175 & ~rb3176);
  assign rb3184 = rb3180 | (rb3182 & ~rb3179);
  assign rb3185 = rb3181 | (rb3183 & rb3179);
  assign rb3186 = (rb3182 | rb3183) & rb3179;
  assign rb3187 = (rb3182 | rb3183) & ~rb3179;
  assign rb3188 = (rb2757 & ~1'b0) | (1'b0 & ~rb2758);
  assign rb3189 = (rb2758 & ~1'b0) | (1'b0 & ~rb2757);
  assign rb3190 = (rb2770 & ~rb2756) | (rb2755 & ~rb2771);
  assign rb3191 = (rb2771 & ~rb2755) | (rb2756 & ~rb2770);
  assign rb3192 = (rb2783 & ~rb2769) | (rb2768 & ~rb2784);
  assign rb3193 = (rb2784 & ~rb2768) | (rb2769 & ~rb2783);
  assign rb3194 = (rb2796 & ~rb2782) | (rb2781 & ~rb2797);
  assign rb3195 = (rb2797 & ~rb2781) | (rb2782 & ~rb2796);
  assign rb3196 = (rb2809 & ~rb2795) | (rb2794 & ~rb2810);
  assign rb3197 = (rb2810 & ~rb2794) | (rb2795 & ~rb2809);
  assign rb3198 = (rb2822 & ~rb2808) | (rb2807 & ~rb2823);
  assign rb3199 = (rb2823 & ~rb2807) | (rb2808 & ~rb2822);
  assign rb3200 = (rb2835 & ~rb2821) | (rb2820 & ~rb2836);
  assign rb3201 = (rb2836 & ~rb2820) | (rb2821 & ~rb2835);
  assign rb3202 = (rb2848 & ~rb2834) | (rb2833 & ~rb2849);
  assign rb3203 = (rb2849 & ~rb2833) | (rb2834 & ~rb2848);
  assign rb3204 = (rb2861 & ~rb2847) | (rb2846 & ~rb2862);
  assign rb3205 = (rb2862 & ~rb2846) | (rb2847 & ~rb2861);
  assign rb3206 = (rb2874 & ~rb2860) | (rb2859 & ~rb2875);
  assign rb3207 = (rb2875 & ~rb2859) | (rb2860 & ~rb2874);
  assign rb3208 = (rb2887 & ~rb2873) | (rb2872 & ~rb2888);
  assign rb3209 = (rb2888 & ~rb2872) | (rb2873 & ~rb2887);
  assign rb3210 = (rb2900 & ~rb2886) | (rb2885 & ~rb2901);
  assign rb3211 = (rb2901 & ~rb2885) | (rb2886 & ~rb2900);
  assign rb3212 = (rb2913 & ~rb2899) | (rb2898 & ~rb2914);
  assign rb3213 = (rb2914 & ~rb2898) | (rb2899 & ~rb2913);
  assign rb3214 = (rb2926 & ~rb2912) | (rb2911 & ~rb2927);
  assign rb3215 = (rb2927 & ~rb2911) | (rb2912 & ~rb2926);
  assign rb3216 = (rb2939 & ~rb2925) | (rb2924 & ~rb2940);
  assign rb3217 = (rb2940 & ~rb2924) | (rb2925 & ~rb2939);
  assign rb3218 = (rb2952 & ~rb2938) | (rb2937 & ~rb2953);
  assign rb3219 = (rb2953 & ~rb2937) | (rb2938 & ~rb2952);
  assign rb3220 = (rb2965 & ~rb2951) | (rb2950 & ~rb2966);
  assign rb3221 = (rb2966 & ~rb2950) | (rb2951 & ~rb2965);
  assign rb3222 = (rb2978 & ~rb2964) | (rb2963 & ~rb2979);
  assign rb3223 = (rb2979 & ~rb2963) | (rb2964 & ~rb2978);
  assign rb3224 = (rb2991 & ~rb2977) | (rb2976 & ~rb2992);
  assign rb3225 = (rb2992 & ~rb2976) | (rb2977 & ~rb2991);
  assign rb3226 = (rb3004 & ~rb2990) | (rb2989 & ~rb3005);
  assign rb3227 = (rb3005 & ~rb2989) | (rb2990 & ~rb3004);
  assign rb3228 = (rb3017 & ~rb3003) | (rb3002 & ~rb3018);
  assign rb3229 = (rb3018 & ~rb3002) | (rb3003 & ~rb3017);
  assign rb3230 = (rb3030 & ~rb3016) | (rb3015 & ~rb3031);
  assign rb3231 = (rb3031 & ~rb3015) | (rb3016 & ~rb3030);
  assign rb3232 = (rb3043 & ~rb3029) | (rb3028 & ~rb3044);
  assign rb3233 = (rb3044 & ~rb3028) | (rb3029 & ~rb3043);
  assign rb3234 = (rb3056 & ~rb3042) | (rb3041 & ~rb3057);
  assign rb3235 = (rb3057 & ~rb3041) | (rb3042 & ~rb3056);
  assign rb3236 = (rb3069 & ~rb3055) | (rb3054 & ~rb3070);
  assign rb3237 = (rb3070 & ~rb3054) | (rb3055 & ~rb3069);
  assign rb3238 = (rb3082 & ~rb3068) | (rb3067 & ~rb3083);
  assign rb3239 = (rb3083 & ~rb3067) | (rb3068 & ~rb3082);
  assign rb3240 = (rb3095 & ~rb3081) | (rb3080 & ~rb3096);
  assign rb3241 = (rb3096 & ~rb3080) | (rb3081 & ~rb3095);
  assign rb3242 = (rb3108 & ~rb3094) | (rb3093 & ~rb3109);
  assign rb3243 = (rb3109 & ~rb3093) | (rb3094 & ~rb3108);
  assign rb3244 = (rb3121 & ~rb3107) | (rb3106 & ~rb3122);
  assign rb3245 = (rb3122 & ~rb3106) | (rb3107 & ~rb3121);
  assign rb3246 = (rb3134 & ~rb3120) | (rb3119 & ~rb3135);
  assign rb3247 = (rb3135 & ~rb3119) | (rb3120 & ~rb3134);
  assign rb3248 = (rb3147 & ~rb3133) | (rb3132 & ~rb3148);
  assign rb3249 = (rb3148 & ~rb3132) | (rb3133 & ~rb3147);
  assign rb3250 = (rb3160 & ~rb3146) | (rb3145 & ~rb3161);
  assign rb3251 = (rb3161 & ~rb3145) | (rb3146 & ~rb3160);
  assign rb3252 = (rb3173 & ~rb3159) | (rb3158 & ~rb3174);
  assign rb3253 = (rb3174 & ~rb3158) | (rb3159 & ~rb3173);
  assign rb3254 = (rb3186 & ~rb3172) | (rb3171 & ~rb3187);
  assign rb3255 = (rb3187 & ~rb3171) | (rb3172 & ~rb3186);
  assign rb3256 = (1'b0 & ~rb3185) | (rb3184 & ~1'b0);
  assign rb3257 = (1'b0 & ~rb3184) | (rb3185 & ~1'b0);
  assign rb3258 = rb2677;
  assign rb3259 = rb2678;
  assign rb3260 = rb3188;
  assign rb3261 = rb3189;
  assign rb3262 = rb3258 & rb3260;
  assign rb3263 = rb3259 & rb3261;
  assign rb3264 = (rb3258 & ~rb3260 & ~rb3261) | (rb3260 & ~rb3258 & ~rb3259);
  assign rb3265 = (rb3259 & ~rb3260 & ~rb3261) | (rb3261 & ~rb3258 & ~rb3259);
  assign rb3266 = rb3262 | (rb3264 & ~1'b0);
  assign rb3267 = rb3263 | (rb3265 & 1'b0);
  assign rb3268 = (rb3264 | rb3265) & 1'b0;
  assign rb3269 = (rb3264 | rb3265) & ~1'b0;
  assign rb3270 = rb2679;
  assign rb3271 = rb2680;
  assign rb3272 = rb3190;
  assign rb3273 = rb3191;
  assign rb3274 = rb2678 | rb3189;
  assign rb3275 = rb3270 & rb3272;
  assign rb3276 = rb3271 & rb3273;
  assign rb3277 = (rb3270 & ~rb3272 & ~rb3273) | (rb3272 & ~rb3270 & ~rb3271);
  assign rb3278 = (rb3271 & ~rb3272 & ~rb3273) | (rb3273 & ~rb3270 & ~rb3271);
  assign rb3279 = rb3275 | (rb3277 & ~rb3274);
  assign rb3280 = rb3276 | (rb3278 & rb3274);
  assign rb3281 = (rb3277 | rb3278) & rb3274;
  assign rb3282 = (rb3277 | rb3278) & ~rb3274;
  assign rb3283 = rb2681;
  assign rb3284 = rb2682;
  assign rb3285 = rb3192;
  assign rb3286 = rb3193;
  assign rb3287 = rb2680 | rb3191;
  assign rb3288 = rb3283 & rb3285;
  assign rb3289 = rb3284 & rb3286;
  assign rb3290 = (rb3283 & ~rb3285 & ~rb3286) | (rb3285 & ~rb3283 & ~rb3284);
  assign rb3291 = (rb3284 & ~rb3285 & ~rb3286) | (rb3286 & ~rb3283 & ~rb3284);
  assign rb3292 = rb3288 | (rb3290 & ~rb3287);
  assign rb3293 = rb3289 | (rb3291 & rb3287);
  assign rb3294 = (rb3290 | rb3291) & rb3287;
  assign rb3295 = (rb3290 | rb3291) & ~rb3287;
  assign rb3296 = rb2683;
  assign rb3297 = rb2684;
  assign rb3298 = rb3194;
  assign rb3299 = rb3195;
  assign rb3300 = rb2682 | rb3193;
  assign rb3301 = rb3296 & rb3298;
  assign rb3302 = rb3297 & rb3299;
  assign rb3303 = (rb3296 & ~rb3298 & ~rb3299) | (rb3298 & ~rb3296 & ~rb3297);
  assign rb3304 = (rb3297 & ~rb3298 & ~rb3299) | (rb3299 & ~rb3296 & ~rb3297);
  assign rb3305 = rb3301 | (rb3303 & ~rb3300);
  assign rb3306 = rb3302 | (rb3304 & rb3300);
  assign rb3307 = (rb3303 | rb3304) & rb3300;
  assign rb3308 = (rb3303 | rb3304) & ~rb3300;
  assign rb3309 = rb2685;
  assign rb3310 = rb2686;
  assign rb3311 = rb3196;
  assign rb3312 = rb3197;
  assign rb3313 = rb2684 | rb3195;
  assign rb3314 = rb3309 & rb3311;
  assign rb3315 = rb3310 & rb3312;
  assign rb3316 = (rb3309 & ~rb3311 & ~rb3312) | (rb3311 & ~rb3309 & ~rb3310);
  assign rb3317 = (rb3310 & ~rb3311 & ~rb3312) | (rb3312 & ~rb3309 & ~rb3310);
  assign rb3318 = rb3314 | (rb3316 & ~rb3313);
  assign rb3319 = rb3315 | (rb3317 & rb3313);
  assign rb3320 = (rb3316 | rb3317) & rb3313;
  assign rb3321 = (rb3316 | rb3317) & ~rb3313;
  assign rb3322 = rb2687;
  assign rb3323 = rb2688;
  assign rb3324 = rb3198;
  assign rb3325 = rb3199;
  assign rb3326 = rb2686 | rb3197;
  assign rb3327 = rb3322 & rb3324;
  assign rb3328 = rb3323 & rb3325;
  assign rb3329 = (rb3322 & ~rb3324 & ~rb3325) | (rb3324 & ~rb3322 & ~rb3323);
  assign rb3330 = (rb3323 & ~rb3324 & ~rb3325) | (rb3325 & ~rb3322 & ~rb3323);
  assign rb3331 = rb3327 | (rb3329 & ~rb3326);
  assign rb3332 = rb3328 | (rb3330 & rb3326);
  assign rb3333 = (rb3329 | rb3330) & rb3326;
  assign rb3334 = (rb3329 | rb3330) & ~rb3326;
  assign rb3335 = rb2689;
  assign rb3336 = rb2690;
  assign rb3337 = rb3200;
  assign rb3338 = rb3201;
  assign rb3339 = rb2688 | rb3199;
  assign rb3340 = rb3335 & rb3337;
  assign rb3341 = rb3336 & rb3338;
  assign rb3342 = (rb3335 & ~rb3337 & ~rb3338) | (rb3337 & ~rb3335 & ~rb3336);
  assign rb3343 = (rb3336 & ~rb3337 & ~rb3338) | (rb3338 & ~rb3335 & ~rb3336);
  assign rb3344 = rb3340 | (rb3342 & ~rb3339);
  assign rb3345 = rb3341 | (rb3343 & rb3339);
  assign rb3346 = (rb3342 | rb3343) & rb3339;
  assign rb3347 = (rb3342 | rb3343) & ~rb3339;
  assign rb3348 = rb2691;
  assign rb3349 = rb2692;
  assign rb3350 = rb3202;
  assign rb3351 = rb3203;
  assign rb3352 = rb2690 | rb3201;
  assign rb3353 = rb3348 & rb3350;
  assign rb3354 = rb3349 & rb3351;
  assign rb3355 = (rb3348 & ~rb3350 & ~rb3351) | (rb3350 & ~rb3348 & ~rb3349);
  assign rb3356 = (rb3349 & ~rb3350 & ~rb3351) | (rb3351 & ~rb3348 & ~rb3349);
  assign rb3357 = rb3353 | (rb3355 & ~rb3352);
  assign rb3358 = rb3354 | (rb3356 & rb3352);
  assign rb3359 = (rb3355 | rb3356) & rb3352;
  assign rb3360 = (rb3355 | rb3356) & ~rb3352;
  assign rb3361 = rb2693;
  assign rb3362 = rb2694;
  assign rb3363 = rb3204;
  assign rb3364 = rb3205;
  assign rb3365 = rb2692 | rb3203;
  assign rb3366 = rb3361 & rb3363;
  assign rb3367 = rb3362 & rb3364;
  assign rb3368 = (rb3361 & ~rb3363 & ~rb3364) | (rb3363 & ~rb3361 & ~rb3362);
  assign rb3369 = (rb3362 & ~rb3363 & ~rb3364) | (rb3364 & ~rb3361 & ~rb3362);
  assign rb3370 = rb3366 | (rb3368 & ~rb3365);
  assign rb3371 = rb3367 | (rb3369 & rb3365);
  assign rb3372 = (rb3368 | rb3369) & rb3365;
  assign rb3373 = (rb3368 | rb3369) & ~rb3365;
  assign rb3374 = rb2695;
  assign rb3375 = rb2696;
  assign rb3376 = rb3206;
  assign rb3377 = rb3207;
  assign rb3378 = rb2694 | rb3205;
  assign rb3379 = rb3374 & rb3376;
  assign rb3380 = rb3375 & rb3377;
  assign rb3381 = (rb3374 & ~rb3376 & ~rb3377) | (rb3376 & ~rb3374 & ~rb3375);
  assign rb3382 = (rb3375 & ~rb3376 & ~rb3377) | (rb3377 & ~rb3374 & ~rb3375);
  assign rb3383 = rb3379 | (rb3381 & ~rb3378);
  assign rb3384 = rb3380 | (rb3382 & rb3378);
  assign rb3385 = (rb3381 | rb3382) & rb3378;
  assign rb3386 = (rb3381 | rb3382) & ~rb3378;
  assign rb3387 = rb2697;
  assign rb3388 = rb2698;
  assign rb3389 = rb3208;
  assign rb3390 = rb3209;
  assign rb3391 = rb2696 | rb3207;
  assign rb3392 = rb3387 & rb3389;
  assign rb3393 = rb3388 & rb3390;
  assign rb3394 = (rb3387 & ~rb3389 & ~rb3390) | (rb3389 & ~rb3387 & ~rb3388);
  assign rb3395 = (rb3388 & ~rb3389 & ~rb3390) | (rb3390 & ~rb3387 & ~rb3388);
  assign rb3396 = rb3392 | (rb3394 & ~rb3391);
  assign rb3397 = rb3393 | (rb3395 & rb3391);
  assign rb3398 = (rb3394 | rb3395) & rb3391;
  assign rb3399 = (rb3394 | rb3395) & ~rb3391;
  assign rb3400 = rb2699;
  assign rb3401 = rb2700;
  assign rb3402 = rb3210;
  assign rb3403 = rb3211;
  assign rb3404 = rb2698 | rb3209;
  assign rb3405 = rb3400 & rb3402;
  assign rb3406 = rb3401 & rb3403;
  assign rb3407 = (rb3400 & ~rb3402 & ~rb3403) | (rb3402 & ~rb3400 & ~rb3401);
  assign rb3408 = (rb3401 & ~rb3402 & ~rb3403) | (rb3403 & ~rb3400 & ~rb3401);
  assign rb3409 = rb3405 | (rb3407 & ~rb3404);
  assign rb3410 = rb3406 | (rb3408 & rb3404);
  assign rb3411 = (rb3407 | rb3408) & rb3404;
  assign rb3412 = (rb3407 | rb3408) & ~rb3404;
  assign rb3413 = rb2701;
  assign rb3414 = rb2702;
  assign rb3415 = rb3212;
  assign rb3416 = rb3213;
  assign rb3417 = rb2700 | rb3211;
  assign rb3418 = rb3413 & rb3415;
  assign rb3419 = rb3414 & rb3416;
  assign rb3420 = (rb3413 & ~rb3415 & ~rb3416) | (rb3415 & ~rb3413 & ~rb3414);
  assign rb3421 = (rb3414 & ~rb3415 & ~rb3416) | (rb3416 & ~rb3413 & ~rb3414);
  assign rb3422 = rb3418 | (rb3420 & ~rb3417);
  assign rb3423 = rb3419 | (rb3421 & rb3417);
  assign rb3424 = (rb3420 | rb3421) & rb3417;
  assign rb3425 = (rb3420 | rb3421) & ~rb3417;
  assign rb3426 = rb2703;
  assign rb3427 = rb2704;
  assign rb3428 = rb3214;
  assign rb3429 = rb3215;
  assign rb3430 = rb2702 | rb3213;
  assign rb3431 = rb3426 & rb3428;
  assign rb3432 = rb3427 & rb3429;
  assign rb3433 = (rb3426 & ~rb3428 & ~rb3429) | (rb3428 & ~rb3426 & ~rb3427);
  assign rb3434 = (rb3427 & ~rb3428 & ~rb3429) | (rb3429 & ~rb3426 & ~rb3427);
  assign rb3435 = rb3431 | (rb3433 & ~rb3430);
  assign rb3436 = rb3432 | (rb3434 & rb3430);
  assign rb3437 = (rb3433 | rb3434) & rb3430;
  assign rb3438 = (rb3433 | rb3434) & ~rb3430;
  assign rb3439 = rb2705;
  assign rb3440 = rb2706;
  assign rb3441 = rb3216;
  assign rb3442 = rb3217;
  assign rb3443 = rb2704 | rb3215;
  assign rb3444 = rb3439 & rb3441;
  assign rb3445 = rb3440 & rb3442;
  assign rb3446 = (rb3439 & ~rb3441 & ~rb3442) | (rb3441 & ~rb3439 & ~rb3440);
  assign rb3447 = (rb3440 & ~rb3441 & ~rb3442) | (rb3442 & ~rb3439 & ~rb3440);
  assign rb3448 = rb3444 | (rb3446 & ~rb3443);
  assign rb3449 = rb3445 | (rb3447 & rb3443);
  assign rb3450 = (rb3446 | rb3447) & rb3443;
  assign rb3451 = (rb3446 | rb3447) & ~rb3443;
  assign rb3452 = rb2707;
  assign rb3453 = rb2708;
  assign rb3454 = rb3218;
  assign rb3455 = rb3219;
  assign rb3456 = rb2706 | rb3217;
  assign rb3457 = rb3452 & rb3454;
  assign rb3458 = rb3453 & rb3455;
  assign rb3459 = (rb3452 & ~rb3454 & ~rb3455) | (rb3454 & ~rb3452 & ~rb3453);
  assign rb3460 = (rb3453 & ~rb3454 & ~rb3455) | (rb3455 & ~rb3452 & ~rb3453);
  assign rb3461 = rb3457 | (rb3459 & ~rb3456);
  assign rb3462 = rb3458 | (rb3460 & rb3456);
  assign rb3463 = (rb3459 | rb3460) & rb3456;
  assign rb3464 = (rb3459 | rb3460) & ~rb3456;
  assign rb3465 = rb2709;
  assign rb3466 = rb2710;
  assign rb3467 = rb3220;
  assign rb3468 = rb3221;
  assign rb3469 = rb2708 | rb3219;
  assign rb3470 = rb3465 & rb3467;
  assign rb3471 = rb3466 & rb3468;
  assign rb3472 = (rb3465 & ~rb3467 & ~rb3468) | (rb3467 & ~rb3465 & ~rb3466);
  assign rb3473 = (rb3466 & ~rb3467 & ~rb3468) | (rb3468 & ~rb3465 & ~rb3466);
  assign rb3474 = rb3470 | (rb3472 & ~rb3469);
  assign rb3475 = rb3471 | (rb3473 & rb3469);
  assign rb3476 = (rb3472 | rb3473) & rb3469;
  assign rb3477 = (rb3472 | rb3473) & ~rb3469;
  assign rb3478 = rb2711;
  assign rb3479 = rb2712;
  assign rb3480 = rb3222;
  assign rb3481 = rb3223;
  assign rb3482 = rb2710 | rb3221;
  assign rb3483 = rb3478 & rb3480;
  assign rb3484 = rb3479 & rb3481;
  assign rb3485 = (rb3478 & ~rb3480 & ~rb3481) | (rb3480 & ~rb3478 & ~rb3479);
  assign rb3486 = (rb3479 & ~rb3480 & ~rb3481) | (rb3481 & ~rb3478 & ~rb3479);
  assign rb3487 = rb3483 | (rb3485 & ~rb3482);
  assign rb3488 = rb3484 | (rb3486 & rb3482);
  assign rb3489 = (rb3485 | rb3486) & rb3482;
  assign rb3490 = (rb3485 | rb3486) & ~rb3482;
  assign rb3491 = rb2713;
  assign rb3492 = rb2714;
  assign rb3493 = rb3224;
  assign rb3494 = rb3225;
  assign rb3495 = rb2712 | rb3223;
  assign rb3496 = rb3491 & rb3493;
  assign rb3497 = rb3492 & rb3494;
  assign rb3498 = (rb3491 & ~rb3493 & ~rb3494) | (rb3493 & ~rb3491 & ~rb3492);
  assign rb3499 = (rb3492 & ~rb3493 & ~rb3494) | (rb3494 & ~rb3491 & ~rb3492);
  assign rb3500 = rb3496 | (rb3498 & ~rb3495);
  assign rb3501 = rb3497 | (rb3499 & rb3495);
  assign rb3502 = (rb3498 | rb3499) & rb3495;
  assign rb3503 = (rb3498 | rb3499) & ~rb3495;
  assign rb3504 = rb2715;
  assign rb3505 = rb2716;
  assign rb3506 = rb3226;
  assign rb3507 = rb3227;
  assign rb3508 = rb2714 | rb3225;
  assign rb3509 = rb3504 & rb3506;
  assign rb3510 = rb3505 & rb3507;
  assign rb3511 = (rb3504 & ~rb3506 & ~rb3507) | (rb3506 & ~rb3504 & ~rb3505);
  assign rb3512 = (rb3505 & ~rb3506 & ~rb3507) | (rb3507 & ~rb3504 & ~rb3505);
  assign rb3513 = rb3509 | (rb3511 & ~rb3508);
  assign rb3514 = rb3510 | (rb3512 & rb3508);
  assign rb3515 = (rb3511 | rb3512) & rb3508;
  assign rb3516 = (rb3511 | rb3512) & ~rb3508;
  assign rb3517 = rb2717;
  assign rb3518 = rb2718;
  assign rb3519 = rb3228;
  assign rb3520 = rb3229;
  assign rb3521 = rb2716 | rb3227;
  assign rb3522 = rb3517 & rb3519;
  assign rb3523 = rb3518 & rb3520;
  assign rb3524 = (rb3517 & ~rb3519 & ~rb3520) | (rb3519 & ~rb3517 & ~rb3518);
  assign rb3525 = (rb3518 & ~rb3519 & ~rb3520) | (rb3520 & ~rb3517 & ~rb3518);
  assign rb3526 = rb3522 | (rb3524 & ~rb3521);
  assign rb3527 = rb3523 | (rb3525 & rb3521);
  assign rb3528 = (rb3524 | rb3525) & rb3521;
  assign rb3529 = (rb3524 | rb3525) & ~rb3521;
  assign rb3530 = rb2719;
  assign rb3531 = rb2720;
  assign rb3532 = rb3230;
  assign rb3533 = rb3231;
  assign rb3534 = rb2718 | rb3229;
  assign rb3535 = rb3530 & rb3532;
  assign rb3536 = rb3531 & rb3533;
  assign rb3537 = (rb3530 & ~rb3532 & ~rb3533) | (rb3532 & ~rb3530 & ~rb3531);
  assign rb3538 = (rb3531 & ~rb3532 & ~rb3533) | (rb3533 & ~rb3530 & ~rb3531);
  assign rb3539 = rb3535 | (rb3537 & ~rb3534);
  assign rb3540 = rb3536 | (rb3538 & rb3534);
  assign rb3541 = (rb3537 | rb3538) & rb3534;
  assign rb3542 = (rb3537 | rb3538) & ~rb3534;
  assign rb3543 = rb2721;
  assign rb3544 = rb2722;
  assign rb3545 = rb3232;
  assign rb3546 = rb3233;
  assign rb3547 = rb2720 | rb3231;
  assign rb3548 = rb3543 & rb3545;
  assign rb3549 = rb3544 & rb3546;
  assign rb3550 = (rb3543 & ~rb3545 & ~rb3546) | (rb3545 & ~rb3543 & ~rb3544);
  assign rb3551 = (rb3544 & ~rb3545 & ~rb3546) | (rb3546 & ~rb3543 & ~rb3544);
  assign rb3552 = rb3548 | (rb3550 & ~rb3547);
  assign rb3553 = rb3549 | (rb3551 & rb3547);
  assign rb3554 = (rb3550 | rb3551) & rb3547;
  assign rb3555 = (rb3550 | rb3551) & ~rb3547;
  assign rb3556 = rb2723;
  assign rb3557 = rb2724;
  assign rb3558 = rb3234;
  assign rb3559 = rb3235;
  assign rb3560 = rb2722 | rb3233;
  assign rb3561 = rb3556 & rb3558;
  assign rb3562 = rb3557 & rb3559;
  assign rb3563 = (rb3556 & ~rb3558 & ~rb3559) | (rb3558 & ~rb3556 & ~rb3557);
  assign rb3564 = (rb3557 & ~rb3558 & ~rb3559) | (rb3559 & ~rb3556 & ~rb3557);
  assign rb3565 = rb3561 | (rb3563 & ~rb3560);
  assign rb3566 = rb3562 | (rb3564 & rb3560);
  assign rb3567 = (rb3563 | rb3564) & rb3560;
  assign rb3568 = (rb3563 | rb3564) & ~rb3560;
  assign rb3569 = rb2725;
  assign rb3570 = rb2726;
  assign rb3571 = rb3236;
  assign rb3572 = rb3237;
  assign rb3573 = rb2724 | rb3235;
  assign rb3574 = rb3569 & rb3571;
  assign rb3575 = rb3570 & rb3572;
  assign rb3576 = (rb3569 & ~rb3571 & ~rb3572) | (rb3571 & ~rb3569 & ~rb3570);
  assign rb3577 = (rb3570 & ~rb3571 & ~rb3572) | (rb3572 & ~rb3569 & ~rb3570);
  assign rb3578 = rb3574 | (rb3576 & ~rb3573);
  assign rb3579 = rb3575 | (rb3577 & rb3573);
  assign rb3580 = (rb3576 | rb3577) & rb3573;
  assign rb3581 = (rb3576 | rb3577) & ~rb3573;
  assign rb3582 = rb2727;
  assign rb3583 = rb2728;
  assign rb3584 = rb3238;
  assign rb3585 = rb3239;
  assign rb3586 = rb2726 | rb3237;
  assign rb3587 = rb3582 & rb3584;
  assign rb3588 = rb3583 & rb3585;
  assign rb3589 = (rb3582 & ~rb3584 & ~rb3585) | (rb3584 & ~rb3582 & ~rb3583);
  assign rb3590 = (rb3583 & ~rb3584 & ~rb3585) | (rb3585 & ~rb3582 & ~rb3583);
  assign rb3591 = rb3587 | (rb3589 & ~rb3586);
  assign rb3592 = rb3588 | (rb3590 & rb3586);
  assign rb3593 = (rb3589 | rb3590) & rb3586;
  assign rb3594 = (rb3589 | rb3590) & ~rb3586;
  assign rb3595 = rb2729;
  assign rb3596 = rb2730;
  assign rb3597 = rb3240;
  assign rb3598 = rb3241;
  assign rb3599 = rb2728 | rb3239;
  assign rb3600 = rb3595 & rb3597;
  assign rb3601 = rb3596 & rb3598;
  assign rb3602 = (rb3595 & ~rb3597 & ~rb3598) | (rb3597 & ~rb3595 & ~rb3596);
  assign rb3603 = (rb3596 & ~rb3597 & ~rb3598) | (rb3598 & ~rb3595 & ~rb3596);
  assign rb3604 = rb3600 | (rb3602 & ~rb3599);
  assign rb3605 = rb3601 | (rb3603 & rb3599);
  assign rb3606 = (rb3602 | rb3603) & rb3599;
  assign rb3607 = (rb3602 | rb3603) & ~rb3599;
  assign rb3608 = rb2731;
  assign rb3609 = rb2732;
  assign rb3610 = rb3242;
  assign rb3611 = rb3243;
  assign rb3612 = rb2730 | rb3241;
  assign rb3613 = rb3608 & rb3610;
  assign rb3614 = rb3609 & rb3611;
  assign rb3615 = (rb3608 & ~rb3610 & ~rb3611) | (rb3610 & ~rb3608 & ~rb3609);
  assign rb3616 = (rb3609 & ~rb3610 & ~rb3611) | (rb3611 & ~rb3608 & ~rb3609);
  assign rb3617 = rb3613 | (rb3615 & ~rb3612);
  assign rb3618 = rb3614 | (rb3616 & rb3612);
  assign rb3619 = (rb3615 | rb3616) & rb3612;
  assign rb3620 = (rb3615 | rb3616) & ~rb3612;
  assign rb3621 = rb2733;
  assign rb3622 = rb2734;
  assign rb3623 = rb3244;
  assign rb3624 = rb3245;
  assign rb3625 = rb2732 | rb3243;
  assign rb3626 = rb3621 & rb3623;
  assign rb3627 = rb3622 & rb3624;
  assign rb3628 = (rb3621 & ~rb3623 & ~rb3624) | (rb3623 & ~rb3621 & ~rb3622);
  assign rb3629 = (rb3622 & ~rb3623 & ~rb3624) | (rb3624 & ~rb3621 & ~rb3622);
  assign rb3630 = rb3626 | (rb3628 & ~rb3625);
  assign rb3631 = rb3627 | (rb3629 & rb3625);
  assign rb3632 = (rb3628 | rb3629) & rb3625;
  assign rb3633 = (rb3628 | rb3629) & ~rb3625;
  assign rb3634 = rb2735;
  assign rb3635 = rb2736;
  assign rb3636 = rb3246;
  assign rb3637 = rb3247;
  assign rb3638 = rb2734 | rb3245;
  assign rb3639 = rb3634 & rb3636;
  assign rb3640 = rb3635 & rb3637;
  assign rb3641 = (rb3634 & ~rb3636 & ~rb3637) | (rb3636 & ~rb3634 & ~rb3635);
  assign rb3642 = (rb3635 & ~rb3636 & ~rb3637) | (rb3637 & ~rb3634 & ~rb3635);
  assign rb3643 = rb3639 | (rb3641 & ~rb3638);
  assign rb3644 = rb3640 | (rb3642 & rb3638);
  assign rb3645 = (rb3641 | rb3642) & rb3638;
  assign rb3646 = (rb3641 | rb3642) & ~rb3638;
  assign rb3647 = rb2737;
  assign rb3648 = rb2738;
  assign rb3649 = rb3248;
  assign rb3650 = rb3249;
  assign rb3651 = rb2736 | rb3247;
  assign rb3652 = rb3647 & rb3649;
  assign rb3653 = rb3648 & rb3650;
  assign rb3654 = (rb3647 & ~rb3649 & ~rb3650) | (rb3649 & ~rb3647 & ~rb3648);
  assign rb3655 = (rb3648 & ~rb3649 & ~rb3650) | (rb3650 & ~rb3647 & ~rb3648);
  assign rb3656 = rb3652 | (rb3654 & ~rb3651);
  assign rb3657 = rb3653 | (rb3655 & rb3651);
  assign rb3658 = (rb3654 | rb3655) & rb3651;
  assign rb3659 = (rb3654 | rb3655) & ~rb3651;
  assign rb3660 = rb2739;
  assign rb3661 = rb2740;
  assign rb3662 = rb3250;
  assign rb3663 = rb3251;
  assign rb3664 = rb2738 | rb3249;
  assign rb3665 = rb3660 & rb3662;
  assign rb3666 = rb3661 & rb3663;
  assign rb3667 = (rb3660 & ~rb3662 & ~rb3663) | (rb3662 & ~rb3660 & ~rb3661);
  assign rb3668 = (rb3661 & ~rb3662 & ~rb3663) | (rb3663 & ~rb3660 & ~rb3661);
  assign rb3669 = rb3665 | (rb3667 & ~rb3664);
  assign rb3670 = rb3666 | (rb3668 & rb3664);
  assign rb3671 = (rb3667 | rb3668) & rb3664;
  assign rb3672 = (rb3667 | rb3668) & ~rb3664;
  assign rb3673 = rb2741;
  assign rb3674 = rb2742;
  assign rb3675 = rb3252;
  assign rb3676 = rb3253;
  assign rb3677 = rb2740 | rb3251;
  assign rb3678 = rb3673 & rb3675;
  assign rb3679 = rb3674 & rb3676;
  assign rb3680 = (rb3673 & ~rb3675 & ~rb3676) | (rb3675 & ~rb3673 & ~rb3674);
  assign rb3681 = (rb3674 & ~rb3675 & ~rb3676) | (rb3676 & ~rb3673 & ~rb3674);
  assign rb3682 = rb3678 | (rb3680 & ~rb3677);
  assign rb3683 = rb3679 | (rb3681 & rb3677);
  assign rb3684 = (rb3680 | rb3681) & rb3677;
  assign rb3685 = (rb3680 | rb3681) & ~rb3677;
  assign rb3686 = rb2743;
  assign rb3687 = rb2744;
  assign rb3688 = rb3254;
  assign rb3689 = rb3255;
  assign rb3690 = rb2742 | rb3253;
  assign rb3691 = rb3686 & rb3688;
  assign rb3692 = rb3687 & rb3689;
  assign rb3693 = (rb3686 & ~rb3688 & ~rb3689) | (rb3688 & ~rb3686 & ~rb3687);
  assign rb3694 = (rb3687 & ~rb3688 & ~rb3689) | (rb3689 & ~rb3686 & ~rb3687);
  assign rb3695 = rb3691 | (rb3693 & ~rb3690);
  assign rb3696 = rb3692 | (rb3694 & rb3690);
  assign rb3697 = (rb3693 | rb3694) & rb3690;
  assign rb3698 = (rb3693 | rb3694) & ~rb3690;
  assign rb3699 = (rb3268 & ~1'b0) | (1'b0 & ~rb3269);
  assign rb3700 = (rb3269 & ~1'b0) | (1'b0 & ~rb3268);
  assign rb3701 = (rb3281 & ~rb3267) | (rb3266 & ~rb3282);
  assign rb3702 = (rb3282 & ~rb3266) | (rb3267 & ~rb3281);
  assign rb3703 = (rb3294 & ~rb3280) | (rb3279 & ~rb3295);
  assign rb3704 = (rb3295 & ~rb3279) | (rb3280 & ~rb3294);
  assign rb3705 = (rb3307 & ~rb3293) | (rb3292 & ~rb3308);
  assign rb3706 = (rb3308 & ~rb3292) | (rb3293 & ~rb3307);
  assign rb3707 = (rb3320 & ~rb3306) | (rb3305 & ~rb3321);
  assign rb3708 = (rb3321 & ~rb3305) | (rb3306 & ~rb3320);
  assign rb3709 = (rb3333 & ~rb3319) | (rb3318 & ~rb3334);
  assign rb3710 = (rb3334 & ~rb3318) | (rb3319 & ~rb3333);
  assign rb3711 = (rb3346 & ~rb3332) | (rb3331 & ~rb3347);
  assign rb3712 = (rb3347 & ~rb3331) | (rb3332 & ~rb3346);
  assign rb3713 = (rb3359 & ~rb3345) | (rb3344 & ~rb3360);
  assign rb3714 = (rb3360 & ~rb3344) | (rb3345 & ~rb3359);
  assign rb3715 = (rb3372 & ~rb3358) | (rb3357 & ~rb3373);
  assign rb3716 = (rb3373 & ~rb3357) | (rb3358 & ~rb3372);
  assign rb3717 = (rb3385 & ~rb3371) | (rb3370 & ~rb3386);
  assign rb3718 = (rb3386 & ~rb3370) | (rb3371 & ~rb3385);
  assign rb3719 = (rb3398 & ~rb3384) | (rb3383 & ~rb3399);
  assign rb3720 = (rb3399 & ~rb3383) | (rb3384 & ~rb3398);
  assign rb3721 = (rb3411 & ~rb3397) | (rb3396 & ~rb3412);
  assign rb3722 = (rb3412 & ~rb3396) | (rb3397 & ~rb3411);
  assign rb3723 = (rb3424 & ~rb3410) | (rb3409 & ~rb3425);
  assign rb3724 = (rb3425 & ~rb3409) | (rb3410 & ~rb3424);
  assign rb3725 = (rb3437 & ~rb3423) | (rb3422 & ~rb3438);
  assign rb3726 = (rb3438 & ~rb3422) | (rb3423 & ~rb3437);
  assign rb3727 = (rb3450 & ~rb3436) | (rb3435 & ~rb3451);
  assign rb3728 = (rb3451 & ~rb3435) | (rb3436 & ~rb3450);
  assign rb3729 = (rb3463 & ~rb3449) | (rb3448 & ~rb3464);
  assign rb3730 = (rb3464 & ~rb3448) | (rb3449 & ~rb3463);
  assign rb3731 = (rb3476 & ~rb3462) | (rb3461 & ~rb3477);
  assign rb3732 = (rb3477 & ~rb3461) | (rb3462 & ~rb3476);
  assign rb3733 = (rb3489 & ~rb3475) | (rb3474 & ~rb3490);
  assign rb3734 = (rb3490 & ~rb3474) | (rb3475 & ~rb3489);
  assign rb3735 = (rb3502 & ~rb3488) | (rb3487 & ~rb3503);
  assign rb3736 = (rb3503 & ~rb3487) | (rb3488 & ~rb3502);
  assign rb3737 = (rb3515 & ~rb3501) | (rb3500 & ~rb3516);
  assign rb3738 = (rb3516 & ~rb3500) | (rb3501 & ~rb3515);
  assign rb3739 = (rb3528 & ~rb3514) | (rb3513 & ~rb3529);
  assign rb3740 = (rb3529 & ~rb3513) | (rb3514 & ~rb3528);
  assign rb3741 = (rb3541 & ~rb3527) | (rb3526 & ~rb3542);
  assign rb3742 = (rb3542 & ~rb3526) | (rb3527 & ~rb3541);
  assign rb3743 = (rb3554 & ~rb3540) | (rb3539 & ~rb3555);
  assign rb3744 = (rb3555 & ~rb3539) | (rb3540 & ~rb3554);
  assign rb3745 = (rb3567 & ~rb3553) | (rb3552 & ~rb3568);
  assign rb3746 = (rb3568 & ~rb3552) | (rb3553 & ~rb3567);
  assign rb3747 = (rb3580 & ~rb3566) | (rb3565 & ~rb3581);
  assign rb3748 = (rb3581 & ~rb3565) | (rb3566 & ~rb3580);
  assign rb3749 = (rb3593 & ~rb3579) | (rb3578 & ~rb3594);
  assign rb3750 = (rb3594 & ~rb3578) | (rb3579 & ~rb3593);
  assign rb3751 = (rb3606 & ~rb3592) | (rb3591 & ~rb3607);
  assign rb3752 = (rb3607 & ~rb3591) | (rb3592 & ~rb3606);
  assign rb3753 = (rb3619 & ~rb3605) | (rb3604 & ~rb3620);
  assign rb3754 = (rb3620 & ~rb3604) | (rb3605 & ~rb3619);
  assign rb3755 = (rb3632 & ~rb3618) | (rb3617 & ~rb3633);
  assign rb3756 = (rb3633 & ~rb3617) | (rb3618 & ~rb3632);
  assign rb3757 = (rb3645 & ~rb3631) | (rb3630 & ~rb3646);
  assign rb3758 = (rb3646 & ~rb3630) | (rb3631 & ~rb3645);
  assign rb3759 = (rb3658 & ~rb3644) | (rb3643 & ~rb3659);
  assign rb3760 = (rb3659 & ~rb3643) | (rb3644 & ~rb3658);
  assign rb3761 = (rb3671 & ~rb3657) | (rb3656 & ~rb3672);
  assign rb3762 = (rb3672 & ~rb3656) | (rb3657 & ~rb3671);
  assign rb3763 = (rb3684 & ~rb3670) | (rb3669 & ~rb3685);
  assign rb3764 = (rb3685 & ~rb3669) | (rb3670 & ~rb3684);
  assign rb3765 = (rb3697 & ~rb3683) | (rb3682 & ~rb3698);
  assign rb3766 = (rb3698 & ~rb3682) | (rb3683 & ~rb3697);
  assign rb3767 = (1'b0 & ~rb3696) | (rb3695 & ~1'b0);
  assign rb3768 = (1'b0 & ~rb3695) | (rb3696 & ~1'b0);
  assign rb3769 = rb3699;
  assign rb3770 = rb3700;
  assign rb3771 = 1'b0;
  assign rb3772 = 1'b0;
  assign rb3773 = rb3769 & rb3771;
  assign rb3774 = rb3770 & rb3772;
  assign rb3775 = (rb3769 & ~rb3771 & ~rb3772) | (rb3771 & ~rb3769 & ~rb3770);
  assign rb3776 = (rb3770 & ~rb3771 & ~rb3772) | (rb3772 & ~rb3769 & ~rb3770);
  assign rb3777 = rb3773 | (rb3775 & ~1'b0);
  assign rb3778 = rb3774 | (rb3776 & 1'b0);
  assign rb3779 = (rb3775 | rb3776) & 1'b0;
  assign rb3780 = (rb3775 | rb3776) & ~1'b0;
  assign rb3781 = rb3701;
  assign rb3782 = rb3702;
  assign rb3783 = 1'b0;
  assign rb3784 = 1'b0;
  assign rb3785 = rb3700 | 1'b0;
  assign rb3786 = rb3781 & rb3783;
  assign rb3787 = rb3782 & rb3784;
  assign rb3788 = (rb3781 & ~rb3783 & ~rb3784) | (rb3783 & ~rb3781 & ~rb3782);
  assign rb3789 = (rb3782 & ~rb3783 & ~rb3784) | (rb3784 & ~rb3781 & ~rb3782);
  assign rb3790 = rb3786 | (rb3788 & ~rb3785);
  assign rb3791 = rb3787 | (rb3789 & rb3785);
  assign rb3792 = (rb3788 | rb3789) & rb3785;
  assign rb3793 = (rb3788 | rb3789) & ~rb3785;
  assign rb3794 = rb3703;
  assign rb3795 = rb3704;
  assign rb3796 = 1'b0;
  assign rb3797 = 1'b0;
  assign rb3798 = rb3702 | 1'b0;
  assign rb3799 = rb3794 & rb3796;
  assign rb3800 = rb3795 & rb3797;
  assign rb3801 = (rb3794 & ~rb3796 & ~rb3797) | (rb3796 & ~rb3794 & ~rb3795);
  assign rb3802 = (rb3795 & ~rb3796 & ~rb3797) | (rb3797 & ~rb3794 & ~rb3795);
  assign rb3803 = rb3799 | (rb3801 & ~rb3798);
  assign rb3804 = rb3800 | (rb3802 & rb3798);
  assign rb3805 = (rb3801 | rb3802) & rb3798;
  assign rb3806 = (rb3801 | rb3802) & ~rb3798;
  assign rb3807 = rb3705;
  assign rb3808 = rb3706;
  assign rb3809 = 1'b0;
  assign rb3810 = 1'b0;
  assign rb3811 = rb3704 | 1'b0;
  assign rb3812 = rb3807 & rb3809;
  assign rb3813 = rb3808 & rb3810;
  assign rb3814 = (rb3807 & ~rb3809 & ~rb3810) | (rb3809 & ~rb3807 & ~rb3808);
  assign rb3815 = (rb3808 & ~rb3809 & ~rb3810) | (rb3810 & ~rb3807 & ~rb3808);
  assign rb3816 = rb3812 | (rb3814 & ~rb3811);
  assign rb3817 = rb3813 | (rb3815 & rb3811);
  assign rb3818 = (rb3814 | rb3815) & rb3811;
  assign rb3819 = (rb3814 | rb3815) & ~rb3811;
  assign rb3820 = rb3707;
  assign rb3821 = rb3708;
  assign rb3822 = 1'b0;
  assign rb3823 = 1'b0;
  assign rb3824 = rb3706 | 1'b0;
  assign rb3825 = rb3820 & rb3822;
  assign rb3826 = rb3821 & rb3823;
  assign rb3827 = (rb3820 & ~rb3822 & ~rb3823) | (rb3822 & ~rb3820 & ~rb3821);
  assign rb3828 = (rb3821 & ~rb3822 & ~rb3823) | (rb3823 & ~rb3820 & ~rb3821);
  assign rb3829 = rb3825 | (rb3827 & ~rb3824);
  assign rb3830 = rb3826 | (rb3828 & rb3824);
  assign rb3831 = (rb3827 | rb3828) & rb3824;
  assign rb3832 = (rb3827 | rb3828) & ~rb3824;
  assign rb3833 = rb3709;
  assign rb3834 = rb3710;
  assign rb3835 = 1'b0;
  assign rb3836 = 1'b0;
  assign rb3837 = rb3708 | 1'b0;
  assign rb3838 = rb3833 & rb3835;
  assign rb3839 = rb3834 & rb3836;
  assign rb3840 = (rb3833 & ~rb3835 & ~rb3836) | (rb3835 & ~rb3833 & ~rb3834);
  assign rb3841 = (rb3834 & ~rb3835 & ~rb3836) | (rb3836 & ~rb3833 & ~rb3834);
  assign rb3842 = rb3838 | (rb3840 & ~rb3837);
  assign rb3843 = rb3839 | (rb3841 & rb3837);
  assign rb3844 = (rb3840 | rb3841) & rb3837;
  assign rb3845 = (rb3840 | rb3841) & ~rb3837;
  assign rb3846 = rb3711;
  assign rb3847 = rb3712;
  assign rb3848 = 1'b0;
  assign rb3849 = 1'b0;
  assign rb3850 = rb3710 | 1'b0;
  assign rb3851 = rb3846 & rb3848;
  assign rb3852 = rb3847 & rb3849;
  assign rb3853 = (rb3846 & ~rb3848 & ~rb3849) | (rb3848 & ~rb3846 & ~rb3847);
  assign rb3854 = (rb3847 & ~rb3848 & ~rb3849) | (rb3849 & ~rb3846 & ~rb3847);
  assign rb3855 = rb3851 | (rb3853 & ~rb3850);
  assign rb3856 = rb3852 | (rb3854 & rb3850);
  assign rb3857 = (rb3853 | rb3854) & rb3850;
  assign rb3858 = (rb3853 | rb3854) & ~rb3850;
  assign rb3859 = rb3713;
  assign rb3860 = rb3714;
  assign rb3861 = 1'b0;
  assign rb3862 = 1'b0;
  assign rb3863 = rb3712 | 1'b0;
  assign rb3864 = rb3859 & rb3861;
  assign rb3865 = rb3860 & rb3862;
  assign rb3866 = (rb3859 & ~rb3861 & ~rb3862) | (rb3861 & ~rb3859 & ~rb3860);
  assign rb3867 = (rb3860 & ~rb3861 & ~rb3862) | (rb3862 & ~rb3859 & ~rb3860);
  assign rb3868 = rb3864 | (rb3866 & ~rb3863);
  assign rb3869 = rb3865 | (rb3867 & rb3863);
  assign rb3870 = (rb3866 | rb3867) & rb3863;
  assign rb3871 = (rb3866 | rb3867) & ~rb3863;
  assign rb3872 = rb3715;
  assign rb3873 = rb3716;
  assign rb3874 = 1'b0;
  assign rb3875 = 1'b0;
  assign rb3876 = rb3714 | 1'b0;
  assign rb3877 = rb3872 & rb3874;
  assign rb3878 = rb3873 & rb3875;
  assign rb3879 = (rb3872 & ~rb3874 & ~rb3875) | (rb3874 & ~rb3872 & ~rb3873);
  assign rb3880 = (rb3873 & ~rb3874 & ~rb3875) | (rb3875 & ~rb3872 & ~rb3873);
  assign rb3881 = rb3877 | (rb3879 & ~rb3876);
  assign rb3882 = rb3878 | (rb3880 & rb3876);
  assign rb3883 = (rb3879 | rb3880) & rb3876;
  assign rb3884 = (rb3879 | rb3880) & ~rb3876;
  assign rb3885 = rb3717;
  assign rb3886 = rb3718;
  assign rb3887 = 1'b0;
  assign rb3888 = 1'b0;
  assign rb3889 = rb3716 | 1'b0;
  assign rb3890 = rb3885 & rb3887;
  assign rb3891 = rb3886 & rb3888;
  assign rb3892 = (rb3885 & ~rb3887 & ~rb3888) | (rb3887 & ~rb3885 & ~rb3886);
  assign rb3893 = (rb3886 & ~rb3887 & ~rb3888) | (rb3888 & ~rb3885 & ~rb3886);
  assign rb3894 = rb3890 | (rb3892 & ~rb3889);
  assign rb3895 = rb3891 | (rb3893 & rb3889);
  assign rb3896 = (rb3892 | rb3893) & rb3889;
  assign rb3897 = (rb3892 | rb3893) & ~rb3889;
  assign rb3898 = rb3719;
  assign rb3899 = rb3720;
  assign rb3900 = 1'b0;
  assign rb3901 = 1'b0;
  assign rb3902 = rb3718 | 1'b0;
  assign rb3903 = rb3898 & rb3900;
  assign rb3904 = rb3899 & rb3901;
  assign rb3905 = (rb3898 & ~rb3900 & ~rb3901) | (rb3900 & ~rb3898 & ~rb3899);
  assign rb3906 = (rb3899 & ~rb3900 & ~rb3901) | (rb3901 & ~rb3898 & ~rb3899);
  assign rb3907 = rb3903 | (rb3905 & ~rb3902);
  assign rb3908 = rb3904 | (rb3906 & rb3902);
  assign rb3909 = (rb3905 | rb3906) & rb3902;
  assign rb3910 = (rb3905 | rb3906) & ~rb3902;
  assign rb3911 = rb3721;
  assign rb3912 = rb3722;
  assign rb3913 = 1'b0;
  assign rb3914 = 1'b0;
  assign rb3915 = rb3720 | 1'b0;
  assign rb3916 = rb3911 & rb3913;
  assign rb3917 = rb3912 & rb3914;
  assign rb3918 = (rb3911 & ~rb3913 & ~rb3914) | (rb3913 & ~rb3911 & ~rb3912);
  assign rb3919 = (rb3912 & ~rb3913 & ~rb3914) | (rb3914 & ~rb3911 & ~rb3912);
  assign rb3920 = rb3916 | (rb3918 & ~rb3915);
  assign rb3921 = rb3917 | (rb3919 & rb3915);
  assign rb3922 = (rb3918 | rb3919) & rb3915;
  assign rb3923 = (rb3918 | rb3919) & ~rb3915;
  assign rb3924 = rb3723;
  assign rb3925 = rb3724;
  assign rb3926 = 1'b0;
  assign rb3927 = 1'b0;
  assign rb3928 = rb3722 | 1'b0;
  assign rb3929 = rb3924 & rb3926;
  assign rb3930 = rb3925 & rb3927;
  assign rb3931 = (rb3924 & ~rb3926 & ~rb3927) | (rb3926 & ~rb3924 & ~rb3925);
  assign rb3932 = (rb3925 & ~rb3926 & ~rb3927) | (rb3927 & ~rb3924 & ~rb3925);
  assign rb3933 = rb3929 | (rb3931 & ~rb3928);
  assign rb3934 = rb3930 | (rb3932 & rb3928);
  assign rb3935 = (rb3931 | rb3932) & rb3928;
  assign rb3936 = (rb3931 | rb3932) & ~rb3928;
  assign rb3937 = rb3725;
  assign rb3938 = rb3726;
  assign rb3939 = 1'b0;
  assign rb3940 = 1'b0;
  assign rb3941 = rb3724 | 1'b0;
  assign rb3942 = rb3937 & rb3939;
  assign rb3943 = rb3938 & rb3940;
  assign rb3944 = (rb3937 & ~rb3939 & ~rb3940) | (rb3939 & ~rb3937 & ~rb3938);
  assign rb3945 = (rb3938 & ~rb3939 & ~rb3940) | (rb3940 & ~rb3937 & ~rb3938);
  assign rb3946 = rb3942 | (rb3944 & ~rb3941);
  assign rb3947 = rb3943 | (rb3945 & rb3941);
  assign rb3948 = (rb3944 | rb3945) & rb3941;
  assign rb3949 = (rb3944 | rb3945) & ~rb3941;
  assign rb3950 = rb3727;
  assign rb3951 = rb3728;
  assign rb3952 = neg162;
  assign rb3953 = 1'b0;
  assign rb3954 = rb3726 | 1'b0;
  assign rb3955 = rb3950 & rb3952;
  assign rb3956 = rb3951 & rb3953;
  assign rb3957 = (rb3950 & ~rb3952 & ~rb3953) | (rb3952 & ~rb3950 & ~rb3951);
  assign rb3958 = (rb3951 & ~rb3952 & ~rb3953) | (rb3953 & ~rb3950 & ~rb3951);
  assign rb3959 = rb3955 | (rb3957 & ~rb3954);
  assign rb3960 = rb3956 | (rb3958 & rb3954);
  assign rb3961 = (rb3957 | rb3958) & rb3954;
  assign rb3962 = (rb3957 | rb3958) & ~rb3954;
  assign rb3963 = rb3729;
  assign rb3964 = rb3730;
  assign rb3965 = 1'b0;
  assign rb3966 = 1'b0;
  assign rb3967 = rb3728 | 1'b0;
  assign rb3968 = rb3963 & rb3965;
  assign rb3969 = rb3964 & rb3966;
  assign rb3970 = (rb3963 & ~rb3965 & ~rb3966) | (rb3965 & ~rb3963 & ~rb3964);
  assign rb3971 = (rb3964 & ~rb3965 & ~rb3966) | (rb3966 & ~rb3963 & ~rb3964);
  assign rb3972 = rb3968 | (rb3970 & ~rb3967);
  assign rb3973 = rb3969 | (rb3971 & rb3967);
  assign rb3974 = (rb3970 | rb3971) & rb3967;
  assign rb3975 = (rb3970 | rb3971) & ~rb3967;
  assign rb3976 = rb3731;
  assign rb3977 = rb3732;
  assign rb3978 = 1'b0;
  assign rb3979 = 1'b0;
  assign rb3980 = rb3730 | 1'b0;
  assign rb3981 = rb3976 & rb3978;
  assign rb3982 = rb3977 & rb3979;
  assign rb3983 = (rb3976 & ~rb3978 & ~rb3979) | (rb3978 & ~rb3976 & ~rb3977);
  assign rb3984 = (rb3977 & ~rb3978 & ~rb3979) | (rb3979 & ~rb3976 & ~rb3977);
  assign rb3985 = rb3981 | (rb3983 & ~rb3980);
  assign rb3986 = rb3982 | (rb3984 & rb3980);
  assign rb3987 = (rb3983 | rb3984) & rb3980;
  assign rb3988 = (rb3983 | rb3984) & ~rb3980;
  assign rb3989 = rb3733;
  assign rb3990 = rb3734;
  assign rb3991 = 1'b1;
  assign rb3992 = 1'b0;
  assign rb3993 = rb3732 | 1'b0;
  assign rb3994 = rb3989 & rb3991;
  assign rb3995 = rb3990 & rb3992;
  assign rb3996 = (rb3989 & ~rb3991 & ~rb3992) | (rb3991 & ~rb3989 & ~rb3990);
  assign rb3997 = (rb3990 & ~rb3991 & ~rb3992) | (rb3992 & ~rb3989 & ~rb3990);
  assign rb3998 = rb3994 | (rb3996 & ~rb3993);
  assign rb3999 = rb3995 | (rb3997 & rb3993);
  assign rb4000 = (rb3996 | rb3997) & rb3993;
  assign rb4001 = (rb3996 | rb3997) & ~rb3993;
  assign rb4002 = rb3735;
  assign rb4003 = rb3736;
  assign rb4004 = 1'b0;
  assign rb4005 = 1'b0;
  assign rb4006 = rb3734 | 1'b0;
  assign rb4007 = rb4002 & rb4004;
  assign rb4008 = rb4003 & rb4005;
  assign rb4009 = (rb4002 & ~rb4004 & ~rb4005) | (rb4004 & ~rb4002 & ~rb4003);
  assign rb4010 = (rb4003 & ~rb4004 & ~rb4005) | (rb4005 & ~rb4002 & ~rb4003);
  assign rb4011 = rb4007 | (rb4009 & ~rb4006);
  assign rb4012 = rb4008 | (rb4010 & rb4006);
  assign rb4013 = (rb4009 | rb4010) & rb4006;
  assign rb4014 = (rb4009 | rb4010) & ~rb4006;
  assign rb4015 = rb3737;
  assign rb4016 = rb3738;
  assign rb4017 = 1'b0;
  assign rb4018 = 1'b0;
  assign rb4019 = rb3736 | 1'b0;
  assign rb4020 = rb4015 & rb4017;
  assign rb4021 = rb4016 & rb4018;
  assign rb4022 = (rb4015 & ~rb4017 & ~rb4018) | (rb4017 & ~rb4015 & ~rb4016);
  assign rb4023 = (rb4016 & ~rb4017 & ~rb4018) | (rb4018 & ~rb4015 & ~rb4016);
  assign rb4024 = rb4020 | (rb4022 & ~rb4019);
  assign rb4025 = rb4021 | (rb4023 & rb4019);
  assign rb4026 = (rb4022 | rb4023) & rb4019;
  assign rb4027 = (rb4022 | rb4023) & ~rb4019;
  assign rb4028 = rb3739;
  assign rb4029 = rb3740;
  assign rb4030 = 1'b0;
  assign rb4031 = 1'b0;
  assign rb4032 = rb3738 | 1'b0;
  assign rb4033 = rb4028 & rb4030;
  assign rb4034 = rb4029 & rb4031;
  assign rb4035 = (rb4028 & ~rb4030 & ~rb4031) | (rb4030 & ~rb4028 & ~rb4029);
  assign rb4036 = (rb4029 & ~rb4030 & ~rb4031) | (rb4031 & ~rb4028 & ~rb4029);
  assign rb4037 = rb4033 | (rb4035 & ~rb4032);
  assign rb4038 = rb4034 | (rb4036 & rb4032);
  assign rb4039 = (rb4035 | rb4036) & rb4032;
  assign rb4040 = (rb4035 | rb4036) & ~rb4032;
  assign rb4041 = rb3741;
  assign rb4042 = rb3742;
  assign rb4043 = 1'b0;
  assign rb4044 = 1'b0;
  assign rb4045 = rb3740 | 1'b0;
  assign rb4046 = rb4041 & rb4043;
  assign rb4047 = rb4042 & rb4044;
  assign rb4048 = (rb4041 & ~rb4043 & ~rb4044) | (rb4043 & ~rb4041 & ~rb4042);
  assign rb4049 = (rb4042 & ~rb4043 & ~rb4044) | (rb4044 & ~rb4041 & ~rb4042);
  assign rb4050 = rb4046 | (rb4048 & ~rb4045);
  assign rb4051 = rb4047 | (rb4049 & rb4045);
  assign rb4052 = (rb4048 | rb4049) & rb4045;
  assign rb4053 = (rb4048 | rb4049) & ~rb4045;
  assign rb4054 = rb3743;
  assign rb4055 = rb3744;
  assign rb4056 = 1'b0;
  assign rb4057 = 1'b0;
  assign rb4058 = rb3742 | 1'b0;
  assign rb4059 = rb4054 & rb4056;
  assign rb4060 = rb4055 & rb4057;
  assign rb4061 = (rb4054 & ~rb4056 & ~rb4057) | (rb4056 & ~rb4054 & ~rb4055);
  assign rb4062 = (rb4055 & ~rb4056 & ~rb4057) | (rb4057 & ~rb4054 & ~rb4055);
  assign rb4063 = rb4059 | (rb4061 & ~rb4058);
  assign rb4064 = rb4060 | (rb4062 & rb4058);
  assign rb4065 = (rb4061 | rb4062) & rb4058;
  assign rb4066 = (rb4061 | rb4062) & ~rb4058;
  assign rb4067 = rb3745;
  assign rb4068 = rb3746;
  assign rb4069 = 1'b0;
  assign rb4070 = 1'b0;
  assign rb4071 = rb3744 | 1'b0;
  assign rb4072 = rb4067 & rb4069;
  assign rb4073 = rb4068 & rb4070;
  assign rb4074 = (rb4067 & ~rb4069 & ~rb4070) | (rb4069 & ~rb4067 & ~rb4068);
  assign rb4075 = (rb4068 & ~rb4069 & ~rb4070) | (rb4070 & ~rb4067 & ~rb4068);
  assign rb4076 = rb4072 | (rb4074 & ~rb4071);
  assign rb4077 = rb4073 | (rb4075 & rb4071);
  assign rb4078 = (rb4074 | rb4075) & rb4071;
  assign rb4079 = (rb4074 | rb4075) & ~rb4071;
  assign rb4080 = rb3747;
  assign rb4081 = rb3748;
  assign rb4082 = 1'b0;
  assign rb4083 = 1'b0;
  assign rb4084 = rb3746 | 1'b0;
  assign rb4085 = rb4080 & rb4082;
  assign rb4086 = rb4081 & rb4083;
  assign rb4087 = (rb4080 & ~rb4082 & ~rb4083) | (rb4082 & ~rb4080 & ~rb4081);
  assign rb4088 = (rb4081 & ~rb4082 & ~rb4083) | (rb4083 & ~rb4080 & ~rb4081);
  assign rb4089 = rb4085 | (rb4087 & ~rb4084);
  assign rb4090 = rb4086 | (rb4088 & rb4084);
  assign rb4091 = (rb4087 | rb4088) & rb4084;
  assign rb4092 = (rb4087 | rb4088) & ~rb4084;
  assign rb4093 = rb3749;
  assign rb4094 = rb3750;
  assign rb4095 = 1'b0;
  assign rb4096 = 1'b0;
  assign rb4097 = rb3748 | 1'b0;
  assign rb4098 = rb4093 & rb4095;
  assign rb4099 = rb4094 & rb4096;
  assign rb4100 = (rb4093 & ~rb4095 & ~rb4096) | (rb4095 & ~rb4093 & ~rb4094);
  assign rb4101 = (rb4094 & ~rb4095 & ~rb4096) | (rb4096 & ~rb4093 & ~rb4094);
  assign rb4102 = rb4098 | (rb4100 & ~rb4097);
  assign rb4103 = rb4099 | (rb4101 & rb4097);
  assign rb4104 = (rb4100 | rb4101) & rb4097;
  assign rb4105 = (rb4100 | rb4101) & ~rb4097;
  assign rb4106 = rb3751;
  assign rb4107 = rb3752;
  assign rb4108 = 1'b0;
  assign rb4109 = 1'b0;
  assign rb4110 = rb3750 | 1'b0;
  assign rb4111 = rb4106 & rb4108;
  assign rb4112 = rb4107 & rb4109;
  assign rb4113 = (rb4106 & ~rb4108 & ~rb4109) | (rb4108 & ~rb4106 & ~rb4107);
  assign rb4114 = (rb4107 & ~rb4108 & ~rb4109) | (rb4109 & ~rb4106 & ~rb4107);
  assign rb4115 = rb4111 | (rb4113 & ~rb4110);
  assign rb4116 = rb4112 | (rb4114 & rb4110);
  assign rb4117 = (rb4113 | rb4114) & rb4110;
  assign rb4118 = (rb4113 | rb4114) & ~rb4110;
  assign rb4119 = rb3753;
  assign rb4120 = rb3754;
  assign rb4121 = 1'b0;
  assign rb4122 = 1'b0;
  assign rb4123 = rb3752 | 1'b0;
  assign rb4124 = rb4119 & rb4121;
  assign rb4125 = rb4120 & rb4122;
  assign rb4126 = (rb4119 & ~rb4121 & ~rb4122) | (rb4121 & ~rb4119 & ~rb4120);
  assign rb4127 = (rb4120 & ~rb4121 & ~rb4122) | (rb4122 & ~rb4119 & ~rb4120);
  assign rb4128 = rb4124 | (rb4126 & ~rb4123);
  assign rb4129 = rb4125 | (rb4127 & rb4123);
  assign rb4130 = (rb4126 | rb4127) & rb4123;
  assign rb4131 = (rb4126 | rb4127) & ~rb4123;
  assign rb4132 = rb3755;
  assign rb4133 = rb3756;
  assign rb4134 = 1'b0;
  assign rb4135 = 1'b0;
  assign rb4136 = rb3754 | 1'b0;
  assign rb4137 = rb4132 & rb4134;
  assign rb4138 = rb4133 & rb4135;
  assign rb4139 = (rb4132 & ~rb4134 & ~rb4135) | (rb4134 & ~rb4132 & ~rb4133);
  assign rb4140 = (rb4133 & ~rb4134 & ~rb4135) | (rb4135 & ~rb4132 & ~rb4133);
  assign rb4141 = rb4137 | (rb4139 & ~rb4136);
  assign rb4142 = rb4138 | (rb4140 & rb4136);
  assign rb4143 = (rb4139 | rb4140) & rb4136;
  assign rb4144 = (rb4139 | rb4140) & ~rb4136;
  assign rb4145 = rb3757;
  assign rb4146 = rb3758;
  assign rb4147 = 1'b0;
  assign rb4148 = 1'b0;
  assign rb4149 = rb3756 | 1'b0;
  assign rb4150 = rb4145 & rb4147;
  assign rb4151 = rb4146 & rb4148;
  assign rb4152 = (rb4145 & ~rb4147 & ~rb4148) | (rb4147 & ~rb4145 & ~rb4146);
  assign rb4153 = (rb4146 & ~rb4147 & ~rb4148) | (rb4148 & ~rb4145 & ~rb4146);
  assign rb4154 = rb4150 | (rb4152 & ~rb4149);
  assign rb4155 = rb4151 | (rb4153 & rb4149);
  assign rb4156 = (rb4152 | rb4153) & rb4149;
  assign rb4157 = (rb4152 | rb4153) & ~rb4149;
  assign rb4158 = rb3759;
  assign rb4159 = rb3760;
  assign rb4160 = 1'b0;
  assign rb4161 = 1'b0;
  assign rb4162 = rb3758 | 1'b0;
  assign rb4163 = rb4158 & rb4160;
  assign rb4164 = rb4159 & rb4161;
  assign rb4165 = (rb4158 & ~rb4160 & ~rb4161) | (rb4160 & ~rb4158 & ~rb4159);
  assign rb4166 = (rb4159 & ~rb4160 & ~rb4161) | (rb4161 & ~rb4158 & ~rb4159);
  assign rb4167 = rb4163 | (rb4165 & ~rb4162);
  assign rb4168 = rb4164 | (rb4166 & rb4162);
  assign rb4169 = (rb4165 | rb4166) & rb4162;
  assign rb4170 = (rb4165 | rb4166) & ~rb4162;
  assign rb4171 = rb3761;
  assign rb4172 = rb3762;
  assign rb4173 = 1'b0;
  assign rb4174 = 1'b0;
  assign rb4175 = rb3760 | 1'b0;
  assign rb4176 = rb4171 & rb4173;
  assign rb4177 = rb4172 & rb4174;
  assign rb4178 = (rb4171 & ~rb4173 & ~rb4174) | (rb4173 & ~rb4171 & ~rb4172);
  assign rb4179 = (rb4172 & ~rb4173 & ~rb4174) | (rb4174 & ~rb4171 & ~rb4172);
  assign rb4180 = rb4176 | (rb4178 & ~rb4175);
  assign rb4181 = rb4177 | (rb4179 & rb4175);
  assign rb4182 = (rb4178 | rb4179) & rb4175;
  assign rb4183 = (rb4178 | rb4179) & ~rb4175;
  assign rb4184 = rb3763;
  assign rb4185 = rb3764;
  assign rb4186 = 1'b0;
  assign rb4187 = 1'b0;
  assign rb4188 = rb3762 | 1'b0;
  assign rb4189 = rb4184 & rb4186;
  assign rb4190 = rb4185 & rb4187;
  assign rb4191 = (rb4184 & ~rb4186 & ~rb4187) | (rb4186 & ~rb4184 & ~rb4185);
  assign rb4192 = (rb4185 & ~rb4186 & ~rb4187) | (rb4187 & ~rb4184 & ~rb4185);
  assign rb4193 = rb4189 | (rb4191 & ~rb4188);
  assign rb4194 = rb4190 | (rb4192 & rb4188);
  assign rb4195 = (rb4191 | rb4192) & rb4188;
  assign rb4196 = (rb4191 | rb4192) & ~rb4188;
  assign rb4197 = rb3765;
  assign rb4198 = rb3766;
  assign rb4199 = 1'b0;
  assign rb4200 = 1'b0;
  assign rb4201 = rb3764 | 1'b0;
  assign rb4202 = rb4197 & rb4199;
  assign rb4203 = rb4198 & rb4200;
  assign rb4204 = (rb4197 & ~rb4199 & ~rb4200) | (rb4199 & ~rb4197 & ~rb4198);
  assign rb4205 = (rb4198 & ~rb4199 & ~rb4200) | (rb4200 & ~rb4197 & ~rb4198);
  assign rb4206 = rb4202 | (rb4204 & ~rb4201);
  assign rb4207 = rb4203 | (rb4205 & rb4201);
  assign rb4208 = (rb4204 | rb4205) & rb4201;
  assign rb4209 = (rb4204 | rb4205) & ~rb4201;
  assign rb4210 = (rb3779 & ~1'b0) | (1'b0 & ~rb3780);
  assign rb4211 = (rb3780 & ~1'b0) | (1'b0 & ~rb3779);
  assign rb4212 = (rb3792 & ~rb3778) | (rb3777 & ~rb3793);
  assign rb4213 = (rb3793 & ~rb3777) | (rb3778 & ~rb3792);
  assign rb4214 = (rb3805 & ~rb3791) | (rb3790 & ~rb3806);
  assign rb4215 = (rb3806 & ~rb3790) | (rb3791 & ~rb3805);
  assign rb4216 = (rb3818 & ~rb3804) | (rb3803 & ~rb3819);
  assign rb4217 = (rb3819 & ~rb3803) | (rb3804 & ~rb3818);
  assign rb4218 = (rb3831 & ~rb3817) | (rb3816 & ~rb3832);
  assign rb4219 = (rb3832 & ~rb3816) | (rb3817 & ~rb3831);
  assign rb4220 = (rb3844 & ~rb3830) | (rb3829 & ~rb3845);
  assign rb4221 = (rb3845 & ~rb3829) | (rb3830 & ~rb3844);
  assign rb4222 = (rb3857 & ~rb3843) | (rb3842 & ~rb3858);
  assign rb4223 = (rb3858 & ~rb3842) | (rb3843 & ~rb3857);
  assign rb4224 = (rb3870 & ~rb3856) | (rb3855 & ~rb3871);
  assign rb4225 = (rb3871 & ~rb3855) | (rb3856 & ~rb3870);
  assign rb4226 = (rb3883 & ~rb3869) | (rb3868 & ~rb3884);
  assign rb4227 = (rb3884 & ~rb3868) | (rb3869 & ~rb3883);
  assign rb4228 = (rb3896 & ~rb3882) | (rb3881 & ~rb3897);
  assign rb4229 = (rb3897 & ~rb3881) | (rb3882 & ~rb3896);
  assign rb4230 = (rb3909 & ~rb3895) | (rb3894 & ~rb3910);
  assign rb4231 = (rb3910 & ~rb3894) | (rb3895 & ~rb3909);
  assign rb4232 = (rb3922 & ~rb3908) | (rb3907 & ~rb3923);
  assign rb4233 = (rb3923 & ~rb3907) | (rb3908 & ~rb3922);
  assign rb4234 = (rb3935 & ~rb3921) | (rb3920 & ~rb3936);
  assign rb4235 = (rb3936 & ~rb3920) | (rb3921 & ~rb3935);
  assign rb4236 = (rb3948 & ~rb3934) | (rb3933 & ~rb3949);
  assign rb4237 = (rb3949 & ~rb3933) | (rb3934 & ~rb3948);
  assign rb4238 = (rb3961 & ~rb3947) | (rb3946 & ~rb3962);
  assign rb4239 = (rb3962 & ~rb3946) | (rb3947 & ~rb3961);
  assign rb4240 = (rb3974 & ~rb3960) | (rb3959 & ~rb3975);
  assign rb4241 = (rb3975 & ~rb3959) | (rb3960 & ~rb3974);
  assign rb4242 = (rb3987 & ~rb3973) | (rb3972 & ~rb3988);
  assign rb4243 = (rb3988 & ~rb3972) | (rb3973 & ~rb3987);
  assign rb4244 = (rb4000 & ~rb3986) | (rb3985 & ~rb4001);
  assign rb4245 = (rb4001 & ~rb3985) | (rb3986 & ~rb4000);
  assign rb4246 = (rb4013 & ~rb3999) | (rb3998 & ~rb4014);
  assign rb4247 = (rb4014 & ~rb3998) | (rb3999 & ~rb4013);
  assign rb4248 = (rb4026 & ~rb4012) | (rb4011 & ~rb4027);
  assign rb4249 = (rb4027 & ~rb4011) | (rb4012 & ~rb4026);
  assign rb4250 = (rb4039 & ~rb4025) | (rb4024 & ~rb4040);
  assign rb4251 = (rb4040 & ~rb4024) | (rb4025 & ~rb4039);
  assign rb4252 = (rb4052 & ~rb4038) | (rb4037 & ~rb4053);
  assign rb4253 = (rb4053 & ~rb4037) | (rb4038 & ~rb4052);
  assign rb4254 = (rb4065 & ~rb4051) | (rb4050 & ~rb4066);
  assign rb4255 = (rb4066 & ~rb4050) | (rb4051 & ~rb4065);
  assign rb4256 = (rb4078 & ~rb4064) | (rb4063 & ~rb4079);
  assign rb4257 = (rb4079 & ~rb4063) | (rb4064 & ~rb4078);
  assign rb4258 = (rb4091 & ~rb4077) | (rb4076 & ~rb4092);
  assign rb4259 = (rb4092 & ~rb4076) | (rb4077 & ~rb4091);
  assign rb4260 = (rb4104 & ~rb4090) | (rb4089 & ~rb4105);
  assign rb4261 = (rb4105 & ~rb4089) | (rb4090 & ~rb4104);
  assign rb4262 = (rb4117 & ~rb4103) | (rb4102 & ~rb4118);
  assign rb4263 = (rb4118 & ~rb4102) | (rb4103 & ~rb4117);
  assign rb4264 = (rb4130 & ~rb4116) | (rb4115 & ~rb4131);
  assign rb4265 = (rb4131 & ~rb4115) | (rb4116 & ~rb4130);
  assign rb4266 = (rb4143 & ~rb4129) | (rb4128 & ~rb4144);
  assign rb4267 = (rb4144 & ~rb4128) | (rb4129 & ~rb4143);
  assign rb4268 = (rb4156 & ~rb4142) | (rb4141 & ~rb4157);
  assign rb4269 = (rb4157 & ~rb4141) | (rb4142 & ~rb4156);
  assign rb4270 = (rb4169 & ~rb4155) | (rb4154 & ~rb4170);
  assign rb4271 = (rb4170 & ~rb4154) | (rb4155 & ~rb4169);
  assign rb4272 = (rb4182 & ~rb4168) | (rb4167 & ~rb4183);
  assign rb4273 = (rb4183 & ~rb4167) | (rb4168 & ~rb4182);
  assign rb4274 = (rb4195 & ~rb4181) | (rb4180 & ~rb4196);
  assign rb4275 = (rb4196 & ~rb4180) | (rb4181 & ~rb4195);
  assign rb4276 = (rb4208 & ~rb4194) | (rb4193 & ~rb4209);
  assign rb4277 = (rb4209 & ~rb4193) | (rb4194 & ~rb4208);
  assign rb4278 = (1'b0 & ~rb4207) | (rb4206 & ~1'b0);
  assign rb4279 = (1'b0 & ~rb4206) | (rb4207 & ~1'b0);
  assign rb4280 = rb4210;
  assign rb4281 = rb4212;
  assign rb4282 = rb4214;
  assign rb4283 = rb4216;
  assign rb4284 = rb4218;
  assign rb4285 = rb4220;
  assign rb4286 = rb4222;
  assign rb4287 = rb4224;
  assign rb4288 = rb4226;
  assign rb4289 = rb4228;
  assign rb4290 = rb4230;
  assign rb4291 = rb4232;
  assign rb4292 = rb4234;
  assign rb4293 = rb4236;
  assign rb4294 = rb4238;
  assign rb4295 = rb4240;
  assign rb4296 = rb4242;
  assign rb4297 = rb4244;
  assign rb4298 = rb4246;
  assign rb4299 = rb4248;
  assign rb4300 = rb4250;
  assign rb4301 = rb4252;
  assign rb4302 = rb4254;
  assign rb4303 = rb4256;
  assign rb4304 = rb4258;
  assign rb4305 = rb4260;
  assign rb4306 = rb4262;
  assign rb4307 = rb4264;
  assign rb4308 = rb4266;
  assign rb4309 = rb4268;
  assign rb4310 = rb4270;
  assign rb4311 = rb4272;
  assign rb4312 = rb4274;
  assign rb4313 = rb4276;
  assign rb4314 = rb4211;
  assign rb4315 = rb4213;
  assign rb4316 = rb4215;
  assign rb4317 = rb4217;
  assign rb4318 = rb4219;
  assign rb4319 = rb4221;
  assign rb4320 = rb4223;
  assign rb4321 = rb4225;
  assign rb4322 = rb4227;
  assign rb4323 = rb4229;
  assign rb4324 = rb4231;
  assign rb4325 = rb4233;
  assign rb4326 = rb4235;
  assign rb4327 = rb4237;
  assign rb4328 = rb4239;
  assign rb4329 = rb4241;
  assign rb4330 = rb4243;
  assign rb4331 = rb4245;
  assign rb4332 = rb4247;
  assign rb4333 = rb4249;
  assign rb4334 = rb4251;
  assign rb4335 = rb4253;
  assign rb4336 = rb4255;
  assign rb4337 = rb4257;
  assign rb4338 = rb4259;
  assign rb4339 = rb4261;
  assign rb4340 = rb4263;
  assign rb4341 = rb4265;
  assign rb4342 = rb4267;
  assign rb4343 = rb4269;
  assign rb4344 = rb4271;
  assign rb4345 = rb4273;
  assign rb4346 = rb4275;
  assign rb4347 = rb4277;
  logic [33:0] zp, zm;
  assign zp = {rb4313, rb4312, rb4311, rb4310, rb4309, rb4308, rb4307, rb4306, rb4305, rb4304, rb4303, rb4302, rb4301, rb4300, rb4299, rb4298, rb4297, rb4296, rb4295, rb4294, rb4293, rb4292, rb4291, rb4290, rb4289, rb4288, rb4287, rb4286, rb4285, rb4284, rb4283, rb4282, rb4281, rb4280};
  assign zm = {rb4347, rb4346, rb4345, rb4344, rb4343, rb4342, rb4341, rb4340, rb4339, rb4338, rb4337, rb4336, rb4335, rb4334, rb4333, rb4332, rb4331, rb4330, rb4329, rb4328, rb4327, rb4326, rb4325, rb4324, rb4323, rb4322, rb4321, rb4320, rb4319, rb4318, rb4317, rb4316, rb4315, rb4314};
  logic [33:0] nz; assign nz = ~zm;
  logic [33:0] dif; logic co;
  // the converter: plus word less minus word through the prefix_synthesis_nonuniform_arrival adder
  fam_prefix_arrival_6_6_6_5_5_5_5_5_5_4_4_4_4_4_3_3_3_3_3_3_2_2_2_2_2_1_1_1_1_1_1_0_0_0_w34 u_conv (.a(zp), .b(nz), .cin(1'b1), .s(dif), .cout(co));
  assign p = dif[31:0];
endmodule

// segmented_grid (square, depth 1): 4 x 4 segment products of 2 x 2 bits (direct_pp_parallel) merged by shift_add_tree (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w8_s_pf90d0475 (input logic [7:0] a, input logic [7:0] b, output logic [15:0] p);
  logic [7:0] ae; assign ae = a;
  logic [7:0] be; assign be = b;
  logic [1:0] sa00; assign sa00 = ae[1:0];
  logic [1:0] sb00; assign sb00 = be[1:0];
  logic [3:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w2_u_p8dfaf87b u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [1:0] sa01; assign sa01 = ae[1:0];
  logic [1:0] sb01; assign sb01 = be[3:2];
  logic [3:0] sp01;
  // segment product (0, 1) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w2_u_p8dfaf87b u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [1:0] sa02; assign sa02 = ae[1:0];
  logic [1:0] sb02; assign sb02 = be[5:4];
  logic [3:0] sp02;
  // segment product (0, 2) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w2_u_p8dfaf87b u3 (.a(sa02), .b(sb02), .p(sp02));
  logic [2:0] sa03; assign sa03 = {{1{1'b0}}, ae[1:0]};
  logic [2:0] sb03; assign sb03 = {{1{be[7]}}, be[7:6]};
  logic [5:0] sp03;
  // segment product (0, 3) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w3_s_p8dfaf87b u4 (.a(sa03), .b(sb03), .p(sp03));
  logic [1:0] sa10; assign sa10 = ae[3:2];
  logic [1:0] sb10; assign sb10 = be[1:0];
  logic [3:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w2_u_p8dfaf87b u5 (.a(sa10), .b(sb10), .p(sp10));
  logic [1:0] sa11; assign sa11 = ae[3:2];
  logic [1:0] sb11; assign sb11 = be[3:2];
  logic [3:0] sp11;
  // segment product (1, 1) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w2_u_p8dfaf87b u6 (.a(sa11), .b(sb11), .p(sp11));
  logic [1:0] sa12; assign sa12 = ae[3:2];
  logic [1:0] sb12; assign sb12 = be[5:4];
  logic [3:0] sp12;
  // segment product (1, 2) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w2_u_p8dfaf87b u7 (.a(sa12), .b(sb12), .p(sp12));
  logic [2:0] sa13; assign sa13 = {{1{1'b0}}, ae[3:2]};
  logic [2:0] sb13; assign sb13 = {{1{be[7]}}, be[7:6]};
  logic [5:0] sp13;
  // segment product (1, 3) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w3_s_p8dfaf87b u8 (.a(sa13), .b(sb13), .p(sp13));
  logic [1:0] sa20; assign sa20 = ae[5:4];
  logic [1:0] sb20; assign sb20 = be[1:0];
  logic [3:0] sp20;
  // segment product (2, 0) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w2_u_p8dfaf87b u9 (.a(sa20), .b(sb20), .p(sp20));
  logic [1:0] sa21; assign sa21 = ae[5:4];
  logic [1:0] sb21; assign sb21 = be[3:2];
  logic [3:0] sp21;
  // segment product (2, 1) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w2_u_p8dfaf87b u10 (.a(sa21), .b(sb21), .p(sp21));
  logic [1:0] sa22; assign sa22 = ae[5:4];
  logic [1:0] sb22; assign sb22 = be[5:4];
  logic [3:0] sp22;
  // segment product (2, 2) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w2_u_p8dfaf87b u11 (.a(sa22), .b(sb22), .p(sp22));
  logic [2:0] sa23; assign sa23 = {{1{1'b0}}, ae[5:4]};
  logic [2:0] sb23; assign sb23 = {{1{be[7]}}, be[7:6]};
  logic [5:0] sp23;
  // segment product (2, 3) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w3_s_p8dfaf87b u12 (.a(sa23), .b(sb23), .p(sp23));
  logic [2:0] sa30; assign sa30 = {{1{ae[7]}}, ae[7:6]};
  logic [2:0] sb30; assign sb30 = {{1{1'b0}}, be[1:0]};
  logic [5:0] sp30;
  // segment product (3, 0) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w3_s_p8dfaf87b u13 (.a(sa30), .b(sb30), .p(sp30));
  logic [2:0] sa31; assign sa31 = {{1{ae[7]}}, ae[7:6]};
  logic [2:0] sb31; assign sb31 = {{1{1'b0}}, be[3:2]};
  logic [5:0] sp31;
  // segment product (3, 1) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w3_s_p8dfaf87b u14 (.a(sa31), .b(sb31), .p(sp31));
  logic [2:0] sa32; assign sa32 = {{1{ae[7]}}, ae[7:6]};
  logic [2:0] sb32; assign sb32 = {{1{1'b0}}, be[5:4]};
  logic [5:0] sp32;
  // segment product (3, 2) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w3_s_p8dfaf87b u15 (.a(sa32), .b(sb32), .p(sp32));
  logic [2:0] sa33; assign sa33 = {{1{ae[7]}}, ae[7:6]};
  logic [2:0] sb33; assign sb33 = {{1{be[7]}}, be[7:6]};
  logic [5:0] sp33;
  // segment product (3, 3) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w3_s_p8dfaf87b u16 (.a(sa33), .b(sb33), .p(sp33));
  logic [17:0] t_sp00; assign t_sp00 = {{(18-4){1'b0}}, sp00} << 0;
  logic [17:0] t_sp01; assign t_sp01 = {{(18-4){1'b0}}, sp01} << 2;
  logic [17:0] t_sp02; assign t_sp02 = {{(18-4){1'b0}}, sp02} << 4;
  logic [17:0] t_sp03; assign t_sp03 = $signed({{(18-6){sp03[5]}}, sp03}) <<< 6;
  logic [17:0] t_sp10; assign t_sp10 = {{(18-4){1'b0}}, sp10} << 2;
  logic [17:0] t_sp11; assign t_sp11 = {{(18-4){1'b0}}, sp11} << 4;
  logic [17:0] t_sp12; assign t_sp12 = {{(18-4){1'b0}}, sp12} << 6;
  logic [17:0] t_sp13; assign t_sp13 = $signed({{(18-6){sp13[5]}}, sp13}) <<< 8;
  logic [17:0] t_sp20; assign t_sp20 = {{(18-4){1'b0}}, sp20} << 4;
  logic [17:0] t_sp21; assign t_sp21 = {{(18-4){1'b0}}, sp21} << 6;
  logic [17:0] t_sp22; assign t_sp22 = {{(18-4){1'b0}}, sp22} << 8;
  logic [17:0] t_sp23; assign t_sp23 = $signed({{(18-6){sp23[5]}}, sp23}) <<< 10;
  logic [17:0] t_sp30; assign t_sp30 = $signed({{(18-6){sp30[5]}}, sp30}) <<< 6;
  logic [17:0] t_sp31; assign t_sp31 = $signed({{(18-6){sp31[5]}}, sp31}) <<< 8;
  logic [17:0] t_sp32; assign t_sp32 = $signed({{(18-6){sp32[5]}}, sp32}) <<< 10;
  logic [17:0] t_sp33; assign t_sp33 = $signed({{(18-6){sp33[5]}}, sp33}) <<< 12;
  logic [18:0] tr0;
  // merge tree adder 0
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18 u17 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(tr0[17:0]), .cout(tr0[18]));
  logic [18:0] tr1;
  // merge tree adder 1
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18 u18 (.a(t_sp02), .b(t_sp03), .cin(1'b0), .s(tr1[17:0]), .cout(tr1[18]));
  logic [18:0] tr2;
  // merge tree adder 2
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18 u19 (.a(t_sp10), .b(t_sp11), .cin(1'b0), .s(tr2[17:0]), .cout(tr2[18]));
  logic [18:0] tr3;
  // merge tree adder 3
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18 u20 (.a(t_sp12), .b(t_sp13), .cin(1'b0), .s(tr3[17:0]), .cout(tr3[18]));
  logic [18:0] tr4;
  // merge tree adder 4
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18 u21 (.a(t_sp20), .b(t_sp21), .cin(1'b0), .s(tr4[17:0]), .cout(tr4[18]));
  logic [18:0] tr5;
  // merge tree adder 5
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18 u22 (.a(t_sp22), .b(t_sp23), .cin(1'b0), .s(tr5[17:0]), .cout(tr5[18]));
  logic [18:0] tr6;
  // merge tree adder 6
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18 u23 (.a(t_sp30), .b(t_sp31), .cin(1'b0), .s(tr6[17:0]), .cout(tr6[18]));
  logic [18:0] tr7;
  // merge tree adder 7
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18 u24 (.a(t_sp32), .b(t_sp33), .cin(1'b0), .s(tr7[17:0]), .cout(tr7[18]));
  logic [18:0] tr8;
  // merge tree adder 8
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18 u25 (.a(tr0[17:0]), .b(tr1[17:0]), .cin(1'b0), .s(tr8[17:0]), .cout(tr8[18]));
  logic [18:0] tr9;
  // merge tree adder 9
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18 u26 (.a(tr2[17:0]), .b(tr3[17:0]), .cin(1'b0), .s(tr9[17:0]), .cout(tr9[18]));
  logic [18:0] tr10;
  // merge tree adder 10
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18 u27 (.a(tr4[17:0]), .b(tr5[17:0]), .cin(1'b0), .s(tr10[17:0]), .cout(tr10[18]));
  logic [18:0] tr11;
  // merge tree adder 11
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18 u28 (.a(tr6[17:0]), .b(tr7[17:0]), .cin(1'b0), .s(tr11[17:0]), .cout(tr11[18]));
  logic [18:0] tr12;
  // merge tree adder 12
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18 u29 (.a(tr8[17:0]), .b(tr9[17:0]), .cin(1'b0), .s(tr12[17:0]), .cout(tr12[18]));
  logic [18:0] tr13;
  // merge tree adder 13
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18 u30 (.a(tr10[17:0]), .b(tr11[17:0]), .cin(1'b0), .s(tr13[17:0]), .cout(tr13[18]));
  logic [18:0] tr14;
  // merge tree adder 14
  fam_adder_sparse_prefix_hybrid_p135e0b5f89968f4c22b3ef8346e4990a8b7f2800556949105d8e9b4799f9adb1_w18 u31 (.a(tr12[17:0]), .b(tr13[17:0]), .cin(1'b0), .s(tr14[17:0]), .cout(tr14[18]));
  logic [17:0] full; assign full = tr14[17:0];
  assign p = full[15:0];
endmodule


module fam_prefix_arrival_6_6_6_5_5_5_5_5_5_4_4_4_4_4_3_3_3_3_3_3_2_2_2_2_2_1_1_1_1_1_1_0_0_0_w34 (input logic [33:0] a, input logic [33:0] b, input logic cin,
  output logic [33:0] s, output logic cout);
  // prefix graph: {'n': 34, 'levels': 10, 'size': 204, 'fanout': 18, 'tracks': 7, 'exact_split': True, 'valency': 2}
  logic [33:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [33:0] g0, p0;
  assign g0 = {gi[33:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_1_2, P_1_2, G_2_3, P_2_3, G_3_4, P_3_4, G_4_5, P_4_5, G_5_6, P_5_6, G_6_7, P_6_7, G_7_8, P_7_8, G_8_9, P_8_9, G_9_10, P_9_10, G_10_11, P_10_11, G_11_12, P_11_12, G_12_13, P_12_13, G_13_14, P_13_14, G_14_15, P_14_15, G_15_16, P_15_16, G_16_17, P_16_17, G_17_18, P_17_18, G_18_19, P_18_19, G_19_20, P_19_20, G_20_21, P_20_21, G_21_22, P_21_22, G_22_23, P_22_23, G_23_24, P_23_24, G_24_25, P_24_25, G_25_26, P_25_26, G_26_27, P_26_27, G_27_28, P_27_28, G_28_29, P_28_29, G_29_30, P_29_30, G_30_31, P_30_31, G_31_32, P_31_32, G_32_33, P_32_33, G_0_2, G_0_3, G_2_4, P_2_4, G_3_5, P_3_5, G_3_6, P_3_6, G_4_7, P_4_7, G_5_8, P_5_8, G_6_9, P_6_9, G_8_10, P_8_10, G_9_11, P_9_11, G_9_12, P_9_12, G_10_13, P_10_13, G_11_14, P_11_14, G_13_15, P_13_15, G_14_16, P_14_16, G_14_17, P_14_17, G_15_18, P_15_18, G_16_19, P_16_19, G_17_20, P_17_20, G_19_21, P_19_21, G_20_22, P_20_22, G_20_23, P_20_23, G_21_24, P_21_24, G_22_25, P_22_25, G_24_26, P_24_26, G_25_27, P_25_27, G_25_28, P_25_28, G_26_29, P_26_29, G_27_30, P_27_30, G_28_31, P_28_31, G_30_32, P_30_32, G_31_33, P_31_33, G_0_4, G_1_5, P_1_5, G_1_6, P_1_6, G_2_7, P_2_7, G_2_8, P_2_8, G_3_9, P_3_9, G_6_10, P_6_10, G_7_11, P_7_11, G_7_12, P_7_12, G_8_13, P_8_13, G_8_14, P_8_14, G_11_15, P_11_15, G_12_16, P_12_16, G_12_17, P_12_17, G_13_18, P_13_18, G_13_19, P_13_19, G_14_20, P_14_20, G_17_21, P_17_21, G_18_22, P_18_22, G_18_23, P_18_23, G_19_24, P_19_24, G_19_25, P_19_25, G_22_26, P_22_26, G_23_27, P_23_27, G_23_28, P_23_28, G_24_29, P_24_29, G_24_30, P_24_30, G_25_31, P_25_31, G_28_32, P_28_32, G_29_33, P_29_33, G_0_5, G_0_6, G_0_7, G_0_8, G_0_9, G_3_10, P_3_10, G_3_11, P_3_11, G_3_12, P_3_12, G_4_13, P_4_13, G_4_14, P_4_14, G_8_15, P_8_15, G_9_16, P_9_16, G_9_17, P_9_17, G_9_18, P_9_18, G_9_19, P_9_19, G_10_20, P_10_20, G_14_21, P_14_21, G_14_22, P_14_22, G_14_23, P_14_23, G_15_24, P_15_24, G_15_25, P_15_25, G_19_26, P_19_26, G_20_27, P_20_27, G_20_28, P_20_28, G_20_29, P_20_29, G_20_30, P_20_30, G_21_31, P_21_31, G_25_32, P_25_32, G_25_33, P_25_33, G_0_10, G_0_11, G_0_12, G_0_13, G_0_14, G_4_15, P_4_15, G_5_16, P_5_16, G_5_17, P_5_17, G_5_18, P_5_18, G_5_19, P_5_19, G_6_20, P_6_20, G_10_21, P_10_21, G_10_22, P_10_22, G_10_23, P_10_23, G_11_24, P_11_24, G_11_25, P_11_25, G_15_26, P_15_26, G_16_27, P_16_27, G_16_28, P_16_28, G_16_29, P_16_29, G_16_30, P_16_30, G_17_31, P_17_31, G_21_32, P_21_32, G_21_33, P_21_33, G_0_15, G_0_16, G_0_17, G_0_18, G_0_19, G_1_20, P_1_20, G_6_21, P_6_21, G_6_22, P_6_22, G_6_23, P_6_23, G_6_24, P_6_24, G_6_25, P_6_25, G_11_26, P_11_26, G_11_27, P_11_27, G_11_28, P_11_28, G_11_29, P_11_29, G_11_30, P_11_30, G_12_31, P_12_31, G_17_32, P_17_32, G_17_33, P_17_33, G_0_20, G_1_21, P_1_21, G_1_22, P_1_22, G_1_23, P_1_23, G_1_24, P_1_24, G_1_25, P_1_25, G_6_26, P_6_26, G_6_27, P_6_27, G_6_28, P_6_28, G_6_29, P_6_29, G_6_30, P_6_30, G_7_31, P_7_31, G_12_32, P_12_32, G_12_33, P_12_33, G_0_21, G_0_22, G_0_23, G_0_24, G_0_25, G_1_26, P_1_26, G_1_27, P_1_27, G_1_28, P_1_28, G_1_29, P_1_29, G_1_30, P_1_30, G_1_31, P_1_31, G_7_32, P_7_32, G_7_33, P_7_33, G_0_26, G_0_27, G_0_28, G_0_29, G_0_30, G_0_31, G_1_32, P_1_32, G_1_33, P_1_33, G_0_32, G_0_33;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_5_6 = g0[6] | (p0[6] & g0[5]);
  assign P_5_6 = p0[6] & p0[5];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_7_8 = g0[8] | (p0[8] & g0[7]);
  assign P_7_8 = p0[8] & p0[7];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_9_10 = g0[10] | (p0[10] & g0[9]);
  assign P_9_10 = p0[10] & p0[9];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_11_12 = g0[12] | (p0[12] & g0[11]);
  assign P_11_12 = p0[12] & p0[11];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_13_14 = g0[14] | (p0[14] & g0[13]);
  assign P_13_14 = p0[14] & p0[13];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_15_16 = g0[16] | (p0[16] & g0[15]);
  assign P_15_16 = p0[16] & p0[15];
  assign G_16_17 = g0[17] | (p0[17] & g0[16]);
  assign P_16_17 = p0[17] & p0[16];
  assign G_17_18 = g0[18] | (p0[18] & g0[17]);
  assign P_17_18 = p0[18] & p0[17];
  assign G_18_19 = g0[19] | (p0[19] & g0[18]);
  assign P_18_19 = p0[19] & p0[18];
  assign G_19_20 = g0[20] | (p0[20] & g0[19]);
  assign P_19_20 = p0[20] & p0[19];
  assign G_20_21 = g0[21] | (p0[21] & g0[20]);
  assign P_20_21 = p0[21] & p0[20];
  assign G_21_22 = g0[22] | (p0[22] & g0[21]);
  assign P_21_22 = p0[22] & p0[21];
  assign G_22_23 = g0[23] | (p0[23] & g0[22]);
  assign P_22_23 = p0[23] & p0[22];
  assign G_23_24 = g0[24] | (p0[24] & g0[23]);
  assign P_23_24 = p0[24] & p0[23];
  assign G_24_25 = g0[25] | (p0[25] & g0[24]);
  assign P_24_25 = p0[25] & p0[24];
  assign G_25_26 = g0[26] | (p0[26] & g0[25]);
  assign P_25_26 = p0[26] & p0[25];
  assign G_26_27 = g0[27] | (p0[27] & g0[26]);
  assign P_26_27 = p0[27] & p0[26];
  assign G_27_28 = g0[28] | (p0[28] & g0[27]);
  assign P_27_28 = p0[28] & p0[27];
  assign G_28_29 = g0[29] | (p0[29] & g0[28]);
  assign P_28_29 = p0[29] & p0[28];
  assign G_29_30 = g0[30] | (p0[30] & g0[29]);
  assign P_29_30 = p0[30] & p0[29];
  assign G_30_31 = g0[31] | (p0[31] & g0[30]);
  assign P_30_31 = p0[31] & p0[30];
  assign G_31_32 = g0[32] | (p0[32] & g0[31]);
  assign P_31_32 = p0[32] & p0[31];
  assign G_32_33 = g0[33] | (p0[33] & g0[32]);
  assign P_32_33 = p0[33] & p0[32];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_2_4 = G_3_4 | (P_3_4 & g0[2]);
  assign P_2_4 = P_3_4 & p0[2];
  assign G_3_5 = G_4_5 | (P_4_5 & g0[3]);
  assign P_3_5 = P_4_5 & p0[3];
  assign G_3_6 = G_5_6 | (P_5_6 & G_3_4);
  assign P_3_6 = P_5_6 & P_3_4;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_5_8 = G_7_8 | (P_7_8 & G_5_6);
  assign P_5_8 = P_7_8 & P_5_6;
  assign G_6_9 = G_8_9 | (P_8_9 & G_6_7);
  assign P_6_9 = P_8_9 & P_6_7;
  assign G_8_10 = G_9_10 | (P_9_10 & g0[8]);
  assign P_8_10 = P_9_10 & p0[8];
  assign G_9_11 = G_10_11 | (P_10_11 & g0[9]);
  assign P_9_11 = P_10_11 & p0[9];
  assign G_9_12 = G_11_12 | (P_11_12 & G_9_10);
  assign P_9_12 = P_11_12 & P_9_10;
  assign G_10_13 = G_12_13 | (P_12_13 & G_10_11);
  assign P_10_13 = P_12_13 & P_10_11;
  assign G_11_14 = G_13_14 | (P_13_14 & G_11_12);
  assign P_11_14 = P_13_14 & P_11_12;
  assign G_13_15 = G_14_15 | (P_14_15 & g0[13]);
  assign P_13_15 = P_14_15 & p0[13];
  assign G_14_16 = G_15_16 | (P_15_16 & g0[14]);
  assign P_14_16 = P_15_16 & p0[14];
  assign G_14_17 = G_16_17 | (P_16_17 & G_14_15);
  assign P_14_17 = P_16_17 & P_14_15;
  assign G_15_18 = G_17_18 | (P_17_18 & G_15_16);
  assign P_15_18 = P_17_18 & P_15_16;
  assign G_16_19 = G_18_19 | (P_18_19 & G_16_17);
  assign P_16_19 = P_18_19 & P_16_17;
  assign G_17_20 = G_19_20 | (P_19_20 & G_17_18);
  assign P_17_20 = P_19_20 & P_17_18;
  assign G_19_21 = G_20_21 | (P_20_21 & g0[19]);
  assign P_19_21 = P_20_21 & p0[19];
  assign G_20_22 = G_21_22 | (P_21_22 & g0[20]);
  assign P_20_22 = P_21_22 & p0[20];
  assign G_20_23 = G_22_23 | (P_22_23 & G_20_21);
  assign P_20_23 = P_22_23 & P_20_21;
  assign G_21_24 = G_23_24 | (P_23_24 & G_21_22);
  assign P_21_24 = P_23_24 & P_21_22;
  assign G_22_25 = G_24_25 | (P_24_25 & G_22_23);
  assign P_22_25 = P_24_25 & P_22_23;
  assign G_24_26 = G_25_26 | (P_25_26 & g0[24]);
  assign P_24_26 = P_25_26 & p0[24];
  assign G_25_27 = G_26_27 | (P_26_27 & g0[25]);
  assign P_25_27 = P_26_27 & p0[25];
  assign G_25_28 = G_27_28 | (P_27_28 & G_25_26);
  assign P_25_28 = P_27_28 & P_25_26;
  assign G_26_29 = G_28_29 | (P_28_29 & G_26_27);
  assign P_26_29 = P_28_29 & P_26_27;
  assign G_27_30 = G_29_30 | (P_29_30 & G_27_28);
  assign P_27_30 = P_29_30 & P_27_28;
  assign G_28_31 = G_30_31 | (P_30_31 & G_28_29);
  assign P_28_31 = P_30_31 & P_28_29;
  assign G_30_32 = G_31_32 | (P_31_32 & g0[30]);
  assign P_30_32 = P_31_32 & p0[30];
  assign G_31_33 = G_32_33 | (P_32_33 & g0[31]);
  assign P_31_33 = P_32_33 & p0[31];
  assign G_0_4 = G_2_4 | (P_2_4 & G_0_1);
  assign G_1_5 = G_3_5 | (P_3_5 & G_1_2);
  assign P_1_5 = P_3_5 & P_1_2;
  assign G_1_6 = G_3_6 | (P_3_6 & G_1_2);
  assign P_1_6 = P_3_6 & P_1_2;
  assign G_2_7 = G_4_7 | (P_4_7 & G_2_3);
  assign P_2_7 = P_4_7 & P_2_3;
  assign G_2_8 = G_5_8 | (P_5_8 & G_2_4);
  assign P_2_8 = P_5_8 & P_2_4;
  assign G_3_9 = G_6_9 | (P_6_9 & G_3_5);
  assign P_3_9 = P_6_9 & P_3_5;
  assign G_6_10 = G_8_10 | (P_8_10 & G_6_7);
  assign P_6_10 = P_8_10 & P_6_7;
  assign G_7_11 = G_9_11 | (P_9_11 & G_7_8);
  assign P_7_11 = P_9_11 & P_7_8;
  assign G_7_12 = G_9_12 | (P_9_12 & G_7_8);
  assign P_7_12 = P_9_12 & P_7_8;
  assign G_8_13 = G_10_13 | (P_10_13 & G_8_9);
  assign P_8_13 = P_10_13 & P_8_9;
  assign G_8_14 = G_11_14 | (P_11_14 & G_8_10);
  assign P_8_14 = P_11_14 & P_8_10;
  assign G_11_15 = G_13_15 | (P_13_15 & G_11_12);
  assign P_11_15 = P_13_15 & P_11_12;
  assign G_12_16 = G_14_16 | (P_14_16 & G_12_13);
  assign P_12_16 = P_14_16 & P_12_13;
  assign G_12_17 = G_14_17 | (P_14_17 & G_12_13);
  assign P_12_17 = P_14_17 & P_12_13;
  assign G_13_18 = G_15_18 | (P_15_18 & G_13_14);
  assign P_13_18 = P_15_18 & P_13_14;
  assign G_13_19 = G_16_19 | (P_16_19 & G_13_15);
  assign P_13_19 = P_16_19 & P_13_15;
  assign G_14_20 = G_17_20 | (P_17_20 & G_14_16);
  assign P_14_20 = P_17_20 & P_14_16;
  assign G_17_21 = G_19_21 | (P_19_21 & G_17_18);
  assign P_17_21 = P_19_21 & P_17_18;
  assign G_18_22 = G_20_22 | (P_20_22 & G_18_19);
  assign P_18_22 = P_20_22 & P_18_19;
  assign G_18_23 = G_20_23 | (P_20_23 & G_18_19);
  assign P_18_23 = P_20_23 & P_18_19;
  assign G_19_24 = G_21_24 | (P_21_24 & G_19_20);
  assign P_19_24 = P_21_24 & P_19_20;
  assign G_19_25 = G_22_25 | (P_22_25 & G_19_21);
  assign P_19_25 = P_22_25 & P_19_21;
  assign G_22_26 = G_24_26 | (P_24_26 & G_22_23);
  assign P_22_26 = P_24_26 & P_22_23;
  assign G_23_27 = G_25_27 | (P_25_27 & G_23_24);
  assign P_23_27 = P_25_27 & P_23_24;
  assign G_23_28 = G_25_28 | (P_25_28 & G_23_24);
  assign P_23_28 = P_25_28 & P_23_24;
  assign G_24_29 = G_26_29 | (P_26_29 & G_24_25);
  assign P_24_29 = P_26_29 & P_24_25;
  assign G_24_30 = G_27_30 | (P_27_30 & G_24_26);
  assign P_24_30 = P_27_30 & P_24_26;
  assign G_25_31 = G_28_31 | (P_28_31 & G_25_27);
  assign P_25_31 = P_28_31 & P_25_27;
  assign G_28_32 = G_30_32 | (P_30_32 & G_28_29);
  assign P_28_32 = P_30_32 & P_28_29;
  assign G_29_33 = G_31_33 | (P_31_33 & G_29_30);
  assign P_29_33 = P_31_33 & P_29_30;
  assign G_0_5 = G_1_5 | (P_1_5 & g0[0]);
  assign G_0_6 = G_1_6 | (P_1_6 & g0[0]);
  assign G_0_7 = G_2_7 | (P_2_7 & G_0_1);
  assign G_0_8 = G_2_8 | (P_2_8 & G_0_1);
  assign G_0_9 = G_3_9 | (P_3_9 & G_0_2);
  assign G_3_10 = G_6_10 | (P_6_10 & G_3_5);
  assign P_3_10 = P_6_10 & P_3_5;
  assign G_3_11 = G_7_11 | (P_7_11 & G_3_6);
  assign P_3_11 = P_7_11 & P_3_6;
  assign G_3_12 = G_7_12 | (P_7_12 & G_3_6);
  assign P_3_12 = P_7_12 & P_3_6;
  assign G_4_13 = G_8_13 | (P_8_13 & G_4_7);
  assign P_4_13 = P_8_13 & P_4_7;
  assign G_4_14 = G_8_14 | (P_8_14 & G_4_7);
  assign P_4_14 = P_8_14 & P_4_7;
  assign G_8_15 = G_11_15 | (P_11_15 & G_8_10);
  assign P_8_15 = P_11_15 & P_8_10;
  assign G_9_16 = G_12_16 | (P_12_16 & G_9_11);
  assign P_9_16 = P_12_16 & P_9_11;
  assign G_9_17 = G_12_17 | (P_12_17 & G_9_11);
  assign P_9_17 = P_12_17 & P_9_11;
  assign G_9_18 = G_13_18 | (P_13_18 & G_9_12);
  assign P_9_18 = P_13_18 & P_9_12;
  assign G_9_19 = G_13_19 | (P_13_19 & G_9_12);
  assign P_9_19 = P_13_19 & P_9_12;
  assign G_10_20 = G_14_20 | (P_14_20 & G_10_13);
  assign P_10_20 = P_14_20 & P_10_13;
  assign G_14_21 = G_17_21 | (P_17_21 & G_14_16);
  assign P_14_21 = P_17_21 & P_14_16;
  assign G_14_22 = G_18_22 | (P_18_22 & G_14_17);
  assign P_14_22 = P_18_22 & P_14_17;
  assign G_14_23 = G_18_23 | (P_18_23 & G_14_17);
  assign P_14_23 = P_18_23 & P_14_17;
  assign G_15_24 = G_19_24 | (P_19_24 & G_15_18);
  assign P_15_24 = P_19_24 & P_15_18;
  assign G_15_25 = G_19_25 | (P_19_25 & G_15_18);
  assign P_15_25 = P_19_25 & P_15_18;
  assign G_19_26 = G_22_26 | (P_22_26 & G_19_21);
  assign P_19_26 = P_22_26 & P_19_21;
  assign G_20_27 = G_23_27 | (P_23_27 & G_20_22);
  assign P_20_27 = P_23_27 & P_20_22;
  assign G_20_28 = G_23_28 | (P_23_28 & G_20_22);
  assign P_20_28 = P_23_28 & P_20_22;
  assign G_20_29 = G_24_29 | (P_24_29 & G_20_23);
  assign P_20_29 = P_24_29 & P_20_23;
  assign G_20_30 = G_24_30 | (P_24_30 & G_20_23);
  assign P_20_30 = P_24_30 & P_20_23;
  assign G_21_31 = G_25_31 | (P_25_31 & G_21_24);
  assign P_21_31 = P_25_31 & P_21_24;
  assign G_25_32 = G_28_32 | (P_28_32 & G_25_27);
  assign P_25_32 = P_28_32 & P_25_27;
  assign G_25_33 = G_29_33 | (P_29_33 & G_25_28);
  assign P_25_33 = P_29_33 & P_25_28;
  assign G_0_10 = G_3_10 | (P_3_10 & G_0_2);
  assign G_0_11 = G_3_11 | (P_3_11 & G_0_2);
  assign G_0_12 = G_3_12 | (P_3_12 & G_0_2);
  assign G_0_13 = G_4_13 | (P_4_13 & G_0_3);
  assign G_0_14 = G_4_14 | (P_4_14 & G_0_3);
  assign G_4_15 = G_8_15 | (P_8_15 & G_4_7);
  assign P_4_15 = P_8_15 & P_4_7;
  assign G_5_16 = G_9_16 | (P_9_16 & G_5_8);
  assign P_5_16 = P_9_16 & P_5_8;
  assign G_5_17 = G_9_17 | (P_9_17 & G_5_8);
  assign P_5_17 = P_9_17 & P_5_8;
  assign G_5_18 = G_9_18 | (P_9_18 & G_5_8);
  assign P_5_18 = P_9_18 & P_5_8;
  assign G_5_19 = G_9_19 | (P_9_19 & G_5_8);
  assign P_5_19 = P_9_19 & P_5_8;
  assign G_6_20 = G_10_20 | (P_10_20 & G_6_9);
  assign P_6_20 = P_10_20 & P_6_9;
  assign G_10_21 = G_14_21 | (P_14_21 & G_10_13);
  assign P_10_21 = P_14_21 & P_10_13;
  assign G_10_22 = G_14_22 | (P_14_22 & G_10_13);
  assign P_10_22 = P_14_22 & P_10_13;
  assign G_10_23 = G_14_23 | (P_14_23 & G_10_13);
  assign P_10_23 = P_14_23 & P_10_13;
  assign G_11_24 = G_15_24 | (P_15_24 & G_11_14);
  assign P_11_24 = P_15_24 & P_11_14;
  assign G_11_25 = G_15_25 | (P_15_25 & G_11_14);
  assign P_11_25 = P_15_25 & P_11_14;
  assign G_15_26 = G_19_26 | (P_19_26 & G_15_18);
  assign P_15_26 = P_19_26 & P_15_18;
  assign G_16_27 = G_20_27 | (P_20_27 & G_16_19);
  assign P_16_27 = P_20_27 & P_16_19;
  assign G_16_28 = G_20_28 | (P_20_28 & G_16_19);
  assign P_16_28 = P_20_28 & P_16_19;
  assign G_16_29 = G_20_29 | (P_20_29 & G_16_19);
  assign P_16_29 = P_20_29 & P_16_19;
  assign G_16_30 = G_20_30 | (P_20_30 & G_16_19);
  assign P_16_30 = P_20_30 & P_16_19;
  assign G_17_31 = G_21_31 | (P_21_31 & G_17_20);
  assign P_17_31 = P_21_31 & P_17_20;
  assign G_21_32 = G_25_32 | (P_25_32 & G_21_24);
  assign P_21_32 = P_25_32 & P_21_24;
  assign G_21_33 = G_25_33 | (P_25_33 & G_21_24);
  assign P_21_33 = P_25_33 & P_21_24;
  assign G_0_15 = G_4_15 | (P_4_15 & G_0_3);
  assign G_0_16 = G_5_16 | (P_5_16 & G_0_4);
  assign G_0_17 = G_5_17 | (P_5_17 & G_0_4);
  assign G_0_18 = G_5_18 | (P_5_18 & G_0_4);
  assign G_0_19 = G_5_19 | (P_5_19 & G_0_4);
  assign G_1_20 = G_6_20 | (P_6_20 & G_1_5);
  assign P_1_20 = P_6_20 & P_1_5;
  assign G_6_21 = G_10_21 | (P_10_21 & G_6_9);
  assign P_6_21 = P_10_21 & P_6_9;
  assign G_6_22 = G_10_22 | (P_10_22 & G_6_9);
  assign P_6_22 = P_10_22 & P_6_9;
  assign G_6_23 = G_10_23 | (P_10_23 & G_6_9);
  assign P_6_23 = P_10_23 & P_6_9;
  assign G_6_24 = G_11_24 | (P_11_24 & G_6_10);
  assign P_6_24 = P_11_24 & P_6_10;
  assign G_6_25 = G_11_25 | (P_11_25 & G_6_10);
  assign P_6_25 = P_11_25 & P_6_10;
  assign G_11_26 = G_15_26 | (P_15_26 & G_11_14);
  assign P_11_26 = P_15_26 & P_11_14;
  assign G_11_27 = G_16_27 | (P_16_27 & G_11_15);
  assign P_11_27 = P_16_27 & P_11_15;
  assign G_11_28 = G_16_28 | (P_16_28 & G_11_15);
  assign P_11_28 = P_16_28 & P_11_15;
  assign G_11_29 = G_16_29 | (P_16_29 & G_11_15);
  assign P_11_29 = P_16_29 & P_11_15;
  assign G_11_30 = G_16_30 | (P_16_30 & G_11_15);
  assign P_11_30 = P_16_30 & P_11_15;
  assign G_12_31 = G_17_31 | (P_17_31 & G_12_16);
  assign P_12_31 = P_17_31 & P_12_16;
  assign G_17_32 = G_21_32 | (P_21_32 & G_17_20);
  assign P_17_32 = P_21_32 & P_17_20;
  assign G_17_33 = G_21_33 | (P_21_33 & G_17_20);
  assign P_17_33 = P_21_33 & P_17_20;
  assign G_0_20 = G_1_20 | (P_1_20 & g0[0]);
  assign G_1_21 = G_6_21 | (P_6_21 & G_1_5);
  assign P_1_21 = P_6_21 & P_1_5;
  assign G_1_22 = G_6_22 | (P_6_22 & G_1_5);
  assign P_1_22 = P_6_22 & P_1_5;
  assign G_1_23 = G_6_23 | (P_6_23 & G_1_5);
  assign P_1_23 = P_6_23 & P_1_5;
  assign G_1_24 = G_6_24 | (P_6_24 & G_1_5);
  assign P_1_24 = P_6_24 & P_1_5;
  assign G_1_25 = G_6_25 | (P_6_25 & G_1_5);
  assign P_1_25 = P_6_25 & P_1_5;
  assign G_6_26 = G_11_26 | (P_11_26 & G_6_10);
  assign P_6_26 = P_11_26 & P_6_10;
  assign G_6_27 = G_11_27 | (P_11_27 & G_6_10);
  assign P_6_27 = P_11_27 & P_6_10;
  assign G_6_28 = G_11_28 | (P_11_28 & G_6_10);
  assign P_6_28 = P_11_28 & P_6_10;
  assign G_6_29 = G_11_29 | (P_11_29 & G_6_10);
  assign P_6_29 = P_11_29 & P_6_10;
  assign G_6_30 = G_11_30 | (P_11_30 & G_6_10);
  assign P_6_30 = P_11_30 & P_6_10;
  assign G_7_31 = G_12_31 | (P_12_31 & G_7_11);
  assign P_7_31 = P_12_31 & P_7_11;
  assign G_12_32 = G_17_32 | (P_17_32 & G_12_16);
  assign P_12_32 = P_17_32 & P_12_16;
  assign G_12_33 = G_17_33 | (P_17_33 & G_12_16);
  assign P_12_33 = P_17_33 & P_12_16;
  assign G_0_21 = G_1_21 | (P_1_21 & g0[0]);
  assign G_0_22 = G_1_22 | (P_1_22 & g0[0]);
  assign G_0_23 = G_1_23 | (P_1_23 & g0[0]);
  assign G_0_24 = G_1_24 | (P_1_24 & g0[0]);
  assign G_0_25 = G_1_25 | (P_1_25 & g0[0]);
  assign G_1_26 = G_6_26 | (P_6_26 & G_1_5);
  assign P_1_26 = P_6_26 & P_1_5;
  assign G_1_27 = G_6_27 | (P_6_27 & G_1_5);
  assign P_1_27 = P_6_27 & P_1_5;
  assign G_1_28 = G_6_28 | (P_6_28 & G_1_5);
  assign P_1_28 = P_6_28 & P_1_5;
  assign G_1_29 = G_6_29 | (P_6_29 & G_1_5);
  assign P_1_29 = P_6_29 & P_1_5;
  assign G_1_30 = G_6_30 | (P_6_30 & G_1_5);
  assign P_1_30 = P_6_30 & P_1_5;
  assign G_1_31 = G_7_31 | (P_7_31 & G_1_6);
  assign P_1_31 = P_7_31 & P_1_6;
  assign G_7_32 = G_12_32 | (P_12_32 & G_7_11);
  assign P_7_32 = P_12_32 & P_7_11;
  assign G_7_33 = G_12_33 | (P_12_33 & G_7_11);
  assign P_7_33 = P_12_33 & P_7_11;
  assign G_0_26 = G_1_26 | (P_1_26 & g0[0]);
  assign G_0_27 = G_1_27 | (P_1_27 & g0[0]);
  assign G_0_28 = G_1_28 | (P_1_28 & g0[0]);
  assign G_0_29 = G_1_29 | (P_1_29 & g0[0]);
  assign G_0_30 = G_1_30 | (P_1_30 & g0[0]);
  assign G_0_31 = G_1_31 | (P_1_31 & g0[0]);
  assign G_1_32 = G_7_32 | (P_7_32 & G_1_6);
  assign P_1_32 = P_7_32 & P_1_6;
  assign G_1_33 = G_7_33 | (P_7_33 & G_1_6);
  assign P_1_33 = P_7_33 & P_1_6;
  assign G_0_32 = G_1_32 | (P_1_32 & g0[0]);
  assign G_0_33 = G_1_33 | (P_1_33 & g0[0]);
  logic [34:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign c[15] = G_0_14;
  assign c[16] = G_0_15;
  assign c[17] = G_0_16;
  assign c[18] = G_0_17;
  assign c[19] = G_0_18;
  assign c[20] = G_0_19;
  assign c[21] = G_0_20;
  assign c[22] = G_0_21;
  assign c[23] = G_0_22;
  assign c[24] = G_0_23;
  assign c[25] = G_0_24;
  assign c[26] = G_0_25;
  assign c[27] = G_0_26;
  assign c[28] = G_0_27;
  assign c[29] = G_0_28;
  assign c[30] = G_0_29;
  assign c[31] = G_0_30;
  assign c[32] = G_0_31;
  assign c[33] = G_0_32;
  assign c[34] = G_0_33;
  assign s = pi_ ^ c[33:0];
  assign cout = c[34];
endmodule





module fam_prefix_han_carlson_w2 (input logic [1:0] a, input logic [1:0] b, input logic cin,
  output logic [1:0] s, output logic cout);
  // prefix graph: {'n': 2, 'levels': 1, 'size': 1, 'fanout': 1, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [1:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [1:0] g0, p0;
  assign g0 = {gi[1:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  logic [2:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign s = pi_ ^ c[1:0];
  assign cout = c[2];
endmodule


// sparse_prefix_hybrid: a han_carlson prefix network over blocks of 2 bits, the sums by carry_select












// sparse_prefix_hybrid: a han_carlson prefix network over blocks of 2 bits, the sums by carry_select












// sparse_prefix_hybrid: a han_carlson prefix network over blocks of 2 bits, the sums by carry_select












// sparse_prefix_hybrid: a han_carlson prefix network over blocks of 2 bits, the sums by carry_select












// sparse_prefix_hybrid: a han_carlson prefix network over blocks of 2 bits, the sums by carry_select












// sparse_prefix_hybrid: a han_carlson prefix network over blocks of 2 bits, the sums by carry_select












// sparse_prefix_hybrid: a han_carlson prefix network over blocks of 2 bits, the sums by carry_select












// sparse_prefix_hybrid: a han_carlson prefix network over blocks of 2 bits, the sums by carry_select












// sparse_prefix_hybrid: a han_carlson prefix network over blocks of 2 bits, the sums by carry_select












// sparse_prefix_hybrid: a han_carlson prefix network over blocks of 2 bits, the sums by carry_select












// sparse_prefix_hybrid: a han_carlson prefix network over blocks of 2 bits, the sums by carry_select












// sparse_prefix_hybrid: a han_carlson prefix network over blocks of 2 bits, the sums by carry_select












// sparse_prefix_hybrid: a han_carlson prefix network over blocks of 2 bits, the sums by carry_select












// sparse_prefix_hybrid: a han_carlson prefix network over blocks of 2 bits, the sums by carry_select















module fam_prefix_han_carlson_w4_ling_sel (input logic [3:0] a, input logic [3:0] b, input logic cin,
  output logic [3:0] s, output logic cout);
  // prefix graph: {'n': 4, 'levels': 2, 'size': 4, 'fanout': 2, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [3:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [3:0] g0, p0;
  assign g0 = {gi[3:1], gi[0] | cin};
  assign p0 = {ti[2:0], 1'b0};
  logic G_0_1, G_2_3, P_2_3, G_0_2, G_0_3;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  logic [4:0] c;
  assign c[0] = cin;
  assign c[1] = ti[0] & g0[0];
  assign c[2] = ti[1] & G_0_1;
  assign c[3] = ti[2] & G_0_2;
  assign c[4] = ti[3] & G_0_3;
  assign s[0] = pi_[0] ^ cin;
  assign s[1] = g0[0] ? (pi_[1] ^ ti[0]) : pi_[1];
  assign s[2] = G_0_1 ? (pi_[2] ^ ti[1]) : pi_[2];
  assign s[3] = G_0_2 ? (pi_[3] ^ ti[2]) : pi_[3];
  assign cout = c[4];
endmodule



module fam_prefix_han_carlson_w6_ling_sel (input logic [5:0] a, input logic [5:0] b, input logic cin,
  output logic [5:0] s, output logic cout);
  // prefix graph: {'n': 6, 'levels': 3, 'size': 8, 'fanout': 3, 'tracks': 2, 'exact_split': True, 'valency': 2}
  logic [5:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [5:0] g0, p0;
  assign g0 = {gi[5:1], gi[0] | cin};
  assign p0 = {ti[4:0], 1'b0};
  logic G_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_0_2, G_0_3, G_2_5, P_2_5, G_0_4, G_0_5;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  logic [6:0] c;
  assign c[0] = cin;
  assign c[1] = ti[0] & g0[0];
  assign c[2] = ti[1] & G_0_1;
  assign c[3] = ti[2] & G_0_2;
  assign c[4] = ti[3] & G_0_3;
  assign c[5] = ti[4] & G_0_4;
  assign c[6] = ti[5] & G_0_5;
  assign s[0] = pi_[0] ^ cin;
  assign s[1] = g0[0] ? (pi_[1] ^ ti[0]) : pi_[1];
  assign s[2] = G_0_1 ? (pi_[2] ^ ti[1]) : pi_[2];
  assign s[3] = G_0_2 ? (pi_[3] ^ ti[2]) : pi_[3];
  assign s[4] = G_0_3 ? (pi_[4] ^ ti[3]) : pi_[4];
  assign s[5] = G_0_4 ? (pi_[5] ^ ti[4]) : pi_[5];
  assign cout = c[6];
endmodule




module fam_prefix_knowles_mixed_w1 (input logic [0:0] a, input logic [0:0] b, input logic cin,
  output logic [0:0] s, output logic cout);
  // prefix graph: {'n': 1, 'levels': 0, 'size': 0, 'fanout': 0, 'tracks': 0, 'exact_split': True, 'valency': 1}
  logic [0:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [0:0] g0, p0;
  assign g0 = gi | (pi_ & cin);
  assign p0 = pi_;
  logic [1:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign s = pi_ ^ c[0:0];
  assign cout = c[1];
endmodule




module fam_prefix_knowles_mixed_w2 (input logic [1:0] a, input logic [1:0] b, input logic cin,
  output logic [1:0] s, output logic cout);
  // prefix graph: {'n': 2, 'levels': 1, 'size': 1, 'fanout': 1, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [1:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [1:0] g0, p0;
  assign g0 = {gi[1:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  logic [2:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign s = pi_ ^ c[1:0];
  assign cout = c[2];
endmodule


module fam_prefix_ladner_fischer_w16 (input logic [15:0] a, input logic [15:0] b, input logic cin,
  output logic [15:0] s, output logic cout);
  // prefix graph: {'n': 16, 'levels': 5, 'size': 27, 'fanout': 5, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [15:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [15:0] g0, p0;
  assign g0 = {gi[15:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_8_9, P_8_9, G_10_11, P_10_11, G_12_13, P_12_13, G_14_15, P_14_15, G_0_2, G_0_3, G_4_7, P_4_7, G_8_11, P_8_11, G_12_15, P_12_15, G_0_4, G_0_5, G_0_7, G_8_13, P_8_13, G_8_15, P_8_15, G_0_6, G_0_8, G_0_9, G_0_11, G_0_13, G_0_15, G_0_10, G_0_12, G_0_14;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_12_15 = G_14_15 | (P_14_15 & G_12_13);
  assign P_12_15 = P_14_15 & P_12_13;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign G_0_5 = G_4_5 | (P_4_5 & G_0_3);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_8_13 = G_12_13 | (P_12_13 & G_8_11);
  assign P_8_13 = P_12_13 & P_8_11;
  assign G_8_15 = G_12_15 | (P_12_15 & G_8_11);
  assign P_8_15 = P_12_15 & P_8_11;
  assign G_0_6 = g0[6] | (p0[6] & G_0_5);
  assign G_0_8 = g0[8] | (p0[8] & G_0_7);
  assign G_0_9 = G_8_9 | (P_8_9 & G_0_7);
  assign G_0_11 = G_8_11 | (P_8_11 & G_0_7);
  assign G_0_13 = G_8_13 | (P_8_13 & G_0_7);
  assign G_0_15 = G_8_15 | (P_8_15 & G_0_7);
  assign G_0_10 = g0[10] | (p0[10] & G_0_9);
  assign G_0_12 = g0[12] | (p0[12] & G_0_11);
  assign G_0_14 = g0[14] | (p0[14] & G_0_13);
  logic [16:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign c[15] = G_0_14;
  assign c[16] = G_0_15;
  assign s = pi_ ^ c[15:0];
  assign cout = c[16];
endmodule



module fam_prefix_ladner_fischer_w5_flag (input logic [4:0] a, input logic [4:0] b, input logic cin,
  output logic [4:0] s, output logic cout, output logic [4:0] s1);
  // prefix graph: {'n': 5, 'levels': 3, 'size': 5, 'fanout': 2, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [4:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [4:0] g0, p0;
  assign g0 = {gi[4:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, P_0_1, G_2_3, P_2_3, G_0_2, P_0_2, G_0_3, P_0_3, G_0_4, P_0_4;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign P_0_1 = p0[1] & p0[0];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign P_0_2 = p0[2] & P_0_1;
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign P_0_3 = P_2_3 & P_0_1;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign P_0_4 = p0[4] & P_0_3;
  logic [5:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign s = pi_ ^ c[4:0];
  assign cout = c[5];
  logic [4:0] f;
  assign f[0] = 1'b1;
  assign f[1] = pi_[0];
  assign f[2] = P_0_1;
  assign f[3] = P_0_2;
  assign f[4] = P_0_3;
  assign s1 = s ^ f;
endmodule




module fam_prefix_net_han_carlson_w9 (input logic [8:0] g, input logic [8:0] p, input logic cin,
  output logic [8:0] c, output logic cout);
  // prefix graph: {'n': 9, 'levels': 4, 'size': 13, 'fanout': 3, 'tracks': 2, 'exact_split': True, 'valency': 2}
  logic [8:0] g0, p0;
  assign g0 = {g[8:1], g[0] | (p[0] & cin)};
  assign p0 = p;
  logic G_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_0_2, G_0_3, G_2_5, P_2_5, G_4_7, P_4_7, G_0_4, G_0_5, G_0_7, G_0_6, G_0_8;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_0_6 = g0[6] | (p0[6] & G_0_5);
  assign G_0_8 = g0[8] | (p0[8] & G_0_7);
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign cout = G_0_8;
endmodule



// -------------------------------------------------------------- barrel_mux_tree
// ceil(AW / K) stages of 2^K:1 muxes (RADIX_LOG2 = K; 0 selects one full-width
// stage of W:1 muxes). DIR: 0 mirrored_datapath (a left and a right datapath,
// the result selected by the direction), 1 data_reversal (a right operation is
// a left one on the reversed word), 2 amount_negation (one left rotator; a right
// operation rotates by W - amt, a shift merges the fill through the keep mask).
// ORDER: 0 small_shift_first, 1 large_shift_first. ONE_HOT: the stages' select
// encoding.
module fam_shift_barrel_mux_tree #(parameter int W = 16, parameter int RADIX_LOG2 = 1, parameter int ONE_HOT = 0,
                                   parameter int DIR = 1, parameter int ORDER = 0, parameter int STICKY = 0)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic [2:0] op, output logic [W-1:0] y, output logic sticky);
  localparam int AW = $clog2(W);
  localparam int K = (RADIX_LOG2 == 0 || RADIX_LOG2 > AW) ? AW : RADIX_LOG2;
  localparam int NS = (AW + K - 1) / K;
  wire right = (op == 3'd1) || (op == 3'd2) || (op == 3'd4);
  wire rot = (op == 3'd3) || (op == 3'd4);
  wire arith = (op == 3'd2);
  wire fill = arith & a[W-1];
  logic [W-1:0] mask;
  fam_shift_keep_mask #(.W(W), .STICKY(STICKY)) u_mask (.a(a), .amt(amt), .right(right), .rot(rot), .mask(mask), .sticky(sticky));
  genvar s, i;
  generate
    if (DIR == 1) begin : reversed
      logic [W-1:0] rev_in, x, back;
      for (i = 0; i < W; i = i + 1) begin : rv
        assign rev_in[i] = a[W-1-i];
      end
      assign x = right ? rev_in : a;
      logic [W-1:0] st [0:NS];
      assign st[0] = x;
      for (s = 0; s < NS; s = s + 1) begin : stage
        localparam int G = ORDER ? (NS - 1 - s) : s;          // the digit this stage consumes
        localparam int KB = (G * K + K <= AW) ? K : AW - G * K;
        fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(0), .ONE_HOT(ONE_HOT))
          u (.x(st[s]), .digit(amt[G*K +: KB]), .rot(rot), .fill(fill), .y(st[s+1]));
      end
      for (i = 0; i < W; i = i + 1) begin : rb
        assign back[i] = st[NS][W-1-i];
      end
      assign y = right ? back : st[NS];
    end else if (DIR == 0) begin : mirrored
      logic [W-1:0] lft [0:NS];
      logic [W-1:0] rgt [0:NS];
      assign lft[0] = a;
      assign rgt[0] = a;
      for (s = 0; s < NS; s = s + 1) begin : stage
        localparam int G = ORDER ? (NS - 1 - s) : s;
        localparam int KB = (G * K + K <= AW) ? K : AW - G * K;
        fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(0), .ONE_HOT(ONE_HOT))
          ul (.x(lft[s]), .digit(amt[G*K +: KB]), .rot(rot), .fill(1'b0), .y(lft[s+1]));
        fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(1), .ONE_HOT(ONE_HOT))
          ur (.x(rgt[s]), .digit(amt[G*K +: KB]), .rot(rot), .fill(fill), .y(rgt[s+1]));
      end
      assign y = right ? rgt[NS] : lft[NS];
    end else begin : negated
      // one left rotator; a right operation is a left rotation by W - amt, and a shift takes
      // its fill through the keep mask (zero and overflow flags fall out of the mask)
      logic [AW-1:0] lamt;
      assign lamt = right ? (W - amt) : amt;
      logic [W-1:0] st [0:NS];
      assign st[0] = a;
      for (s = 0; s < NS; s = s + 1) begin : stage
        localparam int G = ORDER ? (NS - 1 - s) : s;
        localparam int KB = (G * K + K <= AW) ? K : AW - G * K;
        fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(0), .ONE_HOT(ONE_HOT))
          u (.x(st[s]), .digit(lamt[G*K +: KB]), .rot(1'b1), .fill(1'b0), .y(st[s+1]));
      end
      assign y = (st[NS] & mask) | ({W{fill}} & ~mask);
    end
  endgenerate
endmodule




// ---------------------------------------------------------------- butterfly_network
// a rotator on a switch network of lg(W) stages of W/2 two-input switches, stage
// l pairing the bits at distance D = 2^l inside every block of 2D, each switch
// under its own control. On the inverse butterfly (NETWORK = 0, small distance
// first) a rotate right by k over a 2D-block whose two halves are already
// rotated by k mod D swaps the pair (i, i+D) at the block-local index i when
// i >= D - (k mod D), and every pair when bit l of k is set (Hilewitz and Lee's
// rotation on the ibfly). The butterfly (NETWORK = 1) is the same stages in the
// reverse order, which composes the inverse permutation, so it takes the controls
// of a rotation by W - k. The shifts merge a mask as the masked family does; a
// left amount is W - amt. The network needs a power-of-two width.
module fam_shift_butterfly_network #(parameter int W = 16, parameter int NETWORK = 0, parameter int STICKY = 0)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic [2:0] op, output logic [W-1:0] y, output logic sticky);
  localparam int AW = $clog2(W);
  wire right = (op == 3'd1) || (op == 3'd2) || (op == 3'd4);
  wire rot = (op == 3'd3) || (op == 3'd4);
  wire arith = (op == 3'd2);
  wire fill = arith & a[W-1];
  logic [AW-1:0] k0, k;                              // the right-rotation amount, and the controls' amount
  assign k0 = right ? amt : (W - amt);
  assign k = NETWORK ? (W - k0) : k0;
  logic [W-1:0] st [0:AW];
  assign st[0] = a;
  genvar s, i;
  generate
    for (s = 0; s < AW; s = s + 1) begin : stage
      localparam int L = NETWORK ? (AW - 1 - s) : s;   // the switch distance of this stage: 2^L
      localparam int D = 1 << L;
      logic [AW-1:0] kmod;                             // k mod D (the low L bits of k)
      if (L == 0) begin : k0_
        assign kmod = '0;
      end else begin : kl
        assign kmod = {{(AW - L){1'b0}}, k[L-1:0]};
      end
      for (i = 0; i < W; i = i + 1) begin : bit_
        localparam int J = i % (2 * D);              // the block-local index
        if (J < D) begin : sw
          // the switch of the pair (i, i+D): crossed when J >= D - (k mod D), inverted by bit L of k
          wire ctrl = ((J >= D - kmod) ^ k[L]);
          assign st[s+1][i] = ctrl ? st[s][i+D] : st[s][i];
          assign st[s+1][i+D] = ctrl ? st[s][i] : st[s][i+D];
        end
      end
    end
  endgenerate
  logic [W-1:0] mask;
  fam_shift_keep_mask #(.W(W), .STICKY(STICKY)) u_mask (.a(a), .amt(amt), .right(right), .rot(rot), .mask(mask), .sticky(sticky));
  assign y = rot ? st[AW] : ((st[AW] & mask) | ({W{fill}} & ~mask));
endmodule





// ----------------------------------------------------------- the keep mask
// mask[i] = 1 where a shift keeps the input bit that lands at i (a rotate keeps
// every bit): the thermometer of the amount for the direction. sticky is the OR
// of the input bits a shift moves out (the low amt bits of a right shift, the
// top amt bits of a left one; none for a rotate), read through the mask of the
// opposite direction, in parallel with the datapath.
module fam_shift_keep_mask #(parameter int W = 16, parameter int STICKY = 1)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic right, input logic rot,
   output logic [W-1:0] mask, output logic sticky);
  logic [W-1:0] kept_in;
  genvar i;
  generate
    for (i = 0; i < W; i = i + 1) begin : mk
      assign mask[i] = rot | (right ? (i < W - amt) : (i >= amt));
      assign kept_in[i] = rot | (right ? (i >= amt) : (i < W - amt));
    end
  endgenerate
  assign sticky = STICKY ? |(a & ~kept_in) : 1'b0;
endmodule

// The shifter families of chiALU. One interface:
//   #(parameter int W) (input [W-1:0] a, input [AW-1:0] amt, input [2:0] op, output [W-1:0] y)
// op: 0 shl, 1 shr_logical, 2 shr_arith, 3 rol, 4 ror; amt is below W.
// Every family has `output sticky`, the OR of the bits a shift moves out (0 for a rotate), built
// when STICKY = 1 (the sticky_collect choice; an alignment shifter asks for it) and tied to 0
// otherwise; a consumer that does not collect it leaves the port unconnected.

// ------------------------------------------------------------------ one mux stage
// One stage of a shifter: the K-bit digit of the amount selects among R = 2^K
// candidates, candidate d being the input displaced by d * 2^SH to the left
// (RIGHT = 0) or to the right (RIGHT = 1), the vacated bits taken from the
// other end under `rot` or from `fill`. ONE_HOT = 1 decodes the digit to R
// select lines and forms the mux as an AND-OR (the select_encoding choice);
// ONE_HOT = 0 indexes the candidates by the binary digit.
module fam_shift_stage #(parameter int W = 16, parameter int K = 1, parameter int SH = 0,
                         parameter int RIGHT = 0, parameter int ONE_HOT = 0)
  (input logic [W-1:0] x, input logic [K-1:0] digit, input logic rot, input logic fill, output logic [W-1:0] y);
  localparam int R = 1 << K;
  localparam int D = 1 << SH;
  logic [W*R-1:0] cand;                       // candidate d at [d*W +: W]
  genvar d, i;
  generate
    for (d = 0; d < R; d = d + 1) begin : c
      for (i = 0; i < W; i = i + 1) begin : b
        localparam int S = d * D;             // the displacement of this candidate
        if (S >= W) begin : far
          // a displacement past the word: a rotate wraps it (mod W), a shift clears the word
          localparam int IDX = ((RIGHT ? (i + S) : (i - S)) % W + W) % W;
          assign cand[d*W + i] = rot ? x[IDX] : fill;
        end else if (RIGHT) begin : r
          if (i + S < W) begin : in_
            assign cand[d*W + i] = x[i + S];
          end else begin : out_
            assign cand[d*W + i] = rot ? x[i + S - W] : fill;
          end
        end else begin : l
          if (i >= S) begin : in_
            assign cand[d*W + i] = x[i - S];
          end else begin : out_
            assign cand[d*W + i] = rot ? x[W - S + i] : fill;
          end
        end
      end
    end
    if (ONE_HOT) begin : onehot
      logic [R-1:0] sel;
      for (d = 0; d < R; d = d + 1) begin : dec
        assign sel[d] = (digit == d);
      end
      for (i = 0; i < W; i = i + 1) begin : orb
        logic [R-1:0] t;
        for (d = 0; d < R; d = d + 1) begin : and_
          assign t[d] = sel[d] & cand[d*W + i];
        end
        assign y[i] = |t;
      end
    end else begin : binary
      assign y = cand[digit*W +: W];
    end
  endgenerate
endmodule
