// ADIR-MEMBER packages
// alu_core_m0_pkg: the exact-arithmetic functions of mode 0 (1xint16_twos_complement)
package alu_core_m0_pkg;

  // ---- m0: V = {special[1:0], sign, exp[8] (signed), sig[17]}
  //           X = {special[1:0], sign, exp[8] (signed), sig[38], sticky}
  localparam int m0_SW = 17, m0_EW = 8, m0_XW = 38;
  localparam int m0_VW = 28, m0_XT = 50;
  function automatic [27:0] m0_mkv(input [1:0] sp, input s, input signed [7:0] e, input [16:0] sig);
    m0_mkv = {sp, s, e, sig};
  endfunction
  function automatic [49:0] m0_mkx(input [1:0] sp, input s, input signed [7:0] e, input [37:0] sig, input st);
    m0_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [49:0] m0_x(input [27:0] v);   // widen V to X
    m0_x = {v[27:27-1], v[27-2], v[27-3 -: 8], {{(38-17){1'b0}}, v[16:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [49:0] m0_norm(input [49:0] x);
    logic [37:0] s; logic signed [7:0] e; integer k;
    s = x[38:1]; e = x[38+8:38+1];
    if (s != 0) begin
      for (k = 32; k >= 1; k = k / 2) begin
        if (k < 38) begin
          if (s[37 -: 1] == 1'b0 && (s >> (38 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m0_norm = {x[49:49-1], x[49-2], e, s, x[0]};
  endfunction

  function automatic m0_rup(input [2:0] rnd, input s, input inexact, input [38:0] rest, input [38:0] halfv,
                             input st, input lsb, input [38+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m0_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m0_rup = 1'b0;
      3'd2: m0_rup = inexact && s;
      3'd3: m0_rup = inexact && !s;
      3'd4: m0_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m0_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [49:0] m0_add(input [49:0] a, input [49:0] b, input sub);
    logic [49:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [7:0] ea, eb, d; logic [38:0] ms, mb, r; logic st, stb; integer sh;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1];
    sa = na[49-2]; sb = nb[49-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m0_add = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m0_add = (sa == sb) ? m0_mkx(2'd2, sa, 0, 0, 1'b0) : m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_add = m0_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m0_add = m0_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[38:1] == 0 && !na[0]) m0_add = {nb[49:49-1], sb, nb[49-3:0]};
    else if (nb[38:1] == 0 && !nb[0]) m0_add = na;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[38:1] >= nb[38:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[38+8:38+1] - sml[38+8:38+1];
      ms = {1'b0, sml[38:1]}; stb = sml[0];
      if (d > 38 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 38 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[38:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[38]) begin st = st | r[0]; r = r >> 1; m0_add = m0_mkx(2'd0, sr, big[38+8:38+1] + 1, r[37:0], st); end
      else m0_add = m0_mkx(2'd0, sr, big[38+8:38+1], r[37:0], st);
    end
  endfunction
  function automatic [49:0] m0_mul(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38-1:0] pr; logic st; integer k;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m0_mul = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[38:1] == 0 && !na[0]) || (spb == 2'd0 && nb[38:1] == 0 && !nb[0]))
        m0_mul = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m0_mul = m0_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[38:1] * nb[38:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[37:0] != 0);
      m0_mul = m0_mkx(2'd0, s, na[38+8:38+1] + nb[38+8:38+1] + 38, pr[2*38-1:38], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*38+1:0] m0_udiv(input [37:0] a, input [37:0] dv);
    logic [38+1:0] r; logic [38:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 38; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[37:0], ge};
      if (i > 0) r = {r[38:0], 1'b0};
    end
    m0_udiv = {q, r[38:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*38+8+2:0] m0_mulx(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*38-1:0] pr;
    na = m0_norm(a); nb = m0_norm(b);
    pr = na[38:1] * nb[38:1];
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[38:1] == 0) || (spb == 2'd0 && nb[38:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m0_mulx = {sp, s, na[38+8:38+1] + nb[38+8:38+1], pr};
  endfunction
  function automatic [49:0] m0_div(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38+1:0] qr; logic [38:0] q, r;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_div = m0_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m0_div = m0_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[38:1] == 0 && !nb[0]) begin
      if (na[38:1] == 0 && !na[0]) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m0_div = m0_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[38:1] == 0 && !na[0]) m0_div = m0_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m0_udiv(na[38:1], nb[38:1]);     // both normalized: nonzero finite
      q = qr[2*38+1:38+1]; r = qr[38:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[38]) m0_div = m0_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38 + 1, q[38:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m0_div = m0_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38, q[37:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [49:0] m0_sqrt(input [49:0] a);
    logic [49:0] na; logic [1:0] spa; logic signed [7:0] e; logic [38:0] m; logic [2*38+3:0] rad;
    logic [38+2:0] rem, trial; logic [38:0] root; logic ge; integer i;
    na = m0_norm(a); spa = na[49:49-1];
    if (spa == 2'd1) m0_sqrt = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_sqrt = na[49-2] ? m0_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[38:1] == 0 && !na[0]) m0_sqrt = na;
    else if (na[49-2]) m0_sqrt = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[38+8:38+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[38:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[38:1]};
      rad = {{(38+3){1'b0}}, m} << 38;
      rem = 0; root = 0;
      for (i = 38; i >= 0; i = i - 1) begin
        rem = {rem[38:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[37:0], ge};
      end
      m0_sqrt = m0_mkx(2'd0, 1'b0, (e >>> 1) - 19 + 1, root[38:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m0_lt(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [7:0] ea, eb;
    na = m0_norm(a); nb = m0_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    sa = na[49-2] && !za; sb = nb[49-2] && !zb;
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m0_lt = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2) begin
      if (na[49:49-1] == 2'd2 && nb[49:49-1] == 2'd2) m0_lt = na[49-2] && !nb[49-2];
      else if (na[49:49-1] == 2'd2) m0_lt = na[49-2];
      else m0_lt = !nb[49-2];
    end else if (za && zb) m0_lt = 1'b0;
    else if (sa != sb) m0_lt = sa;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[38:1] < nb[38:1] || (na[38:1] == nb[38:1] && !na[0] && nb[0])));
      m0_lt = sa ? !mag_lt && !(za && zb) && !m0_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m0_eq(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb;
    na = m0_norm(a); nb = m0_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m0_eq = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2)
      m0_eq = (na[49:49-1] == nb[49:49-1]) && (na[49-2] == nb[49-2]);
    else if (za || zb) m0_eq = za && zb;
    else m0_eq = (na[49-2] == nb[49-2]) && (na[38+8:38+1] == nb[38+8:38+1]) && (na[38:1] == nb[38:1]) && (na[0] == nb[0]);
  endfunction

  function automatic [28:0] m0_unpack_s(input [15:0] b, input daz);
    logic s; logic [15:0] mag; integer i;
    s = b[15]; mag = s ? (~b + 1'b1) : b;
    m0_unpack_s = {1'b0, m0_mkv(2'd0, s && (mag != 0), -0, {{(17-16){1'b0}}, mag})};
  endfunction

  function automatic [15:0] m0_enc(input signed [34:0] v); m0_enc = v[15:0]; endfunction
  function automatic [15:0] m0_wrap(input signed [34:0] v); m0_wrap = v[15:0]; endfunction
  function automatic [15:0] m0_sat(input signed [34:0] v);
    m0_sat = (v > 35'sd32767) ? {1'b0, {15{1'b1}}} : (v < -35'sd32768) ? {1'b1, {15{1'b0}}} : v[15:0];
  endfunction

  // round v / 2^f under rnd (the SR word applies to the fraction bits)
  function automatic signed [34:0] m0_rshift(input signed [34:0] v, input integer f, input [2:0] rnd, input [7:0] word);
    logic s; logic [34:0] mag, keep, rest, halfv; logic [43:0] fint; logic up, inexact;
    s = v < 0; mag = s ? -v : v;
    if (f <= 0) m0_rshift = v;
    else begin
      keep = mag >> f; rest = mag & (((35'd1) << f) - 1); halfv = (35'd1) << (f - 1);
      inexact = rest != 0;
      fint = (f >= 8) ? (rest >> (f - 8)) : (rest << (8 - f));
      case (rnd)
        3'd0: up = (rest > halfv) || (rest == halfv && keep[0]);
        3'd1: up = 1'b0;
        3'd2: up = inexact && s;
        3'd3: up = inexact && !s;
        3'd4: up = inexact && (0 ? (fint >= word) : (fint > word));
        default: up = inexact;
      endcase
      keep = keep + up;
      m0_rshift = s ? -$signed(keep) : $signed(keep);
    end
  endfunction
  // the SR word of a division: floor(|r| * 2^sb / |b|)
  function automatic [7:0] m0_divfrac(input [34:0] r, input [34:0] b);
    logic [43:0] t;
    t = ({{9{1'b0}}, r} << 8) / {{9{1'b0}}, b};
    m0_divfrac = t[7:0];
  endfunction
endpackage

// alu_core_m1_pkg: the exact-arithmetic functions of mode 1 (1xint16_unsigned)
package alu_core_m1_pkg;

  // ---- m1: V = {special[1:0], sign, exp[8] (signed), sig[17]}
  //           X = {special[1:0], sign, exp[8] (signed), sig[38], sticky}
  localparam int m1_SW = 17, m1_EW = 8, m1_XW = 38;
  localparam int m1_VW = 28, m1_XT = 50;
  function automatic [27:0] m1_mkv(input [1:0] sp, input s, input signed [7:0] e, input [16:0] sig);
    m1_mkv = {sp, s, e, sig};
  endfunction
  function automatic [49:0] m1_mkx(input [1:0] sp, input s, input signed [7:0] e, input [37:0] sig, input st);
    m1_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [49:0] m1_x(input [27:0] v);   // widen V to X
    m1_x = {v[27:27-1], v[27-2], v[27-3 -: 8], {{(38-17){1'b0}}, v[16:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [49:0] m1_norm(input [49:0] x);
    logic [37:0] s; logic signed [7:0] e; integer k;
    s = x[38:1]; e = x[38+8:38+1];
    if (s != 0) begin
      for (k = 32; k >= 1; k = k / 2) begin
        if (k < 38) begin
          if (s[37 -: 1] == 1'b0 && (s >> (38 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m1_norm = {x[49:49-1], x[49-2], e, s, x[0]};
  endfunction

  function automatic m1_rup(input [2:0] rnd, input s, input inexact, input [38:0] rest, input [38:0] halfv,
                             input st, input lsb, input [38+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m1_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m1_rup = 1'b0;
      3'd2: m1_rup = inexact && s;
      3'd3: m1_rup = inexact && !s;
      3'd4: m1_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m1_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [49:0] m1_add(input [49:0] a, input [49:0] b, input sub);
    logic [49:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [7:0] ea, eb, d; logic [38:0] ms, mb, r; logic st, stb; integer sh;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1];
    sa = na[49-2]; sb = nb[49-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m1_add = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m1_add = (sa == sb) ? m1_mkx(2'd2, sa, 0, 0, 1'b0) : m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_add = m1_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m1_add = m1_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[38:1] == 0 && !na[0]) m1_add = {nb[49:49-1], sb, nb[49-3:0]};
    else if (nb[38:1] == 0 && !nb[0]) m1_add = na;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[38:1] >= nb[38:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[38+8:38+1] - sml[38+8:38+1];
      ms = {1'b0, sml[38:1]}; stb = sml[0];
      if (d > 38 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 38 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[38:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[38]) begin st = st | r[0]; r = r >> 1; m1_add = m1_mkx(2'd0, sr, big[38+8:38+1] + 1, r[37:0], st); end
      else m1_add = m1_mkx(2'd0, sr, big[38+8:38+1], r[37:0], st);
    end
  endfunction
  function automatic [49:0] m1_mul(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38-1:0] pr; logic st; integer k;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m1_mul = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[38:1] == 0 && !na[0]) || (spb == 2'd0 && nb[38:1] == 0 && !nb[0]))
        m1_mul = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m1_mul = m1_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[38:1] * nb[38:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[37:0] != 0);
      m1_mul = m1_mkx(2'd0, s, na[38+8:38+1] + nb[38+8:38+1] + 38, pr[2*38-1:38], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*38+1:0] m1_udiv(input [37:0] a, input [37:0] dv);
    logic [38+1:0] r; logic [38:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 38; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[37:0], ge};
      if (i > 0) r = {r[38:0], 1'b0};
    end
    m1_udiv = {q, r[38:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*38+8+2:0] m1_mulx(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*38-1:0] pr;
    na = m1_norm(a); nb = m1_norm(b);
    pr = na[38:1] * nb[38:1];
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[38:1] == 0) || (spb == 2'd0 && nb[38:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m1_mulx = {sp, s, na[38+8:38+1] + nb[38+8:38+1], pr};
  endfunction
  function automatic [49:0] m1_div(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38+1:0] qr; logic [38:0] q, r;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_div = m1_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m1_div = m1_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[38:1] == 0 && !nb[0]) begin
      if (na[38:1] == 0 && !na[0]) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m1_div = m1_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[38:1] == 0 && !na[0]) m1_div = m1_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m1_udiv(na[38:1], nb[38:1]);     // both normalized: nonzero finite
      q = qr[2*38+1:38+1]; r = qr[38:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[38]) m1_div = m1_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38 + 1, q[38:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m1_div = m1_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38, q[37:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [49:0] m1_sqrt(input [49:0] a);
    logic [49:0] na; logic [1:0] spa; logic signed [7:0] e; logic [38:0] m; logic [2*38+3:0] rad;
    logic [38+2:0] rem, trial; logic [38:0] root; logic ge; integer i;
    na = m1_norm(a); spa = na[49:49-1];
    if (spa == 2'd1) m1_sqrt = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_sqrt = na[49-2] ? m1_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[38:1] == 0 && !na[0]) m1_sqrt = na;
    else if (na[49-2]) m1_sqrt = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[38+8:38+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[38:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[38:1]};
      rad = {{(38+3){1'b0}}, m} << 38;
      rem = 0; root = 0;
      for (i = 38; i >= 0; i = i - 1) begin
        rem = {rem[38:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[37:0], ge};
      end
      m1_sqrt = m1_mkx(2'd0, 1'b0, (e >>> 1) - 19 + 1, root[38:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m1_lt(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [7:0] ea, eb;
    na = m1_norm(a); nb = m1_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    sa = na[49-2] && !za; sb = nb[49-2] && !zb;
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m1_lt = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2) begin
      if (na[49:49-1] == 2'd2 && nb[49:49-1] == 2'd2) m1_lt = na[49-2] && !nb[49-2];
      else if (na[49:49-1] == 2'd2) m1_lt = na[49-2];
      else m1_lt = !nb[49-2];
    end else if (za && zb) m1_lt = 1'b0;
    else if (sa != sb) m1_lt = sa;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[38:1] < nb[38:1] || (na[38:1] == nb[38:1] && !na[0] && nb[0])));
      m1_lt = sa ? !mag_lt && !(za && zb) && !m1_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m1_eq(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb;
    na = m1_norm(a); nb = m1_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m1_eq = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2)
      m1_eq = (na[49:49-1] == nb[49:49-1]) && (na[49-2] == nb[49-2]);
    else if (za || zb) m1_eq = za && zb;
    else m1_eq = (na[49-2] == nb[49-2]) && (na[38+8:38+1] == nb[38+8:38+1]) && (na[38:1] == nb[38:1]) && (na[0] == nb[0]);
  endfunction

  function automatic [28:0] m1_unpack_s(input [15:0] b, input daz);
    logic s; logic [15:0] mag; integer i;
    s = 1'b0; mag = b;
    m1_unpack_s = {1'b0, m1_mkv(2'd0, s && (mag != 0), -0, {{(17-16){1'b0}}, mag})};
  endfunction

  function automatic [15:0] m1_enc(input signed [34:0] v); m1_enc = v[15:0]; endfunction
  function automatic [15:0] m1_wrap(input signed [34:0] v); m1_wrap = v[15:0]; endfunction
  function automatic [15:0] m1_sat(input signed [34:0] v);
    m1_sat = (v > 35'sd65535) ? {16{1'b1}} : (v < 0) ? 16'd0 : v[15:0];
  endfunction

  // round v / 2^f under rnd (the SR word applies to the fraction bits)
  function automatic signed [34:0] m1_rshift(input signed [34:0] v, input integer f, input [2:0] rnd, input [7:0] word);
    logic s; logic [34:0] mag, keep, rest, halfv; logic [43:0] fint; logic up, inexact;
    s = v < 0; mag = s ? -v : v;
    if (f <= 0) m1_rshift = v;
    else begin
      keep = mag >> f; rest = mag & (((35'd1) << f) - 1); halfv = (35'd1) << (f - 1);
      inexact = rest != 0;
      fint = (f >= 8) ? (rest >> (f - 8)) : (rest << (8 - f));
      case (rnd)
        3'd0: up = (rest > halfv) || (rest == halfv && keep[0]);
        3'd1: up = 1'b0;
        3'd2: up = inexact && s;
        3'd3: up = inexact && !s;
        3'd4: up = inexact && (0 ? (fint >= word) : (fint > word));
        default: up = inexact;
      endcase
      keep = keep + up;
      m1_rshift = s ? -$signed(keep) : $signed(keep);
    end
  endfunction
  // the SR word of a division: floor(|r| * 2^sb / |b|)
  function automatic [7:0] m1_divfrac(input [34:0] r, input [34:0] b);
    logic [43:0] t;
    t = ({{9{1'b0}}, r} << 8) / {{9{1'b0}}, b};
    m1_divfrac = t[7:0];
  endfunction
endpackage

// alu_core_m2_pkg: the exact-arithmetic functions of mode 2 (2xint8_twos_complement)
package alu_core_m2_pkg;

  // ---- m2: V = {special[1:0], sign, exp[8] (signed), sig[9]}
  //           X = {special[1:0], sign, exp[8] (signed), sig[22], sticky}
  localparam int m2_SW = 9, m2_EW = 8, m2_XW = 22;
  localparam int m2_VW = 20, m2_XT = 34;
  function automatic [19:0] m2_mkv(input [1:0] sp, input s, input signed [7:0] e, input [8:0] sig);
    m2_mkv = {sp, s, e, sig};
  endfunction
  function automatic [33:0] m2_mkx(input [1:0] sp, input s, input signed [7:0] e, input [21:0] sig, input st);
    m2_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [33:0] m2_x(input [19:0] v);   // widen V to X
    m2_x = {v[19:19-1], v[19-2], v[19-3 -: 8], {{(22-9){1'b0}}, v[8:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [33:0] m2_norm(input [33:0] x);
    logic [21:0] s; logic signed [7:0] e; integer k;
    s = x[22:1]; e = x[22+8:22+1];
    if (s != 0) begin
      for (k = 16; k >= 1; k = k / 2) begin
        if (k < 22) begin
          if (s[21 -: 1] == 1'b0 && (s >> (22 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m2_norm = {x[33:33-1], x[33-2], e, s, x[0]};
  endfunction

  function automatic m2_rup(input [2:0] rnd, input s, input inexact, input [22:0] rest, input [22:0] halfv,
                             input st, input lsb, input [22+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m2_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m2_rup = 1'b0;
      3'd2: m2_rup = inexact && s;
      3'd3: m2_rup = inexact && !s;
      3'd4: m2_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m2_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [33:0] m2_add(input [33:0] a, input [33:0] b, input sub);
    logic [33:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [7:0] ea, eb, d; logic [22:0] ms, mb, r; logic st, stb; integer sh;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[33:33-1]; spb = nb[33:33-1];
    sa = na[33-2]; sb = nb[33-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m2_add = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m2_add = (sa == sb) ? m2_mkx(2'd2, sa, 0, 0, 1'b0) : m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_add = m2_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m2_add = m2_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[22:1] == 0 && !na[0]) m2_add = {nb[33:33-1], sb, nb[33-3:0]};
    else if (nb[22:1] == 0 && !nb[0]) m2_add = na;
    else begin
      ea = na[22+8:22+1]; eb = nb[22+8:22+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[22:1] >= nb[22:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[22+8:22+1] - sml[22+8:22+1];
      ms = {1'b0, sml[22:1]}; stb = sml[0];
      if (d > 22 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 22 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[22:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[22]) begin st = st | r[0]; r = r >> 1; m2_add = m2_mkx(2'd0, sr, big[22+8:22+1] + 1, r[21:0], st); end
      else m2_add = m2_mkx(2'd0, sr, big[22+8:22+1], r[21:0], st);
    end
  endfunction
  function automatic [33:0] m2_mul(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*22-1:0] pr; logic st; integer k;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[33:33-1]; spb = nb[33:33-1]; s = na[33-2] ^ nb[33-2];
    if (spa == 2'd1 || spb == 2'd1) m2_mul = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[22:1] == 0 && !na[0]) || (spb == 2'd0 && nb[22:1] == 0 && !nb[0]))
        m2_mul = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m2_mul = m2_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[22:1] * nb[22:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[21:0] != 0);
      m2_mul = m2_mkx(2'd0, s, na[22+8:22+1] + nb[22+8:22+1] + 22, pr[2*22-1:22], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*22+1:0] m2_udiv(input [21:0] a, input [21:0] dv);
    logic [22+1:0] r; logic [22:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 22; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[21:0], ge};
      if (i > 0) r = {r[22:0], 1'b0};
    end
    m2_udiv = {q, r[22:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*22+8+2:0] m2_mulx(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*22-1:0] pr;
    na = m2_norm(a); nb = m2_norm(b);
    pr = na[22:1] * nb[22:1];
    spa = na[33:33-1]; spb = nb[33:33-1]; s = na[33-2] ^ nb[33-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[22:1] == 0) || (spb == 2'd0 && nb[22:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m2_mulx = {sp, s, na[22+8:22+1] + nb[22+8:22+1], pr};
  endfunction
  function automatic [33:0] m2_div(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*22+1:0] qr; logic [22:0] q, r;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[33:33-1]; spb = nb[33:33-1]; s = na[33-2] ^ nb[33-2];
    if (spa == 2'd1 || spb == 2'd1) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_div = m2_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m2_div = m2_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[22:1] == 0 && !nb[0]) begin
      if (na[22:1] == 0 && !na[0]) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m2_div = m2_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[22:1] == 0 && !na[0]) m2_div = m2_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m2_udiv(na[22:1], nb[22:1]);     // both normalized: nonzero finite
      q = qr[2*22+1:22+1]; r = qr[22:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[22]) m2_div = m2_mkx(2'd0, s, na[22+8:22+1] - nb[22+8:22+1] - 22 + 1, q[22:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m2_div = m2_mkx(2'd0, s, na[22+8:22+1] - nb[22+8:22+1] - 22, q[21:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [33:0] m2_sqrt(input [33:0] a);
    logic [33:0] na; logic [1:0] spa; logic signed [7:0] e; logic [22:0] m; logic [2*22+3:0] rad;
    logic [22+2:0] rem, trial; logic [22:0] root; logic ge; integer i;
    na = m2_norm(a); spa = na[33:33-1];
    if (spa == 2'd1) m2_sqrt = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_sqrt = na[33-2] ? m2_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[22:1] == 0 && !na[0]) m2_sqrt = na;
    else if (na[33-2]) m2_sqrt = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[22+8:22+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[22:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[22:1]};
      rad = {{(22+3){1'b0}}, m} << 22;
      rem = 0; root = 0;
      for (i = 22; i >= 0; i = i - 1) begin
        rem = {rem[22:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[21:0], ge};
      end
      m2_sqrt = m2_mkx(2'd0, 1'b0, (e >>> 1) - 11 + 1, root[22:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m2_lt(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [7:0] ea, eb;
    na = m2_norm(a); nb = m2_norm(b);
    za = (na[22:1] == 0) && !na[0]; zb = (nb[22:1] == 0) && !nb[0];
    sa = na[33-2] && !za; sb = nb[33-2] && !zb;
    if (na[33:33-1] == 2'd1 || nb[33:33-1] == 2'd1) m2_lt = 1'b0;
    else if (na[33:33-1] == 2'd2 || nb[33:33-1] == 2'd2) begin
      if (na[33:33-1] == 2'd2 && nb[33:33-1] == 2'd2) m2_lt = na[33-2] && !nb[33-2];
      else if (na[33:33-1] == 2'd2) m2_lt = na[33-2];
      else m2_lt = !nb[33-2];
    end else if (za && zb) m2_lt = 1'b0;
    else if (sa != sb) m2_lt = sa;
    else begin
      ea = na[22+8:22+1]; eb = nb[22+8:22+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[22:1] < nb[22:1] || (na[22:1] == nb[22:1] && !na[0] && nb[0])));
      m2_lt = sa ? !mag_lt && !(za && zb) && !m2_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m2_eq(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic za, zb;
    na = m2_norm(a); nb = m2_norm(b);
    za = (na[22:1] == 0) && !na[0]; zb = (nb[22:1] == 0) && !nb[0];
    if (na[33:33-1] == 2'd1 || nb[33:33-1] == 2'd1) m2_eq = 1'b0;
    else if (na[33:33-1] == 2'd2 || nb[33:33-1] == 2'd2)
      m2_eq = (na[33:33-1] == nb[33:33-1]) && (na[33-2] == nb[33-2]);
    else if (za || zb) m2_eq = za && zb;
    else m2_eq = (na[33-2] == nb[33-2]) && (na[22+8:22+1] == nb[22+8:22+1]) && (na[22:1] == nb[22:1]) && (na[0] == nb[0]);
  endfunction

  function automatic [20:0] m2_unpack_s(input [7:0] b, input daz);
    logic s; logic [7:0] mag; integer i;
    s = b[7]; mag = s ? (~b + 1'b1) : b;
    m2_unpack_s = {1'b0, m2_mkv(2'd0, s && (mag != 0), -0, {{(9-8){1'b0}}, mag})};
  endfunction

  function automatic [7:0] m2_enc(input signed [18:0] v); m2_enc = v[7:0]; endfunction
  function automatic [7:0] m2_wrap(input signed [18:0] v); m2_wrap = v[7:0]; endfunction
  function automatic [7:0] m2_sat(input signed [18:0] v);
    m2_sat = (v > 19'sd127) ? {1'b0, {7{1'b1}}} : (v < -19'sd128) ? {1'b1, {7{1'b0}}} : v[7:0];
  endfunction

  // round v / 2^f under rnd (the SR word applies to the fraction bits)
  function automatic signed [18:0] m2_rshift(input signed [18:0] v, input integer f, input [2:0] rnd, input [7:0] word);
    logic s; logic [18:0] mag, keep, rest, halfv; logic [27:0] fint; logic up, inexact;
    s = v < 0; mag = s ? -v : v;
    if (f <= 0) m2_rshift = v;
    else begin
      keep = mag >> f; rest = mag & (((19'd1) << f) - 1); halfv = (19'd1) << (f - 1);
      inexact = rest != 0;
      fint = (f >= 8) ? (rest >> (f - 8)) : (rest << (8 - f));
      case (rnd)
        3'd0: up = (rest > halfv) || (rest == halfv && keep[0]);
        3'd1: up = 1'b0;
        3'd2: up = inexact && s;
        3'd3: up = inexact && !s;
        3'd4: up = inexact && (0 ? (fint >= word) : (fint > word));
        default: up = inexact;
      endcase
      keep = keep + up;
      m2_rshift = s ? -$signed(keep) : $signed(keep);
    end
  endfunction
  // the SR word of a division: floor(|r| * 2^sb / |b|)
  function automatic [7:0] m2_divfrac(input [18:0] r, input [18:0] b);
    logic [27:0] t;
    t = ({{9{1'b0}}, r} << 8) / {{9{1'b0}}, b};
    m2_divfrac = t[7:0];
  endfunction
endpackage
// ADIR-MEMBER top
// EVOLVE-BLOCK-START
// ADIR-DECL v1
// VAR core.logic.m0.family=wide_gate_row
// VAR core.logic.m1.family=wide_gate_row
// VAR core.logic.m2.family=wide_gate_row
// VAR core.adder.m0.family=carry_lookahead
// VAR core.comparator.m2.family=subtractor_comparator
// VAR core.multiplier.m0.family=twin_precision_subword
// VAR core.multiplier.m0.lane_cpa.full_adder_logic=xor_majority
// VAR core.multiplier.m1.family=squarer
// VAR core.multiplier.m1.reduction.geometry=tdm_arrival_driven
// VAR core.multiplier.m1.reduction.counter_kind=5_2
// VAR core.multiplier.m1.reduction.cpa.adder.family=ling_prefix
// VAR core.multiplier.m1.reduction.cpa.adder.topology=han_carlson
// VAR core.multiplier.m1.reduction.cpa.adder.sum_recovery=xor_correction
// VAR core.multiplier.m1.cross.group_bits=2
// VAR core.multiplier.m1.cross.signed_scheme=sign_extension
// VAR core.multiplier.m1.cross.reduction.cpa.family=hybrid_arrival_driven
// VAR core.multiplier.m1.cross.reduction.cpa.arrival_model=measured_tree_profile
// VAR core.multiplier.m1.cross.hard_multiple_adder.family=parallel_prefix
// VAR core.multiplier.m1.cross.hard_multiple_adder.topology=ladner_fischer
// VAR core.multiplier.m1.pre_adder.family=prefix_synthesis_nonuniform_arrival
// VAR core.multiplier.m1.pre_adder.arrival_profile=msb_late
// VAR core.multiplier.m2.family=segmented_grid
// VAR core.multiplier.m2.seg_w=8
// VAR core.multiplier.m2.num_seg=3
// VAR core.multiplier.m2.segment_shape=rectangular
// VAR core.multiplier.m2.merge_form=carry_save_tree
// VAR core.multiplier.m2.segment.group_bits=2
// VAR core.multiplier.m2.segment.signed_scheme=sign_extension
// VAR core.multiplier.m2.segment.reduction.cpa.family=hybrid_arrival_driven
// VAR core.multiplier.m2.segment.reduction.cpa.region_adder_mix=ripple_skip_select
// VAR core.multiplier.m2.segment.hard_multiple_adder.family=compound_flagged_prefix
// VAR core.multiplier.m2.segment.hard_multiple_adder.topology=harris
// VAR core.multiplier.m2.segment.hard_multiple_adder.fanout_cap=4
// VAR core.multiplier.m2.segment.hard_multiple_adder.outputs=sum_sum1_summinus1
// VAR core.multiplier.m2.segment.hard_multiple_adder.implementation=flag_row
// VAR core.multiplier.m2.segment.hard_multiple_adder.late_carry_in=true
// VAR core.multiplier.m2.merge_adder.family=end_around_carry
// VAR core.multiplier.m2.merge_adder.modulus=mod_2n_plus_1_diminished_one
// VAR core.multiplier.m2.merge_adder.recirculation=select_based
// VAR core.multiplier.m2.merge_adder.topology=harris
// VAR core.multiplier.m2.merge_adder.fanout_cap=4
// VAR core.multiplier.m2.merge_adder.incrementer.structure=select_blocks
// VAR core.multiplier.m2.merge_tree.geometry=wallace
// VAR core.multiplier.m2.merge_tree.cpa.adder.family=compound_flagged_prefix
// VAR core.multiplier.m2.merge_tree.cpa.adder.topology=brent_kung
// VAR core.shifter.m0.family=masked_merged
// VAR core.shifter.m0.sticky_collect=true
// VAR core.shifter.m0.mask_generator=two_thermometer_and
// VAR core.shifter.m0.merge_style=per_bit_mux
// VAR core.shifter.m0.rotator.select_encoding=one_hot_decoded
// VAR core.shifter.m0.rotator.stage_order=large_shift_first
// VAR core.shifter.m1.family=butterfly_network
// VAR core.shifter.m1.sticky_collect=true
// VAR core.shifter.m2.family=butterfly_network
// VAR core.shifter.m2.sticky_collect=true
// VAR core.bitcount.m0.family=priority_encoder
// VAR core.bitcount.m0.output_form=one_hot_then_encode
// VAR core.bitcount.m0.lookahead_group=8
// VAR core.bitcount.m0.levels=2
// VAR core.bitcount.m1.family=trailing_zero
// VAR core.bitcount.m1.strategy=debruijn_multiply_index
// VAR core.bitcount.m1.lzd.family=prefix_lzc
// VAR core.bitcount.m1.lzd.prefix_topology=sklansky
// VAR core.bitcount.m1.lzd.counter.counter_primitive=counter_7_3
// VAR core.bitcount.m1.lzd.counter.tree_shape=linear_chain
// VAR core.bitcount.m1.lzd.counter.final_adder.family=carry_select
// VAR core.bitcount.m1.lzd.counter.final_adder.block_sizing=square_root_ramp
// VAR core.bitcount.m1.lzd.counter.final_adder.duplication=shared_add_one
// VAR core.bitcount.m1.lzd.counter.final_adder.block_adder.full_adder_logic=xor_majority
// VAR core.bitcount.m2.counter_primitive=compressor_4_2
// VAR core.bitcount.m2.final_adder.family=prefix_synthesis_nonuniform_arrival
// VAR core.bitcount.m2.final_adder.arrival_profile=multiplier_vee
// STRUCTURE m0.l0.adder kind=adder slot=adder mode=0 lane=0 width=16 format=int16_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_pair_m0_l0 group=pair_m0_l0
// STRUCTURE m0.l0.multiplier kind=multiplier slot=multiplier mode=0 lane=0 width=16 format=int16_twos_complement ops=mul,mul_high sv=alu_core_u_m0_l0_multiplier
// STRUCTURE m0.l0.comparator kind=comparator slot=comparator mode=0 lane=0 width=16 format=int16_twos_complement ops=min,max,cmp sv=alu_core_u_pair_m0_l0 group=pair_m0_l0
// STRUCTURE m0.l0.shifter kind=shifter slot=shifter mode=0 lane=0 width=16 format=int16_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m0_l0_shifter
// STRUCTURE m0.l0.logic kind=logic slot=logic mode=0 lane=0 width=16 format=int16_twos_complement ops=and,or,xor,not sv=alu_core_u_gate_rows_0 group=gate_rows_0
// STRUCTURE m0.l0.bitcount kind=bitcount slot=bitcount mode=0 lane=0 width=16 format=int16_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m0_l0_bitcount
// STRUCTURE m1.l0.adder kind=adder slot=adder mode=1 lane=0 width=16 format=int16_unsigned ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_pair_m1_l0 group=pair_m1_l0
// STRUCTURE m1.l0.multiplier kind=multiplier slot=multiplier mode=1 lane=0 width=16 format=int16_unsigned ops=mul,mul_high sv=alu_core_u_m1_l0_multiplier
// STRUCTURE m1.l0.comparator kind=comparator slot=comparator mode=1 lane=0 width=16 format=int16_unsigned ops=min,max,cmp sv=alu_core_u_pair_m1_l0 group=pair_m1_l0
// STRUCTURE m1.l0.shifter kind=shifter slot=shifter mode=1 lane=0 width=16 format=int16_unsigned ops=shl,shr_arith,rol sv=alu_core_u_m1_l0_shifter
// STRUCTURE m1.l0.logic kind=logic slot=logic mode=1 lane=0 width=16 format=int16_unsigned ops=and,or,xor,not sv=alu_core_u_gate_rows_0 group=gate_rows_0
// STRUCTURE m1.l0.bitcount kind=bitcount slot=bitcount mode=1 lane=0 width=16 format=int16_unsigned ops=popcount,clz,ctz sv=alu_core_u_m1_l0_bitcount
// STRUCTURE m2.l0.adder kind=adder slot=adder mode=2 lane=0 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_pair_m2_l0 group=pair_m2_l0
// STRUCTURE m2.l1.adder kind=adder slot=adder mode=2 lane=1 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_pair_m2_l1 group=pair_m2_l1
// STRUCTURE m2.l0.multiplier kind=multiplier slot=multiplier mode=2 lane=0 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_m2_l0_multiplier
// STRUCTURE m2.l1.multiplier kind=multiplier slot=multiplier mode=2 lane=1 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_m2_l1_multiplier
// STRUCTURE m2.l0.comparator kind=comparator slot=comparator mode=2 lane=0 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_pair_m2_l0 group=pair_m2_l0
// STRUCTURE m2.l1.comparator kind=comparator slot=comparator mode=2 lane=1 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_pair_m2_l1 group=pair_m2_l1
// STRUCTURE m2.l0.shifter kind=shifter slot=shifter mode=2 lane=0 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l0_shifter
// STRUCTURE m2.l1.shifter kind=shifter slot=shifter mode=2 lane=1 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l1_shifter
// STRUCTURE m2.l0.logic kind=logic slot=logic mode=2 lane=0 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_gate_rows_0 group=gate_rows_0
// STRUCTURE m2.l1.logic kind=logic slot=logic mode=2 lane=1 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_gate_rows_0 group=gate_rows_0
// STRUCTURE m2.l0.bitcount kind=bitcount slot=bitcount mode=2 lane=0 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l0_bitcount
// STRUCTURE m2.l1.bitcount kind=bitcount slot=bitcount mode=2 lane=1 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l1_bitcount
// ADIR-END
module alu_core (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  output logic [15:0] y,
  output logic [3:0] flags
);
  // alu_core: behavioral reference derived from the instance (modes 1xint16_twos_complement, 1xint16_unsigned, 2xint8_twos_complement; ops add, sub, adc, neg, abs, add_sat, mul, mul_high, min, max, cmp, shl, shr_arith, rol, and, or, xor, not, popcount, clz, ctz). Every (mode, op) pair computes the verify layer's exact semantics.
  // HIERARCHY: 17 physical structure modules instantiated by alu_core, built from 12 lane modules (one per mode and kind, parameter LANE) and 3 packages of engine functions (one per mode); a float mode's datapath is split into an unpacker (the xa/xb/den buses), the arithmetic and converter structures (unrounded results on the x bus) and a rounder (y and the flags); 0 misc lane modules and 0 block-conversion group modules
  // UNIT gate_rows_0 module=alu_core_u_gate_rows_0 kind=logic members=m0.l0.logic,m1.l0.logic,m2.l0.logic,m2.l1.logic
  // UNIT pair_m0_l0 module=alu_core_u_pair_m0_l0 kind=adder members=m0.l0.adder,m0.l0.comparator
  // UNIT pair_m1_l0 module=alu_core_u_pair_m1_l0 kind=adder members=m1.l0.adder,m1.l0.comparator
  // UNIT pair_m2_l0 module=alu_core_u_pair_m2_l0 kind=adder members=m2.l0.adder,m2.l0.comparator
  // UNIT pair_m2_l1 module=alu_core_u_pair_m2_l1 kind=adder members=m2.l1.adder,m2.l1.comparator
  // UNIT m0.l0.multiplier module=alu_core_u_m0_l0_multiplier kind=multiplier members=m0.l0.multiplier
  // UNIT m0.l0.shifter module=alu_core_u_m0_l0_shifter kind=shifter members=m0.l0.shifter
  // UNIT m0.l0.bitcount module=alu_core_u_m0_l0_bitcount kind=bitcount members=m0.l0.bitcount
  // UNIT m1.l0.multiplier module=alu_core_u_m1_l0_multiplier kind=multiplier members=m1.l0.multiplier
  // UNIT m1.l0.shifter module=alu_core_u_m1_l0_shifter kind=shifter members=m1.l0.shifter
  // UNIT m1.l0.bitcount module=alu_core_u_m1_l0_bitcount kind=bitcount members=m1.l0.bitcount
  // UNIT m2.l0.multiplier module=alu_core_u_m2_l0_multiplier kind=multiplier members=m2.l0.multiplier
  // UNIT m2.l1.multiplier module=alu_core_u_m2_l1_multiplier kind=multiplier members=m2.l1.multiplier
  // UNIT m2.l0.shifter module=alu_core_u_m2_l0_shifter kind=shifter members=m2.l0.shifter
  // UNIT m2.l1.shifter module=alu_core_u_m2_l1_shifter kind=shifter members=m2.l1.shifter
  // UNIT m2.l0.bitcount module=alu_core_u_m2_l0_bitcount kind=bitcount members=m2.l0.bitcount
  // UNIT m2.l1.bitcount module=alu_core_u_m2_l1_bitcount kind=bitcount members=m2.l1.bitcount
  // // STRUCTURE m0.l0.adder kind=adder slot=adder mode=0 lane=0 width=16 format=int16_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_pair_m0_l0
  // // STRUCTURE m0.l0.multiplier kind=multiplier slot=multiplier mode=0 lane=0 width=16 format=int16_twos_complement ops=mul,mul_high sv=alu_core_u_m0_l0_multiplier
  // // STRUCTURE m0.l0.comparator kind=comparator slot=comparator mode=0 lane=0 width=16 format=int16_twos_complement ops=min,max,cmp sv=alu_core_u_pair_m0_l0
  // // STRUCTURE m0.l0.shifter kind=shifter slot=shifter mode=0 lane=0 width=16 format=int16_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m0_l0_shifter
  // // STRUCTURE m0.l0.logic kind=logic slot=logic mode=0 lane=0 width=16 format=int16_twos_complement ops=and,or,xor,not sv=alu_core_u_gate_rows_0
  // // STRUCTURE m0.l0.bitcount kind=bitcount slot=bitcount mode=0 lane=0 width=16 format=int16_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m0_l0_bitcount
  // // STRUCTURE m1.l0.adder kind=adder slot=adder mode=1 lane=0 width=16 format=int16_unsigned ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_pair_m1_l0
  // // STRUCTURE m1.l0.multiplier kind=multiplier slot=multiplier mode=1 lane=0 width=16 format=int16_unsigned ops=mul,mul_high sv=alu_core_u_m1_l0_multiplier
  // // STRUCTURE m1.l0.comparator kind=comparator slot=comparator mode=1 lane=0 width=16 format=int16_unsigned ops=min,max,cmp sv=alu_core_u_pair_m1_l0
  // // STRUCTURE m1.l0.shifter kind=shifter slot=shifter mode=1 lane=0 width=16 format=int16_unsigned ops=shl,shr_arith,rol sv=alu_core_u_m1_l0_shifter
  // // STRUCTURE m1.l0.logic kind=logic slot=logic mode=1 lane=0 width=16 format=int16_unsigned ops=and,or,xor,not sv=alu_core_u_gate_rows_0
  // // STRUCTURE m1.l0.bitcount kind=bitcount slot=bitcount mode=1 lane=0 width=16 format=int16_unsigned ops=popcount,clz,ctz sv=alu_core_u_m1_l0_bitcount
  // // STRUCTURE m2.l0.adder kind=adder slot=adder mode=2 lane=0 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_pair_m2_l0
  // // STRUCTURE m2.l1.adder kind=adder slot=adder mode=2 lane=1 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_pair_m2_l1
  // // STRUCTURE m2.l0.multiplier kind=multiplier slot=multiplier mode=2 lane=0 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_m2_l0_multiplier
  // // STRUCTURE m2.l1.multiplier kind=multiplier slot=multiplier mode=2 lane=1 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_m2_l1_multiplier
  // // STRUCTURE m2.l0.comparator kind=comparator slot=comparator mode=2 lane=0 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_pair_m2_l0
  // // STRUCTURE m2.l1.comparator kind=comparator slot=comparator mode=2 lane=1 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_pair_m2_l1
  // // STRUCTURE m2.l0.shifter kind=shifter slot=shifter mode=2 lane=0 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l0_shifter
  // // STRUCTURE m2.l1.shifter kind=shifter slot=shifter mode=2 lane=1 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l1_shifter
  // // STRUCTURE m2.l0.logic kind=logic slot=logic mode=2 lane=0 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_gate_rows_0
  // // STRUCTURE m2.l1.logic kind=logic slot=logic mode=2 lane=1 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_gate_rows_0
  // // STRUCTURE m2.l0.bitcount kind=bitcount slot=bitcount mode=2 lane=0 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l0_bitcount
  // // STRUCTURE m2.l1.bitcount kind=bitcount slot=bitcount mode=2 lane=1 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l1_bitcount
  // LIBRARY: fam_add_partitioned_w16_16_carry_kill_gate_0cc88441ac18, fam_add_partitioned_w16_16_carry_kill_gate_5f03ce7bcff6, fam_add_partitioned_w16_8_carry_kill_gate_0cc88441ac18, fam_adder_carry_lookahead, fam_adder_carry_skip_w9, fam_adder_carry_skip_w9_component_block_adder_adder_w1, fam_adder_carry_skip_w9_component_block_adder_adder_w4, fam_adder_cla_level, fam_adder_ripple_carry, fam_adder_ripple_chunk, fam_cmp_prefix_comparator, fam_cmp_subtractor_ripple_carry_p44ebdeaac57043a730d4d7405bd3a8a7932872aa358ca2f3675dab0ea6d5d1f5_sum_or_tree_s_w8, fam_count_popcount_balanced_tree_compressor_4_2_prefix_synthesis_nonuniform_arrival_p453cf_w8, fam_count_priority_encoder_g8_l2_one_hot_then_encode_w16, fam_count_tzc_debruijn_multiply_index_twos_complement_and_pe7180_w16, fam_incr_prefix_and, fam_logic_gate_row, fam_mul_direct_dadda_3_2_w9_s_p812bf641, fam_mul_segmented_grid_w8_s_p7da09409, fam_mul_squarer_w16_u_pa74b3b61, fam_mul_squarer_w16_u_pa74b3b61_sq, fam_mul_twin_precision_w16_16s_mag_ff7a627b5d2a, fam_mul_twin_precision_w16_16s_mag_ff7a627b5d2a_u, fam_prefix_arrival_0_0_0_1_1_1_1_1_1_2_2_2_2_2_2_3_3_3_3_3_3_4_4_4_4_4_4_5_5_5_5_5_5_6_6_6_w36, fam_prefix_arrival_0_0_1_1_1_1_2_2_2_3_3_3_4_4_4_4_5_5_w18, fam_prefix_arrival_0_1_1_w3, fam_prefix_brent_kung_w18_flag_dual, fam_prefix_han_carlson_w36_ling, fam_prefix_harris_l0f1_w11_flagm_late, fam_shift_butterfly_network, fam_shift_keep_mask, fam_shift_masked_merged, fam_shift_stage (chialu.targets.rtl.families: the modules of the declared families the lane modules instantiate; their text follows the generated modules)
  logic [2:0] rnd_sel;
  logic [2:0] rnd;
  logic daz;
  logic ftz;
  logic dual;
  logic [15:0] y_m0_gate_rows_0;
  logic [19:0] fl_m0_gate_rows_0;
  logic [15:0] y_m0_pair_m0_l0;
  logic [19:0] fl_m0_pair_m0_l0;
  logic [15:0] y_m0_m0_l0_multiplier;
  logic [19:0] fl_m0_m0_l0_multiplier;
  logic [15:0] y_m0_m0_l0_shifter;
  logic [19:0] fl_m0_m0_l0_shifter;
  logic [15:0] y_m0_m0_l0_bitcount;
  logic [19:0] fl_m0_m0_l0_bitcount;
  logic [15:0] y_m0;
  logic [19:0] fl_m0;
  logic [15:0] y_m1_gate_rows_0;
  logic [19:0] fl_m1_gate_rows_0;
  logic [15:0] y_m1_pair_m1_l0;
  logic [19:0] fl_m1_pair_m1_l0;
  logic [15:0] y_m1_m1_l0_multiplier;
  logic [19:0] fl_m1_m1_l0_multiplier;
  logic [15:0] y_m1_m1_l0_shifter;
  logic [19:0] fl_m1_m1_l0_shifter;
  logic [15:0] y_m1_m1_l0_bitcount;
  logic [19:0] fl_m1_m1_l0_bitcount;
  logic [15:0] y_m1;
  logic [19:0] fl_m1;
  logic [15:0] y_m2_gate_rows_0;
  logic [19:0] fl_m2_gate_rows_0;
  logic [15:0] y_m2_pair_m2_l0;
  logic [19:0] fl_m2_pair_m2_l0;
  logic [15:0] y_m2_pair_m2_l1;
  logic [19:0] fl_m2_pair_m2_l1;
  logic [15:0] y_m2_m2_l0_multiplier;
  logic [19:0] fl_m2_m2_l0_multiplier;
  logic [15:0] y_m2_m2_l1_multiplier;
  logic [19:0] fl_m2_m2_l1_multiplier;
  logic [15:0] y_m2_m2_l0_shifter;
  logic [19:0] fl_m2_m2_l0_shifter;
  logic [15:0] y_m2_m2_l1_shifter;
  logic [19:0] fl_m2_m2_l1_shifter;
  logic [15:0] y_m2_m2_l0_bitcount;
  logic [19:0] fl_m2_m2_l0_bitcount;
  logic [15:0] y_m2_m2_l1_bitcount;
  logic [19:0] fl_m2_m2_l1_bitcount;
  logic [15:0] y_m2;
  logic [19:0] fl_m2;
  logic [19:0] fl_all;
  assign rnd_sel = 3'd0;
  assign rnd = rnd_sel;
  assign daz = 1'b0;
  assign ftz = 1'b0;
  assign dual = 1'b0;
  assign y_m0 = y_m0_gate_rows_0 | y_m0_pair_m0_l0 | y_m0_m0_l0_multiplier | y_m0_m0_l0_shifter | y_m0_m0_l0_bitcount;
  assign fl_m0 = fl_m0_gate_rows_0 | fl_m0_pair_m0_l0 | fl_m0_m0_l0_multiplier | fl_m0_m0_l0_shifter | fl_m0_m0_l0_bitcount;
  assign y_m1 = y_m1_gate_rows_0 | y_m1_pair_m1_l0 | y_m1_m1_l0_multiplier | y_m1_m1_l0_shifter | y_m1_m1_l0_bitcount;
  assign fl_m1 = fl_m1_gate_rows_0 | fl_m1_pair_m1_l0 | fl_m1_m1_l0_multiplier | fl_m1_m1_l0_shifter | fl_m1_m1_l0_bitcount;
  assign y_m2 = y_m2_gate_rows_0 | y_m2_pair_m2_l0 | y_m2_pair_m2_l1 | y_m2_m2_l0_multiplier | y_m2_m2_l1_multiplier | y_m2_m2_l0_shifter | y_m2_m2_l1_shifter | y_m2_m2_l0_bitcount | y_m2_m2_l1_bitcount;
  assign fl_m2 = fl_m2_gate_rows_0 | fl_m2_pair_m2_l0 | fl_m2_pair_m2_l1 | fl_m2_m2_l0_multiplier | fl_m2_m2_l1_multiplier | fl_m2_m2_l0_shifter | fl_m2_m2_l1_shifter | fl_m2_m2_l0_bitcount | fl_m2_m2_l1_bitcount;
  alu_core_u_gate_rows_0 u_gate_rows_0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_gate_rows_0), .fl_m0(fl_m0_gate_rows_0), .y_m1(y_m1_gate_rows_0), .fl_m1(fl_m1_gate_rows_0), .y_m2(y_m2_gate_rows_0), .fl_m2(fl_m2_gate_rows_0));
  alu_core_u_pair_m0_l0 u_pair_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_pair_m0_l0), .fl_m0(fl_m0_pair_m0_l0));
  alu_core_u_pair_m1_l0 u_pair_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_pair_m1_l0), .fl_m1(fl_m1_pair_m1_l0));
  alu_core_u_pair_m2_l0 u_pair_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_pair_m2_l0), .fl_m2(fl_m2_pair_m2_l0));
  alu_core_u_pair_m2_l1 u_pair_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_pair_m2_l1), .fl_m2(fl_m2_pair_m2_l1));
  alu_core_u_m0_l0_multiplier u_m0_l0_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_multiplier), .fl_m0(fl_m0_m0_l0_multiplier));
  alu_core_u_m0_l0_shifter u_m0_l0_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_shifter), .fl_m0(fl_m0_m0_l0_shifter));
  alu_core_u_m0_l0_bitcount u_m0_l0_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_bitcount), .fl_m0(fl_m0_m0_l0_bitcount));
  alu_core_u_m1_l0_multiplier u_m1_l0_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_multiplier), .fl_m1(fl_m1_m1_l0_multiplier));
  alu_core_u_m1_l0_shifter u_m1_l0_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_shifter), .fl_m1(fl_m1_m1_l0_shifter));
  alu_core_u_m1_l0_bitcount u_m1_l0_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_bitcount), .fl_m1(fl_m1_m1_l0_bitcount));
  alu_core_u_m2_l0_multiplier u_m2_l0_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_multiplier), .fl_m2(fl_m2_m2_l0_multiplier));
  alu_core_u_m2_l1_multiplier u_m2_l1_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_multiplier), .fl_m2(fl_m2_m2_l1_multiplier));
  alu_core_u_m2_l0_shifter u_m2_l0_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_shifter), .fl_m2(fl_m2_m2_l0_shifter));
  alu_core_u_m2_l1_shifter u_m2_l1_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_shifter), .fl_m2(fl_m2_m2_l1_shifter));
  alu_core_u_m2_l0_bitcount u_m2_l0_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_bitcount), .fl_m2(fl_m2_m2_l0_bitcount));
  alu_core_u_m2_l1_bitcount u_m2_l1_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_bitcount), .fl_m2(fl_m2_m2_l1_bitcount));
  always_comb begin
    case (mode)
      2'd0: begin y = y_m0; fl_all = fl_m0; end
      2'd1: begin y = y_m1; fl_all = fl_m1; end
      2'd2: begin y = y_m2; fl_all = fl_m2; end
      default: begin y = '0; fl_all = '0; end
    endcase
  end
  assign flags[0] = fl_all[7];
  assign flags[1] = fl_all[8];
  assign flags[2] = fl_all[17];
  assign flags[3] = fl_all[18];
endmodule
// EVOLVE-BLOCK-END

module alu_core_m0_adder_comparator_sh #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0,
  output logic [15:0] pc_a_m0,
  output logic [15:0] pc_b_m0,
  output logic [0:0] pc_cin_m0,
  input  logic [15:0] pc_s_m0,
  input  logic [0:0] pc_co_m0
);
  // alu_core_m0_adder_comparator_sh: lane LANE of mode 0 (int16_twos_complement) for the adder/comparator ops add, sub, adc, neg, abs, add_sat, min, max, cmp; the result buses are the mode's, with only this lane's bits written; the unit's shared adder serve this lane through the pc_/tp_ buses
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_add_sLANE;
  logic m0_add_coutLANE;
  logic [15:0] m0_cmp_aLANE;
  logic [15:0] m0_cmp_bLANE;
  logic m0_cmp_ltLANE;
  logic m0_cmp_eqLANE;
  logic signed [34:0] m0_o0ex0_LANE;
  logic signed [34:0] m0_o1ex0_LANE;
  logic signed [34:0] m0_o2ex0_LANE;
  logic signed [34:0] m0_o3ex0_LANE;
  logic signed [34:0] m0_o4ex0_LANE;
  logic signed [34:0] m0_o5ex0_LANE;
  logic signed [34:0] m0_o8ex0_LANE;
  logic signed [34:0] m0_o9ex0_LANE;
  logic signed [34:0] m0_o10ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.adder.m0: the unit's shared partitioned adder (subword partitioned_carry_chain)
  assign m0_add_sLANE = pc_s_m0[(LANE)*16 +: 16];
  assign m0_add_coutLANE = pc_co_m0[(LANE+1)*1-1];
  // structure core.comparator.m0: family prefix_comparator realized by the library module fam_cmp_prefix_comparator
  fam_cmp_prefix_comparator #(.W(16), .SIGNED(1), .STRUCTURE(0), .RADIX(2)) u_m0_cmpLANE (.a(m0_cmp_aLANE), .b(m0_cmp_bLANE), .lt(m0_cmp_ltLANE), .eq(m0_cmp_eqLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_cmp_aLANE = 'x; m0_cmp_bLANE = 'x; m0_o0ex0_LANE = 'x; m0_o1ex0_LANE = 'x; m0_o2ex0_LANE = 'x; m0_o3ex0_LANE = 'x;
    m0_o4ex0_LANE = 'x; m0_o5ex0_LANE = 'x; m0_o8ex0_LANE = 'x; m0_o9ex0_LANE = 'x; m0_o10ex0_LANE = 'x;
    pc_a_m0 = '0; pc_b_m0 = '0; pc_cin_m0 = '0;
    case (op)
      5'd0: begin
        pc_a_m0[(LANE)*16 +: 16] = m0_aLANE; pc_b_m0[(LANE)*16 +: 16] = m0_bLANE; pc_cin_m0[(LANE)*1] = 1'b0;
        m0_o0ex0_LANE = $signed({(m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o0ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (m0_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd1: begin
        pc_a_m0[(LANE)*16 +: 16] = m0_aLANE; pc_b_m0[(LANE)*16 +: 16] = ~m0_bLANE; pc_cin_m0[(LANE)*1] = 1'b1;
        m0_o1ex0_LANE = $signed({(m0_aLANE[15] ^ ~m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o1ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ ~m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ ~m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (~m0_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd2: begin
        pc_a_m0[(LANE)*16 +: 16] = m0_aLANE; pc_b_m0[(LANE)*16 +: 16] = m0_bLANE; pc_cin_m0[(LANE)*1] = 1'b1;
        m0_o2ex0_LANE = $signed({(m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o2ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (m0_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd3: begin
        pc_a_m0[(LANE)*16 +: 16] = 16'd0; pc_b_m0[(LANE)*16 +: 16] = ~m0_aLANE; pc_cin_m0[(LANE)*1] = 1'b1;
        m0_o3ex0_LANE = $signed({(1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o3ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (m0_aLANE != 0 ? (10'd1 << 7) : 10'd0);
      end
      5'd4: begin
        pc_a_m0[(LANE)*16 +: 16] = 16'd0; pc_b_m0[(LANE)*16 +: 16] = ~m0_aLANE; pc_cin_m0[(LANE)*1] = 1'b1;
        m0_o4ex0_LANE = (m0_aLANE[15] ? $signed({(1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE), m0_add_sLANE}) : $signed({1'b0, m0_aLANE}));
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o4ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = ((m0_aLANE[15] & ((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15])) ? (10'd1 << 8) : 10'd0) | ((m0_aLANE[15] & ((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15])) ? (10'd1 << 2) : 10'd0);
      end
      5'd5: begin
        pc_a_m0[(LANE)*16 +: 16] = m0_aLANE; pc_b_m0[(LANE)*16 +: 16] = m0_bLANE; pc_cin_m0[(LANE)*1] = 1'b0;
        m0_o5ex0_LANE = $signed({(m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_sat(m0_o5ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0);
      end
      5'd8: begin
        m0_cmp_aLANE = m0_aLANE; m0_cmp_bLANE = m0_bLANE;
        y_m0[((LANE*16)+0) +: 16] = (m0_cmp_ltLANE | m0_cmp_eqLANE) ? m0_aLANE : m0_bLANE;
      end
      5'd9: begin
        m0_cmp_aLANE = m0_aLANE; m0_cmp_bLANE = m0_bLANE;
        y_m0[((LANE*16)+0) +: 16] = (~m0_cmp_ltLANE) ? m0_aLANE : m0_bLANE;
      end
      5'd10: begin
        m0_cmp_aLANE = m0_aLANE; m0_cmp_bLANE = m0_bLANE;
        y_m0[((LANE*16)+0) +: 16] = {{13{1'b0}}, (~m0_cmp_ltLANE & ~m0_cmp_eqLANE), m0_cmp_eqLANE, m0_cmp_ltLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_bitcount #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_bitcount: lane LANE of mode 0 (int16_twos_complement) for the bitcount ops popcount, clz, ctz; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_clz_aLANE;
  logic [4:0] m0_clz_nLANE;
  logic signed [34:0] m0_o18ex0_LANE;
  logic signed [34:0] m0_o19ex0_LANE;
  logic signed [34:0] m0_o20ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.bitcount.m0: family priority_encoder realized by the library module fam_count_priority_encoder_g8_l2_one_hot_then_encode_w16 (clz)
  fam_count_priority_encoder_g8_l2_one_hot_then_encode_w16 u_m0_clzLANE (.a(m0_clz_aLANE), .n(m0_clz_nLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_clz_aLANE = 'x; m0_o18ex0_LANE = 'x; m0_o19ex0_LANE = 'x; m0_o20ex0_LANE = 'x;
    case (op)
      5'd18: begin
        y_m0[((LANE*16)+0) +: 16] = m0_aLANE[0] + m0_aLANE[1] + m0_aLANE[2] + m0_aLANE[3] + m0_aLANE[4] + m0_aLANE[5] + m0_aLANE[6] + m0_aLANE[7] + m0_aLANE[8] + m0_aLANE[9] + m0_aLANE[10] + m0_aLANE[11] + m0_aLANE[12] + m0_aLANE[13] + m0_aLANE[14] + m0_aLANE[15];
      end
      5'd19: begin
        m0_clz_aLANE = m0_aLANE;
        y_m0[((LANE*16)+0) +: 16] = {{11{1'b0}}, m0_clz_nLANE};
      end
      5'd20: begin
        y_m0[((LANE*16)+0) +: 16] = m0_aLANE[0] ? 16'd0 : m0_aLANE[1] ? 16'd1 : m0_aLANE[2] ? 16'd2 : m0_aLANE[3] ? 16'd3 : m0_aLANE[4] ? 16'd4 : m0_aLANE[5] ? 16'd5 : m0_aLANE[6] ? 16'd6 : m0_aLANE[7] ? 16'd7 : m0_aLANE[8] ? 16'd8 : m0_aLANE[9] ? 16'd9 : m0_aLANE[10] ? 16'd10 : m0_aLANE[11] ? 16'd11 : m0_aLANE[12] ? 16'd12 : m0_aLANE[13] ? 16'd13 : m0_aLANE[14] ? 16'd14 : m0_aLANE[15] ? 16'd15 : 16'd16;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_multiplier_sh #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0,
  input  logic [31:0] tp_p_m0
);
  // alu_core_m0_multiplier_sh: lane LANE of mode 0 (int16_twos_complement) for the multiplier ops mul, mul_high; the result buses are the mode's, with only this lane's bits written; the unit's shared multiplier serve this lane through the pc_/tp_ buses
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_mul_aLANE;
  logic [15:0] m0_mul_bLANE;
  logic [31:0] m0_mul_pLANE;
  logic signed [34:0] m0_o6ex0_LANE;
  logic signed [34:0] m0_o7ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.multiplier.m0: family twin_precision_subword realized by the unit's shared twin-precision multiplier 
  assign m0_mul_pLANE = tp_p_m0[(LANE)*32 +: 32];
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_mul_aLANE = 'x; m0_mul_bLANE = 'x; m0_o6ex0_LANE = 'x; m0_o7ex0_LANE = 'x;
    case (op)
      5'd6: begin
        m0_mul_aLANE = m0_aLANE; m0_mul_bLANE = m0_bLANE;
        m0_o6ex0_LANE = $signed({{3{m0_mul_pLANE[31]}}, m0_mul_pLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o6ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (m0_o6ex0_LANE > 35'sd32767 || m0_o6ex0_LANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m0_o6ex0_LANE > 35'sd32767 || m0_o6ex0_LANE < -35'sd32768 ? (10'd1 << 2) : 10'd0);
      end
      5'd7: begin
        m0_mul_aLANE = m0_aLANE; m0_mul_bLANE = m0_bLANE;
        m0_o7ex0_LANE = $signed({{3{m0_mul_pLANE[31]}}, m0_mul_pLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o7ex0_LANE >>> 16);
        fl_m0[(0+LANE)*10 +: 10] = (m0_o7ex0_LANE > 35'sd32767 || m0_o7ex0_LANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m0_o7ex0_LANE > 35'sd32767 || m0_o7ex0_LANE < -35'sd32768 ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_shifter #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_shifter: lane LANE of mode 0 (int16_twos_complement) for the shifter ops shl, shr_arith, rol; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_sh_aLANE;
  logic [3:0] m0_sh_amtLANE;
  logic [2:0] m0_sh_opLANE;
  logic [15:0] m0_sh_yLANE;
  logic signed [34:0] m0_o11ex0_LANE;
  logic signed [34:0] m0_o12ex0_LANE;
  logic signed [34:0] m0_o13ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.shifter.m0: family masked_merged realized by the library module fam_shift_masked_merged
  fam_shift_masked_merged #(.W(16), .MASKGEN(1), .MERGE(1), .R_RADIX_LOG2(1), .R_ONE_HOT(1), .R_ORDER(1), .STICKY(1)) u_m0_shifterLANE (.a(m0_sh_aLANE), .amt(m0_sh_amtLANE), .op(m0_sh_opLANE), .y(m0_sh_yLANE), .sticky());
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_sh_aLANE = 'x; m0_sh_amtLANE = 'x; m0_sh_opLANE = 'x; m0_o11ex0_LANE = 'x; m0_o12ex0_LANE = 'x; m0_o13ex0_LANE = 'x;
    case (op)
      5'd11: begin
        m0_sh_aLANE = m0_aLANE; m0_sh_amtLANE = 4'(m0_bLANE % 16'd16); m0_sh_opLANE = 3'd0;
        y_m0[((LANE*16)+0) +: 16] = m0_sh_yLANE;
      end
      5'd12: begin
        m0_sh_aLANE = m0_aLANE; m0_sh_amtLANE = 4'(m0_bLANE % 16'd16); m0_sh_opLANE = 3'd2;
        y_m0[((LANE*16)+0) +: 16] = m0_sh_yLANE;
      end
      5'd13: begin
        m0_sh_aLANE = m0_aLANE; m0_sh_amtLANE = 4'(m0_bLANE % 16'd16); m0_sh_opLANE = 3'd3;
        y_m0[((LANE*16)+0) +: 16] = m0_sh_yLANE;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_adder_comparator_sh #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1,
  output logic [15:0] pc_a_m1,
  output logic [15:0] pc_b_m1,
  output logic [0:0] pc_cin_m1,
  input  logic [15:0] pc_s_m1,
  input  logic [0:0] pc_co_m1
);
  // alu_core_m1_adder_comparator_sh: lane LANE of mode 1 (int16_unsigned) for the adder/comparator ops add, sub, adc, neg, abs, add_sat, min, max, cmp; the result buses are the mode's, with only this lane's bits written; the unit's shared adder serve this lane through the pc_/tp_ buses
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_add_sLANE;
  logic m1_add_coutLANE;
  logic [15:0] m1_cmp_aLANE;
  logic [15:0] m1_cmp_bLANE;
  logic m1_cmp_ltLANE;
  logic m1_cmp_eqLANE;
  logic signed [34:0] m1_o0ex0_LANE;
  logic signed [34:0] m1_o1ex0_LANE;
  logic signed [34:0] m1_o2ex0_LANE;
  logic signed [34:0] m1_o3ex0_LANE;
  logic signed [34:0] m1_o4ex0_LANE;
  logic signed [34:0] m1_o4sx0_LANE;
  logic signed [34:0] m1_o5ex0_LANE;
  logic signed [34:0] m1_o8ex0_LANE;
  logic signed [34:0] m1_o9ex0_LANE;
  logic signed [34:0] m1_o10ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.adder.m1: the unit's shared partitioned adder (subword partitioned_carry_chain)
  assign m1_add_sLANE = pc_s_m1[(LANE)*16 +: 16];
  assign m1_add_coutLANE = pc_co_m1[(LANE+1)*1-1];
  // structure core.comparator.m1: family prefix_comparator realized by the library module fam_cmp_prefix_comparator
  fam_cmp_prefix_comparator #(.W(16), .SIGNED(0), .STRUCTURE(0), .RADIX(2)) u_m1_cmpLANE (.a(m1_cmp_aLANE), .b(m1_cmp_bLANE), .lt(m1_cmp_ltLANE), .eq(m1_cmp_eqLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_cmp_aLANE = 'x; m1_cmp_bLANE = 'x; m1_o0ex0_LANE = 'x; m1_o1ex0_LANE = 'x; m1_o2ex0_LANE = 'x; m1_o3ex0_LANE = 'x;
    m1_o4ex0_LANE = 'x; m1_o4sx0_LANE = 'x; m1_o5ex0_LANE = 'x; m1_o8ex0_LANE = 'x; m1_o9ex0_LANE = 'x; m1_o10ex0_LANE = 'x;
    pc_a_m1 = '0; pc_b_m1 = '0; pc_cin_m1 = '0;
    case (op)
      5'd0: begin
        pc_a_m1[(LANE)*16 +: 16] = m1_aLANE; pc_b_m1[(LANE)*16 +: 16] = m1_bLANE; pc_cin_m1[(LANE)*1] = 1'b0;
        m1_o0ex0_LANE = $signed({1'b0, m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o0ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (m1_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd1: begin
        pc_a_m1[(LANE)*16 +: 16] = m1_aLANE; pc_b_m1[(LANE)*16 +: 16] = ~m1_bLANE; pc_cin_m1[(LANE)*1] = 1'b1;
        m1_o1ex0_LANE = $signed({~m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o1ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (~m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ ~m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (~m1_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd2: begin
        pc_a_m1[(LANE)*16 +: 16] = m1_aLANE; pc_b_m1[(LANE)*16 +: 16] = m1_bLANE; pc_cin_m1[(LANE)*1] = 1'b1;
        m1_o2ex0_LANE = $signed({1'b0, m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o2ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (m1_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd3: begin
        pc_a_m1[(LANE)*16 +: 16] = 16'd0; pc_b_m1[(LANE)*16 +: 16] = ~m1_aLANE; pc_cin_m1[(LANE)*1] = 1'b1;
        m1_o3ex0_LANE = $signed({~m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o3ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (~m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((1'b0 ^ ~m1_aLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (m1_aLANE != 0 ? (10'd1 << 7) : 10'd0);
      end
      5'd4: begin
        m1_o4ex0_LANE = (m1_vaLANE < 0) ? -m1_vaLANE : m1_vaLANE;
        m1_o4sx0_LANE = (($signed({m1_aLANE[15], m1_aLANE}) < 0) ? -$signed({m1_aLANE[15], m1_aLANE}) : $signed({m1_aLANE[15], m1_aLANE}));
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o4ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_o4sx0_LANE > 35'sd32767 || m1_o4sx0_LANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m1_o4ex0_LANE > 35'sd65535 || m1_o4ex0_LANE < 0 ? (10'd1 << 2) : 10'd0);
      end
      5'd5: begin
        pc_a_m1[(LANE)*16 +: 16] = m1_aLANE; pc_b_m1[(LANE)*16 +: 16] = m1_bLANE; pc_cin_m1[(LANE)*1] = 1'b0;
        m1_o5ex0_LANE = $signed({1'b0, m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_sat(m1_o5ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0);
      end
      5'd8: begin
        m1_cmp_aLANE = m1_aLANE; m1_cmp_bLANE = m1_bLANE;
        y_m1[((LANE*16)+0) +: 16] = (m1_cmp_ltLANE | m1_cmp_eqLANE) ? m1_aLANE : m1_bLANE;
      end
      5'd9: begin
        m1_cmp_aLANE = m1_aLANE; m1_cmp_bLANE = m1_bLANE;
        y_m1[((LANE*16)+0) +: 16] = (~m1_cmp_ltLANE) ? m1_aLANE : m1_bLANE;
      end
      5'd10: begin
        m1_cmp_aLANE = m1_aLANE; m1_cmp_bLANE = m1_bLANE;
        y_m1[((LANE*16)+0) +: 16] = {{13{1'b0}}, (~m1_cmp_ltLANE & ~m1_cmp_eqLANE), m1_cmp_eqLANE, m1_cmp_ltLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_bitcount #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_bitcount: lane LANE of mode 1 (int16_unsigned) for the bitcount ops popcount, clz, ctz; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_ctz_aLANE;
  logic [4:0] m1_ctz_nLANE;
  logic signed [34:0] m1_o18ex0_LANE;
  logic signed [34:0] m1_o19ex0_LANE;
  logic signed [34:0] m1_o20ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.bitcount.m1: family trailing_zero realized by the library module fam_count_tzc_debruijn_multiply_index_twos_complement_and_pe7180_w16 (ctz)
  fam_count_tzc_debruijn_multiply_index_twos_complement_and_pe7180_w16 u_m1_ctzLANE (.a(m1_ctz_aLANE), .n(m1_ctz_nLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_ctz_aLANE = 'x; m1_o18ex0_LANE = 'x; m1_o19ex0_LANE = 'x; m1_o20ex0_LANE = 'x;
    case (op)
      5'd18: begin
        y_m1[((LANE*16)+0) +: 16] = m1_aLANE[0] + m1_aLANE[1] + m1_aLANE[2] + m1_aLANE[3] + m1_aLANE[4] + m1_aLANE[5] + m1_aLANE[6] + m1_aLANE[7] + m1_aLANE[8] + m1_aLANE[9] + m1_aLANE[10] + m1_aLANE[11] + m1_aLANE[12] + m1_aLANE[13] + m1_aLANE[14] + m1_aLANE[15];
      end
      5'd19: begin
        y_m1[((LANE*16)+0) +: 16] = m1_aLANE[15] ? 16'd0 : m1_aLANE[14] ? 16'd1 : m1_aLANE[13] ? 16'd2 : m1_aLANE[12] ? 16'd3 : m1_aLANE[11] ? 16'd4 : m1_aLANE[10] ? 16'd5 : m1_aLANE[9] ? 16'd6 : m1_aLANE[8] ? 16'd7 : m1_aLANE[7] ? 16'd8 : m1_aLANE[6] ? 16'd9 : m1_aLANE[5] ? 16'd10 : m1_aLANE[4] ? 16'd11 : m1_aLANE[3] ? 16'd12 : m1_aLANE[2] ? 16'd13 : m1_aLANE[1] ? 16'd14 : m1_aLANE[0] ? 16'd15 : 16'd16;
      end
      5'd20: begin
        m1_ctz_aLANE = m1_aLANE;
        y_m1[((LANE*16)+0) +: 16] = {{11{1'b0}}, m1_ctz_nLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_multiplier #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_multiplier: lane LANE of mode 1 (int16_unsigned) for the multiplier ops mul, mul_high; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_mul_aLANE;
  logic [15:0] m1_mul_bLANE;
  logic [31:0] m1_mul_pLANE;
  logic signed [34:0] m1_o6ex0_LANE;
  logic signed [34:0] m1_o6sx0_ANE;
  logic signed [34:0] m1_o7ex0_LANE;
  logic signed [34:0] m1_o7sx0_ANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.multiplier.m1: family squarer realized by the library module fam_mul_squarer_w16_u_pa74b3b61
  fam_mul_squarer_w16_u_pa74b3b61 u_m1_mulLANE (.a(m1_mul_aLANE), .b(m1_mul_bLANE), .p(m1_mul_pLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_mul_aLANE = 'x; m1_mul_bLANE = 'x; m1_o6ex0_LANE = 'x; m1_o6sx0_ANE = 'x; m1_o7ex0_LANE = 'x; m1_o7sx0_ANE = 'x;
    case (op)
      5'd6: begin
        m1_mul_aLANE = m1_aLANE; m1_mul_bLANE = m1_bLANE;
        m1_o6ex0_LANE = $signed({{3{1'b0}}, m1_mul_pLANE});
        m1_o6sx0_ANE = m1_o6ex0_LANE - (m1_aLANE[15] ? ($signed(m1_vbLANE) <<< 16) : 35'sd0) - (m1_bLANE[15] ? ($signed(m1_vaLANE) <<< 16) : 35'sd0) + ((m1_aLANE[15] & m1_bLANE[15]) ? 35'sd4294967296 : 35'sd0);
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o6ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_o6sx0_ANE > 35'sd32767 || m1_o6sx0_ANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m1_o6ex0_LANE > 35'sd65535 || m1_o6ex0_LANE < 0 ? (10'd1 << 2) : 10'd0);
      end
      5'd7: begin
        m1_mul_aLANE = m1_aLANE; m1_mul_bLANE = m1_bLANE;
        m1_o7ex0_LANE = $signed({{3{1'b0}}, m1_mul_pLANE});
        m1_o7sx0_ANE = m1_o7ex0_LANE - (m1_aLANE[15] ? ($signed(m1_vbLANE) <<< 16) : 35'sd0) - (m1_bLANE[15] ? ($signed(m1_vaLANE) <<< 16) : 35'sd0) + ((m1_aLANE[15] & m1_bLANE[15]) ? 35'sd4294967296 : 35'sd0);
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o7ex0_LANE >>> 16);
        fl_m1[(0+LANE)*10 +: 10] = (m1_o7sx0_ANE > 35'sd32767 || m1_o7sx0_ANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m1_o7ex0_LANE > 35'sd65535 || m1_o7ex0_LANE < 0 ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_shifter #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_shifter: lane LANE of mode 1 (int16_unsigned) for the shifter ops shl, shr_arith, rol; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_sh_aLANE;
  logic [3:0] m1_sh_amtLANE;
  logic [2:0] m1_sh_opLANE;
  logic [15:0] m1_sh_yLANE;
  logic signed [34:0] m1_o11ex0_LANE;
  logic signed [34:0] m1_o12ex0_LANE;
  logic signed [34:0] m1_o13ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.shifter.m1: family butterfly_network realized by the library module fam_shift_butterfly_network
  fam_shift_butterfly_network #(.W(16), .NETWORK(0), .STICKY(1)) u_m1_shifterLANE (.a(m1_sh_aLANE), .amt(m1_sh_amtLANE), .op(m1_sh_opLANE), .y(m1_sh_yLANE), .sticky());
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_sh_aLANE = 'x; m1_sh_amtLANE = 'x; m1_sh_opLANE = 'x; m1_o11ex0_LANE = 'x; m1_o12ex0_LANE = 'x; m1_o13ex0_LANE = 'x;
    case (op)
      5'd11: begin
        m1_sh_aLANE = m1_aLANE; m1_sh_amtLANE = 4'(m1_bLANE % 16'd16); m1_sh_opLANE = 3'd0;
        y_m1[((LANE*16)+0) +: 16] = m1_sh_yLANE;
      end
      5'd12: begin
        m1_sh_aLANE = m1_aLANE; m1_sh_amtLANE = 4'(m1_bLANE % 16'd16); m1_sh_opLANE = 3'd2;
        y_m1[((LANE*16)+0) +: 16] = m1_sh_yLANE;
      end
      5'd13: begin
        m1_sh_aLANE = m1_aLANE; m1_sh_amtLANE = 4'(m1_bLANE % 16'd16); m1_sh_opLANE = 3'd3;
        y_m1[((LANE*16)+0) +: 16] = m1_sh_yLANE;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_adder_comparator_sh #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2,
  output logic [15:0] pc_a_m2,
  output logic [15:0] pc_b_m2,
  output logic [1:0] pc_cin_m2,
  input  logic [15:0] pc_s_m2,
  input  logic [1:0] pc_co_m2
);
  // alu_core_m2_adder_comparator_sh: lane LANE of mode 2 (int8_twos_complement) for the adder/comparator ops add, sub, adc, neg, abs, add_sat, min, max, cmp; the result buses are the mode's, with only this lane's bits written; the unit's shared adder serve this lane through the pc_/tp_ buses
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_add_sLANE;
  logic m2_add_coutLANE;
  logic [7:0] m2_cmp_aLANE;
  logic [7:0] m2_cmp_bLANE;
  logic m2_cmp_ltLANE;
  logic m2_cmp_eqLANE;
  logic signed [18:0] m2_o0ex0_LANE;
  logic signed [18:0] m2_o1ex0_LANE;
  logic signed [18:0] m2_o2ex0_LANE;
  logic signed [18:0] m2_o3ex0_LANE;
  logic signed [18:0] m2_o4ex0_LANE;
  logic signed [18:0] m2_o5ex0_LANE;
  logic signed [18:0] m2_o8ex0_LANE;
  logic signed [18:0] m2_o9ex0_LANE;
  logic signed [18:0] m2_o10ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.adder.m2: the unit's shared partitioned adder (subword partitioned_carry_chain)
  assign m2_add_sLANE = pc_s_m2[(LANE)*8 +: 8];
  assign m2_add_coutLANE = pc_co_m2[(LANE+1)*1-1];
  // structure core.comparator.m2: family subtractor_comparator realized by the library module fam_cmp_subtractor_ripple_carry_p44ebdeaac57043a730d4d7405bd3a8a7932872aa358ca2f3675dab0ea6d5d1f5_sum_or_tree_s_w8
  fam_cmp_subtractor_ripple_carry_p44ebdeaac57043a730d4d7405bd3a8a7932872aa358ca2f3675dab0ea6d5d1f5_sum_or_tree_s_w8 u_m2_cmpLANE (.a(m2_cmp_aLANE), .b(m2_cmp_bLANE), .lt(m2_cmp_ltLANE), .eq(m2_cmp_eqLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_cmp_aLANE = 'x; m2_cmp_bLANE = 'x; m2_o0ex0_LANE = 'x; m2_o1ex0_LANE = 'x; m2_o2ex0_LANE = 'x; m2_o3ex0_LANE = 'x;
    m2_o4ex0_LANE = 'x; m2_o5ex0_LANE = 'x; m2_o8ex0_LANE = 'x; m2_o9ex0_LANE = 'x; m2_o10ex0_LANE = 'x;
    pc_a_m2 = '0; pc_b_m2 = '0; pc_cin_m2 = '0;
    case (op)
      5'd0: begin
        pc_a_m2[(LANE)*8 +: 8] = m2_aLANE; pc_b_m2[(LANE)*8 +: 8] = m2_bLANE; pc_cin_m2[(LANE)*1] = 1'b0;
        m2_o0ex0_LANE = $signed({(m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o0ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (m2_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd1: begin
        pc_a_m2[(LANE)*8 +: 8] = m2_aLANE; pc_b_m2[(LANE)*8 +: 8] = ~m2_bLANE; pc_cin_m2[(LANE)*1] = 1'b1;
        m2_o1ex0_LANE = $signed({(m2_aLANE[7] ^ ~m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o1ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ ~m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ ~m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (~m2_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd2: begin
        pc_a_m2[(LANE)*8 +: 8] = m2_aLANE; pc_b_m2[(LANE)*8 +: 8] = m2_bLANE; pc_cin_m2[(LANE)*1] = 1'b1;
        m2_o2ex0_LANE = $signed({(m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o2ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (m2_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd3: begin
        pc_a_m2[(LANE)*8 +: 8] = 8'd0; pc_b_m2[(LANE)*8 +: 8] = ~m2_aLANE; pc_cin_m2[(LANE)*1] = 1'b1;
        m2_o3ex0_LANE = $signed({(1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o3ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (m2_aLANE != 0 ? (10'd1 << 7) : 10'd0);
      end
      5'd4: begin
        pc_a_m2[(LANE)*8 +: 8] = 8'd0; pc_b_m2[(LANE)*8 +: 8] = ~m2_aLANE; pc_cin_m2[(LANE)*1] = 1'b1;
        m2_o4ex0_LANE = (m2_aLANE[7] ? $signed({(1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE), m2_add_sLANE}) : $signed({1'b0, m2_aLANE}));
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o4ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = ((m2_aLANE[7] & ((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7])) ? (10'd1 << 8) : 10'd0) | ((m2_aLANE[7] & ((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7])) ? (10'd1 << 2) : 10'd0);
      end
      5'd5: begin
        pc_a_m2[(LANE)*8 +: 8] = m2_aLANE; pc_b_m2[(LANE)*8 +: 8] = m2_bLANE; pc_cin_m2[(LANE)*1] = 1'b0;
        m2_o5ex0_LANE = $signed({(m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_sat(m2_o5ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0);
      end
      5'd8: begin
        m2_cmp_aLANE = m2_aLANE; m2_cmp_bLANE = m2_bLANE;
        y_m2[((LANE*8)+0) +: 8] = (m2_cmp_ltLANE | m2_cmp_eqLANE) ? m2_aLANE : m2_bLANE;
      end
      5'd9: begin
        m2_cmp_aLANE = m2_aLANE; m2_cmp_bLANE = m2_bLANE;
        y_m2[((LANE*8)+0) +: 8] = (~m2_cmp_ltLANE) ? m2_aLANE : m2_bLANE;
      end
      5'd10: begin
        m2_cmp_aLANE = m2_aLANE; m2_cmp_bLANE = m2_bLANE;
        y_m2[((LANE*8)+0) +: 8] = {{5{1'b0}}, (~m2_cmp_ltLANE & ~m2_cmp_eqLANE), m2_cmp_eqLANE, m2_cmp_ltLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_bitcount #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_bitcount: lane LANE of mode 2 (int8_twos_complement) for the bitcount ops popcount, clz, ctz; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_popcount_aLANE;
  logic [3:0] m2_popcount_nLANE;
  logic signed [18:0] m2_o18ex0_LANE;
  logic signed [18:0] m2_o19ex0_LANE;
  logic signed [18:0] m2_o20ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.bitcount.m2: family popcount_counter_tree realized by the library module fam_count_popcount_balanced_tree_compressor_4_2_prefix_synthesis_nonuniform_arrival_p453cf_w8 (popcount)
  fam_count_popcount_balanced_tree_compressor_4_2_prefix_synthesis_nonuniform_arrival_p453cf_w8 u_m2_popcountLANE (.a(m2_popcount_aLANE), .n(m2_popcount_nLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_popcount_aLANE = 'x; m2_o18ex0_LANE = 'x; m2_o19ex0_LANE = 'x; m2_o20ex0_LANE = 'x;
    case (op)
      5'd18: begin
        m2_popcount_aLANE = m2_aLANE;
        y_m2[((LANE*8)+0) +: 8] = {{4{1'b0}}, m2_popcount_nLANE};
      end
      5'd19: begin
        y_m2[((LANE*8)+0) +: 8] = m2_aLANE[7] ? 8'd0 : m2_aLANE[6] ? 8'd1 : m2_aLANE[5] ? 8'd2 : m2_aLANE[4] ? 8'd3 : m2_aLANE[3] ? 8'd4 : m2_aLANE[2] ? 8'd5 : m2_aLANE[1] ? 8'd6 : m2_aLANE[0] ? 8'd7 : 8'd8;
      end
      5'd20: begin
        y_m2[((LANE*8)+0) +: 8] = m2_aLANE[0] ? 8'd0 : m2_aLANE[1] ? 8'd1 : m2_aLANE[2] ? 8'd2 : m2_aLANE[3] ? 8'd3 : m2_aLANE[4] ? 8'd4 : m2_aLANE[5] ? 8'd5 : m2_aLANE[6] ? 8'd6 : m2_aLANE[7] ? 8'd7 : 8'd8;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_multiplier #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_multiplier: lane LANE of mode 2 (int8_twos_complement) for the multiplier ops mul, mul_high; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_mul_aLANE;
  logic [7:0] m2_mul_bLANE;
  logic [15:0] m2_mul_pLANE;
  logic signed [18:0] m2_o6ex0_LANE;
  logic signed [18:0] m2_o7ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.multiplier.m2: family segmented_grid realized by the library module fam_mul_segmented_grid_w8_s_p7da09409
  fam_mul_segmented_grid_w8_s_p7da09409 u_m2_mulLANE (.a(m2_mul_aLANE), .b(m2_mul_bLANE), .p(m2_mul_pLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_mul_aLANE = 'x; m2_mul_bLANE = 'x; m2_o6ex0_LANE = 'x; m2_o7ex0_LANE = 'x;
    case (op)
      5'd6: begin
        m2_mul_aLANE = m2_aLANE; m2_mul_bLANE = m2_bLANE;
        m2_o6ex0_LANE = $signed({{3{m2_mul_pLANE[15]}}, m2_mul_pLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o6ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (m2_o6ex0_LANE > 19'sd127 || m2_o6ex0_LANE < -19'sd128 ? (10'd1 << 8) : 10'd0) | (m2_o6ex0_LANE > 19'sd127 || m2_o6ex0_LANE < -19'sd128 ? (10'd1 << 2) : 10'd0);
      end
      5'd7: begin
        m2_mul_aLANE = m2_aLANE; m2_mul_bLANE = m2_bLANE;
        m2_o7ex0_LANE = $signed({{3{m2_mul_pLANE[15]}}, m2_mul_pLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o7ex0_LANE >>> 8);
        fl_m2[(0+LANE)*10 +: 10] = (m2_o7ex0_LANE > 19'sd127 || m2_o7ex0_LANE < -19'sd128 ? (10'd1 << 8) : 10'd0) | (m2_o7ex0_LANE > 19'sd127 || m2_o7ex0_LANE < -19'sd128 ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_shifter #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_shifter: lane LANE of mode 2 (int8_twos_complement) for the shifter ops shl, shr_arith, rol; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_sh_aLANE;
  logic [2:0] m2_sh_amtLANE;
  logic [2:0] m2_sh_opLANE;
  logic [7:0] m2_sh_yLANE;
  logic signed [18:0] m2_o11ex0_LANE;
  logic signed [18:0] m2_o12ex0_LANE;
  logic signed [18:0] m2_o13ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.shifter.m2: family butterfly_network realized by the library module fam_shift_butterfly_network
  fam_shift_butterfly_network #(.W(8), .NETWORK(0), .STICKY(1)) u_m2_shifterLANE (.a(m2_sh_aLANE), .amt(m2_sh_amtLANE), .op(m2_sh_opLANE), .y(m2_sh_yLANE), .sticky());
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_sh_aLANE = 'x; m2_sh_amtLANE = 'x; m2_sh_opLANE = 'x; m2_o11ex0_LANE = 'x; m2_o12ex0_LANE = 'x; m2_o13ex0_LANE = 'x;
    case (op)
      5'd11: begin
        m2_sh_aLANE = m2_aLANE; m2_sh_amtLANE = 3'(m2_bLANE % 8'd8); m2_sh_opLANE = 3'd0;
        y_m2[((LANE*8)+0) +: 8] = m2_sh_yLANE;
      end
      5'd12: begin
        m2_sh_aLANE = m2_aLANE; m2_sh_amtLANE = 3'(m2_bLANE % 8'd8); m2_sh_opLANE = 3'd2;
        y_m2[((LANE*8)+0) +: 8] = m2_sh_yLANE;
      end
      5'd13: begin
        m2_sh_aLANE = m2_aLANE; m2_sh_amtLANE = 3'(m2_bLANE % 8'd8); m2_sh_opLANE = 3'd3;
        y_m2[((LANE*8)+0) +: 8] = m2_sh_yLANE;
      end
      default: ;
    endcase
  end
endmodule
// ADIR-MEMBER m0_l0_adder
// EVOLVE-BLOCK-START
module alu_core_u_pair_m0_l0 (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_pair_m0_l0: physical structure `pair_m0_l0` (kind adder, slot adder); realizes m0.l0.adder: adder, mode 0 lane 0, int16_twos_complement, ops add, sub, adc, neg, abs, add_sat, m0.l0.comparator: comparator, mode 0 lane 0, int16_twos_complement, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] pc_a_m0;
  logic [15:0] pc_b_m0;
  logic pc_cin_m0;
  logic [15:0] pc_s_m0;
  logic pc_co_m0;
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  logic [15:0] pc_a_m0_l0;
  logic [15:0] pc_b_m0_l0;
  logic pc_cin_m0_l0;
  logic pc_sel;
  logic [15:0] pc_a;
  logic [15:0] pc_b;
  logic pc_cin;
  logic [15:0] pc_s;
  logic pc_co;
  alu_core_m0_adder_comparator_sh #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0), .pc_a_m0(pc_a_m0_l0), .pc_b_m0(pc_b_m0_l0), .pc_cin_m0(pc_cin_m0_l0), .pc_s_m0(pc_s_m0), .pc_co_m0(pc_co_m0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
  assign pc_a_m0 = pc_a_m0_l0;
  assign pc_b_m0 = pc_b_m0_l0;
  assign pc_cin_m0 = pc_cin_m0_l0;
  assign pc_sel = (mode == 2'd0) ? 1'd0 : '0;
  assign pc_a = (mode == 2'd0) ? pc_a_m0 : '0;
  assign pc_b = (mode == 2'd0) ? pc_b_m0 : '0;
  assign pc_cin = (mode == 2'd0) ? pc_cin_m0 : '0;
  // subword partitioned_carry_chain: one library adder over the whole word, its carries cut at the selected packing's lane boundaries (1 x int16_twos_complement)
  fam_add_partitioned_w16_16_carry_kill_gate_5f03ce7bcff6 u_part (.a(pc_a), .b(pc_b), .cin(pc_cin), .sel(pc_sel), .s(pc_s), .cout(pc_co));
  assign pc_s_m0 = pc_s;
  assign pc_co_m0 = pc_co;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_multiplier: physical structure `m0.l0.multiplier` (kind multiplier, slot multiplier); realizes m0.l0.multiplier: multiplier, mode 0 lane 0, int16_twos_complement, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [31:0] tp_p_m0;
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  logic tp_sel;
  logic [31:0] tp_p;
  alu_core_m0_multiplier_sh #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0), .tp_p_m0(tp_p_m0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
  assign tp_sel = (mode == 2'd0) ? 1'd0 : '0;
  // structure core.multiplier: family twin_precision_subword realized by one library matrix over the packings 1 x int16_twos_complement
  fam_mul_twin_precision_w16_16s_mag_ff7a627b5d2a u_twin (.a(a), .b(b), .sel(tp_sel), .p(tp_p));
  assign tp_p_m0 = tp_p;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_comparator
// m0.l0.comparator: realized by the unit module in member m0_l0_adder
// ADIR-MEMBER m0_l0_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_shifter: physical structure `m0.l0.shifter` (kind shifter, slot shifter); realizes m0.l0.shifter: shifter, mode 0 lane 0, int16_twos_complement, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_shifter #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_logic
// EVOLVE-BLOCK-START
module alu_core_u_gate_rows_0 (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_gate_rows_0: physical structure `gate_rows_0` (kind logic, slot logic); realizes m0.l0.logic: logic, mode 0 lane 0, int16_twos_complement, ops and, or, xor, not, m1.l0.logic: logic, mode 1 lane 0, int16_unsigned, ops and, or, xor, not, m2.l0.logic: logic, mode 2 lane 0, int8_twos_complement, ops and, or, xor, not, m2.l1.logic: logic, mode 2 lane 1, int8_twos_complement, ops and, or, xor, not
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [1:0] lg_op;
  logic lg_en;
  logic [15:0] lg_y;
  assign lg_op = (op == 5'd14) ? 2'd0 : (op == 5'd15) ? 2'd1 : (op == 5'd16) ? 2'd2 : (op == 5'd17) ? 2'd3 : 2'd0;
  assign lg_en = (op == 5'd14) | (op == 5'd15) | (op == 5'd16) | (op == 5'd17);
  // structure core.logic: family wide_gate_row realized by one library gate row over the whole word (the packings 1 x int16_twos_complement, 1 x int16_unsigned, 2 x int8_twos_complement)
  fam_logic_gate_row #(.W(16), .NOT_VIA_XOR(0)) u_wide_row (.a(a), .b(b), .op(lg_op), .y(lg_y));
  assign y_m0 = lg_en ? lg_y[15:0] : '0;
  assign fl_m0 = '0;
  assign y_m1 = lg_en ? lg_y[15:0] : '0;
  assign fl_m1 = '0;
  assign y_m2 = lg_en ? lg_y[15:0] : '0;
  assign fl_m2 = '0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_bitcount: physical structure `m0.l0.bitcount` (kind bitcount, slot bitcount); realizes m0.l0.bitcount: bitcount, mode 0 lane 0, int16_twos_complement, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_bitcount #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_adder
// EVOLVE-BLOCK-START
module alu_core_u_pair_m1_l0 (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_pair_m1_l0: physical structure `pair_m1_l0` (kind adder, slot adder); realizes m1.l0.adder: adder, mode 1 lane 0, int16_unsigned, ops add, sub, adc, neg, abs, add_sat, m1.l0.comparator: comparator, mode 1 lane 0, int16_unsigned, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] pc_a_m1;
  logic [15:0] pc_b_m1;
  logic pc_cin_m1;
  logic [15:0] pc_s_m1;
  logic pc_co_m1;
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  logic [15:0] pc_a_m1_l0;
  logic [15:0] pc_b_m1_l0;
  logic pc_cin_m1_l0;
  logic pc_sel;
  logic [15:0] pc_a;
  logic [15:0] pc_b;
  logic pc_cin;
  logic [15:0] pc_s;
  logic pc_co;
  alu_core_m1_adder_comparator_sh #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0), .pc_a_m1(pc_a_m1_l0), .pc_b_m1(pc_b_m1_l0), .pc_cin_m1(pc_cin_m1_l0), .pc_s_m1(pc_s_m1), .pc_co_m1(pc_co_m1));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
  assign pc_a_m1 = pc_a_m1_l0;
  assign pc_b_m1 = pc_b_m1_l0;
  assign pc_cin_m1 = pc_cin_m1_l0;
  assign pc_sel = (mode == 2'd1) ? 1'd0 : '0;
  assign pc_a = (mode == 2'd1) ? pc_a_m1 : '0;
  assign pc_b = (mode == 2'd1) ? pc_b_m1 : '0;
  assign pc_cin = (mode == 2'd1) ? pc_cin_m1 : '0;
  // subword partitioned_carry_chain: one library adder over the whole word, its carries cut at the selected packing's lane boundaries (1 x int16_unsigned)
  fam_add_partitioned_w16_16_carry_kill_gate_0cc88441ac18 u_part (.a(pc_a), .b(pc_b), .cin(pc_cin), .sel(pc_sel), .s(pc_s), .cout(pc_co));
  assign pc_s_m1 = pc_s;
  assign pc_co_m1 = pc_co;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_multiplier: physical structure `m1.l0.multiplier` (kind multiplier, slot multiplier); realizes m1.l0.multiplier: multiplier, mode 1 lane 0, int16_unsigned, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_multiplier #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_comparator
// m1.l0.comparator: realized by the unit module in member m1_l0_adder
// ADIR-MEMBER m1_l0_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_shifter: physical structure `m1.l0.shifter` (kind shifter, slot shifter); realizes m1.l0.shifter: shifter, mode 1 lane 0, int16_unsigned, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_shifter #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_logic
// m1.l0.logic: realized by the unit module in member m0_l0_logic
// ADIR-MEMBER m1_l0_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_bitcount: physical structure `m1.l0.bitcount` (kind bitcount, slot bitcount); realizes m1.l0.bitcount: bitcount, mode 1 lane 0, int16_unsigned, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_bitcount #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_adder
// EVOLVE-BLOCK-START
module alu_core_u_pair_m2_l0 (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_pair_m2_l0: physical structure `pair_m2_l0` (kind adder, slot adder); realizes m2.l0.adder: adder, mode 2 lane 0, int8_twos_complement, ops add, sub, adc, neg, abs, add_sat, m2.l0.comparator: comparator, mode 2 lane 0, int8_twos_complement, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] pc_a_m2;
  logic [15:0] pc_b_m2;
  logic [1:0] pc_cin_m2;
  logic [15:0] pc_s_m2;
  logic [1:0] pc_co_m2;
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  logic [15:0] pc_a_m2_l0;
  logic [15:0] pc_b_m2_l0;
  logic [1:0] pc_cin_m2_l0;
  logic pc_sel;
  logic [15:0] pc_a;
  logic [15:0] pc_b;
  logic [1:0] pc_cin;
  logic [15:0] pc_s;
  logic [1:0] pc_co;
  alu_core_m2_adder_comparator_sh #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0), .pc_a_m2(pc_a_m2_l0), .pc_b_m2(pc_b_m2_l0), .pc_cin_m2(pc_cin_m2_l0), .pc_s_m2(pc_s_m2), .pc_co_m2(pc_co_m2));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
  assign pc_a_m2 = pc_a_m2_l0;
  assign pc_b_m2 = pc_b_m2_l0;
  assign pc_cin_m2 = pc_cin_m2_l0;
  assign pc_sel = (mode == 2'd2) ? 1'd0 : '0;
  assign pc_a = (mode == 2'd2) ? pc_a_m2 : '0;
  assign pc_b = (mode == 2'd2) ? pc_b_m2 : '0;
  assign pc_cin = (mode == 2'd2) ? pc_cin_m2 : '0;
  // subword partitioned_carry_chain: one library adder over the whole word, its carries cut at the selected packing's lane boundaries (2 x int8_twos_complement)
  fam_add_partitioned_w16_8_carry_kill_gate_0cc88441ac18 u_part (.a(pc_a), .b(pc_b), .cin(pc_cin), .sel(pc_sel), .s(pc_s), .cout(pc_co));
  assign pc_s_m2 = pc_s;
  assign pc_co_m2 = pc_co;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_adder
// EVOLVE-BLOCK-START
module alu_core_u_pair_m2_l1 (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_pair_m2_l1: physical structure `pair_m2_l1` (kind adder, slot adder); realizes m2.l1.adder: adder, mode 2 lane 1, int8_twos_complement, ops add, sub, adc, neg, abs, add_sat, m2.l1.comparator: comparator, mode 2 lane 1, int8_twos_complement, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] pc_a_m2;
  logic [15:0] pc_b_m2;
  logic [1:0] pc_cin_m2;
  logic [15:0] pc_s_m2;
  logic [1:0] pc_co_m2;
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  logic [15:0] pc_a_m2_l1;
  logic [15:0] pc_b_m2_l1;
  logic [1:0] pc_cin_m2_l1;
  logic pc_sel;
  logic [15:0] pc_a;
  logic [15:0] pc_b;
  logic [1:0] pc_cin;
  logic [15:0] pc_s;
  logic [1:0] pc_co;
  alu_core_m2_adder_comparator_sh #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1), .pc_a_m2(pc_a_m2_l1), .pc_b_m2(pc_b_m2_l1), .pc_cin_m2(pc_cin_m2_l1), .pc_s_m2(pc_s_m2), .pc_co_m2(pc_co_m2));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
  assign pc_a_m2 = pc_a_m2_l1;
  assign pc_b_m2 = pc_b_m2_l1;
  assign pc_cin_m2 = pc_cin_m2_l1;
  assign pc_sel = (mode == 2'd2) ? 1'd0 : '0;
  assign pc_a = (mode == 2'd2) ? pc_a_m2 : '0;
  assign pc_b = (mode == 2'd2) ? pc_b_m2 : '0;
  assign pc_cin = (mode == 2'd2) ? pc_cin_m2 : '0;
  // subword partitioned_carry_chain: one library adder over the whole word, its carries cut at the selected packing's lane boundaries (2 x int8_twos_complement)
  fam_add_partitioned_w16_8_carry_kill_gate_0cc88441ac18 u_part (.a(pc_a), .b(pc_b), .cin(pc_cin), .sel(pc_sel), .s(pc_s), .cout(pc_co));
  assign pc_s_m2 = pc_s;
  assign pc_co_m2 = pc_co;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_multiplier: physical structure `m2.l0.multiplier` (kind multiplier, slot multiplier); realizes m2.l0.multiplier: multiplier, mode 2 lane 0, int8_twos_complement, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_multiplier #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_multiplier: physical structure `m2.l1.multiplier` (kind multiplier, slot multiplier); realizes m2.l1.multiplier: multiplier, mode 2 lane 1, int8_twos_complement, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_multiplier #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_comparator
// m2.l0.comparator: realized by the unit module in member m2_l0_adder
// ADIR-MEMBER m2_l1_comparator
// m2.l1.comparator: realized by the unit module in member m2_l1_adder
// ADIR-MEMBER m2_l0_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_shifter: physical structure `m2.l0.shifter` (kind shifter, slot shifter); realizes m2.l0.shifter: shifter, mode 2 lane 0, int8_twos_complement, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_shifter #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_shifter: physical structure `m2.l1.shifter` (kind shifter, slot shifter); realizes m2.l1.shifter: shifter, mode 2 lane 1, int8_twos_complement, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_shifter #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_logic
// m2.l0.logic: realized by the unit module in member m0_l0_logic
// ADIR-MEMBER m2_l1_logic
// m2.l1.logic: realized by the unit module in member m0_l0_logic
// ADIR-MEMBER m2_l0_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_bitcount: physical structure `m2.l0.bitcount` (kind bitcount, slot bitcount); realizes m2.l0.bitcount: bitcount, mode 2 lane 0, int8_twos_complement, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_bitcount #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_bitcount: physical structure `m2.l1.bitcount` (kind bitcount, slot bitcount); realizes m2.l1.bitcount: bitcount, mode 2 lane 1, int8_twos_complement, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_bitcount #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER library
// ---- the family library modules the lane modules instantiate (chialu/targets/rtl/families; fixed text, replaced by editing the instances)
// partitioned_carry_chain (carry_kill_gate, ripple_carry segments of 16 bits): one adder for the lane packings 1 x 16, the carry cut at the selected mode's lane boundaries
module fam_add_partitioned_w16_16_carry_kill_gate_0cc88441ac18 (input logic [15:0] a, input logic [15:0] b, input logic [0:0] cin, input logic [0:0] sel, output logic [15:0] s, output logic [0:0] cout);
  logic [1:0] c;
  assign c[0] = cin[0];
  logic co0;
  fam_adder_ripple_carry #(.W(16), .CHUNK(1), .FORM(0)) u0 (.a(a[15:0]), .b(b[15:0]), .cin(c[0]), .s(s[15:0]), .cout(co0));
  assign cout[0] = co0;
  assign c[1] = co0;
endmodule


// partitioned_carry_chain (carry_kill_gate, carry_lookahead segments of 16 bits): one adder for the lane packings 1 x 16, the carry cut at the selected mode's lane boundaries
module fam_add_partitioned_w16_16_carry_kill_gate_5f03ce7bcff6 (input logic [15:0] a, input logic [15:0] b, input logic [0:0] cin, input logic [0:0] sel, output logic [15:0] s, output logic [0:0] cout);
  logic [1:0] c;
  assign c[0] = cin[0];
  logic co0;
  fam_adder_carry_lookahead #(.W(16), .G(2), .INTER(0), .LEVELS(1)) u0 (.a(a[15:0]), .b(b[15:0]), .cin(c[0]), .s(s[15:0]), .cout(co0));
  assign cout[0] = co0;
  assign c[1] = co0;
endmodule


// partitioned_carry_chain (carry_kill_gate, ripple_carry segments of 8 bits): one adder for the lane packings 2 x 8, the carry cut at the selected mode's lane boundaries
module fam_add_partitioned_w16_8_carry_kill_gate_0cc88441ac18 (input logic [15:0] a, input logic [15:0] b, input logic [1:0] cin, input logic [0:0] sel, output logic [15:0] s, output logic [1:0] cout);
  logic [2:0] c;
  assign c[0] = cin[0];
  logic co0;
  fam_adder_ripple_carry #(.W(8), .CHUNK(1), .FORM(0)) u0 (.a(a[7:0]), .b(b[7:0]), .cin(c[0]), .s(s[7:0]), .cout(co0));
  assign cout[0] = co0;
  logic bnd1; assign bnd1 = (sel == 1'd0);
  assign c[1] = (co0 & ~bnd1) | (cin[1] & bnd1);
  logic co1;
  fam_adder_ripple_carry #(.W(8), .CHUNK(1), .FORM(0)) u1 (.a(a[15:8]), .b(b[15:8]), .cin(c[1]), .s(s[15:8]), .cout(co1));
  assign cout[1] = co1;
  assign c[2] = co1;
endmodule




// -------------------------------------------------------------- carry_lookahead
// groups of G bits with a one-level lookahead inside the group (the carries of
// the group from its bit generates and propagates and the group carry-in); the
// group carries come from LEVELS levels of lookahead over the group generates
// and propagates (fam_adder_cla_level): rippled (INTER = 0), looked ahead
// (INTER = 1), or selected (INTER = 2: every group's sum is formed for both
// carry-ins and the rippled group carry selects it, the carry-select stage
// above lookahead blocks).
module fam_adder_carry_lookahead #(parameter int W = 16, parameter int G = 4, parameter int INTER = 0, parameter int LEVELS = 1)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  localparam int NG = (W + G - 1) / G;
  logic [W-1:0] g, p;
  assign g = a & b;
  assign p = a ^ b;
  logic [NG-1:0] gc;                  // the carry into each group
  logic [NG-1:0] GG, GP;              // group generate and propagate
  genvar k, i;
  generate
    for (k = 0; k < NG; k = k + 1) begin : grp
      localparam int LO = k * G;
      localparam int HI = (LO + G > W) ? W : LO + G;
      localparam int NB = HI - LO;
      // the group's generate and propagate from its bits
      logic [NB:0] lg, lp;
      assign lg[0] = 1'b0;
      assign lp[0] = 1'b1;
      for (i = 0; i < NB; i = i + 1) begin : acc
        assign lg[i+1] = g[LO+i] | (p[LO+i] & lg[i]);
        assign lp[i+1] = p[LO+i] & lp[i];
      end
      assign GG[k] = lg[NB];
      assign GP[k] = lp[NB];
      if (INTER == 2) begin : select
        // both sums of the group, selected by the group carry
        logic [NB-1:0] c0, c1;
        for (i = 0; i < NB; i = i + 1) begin : cc
          assign c0[i] = lg[i];
          assign c1[i] = lg[i] | lp[i];
          assign s[LO+i] = p[LO+i] ^ (gc[k] ? c1[i] : c0[i]);
        end
      end else begin : direct
        for (i = 0; i < NB; i = i + 1) begin : cc
          assign s[LO+i] = p[LO+i] ^ (lg[i] | (lp[i] & gc[k]));
        end
      end
    end
    begin : levels
      fam_adder_cla_level #(.N(NG), .G(G), .LEVELS(LEVELS), .INTER(INTER))
        u_lvl (.gg(GG), .gp(GP), .cin(cin), .c(gc), .cout(cout));
    end
  endgenerate
endmodule


// carry_skip: blocks [4, 4, 1] (uniform), 1 skip level, mux
module fam_adder_carry_skip_w9 (input logic [8:0] a, input logic [8:0] b, input logic cin, output logic [8:0] s, output logic cout);
  logic P0; assign P0 = &(a[3:0] ^ b[3:0]);
  logic P1; assign P1 = &(a[7:4] ^ b[7:4]);
  logic P2; assign P2 = &(a[8:8] ^ b[8:8]);
  logic [3:0] s0;
  logic co0;
  // block 0 (4 bits)
  fam_adder_carry_skip_w9_component_block_adder_adder_w4 u1 (.a(a[3:0]), .b(b[3:0]), .cin(cin), .s(s0), .cout(co0));
  assign s[3:0] = s0;
  logic bc0;
  assign bc0 = P0 ? cin : co0;
  logic [3:0] s1;
  logic co1;
  // block 1 (4 bits)
  fam_adder_carry_skip_w9_component_block_adder_adder_w4 u2 (.a(a[7:4]), .b(b[7:4]), .cin(bc0), .s(s1), .cout(co1));
  assign s[7:4] = s1;
  logic bc1;
  assign bc1 = P1 ? bc0 : co1;
  logic s2;
  logic co2;
  // block 2 (1 bits)
  fam_adder_carry_skip_w9_component_block_adder_adder_w1 u3 (.a(a[8:8]), .b(b[8:8]), .cin(bc1), .s(s2), .cout(co2));
  assign s[8:8] = s2;
  logic bc2;
  assign bc2 = P2 ? bc1 : co2;
  assign cout = bc2;
endmodule




module fam_adder_carry_skip_w9_component_block_adder_adder_w1(input wire [0:0] a, input wire [0:0] b, input wire [0:0] cin, output wire [0:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(1), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_carry_skip_w9_component_block_adder_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule



// ------------------------------------------------------------ the lookahead levels
// The carries into N elements from their generate and propagate pairs and a
// carry-in: LEVELS = 1 resolves the N elements flat, the element carries
// rippled (INTER = 0) or looked ahead (INTER = 1); LEVELS > 1 groups G
// elements into super-groups, resolves the super-group carries with the same
// structure one level up, and looks ahead inside every super-group.
module fam_adder_cla_level #(parameter int N = 4, parameter int G = 4, parameter int LEVELS = 1, parameter int INTER = 0)
  (input logic [N-1:0] gg, input logic [N-1:0] gp, input logic cin, output logic [N-1:0] c, output logic cout);
  genvar k, i;
  generate
    if (LEVELS <= 1 || N <= G) begin : flat
      if (INTER == 1) begin : lookahead
        for (k = 0; k < N; k = k + 1) begin : lg
          logic [k+1:0] t;
          assign t[0] = cin;
          for (i = 0; i <= k; i = i + 1) begin : tt
            assign t[i+1] = gg[i] | (gp[i] & t[i]);
          end
          assign c[k] = t[k];
          if (k == N - 1) begin : last
            assign cout = t[k+1];
          end
        end
      end else if (INTER == 2) begin : select
        logic [N:0] r;
        assign r[0] = cin;
        for (k = 0; k < N; k = k + 1) begin : rg
          assign r[k+1] = r[k] ? (gg[k] | gp[k]) : gg[k];
          assign c[k] = r[k];
        end
        assign cout = r[N];
      end else begin : ripple
        logic [N:0] r;
        assign r[0] = cin;
        for (k = 0; k < N; k = k + 1) begin : rg
          assign r[k+1] = gg[k] | (gp[k] & r[k]);
          assign c[k] = r[k];
        end
        assign cout = r[N];
      end
    end else begin : hier
      localparam int NS = (N + G - 1) / G;
      logic [NS-1:0] sgg, sgp, sc;
      for (k = 0; k < NS; k = k + 1) begin : sg
        localparam int LO = k * G;
        localparam int HI = (LO + G > N) ? N : LO + G;
        // the super-group's generate and propagate from its elements
        logic [HI-LO:0] lg, lp;
        assign lg[0] = 1'b0;
        assign lp[0] = 1'b1;
        for (i = 0; i < HI - LO; i = i + 1) begin : acc
          assign lg[i+1] = gg[LO+i] | (gp[LO+i] & lg[i]);
          assign lp[i+1] = gp[LO+i] & lp[i];
          // the lookahead carry into element LO+i from the super-group carry-in
          if (INTER == 2) begin : select
            assign c[LO+i] = sc[k] ? (lg[i] | lp[i]) : lg[i];
          end else begin : lookahead
            assign c[LO+i] = lg[i] | (lp[i] & sc[k]);
          end
        end
        assign sgg[k] = lg[HI-LO];
        assign sgp[k] = lp[HI-LO];
      end
      fam_adder_cla_level #(.N(NS), .G(G), .LEVELS(LEVELS - 1), .INTER(INTER))
        u_up (.gg(sgg), .gp(sgp), .cin(cin), .c(sc), .cout(cout));
    end
  endgenerate
endmodule

// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).
module fam_adder_ripple_carry #(parameter int W = 16, parameter int CHUNK = 1, parameter int FORM = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  localparam int BLOCKS = (W + CHUNK - 1) / CHUNK;
  logic [BLOCKS:0] block_carry;
  assign block_carry[0] = cin;
  for (genvar block_index = 0; block_index < BLOCKS; block_index = block_index + 1) begin : chunk
    localparam int LO = block_index * CHUNK;
    localparam int BW = LO + CHUNK > W ? W - LO : CHUNK;
    (* keep_hierarchy = "yes" *) fam_adder_ripple_chunk #(.W(BW), .FORM(FORM)) u_chunk(
      .a(a[LO +: BW]), .b(b[LO +: BW]), .cin(block_carry[block_index]),
      .s(s[LO +: BW]), .cout(block_carry[block_index+1]));
  end
  assign cout = block_carry[BLOCKS];
endmodule



module fam_adder_ripple_chunk #(parameter int W = 1, parameter int FORM = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  logic [W:0] c;
  assign c[0] = cin;
  genvar i;
  generate
    for (i = 0; i < W; i = i + 1) begin : fa
      if (FORM == 1) begin : two_ha
        wire s1 = a[i] ^ b[i];
        wire c1 = a[i] & b[i];
        wire c2 = s1 & c[i];
        assign s[i] = s1 ^ c[i];
        assign c[i+1] = c1 | c2;
      end else if (FORM == 2) begin : maj
        assign s[i] = a[i] ^ b[i] ^ c[i];
        assign c[i+1] = (a[i] & b[i]) | (a[i] & c[i]) | (b[i] & c[i]);
      end else if (FORM == 3) begin : muxc
        wire p = a[i] ^ b[i];
        assign s[i] = p ^ c[i];
        assign c[i+1] = p ? c[i] : a[i];
      end else begin : gp
        wire g = a[i] & b[i];
        wire p = a[i] ^ b[i];
        assign s[i] = p ^ c[i];
        assign c[i+1] = g | (p & c[i]);
      end
    end
  endgenerate
  assign cout = c[W];
endmodule

// The comparator family of chiALU realized in parametric SystemVerilog:
//   fam_cmp_prefix_comparator #(W, SIGNED, STRUCTURE, RADIX) (input [W-1:0] a, b, output lt, eq)
// The subtractor form (subtractor_comparator) is generated by families/comparator.py around
// the adder of its `subtractor` slot.

// ------------------------------------------------------------ prefix_comparator
// STRUCTURE: 0 msb_first_prefix (a scan from the msb over groups of RADIX bits:
// each group gives (equal, less) flat, the groups are chained msb first), 1
// tree_reduction (a balanced tree of RADIX-ary nodes over the (equal, less)
// pairs). SIGNED flips the sign bits. RADIX is the bits a scan step groups, or
// the arity of a tree node.
module fam_cmp_prefix_comparator #(parameter int W = 16, parameter int SIGNED = 1, parameter int STRUCTURE = 0, parameter int RADIX = 2)
  (input logic [W-1:0] a, input logic [W-1:0] b, output logic lt, output logic eq);
  localparam int R = (RADIX < 2) ? 2 : RADIX;
  localparam int NG = (W + R - 1) / R;                 // the groups of R bits, group g at [g*R +: R] from the lsb
  // ceil(log_r n): the levels of an r-ary tree over n entries
  function automatic int clogr(input int n, input int r);
    int l, p;
    l = 0; p = 1;
    while (p < n) begin p = p * r; l = l + 1; end
    return l;
  endfunction
  // ceil(n / r^l): the entries of level l
  function automatic int entries(input int n, input int r, input int l);
    int m, i;
    m = n;
    for (i = 0; i < l; i = i + 1) m = (m + r - 1) / r;
    return m;
  endfunction
  logic [W-1:0] ax, bx;
  // a signed compare is an unsigned one with the sign bits inverted
  assign ax = {a[W-1] ^ (SIGNED != 0), a[W-2:0]};
  assign bx = {b[W-1] ^ (SIGNED != 0), b[W-2:0]};
  // per bit: equal, less
  logic [W-1:0] e0, l0;
  genvar i, g, l, k;
  generate
    for (i = 0; i < W; i = i + 1) begin : bit_
      assign e0[i] = (ax[i] == bx[i]);
      assign l0[i] = ~ax[i] & bx[i];
    end
    // per group of R bits (flat): equal = every bit equal; less = the first unequal bit from the top is less
    logic [NG-1:0] eg, lg;
    for (g = 0; g < NG; g = g + 1) begin : grp
      localparam int LO = g * R;
      localparam int HI = (LO + R - 1 < W - 1) ? LO + R - 1 : W - 1;
      localparam int N = HI - LO + 1;
      logic [N-1:0] ge, gl;
      assign ge = e0[HI:LO];
      assign gl = l0[HI:LO];
      assign eg[g] = &ge;
      logic [N-1:0] t;
      for (k = 0; k < N; k = k + 1) begin : tk
        // bit LO+k decides when the bits above it in the group are equal
        if (k == N - 1) begin : top
          assign t[k] = gl[k];
        end else begin : low
          assign t[k] = gl[k] & (&ge[N-1:k+1]);
        end
      end
      assign lg[g] = |t;
    end
    if (STRUCTURE == 0) begin : msb_first
      // the scan from the msb group down: e[g]: groups NG-1..g equal; ls[g]: a < b decided within them
      logic [NG:0] e, ls;
      assign e[NG] = 1'b1;
      assign ls[NG] = 1'b0;
      for (g = NG - 1; g >= 0; g = g - 1) begin : scan
        assign e[g] = e[g+1] & eg[g];
        assign ls[g] = ls[g+1] | (e[g+1] & lg[g]);
      end
      assign lt = ls[0];
      assign eq = e[0];
    end else begin : tree
      // a balanced R-ary tree over the group pairs: a node's (equal, less) from its children
      // (child c is more significant than child c-1): equal = AND of the children's equal, less =
      // OR over c of (less_c AND the children above c equal); level l holds ceil(NG / R^l) entries
      localparam int LV = (NG <= 1) ? 1 : clogr(NG, R);
      logic [NG-1:0] E [0:LV];
      logic [NG-1:0] LT [0:LV];
      assign E[0] = eg;
      assign LT[0] = lg;
      for (l = 0; l < LV; l = l + 1) begin : lvl
        localparam int MIN = entries(NG, R, l);       // the entries of the level below
        for (g = 0; g < NG; g = g + 1) begin : node
          if (g * R < MIN) begin : real_
            logic [R-1:0] ce, cl;
            for (k = 0; k < R; k = k + 1) begin : ck
              if (g * R + k < MIN) begin : in_
                assign ce[k] = E[l][g*R + k];
                assign cl[k] = LT[l][g*R + k];
              end else begin : pad
                assign ce[k] = 1'b1;
                assign cl[k] = 1'b0;
              end
            end
            assign E[l+1][g] = &ce;
            logic [R-1:0] t;
            for (k = 0; k < R; k = k + 1) begin : tk
              if (k == R - 1) begin : top
                assign t[k] = cl[k];
              end else begin : low
                assign t[k] = cl[k] & (&ce[R-1:k+1]);
              end
            end
            assign LT[l+1][g] = |t;
          end else begin : pad
            assign E[l+1][g] = 1'b1;
            assign LT[l+1][g] = 1'b0;
          end
        end
      end
      assign lt = LT[LV][0];
      assign eq = E[LV][0];
    end
  endgenerate
endmodule


// subtractor_comparator (ripple_carry, sum_or_tree, signed): a - b through the adder's carry-out, the sum path unused
module fam_cmp_subtractor_ripple_carry_p44ebdeaac57043a730d4d7405bd3a8a7932872aa358ca2f3675dab0ea6d5d1f5_sum_or_tree_s_w8 (input logic [7:0] a, input logic [7:0] b, output logic lt, output logic eq);
  logic [7:0] ax, bx, nb, s;
  logic co;
  assign ax = {a[7] ^ 1'b1, a[6:0]};
  assign bx = {b[7] ^ 1'b1, b[6:0]};
  assign nb = ~bx;
  // the subtractor: the adder (ripple_carry) on a and ~b with a carry in; no carry out means a < b
  fam_adder_ripple_carry #(.W(8), .CHUNK(1), .FORM(0)) u_sub (.a(ax), .b(nb), .cin(1'b1), .s(s), .cout(co));
  assign lt = ~co;
  assign eq = (s == '0);       // the difference is zero
endmodule


// popcount_counter_tree (balanced_tree, compressor_4_2, adders prefix_synthesis_nonuniform_arrival): the count of the ones of a 8-bit word
module fam_count_popcount_balanced_tree_compressor_4_2_prefix_synthesis_nonuniform_arrival_p453cf_w8 (input logic [7:0] a, output logic [3:0] n);
  logic g0_s1; assign g0_s1 = a[0] ^ a[1] ^ a[2];
  logic g0_c2; assign g0_c2 = (a[0] & a[1]) | (a[0] & a[2]) | (a[1] & a[2]);
  logic g0_s3; assign g0_s3 = g0_s1 ^ a[3];
  logic g0_c4; assign g0_c4 = g0_s1 & a[3];
  logic g0_s5; assign g0_s5 = g0_c2 ^ g0_c4;
  logic g0_c6; assign g0_c6 = g0_c2 & g0_c4;
  logic [2:0] gc0; assign gc0 = {g0_c6, g0_s5, g0_s3};
  logic g1_s7; assign g1_s7 = a[4] ^ a[5] ^ a[6];
  logic g1_c8; assign g1_c8 = (a[4] & a[5]) | (a[4] & a[6]) | (a[5] & a[6]);
  logic g1_s9; assign g1_s9 = g1_s7 ^ a[7];
  logic g1_c10; assign g1_c10 = g1_s7 & a[7];
  logic g1_s11; assign g1_s11 = g1_c8 ^ g1_c10;
  logic g1_c12; assign g1_c12 = g1_c8 & g1_c10;
  logic [2:0] gc1; assign gc1 = {g1_c12, g1_s11, g1_s9};
  logic [2:0] s1;
  logic co1;
  // count adder 1 (prefix_synthesis_nonuniform_arrival, 3 bits)
  fam_prefix_arrival_0_1_1_w3 u1 (.a(gc0), .b(gc1), .cin(1'b0), .s(s1), .cout(co1));
  logic [3:0] t1; assign t1 = {co1, s1};
  assign n = t1[3:0];
endmodule

// priority_encoder (groups of 8, 2 lookahead levels, one_hot_then_encode): the leading zeros of a 16-bit word
module fam_count_priority_encoder_g8_l2_one_hot_then_encode_w16 (input logic [15:0] a, output logic [4:0] n);
  logic any0; assign any0 = a[15] | a[14] | a[13] | a[12] | a[11] | a[10] | a[9] | a[8];
  logic any1; assign any1 = a[7] | a[6] | a[5] | a[4] | a[3] | a[2] | a[1] | a[0];
  logic any2_0; assign any2_0 = any0 | any1;
  logic kg0; assign kg0 = 1'b0;
  logic kg1; assign kg1 = any0;
  logic fg0; assign fg0 = any0 & ~kg0;
  logic fg1; assign fg1 = any1 & ~kg1;
  logic kb0; assign kb0 = 1'b0;
  logic oh0; assign oh0 = a[15] & ~kb0 & fg0;
  logic kc0; assign kc0 = kb0 | a[15];
  logic kb1; assign kb1 = kc0;
  logic oh1; assign oh1 = a[14] & ~kb1 & fg0;
  logic kc1; assign kc1 = kb1 | a[14];
  logic kb2; assign kb2 = kc1;
  logic oh2; assign oh2 = a[13] & ~kb2 & fg0;
  logic kc2; assign kc2 = kb2 | a[13];
  logic kb3; assign kb3 = kc2;
  logic oh3; assign oh3 = a[12] & ~kb3 & fg0;
  logic kc3; assign kc3 = kb3 | a[12];
  logic kb4; assign kb4 = kc3;
  logic oh4; assign oh4 = a[11] & ~kb4 & fg0;
  logic kc4; assign kc4 = kb4 | a[11];
  logic kb5; assign kb5 = kc4;
  logic oh5; assign oh5 = a[10] & ~kb5 & fg0;
  logic kc5; assign kc5 = kb5 | a[10];
  logic kb6; assign kb6 = kc5;
  logic oh6; assign oh6 = a[9] & ~kb6 & fg0;
  logic kc6; assign kc6 = kb6 | a[9];
  logic kb7; assign kb7 = kc6;
  logic oh7; assign oh7 = a[8] & ~kb7 & fg0;
  logic kc7; assign kc7 = kb7 | a[8];
  logic kb8; assign kb8 = 1'b0;
  logic oh8; assign oh8 = a[7] & ~kb8 & fg1;
  logic kc8; assign kc8 = kb8 | a[7];
  logic kb9; assign kb9 = kc8;
  logic oh9; assign oh9 = a[6] & ~kb9 & fg1;
  logic kc9; assign kc9 = kb9 | a[6];
  logic kb10; assign kb10 = kc9;
  logic oh10; assign oh10 = a[5] & ~kb10 & fg1;
  logic kc10; assign kc10 = kb10 | a[5];
  logic kb11; assign kb11 = kc10;
  logic oh11; assign oh11 = a[4] & ~kb11 & fg1;
  logic kc11; assign kc11 = kb11 | a[4];
  logic kb12; assign kb12 = kc11;
  logic oh12; assign oh12 = a[3] & ~kb12 & fg1;
  logic kc12; assign kc12 = kb12 | a[3];
  logic kb13; assign kb13 = kc12;
  logic oh13; assign oh13 = a[2] & ~kb13 & fg1;
  logic kc13; assign kc13 = kb13 | a[2];
  logic kb14; assign kb14 = kc13;
  logic oh14; assign oh14 = a[1] & ~kb14 & fg1;
  logic kc14; assign kc14 = kb14 | a[1];
  logic kb15; assign kb15 = kc14;
  logic oh15; assign oh15 = a[0] & ~kb15 & fg1;
  logic kc15; assign kc15 = kb15 | a[0];
  logic v; assign v = any0 | any1;
  logic [4:0] enc;
  // the one-hot leading-one vector encoded to the count
  assign enc[0] = oh1 | oh3 | oh5 | oh7 | oh9 | oh11 | oh13 | oh15;
  assign enc[1] = oh2 | oh3 | oh6 | oh7 | oh10 | oh11 | oh14 | oh15;
  assign enc[2] = oh4 | oh5 | oh6 | oh7 | oh12 | oh13 | oh14 | oh15;
  assign enc[3] = oh8 | oh9 | oh10 | oh11 | oh12 | oh13 | oh14 | oh15;
  assign enc[4] = 1'b0;
  assign n = v ? enc : 5'd16;
endmodule


// trailing_zero (debruijn_multiply_index, twos_complement_and): the lowest one isolated and encoded
module fam_count_tzc_debruijn_multiply_index_twos_complement_and_pe7180_w16 (input logic [15:0] a, output logic [4:0] n);
  logic [15:0] low;
  logic [15:0] na; assign na = ~a;
  logic [15:0] neg;
  // -a = ~a + 1 through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(16), .STRUCTURE(0), .B(4), .TOPO(0)) u1 (.a(na), .cin(1'b1), .s(neg), .cout());
  assign low = a & neg;
  logic [15:0] prod; assign prod = low * 16'd3941;
  logic [3:0] idx; assign idx = prod[15:12];
  logic [4:0] enc;
  // the de Bruijn index table (4 bits, constant 16'd3941)
  always_comb begin case (idx)
    4'd0: enc = 5'd0;
    4'd1: enc = 5'd1;
    4'd2: enc = 5'd11;
    4'd3: enc = 5'd2;
    4'd4: enc = 5'd14;
    4'd5: enc = 5'd12;
    4'd6: enc = 5'd8;
    4'd7: enc = 5'd3;
    4'd8: enc = 5'd15;
    4'd9: enc = 5'd10;
    4'd10: enc = 5'd13;
    4'd11: enc = 5'd7;
    4'd12: enc = 5'd9;
    4'd13: enc = 5'd6;
    4'd14: enc = 5'd5;
    4'd15: enc = 5'd4;
    default: enc = 5'd0;
  endcase end
  assign n = (low == 16'd0) ? 5'd16 : enc;
endmodule




// ------------------------------------------------------------ prefix_and_incrementer
// s = a + cin: the carry into bit i is cin AND every lower bit, a prefix AND
// (STRUCTURE 0 a ripple AND chain, 1 a prefix AND tree of topology TOPO, 2
// select blocks of B bits whose block carry is the AND of the block)
module fam_incr_prefix_and #(parameter int W = 16, parameter int STRUCTURE = 1, parameter int B = 4, parameter int TOPO = 0)
  (input logic [W-1:0] a, input logic cin, output logic [W-1:0] s, output logic cout);
  // STRUCTURE: 0 ripple_and_chain, 1 prefix_and_tree (TOPO: 0 sklansky, 1 brent_kung, 2 kogge_stone),
  // 2 select_blocks of B bits
  logic [W:0] c;
  assign c[0] = cin;
  genvar i, l;
  generate
    if (STRUCTURE == 0) begin : ripple
      for (i = 0; i < W; i = i + 1) begin : ch
        assign c[i+1] = c[i] & a[i];
      end
    end else if (STRUCTURE == 1) begin : tree
      localparam int L = (W <= 1) ? 1 : $clog2(W);
      if (TOPO == 2) begin : kogge_stone
        // p[l][i]: AND of a[i] down to a[i - 2^l + 1]
        logic [W-1:0] p [0:L];
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : lvl
          for (i = 0; i < W; i = i + 1) begin : pos
            if (i >= (1 << l)) begin : comb
              assign p[l+1][i] = p[l][i] & p[l][i - (1 << l)];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[L][i];
        end
      end else if (TOPO == 1) begin : brent_kung
        // an up-sweep over the odd positions of each level, then a down-sweep filling the rest
        logic [W-1:0] p [0:2*L];
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : up
          for (i = 0; i < W; i = i + 1) begin : pos
            if (((i + 1) % (2 << l)) == 0) begin : comb
              assign p[l+1][i] = p[l][i] & p[l][i - (1 << l)];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (l = 0; l < L; l = l + 1) begin : down
          localparam int D = 1 << (L - 1 - l);
          for (i = 0; i < W; i = i + 1) begin : pos
            if (((i + 1) % (2 * D)) == D && (i + 1) > D) begin : comb
              assign p[L+l+1][i] = p[L+l][i] & p[L+l][i - D];
            end else begin : keep
              assign p[L+l+1][i] = p[L+l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[2*L][i];
        end
      end else begin : sklansky
        logic [W-1:0] p [0:L];           // p[l][i]: AND of a[i] down to a[i - 2^l + 1]
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : lvl
          for (i = 0; i < W; i = i + 1) begin : pos
            if ((i / (1 << l)) % 2 == 1) begin : comb   // the upper half of every block takes the lower half's end
              assign p[l+1][i] = p[l][i] & p[l][(i / (1 << l)) * (1 << l) - 1];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[L][i];
        end
      end
    end else begin : blocks
      localparam int NB = (W + B - 1) / B;
      logic [NB:0] bc;                  // the carry into each block
      assign bc[0] = cin;
      for (i = 0; i < NB; i = i + 1) begin : blk
        localparam int LO = i * B;
        localparam int HI = (LO + B - 1 < W - 1) ? LO + B - 1 : W - 1;
        logic all1;
        assign all1 = &a[HI:LO];
        assign bc[i+1] = bc[i] & all1;
        genvar j;
        for (j = LO; j <= HI; j = j + 1) begin : bit_
          if (j == LO) begin : first
            assign c[j+1] = bc[i] & a[j];
          end else begin : rest
            assign c[j+1] = c[j] & a[j];
          end
        end
      end
    end
  endgenerate
  assign s = a ^ c[W-1:0];
  assign cout = c[W];
endmodule


// The logic family library: the bitwise gate row of lane_replicated_gates and wide_gate_row.
//   fam_logic_gate_row #(W, NOT_VIA_XOR) (input [W-1:0] a, b, input [1:0] op, output [W-1:0] y)
//   op: 0 and, 1 or, 2 xor, 3 not (of a)
// NOT_VIA_XOR = 1 forms the not as a xor with ones, so the row is three gate types and a
// two-way operand select instead of four gate types under a four-way result mux.
module fam_logic_gate_row #(parameter int W = 16, parameter int NOT_VIA_XOR = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic [1:0] op, output logic [W-1:0] y);
  generate
    if (NOT_VIA_XOR) begin : via_xor
      logic [W-1:0] bx;
      assign bx = (op == 2'd3) ? {W{1'b1}} : b;
      assign y = (op == 2'd0) ? (a & b) : (op == 2'd1) ? (a | b) : (a ^ bx);
    end else begin : plain
      assign y = (op == 2'd0) ? (a & b) : (op == 2'd1) ? (a | b) : (op == 2'd2) ? (a ^ b) : ~a;
    end
  endgenerate
endmodule



module fam_mul_direct_dadda_3_2_w9_s_p812bf641 (input logic [8:0] a, input logic [8:0] b, output logic [17:0] p);
  // direct_pp_parallel: {'pp_bits': 59, 'full_adders': 24, 'half_adders': 8, 'cells': 0, 'tree_depth': 3}
  logic sel0, sel1, sel2, pp3, pp4, pp5, pp6, pp7, pp8, pp9, pp10, pp11, pp12, pp13, sel14, sel15, sel16, pp17, pp18, pp19, pp20, pp21, pp22, pp23, pp24, pp25, pp26, pp27, sel28, sel29, sel30, pp31, pp32, pp33, pp34, pp35, pp36, pp37, pp38, pp39, pp40, pp41, sel42, sel43, sel44, pp45, pp46, pp47, pp48, pp49, pp50, pp51, pp52, pp53, pp54, pp55, sel56, sel57, sel58, pp59, pp60, pp61, pp62, pp63, pp64, pp65, pp66, pp67, pp68, pp69, ns70, ns71, ns72, ns73, t74, t75, t76, t77, t78, t79, t80, t81, t82, t83, t84, t85, t86, t87, t88, t89, t90, t91, t92, t93, t94, t95, t96, t97, t98, t99, t100, t101, t102, t103, t104, t105, t106, t107, t108, t109, t110, t111, t112, t113, t114, t115, t116, t117, t118, t119, t120, t121, t122, t123, t124, t125, t126, t127, t128, t129, t130, t131, t132, t133, t134, t135, t136, t137;
  logic [10:0] a_ext;
  logic [10:0] m2;
  logic [10:0] m3; logic m3_co;
  // the hard multiple 3a = 2a + a through the adder (compound_flagged_prefix)
  fam_prefix_harris_l0f1_w11_flagm_late u_i1 (.a(m2), .b(a_ext), .cin(1'b0), .s(m3), .cout(m3_co));
  assign a_ext = {{2{a[8]}}, a};
  assign sel0 = b[0] & ~b[1];
  assign sel1 = ~b[0] & b[1];
  assign sel2 = b[0] & b[1];
  assign m2 = {a_ext[9:0], 1'd0};
  assign pp3 = (sel0 & a_ext[0]) | (sel1 & m2[0]) | (sel2 & m3[0]);
  assign pp4 = (sel0 & a_ext[1]) | (sel1 & m2[1]) | (sel2 & m3[1]);
  assign pp5 = (sel0 & a_ext[2]) | (sel1 & m2[2]) | (sel2 & m3[2]);
  assign pp6 = (sel0 & a_ext[3]) | (sel1 & m2[3]) | (sel2 & m3[3]);
  assign pp7 = (sel0 & a_ext[4]) | (sel1 & m2[4]) | (sel2 & m3[4]);
  assign pp8 = (sel0 & a_ext[5]) | (sel1 & m2[5]) | (sel2 & m3[5]);
  assign pp9 = (sel0 & a_ext[6]) | (sel1 & m2[6]) | (sel2 & m3[6]);
  assign pp10 = (sel0 & a_ext[7]) | (sel1 & m2[7]) | (sel2 & m3[7]);
  assign pp11 = (sel0 & a_ext[8]) | (sel1 & m2[8]) | (sel2 & m3[8]);
  assign pp12 = (sel0 & a_ext[9]) | (sel1 & m2[9]) | (sel2 & m3[9]);
  assign pp13 = (sel0 & a_ext[10]) | (sel1 & m2[10]) | (sel2 & m3[10]);
  assign sel14 = b[2] & ~b[3];
  assign sel15 = ~b[2] & b[3];
  assign sel16 = b[2] & b[3];
  assign pp17 = (sel14 & a_ext[0]) | (sel15 & m2[0]) | (sel16 & m3[0]);
  assign pp18 = (sel14 & a_ext[1]) | (sel15 & m2[1]) | (sel16 & m3[1]);
  assign pp19 = (sel14 & a_ext[2]) | (sel15 & m2[2]) | (sel16 & m3[2]);
  assign pp20 = (sel14 & a_ext[3]) | (sel15 & m2[3]) | (sel16 & m3[3]);
  assign pp21 = (sel14 & a_ext[4]) | (sel15 & m2[4]) | (sel16 & m3[4]);
  assign pp22 = (sel14 & a_ext[5]) | (sel15 & m2[5]) | (sel16 & m3[5]);
  assign pp23 = (sel14 & a_ext[6]) | (sel15 & m2[6]) | (sel16 & m3[6]);
  assign pp24 = (sel14 & a_ext[7]) | (sel15 & m2[7]) | (sel16 & m3[7]);
  assign pp25 = (sel14 & a_ext[8]) | (sel15 & m2[8]) | (sel16 & m3[8]);
  assign pp26 = (sel14 & a_ext[9]) | (sel15 & m2[9]) | (sel16 & m3[9]);
  assign pp27 = (sel14 & a_ext[10]) | (sel15 & m2[10]) | (sel16 & m3[10]);
  assign sel28 = b[4] & ~b[5];
  assign sel29 = ~b[4] & b[5];
  assign sel30 = b[4] & b[5];
  assign pp31 = (sel28 & a_ext[0]) | (sel29 & m2[0]) | (sel30 & m3[0]);
  assign pp32 = (sel28 & a_ext[1]) | (sel29 & m2[1]) | (sel30 & m3[1]);
  assign pp33 = (sel28 & a_ext[2]) | (sel29 & m2[2]) | (sel30 & m3[2]);
  assign pp34 = (sel28 & a_ext[3]) | (sel29 & m2[3]) | (sel30 & m3[3]);
  assign pp35 = (sel28 & a_ext[4]) | (sel29 & m2[4]) | (sel30 & m3[4]);
  assign pp36 = (sel28 & a_ext[5]) | (sel29 & m2[5]) | (sel30 & m3[5]);
  assign pp37 = (sel28 & a_ext[6]) | (sel29 & m2[6]) | (sel30 & m3[6]);
  assign pp38 = (sel28 & a_ext[7]) | (sel29 & m2[7]) | (sel30 & m3[7]);
  assign pp39 = (sel28 & a_ext[8]) | (sel29 & m2[8]) | (sel30 & m3[8]);
  assign pp40 = (sel28 & a_ext[9]) | (sel29 & m2[9]) | (sel30 & m3[9]);
  assign pp41 = (sel28 & a_ext[10]) | (sel29 & m2[10]) | (sel30 & m3[10]);
  assign sel42 = b[6] & ~b[7];
  assign sel43 = ~b[6] & b[7];
  assign sel44 = b[6] & b[7];
  assign pp45 = (sel42 & a_ext[0]) | (sel43 & m2[0]) | (sel44 & m3[0]);
  assign pp46 = (sel42 & a_ext[1]) | (sel43 & m2[1]) | (sel44 & m3[1]);
  assign pp47 = (sel42 & a_ext[2]) | (sel43 & m2[2]) | (sel44 & m3[2]);
  assign pp48 = (sel42 & a_ext[3]) | (sel43 & m2[3]) | (sel44 & m3[3]);
  assign pp49 = (sel42 & a_ext[4]) | (sel43 & m2[4]) | (sel44 & m3[4]);
  assign pp50 = (sel42 & a_ext[5]) | (sel43 & m2[5]) | (sel44 & m3[5]);
  assign pp51 = (sel42 & a_ext[6]) | (sel43 & m2[6]) | (sel44 & m3[6]);
  assign pp52 = (sel42 & a_ext[7]) | (sel43 & m2[7]) | (sel44 & m3[7]);
  assign pp53 = (sel42 & a_ext[8]) | (sel43 & m2[8]) | (sel44 & m3[8]);
  assign pp54 = (sel42 & a_ext[9]) | (sel43 & m2[9]) | (sel44 & m3[9]);
  assign pp55 = (sel42 & a_ext[10]) | (sel43 & m2[10]) | (sel44 & m3[10]);
  assign sel56 = b[8] & ~b[8];
  assign sel57 = ~b[8] & b[8];
  assign sel58 = b[8] & b[8];
  assign pp59 = (sel56 & a_ext[0]) | (sel57 & m2[0]) | (sel58 & m3[0]);
  assign pp60 = (sel56 & a_ext[1]) | (sel57 & m2[1]) | (sel58 & m3[1]);
  assign pp61 = (sel56 & a_ext[2]) | (sel57 & m2[2]) | (sel58 & m3[2]);
  assign pp62 = (sel56 & a_ext[3]) | (sel57 & m2[3]) | (sel58 & m3[3]);
  assign pp63 = (sel56 & a_ext[4]) | (sel57 & m2[4]) | (sel58 & m3[4]);
  assign pp64 = (sel56 & a_ext[5]) | (sel57 & m2[5]) | (sel58 & m3[5]);
  assign pp65 = (sel56 & a_ext[6]) | (sel57 & m2[6]) | (sel58 & m3[6]);
  assign pp66 = (sel56 & a_ext[7]) | (sel57 & m2[7]) | (sel58 & m3[7]);
  assign pp67 = (sel56 & a_ext[8]) | (sel57 & m2[8]) | (sel58 & m3[8]);
  assign pp68 = (sel56 & a_ext[9]) | (sel57 & m2[9]) | (sel58 & m3[9]);
  assign pp69 = (sel56 & a_ext[10]) | (sel57 & m2[10]) | (sel58 & m3[10]);
  assign ns70 = ~pp13;
  assign ns71 = ~pp27;
  assign ns72 = ~pp41;
  assign ns73 = ~pp55;
  assign t74 = pp11 ^ pp23;
  assign t75 = pp11 & pp23;
  assign t76 = pp12 ^ pp24 ^ pp36;
  assign t77 = (pp12 & pp24) | (pp12 & pp36) | (pp24 & pp36);
  assign t78 = ns70 ^ pp25 ^ pp37;
  assign t79 = (ns70 & pp25) | (ns70 & pp37) | (pp25 & pp37);
  assign t80 = pp49 ^ pp61;
  assign t81 = pp49 & pp61;
  assign t82 = pp26 ^ pp38 ^ pp50;
  assign t83 = (pp26 & pp38) | (pp26 & pp50) | (pp38 & pp50);
  assign t84 = pp62 ^ 1'b1;
  assign t85 = pp62 & 1'b1;
  assign t86 = ns71 ^ pp39 ^ pp51;
  assign t87 = (ns71 & pp39) | (ns71 & pp51) | (pp39 & pp51);
  assign t88 = pp40 ^ pp52;
  assign t89 = pp40 & pp52;
  assign t90 = pp9 ^ pp21;
  assign t91 = pp9 & pp21;
  assign t92 = pp10 ^ pp22 ^ pp34;
  assign t93 = (pp10 & pp22) | (pp10 & pp34) | (pp22 & pp34);
  assign t94 = pp35 ^ pp47 ^ pp59;
  assign t95 = (pp35 & pp47) | (pp35 & pp59) | (pp47 & pp59);
  assign t96 = pp48 ^ pp60 ^ t75;
  assign t97 = (pp48 & pp60) | (pp48 & t75) | (pp60 & t75);
  assign t98 = 1'b1 ^ t77 ^ t78;
  assign t99 = (1'b1 & t77) | (1'b1 & t78) | (t77 & t78);
  assign t100 = t79 ^ t81 ^ t82;
  assign t101 = (t79 & t81) | (t79 & t82) | (t81 & t82);
  assign t102 = pp63 ^ t83 ^ t85;
  assign t103 = (pp63 & t83) | (pp63 & t85) | (t83 & t85);
  assign t104 = pp64 ^ 1'b1 ^ t87;
  assign t105 = (pp64 & 1'b1) | (pp64 & t87) | (1'b1 & t87);
  assign t106 = ns72 ^ pp53 ^ pp65;
  assign t107 = (ns72 & pp53) | (ns72 & pp65) | (pp53 & pp65);
  assign t108 = pp54 ^ pp66;
  assign t109 = pp54 & pp66;
  assign t110 = pp7 ^ pp19;
  assign t111 = pp7 & pp19;
  assign t112 = pp8 ^ pp20 ^ pp32;
  assign t113 = (pp8 & pp20) | (pp8 & pp32) | (pp20 & pp32);
  assign t114 = pp33 ^ pp45 ^ t90;
  assign t115 = (pp33 & pp45) | (pp33 & t90) | (pp45 & t90);
  assign t116 = pp46 ^ t91 ^ t92;
  assign t117 = (pp46 & t91) | (pp46 & t92) | (t91 & t92);
  assign t118 = t74 ^ t93 ^ t94;
  assign t119 = (t74 & t93) | (t74 & t94) | (t93 & t94);
  assign t120 = t76 ^ t95 ^ t96;
  assign t121 = (t76 & t95) | (t76 & t96) | (t95 & t96);
  assign t122 = t80 ^ t97 ^ t98;
  assign t123 = (t80 & t97) | (t80 & t98) | (t97 & t98);
  assign t124 = t84 ^ t99 ^ t100;
  assign t125 = (t84 & t99) | (t84 & t100) | (t99 & t100);
  assign t126 = t86 ^ t101 ^ t102;
  assign t127 = (t86 & t101) | (t86 & t102) | (t101 & t102);
  assign t128 = t88 ^ t103 ^ t104;
  assign t129 = (t88 & t103) | (t88 & t104) | (t103 & t104);
  assign t130 = t89 ^ t105 ^ t106;
  assign t131 = (t89 & t105) | (t89 & t106) | (t105 & t106);
  assign t132 = 1'b1 ^ t107 ^ t108;
  assign t133 = (1'b1 & t107) | (1'b1 & t108) | (t107 & t108);
  assign t134 = ns73 ^ pp67 ^ t109;
  assign t135 = (ns73 & pp67) | (ns73 & t109) | (pp67 & t109);
  assign t136 = pp68 ^ 1'b1;
  assign t137 = pp68 & 1'b1;
  logic [17:0] row_s, row_c;
  assign row_s = {t135, t133, t131, t129, t127, t125, t123, t121, t119, t117, t115, t113, t111, pp31, pp6, pp5, pp4, pp3};
  assign row_c = {t136, t134, t132, t130, t128, t126, t124, t122, t120, t118, t116, t114, t112, t110, pp18, pp17, 1'b0, 1'b0};
  // hybrid final adder: regions [0, 9, 18] of kinds ['ripple', 'skip'] on the uniform profile (arrival_profile_intersection)
  logic rg0_co;
  fam_adder_ripple_carry #(.W(9), .CHUNK(1), .FORM(0)) u_rg0 (.a(row_s[8:0]), .b(row_c[8:0]), .cin(1'b0), .s(p[8:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_skip_w9 u_rg1 (.a(row_s[17:9]), .b(row_c[17:9]), .cin(rg0_co), .s(p[17:9]), .cout(rg1_co));
endmodule

// segmented_grid (rectangular, depth 1): 2 x 1 segment products of 4 x 8 bits (direct_pp_parallel) merged by carry_save_tree (merge adder end_around_carry)
module fam_mul_segmented_grid_w8_s_p7da09409 (input logic [7:0] a, input logic [7:0] b, output logic [15:0] p);
  logic [7:0] ae; assign ae = a;
  logic [7:0] be; assign be = b;
  logic [8:0] sa00; assign sa00 = {{5{1'b0}}, ae[3:0]};
  logic [8:0] sb00; assign sb00 = {{1{be[7]}}, be[7:0]};
  logic [17:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w9_s_p812bf641 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [8:0] sa10; assign sa10 = {{5{ae[7]}}, ae[7:4]};
  logic [8:0] sb10; assign sb10 = {{1{be[7]}}, be[7:0]};
  logic [17:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w9_s_p812bf641 u2 (.a(sa10), .b(sb10), .p(sp10));
  logic [17:0] full;
  logic [17:0] row_s, row_c;
  assign row_s = {sp00[17], sp00[16], sp00[15], sp00[14], sp00[13], sp00[12], sp00[11], sp00[10], sp00[9], sp00[8], sp00[7], sp00[6], sp00[5], sp00[4], sp00[3], sp00[2], sp00[1], sp00[0]};
  assign row_c = {sp10[13], sp10[12], sp10[11], sp10[10], sp10[9], sp10[8], sp10[7], sp10[6], sp10[5], sp10[4], sp10[3], sp10[2], sp10[1], sp10[0], 1'b0, 1'b0, 1'b0, 1'b0};
  fam_prefix_brent_kung_w18_flag_dual u_cpa (.a(row_s), .b(row_c), .cin(1'b0), .s(full), .cout());
  assign p = full[15:0];
endmodule

// squarer (basic_symmetry): the product from two folded squarers by the quarter-square identity 4ab = (a+b)^2 - (a-b)^2 (a squarer alone serves x^2); the sum, the difference and the final subtraction through the pre_adder slot (prefix_synthesis_nonuniform_arrival)
module fam_mul_squarer_w16_u_pa74b3b61 (input logic [15:0] a, input logic [15:0] b, output logic [31:0] p);
  logic [17:0] ae; assign ae = {2'b0, a};
  logic [17:0] be; assign be = {2'b0, b};
  logic [18:0] sa;
  // a + b (the sign bit's carry unused)
  fam_prefix_arrival_0_0_1_1_1_1_2_2_2_3_3_3_4_4_4_4_5_5_w18 u1 (.a(ae), .b(be), .cin(1'b0), .s(sa[17:0]), .cout(sa[18]));
  logic [18:0] da;
  logic [17:0] da_nb; assign da_nb = ~be;
  // a - b
  fam_prefix_arrival_0_0_1_1_1_1_2_2_2_3_3_3_4_4_4_4_5_5_w18 u2 (.a(ae), .b(da_nb), .cin(1'b1), .s(da[17:0]), .cout(da[18]));
  logic [35:0] s2;
  logic [35:0] d2;
  fam_mul_squarer_w16_u_pa74b3b61_sq u_s (.x(sa[17:0]), .p(s2));
  fam_mul_squarer_w16_u_pa74b3b61_sq u_d (.x(da[17:0]), .p(d2));
  logic [36:0] diff;
  logic [35:0] diff_nb; assign diff_nb = ~d2;
  // (a+b)^2 - (a-b)^2
  fam_prefix_arrival_0_0_0_1_1_1_1_1_1_2_2_2_2_2_2_3_3_3_3_3_3_4_4_4_4_4_4_5_5_5_5_5_5_6_6_6_w36 u3 (.a(s2), .b(diff_nb), .cin(1'b1), .s(diff[35:0]), .cout(diff[36]));
  assign p = diff[33:2];
endmodule


module fam_mul_squarer_w16_u_pa74b3b61_sq (input logic [17:0] x, output logic [35:0] p);
  // squarer (basic_symmetry, two's complement x): 106 full adders, 14 half adders, depth 6
  logic sq0, sq1, sq2, sq3, sq4, sq5, sq6, sq7, sq8, sq9, sq10, sq11, sq12, sq13, sq14, sq15, sq16, sq17, sq18, sq19, sq20, sq21, sq22, sq23, sq24, sq25, sq26, sq27, sq28, sq29, sq30, sq31, sq32, sq33, sq34, sq35, sq36, sq37, sq38, sq39, sq40, sq41, sq42, sq43, sq44, sq45, sq46, sq47, sq48, sq49, sq50, sq51, sq52, sq53, sq54, sq55, sq56, sq57, sq58, sq59, sq60, sq61, sq62, sq63, sq64, sq65, sq66, sq67, sq68, sq69, sq70, sq71, sq72, sq73, sq74, sq75, sq76, sq77, sq78, sq79, sq80, sq81, sq82, sq83, sq84, sq85, sq86, sq87, sq88, sq89, sq90, sq91, sq92, sq93, sq94, sq95, sq96, sq97, sq98, sq99, sq100, sq101, sq102, sq103, sq104, sq105, sq106, sq107, sq108, sq109, sq110, sq111, sq112, sq113, sq114, sq115, sq116, sq117, sq118, sq119, sq120, sq121, sq122, sq123, sq124, sq125, sq126, sq127, sq128, sq129, sq130, sq131, sq132, sq133, sq134, sq135, sq136, sq137, sq138, sq139, sq140, sq141, sq142, sq143, sq144, sq145, sq146, sq147, sq148, sq149, sq150, sq151, sq152, t153, t154, t155, t156, t157, t158, t159, t160, t161, t162, t163, t164, t165, t166, t167, t168, t169, t170, t171, t172, t173, t174, t175, t176, t177, t178, t179, t180, t181, t182, t183, t184, t185, t186, t187, t188, t189, t190, t191, t192, t193, t194, t195, t196, t197, t198, t199, t200, t201, t202, t203, t204, t205, t206, t207, t208, t209, t210, t211, t212, t213, t214, t215, t216, t217, t218, t219, t220, t221, t222, t223, t224, t225, t226, t227, t228, t229, t230, t231, t232, t233, t234, t235, t236, t237, t238, t239, t240, t241, t242, t243, t244, t245, t246, t247, t248, t249, t250, t251, t252, t253, t254, t255, t256, t257, t258, t259, t260, t261, t262, t263, t264, t265, t266, t267, t268, t269, t270, t271, t272, t273, t274, t275, t276, t277, t278, t279, t280, t281, t282, t283, t284, t285, t286, t287, t288, t289, t290, t291, t292, t293, t294, t295, t296, t297, t298, t299, t300, t301, t302, t303, t304, t305, t306, t307, t308, t309, t310, t311, t312, t313, t314, t315, t316, t317, t318, t319, t320, t321, t322, t323, t324, t325, t326, t327, t328, t329, t330, t331, t332, t333, t334, t335, t336, t337, t338, t339, t340, t341, t342, t343, t344, t345, t346, t347, t348, t349, t350, t351, t352, t353, t354, t355, t356, t357, t358, t359, t360, t361, t362, t363, t364, t365, t366, t367, t368, t369, t370, t371, t372, t373, t374, t375, t376, t377, t378, t379, t380, t381, t382, t383, t384, t385, t386, t387, t388, t389, t390, t391, t392;
  assign sq0 = x[0] & x[1];
  assign sq1 = x[0] & x[2];
  assign sq2 = x[0] & x[3];
  assign sq3 = x[0] & x[4];
  assign sq4 = x[0] & x[5];
  assign sq5 = x[0] & x[6];
  assign sq6 = x[0] & x[7];
  assign sq7 = x[0] & x[8];
  assign sq8 = x[0] & x[9];
  assign sq9 = x[0] & x[10];
  assign sq10 = x[0] & x[11];
  assign sq11 = x[0] & x[12];
  assign sq12 = x[0] & x[13];
  assign sq13 = x[0] & x[14];
  assign sq14 = x[0] & x[15];
  assign sq15 = x[0] & x[16];
  assign sq16 = ~(x[0] & x[17]);
  assign sq17 = x[1] & x[2];
  assign sq18 = x[1] & x[3];
  assign sq19 = x[1] & x[4];
  assign sq20 = x[1] & x[5];
  assign sq21 = x[1] & x[6];
  assign sq22 = x[1] & x[7];
  assign sq23 = x[1] & x[8];
  assign sq24 = x[1] & x[9];
  assign sq25 = x[1] & x[10];
  assign sq26 = x[1] & x[11];
  assign sq27 = x[1] & x[12];
  assign sq28 = x[1] & x[13];
  assign sq29 = x[1] & x[14];
  assign sq30 = x[1] & x[15];
  assign sq31 = x[1] & x[16];
  assign sq32 = ~(x[1] & x[17]);
  assign sq33 = x[2] & x[3];
  assign sq34 = x[2] & x[4];
  assign sq35 = x[2] & x[5];
  assign sq36 = x[2] & x[6];
  assign sq37 = x[2] & x[7];
  assign sq38 = x[2] & x[8];
  assign sq39 = x[2] & x[9];
  assign sq40 = x[2] & x[10];
  assign sq41 = x[2] & x[11];
  assign sq42 = x[2] & x[12];
  assign sq43 = x[2] & x[13];
  assign sq44 = x[2] & x[14];
  assign sq45 = x[2] & x[15];
  assign sq46 = x[2] & x[16];
  assign sq47 = ~(x[2] & x[17]);
  assign sq48 = x[3] & x[4];
  assign sq49 = x[3] & x[5];
  assign sq50 = x[3] & x[6];
  assign sq51 = x[3] & x[7];
  assign sq52 = x[3] & x[8];
  assign sq53 = x[3] & x[9];
  assign sq54 = x[3] & x[10];
  assign sq55 = x[3] & x[11];
  assign sq56 = x[3] & x[12];
  assign sq57 = x[3] & x[13];
  assign sq58 = x[3] & x[14];
  assign sq59 = x[3] & x[15];
  assign sq60 = x[3] & x[16];
  assign sq61 = ~(x[3] & x[17]);
  assign sq62 = x[4] & x[5];
  assign sq63 = x[4] & x[6];
  assign sq64 = x[4] & x[7];
  assign sq65 = x[4] & x[8];
  assign sq66 = x[4] & x[9];
  assign sq67 = x[4] & x[10];
  assign sq68 = x[4] & x[11];
  assign sq69 = x[4] & x[12];
  assign sq70 = x[4] & x[13];
  assign sq71 = x[4] & x[14];
  assign sq72 = x[4] & x[15];
  assign sq73 = x[4] & x[16];
  assign sq74 = ~(x[4] & x[17]);
  assign sq75 = x[5] & x[6];
  assign sq76 = x[5] & x[7];
  assign sq77 = x[5] & x[8];
  assign sq78 = x[5] & x[9];
  assign sq79 = x[5] & x[10];
  assign sq80 = x[5] & x[11];
  assign sq81 = x[5] & x[12];
  assign sq82 = x[5] & x[13];
  assign sq83 = x[5] & x[14];
  assign sq84 = x[5] & x[15];
  assign sq85 = x[5] & x[16];
  assign sq86 = ~(x[5] & x[17]);
  assign sq87 = x[6] & x[7];
  assign sq88 = x[6] & x[8];
  assign sq89 = x[6] & x[9];
  assign sq90 = x[6] & x[10];
  assign sq91 = x[6] & x[11];
  assign sq92 = x[6] & x[12];
  assign sq93 = x[6] & x[13];
  assign sq94 = x[6] & x[14];
  assign sq95 = x[6] & x[15];
  assign sq96 = x[6] & x[16];
  assign sq97 = ~(x[6] & x[17]);
  assign sq98 = x[7] & x[8];
  assign sq99 = x[7] & x[9];
  assign sq100 = x[7] & x[10];
  assign sq101 = x[7] & x[11];
  assign sq102 = x[7] & x[12];
  assign sq103 = x[7] & x[13];
  assign sq104 = x[7] & x[14];
  assign sq105 = x[7] & x[15];
  assign sq106 = x[7] & x[16];
  assign sq107 = ~(x[7] & x[17]);
  assign sq108 = x[8] & x[9];
  assign sq109 = x[8] & x[10];
  assign sq110 = x[8] & x[11];
  assign sq111 = x[8] & x[12];
  assign sq112 = x[8] & x[13];
  assign sq113 = x[8] & x[14];
  assign sq114 = x[8] & x[15];
  assign sq115 = x[8] & x[16];
  assign sq116 = ~(x[8] & x[17]);
  assign sq117 = x[9] & x[10];
  assign sq118 = x[9] & x[11];
  assign sq119 = x[9] & x[12];
  assign sq120 = x[9] & x[13];
  assign sq121 = x[9] & x[14];
  assign sq122 = x[9] & x[15];
  assign sq123 = x[9] & x[16];
  assign sq124 = ~(x[9] & x[17]);
  assign sq125 = x[10] & x[11];
  assign sq126 = x[10] & x[12];
  assign sq127 = x[10] & x[13];
  assign sq128 = x[10] & x[14];
  assign sq129 = x[10] & x[15];
  assign sq130 = x[10] & x[16];
  assign sq131 = ~(x[10] & x[17]);
  assign sq132 = x[11] & x[12];
  assign sq133 = x[11] & x[13];
  assign sq134 = x[11] & x[14];
  assign sq135 = x[11] & x[15];
  assign sq136 = x[11] & x[16];
  assign sq137 = ~(x[11] & x[17]);
  assign sq138 = x[12] & x[13];
  assign sq139 = x[12] & x[14];
  assign sq140 = x[12] & x[15];
  assign sq141 = x[12] & x[16];
  assign sq142 = ~(x[12] & x[17]);
  assign sq143 = x[13] & x[14];
  assign sq144 = x[13] & x[15];
  assign sq145 = x[13] & x[16];
  assign sq146 = ~(x[13] & x[17]);
  assign sq147 = x[14] & x[15];
  assign sq148 = x[14] & x[16];
  assign sq149 = ~(x[14] & x[17]);
  assign sq150 = x[15] & x[16];
  assign sq151 = ~(x[15] & x[17]);
  assign sq152 = ~(x[16] & x[17]);
  assign t153 = sq16 ^ sq31 ^ sq45;
  assign t154 = (sq16 & sq31) | (sq16 & sq45) | (sq31 & sq45);
  assign t155 = sq10 ^ sq25;
  assign t156 = sq10 & sq25;
  assign t157 = sq11 ^ sq26;
  assign t158 = sq11 & sq26;
  assign t159 = sq12 ^ sq27 ^ sq41;
  assign t160 = (sq12 & sq27) | (sq12 & sq41) | (sq27 & sq41);
  assign t161 = sq54 ^ sq66;
  assign t162 = sq54 & sq66;
  assign t163 = sq13 ^ sq28 ^ sq42;
  assign t164 = (sq13 & sq28) | (sq13 & sq42) | (sq28 & sq42);
  assign t165 = sq55 ^ sq67;
  assign t166 = sq55 & sq67;
  assign t167 = sq14 ^ sq29 ^ sq43;
  assign t168 = (sq14 & sq29) | (sq14 & sq43) | (sq29 & sq43);
  assign t169 = t167 ^ sq56 ^ sq68;
  assign t170 = (t167 & sq56) | (t167 & sq68) | (sq56 & sq68);
  assign t171 = sq79 ^ sq89;
  assign t172 = sq79 & sq89;
  assign t173 = sq15 ^ sq30 ^ sq44;
  assign t174 = (sq15 & sq30) | (sq15 & sq44) | (sq30 & sq44);
  assign t175 = t173 ^ sq57 ^ sq69;
  assign t176 = (t173 & sq57) | (t173 & sq69) | (sq57 & sq69);
  assign t177 = sq80 ^ sq90;
  assign t178 = sq80 & sq90;
  assign t179 = sq58 ^ sq70 ^ sq81;
  assign t180 = (sq58 & sq70) | (sq58 & sq81) | (sq70 & sq81);
  assign t181 = t179 ^ sq91 ^ sq100;
  assign t182 = (t179 & sq91) | (t179 & sq100) | (sq91 & sq100);
  assign t183 = sq108 ^ x[9] ^ 1'b1;
  assign t184 = (sq108 & x[9]) | (sq108 & 1'b1) | (x[9] & 1'b1);
  assign t185 = sq32 ^ sq46 ^ sq59;
  assign t186 = (sq32 & sq46) | (sq32 & sq59) | (sq46 & sq59);
  assign t187 = t185 ^ sq71 ^ sq82;
  assign t188 = (t185 & sq71) | (t185 & sq82) | (sq71 & sq82);
  assign t189 = sq92 ^ sq101 ^ sq109;
  assign t190 = (sq92 & sq101) | (sq92 & sq109) | (sq101 & sq109);
  assign t191 = sq47 ^ sq60 ^ sq72;
  assign t192 = (sq47 & sq60) | (sq47 & sq72) | (sq60 & sq72);
  assign t193 = t191 ^ sq83 ^ sq93;
  assign t194 = (t191 & sq83) | (t191 & sq93) | (sq83 & sq93);
  assign t195 = sq102 ^ sq110 ^ sq117;
  assign t196 = (sq102 & sq110) | (sq102 & sq117) | (sq110 & sq117);
  assign t197 = sq61 ^ sq73 ^ sq84;
  assign t198 = (sq61 & sq73) | (sq61 & sq84) | (sq73 & sq84);
  assign t199 = t197 ^ sq94 ^ sq103;
  assign t200 = (t197 & sq94) | (t197 & sq103) | (sq94 & sq103);
  assign t201 = sq74 ^ sq85 ^ sq95;
  assign t202 = (sq74 & sq85) | (sq74 & sq95) | (sq85 & sq95);
  assign t203 = t201 ^ sq104 ^ sq112;
  assign t204 = (t201 & sq104) | (t201 & sq112) | (sq104 & sq112);
  assign t205 = sq86 ^ sq96 ^ sq105;
  assign t206 = (sq86 & sq96) | (sq86 & sq105) | (sq96 & sq105);
  assign t207 = sq97 ^ sq106 ^ sq114;
  assign t208 = (sq97 & sq106) | (sq97 & sq114) | (sq106 & sq114);
  assign t209 = sq6 ^ sq21;
  assign t210 = sq6 & sq21;
  assign t211 = sq7 ^ sq22;
  assign t212 = sq7 & sq22;
  assign t213 = sq8 ^ sq23 ^ sq37;
  assign t214 = (sq8 & sq23) | (sq8 & sq37) | (sq23 & sq37);
  assign t215 = sq50 ^ sq62;
  assign t216 = sq50 & sq62;
  assign t217 = sq9 ^ sq24 ^ sq38;
  assign t218 = (sq9 & sq24) | (sq9 & sq38) | (sq24 & sq38);
  assign t219 = sq51 ^ sq63;
  assign t220 = sq51 & sq63;
  assign t221 = sq39 ^ sq52 ^ sq64;
  assign t222 = (sq39 & sq52) | (sq39 & sq64) | (sq52 & sq64);
  assign t223 = t221 ^ sq75 ^ x[6];
  assign t224 = (t221 & sq75) | (t221 & x[6]) | (sq75 & x[6]);
  assign t225 = sq40 ^ sq53 ^ sq65;
  assign t226 = (sq40 & sq53) | (sq40 & sq65) | (sq53 & sq65);
  assign t227 = t225 ^ sq76 ^ t156;
  assign t228 = (t225 & sq76) | (t225 & t156) | (sq76 & t156);
  assign t229 = sq77 ^ sq87 ^ x[7];
  assign t230 = (sq77 & sq87) | (sq77 & x[7]) | (sq87 & x[7]);
  assign t231 = t229 ^ t158 ^ t159;
  assign t232 = (t229 & t158) | (t229 & t159) | (t158 & t159);
  assign t233 = sq78 ^ sq88 ^ t160;
  assign t234 = (sq78 & sq88) | (sq78 & t160) | (sq88 & t160);
  assign t235 = t233 ^ t162 ^ t163;
  assign t236 = (t233 & t162) | (t233 & t163) | (t162 & t163);
  assign t237 = sq98 ^ x[8] ^ t164;
  assign t238 = (sq98 & x[8]) | (sq98 & t164) | (x[8] & t164);
  assign t239 = t237 ^ t166 ^ t169;
  assign t240 = (t237 & t166) | (t237 & t169) | (t166 & t169);
  assign t241 = sq99 ^ t168 ^ t170;
  assign t242 = (sq99 & t168) | (sq99 & t170) | (t168 & t170);
  assign t243 = t241 ^ t172 ^ t175;
  assign t244 = (t241 & t172) | (t241 & t175) | (t172 & t175);
  assign t245 = t153 ^ t174 ^ t176;
  assign t246 = (t153 & t174) | (t153 & t176) | (t174 & t176);
  assign t247 = t245 ^ t178 ^ t181;
  assign t248 = (t245 & t178) | (t245 & t181) | (t178 & t181);
  assign t249 = t154 ^ t180 ^ t182;
  assign t250 = (t154 & t180) | (t154 & t182) | (t180 & t182);
  assign t251 = t249 ^ t184 ^ t187;
  assign t252 = (t249 & t184) | (t249 & t187) | (t184 & t187);
  assign t253 = x[10] ^ t186 ^ t188;
  assign t254 = (x[10] & t186) | (x[10] & t188) | (t186 & t188);
  assign t255 = t253 ^ t190 ^ t193;
  assign t256 = (t253 & t190) | (t253 & t193) | (t190 & t193);
  assign t257 = sq111 ^ sq118 ^ t192;
  assign t258 = (sq111 & sq118) | (sq111 & t192) | (sq118 & t192);
  assign t259 = t257 ^ t194 ^ t196;
  assign t260 = (t257 & t194) | (t257 & t196) | (t194 & t196);
  assign t261 = sq119 ^ sq125 ^ x[11];
  assign t262 = (sq119 & sq125) | (sq119 & x[11]) | (sq125 & x[11]);
  assign t263 = t261 ^ t198 ^ t200;
  assign t264 = (t261 & t198) | (t261 & t200) | (t198 & t200);
  assign t265 = sq113 ^ sq120 ^ sq126;
  assign t266 = (sq113 & sq120) | (sq113 & sq126) | (sq120 & sq126);
  assign t267 = t265 ^ t202 ^ t204;
  assign t268 = (t265 & t202) | (t265 & t204) | (t202 & t204);
  assign t269 = sq121 ^ sq127 ^ sq132;
  assign t270 = (sq121 & sq127) | (sq121 & sq132) | (sq127 & sq132);
  assign t271 = t269 ^ x[12] ^ t206;
  assign t272 = (t269 & x[12]) | (t269 & t206) | (x[12] & t206);
  assign t273 = sq107 ^ sq115 ^ sq122;
  assign t274 = (sq107 & sq115) | (sq107 & sq122) | (sq115 & sq122);
  assign t275 = t273 ^ sq128 ^ sq133;
  assign t276 = (t273 & sq128) | (t273 & sq133) | (sq128 & sq133);
  assign t277 = sq116 ^ sq123 ^ sq129;
  assign t278 = (sq116 & sq123) | (sq116 & sq129) | (sq123 & sq129);
  assign t279 = t277 ^ sq134 ^ sq138;
  assign t280 = (t277 & sq134) | (t277 & sq138) | (sq134 & sq138);
  assign t281 = sq124 ^ sq130 ^ sq135;
  assign t282 = (sq124 & sq130) | (sq124 & sq135) | (sq130 & sq135);
  assign t283 = sq131 ^ sq136 ^ sq140;
  assign t284 = (sq131 & sq136) | (sq131 & sq140) | (sq136 & sq140);
  assign t285 = sq4 ^ sq19;
  assign t286 = sq4 & sq19;
  assign t287 = sq5 ^ sq20;
  assign t288 = sq5 & sq20;
  assign t289 = sq35 ^ sq48 ^ x[4];
  assign t290 = (sq35 & sq48) | (sq35 & x[4]) | (sq48 & x[4]);
  assign t291 = sq36 ^ sq49 ^ t210;
  assign t292 = (sq36 & sq49) | (sq36 & t210) | (sq49 & t210);
  assign t293 = x[5] ^ t212 ^ t213;
  assign t294 = (x[5] & t212) | (x[5] & t213) | (t212 & t213);
  assign t295 = t214 ^ t216 ^ t217;
  assign t296 = (t214 & t216) | (t214 & t217) | (t216 & t217);
  assign t297 = t155 ^ t218 ^ t220;
  assign t298 = (t155 & t218) | (t155 & t220) | (t218 & t220);
  assign t299 = t157 ^ t222 ^ t224;
  assign t300 = (t157 & t222) | (t157 & t224) | (t222 & t224);
  assign t301 = t161 ^ t226 ^ t228;
  assign t302 = (t161 & t226) | (t161 & t228) | (t226 & t228);
  assign t303 = t165 ^ t230 ^ t232;
  assign t304 = (t165 & t230) | (t165 & t232) | (t230 & t232);
  assign t305 = t171 ^ t234 ^ t236;
  assign t306 = (t171 & t234) | (t171 & t236) | (t234 & t236);
  assign t307 = t177 ^ t238 ^ t240;
  assign t308 = (t177 & t238) | (t177 & t240) | (t238 & t240);
  assign t309 = t183 ^ t242 ^ t244;
  assign t310 = (t183 & t242) | (t183 & t244) | (t242 & t244);
  assign t311 = t189 ^ t246 ^ t248;
  assign t312 = (t189 & t246) | (t189 & t248) | (t246 & t248);
  assign t313 = t195 ^ t250 ^ t252;
  assign t314 = (t195 & t250) | (t195 & t252) | (t250 & t252);
  assign t315 = t199 ^ t254 ^ t256;
  assign t316 = (t199 & t254) | (t199 & t256) | (t254 & t256);
  assign t317 = t203 ^ t258 ^ t260;
  assign t318 = (t203 & t258) | (t203 & t260) | (t258 & t260);
  assign t319 = t205 ^ t262 ^ t264;
  assign t320 = (t205 & t262) | (t205 & t264) | (t262 & t264);
  assign t321 = t207 ^ t266 ^ t268;
  assign t322 = (t207 & t266) | (t207 & t268) | (t266 & t268);
  assign t323 = t208 ^ t270 ^ t272;
  assign t324 = (t208 & t270) | (t208 & t272) | (t270 & t272);
  assign t325 = x[13] ^ t274 ^ t276;
  assign t326 = (x[13] & t274) | (x[13] & t276) | (t274 & t276);
  assign t327 = sq139 ^ t278 ^ t280;
  assign t328 = (sq139 & t278) | (sq139 & t280) | (t278 & t280);
  assign t329 = sq143 ^ x[14] ^ t282;
  assign t330 = (sq143 & x[14]) | (sq143 & t282) | (x[14] & t282);
  assign t331 = sq137 ^ sq141 ^ sq144;
  assign t332 = (sq137 & sq141) | (sq137 & sq144) | (sq141 & sq144);
  assign t333 = sq142 ^ sq145 ^ sq147;
  assign t334 = (sq142 & sq145) | (sq142 & sq147) | (sq145 & sq147);
  assign t335 = sq2 ^ sq17;
  assign t336 = sq2 & sq17;
  assign t337 = sq3 ^ sq18;
  assign t338 = sq3 & sq18;
  assign t339 = sq33 ^ x[3] ^ t285;
  assign t340 = (sq33 & x[3]) | (sq33 & t285) | (x[3] & t285);
  assign t341 = sq34 ^ t286 ^ t287;
  assign t342 = (sq34 & t286) | (sq34 & t287) | (t286 & t287);
  assign t343 = t209 ^ t288 ^ t289;
  assign t344 = (t209 & t288) | (t209 & t289) | (t288 & t289);
  assign t345 = t211 ^ t290 ^ t291;
  assign t346 = (t211 & t290) | (t211 & t291) | (t290 & t291);
  assign t347 = t215 ^ t292 ^ t293;
  assign t348 = (t215 & t292) | (t215 & t293) | (t292 & t293);
  assign t349 = t219 ^ t294 ^ t295;
  assign t350 = (t219 & t294) | (t219 & t295) | (t294 & t295);
  assign t351 = t223 ^ t296 ^ t297;
  assign t352 = (t223 & t296) | (t223 & t297) | (t296 & t297);
  assign t353 = t227 ^ t298 ^ t299;
  assign t354 = (t227 & t298) | (t227 & t299) | (t298 & t299);
  assign t355 = t231 ^ t300 ^ t301;
  assign t356 = (t231 & t300) | (t231 & t301) | (t300 & t301);
  assign t357 = t235 ^ t302 ^ t303;
  assign t358 = (t235 & t302) | (t235 & t303) | (t302 & t303);
  assign t359 = t239 ^ t304 ^ t305;
  assign t360 = (t239 & t304) | (t239 & t305) | (t304 & t305);
  assign t361 = t243 ^ t306 ^ t307;
  assign t362 = (t243 & t306) | (t243 & t307) | (t306 & t307);
  assign t363 = t247 ^ t308 ^ t309;
  assign t364 = (t247 & t308) | (t247 & t309) | (t308 & t309);
  assign t365 = t251 ^ t310 ^ t311;
  assign t366 = (t251 & t310) | (t251 & t311) | (t310 & t311);
  assign t367 = t255 ^ t312 ^ t313;
  assign t368 = (t255 & t312) | (t255 & t313) | (t312 & t313);
  assign t369 = t259 ^ t314 ^ t315;
  assign t370 = (t259 & t314) | (t259 & t315) | (t314 & t315);
  assign t371 = t263 ^ t316 ^ t317;
  assign t372 = (t263 & t316) | (t263 & t317) | (t316 & t317);
  assign t373 = t267 ^ t318 ^ t319;
  assign t374 = (t267 & t318) | (t267 & t319) | (t318 & t319);
  assign t375 = t271 ^ t320 ^ t321;
  assign t376 = (t271 & t320) | (t271 & t321) | (t320 & t321);
  assign t377 = t275 ^ t322 ^ t323;
  assign t378 = (t275 & t322) | (t275 & t323) | (t322 & t323);
  assign t379 = t279 ^ t324 ^ t325;
  assign t380 = (t279 & t324) | (t279 & t325) | (t324 & t325);
  assign t381 = t281 ^ t326 ^ t327;
  assign t382 = (t281 & t326) | (t281 & t327) | (t326 & t327);
  assign t383 = t283 ^ t328 ^ t329;
  assign t384 = (t283 & t328) | (t283 & t329) | (t328 & t329);
  assign t385 = t284 ^ t330 ^ t331;
  assign t386 = (t284 & t330) | (t284 & t331) | (t330 & t331);
  assign t387 = x[15] ^ t332 ^ t333;
  assign t388 = (x[15] & t332) | (x[15] & t333) | (t332 & t333);
  assign t389 = sq146 ^ sq148 ^ t334;
  assign t390 = (sq146 & sq148) | (sq146 & t334) | (sq148 & t334);
  assign t391 = sq149 ^ sq150 ^ x[16];
  assign t392 = (sq149 & sq150) | (sq149 & x[16]) | (sq150 & x[16]);
  logic [35:0] row_s, row_c;
  assign row_s = {1'b1, sq152, sq151, t390, t388, t386, t384, t382, t380, t378, t376, t374, t372, t370, t368, t366, t364, t362, t360, t358, t356, t354, t352, t350, t348, t346, t344, t342, t340, t338, t336, x[2], sq1, sq0, 1'b0, x[0]};
  assign row_c = {1'b0, x[17], t392, t391, t389, t387, t385, t383, t381, t379, t377, t375, t373, t371, t369, t367, t365, t363, t361, t359, t357, t355, t353, t351, t349, t347, t345, t343, t341, t339, t337, t335, 1'b0, x[1], 1'b0, 1'b0};
  fam_prefix_han_carlson_w36_ling u_cpa (.a(row_s), .b(row_c), .cin(1'b0), .s(p), .cout());
endmodule

// twin_precision_subword (baugh_wooley, signs outside the matrix): the lanes' magnitudes through an unsigned gated matrix, each lane's product negated back by the operand signs
module fam_mul_twin_precision_w16_16s_mag_ff7a627b5d2a (input logic [15:0] a, input logic [15:0] b, input logic [0:0] sel, output logic [31:0] p);
  logic [15:0] am, bm; logic [31:0] pu, pn;
  logic [15:0] am0, bm0; logic [31:0] pn0;
  assign am0 = {(a[15] ? -a[15:0] : a[15:0])}; assign bm0 = {(b[15] ? -b[15:0] : b[15:0])}; assign pn0 = {((a[15] ^ b[15]) ? -pu[31:0] : pu[31:0])};
  assign am = (sel == 1'd0) ? am0 : a;
  assign bm = (sel == 1'd0) ? bm0 : b;
  fam_mul_twin_precision_w16_16s_mag_ff7a627b5d2a_u u_mat (.a(am), .b(bm), .sel(sel), .p(pu));
  assign p = (sel == 1'd0) ? pn0 : pu;
endmodule


// twin_precision_subword (baugh_wooley, per-lane signed): one partial-product matrix gated by the mode (1 x 16), carries killed at the lane boundaries, the packed products on one bus
module fam_mul_twin_precision_w16_16s_mag_ff7a627b5d2a_u (input logic [15:0] a, input logic [15:0] b, input logic [0:0] sel, output logic [31:0] p);
  logic [0:0] sel_u; assign sel_u = sel;
  logic ms0, pp1, pp2, pp3, pp4, pp5, pp6, pp7, pp8, pp9, pp10, pp11, pp12, pp13, pp14, pp15, pp16, pp17, pp18, pp19, pp20, pp21, pp22, pp23, pp24, pp25, pp26, pp27, pp28, pp29, pp30, pp31, pp32, pp33, pp34, pp35, pp36, pp37, pp38, pp39, pp40, pp41, pp42, pp43, pp44, pp45, pp46, pp47, pp48, pp49, pp50, pp51, pp52, pp53, pp54, pp55, pp56, pp57, pp58, pp59, pp60, pp61, pp62, pp63, pp64, pp65, pp66, pp67, pp68, pp69, pp70, pp71, pp72, pp73, pp74, pp75, pp76, pp77, pp78, pp79, pp80, pp81, pp82, pp83, pp84, pp85, pp86, pp87, pp88, pp89, pp90, pp91, pp92, pp93, pp94, pp95, pp96, pp97, pp98, pp99, pp100, pp101, pp102, pp103, pp104, pp105, pp106, pp107, pp108, pp109, pp110, pp111, pp112, pp113, pp114, pp115, pp116, pp117, pp118, pp119, pp120, pp121, pp122, pp123, pp124, pp125, pp126, pp127, pp128, pp129, pp130, pp131, pp132, pp133, pp134, pp135, pp136, pp137, pp138, pp139, pp140, pp141, pp142, pp143, pp144, pp145, pp146, pp147, pp148, pp149, pp150, pp151, pp152, pp153, pp154, pp155, pp156, pp157, pp158, pp159, pp160, pp161, pp162, pp163, pp164, pp165, pp166, pp167, pp168, pp169, pp170, pp171, pp172, pp173, pp174, pp175, pp176, pp177, pp178, pp179, pp180, pp181, pp182, pp183, pp184, pp185, pp186, pp187, pp188, pp189, pp190, pp191, pp192, pp193, pp194, pp195, pp196, pp197, pp198, pp199, pp200, pp201, pp202, pp203, pp204, pp205, pp206, pp207, pp208, pp209, pp210, pp211, pp212, pp213, pp214, pp215, pp216, pp217, pp218, pp219, pp220, pp221, pp222, pp223, pp224, pp225, pp226, pp227, pp228, pp229, pp230, pp231, pp232, pp233, pp234, pp235, pp236, pp237, pp238, pp239, pp240, pp241, pp242, pp243, pp244, pp245, pp246, pp247, pp248, pp249, pp250, pp251, pp252, pp253, pp254, pp255, pp256, t257, t258, t259, t260, t261, t262, t263, t264, t265, t266, t267, t268, t269, t270, t271, t272, t273, t274, t275, t276, t277, t278, t279, t280, t281, t282, t283, t284, t285, t286, t287, t288, t289, t290, t291, t292, t293, t294, t295, t296, t297, t298, t299, t300, t301, t302, t303, t304, t305, t306, t307, t308, t309, t310, t311, t312, t313, t314, t315, t316, t317, t318, t319, t320, t321, t322, t323, t324, t325, t326, t327, t328, t329, t330, t331, t332, t333, t334, t335, t336, t337, t338, t339, t340, t341, t342, t343, t344, t345, t346, t347, t348, t349, t350, t351, t352, t353, t354, t355, t356, t357, t358, t359, t360, t361, t362, t363, t364, t365, t366, t367, t368, t369, t370, t371, t372, t373, t374, t375, t376, t377, t378, t379, t380, t381, t382, t383, t384, t385, t386, t387, t388, t389, t390, t391, t392, t393, t394, t395, t396, t397, t398, t399, t400, t401, t402, t403, t404, t405, t406, t407, t408, t409, t410, t411, t412, t413, t414, t415, t416, t417, t418, t419, t420, t421, t422, t423, t424, t425, t426, t427, t428, t429, t430, t431, t432, t433, t434, t435, t436, t437, t438, t439, t440, t441, t442, t443, t444, t445, t446, t447, t448, t449, t450, t451, t452, t453, t454, t455, t456, t457, t458, t459, t460, t461, t462, t463, t464, t465, t466, t467, t468, t469, t470, t471, t472, t473, t474, t475, t476, t477, t478, t479, t480, t481, t482, t483, t484, t485, t486, t487, t488, t489, t490, t491, t492, t493, t494, t495, t496, t497, t498, t499, t500, t501, t502, t503, t504, t505, t506, t507, t508, t509, t510, t511, t512, t513, t514, t515, t516, t517, t518, t519, t520, t521, t522, t523, t524, t525, t526, t527, t528, t529, t530, t531, t532, t533, t534, t535, t536, t537, t538, t539, t540, t541, t542, t543, t544, t545, t546, t547, t548, t549, t550, t551, t552, t553, t554, t555, t556, t557, t558, t559, t560, t561, t562, t563, t564, t565, t566, t567, t568, t569, t570, t571, t572, t573, t574, t575, t576, t577, t578, t579, t580, t581, t582, t583, t584, t585, t586, t587, t588, t589, t590, t591, t592, t593, t594, t595, t596, t597, t598, t599, t600, t601, t602, t603, t604, t605, t606, t607, t608, t609, t610, t611, t612, t613, t614, t615, t616, t617, t618, t619, t620, t621, t622, t623, t624, t625, t626, t627, t628, t629, t630, t631, t632, t633, t634, t635, t636, t637, t638, t639, t640, t641, t642, t643, t644, t645, t646, t647, t648, t649, t650, t651, t652, t653, t654, t655, t656, t657, t658, t659, t660, t661, t662, t663, t664, t665, t666, t667, t668, t669, t670, t671, t672, t673, t674, t675, t676;
  assign ms0 = sel == 1'd0;
  assign pp1 = a[0] & b[0];
  assign pp2 = a[0] & b[1];
  assign pp3 = a[0] & b[2];
  assign pp4 = a[0] & b[3];
  assign pp5 = a[0] & b[4];
  assign pp6 = a[0] & b[5];
  assign pp7 = a[0] & b[6];
  assign pp8 = a[0] & b[7];
  assign pp9 = a[0] & b[8];
  assign pp10 = a[0] & b[9];
  assign pp11 = a[0] & b[10];
  assign pp12 = a[0] & b[11];
  assign pp13 = a[0] & b[12];
  assign pp14 = a[0] & b[13];
  assign pp15 = a[0] & b[14];
  assign pp16 = a[0] & b[15];
  assign pp17 = a[1] & b[0];
  assign pp18 = a[1] & b[1];
  assign pp19 = a[1] & b[2];
  assign pp20 = a[1] & b[3];
  assign pp21 = a[1] & b[4];
  assign pp22 = a[1] & b[5];
  assign pp23 = a[1] & b[6];
  assign pp24 = a[1] & b[7];
  assign pp25 = a[1] & b[8];
  assign pp26 = a[1] & b[9];
  assign pp27 = a[1] & b[10];
  assign pp28 = a[1] & b[11];
  assign pp29 = a[1] & b[12];
  assign pp30 = a[1] & b[13];
  assign pp31 = a[1] & b[14];
  assign pp32 = a[1] & b[15];
  assign pp33 = a[2] & b[0];
  assign pp34 = a[2] & b[1];
  assign pp35 = a[2] & b[2];
  assign pp36 = a[2] & b[3];
  assign pp37 = a[2] & b[4];
  assign pp38 = a[2] & b[5];
  assign pp39 = a[2] & b[6];
  assign pp40 = a[2] & b[7];
  assign pp41 = a[2] & b[8];
  assign pp42 = a[2] & b[9];
  assign pp43 = a[2] & b[10];
  assign pp44 = a[2] & b[11];
  assign pp45 = a[2] & b[12];
  assign pp46 = a[2] & b[13];
  assign pp47 = a[2] & b[14];
  assign pp48 = a[2] & b[15];
  assign pp49 = a[3] & b[0];
  assign pp50 = a[3] & b[1];
  assign pp51 = a[3] & b[2];
  assign pp52 = a[3] & b[3];
  assign pp53 = a[3] & b[4];
  assign pp54 = a[3] & b[5];
  assign pp55 = a[3] & b[6];
  assign pp56 = a[3] & b[7];
  assign pp57 = a[3] & b[8];
  assign pp58 = a[3] & b[9];
  assign pp59 = a[3] & b[10];
  assign pp60 = a[3] & b[11];
  assign pp61 = a[3] & b[12];
  assign pp62 = a[3] & b[13];
  assign pp63 = a[3] & b[14];
  assign pp64 = a[3] & b[15];
  assign pp65 = a[4] & b[0];
  assign pp66 = a[4] & b[1];
  assign pp67 = a[4] & b[2];
  assign pp68 = a[4] & b[3];
  assign pp69 = a[4] & b[4];
  assign pp70 = a[4] & b[5];
  assign pp71 = a[4] & b[6];
  assign pp72 = a[4] & b[7];
  assign pp73 = a[4] & b[8];
  assign pp74 = a[4] & b[9];
  assign pp75 = a[4] & b[10];
  assign pp76 = a[4] & b[11];
  assign pp77 = a[4] & b[12];
  assign pp78 = a[4] & b[13];
  assign pp79 = a[4] & b[14];
  assign pp80 = a[4] & b[15];
  assign pp81 = a[5] & b[0];
  assign pp82 = a[5] & b[1];
  assign pp83 = a[5] & b[2];
  assign pp84 = a[5] & b[3];
  assign pp85 = a[5] & b[4];
  assign pp86 = a[5] & b[5];
  assign pp87 = a[5] & b[6];
  assign pp88 = a[5] & b[7];
  assign pp89 = a[5] & b[8];
  assign pp90 = a[5] & b[9];
  assign pp91 = a[5] & b[10];
  assign pp92 = a[5] & b[11];
  assign pp93 = a[5] & b[12];
  assign pp94 = a[5] & b[13];
  assign pp95 = a[5] & b[14];
  assign pp96 = a[5] & b[15];
  assign pp97 = a[6] & b[0];
  assign pp98 = a[6] & b[1];
  assign pp99 = a[6] & b[2];
  assign pp100 = a[6] & b[3];
  assign pp101 = a[6] & b[4];
  assign pp102 = a[6] & b[5];
  assign pp103 = a[6] & b[6];
  assign pp104 = a[6] & b[7];
  assign pp105 = a[6] & b[8];
  assign pp106 = a[6] & b[9];
  assign pp107 = a[6] & b[10];
  assign pp108 = a[6] & b[11];
  assign pp109 = a[6] & b[12];
  assign pp110 = a[6] & b[13];
  assign pp111 = a[6] & b[14];
  assign pp112 = a[6] & b[15];
  assign pp113 = a[7] & b[0];
  assign pp114 = a[7] & b[1];
  assign pp115 = a[7] & b[2];
  assign pp116 = a[7] & b[3];
  assign pp117 = a[7] & b[4];
  assign pp118 = a[7] & b[5];
  assign pp119 = a[7] & b[6];
  assign pp120 = a[7] & b[7];
  assign pp121 = a[7] & b[8];
  assign pp122 = a[7] & b[9];
  assign pp123 = a[7] & b[10];
  assign pp124 = a[7] & b[11];
  assign pp125 = a[7] & b[12];
  assign pp126 = a[7] & b[13];
  assign pp127 = a[7] & b[14];
  assign pp128 = a[7] & b[15];
  assign pp129 = a[8] & b[0];
  assign pp130 = a[8] & b[1];
  assign pp131 = a[8] & b[2];
  assign pp132 = a[8] & b[3];
  assign pp133 = a[8] & b[4];
  assign pp134 = a[8] & b[5];
  assign pp135 = a[8] & b[6];
  assign pp136 = a[8] & b[7];
  assign pp137 = a[8] & b[8];
  assign pp138 = a[8] & b[9];
  assign pp139 = a[8] & b[10];
  assign pp140 = a[8] & b[11];
  assign pp141 = a[8] & b[12];
  assign pp142 = a[8] & b[13];
  assign pp143 = a[8] & b[14];
  assign pp144 = a[8] & b[15];
  assign pp145 = a[9] & b[0];
  assign pp146 = a[9] & b[1];
  assign pp147 = a[9] & b[2];
  assign pp148 = a[9] & b[3];
  assign pp149 = a[9] & b[4];
  assign pp150 = a[9] & b[5];
  assign pp151 = a[9] & b[6];
  assign pp152 = a[9] & b[7];
  assign pp153 = a[9] & b[8];
  assign pp154 = a[9] & b[9];
  assign pp155 = a[9] & b[10];
  assign pp156 = a[9] & b[11];
  assign pp157 = a[9] & b[12];
  assign pp158 = a[9] & b[13];
  assign pp159 = a[9] & b[14];
  assign pp160 = a[9] & b[15];
  assign pp161 = a[10] & b[0];
  assign pp162 = a[10] & b[1];
  assign pp163 = a[10] & b[2];
  assign pp164 = a[10] & b[3];
  assign pp165 = a[10] & b[4];
  assign pp166 = a[10] & b[5];
  assign pp167 = a[10] & b[6];
  assign pp168 = a[10] & b[7];
  assign pp169 = a[10] & b[8];
  assign pp170 = a[10] & b[9];
  assign pp171 = a[10] & b[10];
  assign pp172 = a[10] & b[11];
  assign pp173 = a[10] & b[12];
  assign pp174 = a[10] & b[13];
  assign pp175 = a[10] & b[14];
  assign pp176 = a[10] & b[15];
  assign pp177 = a[11] & b[0];
  assign pp178 = a[11] & b[1];
  assign pp179 = a[11] & b[2];
  assign pp180 = a[11] & b[3];
  assign pp181 = a[11] & b[4];
  assign pp182 = a[11] & b[5];
  assign pp183 = a[11] & b[6];
  assign pp184 = a[11] & b[7];
  assign pp185 = a[11] & b[8];
  assign pp186 = a[11] & b[9];
  assign pp187 = a[11] & b[10];
  assign pp188 = a[11] & b[11];
  assign pp189 = a[11] & b[12];
  assign pp190 = a[11] & b[13];
  assign pp191 = a[11] & b[14];
  assign pp192 = a[11] & b[15];
  assign pp193 = a[12] & b[0];
  assign pp194 = a[12] & b[1];
  assign pp195 = a[12] & b[2];
  assign pp196 = a[12] & b[3];
  assign pp197 = a[12] & b[4];
  assign pp198 = a[12] & b[5];
  assign pp199 = a[12] & b[6];
  assign pp200 = a[12] & b[7];
  assign pp201 = a[12] & b[8];
  assign pp202 = a[12] & b[9];
  assign pp203 = a[12] & b[10];
  assign pp204 = a[12] & b[11];
  assign pp205 = a[12] & b[12];
  assign pp206 = a[12] & b[13];
  assign pp207 = a[12] & b[14];
  assign pp208 = a[12] & b[15];
  assign pp209 = a[13] & b[0];
  assign pp210 = a[13] & b[1];
  assign pp211 = a[13] & b[2];
  assign pp212 = a[13] & b[3];
  assign pp213 = a[13] & b[4];
  assign pp214 = a[13] & b[5];
  assign pp215 = a[13] & b[6];
  assign pp216 = a[13] & b[7];
  assign pp217 = a[13] & b[8];
  assign pp218 = a[13] & b[9];
  assign pp219 = a[13] & b[10];
  assign pp220 = a[13] & b[11];
  assign pp221 = a[13] & b[12];
  assign pp222 = a[13] & b[13];
  assign pp223 = a[13] & b[14];
  assign pp224 = a[13] & b[15];
  assign pp225 = a[14] & b[0];
  assign pp226 = a[14] & b[1];
  assign pp227 = a[14] & b[2];
  assign pp228 = a[14] & b[3];
  assign pp229 = a[14] & b[4];
  assign pp230 = a[14] & b[5];
  assign pp231 = a[14] & b[6];
  assign pp232 = a[14] & b[7];
  assign pp233 = a[14] & b[8];
  assign pp234 = a[14] & b[9];
  assign pp235 = a[14] & b[10];
  assign pp236 = a[14] & b[11];
  assign pp237 = a[14] & b[12];
  assign pp238 = a[14] & b[13];
  assign pp239 = a[14] & b[14];
  assign pp240 = a[14] & b[15];
  assign pp241 = a[15] & b[0];
  assign pp242 = a[15] & b[1];
  assign pp243 = a[15] & b[2];
  assign pp244 = a[15] & b[3];
  assign pp245 = a[15] & b[4];
  assign pp246 = a[15] & b[5];
  assign pp247 = a[15] & b[6];
  assign pp248 = a[15] & b[7];
  assign pp249 = a[15] & b[8];
  assign pp250 = a[15] & b[9];
  assign pp251 = a[15] & b[10];
  assign pp252 = a[15] & b[11];
  assign pp253 = a[15] & b[12];
  assign pp254 = a[15] & b[13];
  assign pp255 = a[15] & b[14];
  assign pp256 = a[15] & b[15];
  assign t257 = pp14 ^ pp29;
  assign t258 = pp14 & pp29;
  assign t259 = pp15 ^ pp30 ^ pp45;
  assign t260 = (pp15 & pp30) | (pp15 & pp45) | (pp30 & pp45);
  assign t261 = pp60 ^ pp75;
  assign t262 = pp60 & pp75;
  assign t263 = pp16 ^ pp31 ^ pp46;
  assign t264 = (pp16 & pp31) | (pp16 & pp46) | (pp31 & pp46);
  assign t265 = pp61 ^ pp76 ^ pp91;
  assign t266 = (pp61 & pp76) | (pp61 & pp91) | (pp76 & pp91);
  assign t267 = pp106 ^ pp121;
  assign t268 = pp106 & pp121;
  assign t269 = pp32 ^ pp47 ^ pp62;
  assign t270 = (pp32 & pp47) | (pp32 & pp62) | (pp47 & pp62);
  assign t271 = pp77 ^ pp92 ^ pp107;
  assign t272 = (pp77 & pp92) | (pp77 & pp107) | (pp92 & pp107);
  assign t273 = pp122 ^ pp137;
  assign t274 = pp122 & pp137;
  assign t275 = pp48 ^ pp63 ^ pp78;
  assign t276 = (pp48 & pp63) | (pp48 & pp78) | (pp63 & pp78);
  assign t277 = pp93 ^ pp108 ^ pp123;
  assign t278 = (pp93 & pp108) | (pp93 & pp123) | (pp108 & pp123);
  assign t279 = pp64 ^ pp79 ^ pp94;
  assign t280 = (pp64 & pp79) | (pp64 & pp94) | (pp79 & pp94);
  assign t281 = pp10 ^ pp25;
  assign t282 = pp10 & pp25;
  assign t283 = pp11 ^ pp26 ^ pp41;
  assign t284 = (pp11 & pp26) | (pp11 & pp41) | (pp26 & pp41);
  assign t285 = pp56 ^ pp71;
  assign t286 = pp56 & pp71;
  assign t287 = pp12 ^ pp27 ^ pp42;
  assign t288 = (pp12 & pp27) | (pp12 & pp42) | (pp27 & pp42);
  assign t289 = pp57 ^ pp72 ^ pp87;
  assign t290 = (pp57 & pp72) | (pp57 & pp87) | (pp72 & pp87);
  assign t291 = pp102 ^ pp117;
  assign t292 = pp102 & pp117;
  assign t293 = pp13 ^ pp28 ^ pp43;
  assign t294 = (pp13 & pp28) | (pp13 & pp43) | (pp28 & pp43);
  assign t295 = pp58 ^ pp73 ^ pp88;
  assign t296 = (pp58 & pp73) | (pp58 & pp88) | (pp73 & pp88);
  assign t297 = pp103 ^ pp118 ^ pp133;
  assign t298 = (pp103 & pp118) | (pp103 & pp133) | (pp118 & pp133);
  assign t299 = pp148 ^ pp163;
  assign t300 = pp148 & pp163;
  assign t301 = t257 ^ pp44 ^ pp59;
  assign t302 = (t257 & pp44) | (t257 & pp59) | (pp44 & pp59);
  assign t303 = pp74 ^ pp89 ^ pp104;
  assign t304 = (pp74 & pp89) | (pp74 & pp104) | (pp89 & pp104);
  assign t305 = pp119 ^ pp134 ^ pp149;
  assign t306 = (pp119 & pp134) | (pp119 & pp149) | (pp134 & pp149);
  assign t307 = pp164 ^ pp179 ^ pp194;
  assign t308 = (pp164 & pp179) | (pp164 & pp194) | (pp179 & pp194);
  assign t309 = t258 ^ t259 ^ t261;
  assign t310 = (t258 & t259) | (t258 & t261) | (t259 & t261);
  assign t311 = pp90 ^ pp105 ^ pp120;
  assign t312 = (pp90 & pp105) | (pp90 & pp120) | (pp105 & pp120);
  assign t313 = pp135 ^ pp150 ^ pp165;
  assign t314 = (pp135 & pp150) | (pp135 & pp165) | (pp150 & pp165);
  assign t315 = pp180 ^ pp195 ^ pp210;
  assign t316 = (pp180 & pp195) | (pp180 & pp210) | (pp195 & pp210);
  assign t317 = t260 ^ t262 ^ t263;
  assign t318 = (t260 & t262) | (t260 & t263) | (t262 & t263);
  assign t319 = t265 ^ t267 ^ pp136;
  assign t320 = (t265 & t267) | (t265 & pp136) | (t267 & pp136);
  assign t321 = pp151 ^ pp166 ^ pp181;
  assign t322 = (pp151 & pp166) | (pp151 & pp181) | (pp166 & pp181);
  assign t323 = pp196 ^ pp211 ^ pp226;
  assign t324 = (pp196 & pp211) | (pp196 & pp226) | (pp211 & pp226);
  assign t325 = t264 ^ t266 ^ t268;
  assign t326 = (t264 & t266) | (t264 & t268) | (t266 & t268);
  assign t327 = t269 ^ t271 ^ t273;
  assign t328 = (t269 & t271) | (t269 & t273) | (t271 & t273);
  assign t329 = pp152 ^ pp167 ^ pp182;
  assign t330 = (pp152 & pp167) | (pp152 & pp182) | (pp167 & pp182);
  assign t331 = pp197 ^ pp212 ^ pp227;
  assign t332 = (pp197 & pp212) | (pp197 & pp227) | (pp212 & pp227);
  assign t333 = t270 ^ t272 ^ t274;
  assign t334 = (t270 & t272) | (t270 & t274) | (t272 & t274);
  assign t335 = t275 ^ t277 ^ pp138;
  assign t336 = (t275 & t277) | (t275 & pp138) | (t277 & pp138);
  assign t337 = pp153 ^ pp168 ^ pp183;
  assign t338 = (pp153 & pp168) | (pp153 & pp183) | (pp168 & pp183);
  assign t339 = pp198 ^ pp213 ^ pp228;
  assign t340 = (pp198 & pp213) | (pp198 & pp228) | (pp213 & pp228);
  assign t341 = t276 ^ t278 ^ t279;
  assign t342 = (t276 & t278) | (t276 & t279) | (t278 & t279);
  assign t343 = pp109 ^ pp124 ^ pp139;
  assign t344 = (pp109 & pp124) | (pp109 & pp139) | (pp124 & pp139);
  assign t345 = pp154 ^ pp169 ^ pp184;
  assign t346 = (pp154 & pp169) | (pp154 & pp184) | (pp169 & pp184);
  assign t347 = pp199 ^ pp214 ^ pp229;
  assign t348 = (pp199 & pp214) | (pp199 & pp229) | (pp214 & pp229);
  assign t349 = t280 ^ pp80 ^ pp95;
  assign t350 = (t280 & pp80) | (t280 & pp95) | (pp80 & pp95);
  assign t351 = pp110 ^ pp125 ^ pp140;
  assign t352 = (pp110 & pp125) | (pp110 & pp140) | (pp125 & pp140);
  assign t353 = pp155 ^ pp170 ^ pp185;
  assign t354 = (pp155 & pp170) | (pp155 & pp185) | (pp170 & pp185);
  assign t355 = pp200 ^ pp215 ^ pp230;
  assign t356 = (pp200 & pp215) | (pp200 & pp230) | (pp215 & pp230);
  assign t357 = pp96 ^ pp111 ^ pp126;
  assign t358 = (pp96 & pp111) | (pp96 & pp126) | (pp111 & pp126);
  assign t359 = pp141 ^ pp156 ^ pp171;
  assign t360 = (pp141 & pp156) | (pp141 & pp171) | (pp156 & pp171);
  assign t361 = pp186 ^ pp201 ^ pp216;
  assign t362 = (pp186 & pp201) | (pp186 & pp216) | (pp201 & pp216);
  assign t363 = pp112 ^ pp127 ^ pp142;
  assign t364 = (pp112 & pp127) | (pp112 & pp142) | (pp127 & pp142);
  assign t365 = pp157 ^ pp172 ^ pp187;
  assign t366 = (pp157 & pp172) | (pp157 & pp187) | (pp172 & pp187);
  assign t367 = pp128 ^ pp143 ^ pp158;
  assign t368 = (pp128 & pp143) | (pp128 & pp158) | (pp143 & pp158);
  assign t369 = pp7 ^ pp22;
  assign t370 = pp7 & pp22;
  assign t371 = pp8 ^ pp23 ^ pp38;
  assign t372 = (pp8 & pp23) | (pp8 & pp38) | (pp23 & pp38);
  assign t373 = pp53 ^ pp68;
  assign t374 = pp53 & pp68;
  assign t375 = pp9 ^ pp24 ^ pp39;
  assign t376 = (pp9 & pp24) | (pp9 & pp39) | (pp24 & pp39);
  assign t377 = pp54 ^ pp69 ^ pp84;
  assign t378 = (pp54 & pp69) | (pp54 & pp84) | (pp69 & pp84);
  assign t379 = pp99 ^ pp114;
  assign t380 = pp99 & pp114;
  assign t381 = t281 ^ pp40 ^ pp55;
  assign t382 = (t281 & pp40) | (t281 & pp55) | (pp40 & pp55);
  assign t383 = pp70 ^ pp85 ^ pp100;
  assign t384 = (pp70 & pp85) | (pp70 & pp100) | (pp85 & pp100);
  assign t385 = pp115 ^ pp130 ^ pp145;
  assign t386 = (pp115 & pp130) | (pp115 & pp145) | (pp130 & pp145);
  assign t387 = t282 ^ t283 ^ t285;
  assign t388 = (t282 & t283) | (t282 & t285) | (t283 & t285);
  assign t389 = pp86 ^ pp101 ^ pp116;
  assign t390 = (pp86 & pp101) | (pp86 & pp116) | (pp101 & pp116);
  assign t391 = pp131 ^ pp146 ^ pp161;
  assign t392 = (pp131 & pp146) | (pp131 & pp161) | (pp146 & pp161);
  assign t393 = t284 ^ t286 ^ t287;
  assign t394 = (t284 & t286) | (t284 & t287) | (t286 & t287);
  assign t395 = t289 ^ t291 ^ pp132;
  assign t396 = (t289 & t291) | (t289 & pp132) | (t291 & pp132);
  assign t397 = pp147 ^ pp162 ^ pp177;
  assign t398 = (pp147 & pp162) | (pp147 & pp177) | (pp162 & pp177);
  assign t399 = t288 ^ t290 ^ t292;
  assign t400 = (t288 & t290) | (t288 & t292) | (t290 & t292);
  assign t401 = t293 ^ t295 ^ t297;
  assign t402 = (t293 & t295) | (t293 & t297) | (t295 & t297);
  assign t403 = t299 ^ pp178 ^ pp193;
  assign t404 = (t299 & pp178) | (t299 & pp193) | (pp178 & pp193);
  assign t405 = t294 ^ t296 ^ t298;
  assign t406 = (t294 & t296) | (t294 & t298) | (t296 & t298);
  assign t407 = t300 ^ t301 ^ t303;
  assign t408 = (t300 & t301) | (t300 & t303) | (t301 & t303);
  assign t409 = t305 ^ t307 ^ pp209;
  assign t410 = (t305 & t307) | (t305 & pp209) | (t307 & pp209);
  assign t411 = t302 ^ t304 ^ t306;
  assign t412 = (t302 & t304) | (t302 & t306) | (t304 & t306);
  assign t413 = t308 ^ t309 ^ t311;
  assign t414 = (t308 & t309) | (t308 & t311) | (t309 & t311);
  assign t415 = t313 ^ t315 ^ pp225;
  assign t416 = (t313 & t315) | (t313 & pp225) | (t315 & pp225);
  assign t417 = t310 ^ t312 ^ t314;
  assign t418 = (t310 & t312) | (t310 & t314) | (t312 & t314);
  assign t419 = t316 ^ t317 ^ t319;
  assign t420 = (t316 & t317) | (t316 & t319) | (t317 & t319);
  assign t421 = t321 ^ t323 ^ pp241;
  assign t422 = (t321 & t323) | (t321 & pp241) | (t323 & pp241);
  assign t423 = t318 ^ t320 ^ t322;
  assign t424 = (t318 & t320) | (t318 & t322) | (t320 & t322);
  assign t425 = t324 ^ t325 ^ t327;
  assign t426 = (t324 & t325) | (t324 & t327) | (t325 & t327);
  assign t427 = t329 ^ t331 ^ pp242;
  assign t428 = (t329 & t331) | (t329 & pp242) | (t331 & pp242);
  assign t429 = t326 ^ t328 ^ t330;
  assign t430 = (t326 & t328) | (t326 & t330) | (t328 & t330);
  assign t431 = t332 ^ t333 ^ t335;
  assign t432 = (t332 & t333) | (t332 & t335) | (t333 & t335);
  assign t433 = t337 ^ t339 ^ pp243;
  assign t434 = (t337 & t339) | (t337 & pp243) | (t339 & pp243);
  assign t435 = t334 ^ t336 ^ t338;
  assign t436 = (t334 & t336) | (t334 & t338) | (t336 & t338);
  assign t437 = t340 ^ t341 ^ t343;
  assign t438 = (t340 & t341) | (t340 & t343) | (t341 & t343);
  assign t439 = t345 ^ t347 ^ pp244;
  assign t440 = (t345 & t347) | (t345 & pp244) | (t347 & pp244);
  assign t441 = t342 ^ t344 ^ t346;
  assign t442 = (t342 & t344) | (t342 & t346) | (t344 & t346);
  assign t443 = t348 ^ t349 ^ t351;
  assign t444 = (t348 & t349) | (t348 & t351) | (t349 & t351);
  assign t445 = t353 ^ t355 ^ pp245;
  assign t446 = (t353 & t355) | (t353 & pp245) | (t355 & pp245);
  assign t447 = t350 ^ t352 ^ t354;
  assign t448 = (t350 & t352) | (t350 & t354) | (t352 & t354);
  assign t449 = t356 ^ t357 ^ t359;
  assign t450 = (t356 & t357) | (t356 & t359) | (t357 & t359);
  assign t451 = t361 ^ pp231 ^ pp246;
  assign t452 = (t361 & pp231) | (t361 & pp246) | (pp231 & pp246);
  assign t453 = t358 ^ t360 ^ t362;
  assign t454 = (t358 & t360) | (t358 & t362) | (t360 & t362);
  assign t455 = t363 ^ t365 ^ pp202;
  assign t456 = (t363 & t365) | (t363 & pp202) | (t365 & pp202);
  assign t457 = pp217 ^ pp232 ^ pp247;
  assign t458 = (pp217 & pp232) | (pp217 & pp247) | (pp232 & pp247);
  assign t459 = t364 ^ t366 ^ t367;
  assign t460 = (t364 & t366) | (t364 & t367) | (t366 & t367);
  assign t461 = pp173 ^ pp188 ^ pp203;
  assign t462 = (pp173 & pp188) | (pp173 & pp203) | (pp188 & pp203);
  assign t463 = pp218 ^ pp233 ^ pp248;
  assign t464 = (pp218 & pp233) | (pp218 & pp248) | (pp233 & pp248);
  assign t465 = t368 ^ pp144 ^ pp159;
  assign t466 = (t368 & pp144) | (t368 & pp159) | (pp144 & pp159);
  assign t467 = pp174 ^ pp189 ^ pp204;
  assign t468 = (pp174 & pp189) | (pp174 & pp204) | (pp189 & pp204);
  assign t469 = pp219 ^ pp234 ^ pp249;
  assign t470 = (pp219 & pp234) | (pp219 & pp249) | (pp234 & pp249);
  assign t471 = pp160 ^ pp175 ^ pp190;
  assign t472 = (pp160 & pp175) | (pp160 & pp190) | (pp175 & pp190);
  assign t473 = pp205 ^ pp220 ^ pp235;
  assign t474 = (pp205 & pp220) | (pp205 & pp235) | (pp220 & pp235);
  assign t475 = pp176 ^ pp191 ^ pp206;
  assign t476 = (pp176 & pp191) | (pp176 & pp206) | (pp191 & pp206);
  assign t477 = pp5 ^ pp20;
  assign t478 = pp5 & pp20;
  assign t479 = pp6 ^ pp21 ^ pp36;
  assign t480 = (pp6 & pp21) | (pp6 & pp36) | (pp21 & pp36);
  assign t481 = pp51 ^ pp66;
  assign t482 = pp51 & pp66;
  assign t483 = t369 ^ pp37 ^ pp52;
  assign t484 = (t369 & pp37) | (t369 & pp52) | (pp37 & pp52);
  assign t485 = pp67 ^ pp82 ^ pp97;
  assign t486 = (pp67 & pp82) | (pp67 & pp97) | (pp82 & pp97);
  assign t487 = t370 ^ t371 ^ t373;
  assign t488 = (t370 & t371) | (t370 & t373) | (t371 & t373);
  assign t489 = pp83 ^ pp98 ^ pp113;
  assign t490 = (pp83 & pp98) | (pp83 & pp113) | (pp98 & pp113);
  assign t491 = t372 ^ t374 ^ t375;
  assign t492 = (t372 & t374) | (t372 & t375) | (t374 & t375);
  assign t493 = t377 ^ t379 ^ pp129;
  assign t494 = (t377 & t379) | (t377 & pp129) | (t379 & pp129);
  assign t495 = t376 ^ t378 ^ t380;
  assign t496 = (t376 & t378) | (t376 & t380) | (t378 & t380);
  assign t497 = t381 ^ t383 ^ t385;
  assign t498 = (t381 & t383) | (t381 & t385) | (t383 & t385);
  assign t499 = t382 ^ t384 ^ t386;
  assign t500 = (t382 & t384) | (t382 & t386) | (t384 & t386);
  assign t501 = t387 ^ t389 ^ t391;
  assign t502 = (t387 & t389) | (t387 & t391) | (t389 & t391);
  assign t503 = t388 ^ t390 ^ t392;
  assign t504 = (t388 & t390) | (t388 & t392) | (t390 & t392);
  assign t505 = t393 ^ t395 ^ t397;
  assign t506 = (t393 & t395) | (t393 & t397) | (t395 & t397);
  assign t507 = t394 ^ t396 ^ t398;
  assign t508 = (t394 & t396) | (t394 & t398) | (t396 & t398);
  assign t509 = t399 ^ t401 ^ t403;
  assign t510 = (t399 & t401) | (t399 & t403) | (t401 & t403);
  assign t511 = t400 ^ t402 ^ t404;
  assign t512 = (t400 & t402) | (t400 & t404) | (t402 & t404);
  assign t513 = t405 ^ t407 ^ t409;
  assign t514 = (t405 & t407) | (t405 & t409) | (t407 & t409);
  assign t515 = t406 ^ t408 ^ t410;
  assign t516 = (t406 & t408) | (t406 & t410) | (t408 & t410);
  assign t517 = t411 ^ t413 ^ t415;
  assign t518 = (t411 & t413) | (t411 & t415) | (t413 & t415);
  assign t519 = t412 ^ t414 ^ t416;
  assign t520 = (t412 & t414) | (t412 & t416) | (t414 & t416);
  assign t521 = t417 ^ t419 ^ t421;
  assign t522 = (t417 & t419) | (t417 & t421) | (t419 & t421);
  assign t523 = t418 ^ t420 ^ t422;
  assign t524 = (t418 & t420) | (t418 & t422) | (t420 & t422);
  assign t525 = t423 ^ t425 ^ t427;
  assign t526 = (t423 & t425) | (t423 & t427) | (t425 & t427);
  assign t527 = t424 ^ t426 ^ t428;
  assign t528 = (t424 & t426) | (t424 & t428) | (t426 & t428);
  assign t529 = t429 ^ t431 ^ t433;
  assign t530 = (t429 & t431) | (t429 & t433) | (t431 & t433);
  assign t531 = t430 ^ t432 ^ t434;
  assign t532 = (t430 & t432) | (t430 & t434) | (t432 & t434);
  assign t533 = t435 ^ t437 ^ t439;
  assign t534 = (t435 & t437) | (t435 & t439) | (t437 & t439);
  assign t535 = t436 ^ t438 ^ t440;
  assign t536 = (t436 & t438) | (t436 & t440) | (t438 & t440);
  assign t537 = t441 ^ t443 ^ t445;
  assign t538 = (t441 & t443) | (t441 & t445) | (t443 & t445);
  assign t539 = t442 ^ t444 ^ t446;
  assign t540 = (t442 & t444) | (t442 & t446) | (t444 & t446);
  assign t541 = t447 ^ t449 ^ t451;
  assign t542 = (t447 & t449) | (t447 & t451) | (t449 & t451);
  assign t543 = t448 ^ t450 ^ t452;
  assign t544 = (t448 & t450) | (t448 & t452) | (t450 & t452);
  assign t545 = t453 ^ t455 ^ t457;
  assign t546 = (t453 & t455) | (t453 & t457) | (t455 & t457);
  assign t547 = t454 ^ t456 ^ t458;
  assign t548 = (t454 & t456) | (t454 & t458) | (t456 & t458);
  assign t549 = t459 ^ t461 ^ t463;
  assign t550 = (t459 & t461) | (t459 & t463) | (t461 & t463);
  assign t551 = t460 ^ t462 ^ t464;
  assign t552 = (t460 & t462) | (t460 & t464) | (t462 & t464);
  assign t553 = t465 ^ t467 ^ t469;
  assign t554 = (t465 & t467) | (t465 & t469) | (t467 & t469);
  assign t555 = t466 ^ t468 ^ t470;
  assign t556 = (t466 & t468) | (t466 & t470) | (t468 & t470);
  assign t557 = t471 ^ t473 ^ pp250;
  assign t558 = (t471 & t473) | (t471 & pp250) | (t473 & pp250);
  assign t559 = t472 ^ t474 ^ t475;
  assign t560 = (t472 & t474) | (t472 & t475) | (t474 & t475);
  assign t561 = pp221 ^ pp236 ^ pp251;
  assign t562 = (pp221 & pp236) | (pp221 & pp251) | (pp236 & pp251);
  assign t563 = t476 ^ pp192 ^ pp207;
  assign t564 = (t476 & pp192) | (t476 & pp207) | (pp192 & pp207);
  assign t565 = pp222 ^ pp237 ^ pp252;
  assign t566 = (pp222 & pp237) | (pp222 & pp252) | (pp237 & pp252);
  assign t567 = pp208 ^ pp223 ^ pp238;
  assign t568 = (pp208 & pp223) | (pp208 & pp238) | (pp223 & pp238);
  assign t569 = pp4 ^ pp19;
  assign t570 = pp4 & pp19;
  assign t571 = t477 ^ pp35 ^ pp50;
  assign t572 = (t477 & pp35) | (t477 & pp50) | (pp35 & pp50);
  assign t573 = t478 ^ t479 ^ t481;
  assign t574 = (t478 & t479) | (t478 & t481) | (t479 & t481);
  assign t575 = t480 ^ t482 ^ t483;
  assign t576 = (t480 & t482) | (t480 & t483) | (t482 & t483);
  assign t577 = t484 ^ t486 ^ t487;
  assign t578 = (t484 & t486) | (t484 & t487) | (t486 & t487);
  assign t579 = t488 ^ t490 ^ t491;
  assign t580 = (t488 & t490) | (t488 & t491) | (t490 & t491);
  assign t581 = t492 ^ t494 ^ t495;
  assign t582 = (t492 & t494) | (t492 & t495) | (t494 & t495);
  assign t583 = t496 ^ t498 ^ t499;
  assign t584 = (t496 & t498) | (t496 & t499) | (t498 & t499);
  assign t585 = t500 ^ t502 ^ t503;
  assign t586 = (t500 & t502) | (t500 & t503) | (t502 & t503);
  assign t587 = t504 ^ t506 ^ t507;
  assign t588 = (t504 & t506) | (t504 & t507) | (t506 & t507);
  assign t589 = t508 ^ t510 ^ t511;
  assign t590 = (t508 & t510) | (t508 & t511) | (t510 & t511);
  assign t591 = t512 ^ t514 ^ t515;
  assign t592 = (t512 & t514) | (t512 & t515) | (t514 & t515);
  assign t593 = t516 ^ t518 ^ t519;
  assign t594 = (t516 & t518) | (t516 & t519) | (t518 & t519);
  assign t595 = t520 ^ t522 ^ t523;
  assign t596 = (t520 & t522) | (t520 & t523) | (t522 & t523);
  assign t597 = t524 ^ t526 ^ t527;
  assign t598 = (t524 & t526) | (t524 & t527) | (t526 & t527);
  assign t599 = t528 ^ t530 ^ t531;
  assign t600 = (t528 & t530) | (t528 & t531) | (t530 & t531);
  assign t601 = t532 ^ t534 ^ t535;
  assign t602 = (t532 & t534) | (t532 & t535) | (t534 & t535);
  assign t603 = t536 ^ t538 ^ t539;
  assign t604 = (t536 & t538) | (t536 & t539) | (t538 & t539);
  assign t605 = t540 ^ t542 ^ t543;
  assign t606 = (t540 & t542) | (t540 & t543) | (t542 & t543);
  assign t607 = t544 ^ t546 ^ t547;
  assign t608 = (t544 & t546) | (t544 & t547) | (t546 & t547);
  assign t609 = t548 ^ t550 ^ t551;
  assign t610 = (t548 & t550) | (t548 & t551) | (t550 & t551);
  assign t611 = t552 ^ t554 ^ t555;
  assign t612 = (t552 & t554) | (t552 & t555) | (t554 & t555);
  assign t613 = t556 ^ t558 ^ t559;
  assign t614 = (t556 & t558) | (t556 & t559) | (t558 & t559);
  assign t615 = t560 ^ t562 ^ t563;
  assign t616 = (t560 & t562) | (t560 & t563) | (t562 & t563);
  assign t617 = t564 ^ t566 ^ t567;
  assign t618 = (t564 & t566) | (t564 & t567) | (t566 & t567);
  assign t619 = t568 ^ pp224 ^ pp239;
  assign t620 = (t568 & pp224) | (t568 & pp239) | (pp224 & pp239);
  assign t621 = pp3 ^ pp18;
  assign t622 = pp3 & pp18;
  assign t623 = t569 ^ pp34 ^ pp49;
  assign t624 = (t569 & pp34) | (t569 & pp49) | (pp34 & pp49);
  assign t625 = t570 ^ t571 ^ pp65;
  assign t626 = (t570 & t571) | (t570 & pp65) | (t571 & pp65);
  assign t627 = t572 ^ t573 ^ pp81;
  assign t628 = (t572 & t573) | (t572 & pp81) | (t573 & pp81);
  assign t629 = t574 ^ t575 ^ t485;
  assign t630 = (t574 & t575) | (t574 & t485) | (t575 & t485);
  assign t631 = t576 ^ t577 ^ t489;
  assign t632 = (t576 & t577) | (t576 & t489) | (t577 & t489);
  assign t633 = t578 ^ t579 ^ t493;
  assign t634 = (t578 & t579) | (t578 & t493) | (t579 & t493);
  assign t635 = t580 ^ t581 ^ t497;
  assign t636 = (t580 & t581) | (t580 & t497) | (t581 & t497);
  assign t637 = t582 ^ t583 ^ t501;
  assign t638 = (t582 & t583) | (t582 & t501) | (t583 & t501);
  assign t639 = t584 ^ t585 ^ t505;
  assign t640 = (t584 & t585) | (t584 & t505) | (t585 & t505);
  assign t641 = t586 ^ t587 ^ t509;
  assign t642 = (t586 & t587) | (t586 & t509) | (t587 & t509);
  assign t643 = t588 ^ t589 ^ t513;
  assign t644 = (t588 & t589) | (t588 & t513) | (t589 & t513);
  assign t645 = t590 ^ t591 ^ t517;
  assign t646 = (t590 & t591) | (t590 & t517) | (t591 & t517);
  assign t647 = t592 ^ t593 ^ t521;
  assign t648 = (t592 & t593) | (t592 & t521) | (t593 & t521);
  assign t649 = t594 ^ t595 ^ t525;
  assign t650 = (t594 & t595) | (t594 & t525) | (t595 & t525);
  assign t651 = t596 ^ t597 ^ t529;
  assign t652 = (t596 & t597) | (t596 & t529) | (t597 & t529);
  assign t653 = t598 ^ t599 ^ t533;
  assign t654 = (t598 & t599) | (t598 & t533) | (t599 & t533);
  assign t655 = t600 ^ t601 ^ t537;
  assign t656 = (t600 & t601) | (t600 & t537) | (t601 & t537);
  assign t657 = t602 ^ t603 ^ t541;
  assign t658 = (t602 & t603) | (t602 & t541) | (t603 & t541);
  assign t659 = t604 ^ t605 ^ t545;
  assign t660 = (t604 & t605) | (t604 & t545) | (t605 & t545);
  assign t661 = t606 ^ t607 ^ t549;
  assign t662 = (t606 & t607) | (t606 & t549) | (t607 & t549);
  assign t663 = t608 ^ t609 ^ t553;
  assign t664 = (t608 & t609) | (t608 & t553) | (t609 & t553);
  assign t665 = t610 ^ t611 ^ t557;
  assign t666 = (t610 & t611) | (t610 & t557) | (t611 & t557);
  assign t667 = t612 ^ t613 ^ t561;
  assign t668 = (t612 & t613) | (t612 & t561) | (t613 & t561);
  assign t669 = t614 ^ t615 ^ t565;
  assign t670 = (t614 & t615) | (t614 & t565) | (t615 & t565);
  assign t671 = t616 ^ t617 ^ pp253;
  assign t672 = (t616 & t617) | (t616 & pp253) | (t617 & pp253);
  assign t673 = t618 ^ t619 ^ pp254;
  assign t674 = (t618 & t619) | (t618 & pp254) | (t619 & pp254);
  assign t675 = t620 ^ pp240 ^ pp255;
  assign t676 = (t620 & pp240) | (t620 & pp255) | (pp240 & pp255);
  logic [31:0] row_s, row_c;
  assign row_s = {1'b0, t676, t674, t672, t670, t668, t666, t664, t662, t660, t658, t656, t654, t652, t650, t648, t646, t644, t642, t640, t638, t636, t634, t632, t630, t628, t626, t624, t622, t621, pp2, pp1};
  assign row_c = {1'b0, pp256, t675, t673, t671, t669, t667, t665, t663, t661, t659, t657, t655, t653, t651, t649, t647, t645, t643, t641, t639, t637, t635, t633, t631, t629, t627, t625, t623, pp33, pp17, 1'b0};
  logic [1:0] cc; assign cc[0] = 1'b0;
  logic ci0; assign ci0 = cc[0] & ~(1'b1);
  fam_adder_ripple_carry #(.W(32), .CHUNK(1), .FORM(2)) u_cpa0 (.a(row_s[31:0]), .b(row_c[31:0]), .cin(ci0), .s(p[31:0]), .cout(cc[1]));
endmodule




module fam_prefix_arrival_0_0_0_1_1_1_1_1_1_2_2_2_2_2_2_3_3_3_3_3_3_4_4_4_4_4_4_5_5_5_5_5_5_6_6_6_w36 (input logic [35:0] a, input logic [35:0] b, input logic cin,
  output logic [35:0] s, output logic cout);
  // prefix graph: {'n': 36, 'levels': 8, 'size': 114, 'fanout': 5, 'tracks': 5, 'exact_split': True, 'valency': 2}
  logic [35:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [35:0] g0, p0;
  assign g0 = {gi[35:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_1_2, P_1_2, G_3_4, P_3_4, G_4_5, P_4_5, G_5_6, P_5_6, G_6_7, P_6_7, G_7_8, P_7_8, G_9_10, P_9_10, G_10_11, P_10_11, G_11_12, P_11_12, G_12_13, P_12_13, G_13_14, P_13_14, G_15_16, P_15_16, G_16_17, P_16_17, G_17_18, P_17_18, G_18_19, P_18_19, G_19_20, P_19_20, G_21_22, P_21_22, G_22_23, P_22_23, G_23_24, P_23_24, G_24_25, P_24_25, G_25_26, P_25_26, G_27_28, P_27_28, G_28_29, P_28_29, G_29_30, P_29_30, G_30_31, P_30_31, G_31_32, P_31_32, G_33_34, P_33_34, G_34_35, P_34_35, G_0_2, G_1_3, P_1_3, G_3_6, P_3_6, G_4_7, P_4_7, G_5_8, P_5_8, G_7_9, P_7_9, G_9_12, P_9_12, G_10_13, P_10_13, G_11_14, P_11_14, G_13_15, P_13_15, G_15_18, P_15_18, G_16_19, P_16_19, G_17_20, P_17_20, G_19_21, P_19_21, G_21_24, P_21_24, G_22_25, P_22_25, G_23_26, P_23_26, G_25_27, P_25_27, G_27_30, P_27_30, G_28_31, P_28_31, G_29_32, P_29_32, G_31_33, P_31_33, G_0_3, G_0_4, G_1_5, P_1_5, G_0_6, G_3_9, P_3_9, G_5_10, P_5_10, G_7_11, P_7_11, G_9_15, P_9_15, G_11_16, P_11_16, G_13_17, P_13_17, G_15_21, P_15_21, G_17_22, P_17_22, G_19_23, P_19_23, G_21_27, P_21_27, G_23_28, P_23_28, G_25_29, P_25_29, G_27_33, P_27_33, G_29_34, P_29_34, G_31_35, P_31_35, G_0_5, G_0_7, G_0_8, G_0_9, G_0_10, G_0_11, G_3_13, P_3_13, G_5_14, P_5_14, G_9_19, P_9_19, G_11_20, P_11_20, G_15_25, P_15_25, G_17_26, P_17_26, G_21_31, P_21_31, G_23_32, P_23_32, G_0_12, G_0_13, G_0_14, G_0_15, G_0_16, G_5_18, P_5_18, G_0_19, G_0_20, G_11_24, P_11_24, G_17_30, P_17_30, G_0_17, G_0_18, G_0_21, G_0_22, G_5_23, P_5_23, G_0_24, G_0_25, G_0_26, G_0_27, G_11_29, P_11_29, G_0_30, G_0_31, G_17_35, P_17_35, G_0_23, G_0_28, G_0_29, G_0_32, G_0_33, G_0_35, G_0_34;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_5_6 = g0[6] | (p0[6] & g0[5]);
  assign P_5_6 = p0[6] & p0[5];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_7_8 = g0[8] | (p0[8] & g0[7]);
  assign P_7_8 = p0[8] & p0[7];
  assign G_9_10 = g0[10] | (p0[10] & g0[9]);
  assign P_9_10 = p0[10] & p0[9];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_11_12 = g0[12] | (p0[12] & g0[11]);
  assign P_11_12 = p0[12] & p0[11];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_13_14 = g0[14] | (p0[14] & g0[13]);
  assign P_13_14 = p0[14] & p0[13];
  assign G_15_16 = g0[16] | (p0[16] & g0[15]);
  assign P_15_16 = p0[16] & p0[15];
  assign G_16_17 = g0[17] | (p0[17] & g0[16]);
  assign P_16_17 = p0[17] & p0[16];
  assign G_17_18 = g0[18] | (p0[18] & g0[17]);
  assign P_17_18 = p0[18] & p0[17];
  assign G_18_19 = g0[19] | (p0[19] & g0[18]);
  assign P_18_19 = p0[19] & p0[18];
  assign G_19_20 = g0[20] | (p0[20] & g0[19]);
  assign P_19_20 = p0[20] & p0[19];
  assign G_21_22 = g0[22] | (p0[22] & g0[21]);
  assign P_21_22 = p0[22] & p0[21];
  assign G_22_23 = g0[23] | (p0[23] & g0[22]);
  assign P_22_23 = p0[23] & p0[22];
  assign G_23_24 = g0[24] | (p0[24] & g0[23]);
  assign P_23_24 = p0[24] & p0[23];
  assign G_24_25 = g0[25] | (p0[25] & g0[24]);
  assign P_24_25 = p0[25] & p0[24];
  assign G_25_26 = g0[26] | (p0[26] & g0[25]);
  assign P_25_26 = p0[26] & p0[25];
  assign G_27_28 = g0[28] | (p0[28] & g0[27]);
  assign P_27_28 = p0[28] & p0[27];
  assign G_28_29 = g0[29] | (p0[29] & g0[28]);
  assign P_28_29 = p0[29] & p0[28];
  assign G_29_30 = g0[30] | (p0[30] & g0[29]);
  assign P_29_30 = p0[30] & p0[29];
  assign G_30_31 = g0[31] | (p0[31] & g0[30]);
  assign P_30_31 = p0[31] & p0[30];
  assign G_31_32 = g0[32] | (p0[32] & g0[31]);
  assign P_31_32 = p0[32] & p0[31];
  assign G_33_34 = g0[34] | (p0[34] & g0[33]);
  assign P_33_34 = p0[34] & p0[33];
  assign G_34_35 = g0[35] | (p0[35] & g0[34]);
  assign P_34_35 = p0[35] & p0[34];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_1_3 = g0[3] | (p0[3] & G_1_2);
  assign P_1_3 = p0[3] & P_1_2;
  assign G_3_6 = G_5_6 | (P_5_6 & G_3_4);
  assign P_3_6 = P_5_6 & P_3_4;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_5_8 = G_7_8 | (P_7_8 & G_5_6);
  assign P_5_8 = P_7_8 & P_5_6;
  assign G_7_9 = g0[9] | (p0[9] & G_7_8);
  assign P_7_9 = p0[9] & P_7_8;
  assign G_9_12 = G_11_12 | (P_11_12 & G_9_10);
  assign P_9_12 = P_11_12 & P_9_10;
  assign G_10_13 = G_12_13 | (P_12_13 & G_10_11);
  assign P_10_13 = P_12_13 & P_10_11;
  assign G_11_14 = G_13_14 | (P_13_14 & G_11_12);
  assign P_11_14 = P_13_14 & P_11_12;
  assign G_13_15 = g0[15] | (p0[15] & G_13_14);
  assign P_13_15 = p0[15] & P_13_14;
  assign G_15_18 = G_17_18 | (P_17_18 & G_15_16);
  assign P_15_18 = P_17_18 & P_15_16;
  assign G_16_19 = G_18_19 | (P_18_19 & G_16_17);
  assign P_16_19 = P_18_19 & P_16_17;
  assign G_17_20 = G_19_20 | (P_19_20 & G_17_18);
  assign P_17_20 = P_19_20 & P_17_18;
  assign G_19_21 = g0[21] | (p0[21] & G_19_20);
  assign P_19_21 = p0[21] & P_19_20;
  assign G_21_24 = G_23_24 | (P_23_24 & G_21_22);
  assign P_21_24 = P_23_24 & P_21_22;
  assign G_22_25 = G_24_25 | (P_24_25 & G_22_23);
  assign P_22_25 = P_24_25 & P_22_23;
  assign G_23_26 = G_25_26 | (P_25_26 & G_23_24);
  assign P_23_26 = P_25_26 & P_23_24;
  assign G_25_27 = g0[27] | (p0[27] & G_25_26);
  assign P_25_27 = p0[27] & P_25_26;
  assign G_27_30 = G_29_30 | (P_29_30 & G_27_28);
  assign P_27_30 = P_29_30 & P_27_28;
  assign G_28_31 = G_30_31 | (P_30_31 & G_28_29);
  assign P_28_31 = P_30_31 & P_28_29;
  assign G_29_32 = G_31_32 | (P_31_32 & G_29_30);
  assign P_29_32 = P_31_32 & P_29_30;
  assign G_31_33 = g0[33] | (p0[33] & G_31_32);
  assign P_31_33 = p0[33] & P_31_32;
  assign G_0_3 = G_1_3 | (P_1_3 & g0[0]);
  assign G_0_4 = G_3_4 | (P_3_4 & G_0_2);
  assign G_1_5 = G_4_5 | (P_4_5 & G_1_3);
  assign P_1_5 = P_4_5 & P_1_3;
  assign G_0_6 = G_3_6 | (P_3_6 & G_0_2);
  assign G_3_9 = G_7_9 | (P_7_9 & G_3_6);
  assign P_3_9 = P_7_9 & P_3_6;
  assign G_5_10 = G_9_10 | (P_9_10 & G_5_8);
  assign P_5_10 = P_9_10 & P_5_8;
  assign G_7_11 = G_10_11 | (P_10_11 & G_7_9);
  assign P_7_11 = P_10_11 & P_7_9;
  assign G_9_15 = G_13_15 | (P_13_15 & G_9_12);
  assign P_9_15 = P_13_15 & P_9_12;
  assign G_11_16 = G_15_16 | (P_15_16 & G_11_14);
  assign P_11_16 = P_15_16 & P_11_14;
  assign G_13_17 = G_16_17 | (P_16_17 & G_13_15);
  assign P_13_17 = P_16_17 & P_13_15;
  assign G_15_21 = G_19_21 | (P_19_21 & G_15_18);
  assign P_15_21 = P_19_21 & P_15_18;
  assign G_17_22 = G_21_22 | (P_21_22 & G_17_20);
  assign P_17_22 = P_21_22 & P_17_20;
  assign G_19_23 = G_22_23 | (P_22_23 & G_19_21);
  assign P_19_23 = P_22_23 & P_19_21;
  assign G_21_27 = G_25_27 | (P_25_27 & G_21_24);
  assign P_21_27 = P_25_27 & P_21_24;
  assign G_23_28 = G_27_28 | (P_27_28 & G_23_26);
  assign P_23_28 = P_27_28 & P_23_26;
  assign G_25_29 = G_28_29 | (P_28_29 & G_25_27);
  assign P_25_29 = P_28_29 & P_25_27;
  assign G_27_33 = G_31_33 | (P_31_33 & G_27_30);
  assign P_27_33 = P_31_33 & P_27_30;
  assign G_29_34 = G_33_34 | (P_33_34 & G_29_32);
  assign P_29_34 = P_33_34 & P_29_32;
  assign G_31_35 = G_34_35 | (P_34_35 & G_31_33);
  assign P_31_35 = P_34_35 & P_31_33;
  assign G_0_5 = G_1_5 | (P_1_5 & g0[0]);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_0_8 = G_5_8 | (P_5_8 & G_0_4);
  assign G_0_9 = G_3_9 | (P_3_9 & G_0_2);
  assign G_0_10 = G_5_10 | (P_5_10 & G_0_4);
  assign G_0_11 = G_7_11 | (P_7_11 & G_0_6);
  assign G_3_13 = G_10_13 | (P_10_13 & G_3_9);
  assign P_3_13 = P_10_13 & P_3_9;
  assign G_5_14 = G_11_14 | (P_11_14 & G_5_10);
  assign P_5_14 = P_11_14 & P_5_10;
  assign G_9_19 = G_16_19 | (P_16_19 & G_9_15);
  assign P_9_19 = P_16_19 & P_9_15;
  assign G_11_20 = G_17_20 | (P_17_20 & G_11_16);
  assign P_11_20 = P_17_20 & P_11_16;
  assign G_15_25 = G_22_25 | (P_22_25 & G_15_21);
  assign P_15_25 = P_22_25 & P_15_21;
  assign G_17_26 = G_23_26 | (P_23_26 & G_17_22);
  assign P_17_26 = P_23_26 & P_17_22;
  assign G_21_31 = G_28_31 | (P_28_31 & G_21_27);
  assign P_21_31 = P_28_31 & P_21_27;
  assign G_23_32 = G_29_32 | (P_29_32 & G_23_28);
  assign P_23_32 = P_29_32 & P_23_28;
  assign G_0_12 = G_9_12 | (P_9_12 & G_0_8);
  assign G_0_13 = G_3_13 | (P_3_13 & G_0_2);
  assign G_0_14 = G_5_14 | (P_5_14 & G_0_4);
  assign G_0_15 = G_9_15 | (P_9_15 & G_0_8);
  assign G_0_16 = G_11_16 | (P_11_16 & G_0_10);
  assign G_5_18 = G_15_18 | (P_15_18 & G_5_14);
  assign P_5_18 = P_15_18 & P_5_14;
  assign G_0_19 = G_9_19 | (P_9_19 & G_0_8);
  assign G_0_20 = G_11_20 | (P_11_20 & G_0_10);
  assign G_11_24 = G_21_24 | (P_21_24 & G_11_20);
  assign P_11_24 = P_21_24 & P_11_20;
  assign G_17_30 = G_27_30 | (P_27_30 & G_17_26);
  assign P_17_30 = P_27_30 & P_17_26;
  assign G_0_17 = G_13_17 | (P_13_17 & G_0_12);
  assign G_0_18 = G_5_18 | (P_5_18 & G_0_4);
  assign G_0_21 = G_15_21 | (P_15_21 & G_0_14);
  assign G_0_22 = G_17_22 | (P_17_22 & G_0_16);
  assign G_5_23 = G_19_23 | (P_19_23 & G_5_18);
  assign P_5_23 = P_19_23 & P_5_18;
  assign G_0_24 = G_11_24 | (P_11_24 & G_0_10);
  assign G_0_25 = G_15_25 | (P_15_25 & G_0_14);
  assign G_0_26 = G_17_26 | (P_17_26 & G_0_16);
  assign G_0_27 = G_21_27 | (P_21_27 & G_0_20);
  assign G_11_29 = G_25_29 | (P_25_29 & G_11_24);
  assign P_11_29 = P_25_29 & P_11_24;
  assign G_0_30 = G_17_30 | (P_17_30 & G_0_16);
  assign G_0_31 = G_21_31 | (P_21_31 & G_0_20);
  assign G_17_35 = G_31_35 | (P_31_35 & G_17_30);
  assign P_17_35 = P_31_35 & P_17_30;
  assign G_0_23 = G_5_23 | (P_5_23 & G_0_4);
  assign G_0_28 = G_23_28 | (P_23_28 & G_0_22);
  assign G_0_29 = G_11_29 | (P_11_29 & G_0_10);
  assign G_0_32 = G_23_32 | (P_23_32 & G_0_22);
  assign G_0_33 = G_27_33 | (P_27_33 & G_0_26);
  assign G_0_35 = G_17_35 | (P_17_35 & G_0_16);
  assign G_0_34 = G_29_34 | (P_29_34 & G_0_28);
  logic [36:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign c[15] = G_0_14;
  assign c[16] = G_0_15;
  assign c[17] = G_0_16;
  assign c[18] = G_0_17;
  assign c[19] = G_0_18;
  assign c[20] = G_0_19;
  assign c[21] = G_0_20;
  assign c[22] = G_0_21;
  assign c[23] = G_0_22;
  assign c[24] = G_0_23;
  assign c[25] = G_0_24;
  assign c[26] = G_0_25;
  assign c[27] = G_0_26;
  assign c[28] = G_0_27;
  assign c[29] = G_0_28;
  assign c[30] = G_0_29;
  assign c[31] = G_0_30;
  assign c[32] = G_0_31;
  assign c[33] = G_0_32;
  assign c[34] = G_0_33;
  assign c[35] = G_0_34;
  assign c[36] = G_0_35;
  assign s = pi_ ^ c[35:0];
  assign cout = c[36];
endmodule



module fam_prefix_arrival_0_0_1_1_1_1_2_2_2_3_3_3_4_4_4_4_5_5_w18 (input logic [17:0] a, input logic [17:0] b, input logic cin,
  output logic [17:0] s, output logic cout);
  // prefix graph: {'n': 18, 'levels': 6, 'size': 42, 'fanout': 4, 'tracks': 3, 'exact_split': True, 'valency': 2}
  logic [17:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [17:0] g0, p0;
  assign g0 = {gi[17:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_2_3, P_2_3, G_3_4, P_3_4, G_4_5, P_4_5, G_6_7, P_6_7, G_7_8, P_7_8, G_9_10, P_9_10, G_10_11, P_10_11, G_12_13, P_12_13, G_13_14, P_13_14, G_14_15, P_14_15, G_16_17, P_16_17, G_0_2, G_0_3, G_2_5, P_2_5, G_4_6, P_4_6, G_7_9, P_7_9, G_10_12, P_10_12, G_12_15, P_12_15, G_14_16, P_14_16, G_0_4, G_0_5, G_0_6, G_2_7, P_2_7, G_4_8, P_4_8, G_7_11, P_7_11, G_10_14, P_10_14, G_12_17, P_12_17, G_0_7, G_0_8, G_0_9, G_4_10, P_4_10, G_0_11, G_7_13, P_7_13, G_0_10, G_0_12, G_0_13, G_0_14, G_0_15, G_7_16, P_7_16, G_0_17, G_0_16;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_7_8 = g0[8] | (p0[8] & g0[7]);
  assign P_7_8 = p0[8] & p0[7];
  assign G_9_10 = g0[10] | (p0[10] & g0[9]);
  assign P_9_10 = p0[10] & p0[9];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_13_14 = g0[14] | (p0[14] & g0[13]);
  assign P_13_14 = p0[14] & p0[13];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_16_17 = g0[17] | (p0[17] & g0[16]);
  assign P_16_17 = p0[17] & p0[16];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_4_6 = g0[6] | (p0[6] & G_4_5);
  assign P_4_6 = p0[6] & P_4_5;
  assign G_7_9 = g0[9] | (p0[9] & G_7_8);
  assign P_7_9 = p0[9] & P_7_8;
  assign G_10_12 = g0[12] | (p0[12] & G_10_11);
  assign P_10_12 = p0[12] & P_10_11;
  assign G_12_15 = G_14_15 | (P_14_15 & G_12_13);
  assign P_12_15 = P_14_15 & P_12_13;
  assign G_14_16 = g0[16] | (p0[16] & G_14_15);
  assign P_14_16 = p0[16] & P_14_15;
  assign G_0_4 = G_3_4 | (P_3_4 & G_0_2);
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  assign G_0_6 = G_4_6 | (P_4_6 & G_0_3);
  assign G_2_7 = G_6_7 | (P_6_7 & G_2_5);
  assign P_2_7 = P_6_7 & P_2_5;
  assign G_4_8 = G_7_8 | (P_7_8 & G_4_6);
  assign P_4_8 = P_7_8 & P_4_6;
  assign G_7_11 = G_10_11 | (P_10_11 & G_7_9);
  assign P_7_11 = P_10_11 & P_7_9;
  assign G_10_14 = G_13_14 | (P_13_14 & G_10_12);
  assign P_10_14 = P_13_14 & P_10_12;
  assign G_12_17 = G_16_17 | (P_16_17 & G_12_15);
  assign P_12_17 = P_16_17 & P_12_15;
  assign G_0_7 = G_2_7 | (P_2_7 & G_0_1);
  assign G_0_8 = G_4_8 | (P_4_8 & G_0_3);
  assign G_0_9 = G_7_9 | (P_7_9 & G_0_6);
  assign G_4_10 = G_9_10 | (P_9_10 & G_4_8);
  assign P_4_10 = P_9_10 & P_4_8;
  assign G_0_11 = G_7_11 | (P_7_11 & G_0_6);
  assign G_7_13 = G_12_13 | (P_12_13 & G_7_11);
  assign P_7_13 = P_12_13 & P_7_11;
  assign G_0_10 = G_4_10 | (P_4_10 & G_0_3);
  assign G_0_12 = G_10_12 | (P_10_12 & G_0_9);
  assign G_0_13 = G_7_13 | (P_7_13 & G_0_6);
  assign G_0_14 = G_10_14 | (P_10_14 & G_0_9);
  assign G_0_15 = G_12_15 | (P_12_15 & G_0_11);
  assign G_7_16 = G_14_16 | (P_14_16 & G_7_13);
  assign P_7_16 = P_14_16 & P_7_13;
  assign G_0_17 = G_12_17 | (P_12_17 & G_0_11);
  assign G_0_16 = G_7_16 | (P_7_16 & G_0_6);
  logic [18:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign c[15] = G_0_14;
  assign c[16] = G_0_15;
  assign c[17] = G_0_16;
  assign c[18] = G_0_17;
  assign s = pi_ ^ c[17:0];
  assign cout = c[18];
endmodule


module fam_prefix_arrival_0_1_1_w3 (input logic [2:0] a, input logic [2:0] b, input logic cin,
  output logic [2:0] s, output logic cout);
  // prefix graph: {'n': 3, 'levels': 2, 'size': 3, 'fanout': 2, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [2:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [2:0] g0, p0;
  assign g0 = {gi[2:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_1_2, P_1_2, G_0_2;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  logic [3:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign s = pi_ ^ c[2:0];
  assign cout = c[3];
endmodule






// carry_skip: blocks [4, 4, 1] (uniform), 1 skip level, mux






// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).











module fam_prefix_brent_kung_w18_flag_dual (input logic [17:0] a, input logic [17:0] b, input logic cin,
  output logic [17:0] s, output logic cout, output logic [17:0] s1);
  // prefix graph: {'n': 18, 'levels': 6, 'size': 29, 'fanout': 4, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [17:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [17:0] g0, p0;
  assign g0 = {gi[17:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, P_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_8_9, P_8_9, G_10_11, P_10_11, G_12_13, P_12_13, G_14_15, P_14_15, G_16_17, P_16_17, G_0_2, P_0_2, G_0_3, P_0_3, G_4_7, P_4_7, G_8_11, P_8_11, G_12_15, P_12_15, G_0_4, P_0_4, G_0_5, P_0_5, G_0_7, P_0_7, G_8_15, P_8_15, G_0_6, P_0_6, G_0_8, P_0_8, G_0_9, P_0_9, G_0_11, P_0_11, G_0_15, P_0_15, G_0_10, P_0_10, G_0_12, P_0_12, G_0_13, P_0_13, G_0_16, P_0_16, G_0_17, P_0_17, G_0_14, P_0_14;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign P_0_1 = p0[1] & p0[0];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_16_17 = g0[17] | (p0[17] & g0[16]);
  assign P_16_17 = p0[17] & p0[16];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign P_0_2 = p0[2] & P_0_1;
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign P_0_3 = P_2_3 & P_0_1;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_12_15 = G_14_15 | (P_14_15 & G_12_13);
  assign P_12_15 = P_14_15 & P_12_13;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign P_0_4 = p0[4] & P_0_3;
  assign G_0_5 = G_4_5 | (P_4_5 & G_0_3);
  assign P_0_5 = P_4_5 & P_0_3;
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign P_0_7 = P_4_7 & P_0_3;
  assign G_8_15 = G_12_15 | (P_12_15 & G_8_11);
  assign P_8_15 = P_12_15 & P_8_11;
  assign G_0_6 = g0[6] | (p0[6] & G_0_5);
  assign P_0_6 = p0[6] & P_0_5;
  assign G_0_8 = g0[8] | (p0[8] & G_0_7);
  assign P_0_8 = p0[8] & P_0_7;
  assign G_0_9 = G_8_9 | (P_8_9 & G_0_7);
  assign P_0_9 = P_8_9 & P_0_7;
  assign G_0_11 = G_8_11 | (P_8_11 & G_0_7);
  assign P_0_11 = P_8_11 & P_0_7;
  assign G_0_15 = G_8_15 | (P_8_15 & G_0_7);
  assign P_0_15 = P_8_15 & P_0_7;
  assign G_0_10 = g0[10] | (p0[10] & G_0_9);
  assign P_0_10 = p0[10] & P_0_9;
  assign G_0_12 = g0[12] | (p0[12] & G_0_11);
  assign P_0_12 = p0[12] & P_0_11;
  assign G_0_13 = G_12_13 | (P_12_13 & G_0_11);
  assign P_0_13 = P_12_13 & P_0_11;
  assign G_0_16 = g0[16] | (p0[16] & G_0_15);
  assign P_0_16 = p0[16] & P_0_15;
  assign G_0_17 = G_16_17 | (P_16_17 & G_0_15);
  assign P_0_17 = P_16_17 & P_0_15;
  assign G_0_14 = g0[14] | (p0[14] & G_0_13);
  assign P_0_14 = p0[14] & P_0_13;
  logic [18:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign c[15] = G_0_14;
  assign c[16] = G_0_15;
  assign c[17] = G_0_16;
  assign c[18] = G_0_17;
  assign s = pi_ ^ c[17:0];
  assign cout = c[18];
  logic [17:0] g1, p1;
  assign g1 = {gi[17:1], gi[0] | pi_[0]};
  assign p1 = pi_;
  logic H_0_1, H_2_3, Q_2_3, H_4_5, Q_4_5, H_6_7, Q_6_7, H_8_9, Q_8_9, H_10_11, Q_10_11, H_12_13, Q_12_13, H_14_15, Q_14_15, H_16_17, Q_16_17, H_0_2, H_0_3, H_4_7, Q_4_7, H_8_11, Q_8_11, H_12_15, Q_12_15, H_0_4, H_0_5, H_0_7, H_8_15, Q_8_15, H_0_6, H_0_8, H_0_9, H_0_11, H_0_15, H_0_10, H_0_12, H_0_13, H_0_16, H_0_17, H_0_14;
  assign H_0_1 = g1[1] | (p1[1] & g1[0]);
  assign H_2_3 = g1[3] | (p1[3] & g1[2]);
  assign Q_2_3 = p1[3] & p1[2];
  assign H_4_5 = g1[5] | (p1[5] & g1[4]);
  assign Q_4_5 = p1[5] & p1[4];
  assign H_6_7 = g1[7] | (p1[7] & g1[6]);
  assign Q_6_7 = p1[7] & p1[6];
  assign H_8_9 = g1[9] | (p1[9] & g1[8]);
  assign Q_8_9 = p1[9] & p1[8];
  assign H_10_11 = g1[11] | (p1[11] & g1[10]);
  assign Q_10_11 = p1[11] & p1[10];
  assign H_12_13 = g1[13] | (p1[13] & g1[12]);
  assign Q_12_13 = p1[13] & p1[12];
  assign H_14_15 = g1[15] | (p1[15] & g1[14]);
  assign Q_14_15 = p1[15] & p1[14];
  assign H_16_17 = g1[17] | (p1[17] & g1[16]);
  assign Q_16_17 = p1[17] & p1[16];
  assign H_0_2 = g1[2] | (p1[2] & H_0_1);
  assign H_0_3 = H_2_3 | (Q_2_3 & H_0_1);
  assign H_4_7 = H_6_7 | (Q_6_7 & H_4_5);
  assign Q_4_7 = Q_6_7 & Q_4_5;
  assign H_8_11 = H_10_11 | (Q_10_11 & H_8_9);
  assign Q_8_11 = Q_10_11 & Q_8_9;
  assign H_12_15 = H_14_15 | (Q_14_15 & H_12_13);
  assign Q_12_15 = Q_14_15 & Q_12_13;
  assign H_0_4 = g1[4] | (p1[4] & H_0_3);
  assign H_0_5 = H_4_5 | (Q_4_5 & H_0_3);
  assign H_0_7 = H_4_7 | (Q_4_7 & H_0_3);
  assign H_8_15 = H_12_15 | (Q_12_15 & H_8_11);
  assign Q_8_15 = Q_12_15 & Q_8_11;
  assign H_0_6 = g1[6] | (p1[6] & H_0_5);
  assign H_0_8 = g1[8] | (p1[8] & H_0_7);
  assign H_0_9 = H_8_9 | (Q_8_9 & H_0_7);
  assign H_0_11 = H_8_11 | (Q_8_11 & H_0_7);
  assign H_0_15 = H_8_15 | (Q_8_15 & H_0_7);
  assign H_0_10 = g1[10] | (p1[10] & H_0_9);
  assign H_0_12 = g1[12] | (p1[12] & H_0_11);
  assign H_0_13 = H_12_13 | (Q_12_13 & H_0_11);
  assign H_0_16 = g1[16] | (p1[16] & H_0_15);
  assign H_0_17 = H_16_17 | (Q_16_17 & H_0_15);
  assign H_0_14 = g1[14] | (p1[14] & H_0_13);
  logic [18:0] c1;
  assign c1[0] = 1'b1;
  assign c1[1] = g1[0];
  assign c1[2] = H_0_1;
  assign c1[3] = H_0_2;
  assign c1[4] = H_0_3;
  assign c1[5] = H_0_4;
  assign c1[6] = H_0_5;
  assign c1[7] = H_0_6;
  assign c1[8] = H_0_7;
  assign c1[9] = H_0_8;
  assign c1[10] = H_0_9;
  assign c1[11] = H_0_10;
  assign c1[12] = H_0_11;
  assign c1[13] = H_0_12;
  assign c1[14] = H_0_13;
  assign c1[15] = H_0_14;
  assign c1[16] = H_0_15;
  assign c1[17] = H_0_16;
  assign c1[18] = H_0_17;
  assign s1 = pi_ ^ c1[17:0];
endmodule



module fam_prefix_han_carlson_w36_ling (input logic [35:0] a, input logic [35:0] b, input logic cin,
  output logic [35:0] s, output logic cout);
  // prefix graph: {'n': 36, 'levels': 7, 'size': 94, 'fanout': 6, 'tracks': 8, 'exact_split': True, 'valency': 2}
  logic [35:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [35:0] g0, p0;
  assign g0 = {gi[35:1], gi[0] | cin};
  assign p0 = {ti[34:0], 1'b0};
  logic G_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_8_9, P_8_9, G_10_11, P_10_11, G_12_13, P_12_13, G_14_15, P_14_15, G_16_17, P_16_17, G_18_19, P_18_19, G_20_21, P_20_21, G_22_23, P_22_23, G_24_25, P_24_25, G_26_27, P_26_27, G_28_29, P_28_29, G_30_31, P_30_31, G_32_33, P_32_33, G_34_35, P_34_35, G_0_2, G_0_3, G_2_5, P_2_5, G_4_7, P_4_7, G_6_9, P_6_9, G_8_11, P_8_11, G_10_13, P_10_13, G_12_15, P_12_15, G_14_17, P_14_17, G_16_19, P_16_19, G_18_21, P_18_21, G_20_23, P_20_23, G_22_25, P_22_25, G_24_27, P_24_27, G_26_29, P_26_29, G_28_31, P_28_31, G_30_33, P_30_33, G_32_35, P_32_35, G_0_4, G_0_5, G_0_7, G_2_9, P_2_9, G_4_11, P_4_11, G_6_13, P_6_13, G_8_15, P_8_15, G_10_17, P_10_17, G_12_19, P_12_19, G_14_21, P_14_21, G_16_23, P_16_23, G_18_25, P_18_25, G_20_27, P_20_27, G_22_29, P_22_29, G_24_31, P_24_31, G_26_33, P_26_33, G_28_35, P_28_35, G_0_6, G_0_8, G_0_9, G_0_11, G_0_13, G_0_15, G_2_17, P_2_17, G_4_19, P_4_19, G_6_21, P_6_21, G_8_23, P_8_23, G_10_25, P_10_25, G_12_27, P_12_27, G_14_29, P_14_29, G_16_31, P_16_31, G_18_33, P_18_33, G_20_35, P_20_35, G_0_10, G_0_12, G_0_14, G_0_16, G_0_17, G_0_19, G_0_21, G_0_23, G_0_25, G_0_27, G_0_29, G_0_31, G_2_33, P_2_33, G_4_35, P_4_35, G_0_18, G_0_20, G_0_22, G_0_24, G_0_26, G_0_28, G_0_30, G_0_32, G_0_33, G_0_35, G_0_34;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_16_17 = g0[17] | (p0[17] & g0[16]);
  assign P_16_17 = p0[17] & p0[16];
  assign G_18_19 = g0[19] | (p0[19] & g0[18]);
  assign P_18_19 = p0[19] & p0[18];
  assign G_20_21 = g0[21] | (p0[21] & g0[20]);
  assign P_20_21 = p0[21] & p0[20];
  assign G_22_23 = g0[23] | (p0[23] & g0[22]);
  assign P_22_23 = p0[23] & p0[22];
  assign G_24_25 = g0[25] | (p0[25] & g0[24]);
  assign P_24_25 = p0[25] & p0[24];
  assign G_26_27 = g0[27] | (p0[27] & g0[26]);
  assign P_26_27 = p0[27] & p0[26];
  assign G_28_29 = g0[29] | (p0[29] & g0[28]);
  assign P_28_29 = p0[29] & p0[28];
  assign G_30_31 = g0[31] | (p0[31] & g0[30]);
  assign P_30_31 = p0[31] & p0[30];
  assign G_32_33 = g0[33] | (p0[33] & g0[32]);
  assign P_32_33 = p0[33] & p0[32];
  assign G_34_35 = g0[35] | (p0[35] & g0[34]);
  assign P_34_35 = p0[35] & p0[34];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_6_9 = G_8_9 | (P_8_9 & G_6_7);
  assign P_6_9 = P_8_9 & P_6_7;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_10_13 = G_12_13 | (P_12_13 & G_10_11);
  assign P_10_13 = P_12_13 & P_10_11;
  assign G_12_15 = G_14_15 | (P_14_15 & G_12_13);
  assign P_12_15 = P_14_15 & P_12_13;
  assign G_14_17 = G_16_17 | (P_16_17 & G_14_15);
  assign P_14_17 = P_16_17 & P_14_15;
  assign G_16_19 = G_18_19 | (P_18_19 & G_16_17);
  assign P_16_19 = P_18_19 & P_16_17;
  assign G_18_21 = G_20_21 | (P_20_21 & G_18_19);
  assign P_18_21 = P_20_21 & P_18_19;
  assign G_20_23 = G_22_23 | (P_22_23 & G_20_21);
  assign P_20_23 = P_22_23 & P_20_21;
  assign G_22_25 = G_24_25 | (P_24_25 & G_22_23);
  assign P_22_25 = P_24_25 & P_22_23;
  assign G_24_27 = G_26_27 | (P_26_27 & G_24_25);
  assign P_24_27 = P_26_27 & P_24_25;
  assign G_26_29 = G_28_29 | (P_28_29 & G_26_27);
  assign P_26_29 = P_28_29 & P_26_27;
  assign G_28_31 = G_30_31 | (P_30_31 & G_28_29);
  assign P_28_31 = P_30_31 & P_28_29;
  assign G_30_33 = G_32_33 | (P_32_33 & G_30_31);
  assign P_30_33 = P_32_33 & P_30_31;
  assign G_32_35 = G_34_35 | (P_34_35 & G_32_33);
  assign P_32_35 = P_34_35 & P_32_33;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_2_9 = G_6_9 | (P_6_9 & G_2_5);
  assign P_2_9 = P_6_9 & P_2_5;
  assign G_4_11 = G_8_11 | (P_8_11 & G_4_7);
  assign P_4_11 = P_8_11 & P_4_7;
  assign G_6_13 = G_10_13 | (P_10_13 & G_6_9);
  assign P_6_13 = P_10_13 & P_6_9;
  assign G_8_15 = G_12_15 | (P_12_15 & G_8_11);
  assign P_8_15 = P_12_15 & P_8_11;
  assign G_10_17 = G_14_17 | (P_14_17 & G_10_13);
  assign P_10_17 = P_14_17 & P_10_13;
  assign G_12_19 = G_16_19 | (P_16_19 & G_12_15);
  assign P_12_19 = P_16_19 & P_12_15;
  assign G_14_21 = G_18_21 | (P_18_21 & G_14_17);
  assign P_14_21 = P_18_21 & P_14_17;
  assign G_16_23 = G_20_23 | (P_20_23 & G_16_19);
  assign P_16_23 = P_20_23 & P_16_19;
  assign G_18_25 = G_22_25 | (P_22_25 & G_18_21);
  assign P_18_25 = P_22_25 & P_18_21;
  assign G_20_27 = G_24_27 | (P_24_27 & G_20_23);
  assign P_20_27 = P_24_27 & P_20_23;
  assign G_22_29 = G_26_29 | (P_26_29 & G_22_25);
  assign P_22_29 = P_26_29 & P_22_25;
  assign G_24_31 = G_28_31 | (P_28_31 & G_24_27);
  assign P_24_31 = P_28_31 & P_24_27;
  assign G_26_33 = G_30_33 | (P_30_33 & G_26_29);
  assign P_26_33 = P_30_33 & P_26_29;
  assign G_28_35 = G_32_35 | (P_32_35 & G_28_31);
  assign P_28_35 = P_32_35 & P_28_31;
  assign G_0_6 = g0[6] | (p0[6] & G_0_5);
  assign G_0_8 = g0[8] | (p0[8] & G_0_7);
  assign G_0_9 = G_2_9 | (P_2_9 & G_0_1);
  assign G_0_11 = G_4_11 | (P_4_11 & G_0_3);
  assign G_0_13 = G_6_13 | (P_6_13 & G_0_5);
  assign G_0_15 = G_8_15 | (P_8_15 & G_0_7);
  assign G_2_17 = G_10_17 | (P_10_17 & G_2_9);
  assign P_2_17 = P_10_17 & P_2_9;
  assign G_4_19 = G_12_19 | (P_12_19 & G_4_11);
  assign P_4_19 = P_12_19 & P_4_11;
  assign G_6_21 = G_14_21 | (P_14_21 & G_6_13);
  assign P_6_21 = P_14_21 & P_6_13;
  assign G_8_23 = G_16_23 | (P_16_23 & G_8_15);
  assign P_8_23 = P_16_23 & P_8_15;
  assign G_10_25 = G_18_25 | (P_18_25 & G_10_17);
  assign P_10_25 = P_18_25 & P_10_17;
  assign G_12_27 = G_20_27 | (P_20_27 & G_12_19);
  assign P_12_27 = P_20_27 & P_12_19;
  assign G_14_29 = G_22_29 | (P_22_29 & G_14_21);
  assign P_14_29 = P_22_29 & P_14_21;
  assign G_16_31 = G_24_31 | (P_24_31 & G_16_23);
  assign P_16_31 = P_24_31 & P_16_23;
  assign G_18_33 = G_26_33 | (P_26_33 & G_18_25);
  assign P_18_33 = P_26_33 & P_18_25;
  assign G_20_35 = G_28_35 | (P_28_35 & G_20_27);
  assign P_20_35 = P_28_35 & P_20_27;
  assign G_0_10 = g0[10] | (p0[10] & G_0_9);
  assign G_0_12 = g0[12] | (p0[12] & G_0_11);
  assign G_0_14 = g0[14] | (p0[14] & G_0_13);
  assign G_0_16 = g0[16] | (p0[16] & G_0_15);
  assign G_0_17 = G_2_17 | (P_2_17 & G_0_1);
  assign G_0_19 = G_4_19 | (P_4_19 & G_0_3);
  assign G_0_21 = G_6_21 | (P_6_21 & G_0_5);
  assign G_0_23 = G_8_23 | (P_8_23 & G_0_7);
  assign G_0_25 = G_10_25 | (P_10_25 & G_0_9);
  assign G_0_27 = G_12_27 | (P_12_27 & G_0_11);
  assign G_0_29 = G_14_29 | (P_14_29 & G_0_13);
  assign G_0_31 = G_16_31 | (P_16_31 & G_0_15);
  assign G_2_33 = G_18_33 | (P_18_33 & G_2_17);
  assign P_2_33 = P_18_33 & P_2_17;
  assign G_4_35 = G_20_35 | (P_20_35 & G_4_19);
  assign P_4_35 = P_20_35 & P_4_19;
  assign G_0_18 = g0[18] | (p0[18] & G_0_17);
  assign G_0_20 = g0[20] | (p0[20] & G_0_19);
  assign G_0_22 = g0[22] | (p0[22] & G_0_21);
  assign G_0_24 = g0[24] | (p0[24] & G_0_23);
  assign G_0_26 = g0[26] | (p0[26] & G_0_25);
  assign G_0_28 = g0[28] | (p0[28] & G_0_27);
  assign G_0_30 = g0[30] | (p0[30] & G_0_29);
  assign G_0_32 = g0[32] | (p0[32] & G_0_31);
  assign G_0_33 = G_2_33 | (P_2_33 & G_0_1);
  assign G_0_35 = G_4_35 | (P_4_35 & G_0_3);
  assign G_0_34 = g0[34] | (p0[34] & G_0_33);
  logic [36:0] c;
  assign c[0] = cin;
  assign c[1] = ti[0] & g0[0];
  assign c[2] = ti[1] & G_0_1;
  assign c[3] = ti[2] & G_0_2;
  assign c[4] = ti[3] & G_0_3;
  assign c[5] = ti[4] & G_0_4;
  assign c[6] = ti[5] & G_0_5;
  assign c[7] = ti[6] & G_0_6;
  assign c[8] = ti[7] & G_0_7;
  assign c[9] = ti[8] & G_0_8;
  assign c[10] = ti[9] & G_0_9;
  assign c[11] = ti[10] & G_0_10;
  assign c[12] = ti[11] & G_0_11;
  assign c[13] = ti[12] & G_0_12;
  assign c[14] = ti[13] & G_0_13;
  assign c[15] = ti[14] & G_0_14;
  assign c[16] = ti[15] & G_0_15;
  assign c[17] = ti[16] & G_0_16;
  assign c[18] = ti[17] & G_0_17;
  assign c[19] = ti[18] & G_0_18;
  assign c[20] = ti[19] & G_0_19;
  assign c[21] = ti[20] & G_0_20;
  assign c[22] = ti[21] & G_0_21;
  assign c[23] = ti[22] & G_0_22;
  assign c[24] = ti[23] & G_0_23;
  assign c[25] = ti[24] & G_0_24;
  assign c[26] = ti[25] & G_0_25;
  assign c[27] = ti[26] & G_0_26;
  assign c[28] = ti[27] & G_0_27;
  assign c[29] = ti[28] & G_0_28;
  assign c[30] = ti[29] & G_0_29;
  assign c[31] = ti[30] & G_0_30;
  assign c[32] = ti[31] & G_0_31;
  assign c[33] = ti[32] & G_0_32;
  assign c[34] = ti[33] & G_0_33;
  assign c[35] = ti[34] & G_0_34;
  assign c[36] = ti[35] & G_0_35;
  assign s = pi_ ^ c[35:0];
  assign cout = c[36];
endmodule


module fam_prefix_harris_l0f1_w11_flagm_late (input logic [10:0] a, input logic [10:0] b, input logic cin,
  output logic [10:0] s, output logic cout, output logic [10:0] s1, output logic [10:0] sm1);
  // prefix graph: {'n': 11, 'levels': 4, 'size': 29, 'fanout': 4, 'tracks': 4, 'exact_split': False, 'valency': 2}
  logic [10:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [10:0] g0, p0;
  assign g0 = gi;
  assign p0 = pi_;
  logic G_0_1, P_0_1, G_1_2, P_1_2, G_2_3, P_2_3, G_3_4, P_3_4, G_4_5, P_4_5, G_5_6, P_5_6, G_6_7, P_6_7, G_7_8, P_7_8, G_8_9, P_8_9, G_9_10, P_9_10, G_0_2, P_0_2, G_0_3, P_0_3, G_1_4, P_1_4, G_2_5, P_2_5, G_3_6, P_3_6, G_4_7, P_4_7, G_5_8, P_5_8, G_6_9, P_6_9, G_7_10, P_7_10, G_0_4, P_0_4, G_0_5, P_0_5, G_0_6, P_0_6, G_0_7, P_0_7, G_1_8, P_1_8, G_2_9, P_2_9, G_3_10, P_3_10, G_0_8, P_0_8, G_0_9, P_0_9, G_0_10, P_0_10;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign P_0_1 = p0[1] & p0[0];
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_5_6 = g0[6] | (p0[6] & g0[5]);
  assign P_5_6 = p0[6] & p0[5];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_7_8 = g0[8] | (p0[8] & g0[7]);
  assign P_7_8 = p0[8] & p0[7];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_9_10 = g0[10] | (p0[10] & g0[9]);
  assign P_9_10 = p0[10] & p0[9];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign P_0_2 = P_1_2 & p0[0];
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign P_0_3 = P_2_3 & P_0_1;
  assign G_1_4 = G_3_4 | (P_3_4 & G_1_2);
  assign P_1_4 = P_3_4 & P_1_2;
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_3_6 = G_5_6 | (P_5_6 & G_3_4);
  assign P_3_6 = P_5_6 & P_3_4;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_5_8 = G_7_8 | (P_7_8 & G_5_6);
  assign P_5_8 = P_7_8 & P_5_6;
  assign G_6_9 = G_8_9 | (P_8_9 & G_6_7);
  assign P_6_9 = P_8_9 & P_6_7;
  assign G_7_10 = G_9_10 | (P_9_10 & G_7_8);
  assign P_7_10 = P_9_10 & P_7_8;
  assign G_0_4 = G_1_4 | (P_1_4 & g0[0]);
  assign P_0_4 = P_1_4 & p0[0];
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  assign P_0_5 = P_2_5 & P_0_1;
  assign G_0_6 = G_3_6 | (P_3_6 & G_0_2);
  assign P_0_6 = P_3_6 & P_0_2;
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign P_0_7 = P_4_7 & P_0_3;
  assign G_1_8 = G_5_8 | (P_5_8 & G_1_4);
  assign P_1_8 = P_5_8 & P_1_4;
  assign G_2_9 = G_6_9 | (P_6_9 & G_2_5);
  assign P_2_9 = P_6_9 & P_2_5;
  assign G_3_10 = G_7_10 | (P_7_10 & G_3_6);
  assign P_3_10 = P_7_10 & P_3_6;
  assign G_0_8 = G_1_8 | (P_1_8 & G_0_1);
  assign P_0_8 = P_1_8 & P_0_1;
  assign G_0_9 = G_2_9 | (P_2_9 & G_0_1);
  assign P_0_9 = P_2_9 & P_0_1;
  assign G_0_10 = G_3_10 | (P_3_10 & G_0_3);
  assign P_0_10 = P_3_10 & P_0_3;
  logic [11:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0] | (p0[0] & cin);
  assign c[2] = G_0_1 | (P_0_1 & cin);
  assign c[3] = G_0_2 | (P_0_2 & cin);
  assign c[4] = G_0_3 | (P_0_3 & cin);
  assign c[5] = G_0_4 | (P_0_4 & cin);
  assign c[6] = G_0_5 | (P_0_5 & cin);
  assign c[7] = G_0_6 | (P_0_6 & cin);
  assign c[8] = G_0_7 | (P_0_7 & cin);
  assign c[9] = G_0_8 | (P_0_8 & cin);
  assign c[10] = G_0_9 | (P_0_9 & cin);
  assign c[11] = G_0_10 | (P_0_10 & cin);
  assign s = pi_ ^ c[10:0];
  assign cout = c[11];
  logic [10:0] f;
  assign f[0] = 1'b1;
  assign f[1] = pi_[0];
  assign f[2] = P_0_1;
  assign f[3] = P_0_2;
  assign f[4] = P_0_3;
  assign f[5] = P_0_4;
  assign f[6] = P_0_5;
  assign f[7] = P_0_6;
  assign f[8] = P_0_7;
  assign f[9] = P_0_8;
  assign f[10] = P_0_9;
  assign s1 = s ^ f;
  logic [10:0] fm;
  assign fm[0] = 1'b1;
  assign fm[1] = fm[0] & ~s[0];
  assign fm[2] = fm[1] & ~s[1];
  assign fm[3] = fm[2] & ~s[2];
  assign fm[4] = fm[3] & ~s[3];
  assign fm[5] = fm[4] & ~s[4];
  assign fm[6] = fm[5] & ~s[5];
  assign fm[7] = fm[6] & ~s[6];
  assign fm[8] = fm[7] & ~s[7];
  assign fm[9] = fm[8] & ~s[8];
  assign fm[10] = fm[9] & ~s[9];
  assign sm1 = s ^ fm;
endmodule




// ---------------------------------------------------------------- butterfly_network
// a rotator on a switch network of lg(W) stages of W/2 two-input switches, stage
// l pairing the bits at distance D = 2^l inside every block of 2D, each switch
// under its own control. On the inverse butterfly (NETWORK = 0, small distance
// first) a rotate right by k over a 2D-block whose two halves are already
// rotated by k mod D swaps the pair (i, i+D) at the block-local index i when
// i >= D - (k mod D), and every pair when bit l of k is set (Hilewitz and Lee's
// rotation on the ibfly). The butterfly (NETWORK = 1) is the same stages in the
// reverse order, which composes the inverse permutation, so it takes the controls
// of a rotation by W - k. The shifts merge a mask as the masked family does; a
// left amount is W - amt. The network needs a power-of-two width.
module fam_shift_butterfly_network #(parameter int W = 16, parameter int NETWORK = 0, parameter int STICKY = 0)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic [2:0] op, output logic [W-1:0] y, output logic sticky);
  localparam int AW = $clog2(W);
  wire right = (op == 3'd1) || (op == 3'd2) || (op == 3'd4);
  wire rot = (op == 3'd3) || (op == 3'd4);
  wire arith = (op == 3'd2);
  wire fill = arith & a[W-1];
  logic [AW-1:0] k0, k;                              // the right-rotation amount, and the controls' amount
  assign k0 = right ? amt : (W - amt);
  assign k = NETWORK ? (W - k0) : k0;
  logic [W-1:0] st [0:AW];
  assign st[0] = a;
  genvar s, i;
  generate
    for (s = 0; s < AW; s = s + 1) begin : stage
      localparam int L = NETWORK ? (AW - 1 - s) : s;   // the switch distance of this stage: 2^L
      localparam int D = 1 << L;
      logic [AW-1:0] kmod;                             // k mod D (the low L bits of k)
      if (L == 0) begin : k0_
        assign kmod = '0;
      end else begin : kl
        assign kmod = {{(AW - L){1'b0}}, k[L-1:0]};
      end
      for (i = 0; i < W; i = i + 1) begin : bit_
        localparam int J = i % (2 * D);              // the block-local index
        if (J < D) begin : sw
          // the switch of the pair (i, i+D): crossed when J >= D - (k mod D), inverted by bit L of k
          wire ctrl = ((J >= D - kmod) ^ k[L]);
          assign st[s+1][i] = ctrl ? st[s][i+D] : st[s][i];
          assign st[s+1][i+D] = ctrl ? st[s][i] : st[s][i+D];
        end
      end
    end
  endgenerate
  logic [W-1:0] mask;
  fam_shift_keep_mask #(.W(W), .STICKY(STICKY)) u_mask (.a(a), .amt(amt), .right(right), .rot(rot), .mask(mask), .sticky(sticky));
  assign y = rot ? st[AW] : ((st[AW] & mask) | ({W{fill}} & ~mask));
endmodule





// ----------------------------------------------------------- the keep mask
// mask[i] = 1 where a shift keeps the input bit that lands at i (a rotate keeps
// every bit): the thermometer of the amount for the direction. sticky is the OR
// of the input bits a shift moves out (the low amt bits of a right shift, the
// top amt bits of a left one; none for a rotate), read through the mask of the
// opposite direction, in parallel with the datapath.
module fam_shift_keep_mask #(parameter int W = 16, parameter int STICKY = 1)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic right, input logic rot,
   output logic [W-1:0] mask, output logic sticky);
  logic [W-1:0] kept_in;
  genvar i;
  generate
    for (i = 0; i < W; i = i + 1) begin : mk
      assign mask[i] = rot | (right ? (i < W - amt) : (i >= amt));
      assign kept_in[i] = rot | (right ? (i >= amt) : (i < W - amt));
    end
  endgenerate
  assign sticky = STICKY ? |(a & ~kept_in) : 1'b0;
endmodule




// ------------------------------------------------------------------ masked_merged
// a left rotator (the `rotator` slot's barrel: R_RADIX_LOG2, R_ONE_HOT, R_ORDER)
// plus a mask that turns the rotation into a shift by merging in the fill bits.
// MASKGEN: 0 thermometer_decode (one thermometer per direction, selected), 1
// two_thermometer_and (a low and a high bound thermometer ANDed), 2 lut (a table
// over the direction and the amount). MERGE: 0 and_or_merge, 1 per_bit_mux.
module fam_shift_masked_merged #(parameter int W = 16, parameter int MASKGEN = 0, parameter int MERGE = 0,
                                 parameter int R_RADIX_LOG2 = 1, parameter int R_ONE_HOT = 0, parameter int R_ORDER = 0, parameter int STICKY = 0)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic [2:0] op, output logic [W-1:0] y, output logic sticky);
  localparam int AW = $clog2(W);
  localparam int K = (R_RADIX_LOG2 == 0 || R_RADIX_LOG2 > AW) ? AW : R_RADIX_LOG2;
  localparam int NS = (AW + K - 1) / K;
  wire right = (op == 3'd1) || (op == 3'd2) || (op == 3'd4);
  wire rot = (op == 3'd3) || (op == 3'd4);
  wire arith = (op == 3'd2);
  wire fill = arith & a[W-1];
  // rotate left by amt (a right operation by k is a left rotation by W - k)
  logic [AW-1:0] lamt;
  assign lamt = right ? (W - amt) : amt;
  logic [W-1:0] st [0:NS];
  assign st[0] = a;
  genvar s, i;
  logic [W-1:0] mask;                 // 1 where the rotated bit is kept
  generate
    for (s = 0; s < NS; s = s + 1) begin : stage
      localparam int G = R_ORDER ? (NS - 1 - s) : s;
      localparam int KB = (G * K + K <= AW) ? K : AW - G * K;
      fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(0), .ONE_HOT(R_ONE_HOT))
        u (.x(st[s]), .digit(lamt[G*K +: KB]), .rot(1'b1), .fill(1'b0), .y(st[s+1]));
    end
    if (MASKGEN == 0) begin : thermo
      for (i = 0; i < W; i = i + 1) begin : mk
        assign mask[i] = right ? (i < W - amt) : (i >= amt);
      end
    end else if (MASKGEN == 1) begin : two_thermo
      // the field kept lies between a low and a high bound: [amt, W-1] for a left shift,
      // [0, W-1-amt] for a right one; each bound is a thermometer, the mask their AND. The
      // high bound is signed: a right amount at or past W (an amount code W leaves the whole
      // word when W is below a power of two) puts it below zero, and no bit is kept
      logic [AW:0] lo;
      logic signed [AW+1:0] hi;
      assign lo = right ? {(AW+1){1'b0}} : {1'b0, amt};
      assign hi = right ? ($signed(W - 1) - $signed({2'b00, amt})) : $signed(W - 1);
      logic [W-1:0] ge_lo, le_hi;
      for (i = 0; i < W; i = i + 1) begin : mk
        assign ge_lo[i] = (i >= lo);
        assign le_hi[i] = (hi >= 0) && (i <= hi);
      end
      assign mask = ge_lo & le_hi;
    end else begin : lut
      // the mask read from a table over the direction and the amount
      logic [AW:0] idx;
      assign idx = {right, amt};
      logic [W-1:0] tab [0:2*(1<<AW)-1];
      for (i = 0; i < 2 * (1 << AW); i = i + 1) begin : t
        localparam int RT = i >> AW;
        localparam int AM = i & ((1 << AW) - 1);
        genvar j;
        for (j = 0; j < W; j = j + 1) begin : bt
          assign tab[i][j] = RT ? (j < W - AM) : (j >= AM);
        end
      end
      assign mask = tab[idx];
    end
  endgenerate
  logic [W-1:0] mask_unused;
  fam_shift_keep_mask #(.W(W), .STICKY(STICKY)) u_sticky (.a(a), .amt(amt), .right(right), .rot(rot), .mask(mask_unused), .sticky(sticky));
  generate
    if (MERGE == 0) begin : and_or
      assign y = rot ? st[NS] : ((st[NS] & mask) | ({W{fill}} & ~mask));
    end else begin : per_bit
      for (i = 0; i < W; i = i + 1) begin : mx
        assign y[i] = (rot | mask[i]) ? st[NS][i] : fill;
      end
    end
  endgenerate
endmodule

// The shifter families of chiALU. One interface:
//   #(parameter int W) (input [W-1:0] a, input [AW-1:0] amt, input [2:0] op, output [W-1:0] y)
// op: 0 shl, 1 shr_logical, 2 shr_arith, 3 rol, 4 ror; amt is below W.
// Every family has `output sticky`, the OR of the bits a shift moves out (0 for a rotate), built
// when STICKY = 1 (the sticky_collect choice; an alignment shifter asks for it) and tied to 0
// otherwise; a consumer that does not collect it leaves the port unconnected.

// ------------------------------------------------------------------ one mux stage
// One stage of a shifter: the K-bit digit of the amount selects among R = 2^K
// candidates, candidate d being the input displaced by d * 2^SH to the left
// (RIGHT = 0) or to the right (RIGHT = 1), the vacated bits taken from the
// other end under `rot` or from `fill`. ONE_HOT = 1 decodes the digit to R
// select lines and forms the mux as an AND-OR (the select_encoding choice);
// ONE_HOT = 0 indexes the candidates by the binary digit.
module fam_shift_stage #(parameter int W = 16, parameter int K = 1, parameter int SH = 0,
                         parameter int RIGHT = 0, parameter int ONE_HOT = 0)
  (input logic [W-1:0] x, input logic [K-1:0] digit, input logic rot, input logic fill, output logic [W-1:0] y);
  localparam int R = 1 << K;
  localparam int D = 1 << SH;
  logic [W*R-1:0] cand;                       // candidate d at [d*W +: W]
  genvar d, i;
  generate
    for (d = 0; d < R; d = d + 1) begin : c
      for (i = 0; i < W; i = i + 1) begin : b
        localparam int S = d * D;             // the displacement of this candidate
        if (S >= W) begin : far
          // a displacement past the word: a rotate wraps it (mod W), a shift clears the word
          localparam int IDX = ((RIGHT ? (i + S) : (i - S)) % W + W) % W;
          assign cand[d*W + i] = rot ? x[IDX] : fill;
        end else if (RIGHT) begin : r
          if (i + S < W) begin : in_
            assign cand[d*W + i] = x[i + S];
          end else begin : out_
            assign cand[d*W + i] = rot ? x[i + S - W] : fill;
          end
        end else begin : l
          if (i >= S) begin : in_
            assign cand[d*W + i] = x[i - S];
          end else begin : out_
            assign cand[d*W + i] = rot ? x[W - S + i] : fill;
          end
        end
      end
    end
    if (ONE_HOT) begin : onehot
      logic [R-1:0] sel;
      for (d = 0; d < R; d = d + 1) begin : dec
        assign sel[d] = (digit == d);
      end
      for (i = 0; i < W; i = i + 1) begin : orb
        logic [R-1:0] t;
        for (d = 0; d < R; d = d + 1) begin : and_
          assign t[d] = sel[d] & cand[d*W + i];
        end
        assign y[i] = |t;
      end
    end else begin : binary
      assign y = cand[digit*W +: W];
    end
  endgenerate
endmodule
