// ADIR-MEMBER packages
// alu_core_m0_pkg: the exact-arithmetic functions of mode 0 (1xint16_twos_complement)
package alu_core_m0_pkg;

  // ---- m0: V = {special[1:0], sign, exp[8] (signed), sig[17]}
  //           X = {special[1:0], sign, exp[8] (signed), sig[38], sticky}
  localparam int m0_SW = 17, m0_EW = 8, m0_XW = 38;
  localparam int m0_VW = 28, m0_XT = 50;
  function automatic [27:0] m0_mkv(input [1:0] sp, input s, input signed [7:0] e, input [16:0] sig);
    m0_mkv = {sp, s, e, sig};
  endfunction
  function automatic [49:0] m0_mkx(input [1:0] sp, input s, input signed [7:0] e, input [37:0] sig, input st);
    m0_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [49:0] m0_x(input [27:0] v);   // widen V to X
    m0_x = {v[27:27-1], v[27-2], v[27-3 -: 8], {{(38-17){1'b0}}, v[16:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [49:0] m0_norm(input [49:0] x);
    logic [37:0] s; logic signed [7:0] e; integer k;
    s = x[38:1]; e = x[38+8:38+1];
    if (s != 0) begin
      for (k = 32; k >= 1; k = k / 2) begin
        if (k < 38) begin
          if (s[37 -: 1] == 1'b0 && (s >> (38 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m0_norm = {x[49:49-1], x[49-2], e, s, x[0]};
  endfunction

  function automatic m0_rup(input [2:0] rnd, input s, input inexact, input [38:0] rest, input [38:0] halfv,
                             input st, input lsb, input [38+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m0_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m0_rup = 1'b0;
      3'd2: m0_rup = inexact && s;
      3'd3: m0_rup = inexact && !s;
      3'd4: m0_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m0_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [49:0] m0_add(input [49:0] a, input [49:0] b, input sub);
    logic [49:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [7:0] ea, eb, d; logic [38:0] ms, mb, r; logic st, stb; integer sh;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1];
    sa = na[49-2]; sb = nb[49-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m0_add = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m0_add = (sa == sb) ? m0_mkx(2'd2, sa, 0, 0, 1'b0) : m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_add = m0_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m0_add = m0_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[38:1] == 0 && !na[0]) m0_add = {nb[49:49-1], sb, nb[49-3:0]};
    else if (nb[38:1] == 0 && !nb[0]) m0_add = na;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[38:1] >= nb[38:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[38+8:38+1] - sml[38+8:38+1];
      ms = {1'b0, sml[38:1]}; stb = sml[0];
      if (d > 38 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 38 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[38:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[38]) begin st = st | r[0]; r = r >> 1; m0_add = m0_mkx(2'd0, sr, big[38+8:38+1] + 1, r[37:0], st); end
      else m0_add = m0_mkx(2'd0, sr, big[38+8:38+1], r[37:0], st);
    end
  endfunction
  function automatic [49:0] m0_mul(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38-1:0] pr; logic st; integer k;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m0_mul = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[38:1] == 0 && !na[0]) || (spb == 2'd0 && nb[38:1] == 0 && !nb[0]))
        m0_mul = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m0_mul = m0_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[38:1] * nb[38:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[37:0] != 0);
      m0_mul = m0_mkx(2'd0, s, na[38+8:38+1] + nb[38+8:38+1] + 38, pr[2*38-1:38], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*38+1:0] m0_udiv(input [37:0] a, input [37:0] dv);
    logic [38+1:0] r; logic [38:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 38; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[37:0], ge};
      if (i > 0) r = {r[38:0], 1'b0};
    end
    m0_udiv = {q, r[38:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*38+8+2:0] m0_mulx(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*38-1:0] pr;
    na = m0_norm(a); nb = m0_norm(b);
    pr = na[38:1] * nb[38:1];
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[38:1] == 0) || (spb == 2'd0 && nb[38:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m0_mulx = {sp, s, na[38+8:38+1] + nb[38+8:38+1], pr};
  endfunction
  function automatic [49:0] m0_div(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38+1:0] qr; logic [38:0] q, r;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_div = m0_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m0_div = m0_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[38:1] == 0 && !nb[0]) begin
      if (na[38:1] == 0 && !na[0]) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m0_div = m0_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[38:1] == 0 && !na[0]) m0_div = m0_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m0_udiv(na[38:1], nb[38:1]);     // both normalized: nonzero finite
      q = qr[2*38+1:38+1]; r = qr[38:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[38]) m0_div = m0_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38 + 1, q[38:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m0_div = m0_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38, q[37:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [49:0] m0_sqrt(input [49:0] a);
    logic [49:0] na; logic [1:0] spa; logic signed [7:0] e; logic [38:0] m; logic [2*38+3:0] rad;
    logic [38+2:0] rem, trial; logic [38:0] root; logic ge; integer i;
    na = m0_norm(a); spa = na[49:49-1];
    if (spa == 2'd1) m0_sqrt = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_sqrt = na[49-2] ? m0_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[38:1] == 0 && !na[0]) m0_sqrt = na;
    else if (na[49-2]) m0_sqrt = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[38+8:38+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[38:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[38:1]};
      rad = {{(38+3){1'b0}}, m} << 38;
      rem = 0; root = 0;
      for (i = 38; i >= 0; i = i - 1) begin
        rem = {rem[38:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[37:0], ge};
      end
      m0_sqrt = m0_mkx(2'd0, 1'b0, (e >>> 1) - 19 + 1, root[38:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m0_lt(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [7:0] ea, eb;
    na = m0_norm(a); nb = m0_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    sa = na[49-2] && !za; sb = nb[49-2] && !zb;
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m0_lt = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2) begin
      if (na[49:49-1] == 2'd2 && nb[49:49-1] == 2'd2) m0_lt = na[49-2] && !nb[49-2];
      else if (na[49:49-1] == 2'd2) m0_lt = na[49-2];
      else m0_lt = !nb[49-2];
    end else if (za && zb) m0_lt = 1'b0;
    else if (sa != sb) m0_lt = sa;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[38:1] < nb[38:1] || (na[38:1] == nb[38:1] && !na[0] && nb[0])));
      m0_lt = sa ? !mag_lt && !(za && zb) && !m0_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m0_eq(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb;
    na = m0_norm(a); nb = m0_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m0_eq = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2)
      m0_eq = (na[49:49-1] == nb[49:49-1]) && (na[49-2] == nb[49-2]);
    else if (za || zb) m0_eq = za && zb;
    else m0_eq = (na[49-2] == nb[49-2]) && (na[38+8:38+1] == nb[38+8:38+1]) && (na[38:1] == nb[38:1]) && (na[0] == nb[0]);
  endfunction

  function automatic [28:0] m0_unpack_s(input [15:0] b, input daz);
    logic s; logic [15:0] mag; integer i;
    s = b[15]; mag = s ? (~b + 1'b1) : b;
    m0_unpack_s = {1'b0, m0_mkv(2'd0, s && (mag != 0), -0, {{(17-16){1'b0}}, mag})};
  endfunction

  function automatic [15:0] m0_enc(input signed [34:0] v); m0_enc = v[15:0]; endfunction
  function automatic [15:0] m0_wrap(input signed [34:0] v); m0_wrap = v[15:0]; endfunction
  function automatic [15:0] m0_sat(input signed [34:0] v);
    m0_sat = (v > 35'sd32767) ? {1'b0, {15{1'b1}}} : (v < -35'sd32768) ? {1'b1, {15{1'b0}}} : v[15:0];
  endfunction

  // round v / 2^f under rnd (the SR word applies to the fraction bits)
  function automatic signed [34:0] m0_rshift(input signed [34:0] v, input integer f, input [2:0] rnd, input [7:0] word);
    logic s; logic [34:0] mag, keep, rest, halfv; logic [43:0] fint; logic up, inexact;
    s = v < 0; mag = s ? -v : v;
    if (f <= 0) m0_rshift = v;
    else begin
      keep = mag >> f; rest = mag & (((35'd1) << f) - 1); halfv = (35'd1) << (f - 1);
      inexact = rest != 0;
      fint = (f >= 8) ? (rest >> (f - 8)) : (rest << (8 - f));
      case (rnd)
        3'd0: up = (rest > halfv) || (rest == halfv && keep[0]);
        3'd1: up = 1'b0;
        3'd2: up = inexact && s;
        3'd3: up = inexact && !s;
        3'd4: up = inexact && (0 ? (fint >= word) : (fint > word));
        default: up = inexact;
      endcase
      keep = keep + up;
      m0_rshift = s ? -$signed(keep) : $signed(keep);
    end
  endfunction
  // the SR word of a division: floor(|r| * 2^sb / |b|)
  function automatic [7:0] m0_divfrac(input [34:0] r, input [34:0] b);
    logic [43:0] t;
    t = ({{9{1'b0}}, r} << 8) / {{9{1'b0}}, b};
    m0_divfrac = t[7:0];
  endfunction
endpackage

// alu_core_m1_pkg: the exact-arithmetic functions of mode 1 (1xint16_unsigned)
package alu_core_m1_pkg;

  // ---- m1: V = {special[1:0], sign, exp[8] (signed), sig[17]}
  //           X = {special[1:0], sign, exp[8] (signed), sig[38], sticky}
  localparam int m1_SW = 17, m1_EW = 8, m1_XW = 38;
  localparam int m1_VW = 28, m1_XT = 50;
  function automatic [27:0] m1_mkv(input [1:0] sp, input s, input signed [7:0] e, input [16:0] sig);
    m1_mkv = {sp, s, e, sig};
  endfunction
  function automatic [49:0] m1_mkx(input [1:0] sp, input s, input signed [7:0] e, input [37:0] sig, input st);
    m1_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [49:0] m1_x(input [27:0] v);   // widen V to X
    m1_x = {v[27:27-1], v[27-2], v[27-3 -: 8], {{(38-17){1'b0}}, v[16:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [49:0] m1_norm(input [49:0] x);
    logic [37:0] s; logic signed [7:0] e; integer k;
    s = x[38:1]; e = x[38+8:38+1];
    if (s != 0) begin
      for (k = 32; k >= 1; k = k / 2) begin
        if (k < 38) begin
          if (s[37 -: 1] == 1'b0 && (s >> (38 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m1_norm = {x[49:49-1], x[49-2], e, s, x[0]};
  endfunction

  function automatic m1_rup(input [2:0] rnd, input s, input inexact, input [38:0] rest, input [38:0] halfv,
                             input st, input lsb, input [38+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m1_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m1_rup = 1'b0;
      3'd2: m1_rup = inexact && s;
      3'd3: m1_rup = inexact && !s;
      3'd4: m1_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m1_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [49:0] m1_add(input [49:0] a, input [49:0] b, input sub);
    logic [49:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [7:0] ea, eb, d; logic [38:0] ms, mb, r; logic st, stb; integer sh;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1];
    sa = na[49-2]; sb = nb[49-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m1_add = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m1_add = (sa == sb) ? m1_mkx(2'd2, sa, 0, 0, 1'b0) : m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_add = m1_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m1_add = m1_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[38:1] == 0 && !na[0]) m1_add = {nb[49:49-1], sb, nb[49-3:0]};
    else if (nb[38:1] == 0 && !nb[0]) m1_add = na;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[38:1] >= nb[38:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[38+8:38+1] - sml[38+8:38+1];
      ms = {1'b0, sml[38:1]}; stb = sml[0];
      if (d > 38 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 38 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[38:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[38]) begin st = st | r[0]; r = r >> 1; m1_add = m1_mkx(2'd0, sr, big[38+8:38+1] + 1, r[37:0], st); end
      else m1_add = m1_mkx(2'd0, sr, big[38+8:38+1], r[37:0], st);
    end
  endfunction
  function automatic [49:0] m1_mul(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38-1:0] pr; logic st; integer k;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m1_mul = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[38:1] == 0 && !na[0]) || (spb == 2'd0 && nb[38:1] == 0 && !nb[0]))
        m1_mul = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m1_mul = m1_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[38:1] * nb[38:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[37:0] != 0);
      m1_mul = m1_mkx(2'd0, s, na[38+8:38+1] + nb[38+8:38+1] + 38, pr[2*38-1:38], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*38+1:0] m1_udiv(input [37:0] a, input [37:0] dv);
    logic [38+1:0] r; logic [38:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 38; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[37:0], ge};
      if (i > 0) r = {r[38:0], 1'b0};
    end
    m1_udiv = {q, r[38:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*38+8+2:0] m1_mulx(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*38-1:0] pr;
    na = m1_norm(a); nb = m1_norm(b);
    pr = na[38:1] * nb[38:1];
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[38:1] == 0) || (spb == 2'd0 && nb[38:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m1_mulx = {sp, s, na[38+8:38+1] + nb[38+8:38+1], pr};
  endfunction
  function automatic [49:0] m1_div(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38+1:0] qr; logic [38:0] q, r;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_div = m1_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m1_div = m1_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[38:1] == 0 && !nb[0]) begin
      if (na[38:1] == 0 && !na[0]) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m1_div = m1_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[38:1] == 0 && !na[0]) m1_div = m1_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m1_udiv(na[38:1], nb[38:1]);     // both normalized: nonzero finite
      q = qr[2*38+1:38+1]; r = qr[38:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[38]) m1_div = m1_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38 + 1, q[38:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m1_div = m1_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38, q[37:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [49:0] m1_sqrt(input [49:0] a);
    logic [49:0] na; logic [1:0] spa; logic signed [7:0] e; logic [38:0] m; logic [2*38+3:0] rad;
    logic [38+2:0] rem, trial; logic [38:0] root; logic ge; integer i;
    na = m1_norm(a); spa = na[49:49-1];
    if (spa == 2'd1) m1_sqrt = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_sqrt = na[49-2] ? m1_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[38:1] == 0 && !na[0]) m1_sqrt = na;
    else if (na[49-2]) m1_sqrt = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[38+8:38+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[38:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[38:1]};
      rad = {{(38+3){1'b0}}, m} << 38;
      rem = 0; root = 0;
      for (i = 38; i >= 0; i = i - 1) begin
        rem = {rem[38:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[37:0], ge};
      end
      m1_sqrt = m1_mkx(2'd0, 1'b0, (e >>> 1) - 19 + 1, root[38:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m1_lt(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [7:0] ea, eb;
    na = m1_norm(a); nb = m1_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    sa = na[49-2] && !za; sb = nb[49-2] && !zb;
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m1_lt = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2) begin
      if (na[49:49-1] == 2'd2 && nb[49:49-1] == 2'd2) m1_lt = na[49-2] && !nb[49-2];
      else if (na[49:49-1] == 2'd2) m1_lt = na[49-2];
      else m1_lt = !nb[49-2];
    end else if (za && zb) m1_lt = 1'b0;
    else if (sa != sb) m1_lt = sa;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[38:1] < nb[38:1] || (na[38:1] == nb[38:1] && !na[0] && nb[0])));
      m1_lt = sa ? !mag_lt && !(za && zb) && !m1_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m1_eq(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb;
    na = m1_norm(a); nb = m1_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m1_eq = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2)
      m1_eq = (na[49:49-1] == nb[49:49-1]) && (na[49-2] == nb[49-2]);
    else if (za || zb) m1_eq = za && zb;
    else m1_eq = (na[49-2] == nb[49-2]) && (na[38+8:38+1] == nb[38+8:38+1]) && (na[38:1] == nb[38:1]) && (na[0] == nb[0]);
  endfunction

  function automatic [28:0] m1_unpack_s(input [15:0] b, input daz);
    logic s; logic [15:0] mag; integer i;
    s = 1'b0; mag = b;
    m1_unpack_s = {1'b0, m1_mkv(2'd0, s && (mag != 0), -0, {{(17-16){1'b0}}, mag})};
  endfunction

  function automatic [15:0] m1_enc(input signed [34:0] v); m1_enc = v[15:0]; endfunction
  function automatic [15:0] m1_wrap(input signed [34:0] v); m1_wrap = v[15:0]; endfunction
  function automatic [15:0] m1_sat(input signed [34:0] v);
    m1_sat = (v > 35'sd65535) ? {16{1'b1}} : (v < 0) ? 16'd0 : v[15:0];
  endfunction

  // round v / 2^f under rnd (the SR word applies to the fraction bits)
  function automatic signed [34:0] m1_rshift(input signed [34:0] v, input integer f, input [2:0] rnd, input [7:0] word);
    logic s; logic [34:0] mag, keep, rest, halfv; logic [43:0] fint; logic up, inexact;
    s = v < 0; mag = s ? -v : v;
    if (f <= 0) m1_rshift = v;
    else begin
      keep = mag >> f; rest = mag & (((35'd1) << f) - 1); halfv = (35'd1) << (f - 1);
      inexact = rest != 0;
      fint = (f >= 8) ? (rest >> (f - 8)) : (rest << (8 - f));
      case (rnd)
        3'd0: up = (rest > halfv) || (rest == halfv && keep[0]);
        3'd1: up = 1'b0;
        3'd2: up = inexact && s;
        3'd3: up = inexact && !s;
        3'd4: up = inexact && (0 ? (fint >= word) : (fint > word));
        default: up = inexact;
      endcase
      keep = keep + up;
      m1_rshift = s ? -$signed(keep) : $signed(keep);
    end
  endfunction
  // the SR word of a division: floor(|r| * 2^sb / |b|)
  function automatic [7:0] m1_divfrac(input [34:0] r, input [34:0] b);
    logic [43:0] t;
    t = ({{9{1'b0}}, r} << 8) / {{9{1'b0}}, b};
    m1_divfrac = t[7:0];
  endfunction
endpackage

// alu_core_m2_pkg: the exact-arithmetic functions of mode 2 (2xint8_twos_complement)
package alu_core_m2_pkg;

  // ---- m2: V = {special[1:0], sign, exp[8] (signed), sig[9]}
  //           X = {special[1:0], sign, exp[8] (signed), sig[22], sticky}
  localparam int m2_SW = 9, m2_EW = 8, m2_XW = 22;
  localparam int m2_VW = 20, m2_XT = 34;
  function automatic [19:0] m2_mkv(input [1:0] sp, input s, input signed [7:0] e, input [8:0] sig);
    m2_mkv = {sp, s, e, sig};
  endfunction
  function automatic [33:0] m2_mkx(input [1:0] sp, input s, input signed [7:0] e, input [21:0] sig, input st);
    m2_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [33:0] m2_x(input [19:0] v);   // widen V to X
    m2_x = {v[19:19-1], v[19-2], v[19-3 -: 8], {{(22-9){1'b0}}, v[8:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [33:0] m2_norm(input [33:0] x);
    logic [21:0] s; logic signed [7:0] e; integer k;
    s = x[22:1]; e = x[22+8:22+1];
    if (s != 0) begin
      for (k = 16; k >= 1; k = k / 2) begin
        if (k < 22) begin
          if (s[21 -: 1] == 1'b0 && (s >> (22 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m2_norm = {x[33:33-1], x[33-2], e, s, x[0]};
  endfunction

  function automatic m2_rup(input [2:0] rnd, input s, input inexact, input [22:0] rest, input [22:0] halfv,
                             input st, input lsb, input [22+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m2_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m2_rup = 1'b0;
      3'd2: m2_rup = inexact && s;
      3'd3: m2_rup = inexact && !s;
      3'd4: m2_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m2_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [33:0] m2_add(input [33:0] a, input [33:0] b, input sub);
    logic [33:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [7:0] ea, eb, d; logic [22:0] ms, mb, r; logic st, stb; integer sh;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[33:33-1]; spb = nb[33:33-1];
    sa = na[33-2]; sb = nb[33-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m2_add = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m2_add = (sa == sb) ? m2_mkx(2'd2, sa, 0, 0, 1'b0) : m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_add = m2_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m2_add = m2_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[22:1] == 0 && !na[0]) m2_add = {nb[33:33-1], sb, nb[33-3:0]};
    else if (nb[22:1] == 0 && !nb[0]) m2_add = na;
    else begin
      ea = na[22+8:22+1]; eb = nb[22+8:22+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[22:1] >= nb[22:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[22+8:22+1] - sml[22+8:22+1];
      ms = {1'b0, sml[22:1]}; stb = sml[0];
      if (d > 22 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 22 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[22:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[22]) begin st = st | r[0]; r = r >> 1; m2_add = m2_mkx(2'd0, sr, big[22+8:22+1] + 1, r[21:0], st); end
      else m2_add = m2_mkx(2'd0, sr, big[22+8:22+1], r[21:0], st);
    end
  endfunction
  function automatic [33:0] m2_mul(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*22-1:0] pr; logic st; integer k;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[33:33-1]; spb = nb[33:33-1]; s = na[33-2] ^ nb[33-2];
    if (spa == 2'd1 || spb == 2'd1) m2_mul = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[22:1] == 0 && !na[0]) || (spb == 2'd0 && nb[22:1] == 0 && !nb[0]))
        m2_mul = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m2_mul = m2_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[22:1] * nb[22:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[21:0] != 0);
      m2_mul = m2_mkx(2'd0, s, na[22+8:22+1] + nb[22+8:22+1] + 22, pr[2*22-1:22], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*22+1:0] m2_udiv(input [21:0] a, input [21:0] dv);
    logic [22+1:0] r; logic [22:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 22; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[21:0], ge};
      if (i > 0) r = {r[22:0], 1'b0};
    end
    m2_udiv = {q, r[22:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*22+8+2:0] m2_mulx(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*22-1:0] pr;
    na = m2_norm(a); nb = m2_norm(b);
    pr = na[22:1] * nb[22:1];
    spa = na[33:33-1]; spb = nb[33:33-1]; s = na[33-2] ^ nb[33-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[22:1] == 0) || (spb == 2'd0 && nb[22:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m2_mulx = {sp, s, na[22+8:22+1] + nb[22+8:22+1], pr};
  endfunction
  function automatic [33:0] m2_div(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*22+1:0] qr; logic [22:0] q, r;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[33:33-1]; spb = nb[33:33-1]; s = na[33-2] ^ nb[33-2];
    if (spa == 2'd1 || spb == 2'd1) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_div = m2_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m2_div = m2_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[22:1] == 0 && !nb[0]) begin
      if (na[22:1] == 0 && !na[0]) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m2_div = m2_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[22:1] == 0 && !na[0]) m2_div = m2_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m2_udiv(na[22:1], nb[22:1]);     // both normalized: nonzero finite
      q = qr[2*22+1:22+1]; r = qr[22:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[22]) m2_div = m2_mkx(2'd0, s, na[22+8:22+1] - nb[22+8:22+1] - 22 + 1, q[22:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m2_div = m2_mkx(2'd0, s, na[22+8:22+1] - nb[22+8:22+1] - 22, q[21:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [33:0] m2_sqrt(input [33:0] a);
    logic [33:0] na; logic [1:0] spa; logic signed [7:0] e; logic [22:0] m; logic [2*22+3:0] rad;
    logic [22+2:0] rem, trial; logic [22:0] root; logic ge; integer i;
    na = m2_norm(a); spa = na[33:33-1];
    if (spa == 2'd1) m2_sqrt = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_sqrt = na[33-2] ? m2_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[22:1] == 0 && !na[0]) m2_sqrt = na;
    else if (na[33-2]) m2_sqrt = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[22+8:22+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[22:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[22:1]};
      rad = {{(22+3){1'b0}}, m} << 22;
      rem = 0; root = 0;
      for (i = 22; i >= 0; i = i - 1) begin
        rem = {rem[22:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[21:0], ge};
      end
      m2_sqrt = m2_mkx(2'd0, 1'b0, (e >>> 1) - 11 + 1, root[22:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m2_lt(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [7:0] ea, eb;
    na = m2_norm(a); nb = m2_norm(b);
    za = (na[22:1] == 0) && !na[0]; zb = (nb[22:1] == 0) && !nb[0];
    sa = na[33-2] && !za; sb = nb[33-2] && !zb;
    if (na[33:33-1] == 2'd1 || nb[33:33-1] == 2'd1) m2_lt = 1'b0;
    else if (na[33:33-1] == 2'd2 || nb[33:33-1] == 2'd2) begin
      if (na[33:33-1] == 2'd2 && nb[33:33-1] == 2'd2) m2_lt = na[33-2] && !nb[33-2];
      else if (na[33:33-1] == 2'd2) m2_lt = na[33-2];
      else m2_lt = !nb[33-2];
    end else if (za && zb) m2_lt = 1'b0;
    else if (sa != sb) m2_lt = sa;
    else begin
      ea = na[22+8:22+1]; eb = nb[22+8:22+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[22:1] < nb[22:1] || (na[22:1] == nb[22:1] && !na[0] && nb[0])));
      m2_lt = sa ? !mag_lt && !(za && zb) && !m2_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m2_eq(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic za, zb;
    na = m2_norm(a); nb = m2_norm(b);
    za = (na[22:1] == 0) && !na[0]; zb = (nb[22:1] == 0) && !nb[0];
    if (na[33:33-1] == 2'd1 || nb[33:33-1] == 2'd1) m2_eq = 1'b0;
    else if (na[33:33-1] == 2'd2 || nb[33:33-1] == 2'd2)
      m2_eq = (na[33:33-1] == nb[33:33-1]) && (na[33-2] == nb[33-2]);
    else if (za || zb) m2_eq = za && zb;
    else m2_eq = (na[33-2] == nb[33-2]) && (na[22+8:22+1] == nb[22+8:22+1]) && (na[22:1] == nb[22:1]) && (na[0] == nb[0]);
  endfunction

  function automatic [20:0] m2_unpack_s(input [7:0] b, input daz);
    logic s; logic [7:0] mag; integer i;
    s = b[7]; mag = s ? (~b + 1'b1) : b;
    m2_unpack_s = {1'b0, m2_mkv(2'd0, s && (mag != 0), -0, {{(9-8){1'b0}}, mag})};
  endfunction

  function automatic [7:0] m2_enc(input signed [18:0] v); m2_enc = v[7:0]; endfunction
  function automatic [7:0] m2_wrap(input signed [18:0] v); m2_wrap = v[7:0]; endfunction
  function automatic [7:0] m2_sat(input signed [18:0] v);
    m2_sat = (v > 19'sd127) ? {1'b0, {7{1'b1}}} : (v < -19'sd128) ? {1'b1, {7{1'b0}}} : v[7:0];
  endfunction

  // round v / 2^f under rnd (the SR word applies to the fraction bits)
  function automatic signed [18:0] m2_rshift(input signed [18:0] v, input integer f, input [2:0] rnd, input [7:0] word);
    logic s; logic [18:0] mag, keep, rest, halfv; logic [27:0] fint; logic up, inexact;
    s = v < 0; mag = s ? -v : v;
    if (f <= 0) m2_rshift = v;
    else begin
      keep = mag >> f; rest = mag & (((19'd1) << f) - 1); halfv = (19'd1) << (f - 1);
      inexact = rest != 0;
      fint = (f >= 8) ? (rest >> (f - 8)) : (rest << (8 - f));
      case (rnd)
        3'd0: up = (rest > halfv) || (rest == halfv && keep[0]);
        3'd1: up = 1'b0;
        3'd2: up = inexact && s;
        3'd3: up = inexact && !s;
        3'd4: up = inexact && (0 ? (fint >= word) : (fint > word));
        default: up = inexact;
      endcase
      keep = keep + up;
      m2_rshift = s ? -$signed(keep) : $signed(keep);
    end
  endfunction
  // the SR word of a division: floor(|r| * 2^sb / |b|)
  function automatic [7:0] m2_divfrac(input [18:0] r, input [18:0] b);
    logic [27:0] t;
    t = ({{9{1'b0}}, r} << 8) / {{9{1'b0}}, b};
    m2_divfrac = t[7:0];
  endfunction
endpackage
// ADIR-MEMBER top
// EVOLVE-BLOCK-START
// ADIR-DECL v1
// VAR core.adder.m0.family=carry_increment
// VAR core.adder.m0.intergroup_carry=lookahead_tree
// VAR core.adder.m0.block_width=7
// VAR core.adder.m0.block_adder.full_adder_logic=two_half_adders_or
// VAR core.multiplier.m0.family=segmented_grid
// VAR core.multiplier.m0.recursion_depth=2
// VAR core.multiplier.m0.merge_form=carry_save_tree
// VAR core.multiplier.m0.segment.family=booth_recoded_parallel
// VAR core.multiplier.m0.segment.booth_radix=16
// VAR core.multiplier.m0.segment.hard_multiple_gen=partially_redundant
// VAR core.multiplier.m0.segment.sign_extension=full_extension
// VAR core.multiplier.m0.segment.reduction.family=tiled_cpa_reduction_tree
// VAR core.multiplier.m0.segment.reduction.adder_width=4
// VAR core.multiplier.m0.segment.reduction.terminal_reduction=compressor_9_2
// VAR core.multiplier.m0.segment.reduction.cpa.adder.family=ling_prefix
// VAR core.multiplier.m0.segment.reduction.cpa.adder.topology=kogge_stone
// VAR core.multiplier.m0.segment.reduction.cpa.adder.pseudo_carry_group=4
// VAR core.multiplier.m0.segment.reduction.cpa.adder.sum_recovery=xor_correction
// VAR core.multiplier.m0.segment.reduction.tile_adder.full_adder_logic=xor_majority
// VAR core.multiplier.m0.segment.hard_multiple_adder.full_adder_logic=xor_majority
// VAR core.multiplier.m0.segment.negation_incrementer.structure=select_blocks
// VAR core.multiplier.m0.merge_adder.family=sparse_prefix_hybrid
// VAR core.multiplier.m0.merge_adder.log2_sparsity=1
// VAR core.multiplier.m0.merge_adder.tree_topology=kogge_stone
// VAR core.multiplier.m0.merge_adder.sum_block_style=conditional_sum
// VAR core.multiplier.m0.merge_tree.counter_kind=4_2
// VAR core.multiplier.m0.merge_tree.cpa.family=hybrid_arrival_driven
// VAR core.multiplier.m0.merge_tree.cpa.region_count=4
// VAR core.multiplier.m0.merge_tree.cpa.region_adder_mix=ripple_cla_select
// VAR core.multiplier.m0.merge_tree.cpa.arrival_model=measured_tree_profile
// VAR core.multiplier.m0.merge_tree.cpa.boundary_search=delay_bound_boundary_enumeration
// VAR core.multiplier.m1.family=redundant_binary_multiplier
// VAR core.multiplier.m1.booth_radix=2
// VAR core.multiplier.m1.rb_encoding=plus_minus_pair
// VAR core.multiplier.m1.rbnb_converter=carry_select
// VAR core.multiplier.m1.final_converter.family=end_around_carry
// VAR core.multiplier.m1.final_converter.recirculation=select_based
// VAR core.multiplier.m1.final_converter.topology=harris
// VAR core.multiplier.m1.final_converter.log2_sparsity=1
// VAR core.multiplier.m1.final_converter.fanout_cap=6
// VAR core.multiplier.m1.final_converter.incrementer.structure=select_blocks
// VAR core.multiplier.m2.family=segmented_grid
// VAR core.multiplier.m2.recursion_depth=3
// VAR core.multiplier.m2.seg_w=8
// VAR core.multiplier.m2.num_seg=3
// VAR core.multiplier.m2.segment_shape=rectangular
// VAR core.multiplier.m2.merge_form=carry_save_tree
// VAR core.multiplier.m2.segment.reduction.family=tiled_cpa_reduction_tree
// VAR core.multiplier.m2.segment.reduction.adder_width=4
// VAR core.multiplier.m2.segment.reduction.carry_assimilation=terminal_compressor
// VAR core.multiplier.m2.segment.reduction.terminal_reduction=compressor_4_2
// VAR core.multiplier.m2.segment.reduction.cpa.adder.family=carry_increment
// VAR core.multiplier.m2.segment.reduction.cpa.adder.intergroup_carry=lookahead_tree
// VAR core.multiplier.m2.segment.reduction.cpa.adder.block_adder.full_adder_logic=two_half_adders_or
// VAR core.multiplier.m2.segment.reduction.cpa.adder.increment_stage.structure=select_blocks
// VAR core.multiplier.m2.segment.reduction.tile_adder.full_adder_logic=two_half_adders_or
// VAR core.multiplier.m2.segment.hard_multiple_adder.family=parallel_prefix
// VAR core.multiplier.m2.merge_adder.family=carry_increment
// VAR core.multiplier.m2.merge_adder.intergroup_carry=lookahead_tree
// VAR core.multiplier.m2.merge_adder.block_sizing=variable_ramp
// VAR core.multiplier.m2.merge_adder.increment_stage.structure=prefix_and_tree
// VAR core.multiplier.m2.merge_adder.increment_stage.topology=kogge_stone
// VAR core.multiplier.m2.merge_tree.geometry=tdm_arrival_driven
// VAR core.multiplier.m2.merge_tree.counter_kind=7_3
// VAR core.multiplier.m2.merge_tree.cpa.family=hybrid_arrival_driven
// VAR core.multiplier.m2.merge_tree.cpa.arrival_model=measured_tree_profile
// VAR core.multiplier.m2.merge_tree.cpa.boundary_search=delay_bound_boundary_enumeration
// VAR core.shifter.m0.family=masked_merged
// VAR core.shifter.m0.sticky_collect=true
// VAR core.shifter.m0.rotator.stage_order=large_shift_first
// VAR core.shifter.m1.family=funnel
// VAR core.shifter.m1.window_mux_radix=4
// VAR core.shifter.m2.family=masked_merged
// VAR core.shifter.m2.sticky_collect=true
// VAR core.shifter.m2.merge_style=per_bit_mux
// VAR core.shifter.m2.rotator.stage_radix=4
// VAR core.shifter.m2.rotator.select_encoding=one_hot_decoded
// VAR core.shifter.m2.rotator.stage_order=large_shift_first
// VAR core.bitcount.m0.family=trailing_zero
// VAR core.bitcount.m0.isolate_circuit=ripple_kill_chain
// VAR core.bitcount.m0.lzd.family=priority_encoder
// VAR core.bitcount.m0.lzd.output_form=one_hot_then_encode
// VAR core.bitcount.m0.lzd.levels=2
// VAR core.bitcount.m0.negation_incrementer.structure=prefix_and_tree
// VAR core.bitcount.m1.final_adder.family=carry_skip
// VAR core.bitcount.m1.final_adder.block_sizing=dp_optimized
// VAR core.bitcount.m1.final_adder.block_adder.full_adder_logic=xor_majority
// VAR core.bitcount.m2.family=trailing_zero
// VAR core.bitcount.m2.lzd.family=prefix_lzc
// VAR core.bitcount.m2.lzd.prefix_topology=brent_kung
// VAR core.bitcount.m2.lzd.count_form=lookahead_flags
// VAR core.bitcount.m2.lzd.counter.counter_primitive=compressor_4_2
// VAR core.bitcount.m2.lzd.counter.final_adder.family=conditional_sum
// VAR core.bitcount.m2.negation_incrementer.structure=prefix_and_tree
// VAR core.logic.m0.family=wide_gate_row
// VAR core.logic.m0.not_via_xor=true
// VAR core.comparator.m0.radix=3
// VAR core.comparator.m1.family=subtractor_comparator
// VAR core.comparator.m1.subtractor.family=carry_increment
// VAR core.comparator.m1.subtractor.intergroup_carry=rippled
// VAR core.comparator.m1.subtractor.block_width=7
// VAR core.comparator.m1.subtractor.increment_levels=2
// VAR core.comparator.m1.subtractor.block_adder.family=parallel_prefix
// VAR core.comparator.m1.subtractor.block_adder.topology=kogge_stone
// VAR core.comparator.m1.subtractor.block_adder.valency=3
// VAR core.comparator.m1.subtractor.increment_stage.structure=prefix_and_tree
// VAR core.comparator.m2.family=subtractor_comparator
// VAR core.comparator.m2.zero_detect=operand_xnor
// VAR core.comparator.m2.subtractor.family=prefix_synthesis_nonuniform_arrival
// VAR core.comparator.m2.subtractor.arrival_profile=multiplier_vee
// VAR core.adder.m1.family=carry_increment
// VAR core.adder.m1.intergroup_carry=lookahead_tree
// VAR core.adder.m1.block_width=7
// VAR core.adder.m1.block_adder.full_adder_logic=two_half_adders_or
// VAR core.adder.m2.family=carry_increment
// VAR core.adder.m2.intergroup_carry=lookahead_tree
// VAR core.adder.m2.block_width=7
// VAR core.adder.m2.block_adder.full_adder_logic=two_half_adders_or
// STRUCTURE m0.l0.adder kind=adder slot=adder mode=0 lane=0 width=16 format=int16_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m0_l0_adder
// STRUCTURE m0.l0.multiplier kind=multiplier slot=multiplier mode=0 lane=0 width=16 format=int16_twos_complement ops=mul,mul_high sv=alu_core_u_m0_l0_multiplier
// STRUCTURE m0.l0.comparator kind=comparator slot=comparator mode=0 lane=0 width=16 format=int16_twos_complement ops=min,max,cmp sv=alu_core_u_m0_l0_comparator
// STRUCTURE m0.l0.shifter kind=shifter slot=shifter mode=0 lane=0 width=16 format=int16_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m0_l0_shifter
// STRUCTURE m0.l0.logic kind=logic slot=logic mode=0 lane=0 width=16 format=int16_twos_complement ops=and,or,xor,not sv=alu_core_u_m0_l0_logic
// STRUCTURE m0.l0.bitcount kind=bitcount slot=bitcount mode=0 lane=0 width=16 format=int16_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m0_l0_bitcount
// STRUCTURE m1.l0.adder kind=adder slot=adder mode=1 lane=0 width=16 format=int16_unsigned ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m1_l0_adder
// STRUCTURE m1.l0.multiplier kind=multiplier slot=multiplier mode=1 lane=0 width=16 format=int16_unsigned ops=mul,mul_high sv=alu_core_u_m1_l0_multiplier
// STRUCTURE m1.l0.comparator kind=comparator slot=comparator mode=1 lane=0 width=16 format=int16_unsigned ops=min,max,cmp sv=alu_core_u_m1_l0_comparator
// STRUCTURE m1.l0.shifter kind=shifter slot=shifter mode=1 lane=0 width=16 format=int16_unsigned ops=shl,shr_arith,rol sv=alu_core_u_m1_l0_shifter
// STRUCTURE m1.l0.logic kind=logic slot=logic mode=1 lane=0 width=16 format=int16_unsigned ops=and,or,xor,not sv=alu_core_u_m1_l0_logic
// STRUCTURE m1.l0.bitcount kind=bitcount slot=bitcount mode=1 lane=0 width=16 format=int16_unsigned ops=popcount,clz,ctz sv=alu_core_u_m1_l0_bitcount
// STRUCTURE m2.l0.adder kind=adder slot=adder mode=2 lane=0 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m2_l0_adder
// STRUCTURE m2.l1.adder kind=adder slot=adder mode=2 lane=1 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m2_l1_adder
// STRUCTURE m2.l0.multiplier kind=multiplier slot=multiplier mode=2 lane=0 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_m2_l0_multiplier
// STRUCTURE m2.l1.multiplier kind=multiplier slot=multiplier mode=2 lane=1 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_m2_l1_multiplier
// STRUCTURE m2.l0.comparator kind=comparator slot=comparator mode=2 lane=0 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_m2_l0_comparator
// STRUCTURE m2.l1.comparator kind=comparator slot=comparator mode=2 lane=1 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_m2_l1_comparator
// STRUCTURE m2.l0.shifter kind=shifter slot=shifter mode=2 lane=0 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l0_shifter
// STRUCTURE m2.l1.shifter kind=shifter slot=shifter mode=2 lane=1 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l1_shifter
// STRUCTURE m2.l0.logic kind=logic slot=logic mode=2 lane=0 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_m2_l0_logic
// STRUCTURE m2.l1.logic kind=logic slot=logic mode=2 lane=1 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_m2_l1_logic
// STRUCTURE m2.l0.bitcount kind=bitcount slot=bitcount mode=2 lane=0 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l0_bitcount
// STRUCTURE m2.l1.bitcount kind=bitcount slot=bitcount mode=2 lane=1 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l1_bitcount
// ADIR-END
module alu_core (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  output logic [15:0] y,
  output logic [3:0] flags
);
  // alu_core: behavioral reference derived from the instance (modes 1xint16_twos_complement, 1xint16_unsigned, 2xint8_twos_complement; ops add, sub, adc, neg, abs, add_sat, mul, mul_high, min, max, cmp, shl, shr_arith, rol, and, or, xor, not, popcount, clz, ctz). Every (mode, op) pair computes the verify layer's exact semantics.
  // HIERARCHY: 24 physical structure modules instantiated by alu_core, built from 17 lane modules (one per mode and kind, parameter LANE) and 3 packages of engine functions (one per mode); a float mode's datapath is split into an unpacker (the xa/xb/den buses), the arithmetic and converter structures (unrounded results on the x bus) and a rounder (y and the flags); 0 misc lane modules and 0 block-conversion group modules
  // UNIT m0.l0.adder module=alu_core_u_m0_l0_adder kind=adder members=m0.l0.adder
  // UNIT m0.l0.multiplier module=alu_core_u_m0_l0_multiplier kind=multiplier members=m0.l0.multiplier
  // UNIT m0.l0.comparator module=alu_core_u_m0_l0_comparator kind=comparator members=m0.l0.comparator
  // UNIT m0.l0.shifter module=alu_core_u_m0_l0_shifter kind=shifter members=m0.l0.shifter
  // UNIT m0.l0.logic module=alu_core_u_m0_l0_logic kind=logic members=m0.l0.logic
  // UNIT m0.l0.bitcount module=alu_core_u_m0_l0_bitcount kind=bitcount members=m0.l0.bitcount
  // UNIT m1.l0.adder module=alu_core_u_m1_l0_adder kind=adder members=m1.l0.adder
  // UNIT m1.l0.multiplier module=alu_core_u_m1_l0_multiplier kind=multiplier members=m1.l0.multiplier
  // UNIT m1.l0.comparator module=alu_core_u_m1_l0_comparator kind=comparator members=m1.l0.comparator
  // UNIT m1.l0.shifter module=alu_core_u_m1_l0_shifter kind=shifter members=m1.l0.shifter
  // UNIT m1.l0.logic module=alu_core_u_m1_l0_logic kind=logic members=m1.l0.logic
  // UNIT m1.l0.bitcount module=alu_core_u_m1_l0_bitcount kind=bitcount members=m1.l0.bitcount
  // UNIT m2.l0.adder module=alu_core_u_m2_l0_adder kind=adder members=m2.l0.adder
  // UNIT m2.l1.adder module=alu_core_u_m2_l1_adder kind=adder members=m2.l1.adder
  // UNIT m2.l0.multiplier module=alu_core_u_m2_l0_multiplier kind=multiplier members=m2.l0.multiplier
  // UNIT m2.l1.multiplier module=alu_core_u_m2_l1_multiplier kind=multiplier members=m2.l1.multiplier
  // UNIT m2.l0.comparator module=alu_core_u_m2_l0_comparator kind=comparator members=m2.l0.comparator
  // UNIT m2.l1.comparator module=alu_core_u_m2_l1_comparator kind=comparator members=m2.l1.comparator
  // UNIT m2.l0.shifter module=alu_core_u_m2_l0_shifter kind=shifter members=m2.l0.shifter
  // UNIT m2.l1.shifter module=alu_core_u_m2_l1_shifter kind=shifter members=m2.l1.shifter
  // UNIT m2.l0.logic module=alu_core_u_m2_l0_logic kind=logic members=m2.l0.logic
  // UNIT m2.l1.logic module=alu_core_u_m2_l1_logic kind=logic members=m2.l1.logic
  // UNIT m2.l0.bitcount module=alu_core_u_m2_l0_bitcount kind=bitcount members=m2.l0.bitcount
  // UNIT m2.l1.bitcount module=alu_core_u_m2_l1_bitcount kind=bitcount members=m2.l1.bitcount
  // // STRUCTURE m0.l0.adder kind=adder slot=adder mode=0 lane=0 width=16 format=int16_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m0_l0_adder
  // // STRUCTURE m0.l0.multiplier kind=multiplier slot=multiplier mode=0 lane=0 width=16 format=int16_twos_complement ops=mul,mul_high sv=alu_core_u_m0_l0_multiplier
  // // STRUCTURE m0.l0.comparator kind=comparator slot=comparator mode=0 lane=0 width=16 format=int16_twos_complement ops=min,max,cmp sv=alu_core_u_m0_l0_comparator
  // // STRUCTURE m0.l0.shifter kind=shifter slot=shifter mode=0 lane=0 width=16 format=int16_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m0_l0_shifter
  // // STRUCTURE m0.l0.logic kind=logic slot=logic mode=0 lane=0 width=16 format=int16_twos_complement ops=and,or,xor,not sv=alu_core_u_m0_l0_logic
  // // STRUCTURE m0.l0.bitcount kind=bitcount slot=bitcount mode=0 lane=0 width=16 format=int16_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m0_l0_bitcount
  // // STRUCTURE m1.l0.adder kind=adder slot=adder mode=1 lane=0 width=16 format=int16_unsigned ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m1_l0_adder
  // // STRUCTURE m1.l0.multiplier kind=multiplier slot=multiplier mode=1 lane=0 width=16 format=int16_unsigned ops=mul,mul_high sv=alu_core_u_m1_l0_multiplier
  // // STRUCTURE m1.l0.comparator kind=comparator slot=comparator mode=1 lane=0 width=16 format=int16_unsigned ops=min,max,cmp sv=alu_core_u_m1_l0_comparator
  // // STRUCTURE m1.l0.shifter kind=shifter slot=shifter mode=1 lane=0 width=16 format=int16_unsigned ops=shl,shr_arith,rol sv=alu_core_u_m1_l0_shifter
  // // STRUCTURE m1.l0.logic kind=logic slot=logic mode=1 lane=0 width=16 format=int16_unsigned ops=and,or,xor,not sv=alu_core_u_m1_l0_logic
  // // STRUCTURE m1.l0.bitcount kind=bitcount slot=bitcount mode=1 lane=0 width=16 format=int16_unsigned ops=popcount,clz,ctz sv=alu_core_u_m1_l0_bitcount
  // // STRUCTURE m2.l0.adder kind=adder slot=adder mode=2 lane=0 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m2_l0_adder
  // // STRUCTURE m2.l1.adder kind=adder slot=adder mode=2 lane=1 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m2_l1_adder
  // // STRUCTURE m2.l0.multiplier kind=multiplier slot=multiplier mode=2 lane=0 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_m2_l0_multiplier
  // // STRUCTURE m2.l1.multiplier kind=multiplier slot=multiplier mode=2 lane=1 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_m2_l1_multiplier
  // // STRUCTURE m2.l0.comparator kind=comparator slot=comparator mode=2 lane=0 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_m2_l0_comparator
  // // STRUCTURE m2.l1.comparator kind=comparator slot=comparator mode=2 lane=1 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_m2_l1_comparator
  // // STRUCTURE m2.l0.shifter kind=shifter slot=shifter mode=2 lane=0 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l0_shifter
  // // STRUCTURE m2.l1.shifter kind=shifter slot=shifter mode=2 lane=1 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l1_shifter
  // // STRUCTURE m2.l0.logic kind=logic slot=logic mode=2 lane=0 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_m2_l0_logic
  // // STRUCTURE m2.l1.logic kind=logic slot=logic mode=2 lane=1 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_m2_l1_logic
  // // STRUCTURE m2.l0.bitcount kind=bitcount slot=bitcount mode=2 lane=0 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l0_bitcount
  // // STRUCTURE m2.l1.bitcount kind=bitcount slot=bitcount mode=2 lane=1 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l1_bitcount
  // LIBRARY: fam_add_partitioned_w16_16_carry_kill_gate_97f154d649b3, fam_add_partitioned_w16_8_carry_kill_gate_97f154d649b3, fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16, fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_block_adder_adder_w2, fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_block_adder_adder_w7, fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_increment_stage_incrementer_w14, fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_increment_stage_incrementer_w2, fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_increment_stage_incrementer_w7, fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w16, fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w16_component_block_adder_adder_w2, fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w16_component_block_adder_adder_w7, fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w16_component_increment_stage_incrementer_w2, fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w16_component_increment_stage_incrementer_w7, fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w8, fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w8_component_block_adder_adder_w1, fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w8_component_block_adder_adder_w7, fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w8_component_increment_stage_incrementer_w1, fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w8_component_increment_stage_incrementer_w7, fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26, fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_block_adder_adder_w2, fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_increment_stage_incrementer_w2, fam_adder_carry_lookahead, fam_adder_carry_select_w11, fam_adder_carry_select_w11_component_block_adder_adder_w3, fam_adder_carry_select_w11_component_block_adder_adder_w4, fam_adder_carry_select_w13, fam_adder_carry_select_w13_component_block_adder_adder_w1, fam_adder_carry_select_w13_component_block_adder_adder_w4, fam_adder_carry_select_w34, fam_adder_carry_select_w34_component_block_adder_adder_w2, fam_adder_carry_select_w34_component_block_adder_adder_w4, fam_adder_carry_select_w4, fam_adder_carry_select_w4_component_block_adder_adder_w4, fam_adder_carry_select_w5, fam_adder_carry_select_w5_component_block_adder_adder_w1, fam_adder_carry_select_w5_component_block_adder_adder_w4, fam_adder_carry_select_w6, fam_adder_carry_select_w6_component_block_adder_adder_w2, fam_adder_carry_select_w6_component_block_adder_adder_w4, fam_adder_carry_select_w8, fam_adder_carry_select_w8_component_block_adder_adder_w4, fam_adder_carry_select_w9, fam_adder_carry_select_w9_component_block_adder_adder_w1, fam_adder_carry_select_w9_component_block_adder_adder_w4, fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w2, fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w2_component_block_adder_adder_w2, fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w3, fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w3_component_block_adder_adder_w1, fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w4, fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w4_component_block_adder_adder_w1, fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w4_component_block_adder_adder_w2, fam_adder_cla_level, fam_adder_ripple_carry, fam_adder_ripple_chunk, fam_cmp_prefix_comparator, fam_cmp_subtractor_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_sum_or_tree_u_w16, fam_cmp_subtractor_prefix_synthesis_nonuniform_arrival_pc87885195967a6123ef6af9e4b2732165d2e32528a8c668a3c2a6850933d85a8_operand_xnor_s_w8, fam_count_popcount_balanced_tree_full_adder_3_2_carry_skip_pb5ae0_w16, fam_count_prefix_lzc_brent_kung_flags_w8, fam_count_priority_encoder_g4_l2_one_hot_then_encode_w16, fam_count_tzc_reverse_prefix_lzc_pb8d18_w8, fam_count_tzc_reverse_priority_encoder_pdb5fa_w16, fam_incr_prefix_and, fam_logic_gate_row, fam_mul_booth16_dadda_3_2_w4_u_pe5d7a1e3, fam_mul_booth16_dadda_3_2_w5_u_pe5d7a1e3, fam_mul_booth16_dadda_3_2_w6_s_pe5d7a1e3, fam_mul_direct_dadda_3_2_w13_s_pbe89483b, fam_mul_redundant_binary_multiplier_w16_u_pe58f448b, fam_mul_segmented_grid_w16_s_p012a83fa, fam_mul_segmented_grid_w16_s_p012a83fa_g00, fam_mul_segmented_grid_w16_s_p012a83fa_g01, fam_mul_segmented_grid_w16_s_p012a83fa_g10, fam_mul_segmented_grid_w16_s_p012a83fa_g11, fam_mul_segmented_grid_w8_s_pda2147ed, fam_mul_segmented_grid_w8_s_pda2147ed_g00, fam_mul_segmented_grid_w8_s_pda2147ed_g00_g00, fam_mul_segmented_grid_w8_s_pda2147ed_g00_g10, fam_mul_segmented_grid_w8_s_pda2147ed_g10, fam_mul_segmented_grid_w8_s_pda2147ed_g10_g00, fam_mul_segmented_grid_w8_s_pda2147ed_g10_g10, fam_prefix_arrival_0_1_2_2_3_2_2_1_w8, fam_prefix_kogge_stone_w10_ling4, fam_prefix_kogge_stone_w12_ling4, fam_prefix_kogge_stone_w2_v3, fam_prefix_kogge_stone_w7_v3, fam_prefix_kogge_stone_w8_ling4, fam_shift_funnel, fam_shift_keep_mask, fam_shift_masked_merged, fam_shift_stage (chialu.targets.rtl.families: the modules of the declared families the lane modules instantiate; their text follows the generated modules)
  logic [2:0] rnd_sel;
  logic [2:0] rnd;
  logic daz;
  logic ftz;
  logic dual;
  logic [15:0] y_m0_m0_l0_adder;
  logic [19:0] fl_m0_m0_l0_adder;
  logic [15:0] y_m0_m0_l0_multiplier;
  logic [19:0] fl_m0_m0_l0_multiplier;
  logic [15:0] y_m0_m0_l0_comparator;
  logic [19:0] fl_m0_m0_l0_comparator;
  logic [15:0] y_m0_m0_l0_shifter;
  logic [19:0] fl_m0_m0_l0_shifter;
  logic [15:0] y_m0_m0_l0_logic;
  logic [19:0] fl_m0_m0_l0_logic;
  logic [15:0] y_m0_m0_l0_bitcount;
  logic [19:0] fl_m0_m0_l0_bitcount;
  logic [15:0] y_m0;
  logic [19:0] fl_m0;
  logic [15:0] y_m1_m1_l0_adder;
  logic [19:0] fl_m1_m1_l0_adder;
  logic [15:0] y_m1_m1_l0_multiplier;
  logic [19:0] fl_m1_m1_l0_multiplier;
  logic [15:0] y_m1_m1_l0_comparator;
  logic [19:0] fl_m1_m1_l0_comparator;
  logic [15:0] y_m1_m1_l0_shifter;
  logic [19:0] fl_m1_m1_l0_shifter;
  logic [15:0] y_m1_m1_l0_logic;
  logic [19:0] fl_m1_m1_l0_logic;
  logic [15:0] y_m1_m1_l0_bitcount;
  logic [19:0] fl_m1_m1_l0_bitcount;
  logic [15:0] y_m1;
  logic [19:0] fl_m1;
  logic [15:0] y_m2_m2_l0_adder;
  logic [19:0] fl_m2_m2_l0_adder;
  logic [15:0] y_m2_m2_l1_adder;
  logic [19:0] fl_m2_m2_l1_adder;
  logic [15:0] y_m2_m2_l0_multiplier;
  logic [19:0] fl_m2_m2_l0_multiplier;
  logic [15:0] y_m2_m2_l1_multiplier;
  logic [19:0] fl_m2_m2_l1_multiplier;
  logic [15:0] y_m2_m2_l0_comparator;
  logic [19:0] fl_m2_m2_l0_comparator;
  logic [15:0] y_m2_m2_l1_comparator;
  logic [19:0] fl_m2_m2_l1_comparator;
  logic [15:0] y_m2_m2_l0_shifter;
  logic [19:0] fl_m2_m2_l0_shifter;
  logic [15:0] y_m2_m2_l1_shifter;
  logic [19:0] fl_m2_m2_l1_shifter;
  logic [15:0] y_m2_m2_l0_logic;
  logic [19:0] fl_m2_m2_l0_logic;
  logic [15:0] y_m2_m2_l1_logic;
  logic [19:0] fl_m2_m2_l1_logic;
  logic [15:0] y_m2_m2_l0_bitcount;
  logic [19:0] fl_m2_m2_l0_bitcount;
  logic [15:0] y_m2_m2_l1_bitcount;
  logic [19:0] fl_m2_m2_l1_bitcount;
  logic [15:0] y_m2;
  logic [19:0] fl_m2;
  logic [19:0] fl_all;
  assign rnd_sel = 3'd0;
  assign rnd = rnd_sel;
  assign daz = 1'b0;
  assign ftz = 1'b0;
  assign dual = 1'b0;
  assign y_m0 = y_m0_m0_l0_adder | y_m0_m0_l0_multiplier | y_m0_m0_l0_comparator | y_m0_m0_l0_shifter | y_m0_m0_l0_logic | y_m0_m0_l0_bitcount;
  assign fl_m0 = fl_m0_m0_l0_adder | fl_m0_m0_l0_multiplier | fl_m0_m0_l0_comparator | fl_m0_m0_l0_shifter | fl_m0_m0_l0_logic | fl_m0_m0_l0_bitcount;
  assign y_m1 = y_m1_m1_l0_adder | y_m1_m1_l0_multiplier | y_m1_m1_l0_comparator | y_m1_m1_l0_shifter | y_m1_m1_l0_logic | y_m1_m1_l0_bitcount;
  assign fl_m1 = fl_m1_m1_l0_adder | fl_m1_m1_l0_multiplier | fl_m1_m1_l0_comparator | fl_m1_m1_l0_shifter | fl_m1_m1_l0_logic | fl_m1_m1_l0_bitcount;
  assign y_m2 = y_m2_m2_l0_adder | y_m2_m2_l1_adder | y_m2_m2_l0_multiplier | y_m2_m2_l1_multiplier | y_m2_m2_l0_comparator | y_m2_m2_l1_comparator | y_m2_m2_l0_shifter | y_m2_m2_l1_shifter | y_m2_m2_l0_logic | y_m2_m2_l1_logic | y_m2_m2_l0_bitcount | y_m2_m2_l1_bitcount;
  assign fl_m2 = fl_m2_m2_l0_adder | fl_m2_m2_l1_adder | fl_m2_m2_l0_multiplier | fl_m2_m2_l1_multiplier | fl_m2_m2_l0_comparator | fl_m2_m2_l1_comparator | fl_m2_m2_l0_shifter | fl_m2_m2_l1_shifter | fl_m2_m2_l0_logic | fl_m2_m2_l1_logic | fl_m2_m2_l0_bitcount | fl_m2_m2_l1_bitcount;
  alu_core_u_m0_l0_adder u_m0_l0_adder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_adder), .fl_m0(fl_m0_m0_l0_adder));
  alu_core_u_m0_l0_multiplier u_m0_l0_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_multiplier), .fl_m0(fl_m0_m0_l0_multiplier));
  alu_core_u_m0_l0_comparator u_m0_l0_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_comparator), .fl_m0(fl_m0_m0_l0_comparator));
  alu_core_u_m0_l0_shifter u_m0_l0_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_shifter), .fl_m0(fl_m0_m0_l0_shifter));
  alu_core_u_m0_l0_logic u_m0_l0_logic (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_logic), .fl_m0(fl_m0_m0_l0_logic));
  alu_core_u_m0_l0_bitcount u_m0_l0_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_bitcount), .fl_m0(fl_m0_m0_l0_bitcount));
  alu_core_u_m1_l0_adder u_m1_l0_adder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_adder), .fl_m1(fl_m1_m1_l0_adder));
  alu_core_u_m1_l0_multiplier u_m1_l0_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_multiplier), .fl_m1(fl_m1_m1_l0_multiplier));
  alu_core_u_m1_l0_comparator u_m1_l0_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_comparator), .fl_m1(fl_m1_m1_l0_comparator));
  alu_core_u_m1_l0_shifter u_m1_l0_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_shifter), .fl_m1(fl_m1_m1_l0_shifter));
  alu_core_u_m1_l0_logic u_m1_l0_logic (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_logic), .fl_m1(fl_m1_m1_l0_logic));
  alu_core_u_m1_l0_bitcount u_m1_l0_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_bitcount), .fl_m1(fl_m1_m1_l0_bitcount));
  alu_core_u_m2_l0_adder u_m2_l0_adder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_adder), .fl_m2(fl_m2_m2_l0_adder));
  alu_core_u_m2_l1_adder u_m2_l1_adder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_adder), .fl_m2(fl_m2_m2_l1_adder));
  alu_core_u_m2_l0_multiplier u_m2_l0_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_multiplier), .fl_m2(fl_m2_m2_l0_multiplier));
  alu_core_u_m2_l1_multiplier u_m2_l1_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_multiplier), .fl_m2(fl_m2_m2_l1_multiplier));
  alu_core_u_m2_l0_comparator u_m2_l0_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_comparator), .fl_m2(fl_m2_m2_l0_comparator));
  alu_core_u_m2_l1_comparator u_m2_l1_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_comparator), .fl_m2(fl_m2_m2_l1_comparator));
  alu_core_u_m2_l0_shifter u_m2_l0_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_shifter), .fl_m2(fl_m2_m2_l0_shifter));
  alu_core_u_m2_l1_shifter u_m2_l1_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_shifter), .fl_m2(fl_m2_m2_l1_shifter));
  alu_core_u_m2_l0_logic u_m2_l0_logic (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_logic), .fl_m2(fl_m2_m2_l0_logic));
  alu_core_u_m2_l1_logic u_m2_l1_logic (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_logic), .fl_m2(fl_m2_m2_l1_logic));
  alu_core_u_m2_l0_bitcount u_m2_l0_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_bitcount), .fl_m2(fl_m2_m2_l0_bitcount));
  alu_core_u_m2_l1_bitcount u_m2_l1_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_bitcount), .fl_m2(fl_m2_m2_l1_bitcount));
  always_comb begin
    case (mode)
      2'd0: begin y = y_m0; fl_all = fl_m0; end
      2'd1: begin y = y_m1; fl_all = fl_m1; end
      2'd2: begin y = y_m2; fl_all = fl_m2; end
      default: begin y = '0; fl_all = '0; end
    endcase
  end
  assign flags[0] = fl_all[7];
  assign flags[1] = fl_all[8];
  assign flags[2] = fl_all[17];
  assign flags[3] = fl_all[18];
endmodule
// EVOLVE-BLOCK-END

module alu_core_m0_adder_sh #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0,
  output logic [15:0] pc_a_m0,
  output logic [15:0] pc_b_m0,
  output logic [0:0] pc_cin_m0,
  input  logic [15:0] pc_s_m0,
  input  logic [0:0] pc_co_m0
);
  // alu_core_m0_adder_sh: lane LANE of mode 0 (int16_twos_complement) for the adder ops add, sub, adc, neg, abs, add_sat; the result buses are the mode's, with only this lane's bits written; the unit's shared adder serve this lane through the pc_/tp_ buses
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_add_sLANE;
  logic m0_add_coutLANE;
  logic signed [34:0] m0_o0ex0_LANE;
  logic signed [34:0] m0_o1ex0_LANE;
  logic signed [34:0] m0_o2ex0_LANE;
  logic signed [34:0] m0_o3ex0_LANE;
  logic signed [34:0] m0_o4ex0_LANE;
  logic signed [34:0] m0_o5ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.adder.m0: the unit's shared partitioned adder (subword partitioned_carry_chain)
  assign m0_add_sLANE = pc_s_m0[(LANE)*16 +: 16];
  assign m0_add_coutLANE = pc_co_m0[(LANE+1)*1-1];
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_o0ex0_LANE = 'x; m0_o1ex0_LANE = 'x; m0_o2ex0_LANE = 'x; m0_o3ex0_LANE = 'x; m0_o4ex0_LANE = 'x; m0_o5ex0_LANE = 'x;
    pc_a_m0 = '0; pc_b_m0 = '0; pc_cin_m0 = '0;
    case (op)
      5'd0: begin
        pc_a_m0[(LANE)*16 +: 16] = m0_aLANE; pc_b_m0[(LANE)*16 +: 16] = m0_bLANE; pc_cin_m0[(LANE)*1] = 1'b0;
        m0_o0ex0_LANE = $signed({(m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o0ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (m0_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd1: begin
        pc_a_m0[(LANE)*16 +: 16] = m0_aLANE; pc_b_m0[(LANE)*16 +: 16] = ~m0_bLANE; pc_cin_m0[(LANE)*1] = 1'b1;
        m0_o1ex0_LANE = $signed({(m0_aLANE[15] ^ ~m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o1ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ ~m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ ~m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (~m0_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd2: begin
        pc_a_m0[(LANE)*16 +: 16] = m0_aLANE; pc_b_m0[(LANE)*16 +: 16] = m0_bLANE; pc_cin_m0[(LANE)*1] = 1'b1;
        m0_o2ex0_LANE = $signed({(m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o2ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (m0_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd3: begin
        pc_a_m0[(LANE)*16 +: 16] = 16'd0; pc_b_m0[(LANE)*16 +: 16] = ~m0_aLANE; pc_cin_m0[(LANE)*1] = 1'b1;
        m0_o3ex0_LANE = $signed({(1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o3ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (m0_aLANE != 0 ? (10'd1 << 7) : 10'd0);
      end
      5'd4: begin
        pc_a_m0[(LANE)*16 +: 16] = 16'd0; pc_b_m0[(LANE)*16 +: 16] = ~m0_aLANE; pc_cin_m0[(LANE)*1] = 1'b1;
        m0_o4ex0_LANE = (m0_aLANE[15] ? $signed({(1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE), m0_add_sLANE}) : $signed({1'b0, m0_aLANE}));
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o4ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = ((m0_aLANE[15] & ((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15])) ? (10'd1 << 8) : 10'd0) | ((m0_aLANE[15] & ((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15])) ? (10'd1 << 2) : 10'd0);
      end
      5'd5: begin
        pc_a_m0[(LANE)*16 +: 16] = m0_aLANE; pc_b_m0[(LANE)*16 +: 16] = m0_bLANE; pc_cin_m0[(LANE)*1] = 1'b0;
        m0_o5ex0_LANE = $signed({(m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_sat(m0_o5ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_bitcount #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_bitcount: lane LANE of mode 0 (int16_twos_complement) for the bitcount ops popcount, clz, ctz; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_ctz_aLANE;
  logic [4:0] m0_ctz_nLANE;
  logic signed [34:0] m0_o18ex0_LANE;
  logic signed [34:0] m0_o19ex0_LANE;
  logic signed [34:0] m0_o20ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.bitcount.m0: family trailing_zero realized by the library module fam_count_tzc_reverse_priority_encoder_pdb5fa_w16 (ctz)
  fam_count_tzc_reverse_priority_encoder_pdb5fa_w16 u_m0_ctzLANE (.a(m0_ctz_aLANE), .n(m0_ctz_nLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_ctz_aLANE = 'x; m0_o18ex0_LANE = 'x; m0_o19ex0_LANE = 'x; m0_o20ex0_LANE = 'x;
    case (op)
      5'd18: begin
        y_m0[((LANE*16)+0) +: 16] = m0_aLANE[0] + m0_aLANE[1] + m0_aLANE[2] + m0_aLANE[3] + m0_aLANE[4] + m0_aLANE[5] + m0_aLANE[6] + m0_aLANE[7] + m0_aLANE[8] + m0_aLANE[9] + m0_aLANE[10] + m0_aLANE[11] + m0_aLANE[12] + m0_aLANE[13] + m0_aLANE[14] + m0_aLANE[15];
      end
      5'd19: begin
        y_m0[((LANE*16)+0) +: 16] = m0_aLANE[15] ? 16'd0 : m0_aLANE[14] ? 16'd1 : m0_aLANE[13] ? 16'd2 : m0_aLANE[12] ? 16'd3 : m0_aLANE[11] ? 16'd4 : m0_aLANE[10] ? 16'd5 : m0_aLANE[9] ? 16'd6 : m0_aLANE[8] ? 16'd7 : m0_aLANE[7] ? 16'd8 : m0_aLANE[6] ? 16'd9 : m0_aLANE[5] ? 16'd10 : m0_aLANE[4] ? 16'd11 : m0_aLANE[3] ? 16'd12 : m0_aLANE[2] ? 16'd13 : m0_aLANE[1] ? 16'd14 : m0_aLANE[0] ? 16'd15 : 16'd16;
      end
      5'd20: begin
        m0_ctz_aLANE = m0_aLANE;
        y_m0[((LANE*16)+0) +: 16] = {{11{1'b0}}, m0_ctz_nLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_comparator #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_comparator: lane LANE of mode 0 (int16_twos_complement) for the comparator ops min, max, cmp; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_cmp_aLANE;
  logic [15:0] m0_cmp_bLANE;
  logic m0_cmp_ltLANE;
  logic m0_cmp_eqLANE;
  logic signed [34:0] m0_o8ex0_LANE;
  logic signed [34:0] m0_o9ex0_LANE;
  logic signed [34:0] m0_o10ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.comparator.m0: family prefix_comparator realized by the library module fam_cmp_prefix_comparator
  fam_cmp_prefix_comparator #(.W(16), .SIGNED(1), .STRUCTURE(0), .RADIX(3)) u_m0_cmpLANE (.a(m0_cmp_aLANE), .b(m0_cmp_bLANE), .lt(m0_cmp_ltLANE), .eq(m0_cmp_eqLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_cmp_aLANE = 'x; m0_cmp_bLANE = 'x; m0_o8ex0_LANE = 'x; m0_o9ex0_LANE = 'x; m0_o10ex0_LANE = 'x;
    case (op)
      5'd8: begin
        m0_cmp_aLANE = m0_aLANE; m0_cmp_bLANE = m0_bLANE;
        y_m0[((LANE*16)+0) +: 16] = (m0_cmp_ltLANE | m0_cmp_eqLANE) ? m0_aLANE : m0_bLANE;
      end
      5'd9: begin
        m0_cmp_aLANE = m0_aLANE; m0_cmp_bLANE = m0_bLANE;
        y_m0[((LANE*16)+0) +: 16] = (~m0_cmp_ltLANE) ? m0_aLANE : m0_bLANE;
      end
      5'd10: begin
        m0_cmp_aLANE = m0_aLANE; m0_cmp_bLANE = m0_bLANE;
        y_m0[((LANE*16)+0) +: 16] = {{13{1'b0}}, (~m0_cmp_ltLANE & ~m0_cmp_eqLANE), m0_cmp_eqLANE, m0_cmp_ltLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_multiplier #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_multiplier: lane LANE of mode 0 (int16_twos_complement) for the multiplier ops mul, mul_high; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_mul_aLANE;
  logic [15:0] m0_mul_bLANE;
  logic [31:0] m0_mul_pLANE;
  logic signed [34:0] m0_o6ex0_LANE;
  logic signed [34:0] m0_o7ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.multiplier.m0: family segmented_grid realized by the library module fam_mul_segmented_grid_w16_s_p012a83fa
  fam_mul_segmented_grid_w16_s_p012a83fa u_m0_mulLANE (.a(m0_mul_aLANE), .b(m0_mul_bLANE), .p(m0_mul_pLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_mul_aLANE = 'x; m0_mul_bLANE = 'x; m0_o6ex0_LANE = 'x; m0_o7ex0_LANE = 'x;
    case (op)
      5'd6: begin
        m0_mul_aLANE = m0_aLANE; m0_mul_bLANE = m0_bLANE;
        m0_o6ex0_LANE = $signed({{3{m0_mul_pLANE[31]}}, m0_mul_pLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o6ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (m0_o6ex0_LANE > 35'sd32767 || m0_o6ex0_LANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m0_o6ex0_LANE > 35'sd32767 || m0_o6ex0_LANE < -35'sd32768 ? (10'd1 << 2) : 10'd0);
      end
      5'd7: begin
        m0_mul_aLANE = m0_aLANE; m0_mul_bLANE = m0_bLANE;
        m0_o7ex0_LANE = $signed({{3{m0_mul_pLANE[31]}}, m0_mul_pLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o7ex0_LANE >>> 16);
        fl_m0[(0+LANE)*10 +: 10] = (m0_o7ex0_LANE > 35'sd32767 || m0_o7ex0_LANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m0_o7ex0_LANE > 35'sd32767 || m0_o7ex0_LANE < -35'sd32768 ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_shifter #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_shifter: lane LANE of mode 0 (int16_twos_complement) for the shifter ops shl, shr_arith, rol; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_sh_aLANE;
  logic [3:0] m0_sh_amtLANE;
  logic [2:0] m0_sh_opLANE;
  logic [15:0] m0_sh_yLANE;
  logic signed [34:0] m0_o11ex0_LANE;
  logic signed [34:0] m0_o12ex0_LANE;
  logic signed [34:0] m0_o13ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.shifter.m0: family masked_merged realized by the library module fam_shift_masked_merged
  fam_shift_masked_merged #(.W(16), .MASKGEN(0), .MERGE(0), .R_RADIX_LOG2(1), .R_ONE_HOT(0), .R_ORDER(1), .STICKY(1)) u_m0_shifterLANE (.a(m0_sh_aLANE), .amt(m0_sh_amtLANE), .op(m0_sh_opLANE), .y(m0_sh_yLANE), .sticky());
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_sh_aLANE = 'x; m0_sh_amtLANE = 'x; m0_sh_opLANE = 'x; m0_o11ex0_LANE = 'x; m0_o12ex0_LANE = 'x; m0_o13ex0_LANE = 'x;
    case (op)
      5'd11: begin
        m0_sh_aLANE = m0_aLANE; m0_sh_amtLANE = 4'(m0_bLANE % 16'd16); m0_sh_opLANE = 3'd0;
        y_m0[((LANE*16)+0) +: 16] = m0_sh_yLANE;
      end
      5'd12: begin
        m0_sh_aLANE = m0_aLANE; m0_sh_amtLANE = 4'(m0_bLANE % 16'd16); m0_sh_opLANE = 3'd2;
        y_m0[((LANE*16)+0) +: 16] = m0_sh_yLANE;
      end
      5'd13: begin
        m0_sh_aLANE = m0_aLANE; m0_sh_amtLANE = 4'(m0_bLANE % 16'd16); m0_sh_opLANE = 3'd3;
        y_m0[((LANE*16)+0) +: 16] = m0_sh_yLANE;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_adder_sh #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1,
  output logic [15:0] pc_a_m1,
  output logic [15:0] pc_b_m1,
  output logic [0:0] pc_cin_m1,
  input  logic [15:0] pc_s_m1,
  input  logic [0:0] pc_co_m1
);
  // alu_core_m1_adder_sh: lane LANE of mode 1 (int16_unsigned) for the adder ops add, sub, adc, neg, abs, add_sat; the result buses are the mode's, with only this lane's bits written; the unit's shared adder serve this lane through the pc_/tp_ buses
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_add_sLANE;
  logic m1_add_coutLANE;
  logic signed [34:0] m1_o0ex0_LANE;
  logic signed [34:0] m1_o1ex0_LANE;
  logic signed [34:0] m1_o2ex0_LANE;
  logic signed [34:0] m1_o3ex0_LANE;
  logic signed [34:0] m1_o4ex0_LANE;
  logic signed [34:0] m1_o4sx0_LANE;
  logic signed [34:0] m1_o5ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.adder.m1: the unit's shared partitioned adder (subword partitioned_carry_chain)
  assign m1_add_sLANE = pc_s_m1[(LANE)*16 +: 16];
  assign m1_add_coutLANE = pc_co_m1[(LANE+1)*1-1];
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_o0ex0_LANE = 'x; m1_o1ex0_LANE = 'x; m1_o2ex0_LANE = 'x; m1_o3ex0_LANE = 'x; m1_o4ex0_LANE = 'x; m1_o4sx0_LANE = 'x;
    m1_o5ex0_LANE = 'x;
    pc_a_m1 = '0; pc_b_m1 = '0; pc_cin_m1 = '0;
    case (op)
      5'd0: begin
        pc_a_m1[(LANE)*16 +: 16] = m1_aLANE; pc_b_m1[(LANE)*16 +: 16] = m1_bLANE; pc_cin_m1[(LANE)*1] = 1'b0;
        m1_o0ex0_LANE = $signed({1'b0, m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o0ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (m1_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd1: begin
        pc_a_m1[(LANE)*16 +: 16] = m1_aLANE; pc_b_m1[(LANE)*16 +: 16] = ~m1_bLANE; pc_cin_m1[(LANE)*1] = 1'b1;
        m1_o1ex0_LANE = $signed({~m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o1ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (~m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ ~m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (~m1_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd2: begin
        pc_a_m1[(LANE)*16 +: 16] = m1_aLANE; pc_b_m1[(LANE)*16 +: 16] = m1_bLANE; pc_cin_m1[(LANE)*1] = 1'b1;
        m1_o2ex0_LANE = $signed({1'b0, m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o2ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (m1_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd3: begin
        pc_a_m1[(LANE)*16 +: 16] = 16'd0; pc_b_m1[(LANE)*16 +: 16] = ~m1_aLANE; pc_cin_m1[(LANE)*1] = 1'b1;
        m1_o3ex0_LANE = $signed({~m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o3ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (~m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((1'b0 ^ ~m1_aLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (m1_aLANE != 0 ? (10'd1 << 7) : 10'd0);
      end
      5'd4: begin
        m1_o4ex0_LANE = (m1_vaLANE < 0) ? -m1_vaLANE : m1_vaLANE;
        m1_o4sx0_LANE = (($signed({m1_aLANE[15], m1_aLANE}) < 0) ? -$signed({m1_aLANE[15], m1_aLANE}) : $signed({m1_aLANE[15], m1_aLANE}));
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o4ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_o4sx0_LANE > 35'sd32767 || m1_o4sx0_LANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m1_o4ex0_LANE > 35'sd65535 || m1_o4ex0_LANE < 0 ? (10'd1 << 2) : 10'd0);
      end
      5'd5: begin
        pc_a_m1[(LANE)*16 +: 16] = m1_aLANE; pc_b_m1[(LANE)*16 +: 16] = m1_bLANE; pc_cin_m1[(LANE)*1] = 1'b0;
        m1_o5ex0_LANE = $signed({1'b0, m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_sat(m1_o5ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_bitcount #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_bitcount: lane LANE of mode 1 (int16_unsigned) for the bitcount ops popcount, clz, ctz; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_popcount_aLANE;
  logic [4:0] m1_popcount_nLANE;
  logic signed [34:0] m1_o18ex0_LANE;
  logic signed [34:0] m1_o19ex0_LANE;
  logic signed [34:0] m1_o20ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.bitcount.m1: family popcount_counter_tree realized by the library module fam_count_popcount_balanced_tree_full_adder_3_2_carry_skip_pb5ae0_w16 (popcount)
  fam_count_popcount_balanced_tree_full_adder_3_2_carry_skip_pb5ae0_w16 u_m1_popcountLANE (.a(m1_popcount_aLANE), .n(m1_popcount_nLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_popcount_aLANE = 'x; m1_o18ex0_LANE = 'x; m1_o19ex0_LANE = 'x; m1_o20ex0_LANE = 'x;
    case (op)
      5'd18: begin
        m1_popcount_aLANE = m1_aLANE;
        y_m1[((LANE*16)+0) +: 16] = {{11{1'b0}}, m1_popcount_nLANE};
      end
      5'd19: begin
        y_m1[((LANE*16)+0) +: 16] = m1_aLANE[15] ? 16'd0 : m1_aLANE[14] ? 16'd1 : m1_aLANE[13] ? 16'd2 : m1_aLANE[12] ? 16'd3 : m1_aLANE[11] ? 16'd4 : m1_aLANE[10] ? 16'd5 : m1_aLANE[9] ? 16'd6 : m1_aLANE[8] ? 16'd7 : m1_aLANE[7] ? 16'd8 : m1_aLANE[6] ? 16'd9 : m1_aLANE[5] ? 16'd10 : m1_aLANE[4] ? 16'd11 : m1_aLANE[3] ? 16'd12 : m1_aLANE[2] ? 16'd13 : m1_aLANE[1] ? 16'd14 : m1_aLANE[0] ? 16'd15 : 16'd16;
      end
      5'd20: begin
        y_m1[((LANE*16)+0) +: 16] = m1_aLANE[0] ? 16'd0 : m1_aLANE[1] ? 16'd1 : m1_aLANE[2] ? 16'd2 : m1_aLANE[3] ? 16'd3 : m1_aLANE[4] ? 16'd4 : m1_aLANE[5] ? 16'd5 : m1_aLANE[6] ? 16'd6 : m1_aLANE[7] ? 16'd7 : m1_aLANE[8] ? 16'd8 : m1_aLANE[9] ? 16'd9 : m1_aLANE[10] ? 16'd10 : m1_aLANE[11] ? 16'd11 : m1_aLANE[12] ? 16'd12 : m1_aLANE[13] ? 16'd13 : m1_aLANE[14] ? 16'd14 : m1_aLANE[15] ? 16'd15 : 16'd16;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_comparator #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_comparator: lane LANE of mode 1 (int16_unsigned) for the comparator ops min, max, cmp; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_cmp_aLANE;
  logic [15:0] m1_cmp_bLANE;
  logic m1_cmp_ltLANE;
  logic m1_cmp_eqLANE;
  logic signed [34:0] m1_o8ex0_LANE;
  logic signed [34:0] m1_o9ex0_LANE;
  logic signed [34:0] m1_o10ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.comparator.m1: family subtractor_comparator realized by the library module fam_cmp_subtractor_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_sum_or_tree_u_w16
  fam_cmp_subtractor_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_sum_or_tree_u_w16 u_m1_cmpLANE (.a(m1_cmp_aLANE), .b(m1_cmp_bLANE), .lt(m1_cmp_ltLANE), .eq(m1_cmp_eqLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_cmp_aLANE = 'x; m1_cmp_bLANE = 'x; m1_o8ex0_LANE = 'x; m1_o9ex0_LANE = 'x; m1_o10ex0_LANE = 'x;
    case (op)
      5'd8: begin
        m1_cmp_aLANE = m1_aLANE; m1_cmp_bLANE = m1_bLANE;
        y_m1[((LANE*16)+0) +: 16] = (m1_cmp_ltLANE | m1_cmp_eqLANE) ? m1_aLANE : m1_bLANE;
      end
      5'd9: begin
        m1_cmp_aLANE = m1_aLANE; m1_cmp_bLANE = m1_bLANE;
        y_m1[((LANE*16)+0) +: 16] = (~m1_cmp_ltLANE) ? m1_aLANE : m1_bLANE;
      end
      5'd10: begin
        m1_cmp_aLANE = m1_aLANE; m1_cmp_bLANE = m1_bLANE;
        y_m1[((LANE*16)+0) +: 16] = {{13{1'b0}}, (~m1_cmp_ltLANE & ~m1_cmp_eqLANE), m1_cmp_eqLANE, m1_cmp_ltLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_logic #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_logic: lane LANE of mode 1 (int16_unsigned) for the logic ops and, or, xor, not; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_lg_aLANE;
  logic [15:0] m1_lg_bLANE;
  logic [1:0] m1_lg_opLANE;
  logic [15:0] m1_lg_yLANE;
  logic signed [34:0] m1_o14ex0_LANE;
  logic signed [34:0] m1_o15ex0_LANE;
  logic signed [34:0] m1_o16ex0_LANE;
  logic signed [34:0] m1_o17ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.logic.m1: family lane_replicated_gates realized by the library module fam_logic_gate_row
  fam_logic_gate_row #(.W(16), .NOT_VIA_XOR(0)) u_m1_logicLANE (.a(m1_lg_aLANE), .b(m1_lg_bLANE), .op(m1_lg_opLANE), .y(m1_lg_yLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_lg_aLANE = 'x; m1_lg_bLANE = 'x; m1_lg_opLANE = 'x; m1_o14ex0_LANE = 'x; m1_o15ex0_LANE = 'x; m1_o16ex0_LANE = 'x;
    m1_o17ex0_LANE = 'x;
    case (op)
      5'd14: begin
        m1_lg_aLANE = m1_aLANE; m1_lg_bLANE = m1_bLANE; m1_lg_opLANE = 2'd0;
        y_m1[((LANE*16)+0) +: 16] = m1_lg_yLANE;
      end
      5'd15: begin
        m1_lg_aLANE = m1_aLANE; m1_lg_bLANE = m1_bLANE; m1_lg_opLANE = 2'd1;
        y_m1[((LANE*16)+0) +: 16] = m1_lg_yLANE;
      end
      5'd16: begin
        m1_lg_aLANE = m1_aLANE; m1_lg_bLANE = m1_bLANE; m1_lg_opLANE = 2'd2;
        y_m1[((LANE*16)+0) +: 16] = m1_lg_yLANE;
      end
      5'd17: begin
        m1_lg_aLANE = m1_aLANE; m1_lg_bLANE = m1_bLANE; m1_lg_opLANE = 2'd3;
        y_m1[((LANE*16)+0) +: 16] = m1_lg_yLANE;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_multiplier #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_multiplier: lane LANE of mode 1 (int16_unsigned) for the multiplier ops mul, mul_high; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_mul_aLANE;
  logic [15:0] m1_mul_bLANE;
  logic [31:0] m1_mul_pLANE;
  logic signed [34:0] m1_o6ex0_LANE;
  logic signed [34:0] m1_o6sx0_ANE;
  logic signed [34:0] m1_o7ex0_LANE;
  logic signed [34:0] m1_o7sx0_ANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.multiplier.m1: family redundant_binary_multiplier realized by the library module fam_mul_redundant_binary_multiplier_w16_u_pe58f448b
  fam_mul_redundant_binary_multiplier_w16_u_pe58f448b u_m1_mulLANE (.a(m1_mul_aLANE), .b(m1_mul_bLANE), .p(m1_mul_pLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_mul_aLANE = 'x; m1_mul_bLANE = 'x; m1_o6ex0_LANE = 'x; m1_o6sx0_ANE = 'x; m1_o7ex0_LANE = 'x; m1_o7sx0_ANE = 'x;
    case (op)
      5'd6: begin
        m1_mul_aLANE = m1_aLANE; m1_mul_bLANE = m1_bLANE;
        m1_o6ex0_LANE = $signed({{3{1'b0}}, m1_mul_pLANE});
        m1_o6sx0_ANE = m1_o6ex0_LANE - (m1_aLANE[15] ? ($signed(m1_vbLANE) <<< 16) : 35'sd0) - (m1_bLANE[15] ? ($signed(m1_vaLANE) <<< 16) : 35'sd0) + ((m1_aLANE[15] & m1_bLANE[15]) ? 35'sd4294967296 : 35'sd0);
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o6ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_o6sx0_ANE > 35'sd32767 || m1_o6sx0_ANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m1_o6ex0_LANE > 35'sd65535 || m1_o6ex0_LANE < 0 ? (10'd1 << 2) : 10'd0);
      end
      5'd7: begin
        m1_mul_aLANE = m1_aLANE; m1_mul_bLANE = m1_bLANE;
        m1_o7ex0_LANE = $signed({{3{1'b0}}, m1_mul_pLANE});
        m1_o7sx0_ANE = m1_o7ex0_LANE - (m1_aLANE[15] ? ($signed(m1_vbLANE) <<< 16) : 35'sd0) - (m1_bLANE[15] ? ($signed(m1_vaLANE) <<< 16) : 35'sd0) + ((m1_aLANE[15] & m1_bLANE[15]) ? 35'sd4294967296 : 35'sd0);
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o7ex0_LANE >>> 16);
        fl_m1[(0+LANE)*10 +: 10] = (m1_o7sx0_ANE > 35'sd32767 || m1_o7sx0_ANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m1_o7ex0_LANE > 35'sd65535 || m1_o7ex0_LANE < 0 ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_shifter #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_shifter: lane LANE of mode 1 (int16_unsigned) for the shifter ops shl, shr_arith, rol; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_sh_aLANE;
  logic [3:0] m1_sh_amtLANE;
  logic [2:0] m1_sh_opLANE;
  logic [15:0] m1_sh_yLANE;
  logic signed [34:0] m1_o11ex0_LANE;
  logic signed [34:0] m1_o12ex0_LANE;
  logic signed [34:0] m1_o13ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.shifter.m1: family funnel realized by the library module fam_shift_funnel
  fam_shift_funnel #(.W(16), .RADIX_LOG2(2), .AMT_PRE(0), .STICKY(0)) u_m1_shifterLANE (.a(m1_sh_aLANE), .amt(m1_sh_amtLANE), .op(m1_sh_opLANE), .y(m1_sh_yLANE), .sticky());
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_sh_aLANE = 'x; m1_sh_amtLANE = 'x; m1_sh_opLANE = 'x; m1_o11ex0_LANE = 'x; m1_o12ex0_LANE = 'x; m1_o13ex0_LANE = 'x;
    case (op)
      5'd11: begin
        m1_sh_aLANE = m1_aLANE; m1_sh_amtLANE = 4'(m1_bLANE % 16'd16); m1_sh_opLANE = 3'd0;
        y_m1[((LANE*16)+0) +: 16] = m1_sh_yLANE;
      end
      5'd12: begin
        m1_sh_aLANE = m1_aLANE; m1_sh_amtLANE = 4'(m1_bLANE % 16'd16); m1_sh_opLANE = 3'd2;
        y_m1[((LANE*16)+0) +: 16] = m1_sh_yLANE;
      end
      5'd13: begin
        m1_sh_aLANE = m1_aLANE; m1_sh_amtLANE = 4'(m1_bLANE % 16'd16); m1_sh_opLANE = 3'd3;
        y_m1[((LANE*16)+0) +: 16] = m1_sh_yLANE;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_adder_sh #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2,
  output logic [15:0] pc_a_m2,
  output logic [15:0] pc_b_m2,
  output logic [1:0] pc_cin_m2,
  input  logic [15:0] pc_s_m2,
  input  logic [1:0] pc_co_m2
);
  // alu_core_m2_adder_sh: lane LANE of mode 2 (int8_twos_complement) for the adder ops add, sub, adc, neg, abs, add_sat; the result buses are the mode's, with only this lane's bits written; the unit's shared adder serve this lane through the pc_/tp_ buses
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_add_sLANE;
  logic m2_add_coutLANE;
  logic signed [18:0] m2_o0ex0_LANE;
  logic signed [18:0] m2_o1ex0_LANE;
  logic signed [18:0] m2_o2ex0_LANE;
  logic signed [18:0] m2_o3ex0_LANE;
  logic signed [18:0] m2_o4ex0_LANE;
  logic signed [18:0] m2_o5ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.adder.m2: the unit's shared partitioned adder (subword partitioned_carry_chain)
  assign m2_add_sLANE = pc_s_m2[(LANE)*8 +: 8];
  assign m2_add_coutLANE = pc_co_m2[(LANE+1)*1-1];
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_o0ex0_LANE = 'x; m2_o1ex0_LANE = 'x; m2_o2ex0_LANE = 'x; m2_o3ex0_LANE = 'x; m2_o4ex0_LANE = 'x; m2_o5ex0_LANE = 'x;
    pc_a_m2 = '0; pc_b_m2 = '0; pc_cin_m2 = '0;
    case (op)
      5'd0: begin
        pc_a_m2[(LANE)*8 +: 8] = m2_aLANE; pc_b_m2[(LANE)*8 +: 8] = m2_bLANE; pc_cin_m2[(LANE)*1] = 1'b0;
        m2_o0ex0_LANE = $signed({(m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o0ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (m2_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd1: begin
        pc_a_m2[(LANE)*8 +: 8] = m2_aLANE; pc_b_m2[(LANE)*8 +: 8] = ~m2_bLANE; pc_cin_m2[(LANE)*1] = 1'b1;
        m2_o1ex0_LANE = $signed({(m2_aLANE[7] ^ ~m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o1ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ ~m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ ~m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (~m2_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd2: begin
        pc_a_m2[(LANE)*8 +: 8] = m2_aLANE; pc_b_m2[(LANE)*8 +: 8] = m2_bLANE; pc_cin_m2[(LANE)*1] = 1'b1;
        m2_o2ex0_LANE = $signed({(m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o2ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (m2_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd3: begin
        pc_a_m2[(LANE)*8 +: 8] = 8'd0; pc_b_m2[(LANE)*8 +: 8] = ~m2_aLANE; pc_cin_m2[(LANE)*1] = 1'b1;
        m2_o3ex0_LANE = $signed({(1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o3ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (m2_aLANE != 0 ? (10'd1 << 7) : 10'd0);
      end
      5'd4: begin
        pc_a_m2[(LANE)*8 +: 8] = 8'd0; pc_b_m2[(LANE)*8 +: 8] = ~m2_aLANE; pc_cin_m2[(LANE)*1] = 1'b1;
        m2_o4ex0_LANE = (m2_aLANE[7] ? $signed({(1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE), m2_add_sLANE}) : $signed({1'b0, m2_aLANE}));
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o4ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = ((m2_aLANE[7] & ((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7])) ? (10'd1 << 8) : 10'd0) | ((m2_aLANE[7] & ((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7])) ? (10'd1 << 2) : 10'd0);
      end
      5'd5: begin
        pc_a_m2[(LANE)*8 +: 8] = m2_aLANE; pc_b_m2[(LANE)*8 +: 8] = m2_bLANE; pc_cin_m2[(LANE)*1] = 1'b0;
        m2_o5ex0_LANE = $signed({(m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_sat(m2_o5ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_bitcount #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_bitcount: lane LANE of mode 2 (int8_twos_complement) for the bitcount ops popcount, clz, ctz; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_ctz_aLANE;
  logic [3:0] m2_ctz_nLANE;
  logic signed [18:0] m2_o18ex0_LANE;
  logic signed [18:0] m2_o19ex0_LANE;
  logic signed [18:0] m2_o20ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.bitcount.m2: family trailing_zero realized by the library module fam_count_tzc_reverse_prefix_lzc_pb8d18_w8 (ctz)
  fam_count_tzc_reverse_prefix_lzc_pb8d18_w8 u_m2_ctzLANE (.a(m2_ctz_aLANE), .n(m2_ctz_nLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_ctz_aLANE = 'x; m2_o18ex0_LANE = 'x; m2_o19ex0_LANE = 'x; m2_o20ex0_LANE = 'x;
    case (op)
      5'd18: begin
        y_m2[((LANE*8)+0) +: 8] = m2_aLANE[0] + m2_aLANE[1] + m2_aLANE[2] + m2_aLANE[3] + m2_aLANE[4] + m2_aLANE[5] + m2_aLANE[6] + m2_aLANE[7];
      end
      5'd19: begin
        y_m2[((LANE*8)+0) +: 8] = m2_aLANE[7] ? 8'd0 : m2_aLANE[6] ? 8'd1 : m2_aLANE[5] ? 8'd2 : m2_aLANE[4] ? 8'd3 : m2_aLANE[3] ? 8'd4 : m2_aLANE[2] ? 8'd5 : m2_aLANE[1] ? 8'd6 : m2_aLANE[0] ? 8'd7 : 8'd8;
      end
      5'd20: begin
        m2_ctz_aLANE = m2_aLANE;
        y_m2[((LANE*8)+0) +: 8] = {{4{1'b0}}, m2_ctz_nLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_comparator #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_comparator: lane LANE of mode 2 (int8_twos_complement) for the comparator ops min, max, cmp; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_cmp_aLANE;
  logic [7:0] m2_cmp_bLANE;
  logic m2_cmp_ltLANE;
  logic m2_cmp_eqLANE;
  logic signed [18:0] m2_o8ex0_LANE;
  logic signed [18:0] m2_o9ex0_LANE;
  logic signed [18:0] m2_o10ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.comparator.m2: family subtractor_comparator realized by the library module fam_cmp_subtractor_prefix_synthesis_nonuniform_arrival_pc87885195967a6123ef6af9e4b2732165d2e32528a8c668a3c2a6850933d85a8_operand_xnor_s_w8
  fam_cmp_subtractor_prefix_synthesis_nonuniform_arrival_pc87885195967a6123ef6af9e4b2732165d2e32528a8c668a3c2a6850933d85a8_operand_xnor_s_w8 u_m2_cmpLANE (.a(m2_cmp_aLANE), .b(m2_cmp_bLANE), .lt(m2_cmp_ltLANE), .eq(m2_cmp_eqLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_cmp_aLANE = 'x; m2_cmp_bLANE = 'x; m2_o8ex0_LANE = 'x; m2_o9ex0_LANE = 'x; m2_o10ex0_LANE = 'x;
    case (op)
      5'd8: begin
        m2_cmp_aLANE = m2_aLANE; m2_cmp_bLANE = m2_bLANE;
        y_m2[((LANE*8)+0) +: 8] = (m2_cmp_ltLANE | m2_cmp_eqLANE) ? m2_aLANE : m2_bLANE;
      end
      5'd9: begin
        m2_cmp_aLANE = m2_aLANE; m2_cmp_bLANE = m2_bLANE;
        y_m2[((LANE*8)+0) +: 8] = (~m2_cmp_ltLANE) ? m2_aLANE : m2_bLANE;
      end
      5'd10: begin
        m2_cmp_aLANE = m2_aLANE; m2_cmp_bLANE = m2_bLANE;
        y_m2[((LANE*8)+0) +: 8] = {{5{1'b0}}, (~m2_cmp_ltLANE & ~m2_cmp_eqLANE), m2_cmp_eqLANE, m2_cmp_ltLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_logic #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_logic: lane LANE of mode 2 (int8_twos_complement) for the logic ops and, or, xor, not; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_lg_aLANE;
  logic [7:0] m2_lg_bLANE;
  logic [1:0] m2_lg_opLANE;
  logic [7:0] m2_lg_yLANE;
  logic signed [18:0] m2_o14ex0_LANE;
  logic signed [18:0] m2_o15ex0_LANE;
  logic signed [18:0] m2_o16ex0_LANE;
  logic signed [18:0] m2_o17ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.logic.m2: family lane_replicated_gates realized by the library module fam_logic_gate_row
  fam_logic_gate_row #(.W(8), .NOT_VIA_XOR(0)) u_m2_logicLANE (.a(m2_lg_aLANE), .b(m2_lg_bLANE), .op(m2_lg_opLANE), .y(m2_lg_yLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_lg_aLANE = 'x; m2_lg_bLANE = 'x; m2_lg_opLANE = 'x; m2_o14ex0_LANE = 'x; m2_o15ex0_LANE = 'x; m2_o16ex0_LANE = 'x;
    m2_o17ex0_LANE = 'x;
    case (op)
      5'd14: begin
        m2_lg_aLANE = m2_aLANE; m2_lg_bLANE = m2_bLANE; m2_lg_opLANE = 2'd0;
        y_m2[((LANE*8)+0) +: 8] = m2_lg_yLANE;
      end
      5'd15: begin
        m2_lg_aLANE = m2_aLANE; m2_lg_bLANE = m2_bLANE; m2_lg_opLANE = 2'd1;
        y_m2[((LANE*8)+0) +: 8] = m2_lg_yLANE;
      end
      5'd16: begin
        m2_lg_aLANE = m2_aLANE; m2_lg_bLANE = m2_bLANE; m2_lg_opLANE = 2'd2;
        y_m2[((LANE*8)+0) +: 8] = m2_lg_yLANE;
      end
      5'd17: begin
        m2_lg_aLANE = m2_aLANE; m2_lg_bLANE = m2_bLANE; m2_lg_opLANE = 2'd3;
        y_m2[((LANE*8)+0) +: 8] = m2_lg_yLANE;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_multiplier #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_multiplier: lane LANE of mode 2 (int8_twos_complement) for the multiplier ops mul, mul_high; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_mul_aLANE;
  logic [7:0] m2_mul_bLANE;
  logic [15:0] m2_mul_pLANE;
  logic signed [18:0] m2_o6ex0_LANE;
  logic signed [18:0] m2_o7ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.multiplier.m2: family segmented_grid realized by the library module fam_mul_segmented_grid_w8_s_pda2147ed
  fam_mul_segmented_grid_w8_s_pda2147ed u_m2_mulLANE (.a(m2_mul_aLANE), .b(m2_mul_bLANE), .p(m2_mul_pLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_mul_aLANE = 'x; m2_mul_bLANE = 'x; m2_o6ex0_LANE = 'x; m2_o7ex0_LANE = 'x;
    case (op)
      5'd6: begin
        m2_mul_aLANE = m2_aLANE; m2_mul_bLANE = m2_bLANE;
        m2_o6ex0_LANE = $signed({{3{m2_mul_pLANE[15]}}, m2_mul_pLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o6ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (m2_o6ex0_LANE > 19'sd127 || m2_o6ex0_LANE < -19'sd128 ? (10'd1 << 8) : 10'd0) | (m2_o6ex0_LANE > 19'sd127 || m2_o6ex0_LANE < -19'sd128 ? (10'd1 << 2) : 10'd0);
      end
      5'd7: begin
        m2_mul_aLANE = m2_aLANE; m2_mul_bLANE = m2_bLANE;
        m2_o7ex0_LANE = $signed({{3{m2_mul_pLANE[15]}}, m2_mul_pLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o7ex0_LANE >>> 8);
        fl_m2[(0+LANE)*10 +: 10] = (m2_o7ex0_LANE > 19'sd127 || m2_o7ex0_LANE < -19'sd128 ? (10'd1 << 8) : 10'd0) | (m2_o7ex0_LANE > 19'sd127 || m2_o7ex0_LANE < -19'sd128 ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_shifter #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_shifter: lane LANE of mode 2 (int8_twos_complement) for the shifter ops shl, shr_arith, rol; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_sh_aLANE;
  logic [2:0] m2_sh_amtLANE;
  logic [2:0] m2_sh_opLANE;
  logic [7:0] m2_sh_yLANE;
  logic signed [18:0] m2_o11ex0_LANE;
  logic signed [18:0] m2_o12ex0_LANE;
  logic signed [18:0] m2_o13ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.shifter.m2: family masked_merged realized by the library module fam_shift_masked_merged
  fam_shift_masked_merged #(.W(8), .MASKGEN(0), .MERGE(1), .R_RADIX_LOG2(2), .R_ONE_HOT(1), .R_ORDER(1), .STICKY(1)) u_m2_shifterLANE (.a(m2_sh_aLANE), .amt(m2_sh_amtLANE), .op(m2_sh_opLANE), .y(m2_sh_yLANE), .sticky());
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_sh_aLANE = 'x; m2_sh_amtLANE = 'x; m2_sh_opLANE = 'x; m2_o11ex0_LANE = 'x; m2_o12ex0_LANE = 'x; m2_o13ex0_LANE = 'x;
    case (op)
      5'd11: begin
        m2_sh_aLANE = m2_aLANE; m2_sh_amtLANE = 3'(m2_bLANE % 8'd8); m2_sh_opLANE = 3'd0;
        y_m2[((LANE*8)+0) +: 8] = m2_sh_yLANE;
      end
      5'd12: begin
        m2_sh_aLANE = m2_aLANE; m2_sh_amtLANE = 3'(m2_bLANE % 8'd8); m2_sh_opLANE = 3'd2;
        y_m2[((LANE*8)+0) +: 8] = m2_sh_yLANE;
      end
      5'd13: begin
        m2_sh_aLANE = m2_aLANE; m2_sh_amtLANE = 3'(m2_bLANE % 8'd8); m2_sh_opLANE = 3'd3;
        y_m2[((LANE*8)+0) +: 8] = m2_sh_yLANE;
      end
      default: ;
    endcase
  end
endmodule
// ADIR-MEMBER m0_l0_adder
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_adder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_adder: physical structure `m0.l0.adder` (kind adder, slot adder); realizes m0.l0.adder: adder, mode 0 lane 0, int16_twos_complement, ops add, sub, adc, neg, abs, add_sat
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] pc_a_m0;
  logic [15:0] pc_b_m0;
  logic pc_cin_m0;
  logic [15:0] pc_s_m0;
  logic pc_co_m0;
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  logic [15:0] pc_a_m0_l0;
  logic [15:0] pc_b_m0_l0;
  logic pc_cin_m0_l0;
  logic pc_sel;
  logic [15:0] pc_a;
  logic [15:0] pc_b;
  logic pc_cin;
  logic [15:0] pc_s;
  logic pc_co;
  alu_core_m0_adder_sh #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0), .pc_a_m0(pc_a_m0_l0), .pc_b_m0(pc_b_m0_l0), .pc_cin_m0(pc_cin_m0_l0), .pc_s_m0(pc_s_m0), .pc_co_m0(pc_co_m0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
  assign pc_a_m0 = pc_a_m0_l0;
  assign pc_b_m0 = pc_b_m0_l0;
  assign pc_cin_m0 = pc_cin_m0_l0;
  assign pc_sel = (mode == 2'd0) ? 1'd0 : '0;
  assign pc_a = (mode == 2'd0) ? pc_a_m0 : '0;
  assign pc_b = (mode == 2'd0) ? pc_b_m0 : '0;
  assign pc_cin = (mode == 2'd0) ? pc_cin_m0 : '0;
  // subword partitioned_carry_chain: one library adder over the whole word, its carries cut at the selected packing's lane boundaries (1 x int16_twos_complement)
  fam_add_partitioned_w16_16_carry_kill_gate_97f154d649b3 u_part (.a(pc_a), .b(pc_b), .cin(pc_cin), .sel(pc_sel), .s(pc_s), .cout(pc_co));
  assign pc_s_m0 = pc_s;
  assign pc_co_m0 = pc_co;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_multiplier: physical structure `m0.l0.multiplier` (kind multiplier, slot multiplier); realizes m0.l0.multiplier: multiplier, mode 0 lane 0, int16_twos_complement, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_multiplier #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_comparator: physical structure `m0.l0.comparator` (kind comparator, slot comparator); realizes m0.l0.comparator: comparator, mode 0 lane 0, int16_twos_complement, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_comparator #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_shifter: physical structure `m0.l0.shifter` (kind shifter, slot shifter); realizes m0.l0.shifter: shifter, mode 0 lane 0, int16_twos_complement, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_shifter #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_logic
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_logic (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_logic: physical structure `m0.l0.logic` (kind logic, slot logic); realizes m0.l0.logic: logic, mode 0 lane 0, int16_twos_complement, ops and, or, xor, not
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [1:0] lg_op;
  logic lg_en;
  logic [15:0] lg_y;
  assign lg_op = (op == 5'd14) ? 2'd0 : (op == 5'd15) ? 2'd1 : (op == 5'd16) ? 2'd2 : (op == 5'd17) ? 2'd3 : 2'd0;
  assign lg_en = (op == 5'd14) | (op == 5'd15) | (op == 5'd16) | (op == 5'd17);
  // structure core.logic: family wide_gate_row realized by one library gate row over the whole word (the packings 1 x int16_twos_complement)
  fam_logic_gate_row #(.W(16), .NOT_VIA_XOR(1)) u_wide_row (.a(a), .b(b), .op(lg_op), .y(lg_y));
  assign y_m0 = lg_en ? lg_y[15:0] : '0;
  assign fl_m0 = '0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_bitcount: physical structure `m0.l0.bitcount` (kind bitcount, slot bitcount); realizes m0.l0.bitcount: bitcount, mode 0 lane 0, int16_twos_complement, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_bitcount #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_adder
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_adder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_adder: physical structure `m1.l0.adder` (kind adder, slot adder); realizes m1.l0.adder: adder, mode 1 lane 0, int16_unsigned, ops add, sub, adc, neg, abs, add_sat
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] pc_a_m1;
  logic [15:0] pc_b_m1;
  logic pc_cin_m1;
  logic [15:0] pc_s_m1;
  logic pc_co_m1;
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  logic [15:0] pc_a_m1_l0;
  logic [15:0] pc_b_m1_l0;
  logic pc_cin_m1_l0;
  logic pc_sel;
  logic [15:0] pc_a;
  logic [15:0] pc_b;
  logic pc_cin;
  logic [15:0] pc_s;
  logic pc_co;
  alu_core_m1_adder_sh #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0), .pc_a_m1(pc_a_m1_l0), .pc_b_m1(pc_b_m1_l0), .pc_cin_m1(pc_cin_m1_l0), .pc_s_m1(pc_s_m1), .pc_co_m1(pc_co_m1));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
  assign pc_a_m1 = pc_a_m1_l0;
  assign pc_b_m1 = pc_b_m1_l0;
  assign pc_cin_m1 = pc_cin_m1_l0;
  assign pc_sel = (mode == 2'd1) ? 1'd0 : '0;
  assign pc_a = (mode == 2'd1) ? pc_a_m1 : '0;
  assign pc_b = (mode == 2'd1) ? pc_b_m1 : '0;
  assign pc_cin = (mode == 2'd1) ? pc_cin_m1 : '0;
  // subword partitioned_carry_chain: one library adder over the whole word, its carries cut at the selected packing's lane boundaries (1 x int16_unsigned)
  fam_add_partitioned_w16_16_carry_kill_gate_97f154d649b3 u_part (.a(pc_a), .b(pc_b), .cin(pc_cin), .sel(pc_sel), .s(pc_s), .cout(pc_co));
  assign pc_s_m1 = pc_s;
  assign pc_co_m1 = pc_co;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_multiplier: physical structure `m1.l0.multiplier` (kind multiplier, slot multiplier); realizes m1.l0.multiplier: multiplier, mode 1 lane 0, int16_unsigned, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_multiplier #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_comparator: physical structure `m1.l0.comparator` (kind comparator, slot comparator); realizes m1.l0.comparator: comparator, mode 1 lane 0, int16_unsigned, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_comparator #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_shifter: physical structure `m1.l0.shifter` (kind shifter, slot shifter); realizes m1.l0.shifter: shifter, mode 1 lane 0, int16_unsigned, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_shifter #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_logic
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_logic (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_logic: physical structure `m1.l0.logic` (kind logic, slot logic); realizes m1.l0.logic: logic, mode 1 lane 0, int16_unsigned, ops and, or, xor, not
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_logic #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_bitcount: physical structure `m1.l0.bitcount` (kind bitcount, slot bitcount); realizes m1.l0.bitcount: bitcount, mode 1 lane 0, int16_unsigned, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_bitcount #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_adder
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_adder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_adder: physical structure `m2.l0.adder` (kind adder, slot adder); realizes m2.l0.adder: adder, mode 2 lane 0, int8_twos_complement, ops add, sub, adc, neg, abs, add_sat
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] pc_a_m2;
  logic [15:0] pc_b_m2;
  logic [1:0] pc_cin_m2;
  logic [15:0] pc_s_m2;
  logic [1:0] pc_co_m2;
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  logic [15:0] pc_a_m2_l0;
  logic [15:0] pc_b_m2_l0;
  logic [1:0] pc_cin_m2_l0;
  logic pc_sel;
  logic [15:0] pc_a;
  logic [15:0] pc_b;
  logic [1:0] pc_cin;
  logic [15:0] pc_s;
  logic [1:0] pc_co;
  alu_core_m2_adder_sh #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0), .pc_a_m2(pc_a_m2_l0), .pc_b_m2(pc_b_m2_l0), .pc_cin_m2(pc_cin_m2_l0), .pc_s_m2(pc_s_m2), .pc_co_m2(pc_co_m2));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
  assign pc_a_m2 = pc_a_m2_l0;
  assign pc_b_m2 = pc_b_m2_l0;
  assign pc_cin_m2 = pc_cin_m2_l0;
  assign pc_sel = (mode == 2'd2) ? 1'd0 : '0;
  assign pc_a = (mode == 2'd2) ? pc_a_m2 : '0;
  assign pc_b = (mode == 2'd2) ? pc_b_m2 : '0;
  assign pc_cin = (mode == 2'd2) ? pc_cin_m2 : '0;
  // subword partitioned_carry_chain: one library adder over the whole word, its carries cut at the selected packing's lane boundaries (2 x int8_twos_complement)
  fam_add_partitioned_w16_8_carry_kill_gate_97f154d649b3 u_part (.a(pc_a), .b(pc_b), .cin(pc_cin), .sel(pc_sel), .s(pc_s), .cout(pc_co));
  assign pc_s_m2 = pc_s;
  assign pc_co_m2 = pc_co;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_adder
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_adder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_adder: physical structure `m2.l1.adder` (kind adder, slot adder); realizes m2.l1.adder: adder, mode 2 lane 1, int8_twos_complement, ops add, sub, adc, neg, abs, add_sat
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] pc_a_m2;
  logic [15:0] pc_b_m2;
  logic [1:0] pc_cin_m2;
  logic [15:0] pc_s_m2;
  logic [1:0] pc_co_m2;
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  logic [15:0] pc_a_m2_l1;
  logic [15:0] pc_b_m2_l1;
  logic [1:0] pc_cin_m2_l1;
  logic pc_sel;
  logic [15:0] pc_a;
  logic [15:0] pc_b;
  logic [1:0] pc_cin;
  logic [15:0] pc_s;
  logic [1:0] pc_co;
  alu_core_m2_adder_sh #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1), .pc_a_m2(pc_a_m2_l1), .pc_b_m2(pc_b_m2_l1), .pc_cin_m2(pc_cin_m2_l1), .pc_s_m2(pc_s_m2), .pc_co_m2(pc_co_m2));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
  assign pc_a_m2 = pc_a_m2_l1;
  assign pc_b_m2 = pc_b_m2_l1;
  assign pc_cin_m2 = pc_cin_m2_l1;
  assign pc_sel = (mode == 2'd2) ? 1'd0 : '0;
  assign pc_a = (mode == 2'd2) ? pc_a_m2 : '0;
  assign pc_b = (mode == 2'd2) ? pc_b_m2 : '0;
  assign pc_cin = (mode == 2'd2) ? pc_cin_m2 : '0;
  // subword partitioned_carry_chain: one library adder over the whole word, its carries cut at the selected packing's lane boundaries (2 x int8_twos_complement)
  fam_add_partitioned_w16_8_carry_kill_gate_97f154d649b3 u_part (.a(pc_a), .b(pc_b), .cin(pc_cin), .sel(pc_sel), .s(pc_s), .cout(pc_co));
  assign pc_s_m2 = pc_s;
  assign pc_co_m2 = pc_co;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_multiplier: physical structure `m2.l0.multiplier` (kind multiplier, slot multiplier); realizes m2.l0.multiplier: multiplier, mode 2 lane 0, int8_twos_complement, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_multiplier #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_multiplier: physical structure `m2.l1.multiplier` (kind multiplier, slot multiplier); realizes m2.l1.multiplier: multiplier, mode 2 lane 1, int8_twos_complement, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_multiplier #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_comparator: physical structure `m2.l0.comparator` (kind comparator, slot comparator); realizes m2.l0.comparator: comparator, mode 2 lane 0, int8_twos_complement, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_comparator #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_comparator: physical structure `m2.l1.comparator` (kind comparator, slot comparator); realizes m2.l1.comparator: comparator, mode 2 lane 1, int8_twos_complement, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_comparator #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_shifter: physical structure `m2.l0.shifter` (kind shifter, slot shifter); realizes m2.l0.shifter: shifter, mode 2 lane 0, int8_twos_complement, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_shifter #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_shifter: physical structure `m2.l1.shifter` (kind shifter, slot shifter); realizes m2.l1.shifter: shifter, mode 2 lane 1, int8_twos_complement, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_shifter #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_logic
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_logic (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_logic: physical structure `m2.l0.logic` (kind logic, slot logic); realizes m2.l0.logic: logic, mode 2 lane 0, int8_twos_complement, ops and, or, xor, not
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_logic #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_logic
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_logic (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_logic: physical structure `m2.l1.logic` (kind logic, slot logic); realizes m2.l1.logic: logic, mode 2 lane 1, int8_twos_complement, ops and, or, xor, not
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_logic #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_bitcount: physical structure `m2.l0.bitcount` (kind bitcount, slot bitcount); realizes m2.l0.bitcount: bitcount, mode 2 lane 0, int8_twos_complement, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_bitcount #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_bitcount: physical structure `m2.l1.bitcount` (kind bitcount, slot bitcount); realizes m2.l1.bitcount: bitcount, mode 2 lane 1, int8_twos_complement, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_bitcount #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER library
// ---- the family library modules the lane modules instantiate (chialu/targets/rtl/families; fixed text, replaced by editing the instances)
// partitioned_carry_chain (carry_kill_gate, carry_increment segments of 16 bits): one adder for the lane packings 1 x 16, the carry cut at the selected mode's lane boundaries
module fam_add_partitioned_w16_16_carry_kill_gate_97f154d649b3 (input logic [15:0] a, input logic [15:0] b, input logic [0:0] cin, input logic [0:0] sel, output logic [15:0] s, output logic [0:0] cout);
  logic [1:0] c;
  assign c[0] = cin[0];
  logic co0;
  fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w16 u0 (.a(a[15:0]), .b(b[15:0]), .cin(c[0]), .s(s[15:0]), .cout(co0));
  assign cout[0] = co0;
  assign c[1] = co0;
endmodule

// partitioned_carry_chain (carry_kill_gate, carry_increment segments of 8 bits): one adder for the lane packings 2 x 8, the carry cut at the selected mode's lane boundaries
module fam_add_partitioned_w16_8_carry_kill_gate_97f154d649b3 (input logic [15:0] a, input logic [15:0] b, input logic [1:0] cin, input logic [0:0] sel, output logic [15:0] s, output logic [1:0] cout);
  logic [2:0] c;
  assign c[0] = cin[0];
  logic co0;
  fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w8 u0 (.a(a[7:0]), .b(b[7:0]), .cin(c[0]), .s(s[7:0]), .cout(co0));
  assign cout[0] = co0;
  logic bnd1; assign bnd1 = (sel == 1'd0);
  assign c[1] = (co0 & ~bnd1) | (cin[1] & bnd1);
  logic co1;
  fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w8 u1 (.a(a[15:8]), .b(b[15:8]), .cin(c[1]), .s(s[15:8]), .cout(co1));
  assign cout[1] = co1;
  assign c[2] = co1;
endmodule


// carry_increment: blocks [7, 7, 2] (uniform), group carries rippled, 2 increment levels
module fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16 (input logic [15:0] a, input logic [15:0] b, input logic cin, output logic [15:0] s, output logic cout);
  logic [6:0] s0;
  logic co0;
  // block 0 (7 bits), carry-in 0
  fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_block_adder_adder_w7 u1 (.a(a[6:0]), .b(b[6:0]), .cin(1'b0), .s(s0), .cout(co0));
  logic bp0; assign bp0 = &(a[6:0] ^ b[6:0]);
  logic [6:0] s1;
  logic co1;
  // block 1 (7 bits), carry-in 0
  fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_block_adder_adder_w7 u2 (.a(a[13:7]), .b(b[13:7]), .cin(1'b0), .s(s1), .cout(co1));
  logic bp1; assign bp1 = &(a[13:7] ^ b[13:7]);
  logic [1:0] s2;
  logic co2;
  // block 2 (2 bits), carry-in 0
  fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_block_adder_adder_w2 u3 (.a(a[15:14]), .b(b[15:14]), .cin(1'b0), .s(s2), .cout(co2));
  logic bp2; assign bp2 = &(a[15:14] ^ b[15:14]);
  logic c0_0; assign c0_0 = co0 | (bp0 & 1'b0);
  logic c0_1; assign c0_1 = co1 | (bp1 & c0_0);
  logic [6:0] si0;
  logic ico0;
  // group 0 block 0: the group-internal carry
  fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_increment_stage_incrementer_w7 u4 (.a(s0), .cin(1'b0), .s(si0), .cout(ico0));
  logic [6:0] si1;
  logic ico1;
  // group 0 block 1: the group-internal carry
  fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_increment_stage_incrementer_w7 u5 (.a(s1), .cin(c0_0), .s(si1), .cout(ico1));
  logic [13:0] gs0; assign gs0 = {si1, si0};
  logic gp0; assign gp0 = bp0 & bp1;
  logic c1_2; assign c1_2 = co2 | (bp2 & 1'b0);
  logic [1:0] si2;
  logic ico2;
  // group 1 block 2: the group-internal carry
  fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_increment_stage_incrementer_w2 u6 (.a(s2), .cin(1'b0), .s(si2), .cout(ico2));
  logic [1:0] gs1; assign gs1 = {si2};
  logic gp1; assign gp1 = bp2;
  logic gc1; assign gc1 = c0_1 | (gp0 & cin);
  logic gc2; assign gc2 = c1_2 | (gp1 & gc1);
  logic [13:0] gsi0;
  logic gico0;
  // group 0: the group carry-in through the second increment level
  fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_increment_stage_incrementer_w14 u7 (.a(gs0), .cin(cin), .s(gsi0), .cout(gico0));
  assign s[13:0] = gsi0;
  logic [1:0] gsi1;
  logic gico1;
  // group 1: the group carry-in through the second increment level
  fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_increment_stage_incrementer_w2 u8 (.a(gs1), .cin(gc1), .s(gsi1), .cout(gico1));
  assign s[15:14] = gsi1;
  assign cout = gc2;
endmodule





module fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_block_adder_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_prefix_kogge_stone_w2_v3 implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_block_adder_adder_w7(input wire [6:0] a, input wire [6:0] b, input wire [0:0] cin, output wire [6:0] s, output wire [0:0] cout);
fam_prefix_kogge_stone_w7_v3 implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule



module fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_increment_stage_incrementer_w14(input wire [13:0] a, input wire [0:0] cin, output wire [13:0] s, output wire [0:0] cout);
fam_incr_prefix_and #(.W(14), .STRUCTURE(1), .B(4), .TOPO(0)) implementation(.a(a), .cin(cin), .s(s), .cout(cout));
endmodule






module fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_increment_stage_incrementer_w2(input wire [1:0] a, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_incr_prefix_and #(.W(2), .STRUCTURE(1), .B(4), .TOPO(0)) implementation(.a(a), .cin(cin), .s(s), .cout(cout));
endmodule





module fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16_component_increment_stage_incrementer_w7(input wire [6:0] a, input wire [0:0] cin, output wire [6:0] s, output wire [0:0] cout);
fam_incr_prefix_and #(.W(7), .STRUCTURE(1), .B(4), .TOPO(0)) implementation(.a(a), .cin(cin), .s(s), .cout(cout));
endmodule

// carry_increment: blocks [7, 7, 2] (uniform), group carries lookahead_tree, 1 increment level
module fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w16 (input logic [15:0] a, input logic [15:0] b, input logic cin, output logic [15:0] s, output logic cout);
  logic [6:0] s0;
  logic co0;
  // block 0 (7 bits), carry-in 0
  fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w16_component_block_adder_adder_w7 u1 (.a(a[6:0]), .b(b[6:0]), .cin(1'b0), .s(s0), .cout(co0));
  logic bp0; assign bp0 = &(a[6:0] ^ b[6:0]);
  logic [6:0] s1;
  logic co1;
  // block 1 (7 bits), carry-in 0
  fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w16_component_block_adder_adder_w7 u2 (.a(a[13:7]), .b(b[13:7]), .cin(1'b0), .s(s1), .cout(co1));
  logic bp1; assign bp1 = &(a[13:7] ^ b[13:7]);
  logic [1:0] s2;
  logic co2;
  // block 2 (2 bits), carry-in 0
  fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w16_component_block_adder_adder_w2 u3 (.a(a[15:14]), .b(b[15:14]), .cin(1'b0), .s(s2), .cout(co2));
  logic bp2; assign bp2 = &(a[15:14] ^ b[15:14]);
  logic la_t0_0; assign la_t0_0 = co0 | (bp0 & cin);
  logic la_t1_0; assign la_t1_0 = co0 | (bp0 & cin);
  logic la_t1_1; assign la_t1_1 = co1 | (bp1 & la_t1_0);
  logic la_t2_0; assign la_t2_0 = co0 | (bp0 & cin);
  logic la_t2_1; assign la_t2_1 = co1 | (bp1 & la_t2_0);
  logic la_t2_2; assign la_t2_2 = co2 | (bp2 & la_t2_1);
  logic [6:0] si0;
  logic ico0;
  // block 0: the carry-in through the increment stage
  fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w16_component_increment_stage_incrementer_w7 u4 (.a(s0), .cin(cin), .s(si0), .cout(ico0));
  assign s[6:0] = si0;
  logic [6:0] si1;
  logic ico1;
  // block 1: the carry-in through the increment stage
  fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w16_component_increment_stage_incrementer_w7 u5 (.a(s1), .cin(la_t0_0), .s(si1), .cout(ico1));
  assign s[13:7] = si1;
  logic [1:0] si2;
  logic ico2;
  // block 2: the carry-in through the increment stage
  fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w16_component_increment_stage_incrementer_w2 u6 (.a(s2), .cin(la_t1_1), .s(si2), .cout(ico2));
  assign s[15:14] = si2;
  assign cout = la_t2_2;
endmodule




module fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w16_component_block_adder_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(1)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w16_component_block_adder_adder_w7(input wire [6:0] a, input wire [6:0] b, input wire [0:0] cin, output wire [6:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(7), .CHUNK(1), .FORM(1)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule





module fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w16_component_increment_stage_incrementer_w2(input wire [1:0] a, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_incr_prefix_and #(.W(2), .STRUCTURE(0), .B(4), .TOPO(0)) implementation(.a(a), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w16_component_increment_stage_incrementer_w7(input wire [6:0] a, input wire [0:0] cin, output wire [6:0] s, output wire [0:0] cout);
fam_incr_prefix_and #(.W(7), .STRUCTURE(0), .B(4), .TOPO(0)) implementation(.a(a), .cin(cin), .s(s), .cout(cout));
endmodule

// carry_increment: blocks [7, 1] (uniform), group carries lookahead_tree, 1 increment level
module fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w8 (input logic [7:0] a, input logic [7:0] b, input logic cin, output logic [7:0] s, output logic cout);
  logic [6:0] s0;
  logic co0;
  // block 0 (7 bits), carry-in 0
  fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w8_component_block_adder_adder_w7 u1 (.a(a[6:0]), .b(b[6:0]), .cin(1'b0), .s(s0), .cout(co0));
  logic bp0; assign bp0 = &(a[6:0] ^ b[6:0]);
  logic s1;
  logic co1;
  // block 1 (1 bits), carry-in 0
  fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w8_component_block_adder_adder_w1 u2 (.a(a[7:7]), .b(b[7:7]), .cin(1'b0), .s(s1), .cout(co1));
  logic bp1; assign bp1 = &(a[7:7] ^ b[7:7]);
  logic la_t0_0; assign la_t0_0 = co0 | (bp0 & cin);
  logic la_t1_0; assign la_t1_0 = co0 | (bp0 & cin);
  logic la_t1_1; assign la_t1_1 = co1 | (bp1 & la_t1_0);
  logic [6:0] si0;
  logic ico0;
  // block 0: the carry-in through the increment stage
  fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w8_component_increment_stage_incrementer_w7 u3 (.a(s0), .cin(cin), .s(si0), .cout(ico0));
  assign s[6:0] = si0;
  logic si1;
  logic ico1;
  // block 1: the carry-in through the increment stage
  fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w8_component_increment_stage_incrementer_w1 u4 (.a(s1), .cin(la_t0_0), .s(si1), .cout(ico1));
  assign s[7:7] = si1;
  assign cout = la_t1_1;
endmodule




module fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w8_component_block_adder_adder_w1(input wire [0:0] a, input wire [0:0] b, input wire [0:0] cin, output wire [0:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(1), .CHUNK(1), .FORM(1)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w8_component_block_adder_adder_w7(input wire [6:0] a, input wire [6:0] b, input wire [0:0] cin, output wire [6:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(7), .CHUNK(1), .FORM(1)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule





module fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w8_component_increment_stage_incrementer_w1(input wire [0:0] a, input wire [0:0] cin, output wire [0:0] s, output wire [0:0] cout);
fam_incr_prefix_and #(.W(1), .STRUCTURE(0), .B(4), .TOPO(0)) implementation(.a(a), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_carry_increment_p8e2a1d9fd6009dc756b1a3b10ff0f4f78a834b05e1fdfe74950a42d15bbacc33_w8_component_increment_stage_incrementer_w7(input wire [6:0] a, input wire [0:0] cin, output wire [6:0] s, output wire [0:0] cout);
fam_incr_prefix_and #(.W(7), .STRUCTURE(0), .B(4), .TOPO(0)) implementation(.a(a), .cin(cin), .s(s), .cout(cout));
endmodule


// carry_increment: blocks [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] (uniform), group carries lookahead_tree, 1 increment level
module fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26 (input logic [25:0] a, input logic [25:0] b, input logic cin, output logic [25:0] s, output logic cout);
  logic [1:0] s0;
  logic co0;
  // block 0 (2 bits), carry-in 0
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_block_adder_adder_w2 u1 (.a(a[1:0]), .b(b[1:0]), .cin(1'b0), .s(s0), .cout(co0));
  logic bp0; assign bp0 = &(a[1:0] ^ b[1:0]);
  logic [1:0] s1;
  logic co1;
  // block 1 (2 bits), carry-in 0
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_block_adder_adder_w2 u2 (.a(a[3:2]), .b(b[3:2]), .cin(1'b0), .s(s1), .cout(co1));
  logic bp1; assign bp1 = &(a[3:2] ^ b[3:2]);
  logic [1:0] s2;
  logic co2;
  // block 2 (2 bits), carry-in 0
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_block_adder_adder_w2 u3 (.a(a[5:4]), .b(b[5:4]), .cin(1'b0), .s(s2), .cout(co2));
  logic bp2; assign bp2 = &(a[5:4] ^ b[5:4]);
  logic [1:0] s3;
  logic co3;
  // block 3 (2 bits), carry-in 0
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_block_adder_adder_w2 u4 (.a(a[7:6]), .b(b[7:6]), .cin(1'b0), .s(s3), .cout(co3));
  logic bp3; assign bp3 = &(a[7:6] ^ b[7:6]);
  logic [1:0] s4;
  logic co4;
  // block 4 (2 bits), carry-in 0
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_block_adder_adder_w2 u5 (.a(a[9:8]), .b(b[9:8]), .cin(1'b0), .s(s4), .cout(co4));
  logic bp4; assign bp4 = &(a[9:8] ^ b[9:8]);
  logic [1:0] s5;
  logic co5;
  // block 5 (2 bits), carry-in 0
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_block_adder_adder_w2 u6 (.a(a[11:10]), .b(b[11:10]), .cin(1'b0), .s(s5), .cout(co5));
  logic bp5; assign bp5 = &(a[11:10] ^ b[11:10]);
  logic [1:0] s6;
  logic co6;
  // block 6 (2 bits), carry-in 0
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_block_adder_adder_w2 u7 (.a(a[13:12]), .b(b[13:12]), .cin(1'b0), .s(s6), .cout(co6));
  logic bp6; assign bp6 = &(a[13:12] ^ b[13:12]);
  logic [1:0] s7;
  logic co7;
  // block 7 (2 bits), carry-in 0
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_block_adder_adder_w2 u8 (.a(a[15:14]), .b(b[15:14]), .cin(1'b0), .s(s7), .cout(co7));
  logic bp7; assign bp7 = &(a[15:14] ^ b[15:14]);
  logic [1:0] s8;
  logic co8;
  // block 8 (2 bits), carry-in 0
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_block_adder_adder_w2 u9 (.a(a[17:16]), .b(b[17:16]), .cin(1'b0), .s(s8), .cout(co8));
  logic bp8; assign bp8 = &(a[17:16] ^ b[17:16]);
  logic [1:0] s9;
  logic co9;
  // block 9 (2 bits), carry-in 0
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_block_adder_adder_w2 u10 (.a(a[19:18]), .b(b[19:18]), .cin(1'b0), .s(s9), .cout(co9));
  logic bp9; assign bp9 = &(a[19:18] ^ b[19:18]);
  logic [1:0] s10;
  logic co10;
  // block 10 (2 bits), carry-in 0
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_block_adder_adder_w2 u11 (.a(a[21:20]), .b(b[21:20]), .cin(1'b0), .s(s10), .cout(co10));
  logic bp10; assign bp10 = &(a[21:20] ^ b[21:20]);
  logic [1:0] s11;
  logic co11;
  // block 11 (2 bits), carry-in 0
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_block_adder_adder_w2 u12 (.a(a[23:22]), .b(b[23:22]), .cin(1'b0), .s(s11), .cout(co11));
  logic bp11; assign bp11 = &(a[23:22] ^ b[23:22]);
  logic [1:0] s12;
  logic co12;
  // block 12 (2 bits), carry-in 0
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_block_adder_adder_w2 u13 (.a(a[25:24]), .b(b[25:24]), .cin(1'b0), .s(s12), .cout(co12));
  logic bp12; assign bp12 = &(a[25:24] ^ b[25:24]);
  logic la_t0_0; assign la_t0_0 = co0 | (bp0 & cin);
  logic la_t1_0; assign la_t1_0 = co0 | (bp0 & cin);
  logic la_t1_1; assign la_t1_1 = co1 | (bp1 & la_t1_0);
  logic la_t2_0; assign la_t2_0 = co0 | (bp0 & cin);
  logic la_t2_1; assign la_t2_1 = co1 | (bp1 & la_t2_0);
  logic la_t2_2; assign la_t2_2 = co2 | (bp2 & la_t2_1);
  logic la_t3_0; assign la_t3_0 = co0 | (bp0 & cin);
  logic la_t3_1; assign la_t3_1 = co1 | (bp1 & la_t3_0);
  logic la_t3_2; assign la_t3_2 = co2 | (bp2 & la_t3_1);
  logic la_t3_3; assign la_t3_3 = co3 | (bp3 & la_t3_2);
  logic la_t4_0; assign la_t4_0 = co0 | (bp0 & cin);
  logic la_t4_1; assign la_t4_1 = co1 | (bp1 & la_t4_0);
  logic la_t4_2; assign la_t4_2 = co2 | (bp2 & la_t4_1);
  logic la_t4_3; assign la_t4_3 = co3 | (bp3 & la_t4_2);
  logic la_t4_4; assign la_t4_4 = co4 | (bp4 & la_t4_3);
  logic la_t5_0; assign la_t5_0 = co0 | (bp0 & cin);
  logic la_t5_1; assign la_t5_1 = co1 | (bp1 & la_t5_0);
  logic la_t5_2; assign la_t5_2 = co2 | (bp2 & la_t5_1);
  logic la_t5_3; assign la_t5_3 = co3 | (bp3 & la_t5_2);
  logic la_t5_4; assign la_t5_4 = co4 | (bp4 & la_t5_3);
  logic la_t5_5; assign la_t5_5 = co5 | (bp5 & la_t5_4);
  logic la_t6_0; assign la_t6_0 = co0 | (bp0 & cin);
  logic la_t6_1; assign la_t6_1 = co1 | (bp1 & la_t6_0);
  logic la_t6_2; assign la_t6_2 = co2 | (bp2 & la_t6_1);
  logic la_t6_3; assign la_t6_3 = co3 | (bp3 & la_t6_2);
  logic la_t6_4; assign la_t6_4 = co4 | (bp4 & la_t6_3);
  logic la_t6_5; assign la_t6_5 = co5 | (bp5 & la_t6_4);
  logic la_t6_6; assign la_t6_6 = co6 | (bp6 & la_t6_5);
  logic la_t7_0; assign la_t7_0 = co0 | (bp0 & cin);
  logic la_t7_1; assign la_t7_1 = co1 | (bp1 & la_t7_0);
  logic la_t7_2; assign la_t7_2 = co2 | (bp2 & la_t7_1);
  logic la_t7_3; assign la_t7_3 = co3 | (bp3 & la_t7_2);
  logic la_t7_4; assign la_t7_4 = co4 | (bp4 & la_t7_3);
  logic la_t7_5; assign la_t7_5 = co5 | (bp5 & la_t7_4);
  logic la_t7_6; assign la_t7_6 = co6 | (bp6 & la_t7_5);
  logic la_t7_7; assign la_t7_7 = co7 | (bp7 & la_t7_6);
  logic la_t8_0; assign la_t8_0 = co0 | (bp0 & cin);
  logic la_t8_1; assign la_t8_1 = co1 | (bp1 & la_t8_0);
  logic la_t8_2; assign la_t8_2 = co2 | (bp2 & la_t8_1);
  logic la_t8_3; assign la_t8_3 = co3 | (bp3 & la_t8_2);
  logic la_t8_4; assign la_t8_4 = co4 | (bp4 & la_t8_3);
  logic la_t8_5; assign la_t8_5 = co5 | (bp5 & la_t8_4);
  logic la_t8_6; assign la_t8_6 = co6 | (bp6 & la_t8_5);
  logic la_t8_7; assign la_t8_7 = co7 | (bp7 & la_t8_6);
  logic la_t8_8; assign la_t8_8 = co8 | (bp8 & la_t8_7);
  logic la_t9_0; assign la_t9_0 = co0 | (bp0 & cin);
  logic la_t9_1; assign la_t9_1 = co1 | (bp1 & la_t9_0);
  logic la_t9_2; assign la_t9_2 = co2 | (bp2 & la_t9_1);
  logic la_t9_3; assign la_t9_3 = co3 | (bp3 & la_t9_2);
  logic la_t9_4; assign la_t9_4 = co4 | (bp4 & la_t9_3);
  logic la_t9_5; assign la_t9_5 = co5 | (bp5 & la_t9_4);
  logic la_t9_6; assign la_t9_6 = co6 | (bp6 & la_t9_5);
  logic la_t9_7; assign la_t9_7 = co7 | (bp7 & la_t9_6);
  logic la_t9_8; assign la_t9_8 = co8 | (bp8 & la_t9_7);
  logic la_t9_9; assign la_t9_9 = co9 | (bp9 & la_t9_8);
  logic la_t10_0; assign la_t10_0 = co0 | (bp0 & cin);
  logic la_t10_1; assign la_t10_1 = co1 | (bp1 & la_t10_0);
  logic la_t10_2; assign la_t10_2 = co2 | (bp2 & la_t10_1);
  logic la_t10_3; assign la_t10_3 = co3 | (bp3 & la_t10_2);
  logic la_t10_4; assign la_t10_4 = co4 | (bp4 & la_t10_3);
  logic la_t10_5; assign la_t10_5 = co5 | (bp5 & la_t10_4);
  logic la_t10_6; assign la_t10_6 = co6 | (bp6 & la_t10_5);
  logic la_t10_7; assign la_t10_7 = co7 | (bp7 & la_t10_6);
  logic la_t10_8; assign la_t10_8 = co8 | (bp8 & la_t10_7);
  logic la_t10_9; assign la_t10_9 = co9 | (bp9 & la_t10_8);
  logic la_t10_10; assign la_t10_10 = co10 | (bp10 & la_t10_9);
  logic la_t11_0; assign la_t11_0 = co0 | (bp0 & cin);
  logic la_t11_1; assign la_t11_1 = co1 | (bp1 & la_t11_0);
  logic la_t11_2; assign la_t11_2 = co2 | (bp2 & la_t11_1);
  logic la_t11_3; assign la_t11_3 = co3 | (bp3 & la_t11_2);
  logic la_t11_4; assign la_t11_4 = co4 | (bp4 & la_t11_3);
  logic la_t11_5; assign la_t11_5 = co5 | (bp5 & la_t11_4);
  logic la_t11_6; assign la_t11_6 = co6 | (bp6 & la_t11_5);
  logic la_t11_7; assign la_t11_7 = co7 | (bp7 & la_t11_6);
  logic la_t11_8; assign la_t11_8 = co8 | (bp8 & la_t11_7);
  logic la_t11_9; assign la_t11_9 = co9 | (bp9 & la_t11_8);
  logic la_t11_10; assign la_t11_10 = co10 | (bp10 & la_t11_9);
  logic la_t11_11; assign la_t11_11 = co11 | (bp11 & la_t11_10);
  logic la_t12_0; assign la_t12_0 = co0 | (bp0 & cin);
  logic la_t12_1; assign la_t12_1 = co1 | (bp1 & la_t12_0);
  logic la_t12_2; assign la_t12_2 = co2 | (bp2 & la_t12_1);
  logic la_t12_3; assign la_t12_3 = co3 | (bp3 & la_t12_2);
  logic la_t12_4; assign la_t12_4 = co4 | (bp4 & la_t12_3);
  logic la_t12_5; assign la_t12_5 = co5 | (bp5 & la_t12_4);
  logic la_t12_6; assign la_t12_6 = co6 | (bp6 & la_t12_5);
  logic la_t12_7; assign la_t12_7 = co7 | (bp7 & la_t12_6);
  logic la_t12_8; assign la_t12_8 = co8 | (bp8 & la_t12_7);
  logic la_t12_9; assign la_t12_9 = co9 | (bp9 & la_t12_8);
  logic la_t12_10; assign la_t12_10 = co10 | (bp10 & la_t12_9);
  logic la_t12_11; assign la_t12_11 = co11 | (bp11 & la_t12_10);
  logic la_t12_12; assign la_t12_12 = co12 | (bp12 & la_t12_11);
  logic [1:0] si0;
  logic ico0;
  // block 0: the carry-in through the increment stage
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_increment_stage_incrementer_w2 u14 (.a(s0), .cin(cin), .s(si0), .cout(ico0));
  assign s[1:0] = si0;
  logic [1:0] si1;
  logic ico1;
  // block 1: the carry-in through the increment stage
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_increment_stage_incrementer_w2 u15 (.a(s1), .cin(la_t0_0), .s(si1), .cout(ico1));
  assign s[3:2] = si1;
  logic [1:0] si2;
  logic ico2;
  // block 2: the carry-in through the increment stage
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_increment_stage_incrementer_w2 u16 (.a(s2), .cin(la_t1_1), .s(si2), .cout(ico2));
  assign s[5:4] = si2;
  logic [1:0] si3;
  logic ico3;
  // block 3: the carry-in through the increment stage
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_increment_stage_incrementer_w2 u17 (.a(s3), .cin(la_t2_2), .s(si3), .cout(ico3));
  assign s[7:6] = si3;
  logic [1:0] si4;
  logic ico4;
  // block 4: the carry-in through the increment stage
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_increment_stage_incrementer_w2 u18 (.a(s4), .cin(la_t3_3), .s(si4), .cout(ico4));
  assign s[9:8] = si4;
  logic [1:0] si5;
  logic ico5;
  // block 5: the carry-in through the increment stage
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_increment_stage_incrementer_w2 u19 (.a(s5), .cin(la_t4_4), .s(si5), .cout(ico5));
  assign s[11:10] = si5;
  logic [1:0] si6;
  logic ico6;
  // block 6: the carry-in through the increment stage
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_increment_stage_incrementer_w2 u20 (.a(s6), .cin(la_t5_5), .s(si6), .cout(ico6));
  assign s[13:12] = si6;
  logic [1:0] si7;
  logic ico7;
  // block 7: the carry-in through the increment stage
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_increment_stage_incrementer_w2 u21 (.a(s7), .cin(la_t6_6), .s(si7), .cout(ico7));
  assign s[15:14] = si7;
  logic [1:0] si8;
  logic ico8;
  // block 8: the carry-in through the increment stage
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_increment_stage_incrementer_w2 u22 (.a(s8), .cin(la_t7_7), .s(si8), .cout(ico8));
  assign s[17:16] = si8;
  logic [1:0] si9;
  logic ico9;
  // block 9: the carry-in through the increment stage
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_increment_stage_incrementer_w2 u23 (.a(s9), .cin(la_t8_8), .s(si9), .cout(ico9));
  assign s[19:18] = si9;
  logic [1:0] si10;
  logic ico10;
  // block 10: the carry-in through the increment stage
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_increment_stage_incrementer_w2 u24 (.a(s10), .cin(la_t9_9), .s(si10), .cout(ico10));
  assign s[21:20] = si10;
  logic [1:0] si11;
  logic ico11;
  // block 11: the carry-in through the increment stage
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_increment_stage_incrementer_w2 u25 (.a(s11), .cin(la_t10_10), .s(si11), .cout(ico11));
  assign s[23:22] = si11;
  logic [1:0] si12;
  logic ico12;
  // block 12: the carry-in through the increment stage
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_increment_stage_incrementer_w2 u26 (.a(s12), .cin(la_t11_11), .s(si12), .cout(ico12));
  assign s[25:24] = si12;
  assign cout = la_t12_12;
endmodule




module fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_block_adder_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(1)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26_component_increment_stage_incrementer_w2(input wire [1:0] a, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_incr_prefix_and #(.W(2), .STRUCTURE(2), .B(4), .TOPO(0)) implementation(.a(a), .cin(cin), .s(s), .cout(cout));
endmodule



// -------------------------------------------------------------- carry_lookahead
// groups of G bits with a one-level lookahead inside the group (the carries of
// the group from its bit generates and propagates and the group carry-in); the
// group carries come from LEVELS levels of lookahead over the group generates
// and propagates (fam_adder_cla_level): rippled (INTER = 0), looked ahead
// (INTER = 1), or selected (INTER = 2: every group's sum is formed for both
// carry-ins and the rippled group carry selects it, the carry-select stage
// above lookahead blocks).
module fam_adder_carry_lookahead #(parameter int W = 16, parameter int G = 4, parameter int INTER = 0, parameter int LEVELS = 1)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  localparam int NG = (W + G - 1) / G;
  logic [W-1:0] g, p;
  assign g = a & b;
  assign p = a ^ b;
  logic [NG-1:0] gc;                  // the carry into each group
  logic [NG-1:0] GG, GP;              // group generate and propagate
  genvar k, i;
  generate
    for (k = 0; k < NG; k = k + 1) begin : grp
      localparam int LO = k * G;
      localparam int HI = (LO + G > W) ? W : LO + G;
      localparam int NB = HI - LO;
      // the group's generate and propagate from its bits
      logic [NB:0] lg, lp;
      assign lg[0] = 1'b0;
      assign lp[0] = 1'b1;
      for (i = 0; i < NB; i = i + 1) begin : acc
        assign lg[i+1] = g[LO+i] | (p[LO+i] & lg[i]);
        assign lp[i+1] = p[LO+i] & lp[i];
      end
      assign GG[k] = lg[NB];
      assign GP[k] = lp[NB];
      if (INTER == 2) begin : select
        // both sums of the group, selected by the group carry
        logic [NB-1:0] c0, c1;
        for (i = 0; i < NB; i = i + 1) begin : cc
          assign c0[i] = lg[i];
          assign c1[i] = lg[i] | lp[i];
          assign s[LO+i] = p[LO+i] ^ (gc[k] ? c1[i] : c0[i]);
        end
      end else begin : direct
        for (i = 0; i < NB; i = i + 1) begin : cc
          assign s[LO+i] = p[LO+i] ^ (lg[i] | (lp[i] & gc[k]));
        end
      end
    end
    begin : levels
      fam_adder_cla_level #(.N(NG), .G(G), .LEVELS(LEVELS), .INTER(INTER))
        u_lvl (.gg(GG), .gp(GP), .cin(cin), .c(gc), .cout(cout));
    end
  endgenerate
endmodule



// carry_increment: blocks [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] (uniform), group carries lookahead_tree, 1 increment level






// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).














// ------------------------------------------------------------ prefix_and_incrementer
// s = a + cin: the carry into bit i is cin AND every lower bit, a prefix AND
// (STRUCTURE 0 a ripple AND chain, 1 a prefix AND tree of topology TOPO, 2
// select blocks of B bits whose block carry is the AND of the block)





// carry_increment: blocks [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] (uniform), group carries lookahead_tree, 1 increment level






// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).














// ------------------------------------------------------------ prefix_and_incrementer
// s = a + cin: the carry into bit i is cin AND every lower bit, a prefix AND
// (STRUCTURE 0 a ripple AND chain, 1 a prefix AND tree of topology TOPO, 2
// select blocks of B bits whose block carry is the AND of the block)




// carry_select: blocks [4, 4, 4, 1] (uniform), full_duplicate, selects rippled_block_carries






// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).










// carry_select: blocks [4, 4, 3] (uniform), full_duplicate, selects rippled_block_carries
module fam_adder_carry_select_w11 (input logic [10:0] a, input logic [10:0] b, input logic cin, output logic [10:0] s, output logic cout);
  logic [3:0] s0_0;
  logic [3:0] s0_1;
  logic co0_0;
  logic co0_1;
  // block 0 (4 bits), carry-in 0
  fam_adder_carry_select_w11_component_block_adder_adder_w4 u1 (.a(a[3:0]), .b(b[3:0]), .cin(1'b0), .s(s0_0), .cout(co0_0));
  // block 0, carry-in 1
  fam_adder_carry_select_w11_component_block_adder_adder_w4 u2 (.a(a[3:0]), .b(b[3:0]), .cin(1'b1), .s(s0_1), .cout(co0_1));
  logic bp0; assign bp0 = co0_1 & ~co0_0;
  logic [3:0] s1_0;
  logic [3:0] s1_1;
  logic co1_0;
  logic co1_1;
  // block 1 (4 bits), carry-in 0
  fam_adder_carry_select_w11_component_block_adder_adder_w4 u3 (.a(a[7:4]), .b(b[7:4]), .cin(1'b0), .s(s1_0), .cout(co1_0));
  // block 1, carry-in 1
  fam_adder_carry_select_w11_component_block_adder_adder_w4 u4 (.a(a[7:4]), .b(b[7:4]), .cin(1'b1), .s(s1_1), .cout(co1_1));
  logic bp1; assign bp1 = co1_1 & ~co1_0;
  logic [2:0] s2_0;
  logic [2:0] s2_1;
  logic co2_0;
  logic co2_1;
  // block 2 (3 bits), carry-in 0
  fam_adder_carry_select_w11_component_block_adder_adder_w3 u5 (.a(a[10:8]), .b(b[10:8]), .cin(1'b0), .s(s2_0), .cout(co2_0));
  // block 2, carry-in 1
  fam_adder_carry_select_w11_component_block_adder_adder_w3 u6 (.a(a[10:8]), .b(b[10:8]), .cin(1'b1), .s(s2_1), .cout(co2_1));
  logic bp2; assign bp2 = co2_1 & ~co2_0;
  logic c1; assign c1 = cin ? co0_1 : co0_0;
  logic c2; assign c2 = c1 ? co1_1 : co1_0;
  logic c3; assign c3 = c2 ? co2_1 : co2_0;
  assign s[3:0] = cin ? s0_1 : s0_0;
  assign s[7:4] = c1 ? s1_1 : s1_0;
  assign s[10:8] = c2 ? s2_1 : s2_0;
  assign cout = c3;
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).









module fam_adder_carry_select_w11_component_block_adder_adder_w3(input wire [2:0] a, input wire [2:0] b, input wire [0:0] cin, output wire [2:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(3), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_carry_select_w11_component_block_adder_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule






// carry_increment: blocks [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] (uniform), group carries lookahead_tree, 1 increment level






// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).














// ------------------------------------------------------------ prefix_and_incrementer
// s = a + cin: the carry into bit i is cin AND every lower bit, a prefix AND
// (STRUCTURE 0 a ripple AND chain, 1 a prefix AND tree of topology TOPO, 2
// select blocks of B bits whose block carry is the AND of the block)




// carry_select: blocks [4, 4, 4, 1] (uniform), full_duplicate, selects rippled_block_carries
module fam_adder_carry_select_w13 (input logic [12:0] a, input logic [12:0] b, input logic cin, output logic [12:0] s, output logic cout);
  logic [3:0] s0_0;
  logic [3:0] s0_1;
  logic co0_0;
  logic co0_1;
  // block 0 (4 bits), carry-in 0
  fam_adder_carry_select_w13_component_block_adder_adder_w4 u1 (.a(a[3:0]), .b(b[3:0]), .cin(1'b0), .s(s0_0), .cout(co0_0));
  // block 0, carry-in 1
  fam_adder_carry_select_w13_component_block_adder_adder_w4 u2 (.a(a[3:0]), .b(b[3:0]), .cin(1'b1), .s(s0_1), .cout(co0_1));
  logic bp0; assign bp0 = co0_1 & ~co0_0;
  logic [3:0] s1_0;
  logic [3:0] s1_1;
  logic co1_0;
  logic co1_1;
  // block 1 (4 bits), carry-in 0
  fam_adder_carry_select_w13_component_block_adder_adder_w4 u3 (.a(a[7:4]), .b(b[7:4]), .cin(1'b0), .s(s1_0), .cout(co1_0));
  // block 1, carry-in 1
  fam_adder_carry_select_w13_component_block_adder_adder_w4 u4 (.a(a[7:4]), .b(b[7:4]), .cin(1'b1), .s(s1_1), .cout(co1_1));
  logic bp1; assign bp1 = co1_1 & ~co1_0;
  logic [3:0] s2_0;
  logic [3:0] s2_1;
  logic co2_0;
  logic co2_1;
  // block 2 (4 bits), carry-in 0
  fam_adder_carry_select_w13_component_block_adder_adder_w4 u5 (.a(a[11:8]), .b(b[11:8]), .cin(1'b0), .s(s2_0), .cout(co2_0));
  // block 2, carry-in 1
  fam_adder_carry_select_w13_component_block_adder_adder_w4 u6 (.a(a[11:8]), .b(b[11:8]), .cin(1'b1), .s(s2_1), .cout(co2_1));
  logic bp2; assign bp2 = co2_1 & ~co2_0;
  logic s3_0;
  logic s3_1;
  logic co3_0;
  logic co3_1;
  // block 3 (1 bits), carry-in 0
  fam_adder_carry_select_w13_component_block_adder_adder_w1 u7 (.a(a[12:12]), .b(b[12:12]), .cin(1'b0), .s(s3_0), .cout(co3_0));
  // block 3, carry-in 1
  fam_adder_carry_select_w13_component_block_adder_adder_w1 u8 (.a(a[12:12]), .b(b[12:12]), .cin(1'b1), .s(s3_1), .cout(co3_1));
  logic bp3; assign bp3 = co3_1 & ~co3_0;
  logic c1; assign c1 = cin ? co0_1 : co0_0;
  logic c2; assign c2 = c1 ? co1_1 : co1_0;
  logic c3; assign c3 = c2 ? co2_1 : co2_0;
  logic c4; assign c4 = c3 ? co3_1 : co3_0;
  assign s[3:0] = cin ? s0_1 : s0_0;
  assign s[7:4] = c1 ? s1_1 : s1_0;
  assign s[11:8] = c2 ? s2_1 : s2_0;
  assign s[12:12] = c3 ? s3_1 : s3_0;
  assign cout = c4;
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).









module fam_adder_carry_select_w13_component_block_adder_adder_w1(input wire [0:0] a, input wire [0:0] b, input wire [0:0] cin, output wire [0:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(1), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_carry_select_w13_component_block_adder_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule


// carry_select: blocks [4, 4, 4, 4, 4, 4, 4, 4, 2] (uniform), full_duplicate, selects rippled_block_carries
module fam_adder_carry_select_w34 (input logic [33:0] a, input logic [33:0] b, input logic cin, output logic [33:0] s, output logic cout);
  logic [3:0] s0_0;
  logic [3:0] s0_1;
  logic co0_0;
  logic co0_1;
  // block 0 (4 bits), carry-in 0
  fam_adder_carry_select_w34_component_block_adder_adder_w4 u1 (.a(a[3:0]), .b(b[3:0]), .cin(1'b0), .s(s0_0), .cout(co0_0));
  // block 0, carry-in 1
  fam_adder_carry_select_w34_component_block_adder_adder_w4 u2 (.a(a[3:0]), .b(b[3:0]), .cin(1'b1), .s(s0_1), .cout(co0_1));
  logic bp0; assign bp0 = co0_1 & ~co0_0;
  logic [3:0] s1_0;
  logic [3:0] s1_1;
  logic co1_0;
  logic co1_1;
  // block 1 (4 bits), carry-in 0
  fam_adder_carry_select_w34_component_block_adder_adder_w4 u3 (.a(a[7:4]), .b(b[7:4]), .cin(1'b0), .s(s1_0), .cout(co1_0));
  // block 1, carry-in 1
  fam_adder_carry_select_w34_component_block_adder_adder_w4 u4 (.a(a[7:4]), .b(b[7:4]), .cin(1'b1), .s(s1_1), .cout(co1_1));
  logic bp1; assign bp1 = co1_1 & ~co1_0;
  logic [3:0] s2_0;
  logic [3:0] s2_1;
  logic co2_0;
  logic co2_1;
  // block 2 (4 bits), carry-in 0
  fam_adder_carry_select_w34_component_block_adder_adder_w4 u5 (.a(a[11:8]), .b(b[11:8]), .cin(1'b0), .s(s2_0), .cout(co2_0));
  // block 2, carry-in 1
  fam_adder_carry_select_w34_component_block_adder_adder_w4 u6 (.a(a[11:8]), .b(b[11:8]), .cin(1'b1), .s(s2_1), .cout(co2_1));
  logic bp2; assign bp2 = co2_1 & ~co2_0;
  logic [3:0] s3_0;
  logic [3:0] s3_1;
  logic co3_0;
  logic co3_1;
  // block 3 (4 bits), carry-in 0
  fam_adder_carry_select_w34_component_block_adder_adder_w4 u7 (.a(a[15:12]), .b(b[15:12]), .cin(1'b0), .s(s3_0), .cout(co3_0));
  // block 3, carry-in 1
  fam_adder_carry_select_w34_component_block_adder_adder_w4 u8 (.a(a[15:12]), .b(b[15:12]), .cin(1'b1), .s(s3_1), .cout(co3_1));
  logic bp3; assign bp3 = co3_1 & ~co3_0;
  logic [3:0] s4_0;
  logic [3:0] s4_1;
  logic co4_0;
  logic co4_1;
  // block 4 (4 bits), carry-in 0
  fam_adder_carry_select_w34_component_block_adder_adder_w4 u9 (.a(a[19:16]), .b(b[19:16]), .cin(1'b0), .s(s4_0), .cout(co4_0));
  // block 4, carry-in 1
  fam_adder_carry_select_w34_component_block_adder_adder_w4 u10 (.a(a[19:16]), .b(b[19:16]), .cin(1'b1), .s(s4_1), .cout(co4_1));
  logic bp4; assign bp4 = co4_1 & ~co4_0;
  logic [3:0] s5_0;
  logic [3:0] s5_1;
  logic co5_0;
  logic co5_1;
  // block 5 (4 bits), carry-in 0
  fam_adder_carry_select_w34_component_block_adder_adder_w4 u11 (.a(a[23:20]), .b(b[23:20]), .cin(1'b0), .s(s5_0), .cout(co5_0));
  // block 5, carry-in 1
  fam_adder_carry_select_w34_component_block_adder_adder_w4 u12 (.a(a[23:20]), .b(b[23:20]), .cin(1'b1), .s(s5_1), .cout(co5_1));
  logic bp5; assign bp5 = co5_1 & ~co5_0;
  logic [3:0] s6_0;
  logic [3:0] s6_1;
  logic co6_0;
  logic co6_1;
  // block 6 (4 bits), carry-in 0
  fam_adder_carry_select_w34_component_block_adder_adder_w4 u13 (.a(a[27:24]), .b(b[27:24]), .cin(1'b0), .s(s6_0), .cout(co6_0));
  // block 6, carry-in 1
  fam_adder_carry_select_w34_component_block_adder_adder_w4 u14 (.a(a[27:24]), .b(b[27:24]), .cin(1'b1), .s(s6_1), .cout(co6_1));
  logic bp6; assign bp6 = co6_1 & ~co6_0;
  logic [3:0] s7_0;
  logic [3:0] s7_1;
  logic co7_0;
  logic co7_1;
  // block 7 (4 bits), carry-in 0
  fam_adder_carry_select_w34_component_block_adder_adder_w4 u15 (.a(a[31:28]), .b(b[31:28]), .cin(1'b0), .s(s7_0), .cout(co7_0));
  // block 7, carry-in 1
  fam_adder_carry_select_w34_component_block_adder_adder_w4 u16 (.a(a[31:28]), .b(b[31:28]), .cin(1'b1), .s(s7_1), .cout(co7_1));
  logic bp7; assign bp7 = co7_1 & ~co7_0;
  logic [1:0] s8_0;
  logic [1:0] s8_1;
  logic co8_0;
  logic co8_1;
  // block 8 (2 bits), carry-in 0
  fam_adder_carry_select_w34_component_block_adder_adder_w2 u17 (.a(a[33:32]), .b(b[33:32]), .cin(1'b0), .s(s8_0), .cout(co8_0));
  // block 8, carry-in 1
  fam_adder_carry_select_w34_component_block_adder_adder_w2 u18 (.a(a[33:32]), .b(b[33:32]), .cin(1'b1), .s(s8_1), .cout(co8_1));
  logic bp8; assign bp8 = co8_1 & ~co8_0;
  logic c1; assign c1 = cin ? co0_1 : co0_0;
  logic c2; assign c2 = c1 ? co1_1 : co1_0;
  logic c3; assign c3 = c2 ? co2_1 : co2_0;
  logic c4; assign c4 = c3 ? co3_1 : co3_0;
  logic c5; assign c5 = c4 ? co4_1 : co4_0;
  logic c6; assign c6 = c5 ? co5_1 : co5_0;
  logic c7; assign c7 = c6 ? co6_1 : co6_0;
  logic c8; assign c8 = c7 ? co7_1 : co7_0;
  logic c9; assign c9 = c8 ? co8_1 : co8_0;
  assign s[3:0] = cin ? s0_1 : s0_0;
  assign s[7:4] = c1 ? s1_1 : s1_0;
  assign s[11:8] = c2 ? s2_1 : s2_0;
  assign s[15:12] = c3 ? s3_1 : s3_0;
  assign s[19:16] = c4 ? s4_1 : s4_0;
  assign s[23:20] = c5 ? s5_1 : s5_0;
  assign s[27:24] = c6 ? s6_1 : s6_0;
  assign s[31:28] = c7 ? s7_1 : s7_0;
  assign s[33:32] = c8 ? s8_1 : s8_0;
  assign cout = c9;
endmodule




module fam_adder_carry_select_w34_component_block_adder_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule





module fam_adder_carry_select_w34_component_block_adder_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule












// carry_select: blocks [4] (uniform), full_duplicate, selects rippled_block_carries
module fam_adder_carry_select_w4 (input logic [3:0] a, input logic [3:0] b, input logic cin, output logic [3:0] s, output logic cout);
  logic [3:0] s0_0;
  logic [3:0] s0_1;
  logic co0_0;
  logic co0_1;
  // block 0 (4 bits), carry-in 0
  fam_adder_carry_select_w4_component_block_adder_adder_w4 u1 (.a(a[3:0]), .b(b[3:0]), .cin(1'b0), .s(s0_0), .cout(co0_0));
  // block 0, carry-in 1
  fam_adder_carry_select_w4_component_block_adder_adder_w4 u2 (.a(a[3:0]), .b(b[3:0]), .cin(1'b1), .s(s0_1), .cout(co0_1));
  logic bp0; assign bp0 = co0_1 & ~co0_0;
  logic c1; assign c1 = cin ? co0_1 : co0_0;
  assign s[3:0] = cin ? s0_1 : s0_0;
  assign cout = c1;
endmodule




module fam_adder_carry_select_w4_component_block_adder_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule



// carry_select: blocks [4, 1] (uniform), full_duplicate, selects rippled_block_carries
module fam_adder_carry_select_w5 (input logic [4:0] a, input logic [4:0] b, input logic cin, output logic [4:0] s, output logic cout);
  logic [3:0] s0_0;
  logic [3:0] s0_1;
  logic co0_0;
  logic co0_1;
  // block 0 (4 bits), carry-in 0
  fam_adder_carry_select_w5_component_block_adder_adder_w4 u1 (.a(a[3:0]), .b(b[3:0]), .cin(1'b0), .s(s0_0), .cout(co0_0));
  // block 0, carry-in 1
  fam_adder_carry_select_w5_component_block_adder_adder_w4 u2 (.a(a[3:0]), .b(b[3:0]), .cin(1'b1), .s(s0_1), .cout(co0_1));
  logic bp0; assign bp0 = co0_1 & ~co0_0;
  logic s1_0;
  logic s1_1;
  logic co1_0;
  logic co1_1;
  // block 1 (1 bits), carry-in 0
  fam_adder_carry_select_w5_component_block_adder_adder_w1 u3 (.a(a[4:4]), .b(b[4:4]), .cin(1'b0), .s(s1_0), .cout(co1_0));
  // block 1, carry-in 1
  fam_adder_carry_select_w5_component_block_adder_adder_w1 u4 (.a(a[4:4]), .b(b[4:4]), .cin(1'b1), .s(s1_1), .cout(co1_1));
  logic bp1; assign bp1 = co1_1 & ~co1_0;
  logic c1; assign c1 = cin ? co0_1 : co0_0;
  logic c2; assign c2 = c1 ? co1_1 : co1_0;
  assign s[3:0] = cin ? s0_1 : s0_0;
  assign s[4:4] = c1 ? s1_1 : s1_0;
  assign cout = c2;
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).









module fam_adder_carry_select_w5_component_block_adder_adder_w1(input wire [0:0] a, input wire [0:0] b, input wire [0:0] cin, output wire [0:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(1), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_carry_select_w5_component_block_adder_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule









// carry_select: blocks [4, 1] (uniform), full_duplicate, selects rippled_block_carries






// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).










// carry_select: blocks [4, 2] (uniform), full_duplicate, selects rippled_block_carries
module fam_adder_carry_select_w6 (input logic [5:0] a, input logic [5:0] b, input logic cin, output logic [5:0] s, output logic cout);
  logic [3:0] s0_0;
  logic [3:0] s0_1;
  logic co0_0;
  logic co0_1;
  // block 0 (4 bits), carry-in 0
  fam_adder_carry_select_w6_component_block_adder_adder_w4 u1 (.a(a[3:0]), .b(b[3:0]), .cin(1'b0), .s(s0_0), .cout(co0_0));
  // block 0, carry-in 1
  fam_adder_carry_select_w6_component_block_adder_adder_w4 u2 (.a(a[3:0]), .b(b[3:0]), .cin(1'b1), .s(s0_1), .cout(co0_1));
  logic bp0; assign bp0 = co0_1 & ~co0_0;
  logic [1:0] s1_0;
  logic [1:0] s1_1;
  logic co1_0;
  logic co1_1;
  // block 1 (2 bits), carry-in 0
  fam_adder_carry_select_w6_component_block_adder_adder_w2 u3 (.a(a[5:4]), .b(b[5:4]), .cin(1'b0), .s(s1_0), .cout(co1_0));
  // block 1, carry-in 1
  fam_adder_carry_select_w6_component_block_adder_adder_w2 u4 (.a(a[5:4]), .b(b[5:4]), .cin(1'b1), .s(s1_1), .cout(co1_1));
  logic bp1; assign bp1 = co1_1 & ~co1_0;
  logic c1; assign c1 = cin ? co0_1 : co0_0;
  logic c2; assign c2 = c1 ? co1_1 : co1_0;
  assign s[3:0] = cin ? s0_1 : s0_0;
  assign s[5:4] = c1 ? s1_1 : s1_0;
  assign cout = c2;
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).









module fam_adder_carry_select_w6_component_block_adder_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_carry_select_w6_component_block_adder_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule














// carry_select: blocks [4, 1] (uniform), full_duplicate, selects rippled_block_carries






// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).










// carry_select: blocks [4, 2] (uniform), full_duplicate, selects rippled_block_carries






// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).










// carry_select: blocks [4, 4] (uniform), full_duplicate, selects rippled_block_carries
module fam_adder_carry_select_w8 (input logic [7:0] a, input logic [7:0] b, input logic cin, output logic [7:0] s, output logic cout);
  logic [3:0] s0_0;
  logic [3:0] s0_1;
  logic co0_0;
  logic co0_1;
  // block 0 (4 bits), carry-in 0
  fam_adder_carry_select_w8_component_block_adder_adder_w4 u1 (.a(a[3:0]), .b(b[3:0]), .cin(1'b0), .s(s0_0), .cout(co0_0));
  // block 0, carry-in 1
  fam_adder_carry_select_w8_component_block_adder_adder_w4 u2 (.a(a[3:0]), .b(b[3:0]), .cin(1'b1), .s(s0_1), .cout(co0_1));
  logic bp0; assign bp0 = co0_1 & ~co0_0;
  logic [3:0] s1_0;
  logic [3:0] s1_1;
  logic co1_0;
  logic co1_1;
  // block 1 (4 bits), carry-in 0
  fam_adder_carry_select_w8_component_block_adder_adder_w4 u3 (.a(a[7:4]), .b(b[7:4]), .cin(1'b0), .s(s1_0), .cout(co1_0));
  // block 1, carry-in 1
  fam_adder_carry_select_w8_component_block_adder_adder_w4 u4 (.a(a[7:4]), .b(b[7:4]), .cin(1'b1), .s(s1_1), .cout(co1_1));
  logic bp1; assign bp1 = co1_1 & ~co1_0;
  logic c1; assign c1 = cin ? co0_1 : co0_0;
  logic c2; assign c2 = c1 ? co1_1 : co1_0;
  assign s[3:0] = cin ? s0_1 : s0_0;
  assign s[7:4] = c1 ? s1_1 : s1_0;
  assign cout = c2;
endmodule




module fam_adder_carry_select_w8_component_block_adder_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).








// carry_select: blocks [4, 4, 1] (uniform), full_duplicate, selects rippled_block_carries
module fam_adder_carry_select_w9 (input logic [8:0] a, input logic [8:0] b, input logic cin, output logic [8:0] s, output logic cout);
  logic [3:0] s0_0;
  logic [3:0] s0_1;
  logic co0_0;
  logic co0_1;
  // block 0 (4 bits), carry-in 0
  fam_adder_carry_select_w9_component_block_adder_adder_w4 u1 (.a(a[3:0]), .b(b[3:0]), .cin(1'b0), .s(s0_0), .cout(co0_0));
  // block 0, carry-in 1
  fam_adder_carry_select_w9_component_block_adder_adder_w4 u2 (.a(a[3:0]), .b(b[3:0]), .cin(1'b1), .s(s0_1), .cout(co0_1));
  logic bp0; assign bp0 = co0_1 & ~co0_0;
  logic [3:0] s1_0;
  logic [3:0] s1_1;
  logic co1_0;
  logic co1_1;
  // block 1 (4 bits), carry-in 0
  fam_adder_carry_select_w9_component_block_adder_adder_w4 u3 (.a(a[7:4]), .b(b[7:4]), .cin(1'b0), .s(s1_0), .cout(co1_0));
  // block 1, carry-in 1
  fam_adder_carry_select_w9_component_block_adder_adder_w4 u4 (.a(a[7:4]), .b(b[7:4]), .cin(1'b1), .s(s1_1), .cout(co1_1));
  logic bp1; assign bp1 = co1_1 & ~co1_0;
  logic s2_0;
  logic s2_1;
  logic co2_0;
  logic co2_1;
  // block 2 (1 bits), carry-in 0
  fam_adder_carry_select_w9_component_block_adder_adder_w1 u5 (.a(a[8:8]), .b(b[8:8]), .cin(1'b0), .s(s2_0), .cout(co2_0));
  // block 2, carry-in 1
  fam_adder_carry_select_w9_component_block_adder_adder_w1 u6 (.a(a[8:8]), .b(b[8:8]), .cin(1'b1), .s(s2_1), .cout(co2_1));
  logic bp2; assign bp2 = co2_1 & ~co2_0;
  logic c1; assign c1 = cin ? co0_1 : co0_0;
  logic c2; assign c2 = c1 ? co1_1 : co1_0;
  logic c3; assign c3 = c2 ? co2_1 : co2_0;
  assign s[3:0] = cin ? s0_1 : s0_0;
  assign s[7:4] = c1 ? s1_1 : s1_0;
  assign s[8:8] = c2 ? s2_1 : s2_0;
  assign cout = c3;
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).









module fam_adder_carry_select_w9_component_block_adder_adder_w1(input wire [0:0] a, input wire [0:0] b, input wire [0:0] cin, output wire [0:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(1), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule





module fam_adder_carry_select_w9_component_block_adder_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule


// carry_skip: blocks [2] (dp_optimized), 1 skip level, mux
module fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w2 (input logic [1:0] a, input logic [1:0] b, input logic cin, output logic [1:0] s, output logic cout);
  logic P0; assign P0 = &(a[1:0] ^ b[1:0]);
  logic [1:0] s0;
  logic co0;
  // block 0 (2 bits)
  fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w2_component_block_adder_adder_w2 u1 (.a(a[1:0]), .b(b[1:0]), .cin(cin), .s(s0), .cout(co0));
  assign s[1:0] = s0;
  logic bc0;
  assign bc0 = P0 ? cin : co0;
  assign cout = bc0;
endmodule




module fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w2_component_block_adder_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule



// carry_skip: blocks [2] (dp_optimized), 1 skip level, mux






// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).








// carry_skip: blocks [2] (dp_optimized), 1 skip level, mux






// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).








// carry_skip: blocks [1, 1, 1] (dp_optimized), 1 skip level, mux
module fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w3 (input logic [2:0] a, input logic [2:0] b, input logic cin, output logic [2:0] s, output logic cout);
  logic P0; assign P0 = &(a[0:0] ^ b[0:0]);
  logic P1; assign P1 = &(a[1:1] ^ b[1:1]);
  logic P2; assign P2 = &(a[2:2] ^ b[2:2]);
  logic s0;
  logic co0;
  // block 0 (1 bits)
  fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w3_component_block_adder_adder_w1 u1 (.a(a[0:0]), .b(b[0:0]), .cin(cin), .s(s0), .cout(co0));
  assign s[0:0] = s0;
  logic bc0;
  assign bc0 = P0 ? cin : co0;
  logic s1;
  logic co1;
  // block 1 (1 bits)
  fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w3_component_block_adder_adder_w1 u2 (.a(a[1:1]), .b(b[1:1]), .cin(bc0), .s(s1), .cout(co1));
  assign s[1:1] = s1;
  logic bc1;
  assign bc1 = P1 ? bc0 : co1;
  logic s2;
  logic co2;
  // block 2 (1 bits)
  fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w3_component_block_adder_adder_w1 u3 (.a(a[2:2]), .b(b[2:2]), .cin(bc1), .s(s2), .cout(co2));
  assign s[2:2] = s2;
  logic bc2;
  assign bc2 = P2 ? bc1 : co2;
  assign cout = bc2;
endmodule




module fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w3_component_block_adder_adder_w1(input wire [0:0] a, input wire [0:0] b, input wire [0:0] cin, output wire [0:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(1), .CHUNK(1), .FORM(2)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).








// carry_skip: blocks [1, 2, 1] (dp_optimized), 1 skip level, mux
module fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w4 (input logic [3:0] a, input logic [3:0] b, input logic cin, output logic [3:0] s, output logic cout);
  logic P0; assign P0 = &(a[0:0] ^ b[0:0]);
  logic P1; assign P1 = &(a[2:1] ^ b[2:1]);
  logic P2; assign P2 = &(a[3:3] ^ b[3:3]);
  logic s0;
  logic co0;
  // block 0 (1 bits)
  fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w4_component_block_adder_adder_w1 u1 (.a(a[0:0]), .b(b[0:0]), .cin(cin), .s(s0), .cout(co0));
  assign s[0:0] = s0;
  logic bc0;
  assign bc0 = P0 ? cin : co0;
  logic [1:0] s1;
  logic co1;
  // block 1 (2 bits)
  fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w4_component_block_adder_adder_w2 u2 (.a(a[2:1]), .b(b[2:1]), .cin(bc0), .s(s1), .cout(co1));
  assign s[2:1] = s1;
  logic bc1;
  assign bc1 = P1 ? bc0 : co1;
  logic s2;
  logic co2;
  // block 2 (1 bits)
  fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w4_component_block_adder_adder_w1 u3 (.a(a[3:3]), .b(b[3:3]), .cin(bc1), .s(s2), .cout(co2));
  assign s[3:3] = s2;
  logic bc2;
  assign bc2 = P2 ? bc1 : co2;
  assign cout = bc2;
endmodule




module fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w4_component_block_adder_adder_w1(input wire [0:0] a, input wire [0:0] b, input wire [0:0] cin, output wire [0:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(1), .CHUNK(1), .FORM(2)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).









module fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w4_component_block_adder_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




// ------------------------------------------------------------ the lookahead levels
// The carries into N elements from their generate and propagate pairs and a
// carry-in: LEVELS = 1 resolves the N elements flat, the element carries
// rippled (INTER = 0) or looked ahead (INTER = 1); LEVELS > 1 groups G
// elements into super-groups, resolves the super-group carries with the same
// structure one level up, and looks ahead inside every super-group.
module fam_adder_cla_level #(parameter int N = 4, parameter int G = 4, parameter int LEVELS = 1, parameter int INTER = 0)
  (input logic [N-1:0] gg, input logic [N-1:0] gp, input logic cin, output logic [N-1:0] c, output logic cout);
  genvar k, i;
  generate
    if (LEVELS <= 1 || N <= G) begin : flat
      if (INTER == 1) begin : lookahead
        for (k = 0; k < N; k = k + 1) begin : lg
          logic [k+1:0] t;
          assign t[0] = cin;
          for (i = 0; i <= k; i = i + 1) begin : tt
            assign t[i+1] = gg[i] | (gp[i] & t[i]);
          end
          assign c[k] = t[k];
          if (k == N - 1) begin : last
            assign cout = t[k+1];
          end
        end
      end else if (INTER == 2) begin : select
        logic [N:0] r;
        assign r[0] = cin;
        for (k = 0; k < N; k = k + 1) begin : rg
          assign r[k+1] = r[k] ? (gg[k] | gp[k]) : gg[k];
          assign c[k] = r[k];
        end
        assign cout = r[N];
      end else begin : ripple
        logic [N:0] r;
        assign r[0] = cin;
        for (k = 0; k < N; k = k + 1) begin : rg
          assign r[k+1] = gg[k] | (gp[k] & r[k]);
          assign c[k] = r[k];
        end
        assign cout = r[N];
      end
    end else begin : hier
      localparam int NS = (N + G - 1) / G;
      logic [NS-1:0] sgg, sgp, sc;
      for (k = 0; k < NS; k = k + 1) begin : sg
        localparam int LO = k * G;
        localparam int HI = (LO + G > N) ? N : LO + G;
        // the super-group's generate and propagate from its elements
        logic [HI-LO:0] lg, lp;
        assign lg[0] = 1'b0;
        assign lp[0] = 1'b1;
        for (i = 0; i < HI - LO; i = i + 1) begin : acc
          assign lg[i+1] = gg[LO+i] | (gp[LO+i] & lg[i]);
          assign lp[i+1] = gp[LO+i] & lp[i];
          // the lookahead carry into element LO+i from the super-group carry-in
          if (INTER == 2) begin : select
            assign c[LO+i] = sc[k] ? (lg[i] | lp[i]) : lg[i];
          end else begin : lookahead
            assign c[LO+i] = lg[i] | (lp[i] & sc[k]);
          end
        end
        assign sgg[k] = lg[HI-LO];
        assign sgp[k] = lp[HI-LO];
      end
      fam_adder_cla_level #(.N(NS), .G(G), .LEVELS(LEVELS - 1), .INTER(INTER))
        u_up (.gg(sgg), .gp(sgp), .cin(cin), .c(sc), .cout(cout));
    end
  endgenerate
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).
module fam_adder_ripple_carry #(parameter int W = 16, parameter int CHUNK = 1, parameter int FORM = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  localparam int BLOCKS = (W + CHUNK - 1) / CHUNK;
  logic [BLOCKS:0] block_carry;
  assign block_carry[0] = cin;
  for (genvar block_index = 0; block_index < BLOCKS; block_index = block_index + 1) begin : chunk
    localparam int LO = block_index * CHUNK;
    localparam int BW = LO + CHUNK > W ? W - LO : CHUNK;
    (* keep_hierarchy = "yes" *) fam_adder_ripple_chunk #(.W(BW), .FORM(FORM)) u_chunk(
      .a(a[LO +: BW]), .b(b[LO +: BW]), .cin(block_carry[block_index]),
      .s(s[LO +: BW]), .cout(block_carry[block_index+1]));
  end
  assign cout = block_carry[BLOCKS];
endmodule







module fam_adder_ripple_chunk #(parameter int W = 1, parameter int FORM = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  logic [W:0] c;
  assign c[0] = cin;
  genvar i;
  generate
    for (i = 0; i < W; i = i + 1) begin : fa
      if (FORM == 1) begin : two_ha
        wire s1 = a[i] ^ b[i];
        wire c1 = a[i] & b[i];
        wire c2 = s1 & c[i];
        assign s[i] = s1 ^ c[i];
        assign c[i+1] = c1 | c2;
      end else if (FORM == 2) begin : maj
        assign s[i] = a[i] ^ b[i] ^ c[i];
        assign c[i+1] = (a[i] & b[i]) | (a[i] & c[i]) | (b[i] & c[i]);
      end else if (FORM == 3) begin : muxc
        wire p = a[i] ^ b[i];
        assign s[i] = p ^ c[i];
        assign c[i+1] = p ? c[i] : a[i];
      end else begin : gp
        wire g = a[i] & b[i];
        wire p = a[i] ^ b[i];
        assign s[i] = p ^ c[i];
        assign c[i+1] = g | (p & c[i]);
      end
    end
  endgenerate
  assign cout = c[W];
endmodule

// The comparator family of chiALU realized in parametric SystemVerilog:
//   fam_cmp_prefix_comparator #(W, SIGNED, STRUCTURE, RADIX) (input [W-1:0] a, b, output lt, eq)
// The subtractor form (subtractor_comparator) is generated by families/comparator.py around
// the adder of its `subtractor` slot.

// ------------------------------------------------------------ prefix_comparator
// STRUCTURE: 0 msb_first_prefix (a scan from the msb over groups of RADIX bits:
// each group gives (equal, less) flat, the groups are chained msb first), 1
// tree_reduction (a balanced tree of RADIX-ary nodes over the (equal, less)
// pairs). SIGNED flips the sign bits. RADIX is the bits a scan step groups, or
// the arity of a tree node.
module fam_cmp_prefix_comparator #(parameter int W = 16, parameter int SIGNED = 1, parameter int STRUCTURE = 0, parameter int RADIX = 2)
  (input logic [W-1:0] a, input logic [W-1:0] b, output logic lt, output logic eq);
  localparam int R = (RADIX < 2) ? 2 : RADIX;
  localparam int NG = (W + R - 1) / R;                 // the groups of R bits, group g at [g*R +: R] from the lsb
  // ceil(log_r n): the levels of an r-ary tree over n entries
  function automatic int clogr(input int n, input int r);
    int l, p;
    l = 0; p = 1;
    while (p < n) begin p = p * r; l = l + 1; end
    return l;
  endfunction
  // ceil(n / r^l): the entries of level l
  function automatic int entries(input int n, input int r, input int l);
    int m, i;
    m = n;
    for (i = 0; i < l; i = i + 1) m = (m + r - 1) / r;
    return m;
  endfunction
  logic [W-1:0] ax, bx;
  // a signed compare is an unsigned one with the sign bits inverted
  assign ax = {a[W-1] ^ (SIGNED != 0), a[W-2:0]};
  assign bx = {b[W-1] ^ (SIGNED != 0), b[W-2:0]};
  // per bit: equal, less
  logic [W-1:0] e0, l0;
  genvar i, g, l, k;
  generate
    for (i = 0; i < W; i = i + 1) begin : bit_
      assign e0[i] = (ax[i] == bx[i]);
      assign l0[i] = ~ax[i] & bx[i];
    end
    // per group of R bits (flat): equal = every bit equal; less = the first unequal bit from the top is less
    logic [NG-1:0] eg, lg;
    for (g = 0; g < NG; g = g + 1) begin : grp
      localparam int LO = g * R;
      localparam int HI = (LO + R - 1 < W - 1) ? LO + R - 1 : W - 1;
      localparam int N = HI - LO + 1;
      logic [N-1:0] ge, gl;
      assign ge = e0[HI:LO];
      assign gl = l0[HI:LO];
      assign eg[g] = &ge;
      logic [N-1:0] t;
      for (k = 0; k < N; k = k + 1) begin : tk
        // bit LO+k decides when the bits above it in the group are equal
        if (k == N - 1) begin : top
          assign t[k] = gl[k];
        end else begin : low
          assign t[k] = gl[k] & (&ge[N-1:k+1]);
        end
      end
      assign lg[g] = |t;
    end
    if (STRUCTURE == 0) begin : msb_first
      // the scan from the msb group down: e[g]: groups NG-1..g equal; ls[g]: a < b decided within them
      logic [NG:0] e, ls;
      assign e[NG] = 1'b1;
      assign ls[NG] = 1'b0;
      for (g = NG - 1; g >= 0; g = g - 1) begin : scan
        assign e[g] = e[g+1] & eg[g];
        assign ls[g] = ls[g+1] | (e[g+1] & lg[g]);
      end
      assign lt = ls[0];
      assign eq = e[0];
    end else begin : tree
      // a balanced R-ary tree over the group pairs: a node's (equal, less) from its children
      // (child c is more significant than child c-1): equal = AND of the children's equal, less =
      // OR over c of (less_c AND the children above c equal); level l holds ceil(NG / R^l) entries
      localparam int LV = (NG <= 1) ? 1 : clogr(NG, R);
      logic [NG-1:0] E [0:LV];
      logic [NG-1:0] LT [0:LV];
      assign E[0] = eg;
      assign LT[0] = lg;
      for (l = 0; l < LV; l = l + 1) begin : lvl
        localparam int MIN = entries(NG, R, l);       // the entries of the level below
        for (g = 0; g < NG; g = g + 1) begin : node
          if (g * R < MIN) begin : real_
            logic [R-1:0] ce, cl;
            for (k = 0; k < R; k = k + 1) begin : ck
              if (g * R + k < MIN) begin : in_
                assign ce[k] = E[l][g*R + k];
                assign cl[k] = LT[l][g*R + k];
              end else begin : pad
                assign ce[k] = 1'b1;
                assign cl[k] = 1'b0;
              end
            end
            assign E[l+1][g] = &ce;
            logic [R-1:0] t;
            for (k = 0; k < R; k = k + 1) begin : tk
              if (k == R - 1) begin : top
                assign t[k] = cl[k];
              end else begin : low
                assign t[k] = cl[k] & (&ce[R-1:k+1]);
              end
            end
            assign LT[l+1][g] = |t;
          end else begin : pad
            assign E[l+1][g] = 1'b1;
            assign LT[l+1][g] = 1'b0;
          end
        end
      end
      assign lt = LT[LV][0];
      assign eq = E[LV][0];
    end
  endgenerate
endmodule


// subtractor_comparator (carry_increment, sum_or_tree, unsigned): a - b through the adder's carry-out, the sum path unused
module fam_cmp_subtractor_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_sum_or_tree_u_w16 (input logic [15:0] a, input logic [15:0] b, output logic lt, output logic eq);
  logic [15:0] ax, bx, nb, s;
  logic co;
  assign ax = {a[15] ^ 1'b0, a[14:0]};
  assign bx = {b[15] ^ 1'b0, b[14:0]};
  assign nb = ~bx;
  // the subtractor: the adder (carry_increment) on a and ~b with a carry in; no carry out means a < b
  fam_adder_carry_increment_p6f81b180a9f564fa5e724c3d630de9389db6eb128d2111fe7c84b7b2579a71ae_w16 u_sub (.a(ax), .b(nb), .cin(1'b1), .s(s), .cout(co));
  assign lt = ~co;
  assign eq = (s == '0);       // the difference is zero
endmodule

// subtractor_comparator (prefix_synthesis_nonuniform_arrival, operand_xnor, signed): a - b through the adder's carry-out, the sum path unused
module fam_cmp_subtractor_prefix_synthesis_nonuniform_arrival_pc87885195967a6123ef6af9e4b2732165d2e32528a8c668a3c2a6850933d85a8_operand_xnor_s_w8 (input logic [7:0] a, input logic [7:0] b, output logic lt, output logic eq);
  logic [7:0] ax, bx, nb, s;
  logic co;
  assign ax = {a[7] ^ 1'b1, a[6:0]};
  assign bx = {b[7] ^ 1'b1, b[6:0]};
  assign nb = ~bx;
  // the subtractor: the adder (prefix_synthesis_nonuniform_arrival) on a and ~b with a carry in; no carry out means a < b
  fam_prefix_arrival_0_1_2_2_3_2_2_1_w8 u_sub (.a(ax), .b(nb), .cin(1'b1), .s(s), .cout(co));
  assign lt = ~co;
  assign eq = &(ax ~^ bx);     // the operands' XNOR tree
endmodule

// popcount_counter_tree (balanced_tree, full_adder_3_2, adders carry_skip): the count of the ones of a 16-bit word
module fam_count_popcount_balanced_tree_full_adder_3_2_carry_skip_pb5ae0_w16 (input logic [15:0] a, output logic [4:0] n);
  logic g0_s1; assign g0_s1 = a[0] ^ a[1] ^ a[2];
  logic g0_c2; assign g0_c2 = (a[0] & a[1]) | (a[0] & a[2]) | (a[1] & a[2]);
  logic [1:0] gc0; assign gc0 = {g0_c2, g0_s1};
  logic g1_s3; assign g1_s3 = a[3] ^ a[4] ^ a[5];
  logic g1_c4; assign g1_c4 = (a[3] & a[4]) | (a[3] & a[5]) | (a[4] & a[5]);
  logic [1:0] gc1; assign gc1 = {g1_c4, g1_s3};
  logic g2_s5; assign g2_s5 = a[6] ^ a[7] ^ a[8];
  logic g2_c6; assign g2_c6 = (a[6] & a[7]) | (a[6] & a[8]) | (a[7] & a[8]);
  logic [1:0] gc2; assign gc2 = {g2_c6, g2_s5};
  logic g3_s7; assign g3_s7 = a[9] ^ a[10] ^ a[11];
  logic g3_c8; assign g3_c8 = (a[9] & a[10]) | (a[9] & a[11]) | (a[10] & a[11]);
  logic [1:0] gc3; assign gc3 = {g3_c8, g3_s7};
  logic g4_s9; assign g4_s9 = a[12] ^ a[13] ^ a[14];
  logic g4_c10; assign g4_c10 = (a[12] & a[13]) | (a[12] & a[14]) | (a[13] & a[14]);
  logic [1:0] gc4; assign gc4 = {g4_c10, g4_s9};
  logic gc5; assign gc5 = a[15];
  logic [1:0] s1;
  logic co1;
  // count adder 1 (carry_skip, 2 bits)
  fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w2 u1 (.a(gc0), .b(gc1), .cin(1'b0), .s(s1), .cout(co1));
  logic [2:0] t1; assign t1 = {co1, s1};
  logic [1:0] s2;
  logic co2;
  // count adder 2 (carry_skip, 2 bits)
  fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w2 u2 (.a(gc2), .b(gc3), .cin(1'b0), .s(s2), .cout(co2));
  logic [2:0] t2; assign t2 = {co2, s2};
  logic [1:0] s3;
  logic co3;
  // count adder 3 (carry_skip, 2 bits)
  fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w2 u3 (.a(gc4), .b({1'd0, gc5}), .cin(1'b0), .s(s3), .cout(co3));
  logic [2:0] t3; assign t3 = {co3, s3};
  logic [2:0] s4;
  logic co4;
  // count adder 4 (carry_skip, 3 bits)
  fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w3 u4 (.a(t1), .b(t2), .cin(1'b0), .s(s4), .cout(co4));
  logic [3:0] t4; assign t4 = {co4, s4};
  logic [3:0] s5;
  logic co5;
  // count adder 5 (carry_skip, 4 bits)
  fam_adder_carry_skip_p7bc7a93f0e2c5331bda2877dbd43e1d86436b888296411f87c28d9e6c2f96239_w4 u5 (.a(t4), .b({1'd0, t3}), .cin(1'b0), .s(s5), .cout(co5));
  logic [4:0] t5; assign t5 = {co5, s5};
  assign n = t5[4:0];
endmodule


// prefix_lzc (brent_kung prefix OR, lookahead_flags): the leading zeros of a 8-bit word
module fam_count_prefix_lzc_brent_kung_flags_w8 (input logic [7:0] a, output logic [3:0] n);
  logic x0; assign x0 = a[7];
  logic x1; assign x1 = a[6];
  logic x2; assign x2 = a[5];
  logic x3; assign x3 = a[4];
  logic x4; assign x4 = a[3];
  logic x5; assign x5 = a[2];
  logic x6; assign x6 = a[1];
  logic x7; assign x7 = a[0];
  logic p_bu0_1; assign p_bu0_1 = x1 | x0;
  logic p_bu0_3; assign p_bu0_3 = x3 | x2;
  logic p_bu0_5; assign p_bu0_5 = x5 | x4;
  logic p_bu0_7; assign p_bu0_7 = x7 | x6;
  logic p_bu1_3; assign p_bu1_3 = p_bu0_3 | p_bu0_1;
  logic p_bu1_7; assign p_bu1_7 = p_bu0_7 | p_bu0_5;
  logic p_bu2_7; assign p_bu2_7 = p_bu1_7 | p_bu1_3;
  logic p_bd4_5; assign p_bd4_5 = p_bu0_5 | p_bu1_3;
  logic p_bd5_2; assign p_bd5_2 = x2 | p_bu0_1;
  logic p_bd5_4; assign p_bd5_4 = x4 | p_bu1_3;
  logic p_bd5_6; assign p_bd5_6 = x6 | p_bd4_5;
  logic f0; assign f0 = x0;
  logic f1; assign f1 = p_bu0_1 & ~x0;
  logic f2; assign f2 = p_bd5_2 & ~p_bu0_1;
  logic f3; assign f3 = p_bu1_3 & ~p_bd5_2;
  logic f4; assign f4 = p_bd5_4 & ~p_bu1_3;
  logic f5; assign f5 = p_bd4_5 & ~p_bd5_4;
  logic f6; assign f6 = p_bd5_6 & ~p_bd4_5;
  logic f7; assign f7 = p_bu2_7 & ~p_bd5_6;
  logic [3:0] enc;
  // the leading-one flags encoded by one OR tree per count bit
  assign enc[0] = f1 | f3 | f5 | f7;
  assign enc[1] = f2 | f3 | f6 | f7;
  assign enc[2] = f4 | f5 | f6 | f7;
  assign enc[3] = 1'b0;
  assign n = p_bu2_7 ? enc : 4'd8;
endmodule



// priority_encoder (groups of 4, 2 lookahead levels, one_hot_then_encode): the leading zeros of a 16-bit word
module fam_count_priority_encoder_g4_l2_one_hot_then_encode_w16 (input logic [15:0] a, output logic [4:0] n);
  logic any0; assign any0 = a[15] | a[14] | a[13] | a[12];
  logic any1; assign any1 = a[11] | a[10] | a[9] | a[8];
  logic any2; assign any2 = a[7] | a[6] | a[5] | a[4];
  logic any3; assign any3 = a[3] | a[2] | a[1] | a[0];
  logic any2_0; assign any2_0 = any0 | any1 | any2 | any3;
  logic kg0; assign kg0 = 1'b0;
  logic kg1; assign kg1 = any0;
  logic kg2; assign kg2 = any0 | any1;
  logic kg3; assign kg3 = any0 | any1 | any2;
  logic fg0; assign fg0 = any0 & ~kg0;
  logic fg1; assign fg1 = any1 & ~kg1;
  logic fg2; assign fg2 = any2 & ~kg2;
  logic fg3; assign fg3 = any3 & ~kg3;
  logic kb0; assign kb0 = 1'b0;
  logic oh0; assign oh0 = a[15] & ~kb0 & fg0;
  logic kc0; assign kc0 = kb0 | a[15];
  logic kb1; assign kb1 = kc0;
  logic oh1; assign oh1 = a[14] & ~kb1 & fg0;
  logic kc1; assign kc1 = kb1 | a[14];
  logic kb2; assign kb2 = kc1;
  logic oh2; assign oh2 = a[13] & ~kb2 & fg0;
  logic kc2; assign kc2 = kb2 | a[13];
  logic kb3; assign kb3 = kc2;
  logic oh3; assign oh3 = a[12] & ~kb3 & fg0;
  logic kc3; assign kc3 = kb3 | a[12];
  logic kb4; assign kb4 = 1'b0;
  logic oh4; assign oh4 = a[11] & ~kb4 & fg1;
  logic kc4; assign kc4 = kb4 | a[11];
  logic kb5; assign kb5 = kc4;
  logic oh5; assign oh5 = a[10] & ~kb5 & fg1;
  logic kc5; assign kc5 = kb5 | a[10];
  logic kb6; assign kb6 = kc5;
  logic oh6; assign oh6 = a[9] & ~kb6 & fg1;
  logic kc6; assign kc6 = kb6 | a[9];
  logic kb7; assign kb7 = kc6;
  logic oh7; assign oh7 = a[8] & ~kb7 & fg1;
  logic kc7; assign kc7 = kb7 | a[8];
  logic kb8; assign kb8 = 1'b0;
  logic oh8; assign oh8 = a[7] & ~kb8 & fg2;
  logic kc8; assign kc8 = kb8 | a[7];
  logic kb9; assign kb9 = kc8;
  logic oh9; assign oh9 = a[6] & ~kb9 & fg2;
  logic kc9; assign kc9 = kb9 | a[6];
  logic kb10; assign kb10 = kc9;
  logic oh10; assign oh10 = a[5] & ~kb10 & fg2;
  logic kc10; assign kc10 = kb10 | a[5];
  logic kb11; assign kb11 = kc10;
  logic oh11; assign oh11 = a[4] & ~kb11 & fg2;
  logic kc11; assign kc11 = kb11 | a[4];
  logic kb12; assign kb12 = 1'b0;
  logic oh12; assign oh12 = a[3] & ~kb12 & fg3;
  logic kc12; assign kc12 = kb12 | a[3];
  logic kb13; assign kb13 = kc12;
  logic oh13; assign oh13 = a[2] & ~kb13 & fg3;
  logic kc13; assign kc13 = kb13 | a[2];
  logic kb14; assign kb14 = kc13;
  logic oh14; assign oh14 = a[1] & ~kb14 & fg3;
  logic kc14; assign kc14 = kb14 | a[1];
  logic kb15; assign kb15 = kc14;
  logic oh15; assign oh15 = a[0] & ~kb15 & fg3;
  logic kc15; assign kc15 = kb15 | a[0];
  logic v; assign v = any0 | any1 | any2 | any3;
  logic [4:0] enc;
  // the one-hot leading-one vector encoded to the count
  assign enc[0] = oh1 | oh3 | oh5 | oh7 | oh9 | oh11 | oh13 | oh15;
  assign enc[1] = oh2 | oh3 | oh6 | oh7 | oh10 | oh11 | oh14 | oh15;
  assign enc[2] = oh4 | oh5 | oh6 | oh7 | oh12 | oh13 | oh14 | oh15;
  assign enc[3] = oh8 | oh9 | oh10 | oh11 | oh12 | oh13 | oh14 | oh15;
  assign enc[4] = 1'b0;
  assign n = v ? enc : 5'd16;
endmodule


// trailing_zero (reverse_then_lzd over prefix_lzc): the word reversed into the leading-zero detector
module fam_count_tzc_reverse_prefix_lzc_pb8d18_w8 (input logic [7:0] a, output logic [3:0] n);
  logic [7:0] r; assign r = {a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]};
  // the leading-zero detector (prefix_lzc) on the reversed word
  fam_count_prefix_lzc_brent_kung_flags_w8 u1 (.a(r), .n(n));
endmodule

// trailing_zero (reverse_then_lzd over priority_encoder): the word reversed into the leading-zero detector
module fam_count_tzc_reverse_priority_encoder_pdb5fa_w16 (input logic [15:0] a, output logic [4:0] n);
  logic [15:0] r; assign r = {a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12], a[13], a[14], a[15]};
  // the leading-zero detector (priority_encoder) on the reversed word
  fam_count_priority_encoder_g4_l2_one_hot_then_encode_w16 u1 (.a(r), .n(n));
endmodule






// ------------------------------------------------------------ prefix_and_incrementer
// s = a + cin: the carry into bit i is cin AND every lower bit, a prefix AND
// (STRUCTURE 0 a ripple AND chain, 1 a prefix AND tree of topology TOPO, 2
// select blocks of B bits whose block carry is the AND of the block)
module fam_incr_prefix_and #(parameter int W = 16, parameter int STRUCTURE = 1, parameter int B = 4, parameter int TOPO = 0)
  (input logic [W-1:0] a, input logic cin, output logic [W-1:0] s, output logic cout);
  // STRUCTURE: 0 ripple_and_chain, 1 prefix_and_tree (TOPO: 0 sklansky, 1 brent_kung, 2 kogge_stone),
  // 2 select_blocks of B bits
  logic [W:0] c;
  assign c[0] = cin;
  genvar i, l;
  generate
    if (STRUCTURE == 0) begin : ripple
      for (i = 0; i < W; i = i + 1) begin : ch
        assign c[i+1] = c[i] & a[i];
      end
    end else if (STRUCTURE == 1) begin : tree
      localparam int L = (W <= 1) ? 1 : $clog2(W);
      if (TOPO == 2) begin : kogge_stone
        // p[l][i]: AND of a[i] down to a[i - 2^l + 1]
        logic [W-1:0] p [0:L];
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : lvl
          for (i = 0; i < W; i = i + 1) begin : pos
            if (i >= (1 << l)) begin : comb
              assign p[l+1][i] = p[l][i] & p[l][i - (1 << l)];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[L][i];
        end
      end else if (TOPO == 1) begin : brent_kung
        // an up-sweep over the odd positions of each level, then a down-sweep filling the rest
        logic [W-1:0] p [0:2*L];
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : up
          for (i = 0; i < W; i = i + 1) begin : pos
            if (((i + 1) % (2 << l)) == 0) begin : comb
              assign p[l+1][i] = p[l][i] & p[l][i - (1 << l)];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (l = 0; l < L; l = l + 1) begin : down
          localparam int D = 1 << (L - 1 - l);
          for (i = 0; i < W; i = i + 1) begin : pos
            if (((i + 1) % (2 * D)) == D && (i + 1) > D) begin : comb
              assign p[L+l+1][i] = p[L+l][i] & p[L+l][i - D];
            end else begin : keep
              assign p[L+l+1][i] = p[L+l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[2*L][i];
        end
      end else begin : sklansky
        logic [W-1:0] p [0:L];           // p[l][i]: AND of a[i] down to a[i - 2^l + 1]
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : lvl
          for (i = 0; i < W; i = i + 1) begin : pos
            if ((i / (1 << l)) % 2 == 1) begin : comb   // the upper half of every block takes the lower half's end
              assign p[l+1][i] = p[l][i] & p[l][(i / (1 << l)) * (1 << l) - 1];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[L][i];
        end
      end
    end else begin : blocks
      localparam int NB = (W + B - 1) / B;
      logic [NB:0] bc;                  // the carry into each block
      assign bc[0] = cin;
      for (i = 0; i < NB; i = i + 1) begin : blk
        localparam int LO = i * B;
        localparam int HI = (LO + B - 1 < W - 1) ? LO + B - 1 : W - 1;
        logic all1;
        assign all1 = &a[HI:LO];
        assign bc[i+1] = bc[i] & all1;
        genvar j;
        for (j = LO; j <= HI; j = j + 1) begin : bit_
          if (j == LO) begin : first
            assign c[j+1] = bc[i] & a[j];
          end else begin : rest
            assign c[j+1] = c[j] & a[j];
          end
        end
      end
    end
  endgenerate
  assign s = a ^ c[W-1:0];
  assign cout = c[W];
endmodule

// The logic family library: the bitwise gate row of lane_replicated_gates and wide_gate_row.
//   fam_logic_gate_row #(W, NOT_VIA_XOR) (input [W-1:0] a, b, input [1:0] op, output [W-1:0] y)
//   op: 0 and, 1 or, 2 xor, 3 not (of a)
// NOT_VIA_XOR = 1 forms the not as a xor with ones, so the row is three gate types and a
// two-way operand select instead of four gate types under a four-way result mux.
module fam_logic_gate_row #(parameter int W = 16, parameter int NOT_VIA_XOR = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic [1:0] op, output logic [W-1:0] y);
  generate
    if (NOT_VIA_XOR) begin : via_xor
      logic [W-1:0] bx;
      assign bx = (op == 2'd3) ? {W{1'b1}} : b;
      assign y = (op == 2'd0) ? (a & b) : (op == 2'd1) ? (a | b) : (a ^ bx);
    end else begin : plain
      assign y = (op == 2'd0) ? (a & b) : (op == 2'd1) ? (a | b) : (op == 2'd2) ? (a ^ b) : ~a;
    end
  endgenerate
endmodule



module fam_mul_booth16_dadda_3_2_w4_u_pe5d7a1e3 (input logic [3:0] a, input logic [3:0] b, output logic [7:0] p);
  // booth_recoded_parallel: {'pp_bits': 23, 'full_adders': 0, 'half_adders': 4, 'cells': 0, 'tree_depth': 3}
  logic neg1, sel3, sel4, sel5, sel6, sel7, sel8, sel9, sel10, pp11, pp12, pp13, pp14, pp15, pp16, pp17, pp18, pp19, pp20, pp21, pp22, pp23, pp24, pp25, neg27, sel29, sel30, sel31, sel32, sel33, sel34, sel35, sel36, pp37, pp38, pp39, pp40, pp41, pp42, pp43, pp44, pp45, t46, t47, t48, t49, t50, t51, t52, t53;
  logic [8:0] a_ext;
  logic [3:0] lo0;
  logic [3:0] mg2;
  logic [8:0] m2;
  logic [8:0] m3;
  logic [8:0] m4;
  logic [8:0] m5;
  logic [8:0] m6;
  logic [8:0] m8;
  logic [8:0] m7_ny;
  logic [8:0] m7;
  logic [3:0] lo26;
  logic [3:0] mg28;
  logic [3:0] m3_t0; logic m3_c0;
  // 3a tile 0 (ripple_carry, 4 bits): 2a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i1 (.a(m2[3:0]), .b(a_ext[3:0]), .cin(1'b0), .s(m3_t0), .cout(m3_c0));
  logic [3:0] m3_t1; logic m3_c1;
  // 3a tile 1 (ripple_carry, 4 bits): 2a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i2 (.a(m2[7:4]), .b(a_ext[7:4]), .cin(1'b0), .s(m3_t1), .cout(m3_c1));
  logic m3_t2; logic m3_c2;
  // 3a tile 2 (ripple_carry, 1 bits): 2a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(1), .CHUNK(1), .FORM(2)) u_i3 (.a(m2[8:8]), .b(a_ext[8:8]), .cin(1'b0), .s(m3_t2), .cout(m3_c2));
  logic [3:0] m5_t0; logic m5_c0;
  // 5a tile 0 (ripple_carry, 4 bits): 4a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i4 (.a(m4[3:0]), .b(a_ext[3:0]), .cin(1'b0), .s(m5_t0), .cout(m5_c0));
  logic [3:0] m5_t1; logic m5_c1;
  // 5a tile 1 (ripple_carry, 4 bits): 4a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i5 (.a(m4[7:4]), .b(a_ext[7:4]), .cin(1'b0), .s(m5_t1), .cout(m5_c1));
  logic m5_t2; logic m5_c2;
  // 5a tile 2 (ripple_carry, 1 bits): 4a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(1), .CHUNK(1), .FORM(2)) u_i6 (.a(m4[8:8]), .b(a_ext[8:8]), .cin(1'b0), .s(m5_t2), .cout(m5_c2));
  logic [3:0] m7_t0; logic m7_c0;
  // 7a tile 0 (ripple_carry, 4 bits): 8a - a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i7 (.a(m8[3:0]), .b(m7_ny[3:0]), .cin(1'b1), .s(m7_t0), .cout(m7_c0));
  logic [3:0] m7_t1; logic m7_c1;
  // 7a tile 1 (ripple_carry, 4 bits): 8a - a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i8 (.a(m8[7:4]), .b(m7_ny[7:4]), .cin(1'b0), .s(m7_t1), .cout(m7_c1));
  logic m7_t2; logic m7_c2;
  // 7a tile 2 (ripple_carry, 1 bits): 8a - a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(1), .CHUNK(1), .FORM(2)) u_i9 (.a(m8[8:8]), .b(m7_ny[8:8]), .cin(1'b0), .s(m7_t2), .cout(m7_c2));
  logic [3:0] ts1; logic tc1;
  // tile 1 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i10 (.a({pp14, pp13, pp12, pp11}), .b({1'b0, 1'b0, 1'b0, neg1}), .cin(1'b0), .s(ts1), .cout(tc1));
  logic [3:0] ts2; logic tc2;
  // tile 2 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i11 (.a({pp18, pp17, pp16, pp15}), .b({pp40, pp39, pp38, pp37}), .cin(1'b0), .s(ts2), .cout(tc2));
  logic [3:0] ts3; logic tc3;
  // tile 3 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i12 (.a({1'b1, 1'b1, pp24, neg27}), .b({1'b0, 1'b0, pp25, pp20}), .cin(1'b0), .s(ts3), .cout(tc3));
  logic [3:0] ts4; logic tc4;
  // tile 4 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i13 (.a({1'b0, 1'b0, 1'b0, pp21}), .b({1'b0, 1'b0, 1'b0, pp22}), .cin(1'b0), .s(ts4), .cout(tc4));
  logic [3:0] ts5; logic tc5;
  // tile 5 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i14 (.a({1'b0, 1'b0, 1'b0, pp23}), .b({1'b0, 1'b0, 1'b0, 1'b1}), .cin(1'b0), .s(ts5), .cout(tc5));
  logic [3:0] ts6; logic tc6;
  // tile 6 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i15 (.a({ts2[3], ts2[2], ts2[1], ts2[0]}), .b({ts3[3], ts3[2], ts3[1], ts3[0]}), .cin(1'b0), .s(ts6), .cout(tc6));
  logic [3:0] ts7; logic tc7;
  // tile 7 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i16 (.a({ts4[3], ts4[2], ts4[1], ts4[0]}), .b({ts5[3], ts5[2], ts5[1], ts5[0]}), .cin(1'b0), .s(ts7), .cout(tc7));
  assign a_ext = {{5{1'b0}}, a};
  assign lo0 = {1'b0, {b[2], b[1], b[0]}} + {{3{1'b0}}, 1'b0};
  assign neg1 = b[3] & ~(1'b0 & b[0] & b[1] & b[2]);
  assign mg2 = b[3] ? (4'd8 - lo0) : lo0;
  assign sel3 = (mg2 == 4'd1);
  assign sel4 = (mg2 == 4'd2);
  assign sel5 = (mg2 == 4'd3);
  assign sel6 = (mg2 == 4'd4);
  assign sel7 = (mg2 == 4'd5);
  assign sel8 = (mg2 == 4'd6);
  assign sel9 = (mg2 == 4'd7);
  assign sel10 = (mg2 == 4'd8);
  assign m2 = {a_ext[7:0], 1'd0};
  assign m3 = {m3_t2, m3_t1, m3_t0};
  assign m4 = {a_ext[6:0], 2'd0};
  assign m5 = {m5_t2, m5_t1, m5_t0};
  assign m6 = {m3[7:0], 1'd0};
  assign m8 = {a_ext[5:0], 3'd0};
  assign m7_ny = ~a_ext;
  assign m7 = {m7_t2, m7_t1, m7_t0};
  assign pp11 = ((sel3 & a_ext[0]) | (sel4 & m2[0]) | (sel5 & m3[0]) | (sel6 & m4[0]) | (sel7 & m5[0]) | (sel8 & m6[0]) | (sel9 & m7[0]) | (sel10 & m8[0])) ^ neg1;
  assign pp12 = ((sel3 & a_ext[1]) | (sel4 & m2[1]) | (sel5 & m3[1]) | (sel6 & m4[1]) | (sel7 & m5[1]) | (sel8 & m6[1]) | (sel9 & m7[1]) | (sel10 & m8[1])) ^ neg1;
  assign pp13 = ((sel3 & a_ext[2]) | (sel4 & m2[2]) | (sel5 & m3[2]) | (sel6 & m4[2]) | (sel7 & m5[2]) | (sel8 & m6[2]) | (sel9 & m7[2]) | (sel10 & m8[2])) ^ neg1;
  assign pp14 = ((sel3 & a_ext[3]) | (sel4 & m2[3]) | (sel5 & m3[3]) | (sel6 & m4[3]) | (sel7 & m5[3]) | (sel8 & m6[3]) | (sel9 & m7[3]) | (sel10 & m8[3])) ^ neg1;
  assign pp15 = ((sel3 & a_ext[4]) | (sel4 & m2[4]) | (sel5 & m3[4]) | (sel6 & m4[4]) | (sel7 & m5[4]) | (sel8 & m6[4]) | (sel9 & m7[4]) | (sel10 & m8[4])) ^ neg1;
  assign pp16 = ((sel3 & a_ext[5]) | (sel4 & m2[5]) | (sel5 & m3[5]) | (sel6 & m4[5]) | (sel7 & m5[5]) | (sel8 & m6[5]) | (sel9 & m7[5]) | (sel10 & m8[5])) ^ neg1;
  assign pp17 = ((sel3 & a_ext[6]) | (sel4 & m2[6]) | (sel5 & m3[6]) | (sel6 & m4[6]) | (sel7 & m5[6]) | (sel8 & m6[6]) | (sel9 & m7[6]) | (sel10 & m8[6])) ^ neg1;
  assign pp18 = ((sel3 & a_ext[7]) | (sel4 & m2[7]) | (sel5 & m3[7]) | (sel6 & m4[7]) | (sel7 & m5[7]) | (sel8 & m6[7]) | (sel9 & m7[7]) | (sel10 & m8[7])) ^ neg1;
  assign pp19 = ((sel3 & a_ext[8]) | (sel4 & m2[8]) | (sel5 & m3[8]) | (sel6 & m4[8]) | (sel7 & m5[8]) | (sel8 & m6[8]) | (sel9 & m7[8]) | (sel10 & m8[8])) ^ neg1;
  assign pp20 = sel5 & (m3_c0 ^ neg1);
  assign pp21 = sel7 & (m5_c0 ^ neg1);
  assign pp22 = sel9 & (m7_c0 ^ neg1);
  assign pp23 = ~(neg1 & (sel5 | sel7 | sel9));
  assign pp24 = sel8 & (m3_c0 ^ neg1);
  assign pp25 = ~(neg1 & (sel8));
  assign lo26 = {1'b0, {1'b0, 1'b0, 1'b0}} + {{3{1'b0}}, b[3]};
  assign neg27 = 1'b0 & ~(b[3] & 1'b0 & 1'b0 & 1'b0);
  assign mg28 = 1'b0 ? (4'd8 - lo26) : lo26;
  assign sel29 = (mg28 == 4'd1);
  assign sel30 = (mg28 == 4'd2);
  assign sel31 = (mg28 == 4'd3);
  assign sel32 = (mg28 == 4'd4);
  assign sel33 = (mg28 == 4'd5);
  assign sel34 = (mg28 == 4'd6);
  assign sel35 = (mg28 == 4'd7);
  assign sel36 = (mg28 == 4'd8);
  assign pp37 = ((sel29 & a_ext[0]) | (sel30 & m2[0]) | (sel31 & m3[0]) | (sel32 & m4[0]) | (sel33 & m5[0]) | (sel34 & m6[0]) | (sel35 & m7[0]) | (sel36 & m8[0])) ^ neg27;
  assign pp38 = ((sel29 & a_ext[1]) | (sel30 & m2[1]) | (sel31 & m3[1]) | (sel32 & m4[1]) | (sel33 & m5[1]) | (sel34 & m6[1]) | (sel35 & m7[1]) | (sel36 & m8[1])) ^ neg27;
  assign pp39 = ((sel29 & a_ext[2]) | (sel30 & m2[2]) | (sel31 & m3[2]) | (sel32 & m4[2]) | (sel33 & m5[2]) | (sel34 & m6[2]) | (sel35 & m7[2]) | (sel36 & m8[2])) ^ neg27;
  assign pp40 = ((sel29 & a_ext[3]) | (sel30 & m2[3]) | (sel31 & m3[3]) | (sel32 & m4[3]) | (sel33 & m5[3]) | (sel34 & m6[3]) | (sel35 & m7[3]) | (sel36 & m8[3])) ^ neg27;
  assign pp41 = ((sel29 & a_ext[4]) | (sel30 & m2[4]) | (sel31 & m3[4]) | (sel32 & m4[4]) | (sel33 & m5[4]) | (sel34 & m6[4]) | (sel35 & m7[4]) | (sel36 & m8[4])) ^ neg27;
  assign pp42 = ((sel29 & a_ext[5]) | (sel30 & m2[5]) | (sel31 & m3[5]) | (sel32 & m4[5]) | (sel33 & m5[5]) | (sel34 & m6[5]) | (sel35 & m7[5]) | (sel36 & m8[5])) ^ neg27;
  assign pp43 = ((sel29 & a_ext[6]) | (sel30 & m2[6]) | (sel31 & m3[6]) | (sel32 & m4[6]) | (sel33 & m5[6]) | (sel34 & m6[6]) | (sel35 & m7[6]) | (sel36 & m8[6])) ^ neg27;
  assign pp44 = ((sel29 & a_ext[7]) | (sel30 & m2[7]) | (sel31 & m3[7]) | (sel32 & m4[7]) | (sel33 & m5[7]) | (sel34 & m6[7]) | (sel35 & m7[7]) | (sel36 & m8[7])) ^ neg27;
  assign pp45 = ((sel29 & a_ext[8]) | (sel30 & m2[8]) | (sel31 & m3[8]) | (sel32 & m4[8]) | (sel33 & m5[8]) | (sel34 & m6[8]) | (sel35 & m7[8]) | (sel36 & m8[8])) ^ neg27;
  assign t46 = ts6[0] ^ ts7[0];
  assign t47 = ts6[0] & ts7[0];
  assign t48 = ts6[1] ^ ts7[1];
  assign t49 = ts6[1] & ts7[1];
  assign t50 = ts6[2] ^ ts7[2];
  assign t51 = ts6[2] & ts7[2];
  assign t52 = ts6[3] ^ ts7[3];
  assign t53 = ts6[3] & ts7[3];
  logic [7:0] row_s, row_c;
  assign row_s = {t51, t49, t47, tc1, ts1[3], ts1[2], ts1[1], ts1[0]};
  assign row_c = {t52, t50, t48, t46, 1'b0, 1'b0, 1'b0, 1'b0};
  fam_prefix_kogge_stone_w8_ling4 u_cpa (.a(row_s), .b(row_c), .cin(1'b0), .s(p), .cout());
endmodule


module fam_mul_booth16_dadda_3_2_w5_u_pe5d7a1e3 (input logic [4:0] a, input logic [4:0] b, output logic [9:0] p);
  // booth_recoded_parallel: {'pp_bits': 40, 'full_adders': 0, 'half_adders': 0, 'cells': 0, 'tree_depth': 5}
  logic neg1, sel3, sel4, sel5, sel6, sel7, sel8, sel9, sel10, pp11, pp12, pp13, pp14, pp15, pp16, pp17, pp18, pp19, pp20, pp21, pp22, pp23, pp24, pp25, pp26, pp27, pp28, pp29, pp30, pp31, pp32, neg34, sel36, sel37, sel38, sel39, sel40, sel41, sel42, sel43, pp44, pp45, pp46, pp47, pp48, pp49, pp50, pp51, pp52, pp53, pp54, pp55, pp56, pp57, pp58, pp59;
  logic [9:0] a_ext;
  logic [3:0] lo0;
  logic [3:0] mg2;
  logic [9:0] m2;
  logic [9:0] m3;
  logic [9:0] m4;
  logic [9:0] m5;
  logic [9:0] m6;
  logic [9:0] m8;
  logic [9:0] m7_ny;
  logic [9:0] m7;
  logic [3:0] lo33;
  logic [3:0] mg35;
  logic [3:0] m3_t0; logic m3_c0;
  // 3a tile 0 (ripple_carry, 4 bits): 2a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i1 (.a(m2[3:0]), .b(a_ext[3:0]), .cin(1'b0), .s(m3_t0), .cout(m3_c0));
  logic [3:0] m3_t1; logic m3_c1;
  // 3a tile 1 (ripple_carry, 4 bits): 2a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i2 (.a(m2[7:4]), .b(a_ext[7:4]), .cin(1'b0), .s(m3_t1), .cout(m3_c1));
  logic [1:0] m3_t2; logic m3_c2;
  // 3a tile 2 (ripple_carry, 2 bits): 2a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i3 (.a(m2[9:8]), .b(a_ext[9:8]), .cin(1'b0), .s(m3_t2), .cout(m3_c2));
  logic [3:0] m5_t0; logic m5_c0;
  // 5a tile 0 (ripple_carry, 4 bits): 4a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i4 (.a(m4[3:0]), .b(a_ext[3:0]), .cin(1'b0), .s(m5_t0), .cout(m5_c0));
  logic [3:0] m5_t1; logic m5_c1;
  // 5a tile 1 (ripple_carry, 4 bits): 4a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i5 (.a(m4[7:4]), .b(a_ext[7:4]), .cin(1'b0), .s(m5_t1), .cout(m5_c1));
  logic [1:0] m5_t2; logic m5_c2;
  // 5a tile 2 (ripple_carry, 2 bits): 4a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i6 (.a(m4[9:8]), .b(a_ext[9:8]), .cin(1'b0), .s(m5_t2), .cout(m5_c2));
  logic [3:0] m7_t0; logic m7_c0;
  // 7a tile 0 (ripple_carry, 4 bits): 8a - a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i7 (.a(m8[3:0]), .b(m7_ny[3:0]), .cin(1'b1), .s(m7_t0), .cout(m7_c0));
  logic [3:0] m7_t1; logic m7_c1;
  // 7a tile 1 (ripple_carry, 4 bits): 8a - a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i8 (.a(m8[7:4]), .b(m7_ny[7:4]), .cin(1'b0), .s(m7_t1), .cout(m7_c1));
  logic [1:0] m7_t2; logic m7_c2;
  // 7a tile 2 (ripple_carry, 2 bits): 8a - a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i9 (.a(m8[9:8]), .b(m7_ny[9:8]), .cin(1'b0), .s(m7_t2), .cout(m7_c2));
  logic [3:0] ts1; logic tc1;
  // tile 1 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i10 (.a({pp14, pp13, pp12, pp11}), .b({1'b0, 1'b0, 1'b0, neg1}), .cin(1'b0), .s(ts1), .cout(tc1));
  logic [3:0] ts2; logic tc2;
  // tile 2 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i11 (.a({pp18, pp17, pp16, pp15}), .b({pp47, pp46, pp45, pp44}), .cin(1'b0), .s(ts2), .cout(tc2));
  logic [1:0] ts3; logic tc3;
  // tile 3 (ripple_carry, 2 bits) at level 0
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i12 (.a({pp20, pp19}), .b({pp49, pp48}), .cin(1'b0), .s(ts3), .cout(tc3));
  logic [3:0] ts4; logic tc4;
  // tile 4 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i13 (.a({1'b1, 1'b1, pp25, neg34}), .b({1'b0, 1'b0, pp26, pp21}), .cin(1'b0), .s(ts4), .cout(tc4));
  logic [1:0] ts5; logic tc5;
  // tile 5 (ripple_carry, 2 bits) at level 0
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i14 (.a({pp31, pp27}), .b({pp32, pp28}), .cin(1'b0), .s(ts5), .cout(tc5));
  logic [3:0] ts6; logic tc6;
  // tile 6 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i15 (.a({1'b0, 1'b0, 1'b0, pp22}), .b({1'b0, 1'b0, 1'b0, pp23}), .cin(1'b0), .s(ts6), .cout(tc6));
  logic [1:0] ts7; logic tc7;
  // tile 7 (ripple_carry, 2 bits) at level 0
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i16 (.a({pp58, pp29}), .b({pp59, pp30}), .cin(1'b0), .s(ts7), .cout(tc7));
  logic [3:0] ts8; logic tc8;
  // tile 8 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i17 (.a({1'b0, 1'b0, 1'b0, pp24}), .b({1'b0, 1'b0, 1'b0, 1'b1}), .cin(1'b0), .s(ts8), .cout(tc8));
  logic [1:0] ts9; logic tc9;
  // tile 9 (ripple_carry, 2 bits) at level 0
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i18 (.a({1'b0, pp54}), .b({1'b0, pp55}), .cin(1'b0), .s(ts9), .cout(tc9));
  logic [1:0] ts10; logic tc10;
  // tile 10 (ripple_carry, 2 bits) at level 0
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i19 (.a({1'b0, pp56}), .b({1'b0, pp57}), .cin(1'b0), .s(ts10), .cout(tc10));
  logic [3:0] ts11; logic tc11;
  // tile 11 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i20 (.a({ts2[3], ts2[2], ts2[1], ts2[0]}), .b({ts4[3], ts4[2], ts4[1], ts4[0]}), .cin(1'b0), .s(ts11), .cout(tc11));
  logic [1:0] ts12; logic tc12;
  // tile 12 (ripple_carry, 2 bits) at level 1
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i21 (.a({ts3[1], ts3[0]}), .b({ts5[1], ts5[0]}), .cin(1'b0), .s(ts12), .cout(tc12));
  logic [3:0] ts13; logic tc13;
  // tile 13 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i22 (.a({ts6[3], ts6[2], ts6[1], ts6[0]}), .b({ts8[3], ts8[2], ts8[1], ts8[0]}), .cin(1'b0), .s(ts13), .cout(tc13));
  logic [1:0] ts14; logic tc14;
  // tile 14 (ripple_carry, 2 bits) at level 1
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i23 (.a({ts7[1], ts7[0]}), .b({ts9[1], ts9[0]}), .cin(1'b0), .s(ts14), .cout(tc14));
  logic [1:0] ts15; logic tc15;
  // tile 15 (ripple_carry, 2 bits) at level 1
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i24 (.a({ts10[1], ts10[0]}), .b({1'b0, 1'b1}), .cin(1'b0), .s(ts15), .cout(tc15));
  logic [1:0] ts16; logic tc16;
  // tile 16 (ripple_carry, 2 bits) at level 1
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i25 (.a({1'b0, tc2}), .b({1'b0, tc4}), .cin(1'b0), .s(ts16), .cout(tc16));
  logic [1:0] ts17; logic tc17;
  // tile 17 (ripple_carry, 2 bits) at level 1
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i26 (.a({1'b0, tc6}), .b({1'b0, tc8}), .cin(1'b0), .s(ts17), .cout(tc17));
  logic [3:0] ts18; logic tc18;
  // tile 18 (ripple_carry, 4 bits) at level 2
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i27 (.a({ts11[3], ts11[2], ts11[1], ts11[0]}), .b({ts13[3], ts13[2], ts13[1], ts13[0]}), .cin(1'b0), .s(ts18), .cout(tc18));
  logic [1:0] ts19; logic tc19;
  // tile 19 (ripple_carry, 2 bits) at level 2
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i28 (.a({ts12[1], ts12[0]}), .b({ts14[1], ts14[0]}), .cin(1'b0), .s(ts19), .cout(tc19));
  logic [1:0] ts20; logic tc20;
  // tile 20 (ripple_carry, 2 bits) at level 2
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i29 (.a({ts15[1], ts15[0]}), .b({ts16[1], ts16[0]}), .cin(1'b0), .s(ts20), .cout(tc20));
  logic [1:0] ts21; logic tc21;
  // tile 21 (ripple_carry, 2 bits) at level 2
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i30 (.a({ts17[1], ts17[0]}), .b({1'b0, tc11}), .cin(1'b0), .s(ts21), .cout(tc21));
  logic [3:0] ts22; logic tc22;
  // tile 22 (ripple_carry, 4 bits) at level 3
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i31 (.a({ts18[3], ts18[2], ts18[1], ts18[0]}), .b({1'b0, 1'b0, 1'b0, tc1}), .cin(1'b0), .s(ts22), .cout(tc22));
  logic [1:0] ts23; logic tc23;
  // tile 23 (ripple_carry, 2 bits) at level 3
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i32 (.a({ts19[1], ts19[0]}), .b({ts20[1], ts20[0]}), .cin(1'b0), .s(ts23), .cout(tc23));
  logic [1:0] ts24; logic tc24;
  // tile 24 (ripple_carry, 2 bits) at level 3
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i33 (.a({ts21[1], ts21[0]}), .b({1'b0, tc13}), .cin(1'b0), .s(ts24), .cout(tc24));
  logic [1:0] ts25; logic tc25;
  // tile 25 (ripple_carry, 2 bits) at level 4
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i34 (.a({ts23[1], ts23[0]}), .b({ts24[1], ts24[0]}), .cin(1'b0), .s(ts25), .cout(tc25));
  logic [1:0] ts26; logic tc26;
  // tile 26 (ripple_carry, 2 bits) at level 4
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i35 (.a({1'b0, tc18}), .b({1'b0, tc22}), .cin(1'b0), .s(ts26), .cout(tc26));
  assign a_ext = {{5{1'b0}}, a};
  assign lo0 = {1'b0, {b[2], b[1], b[0]}} + {{3{1'b0}}, 1'b0};
  assign neg1 = b[3] & ~(1'b0 & b[0] & b[1] & b[2]);
  assign mg2 = b[3] ? (4'd8 - lo0) : lo0;
  assign sel3 = (mg2 == 4'd1);
  assign sel4 = (mg2 == 4'd2);
  assign sel5 = (mg2 == 4'd3);
  assign sel6 = (mg2 == 4'd4);
  assign sel7 = (mg2 == 4'd5);
  assign sel8 = (mg2 == 4'd6);
  assign sel9 = (mg2 == 4'd7);
  assign sel10 = (mg2 == 4'd8);
  assign m2 = {a_ext[8:0], 1'd0};
  assign m3 = {m3_t2, m3_t1, m3_t0};
  assign m4 = {a_ext[7:0], 2'd0};
  assign m5 = {m5_t2, m5_t1, m5_t0};
  assign m6 = {m3[8:0], 1'd0};
  assign m8 = {a_ext[6:0], 3'd0};
  assign m7_ny = ~a_ext;
  assign m7 = {m7_t2, m7_t1, m7_t0};
  assign pp11 = ((sel3 & a_ext[0]) | (sel4 & m2[0]) | (sel5 & m3[0]) | (sel6 & m4[0]) | (sel7 & m5[0]) | (sel8 & m6[0]) | (sel9 & m7[0]) | (sel10 & m8[0])) ^ neg1;
  assign pp12 = ((sel3 & a_ext[1]) | (sel4 & m2[1]) | (sel5 & m3[1]) | (sel6 & m4[1]) | (sel7 & m5[1]) | (sel8 & m6[1]) | (sel9 & m7[1]) | (sel10 & m8[1])) ^ neg1;
  assign pp13 = ((sel3 & a_ext[2]) | (sel4 & m2[2]) | (sel5 & m3[2]) | (sel6 & m4[2]) | (sel7 & m5[2]) | (sel8 & m6[2]) | (sel9 & m7[2]) | (sel10 & m8[2])) ^ neg1;
  assign pp14 = ((sel3 & a_ext[3]) | (sel4 & m2[3]) | (sel5 & m3[3]) | (sel6 & m4[3]) | (sel7 & m5[3]) | (sel8 & m6[3]) | (sel9 & m7[3]) | (sel10 & m8[3])) ^ neg1;
  assign pp15 = ((sel3 & a_ext[4]) | (sel4 & m2[4]) | (sel5 & m3[4]) | (sel6 & m4[4]) | (sel7 & m5[4]) | (sel8 & m6[4]) | (sel9 & m7[4]) | (sel10 & m8[4])) ^ neg1;
  assign pp16 = ((sel3 & a_ext[5]) | (sel4 & m2[5]) | (sel5 & m3[5]) | (sel6 & m4[5]) | (sel7 & m5[5]) | (sel8 & m6[5]) | (sel9 & m7[5]) | (sel10 & m8[5])) ^ neg1;
  assign pp17 = ((sel3 & a_ext[6]) | (sel4 & m2[6]) | (sel5 & m3[6]) | (sel6 & m4[6]) | (sel7 & m5[6]) | (sel8 & m6[6]) | (sel9 & m7[6]) | (sel10 & m8[6])) ^ neg1;
  assign pp18 = ((sel3 & a_ext[7]) | (sel4 & m2[7]) | (sel5 & m3[7]) | (sel6 & m4[7]) | (sel7 & m5[7]) | (sel8 & m6[7]) | (sel9 & m7[7]) | (sel10 & m8[7])) ^ neg1;
  assign pp19 = ((sel3 & a_ext[8]) | (sel4 & m2[8]) | (sel5 & m3[8]) | (sel6 & m4[8]) | (sel7 & m5[8]) | (sel8 & m6[8]) | (sel9 & m7[8]) | (sel10 & m8[8])) ^ neg1;
  assign pp20 = ((sel3 & a_ext[9]) | (sel4 & m2[9]) | (sel5 & m3[9]) | (sel6 & m4[9]) | (sel7 & m5[9]) | (sel8 & m6[9]) | (sel9 & m7[9]) | (sel10 & m8[9])) ^ neg1;
  assign pp21 = sel5 & (m3_c0 ^ neg1);
  assign pp22 = sel7 & (m5_c0 ^ neg1);
  assign pp23 = sel9 & (m7_c0 ^ neg1);
  assign pp24 = ~(neg1 & (sel5 | sel7 | sel9));
  assign pp25 = sel8 & (m3_c0 ^ neg1);
  assign pp26 = ~(neg1 & (sel8));
  assign pp27 = sel5 & (m3_c1 ^ neg1);
  assign pp28 = sel7 & (m5_c1 ^ neg1);
  assign pp29 = sel9 & (m7_c1 ^ neg1);
  assign pp30 = ~(neg1 & (sel5 | sel7 | sel9));
  assign pp31 = sel8 & (m3_c1 ^ neg1);
  assign pp32 = ~(neg1 & (sel8));
  assign lo33 = {1'b0, {1'b0, 1'b0, b[4]}} + {{3{1'b0}}, b[3]};
  assign neg34 = 1'b0 & ~(b[3] & b[4] & 1'b0 & 1'b0);
  assign mg35 = 1'b0 ? (4'd8 - lo33) : lo33;
  assign sel36 = (mg35 == 4'd1);
  assign sel37 = (mg35 == 4'd2);
  assign sel38 = (mg35 == 4'd3);
  assign sel39 = (mg35 == 4'd4);
  assign sel40 = (mg35 == 4'd5);
  assign sel41 = (mg35 == 4'd6);
  assign sel42 = (mg35 == 4'd7);
  assign sel43 = (mg35 == 4'd8);
  assign pp44 = ((sel36 & a_ext[0]) | (sel37 & m2[0]) | (sel38 & m3[0]) | (sel39 & m4[0]) | (sel40 & m5[0]) | (sel41 & m6[0]) | (sel42 & m7[0]) | (sel43 & m8[0])) ^ neg34;
  assign pp45 = ((sel36 & a_ext[1]) | (sel37 & m2[1]) | (sel38 & m3[1]) | (sel39 & m4[1]) | (sel40 & m5[1]) | (sel41 & m6[1]) | (sel42 & m7[1]) | (sel43 & m8[1])) ^ neg34;
  assign pp46 = ((sel36 & a_ext[2]) | (sel37 & m2[2]) | (sel38 & m3[2]) | (sel39 & m4[2]) | (sel40 & m5[2]) | (sel41 & m6[2]) | (sel42 & m7[2]) | (sel43 & m8[2])) ^ neg34;
  assign pp47 = ((sel36 & a_ext[3]) | (sel37 & m2[3]) | (sel38 & m3[3]) | (sel39 & m4[3]) | (sel40 & m5[3]) | (sel41 & m6[3]) | (sel42 & m7[3]) | (sel43 & m8[3])) ^ neg34;
  assign pp48 = ((sel36 & a_ext[4]) | (sel37 & m2[4]) | (sel38 & m3[4]) | (sel39 & m4[4]) | (sel40 & m5[4]) | (sel41 & m6[4]) | (sel42 & m7[4]) | (sel43 & m8[4])) ^ neg34;
  assign pp49 = ((sel36 & a_ext[5]) | (sel37 & m2[5]) | (sel38 & m3[5]) | (sel39 & m4[5]) | (sel40 & m5[5]) | (sel41 & m6[5]) | (sel42 & m7[5]) | (sel43 & m8[5])) ^ neg34;
  assign pp50 = ((sel36 & a_ext[6]) | (sel37 & m2[6]) | (sel38 & m3[6]) | (sel39 & m4[6]) | (sel40 & m5[6]) | (sel41 & m6[6]) | (sel42 & m7[6]) | (sel43 & m8[6])) ^ neg34;
  assign pp51 = ((sel36 & a_ext[7]) | (sel37 & m2[7]) | (sel38 & m3[7]) | (sel39 & m4[7]) | (sel40 & m5[7]) | (sel41 & m6[7]) | (sel42 & m7[7]) | (sel43 & m8[7])) ^ neg34;
  assign pp52 = ((sel36 & a_ext[8]) | (sel37 & m2[8]) | (sel38 & m3[8]) | (sel39 & m4[8]) | (sel40 & m5[8]) | (sel41 & m6[8]) | (sel42 & m7[8]) | (sel43 & m8[8])) ^ neg34;
  assign pp53 = ((sel36 & a_ext[9]) | (sel37 & m2[9]) | (sel38 & m3[9]) | (sel39 & m4[9]) | (sel40 & m5[9]) | (sel41 & m6[9]) | (sel42 & m7[9]) | (sel43 & m8[9])) ^ neg34;
  assign pp54 = sel38 & (m3_c0 ^ neg34);
  assign pp55 = sel40 & (m5_c0 ^ neg34);
  assign pp56 = sel42 & (m7_c0 ^ neg34);
  assign pp57 = ~(neg34 & (sel38 | sel40 | sel42));
  assign pp58 = sel41 & (m3_c0 ^ neg34);
  assign pp59 = ~(neg34 & (sel41));
  logic [9:0] row_s, row_c;
  assign row_s = {ts25[1], ts25[0], ts22[3], ts22[2], ts22[1], ts22[0], ts1[3], ts1[2], ts1[1], ts1[0]};
  assign row_c = {ts26[1], ts26[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
  fam_prefix_kogge_stone_w10_ling4 u_cpa (.a(row_s), .b(row_c), .cin(1'b0), .s(p), .cout());
endmodule



module fam_mul_booth16_dadda_3_2_w6_s_pe5d7a1e3 (input logic [5:0] a, input logic [5:0] b, output logic [11:0] p);
  // booth_recoded_parallel: {'pp_bits': 45, 'full_adders': 0, 'half_adders': 0, 'cells': 0, 'tree_depth': 5}
  logic neg1, sel3, sel4, sel5, sel6, sel7, sel8, sel9, sel10, pp11, pp12, pp13, pp14, pp15, pp16, pp17, pp18, pp19, pp20, pp21, pp22, pp23, pp24, pp25, pp26, pp27, pp28, pp29, pp30, pp31, pp32, neg34, sel36, sel37, sel38, sel39, sel40, sel41, sel42, sel43, pp44, pp45, pp46, pp47, pp48, pp49, pp50, pp51, pp52, pp53, pp54, pp55, pp56, pp57, pp58, pp59;
  logic [9:0] a_ext;
  logic [3:0] lo0;
  logic [3:0] mg2;
  logic [9:0] m2;
  logic [9:0] m3;
  logic [9:0] m4;
  logic [9:0] m5;
  logic [9:0] m6;
  logic [9:0] m8;
  logic [9:0] m7_ny;
  logic [9:0] m7;
  logic [3:0] lo33;
  logic [3:0] mg35;
  logic [3:0] m3_t0; logic m3_c0;
  // 3a tile 0 (ripple_carry, 4 bits): 2a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i1 (.a(m2[3:0]), .b(a_ext[3:0]), .cin(1'b0), .s(m3_t0), .cout(m3_c0));
  logic [3:0] m3_t1; logic m3_c1;
  // 3a tile 1 (ripple_carry, 4 bits): 2a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i2 (.a(m2[7:4]), .b(a_ext[7:4]), .cin(1'b0), .s(m3_t1), .cout(m3_c1));
  logic [1:0] m3_t2; logic m3_c2;
  // 3a tile 2 (ripple_carry, 2 bits): 2a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i3 (.a(m2[9:8]), .b(a_ext[9:8]), .cin(1'b0), .s(m3_t2), .cout(m3_c2));
  logic [3:0] m5_t0; logic m5_c0;
  // 5a tile 0 (ripple_carry, 4 bits): 4a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i4 (.a(m4[3:0]), .b(a_ext[3:0]), .cin(1'b0), .s(m5_t0), .cout(m5_c0));
  logic [3:0] m5_t1; logic m5_c1;
  // 5a tile 1 (ripple_carry, 4 bits): 4a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i5 (.a(m4[7:4]), .b(a_ext[7:4]), .cin(1'b0), .s(m5_t1), .cout(m5_c1));
  logic [1:0] m5_t2; logic m5_c2;
  // 5a tile 2 (ripple_carry, 2 bits): 4a + a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i6 (.a(m4[9:8]), .b(a_ext[9:8]), .cin(1'b0), .s(m5_t2), .cout(m5_c2));
  logic [3:0] m7_t0; logic m7_c0;
  // 7a tile 0 (ripple_carry, 4 bits): 8a - a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i7 (.a(m8[3:0]), .b(m7_ny[3:0]), .cin(1'b1), .s(m7_t0), .cout(m7_c0));
  logic [3:0] m7_t1; logic m7_c1;
  // 7a tile 1 (ripple_carry, 4 bits): 8a - a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i8 (.a(m8[7:4]), .b(m7_ny[7:4]), .cin(1'b0), .s(m7_t1), .cout(m7_c1));
  logic [1:0] m7_t2; logic m7_c2;
  // 7a tile 2 (ripple_carry, 2 bits): 8a - a without carry propagation across tiles
  fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(2)) u_i9 (.a(m8[9:8]), .b(m7_ny[9:8]), .cin(1'b0), .s(m7_t2), .cout(m7_c2));
  logic [3:0] ts1; logic tc1;
  // tile 1 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i10 (.a({pp14, pp13, pp12, pp11}), .b({1'b0, 1'b0, 1'b0, neg1}), .cin(1'b0), .s(ts1), .cout(tc1));
  logic [3:0] ts2; logic tc2;
  // tile 2 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i11 (.a({pp18, pp17, pp16, pp15}), .b({pp47, pp46, pp45, pp44}), .cin(1'b0), .s(ts2), .cout(tc2));
  logic [3:0] ts3; logic tc3;
  // tile 3 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i12 (.a({pp20, pp20, pp20, pp19}), .b({pp51, pp50, pp49, pp48}), .cin(1'b0), .s(ts3), .cout(tc3));
  logic [3:0] ts4; logic tc4;
  // tile 4 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i13 (.a({1'b1, 1'b1, pp25, neg34}), .b({1'b0, 1'b0, pp26, pp21}), .cin(1'b0), .s(ts4), .cout(tc4));
  logic [3:0] ts5; logic tc5;
  // tile 5 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i14 (.a({1'b1, 1'b0, pp31, pp27}), .b({1'b0, 1'b0, pp32, pp28}), .cin(1'b0), .s(ts5), .cout(tc5));
  logic [3:0] ts6; logic tc6;
  // tile 6 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i15 (.a({1'b0, 1'b0, 1'b0, pp22}), .b({1'b0, 1'b0, 1'b0, pp23}), .cin(1'b0), .s(ts6), .cout(tc6));
  logic [3:0] ts7; logic tc7;
  // tile 7 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i16 (.a({1'b0, 1'b0, pp58, pp29}), .b({1'b0, 1'b0, pp59, pp30}), .cin(1'b0), .s(ts7), .cout(tc7));
  logic [3:0] ts8; logic tc8;
  // tile 8 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i17 (.a({1'b0, 1'b0, 1'b0, pp24}), .b({1'b0, 1'b0, 1'b0, 1'b1}), .cin(1'b0), .s(ts8), .cout(tc8));
  logic [3:0] ts9; logic tc9;
  // tile 9 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i18 (.a({1'b0, 1'b0, 1'b0, pp54}), .b({1'b0, 1'b0, 1'b0, pp55}), .cin(1'b0), .s(ts9), .cout(tc9));
  logic [3:0] ts10; logic tc10;
  // tile 10 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i19 (.a({1'b0, 1'b0, 1'b0, pp56}), .b({1'b0, 1'b0, 1'b0, pp57}), .cin(1'b0), .s(ts10), .cout(tc10));
  logic [3:0] ts11; logic tc11;
  // tile 11 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i20 (.a({ts2[3], ts2[2], ts2[1], ts2[0]}), .b({ts4[3], ts4[2], ts4[1], ts4[0]}), .cin(1'b0), .s(ts11), .cout(tc11));
  logic [3:0] ts12; logic tc12;
  // tile 12 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i21 (.a({ts3[3], ts3[2], ts3[1], ts3[0]}), .b({ts5[3], ts5[2], ts5[1], ts5[0]}), .cin(1'b0), .s(ts12), .cout(tc12));
  logic [3:0] ts13; logic tc13;
  // tile 13 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i22 (.a({ts6[3], ts6[2], ts6[1], ts6[0]}), .b({ts8[3], ts8[2], ts8[1], ts8[0]}), .cin(1'b0), .s(ts13), .cout(tc13));
  logic [3:0] ts14; logic tc14;
  // tile 14 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i23 (.a({ts7[3], ts7[2], ts7[1], ts7[0]}), .b({ts9[3], ts9[2], ts9[1], ts9[0]}), .cin(1'b0), .s(ts14), .cout(tc14));
  logic [3:0] ts15; logic tc15;
  // tile 15 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i24 (.a({ts10[3], ts10[2], ts10[1], ts10[0]}), .b({1'b0, 1'b0, 1'b0, 1'b1}), .cin(1'b0), .s(ts15), .cout(tc15));
  logic [3:0] ts16; logic tc16;
  // tile 16 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i25 (.a({1'b0, 1'b0, 1'b0, tc2}), .b({1'b0, 1'b0, 1'b0, tc4}), .cin(1'b0), .s(ts16), .cout(tc16));
  logic [3:0] ts17; logic tc17;
  // tile 17 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i26 (.a({1'b0, 1'b0, 1'b0, tc6}), .b({1'b0, 1'b0, 1'b0, tc8}), .cin(1'b0), .s(ts17), .cout(tc17));
  logic [3:0] ts18; logic tc18;
  // tile 18 (ripple_carry, 4 bits) at level 2
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i27 (.a({ts11[3], ts11[2], ts11[1], ts11[0]}), .b({ts13[3], ts13[2], ts13[1], ts13[0]}), .cin(1'b0), .s(ts18), .cout(tc18));
  logic [3:0] ts19; logic tc19;
  // tile 19 (ripple_carry, 4 bits) at level 2
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i28 (.a({ts12[3], ts12[2], ts12[1], ts12[0]}), .b({ts14[3], ts14[2], ts14[1], ts14[0]}), .cin(1'b0), .s(ts19), .cout(tc19));
  logic [3:0] ts20; logic tc20;
  // tile 20 (ripple_carry, 4 bits) at level 2
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i29 (.a({ts15[3], ts15[2], ts15[1], ts15[0]}), .b({ts16[3], ts16[2], ts16[1], ts16[0]}), .cin(1'b0), .s(ts20), .cout(tc20));
  logic [3:0] ts21; logic tc21;
  // tile 21 (ripple_carry, 4 bits) at level 2
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i30 (.a({ts17[3], ts17[2], ts17[1], ts17[0]}), .b({1'b0, 1'b0, 1'b0, tc11}), .cin(1'b0), .s(ts21), .cout(tc21));
  logic [3:0] ts22; logic tc22;
  // tile 22 (ripple_carry, 4 bits) at level 3
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i31 (.a({ts18[3], ts18[2], ts18[1], ts18[0]}), .b({1'b0, 1'b0, 1'b0, tc1}), .cin(1'b0), .s(ts22), .cout(tc22));
  logic [3:0] ts23; logic tc23;
  // tile 23 (ripple_carry, 4 bits) at level 3
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i32 (.a({ts19[3], ts19[2], ts19[1], ts19[0]}), .b({ts20[3], ts20[2], ts20[1], ts20[0]}), .cin(1'b0), .s(ts23), .cout(tc23));
  logic [3:0] ts24; logic tc24;
  // tile 24 (ripple_carry, 4 bits) at level 3
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i33 (.a({ts21[3], ts21[2], ts21[1], ts21[0]}), .b({1'b0, 1'b0, 1'b0, tc13}), .cin(1'b0), .s(ts24), .cout(tc24));
  logic [3:0] ts25; logic tc25;
  // tile 25 (ripple_carry, 4 bits) at level 4
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i34 (.a({ts23[3], ts23[2], ts23[1], ts23[0]}), .b({ts24[3], ts24[2], ts24[1], ts24[0]}), .cin(1'b0), .s(ts25), .cout(tc25));
  logic [3:0] ts26; logic tc26;
  // tile 26 (ripple_carry, 4 bits) at level 4
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(2)) u_i35 (.a({1'b0, 1'b0, 1'b0, tc18}), .b({1'b0, 1'b0, 1'b0, tc22}), .cin(1'b0), .s(ts26), .cout(tc26));
  assign a_ext = {{4{a[5]}}, a};
  assign lo0 = {1'b0, {b[2], b[1], b[0]}} + {{3{1'b0}}, 1'b0};
  assign neg1 = b[3] & ~(1'b0 & b[0] & b[1] & b[2]);
  assign mg2 = b[3] ? (4'd8 - lo0) : lo0;
  assign sel3 = (mg2 == 4'd1);
  assign sel4 = (mg2 == 4'd2);
  assign sel5 = (mg2 == 4'd3);
  assign sel6 = (mg2 == 4'd4);
  assign sel7 = (mg2 == 4'd5);
  assign sel8 = (mg2 == 4'd6);
  assign sel9 = (mg2 == 4'd7);
  assign sel10 = (mg2 == 4'd8);
  assign m2 = {a_ext[8:0], 1'd0};
  assign m3 = {m3_t2, m3_t1, m3_t0};
  assign m4 = {a_ext[7:0], 2'd0};
  assign m5 = {m5_t2, m5_t1, m5_t0};
  assign m6 = {m3[8:0], 1'd0};
  assign m8 = {a_ext[6:0], 3'd0};
  assign m7_ny = ~a_ext;
  assign m7 = {m7_t2, m7_t1, m7_t0};
  assign pp11 = ((sel3 & a_ext[0]) | (sel4 & m2[0]) | (sel5 & m3[0]) | (sel6 & m4[0]) | (sel7 & m5[0]) | (sel8 & m6[0]) | (sel9 & m7[0]) | (sel10 & m8[0])) ^ neg1;
  assign pp12 = ((sel3 & a_ext[1]) | (sel4 & m2[1]) | (sel5 & m3[1]) | (sel6 & m4[1]) | (sel7 & m5[1]) | (sel8 & m6[1]) | (sel9 & m7[1]) | (sel10 & m8[1])) ^ neg1;
  assign pp13 = ((sel3 & a_ext[2]) | (sel4 & m2[2]) | (sel5 & m3[2]) | (sel6 & m4[2]) | (sel7 & m5[2]) | (sel8 & m6[2]) | (sel9 & m7[2]) | (sel10 & m8[2])) ^ neg1;
  assign pp14 = ((sel3 & a_ext[3]) | (sel4 & m2[3]) | (sel5 & m3[3]) | (sel6 & m4[3]) | (sel7 & m5[3]) | (sel8 & m6[3]) | (sel9 & m7[3]) | (sel10 & m8[3])) ^ neg1;
  assign pp15 = ((sel3 & a_ext[4]) | (sel4 & m2[4]) | (sel5 & m3[4]) | (sel6 & m4[4]) | (sel7 & m5[4]) | (sel8 & m6[4]) | (sel9 & m7[4]) | (sel10 & m8[4])) ^ neg1;
  assign pp16 = ((sel3 & a_ext[5]) | (sel4 & m2[5]) | (sel5 & m3[5]) | (sel6 & m4[5]) | (sel7 & m5[5]) | (sel8 & m6[5]) | (sel9 & m7[5]) | (sel10 & m8[5])) ^ neg1;
  assign pp17 = ((sel3 & a_ext[6]) | (sel4 & m2[6]) | (sel5 & m3[6]) | (sel6 & m4[6]) | (sel7 & m5[6]) | (sel8 & m6[6]) | (sel9 & m7[6]) | (sel10 & m8[6])) ^ neg1;
  assign pp18 = ((sel3 & a_ext[7]) | (sel4 & m2[7]) | (sel5 & m3[7]) | (sel6 & m4[7]) | (sel7 & m5[7]) | (sel8 & m6[7]) | (sel9 & m7[7]) | (sel10 & m8[7])) ^ neg1;
  assign pp19 = ((sel3 & a_ext[8]) | (sel4 & m2[8]) | (sel5 & m3[8]) | (sel6 & m4[8]) | (sel7 & m5[8]) | (sel8 & m6[8]) | (sel9 & m7[8]) | (sel10 & m8[8])) ^ neg1;
  assign pp20 = ((sel3 & a_ext[9]) | (sel4 & m2[9]) | (sel5 & m3[9]) | (sel6 & m4[9]) | (sel7 & m5[9]) | (sel8 & m6[9]) | (sel9 & m7[9]) | (sel10 & m8[9])) ^ neg1;
  assign pp21 = sel5 & (m3_c0 ^ neg1);
  assign pp22 = sel7 & (m5_c0 ^ neg1);
  assign pp23 = sel9 & (m7_c0 ^ neg1);
  assign pp24 = ~(neg1 & (sel5 | sel7 | sel9));
  assign pp25 = sel8 & (m3_c0 ^ neg1);
  assign pp26 = ~(neg1 & (sel8));
  assign pp27 = sel5 & (m3_c1 ^ neg1);
  assign pp28 = sel7 & (m5_c1 ^ neg1);
  assign pp29 = sel9 & (m7_c1 ^ neg1);
  assign pp30 = ~(neg1 & (sel5 | sel7 | sel9));
  assign pp31 = sel8 & (m3_c1 ^ neg1);
  assign pp32 = ~(neg1 & (sel8));
  assign lo33 = {1'b0, {b[5], b[5], b[4]}} + {{3{1'b0}}, b[3]};
  assign neg34 = b[5] & ~(b[3] & b[4] & b[5] & b[5]);
  assign mg35 = b[5] ? (4'd8 - lo33) : lo33;
  assign sel36 = (mg35 == 4'd1);
  assign sel37 = (mg35 == 4'd2);
  assign sel38 = (mg35 == 4'd3);
  assign sel39 = (mg35 == 4'd4);
  assign sel40 = (mg35 == 4'd5);
  assign sel41 = (mg35 == 4'd6);
  assign sel42 = (mg35 == 4'd7);
  assign sel43 = (mg35 == 4'd8);
  assign pp44 = ((sel36 & a_ext[0]) | (sel37 & m2[0]) | (sel38 & m3[0]) | (sel39 & m4[0]) | (sel40 & m5[0]) | (sel41 & m6[0]) | (sel42 & m7[0]) | (sel43 & m8[0])) ^ neg34;
  assign pp45 = ((sel36 & a_ext[1]) | (sel37 & m2[1]) | (sel38 & m3[1]) | (sel39 & m4[1]) | (sel40 & m5[1]) | (sel41 & m6[1]) | (sel42 & m7[1]) | (sel43 & m8[1])) ^ neg34;
  assign pp46 = ((sel36 & a_ext[2]) | (sel37 & m2[2]) | (sel38 & m3[2]) | (sel39 & m4[2]) | (sel40 & m5[2]) | (sel41 & m6[2]) | (sel42 & m7[2]) | (sel43 & m8[2])) ^ neg34;
  assign pp47 = ((sel36 & a_ext[3]) | (sel37 & m2[3]) | (sel38 & m3[3]) | (sel39 & m4[3]) | (sel40 & m5[3]) | (sel41 & m6[3]) | (sel42 & m7[3]) | (sel43 & m8[3])) ^ neg34;
  assign pp48 = ((sel36 & a_ext[4]) | (sel37 & m2[4]) | (sel38 & m3[4]) | (sel39 & m4[4]) | (sel40 & m5[4]) | (sel41 & m6[4]) | (sel42 & m7[4]) | (sel43 & m8[4])) ^ neg34;
  assign pp49 = ((sel36 & a_ext[5]) | (sel37 & m2[5]) | (sel38 & m3[5]) | (sel39 & m4[5]) | (sel40 & m5[5]) | (sel41 & m6[5]) | (sel42 & m7[5]) | (sel43 & m8[5])) ^ neg34;
  assign pp50 = ((sel36 & a_ext[6]) | (sel37 & m2[6]) | (sel38 & m3[6]) | (sel39 & m4[6]) | (sel40 & m5[6]) | (sel41 & m6[6]) | (sel42 & m7[6]) | (sel43 & m8[6])) ^ neg34;
  assign pp51 = ((sel36 & a_ext[7]) | (sel37 & m2[7]) | (sel38 & m3[7]) | (sel39 & m4[7]) | (sel40 & m5[7]) | (sel41 & m6[7]) | (sel42 & m7[7]) | (sel43 & m8[7])) ^ neg34;
  assign pp52 = ((sel36 & a_ext[8]) | (sel37 & m2[8]) | (sel38 & m3[8]) | (sel39 & m4[8]) | (sel40 & m5[8]) | (sel41 & m6[8]) | (sel42 & m7[8]) | (sel43 & m8[8])) ^ neg34;
  assign pp53 = ((sel36 & a_ext[9]) | (sel37 & m2[9]) | (sel38 & m3[9]) | (sel39 & m4[9]) | (sel40 & m5[9]) | (sel41 & m6[9]) | (sel42 & m7[9]) | (sel43 & m8[9])) ^ neg34;
  assign pp54 = sel38 & (m3_c0 ^ neg34);
  assign pp55 = sel40 & (m5_c0 ^ neg34);
  assign pp56 = sel42 & (m7_c0 ^ neg34);
  assign pp57 = ~(neg34 & (sel38 | sel40 | sel42));
  assign pp58 = sel41 & (m3_c0 ^ neg34);
  assign pp59 = ~(neg34 & (sel41));
  logic [11:0] row_s, row_c;
  assign row_s = {ts25[3], ts25[2], ts25[1], ts25[0], ts22[3], ts22[2], ts22[1], ts22[0], ts1[3], ts1[2], ts1[1], ts1[0]};
  assign row_c = {ts26[3], ts26[2], ts26[1], ts26[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
  fam_prefix_kogge_stone_w12_ling4 u_cpa (.a(row_s), .b(row_c), .cin(1'b0), .s(p), .cout());
endmodule


module fam_mul_direct_dadda_3_2_w13_s_pbe89483b (input logic [12:0] a, input logic [12:0] b, output logic [25:0] p);
  // direct_pp_parallel: {'pp_bits': 171, 'full_adders': 72, 'half_adders': 6, 'cells': 36, 'tree_depth': 27}
  logic pp0, pp1, pp2, pp3, pp4, pp5, pp6, pp7, pp8, pp9, pp10, pp11, pp12, pp13, pp14, pp15, pp16, pp17, pp18, pp19, pp20, pp21, pp22, pp23, pp24, pp25, pp26, pp27, pp28, pp29, pp30, pp31, pp32, pp33, pp34, pp35, pp36, pp37, pp38, pp39, pp40, pp41, pp42, pp43, pp44, pp45, pp46, pp47, pp48, pp49, pp50, pp51, pp52, pp53, pp54, pp55, pp56, pp57, pp58, pp59, pp60, pp61, pp62, pp63, pp64, pp65, pp66, pp67, pp68, pp69, pp70, pp71, pp72, pp73, pp74, pp75, pp76, pp77, pp78, pp79, pp80, pp81, pp82, pp83, pp84, pp85, pp86, pp87, pp88, pp89, pp90, pp91, pp92, pp93, pp94, pp95, pp96, pp97, pp98, pp99, pp100, pp101, pp102, pp103, pp104, pp105, pp106, pp107, pp108, pp109, pp110, pp111, pp112, pp113, pp114, pp115, pp116, pp117, pp118, pp119, pp120, pp121, pp122, pp123, pp124, pp125, pp126, pp127, pp128, pp129, pp130, pp131, pp132, pp133, pp134, pp135, pp136, pp137, pp138, pp139, pp140, pp141, pp142, pp143, pp144, pp145, pp146, pp147, pp148, pp149, pp150, pp151, pp152, pp153, pp154, pp155, pp156, pp157, pp158, pp159, pp160, pp161, pp162, pp163, pp164, pp165, pp166, pp167, pp168, t169, t170, t171, t172, t173, t174, t175, t176, t177, t178, t179, t180, t181, t182, t183, t184, t185, t186, t187, t188, t189, t190, t191, t192, t193, t194, t195, t196, t197, t198, t199, t200, t201, t202, t203, t204, t205, t206, t207, t208, t209, t210, t211, t212, t213, t214, t215, t216, t217, t218, t219, t220, t221, t222, t223, t224, t225, t226, t227, t228, t229, t230, t231, t232, t233, t234, t235, t236, t237, t238, t239, t240, t241, t242, t243, t244, t245, t246, t247, t248, t249, t250, t251, t252, t253, t254, t255, t256, t257, t258, t259, t260, t261, t262, t263, t264, t265, t266, t267, t268, t269, t270, t271, t272, t273, t274, t275, t276, t277, t278, t279, t280, t281, t282, t283, t284, t285, t286, t287, t288, t289, t290, t291, t292, t293, t294, t295, t296, t297, t298, t299, t300, t301, t302, t303, t304, t305, t306, t307, t308, t309, t310, t311, t312, t313, t314, t315, t316, t317, t318, t319, t320, t321, t322, t323, t324;
  logic [3:0] ts1; logic tc1;
  // tile 1 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i1 (.a({pp3, pp2, pp1, pp0}), .b({pp15, pp14, pp13, 1'b0}), .cin(1'b0), .s(ts1), .cout(tc1));
  logic [3:0] ts2; logic tc2;
  // tile 2 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i2 (.a({pp7, pp6, pp5, pp4}), .b({pp19, pp18, pp17, pp16}), .cin(1'b0), .s(ts2), .cout(tc2));
  logic [3:0] ts3; logic tc3;
  // tile 3 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i3 (.a({pp11, pp10, pp9, pp8}), .b({pp23, pp22, pp21, pp20}), .cin(1'b0), .s(ts3), .cout(tc3));
  logic [3:0] ts4; logic tc4;
  // tile 4 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i4 (.a({pp51, pp38, pp25, pp12}), .b({pp63, pp50, pp37, pp24}), .cin(1'b0), .s(ts4), .cout(tc4));
  logic [3:0] ts5; logic tc5;
  // tile 5 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i5 (.a({pp103, pp90, pp77, pp64}), .b({pp115, pp102, pp89, pp76}), .cin(1'b0), .s(ts5), .cout(tc5));
  logic [3:0] ts6; logic tc6;
  // tile 6 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i6 (.a({pp155, pp142, pp129, pp116}), .b({pp167, pp154, pp141, pp128}), .cin(1'b0), .s(ts6), .cout(tc6));
  logic [3:0] ts7; logic tc7;
  // tile 7 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i7 (.a({pp27, pp26, 1'b0, 1'b0}), .b({pp39, 1'b0, 1'b0, 1'b0}), .cin(1'b0), .s(ts7), .cout(tc7));
  logic [3:0] ts8; logic tc8;
  // tile 8 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i8 (.a({pp31, pp30, pp29, pp28}), .b({pp43, pp42, pp41, pp40}), .cin(1'b0), .s(ts8), .cout(tc8));
  logic [3:0] ts9; logic tc9;
  // tile 9 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i9 (.a({pp35, pp34, pp33, pp32}), .b({pp47, pp46, pp45, pp44}), .cin(1'b0), .s(ts9), .cout(tc9));
  logic [3:0] ts10; logic tc10;
  // tile 10 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i10 (.a({pp75, pp62, pp49, pp36}), .b({pp87, pp74, pp61, pp48}), .cin(1'b0), .s(ts10), .cout(tc10));
  logic [3:0] ts11; logic tc11;
  // tile 11 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i11 (.a({pp127, pp114, pp101, pp88}), .b({pp139, pp126, pp113, pp100}), .cin(1'b0), .s(ts11), .cout(tc11));
  logic [3:0] ts12; logic tc12;
  // tile 12 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i12 (.a({1'b0, pp166, pp153, pp140}), .b({1'b0, 1'b0, pp165, pp152}), .cin(1'b0), .s(ts12), .cout(tc12));
  logic [3:0] ts13; logic tc13;
  // tile 13 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i13 (.a({pp55, pp54, pp53, pp52}), .b({pp67, pp66, pp65, 1'b0}), .cin(1'b0), .s(ts13), .cout(tc13));
  logic [3:0] ts14; logic tc14;
  // tile 14 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i14 (.a({pp59, pp58, pp57, pp56}), .b({pp71, pp70, pp69, pp68}), .cin(1'b0), .s(ts14), .cout(tc14));
  logic [3:0] ts15; logic tc15;
  // tile 15 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i15 (.a({pp99, pp86, pp73, pp60}), .b({pp111, pp98, pp85, pp72}), .cin(1'b0), .s(ts15), .cout(tc15));
  logic [3:0] ts16; logic tc16;
  // tile 16 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i16 (.a({pp151, pp138, pp125, pp112}), .b({pp163, pp150, pp137, pp124}), .cin(1'b0), .s(ts16), .cout(tc16));
  logic [3:0] ts17; logic tc17;
  // tile 17 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i17 (.a({pp79, pp78, 1'b0, 1'b0}), .b({pp91, 1'b0, 1'b0, 1'b0}), .cin(1'b0), .s(ts17), .cout(tc17));
  logic [3:0] ts18; logic tc18;
  // tile 18 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i18 (.a({pp83, pp82, pp81, pp80}), .b({pp95, pp94, pp93, pp92}), .cin(1'b0), .s(ts18), .cout(tc18));
  logic [3:0] ts19; logic tc19;
  // tile 19 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i19 (.a({pp123, pp110, pp97, pp84}), .b({pp135, pp122, pp109, pp96}), .cin(1'b0), .s(ts19), .cout(tc19));
  logic [3:0] ts20; logic tc20;
  // tile 20 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i20 (.a({1'b0, pp162, pp149, pp136}), .b({1'b0, 1'b0, pp161, pp148}), .cin(1'b0), .s(ts20), .cout(tc20));
  logic [3:0] ts21; logic tc21;
  // tile 21 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i21 (.a({pp107, pp106, pp105, pp104}), .b({pp119, pp118, pp117, 1'b0}), .cin(1'b0), .s(ts21), .cout(tc21));
  logic [3:0] ts22; logic tc22;
  // tile 22 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i22 (.a({pp147, pp134, pp121, pp108}), .b({pp159, pp146, pp133, pp120}), .cin(1'b0), .s(ts22), .cout(tc22));
  logic [3:0] ts23; logic tc23;
  // tile 23 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i23 (.a({pp131, pp130, 1'b0, 1'b0}), .b({pp143, 1'b0, 1'b0, 1'b0}), .cin(1'b0), .s(ts23), .cout(tc23));
  logic [3:0] ts24; logic tc24;
  // tile 24 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i24 (.a({1'b0, pp158, pp145, pp132}), .b({1'b0, 1'b0, pp157, pp144}), .cin(1'b0), .s(ts24), .cout(tc24));
  logic [3:0] ts25; logic tc25;
  // tile 25 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i25 (.a({ts1[3], ts1[2], ts1[1], ts1[0]}), .b({ts7[3], ts7[2], ts7[1], ts7[0]}), .cin(1'b0), .s(ts25), .cout(tc25));
  logic [3:0] ts26; logic tc26;
  // tile 26 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i26 (.a({ts2[3], ts2[2], ts2[1], ts2[0]}), .b({ts8[3], ts8[2], ts8[1], ts8[0]}), .cin(1'b0), .s(ts26), .cout(tc26));
  logic [3:0] ts27; logic tc27;
  // tile 27 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i27 (.a({ts3[3], ts3[2], ts3[1], ts3[0]}), .b({ts9[3], ts9[2], ts9[1], ts9[0]}), .cin(1'b0), .s(ts27), .cout(tc27));
  logic [3:0] ts28; logic tc28;
  // tile 28 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i28 (.a({ts4[3], ts4[2], ts4[1], ts4[0]}), .b({ts10[3], ts10[2], ts10[1], ts10[0]}), .cin(1'b0), .s(ts28), .cout(tc28));
  logic [3:0] ts29; logic tc29;
  // tile 29 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i29 (.a({ts5[3], ts5[2], ts5[1], ts5[0]}), .b({ts11[3], ts11[2], ts11[1], ts11[0]}), .cin(1'b0), .s(ts29), .cout(tc29));
  logic [3:0] ts30; logic tc30;
  // tile 30 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i30 (.a({ts6[3], ts6[2], ts6[1], ts6[0]}), .b({ts12[3], ts12[2], ts12[1], ts12[0]}), .cin(1'b0), .s(ts30), .cout(tc30));
  logic [3:0] ts31; logic tc31;
  // tile 31 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i31 (.a({ts13[3], ts13[2], ts13[1], ts13[0]}), .b({ts17[3], ts17[2], ts17[1], ts17[0]}), .cin(1'b0), .s(ts31), .cout(tc31));
  logic [3:0] ts32; logic tc32;
  // tile 32 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i32 (.a({ts14[3], ts14[2], ts14[1], ts14[0]}), .b({ts18[3], ts18[2], ts18[1], ts18[0]}), .cin(1'b0), .s(ts32), .cout(tc32));
  logic [3:0] ts33; logic tc33;
  // tile 33 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i33 (.a({ts15[3], ts15[2], ts15[1], ts15[0]}), .b({ts19[3], ts19[2], ts19[1], ts19[0]}), .cin(1'b0), .s(ts33), .cout(tc33));
  logic [3:0] ts34; logic tc34;
  // tile 34 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i34 (.a({ts16[3], ts16[2], ts16[1], ts16[0]}), .b({ts20[3], ts20[2], ts20[1], ts20[0]}), .cin(1'b0), .s(ts34), .cout(tc34));
  logic [3:0] ts35; logic tc35;
  // tile 35 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i35 (.a({ts21[3], ts21[2], ts21[1], ts21[0]}), .b({ts23[3], ts23[2], ts23[1], ts23[0]}), .cin(1'b0), .s(ts35), .cout(tc35));
  logic [3:0] ts36; logic tc36;
  // tile 36 (ripple_carry, 4 bits) at level 1
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i36 (.a({ts22[3], ts22[2], ts22[1], ts22[0]}), .b({ts24[3], ts24[2], ts24[1], ts24[0]}), .cin(1'b0), .s(ts36), .cout(tc36));
  logic [3:0] ts37; logic tc37;
  // tile 37 (ripple_carry, 4 bits) at level 2
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i37 (.a({ts26[3], ts26[2], ts26[1], ts26[0]}), .b({ts31[3], ts31[2], ts31[1], ts31[0]}), .cin(1'b0), .s(ts37), .cout(tc37));
  logic [3:0] ts38; logic tc38;
  // tile 38 (ripple_carry, 4 bits) at level 2
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i38 (.a({ts27[3], ts27[2], ts27[1], ts27[0]}), .b({ts32[3], ts32[2], ts32[1], ts32[0]}), .cin(1'b0), .s(ts38), .cout(tc38));
  logic [3:0] ts39; logic tc39;
  // tile 39 (ripple_carry, 4 bits) at level 2
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i39 (.a({ts28[3], ts28[2], ts28[1], ts28[0]}), .b({ts33[3], ts33[2], ts33[1], ts33[0]}), .cin(1'b0), .s(ts39), .cout(tc39));
  logic [3:0] ts40; logic tc40;
  // tile 40 (ripple_carry, 4 bits) at level 2
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i40 (.a({ts29[3], ts29[2], ts29[1], ts29[0]}), .b({ts34[3], ts34[2], ts34[1], ts34[0]}), .cin(1'b0), .s(ts40), .cout(tc40));
  logic [3:0] ts41; logic tc41;
  // tile 41 (ripple_carry, 4 bits) at level 2
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i41 (.a({ts30[3], ts30[2], ts30[1], ts30[0]}), .b({1'b0, 1'b0, 1'b0, pp164}), .cin(1'b0), .s(ts41), .cout(tc41));
  logic [3:0] ts42; logic tc42;
  // tile 42 (ripple_carry, 4 bits) at level 2
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(1)) u_i42 (.a({ts36[3], ts36[2], ts36[1], ts36[0]}), .b({1'b0, 1'b0, 1'b1, pp156}), .cin(1'b0), .s(ts42), .cout(tc42));
  assign pp0 = (a[0] & b[0]);
  assign pp1 = (a[0] & b[1]);
  assign pp2 = (a[0] & b[2]);
  assign pp3 = (a[0] & b[3]);
  assign pp4 = (a[0] & b[4]);
  assign pp5 = (a[0] & b[5]);
  assign pp6 = (a[0] & b[6]);
  assign pp7 = (a[0] & b[7]);
  assign pp8 = (a[0] & b[8]);
  assign pp9 = (a[0] & b[9]);
  assign pp10 = (a[0] & b[10]);
  assign pp11 = (a[0] & b[11]);
  assign pp12 = ~(a[0] & b[12]);
  assign pp13 = (a[1] & b[0]);
  assign pp14 = (a[1] & b[1]);
  assign pp15 = (a[1] & b[2]);
  assign pp16 = (a[1] & b[3]);
  assign pp17 = (a[1] & b[4]);
  assign pp18 = (a[1] & b[5]);
  assign pp19 = (a[1] & b[6]);
  assign pp20 = (a[1] & b[7]);
  assign pp21 = (a[1] & b[8]);
  assign pp22 = (a[1] & b[9]);
  assign pp23 = (a[1] & b[10]);
  assign pp24 = (a[1] & b[11]);
  assign pp25 = ~(a[1] & b[12]);
  assign pp26 = (a[2] & b[0]);
  assign pp27 = (a[2] & b[1]);
  assign pp28 = (a[2] & b[2]);
  assign pp29 = (a[2] & b[3]);
  assign pp30 = (a[2] & b[4]);
  assign pp31 = (a[2] & b[5]);
  assign pp32 = (a[2] & b[6]);
  assign pp33 = (a[2] & b[7]);
  assign pp34 = (a[2] & b[8]);
  assign pp35 = (a[2] & b[9]);
  assign pp36 = (a[2] & b[10]);
  assign pp37 = (a[2] & b[11]);
  assign pp38 = ~(a[2] & b[12]);
  assign pp39 = (a[3] & b[0]);
  assign pp40 = (a[3] & b[1]);
  assign pp41 = (a[3] & b[2]);
  assign pp42 = (a[3] & b[3]);
  assign pp43 = (a[3] & b[4]);
  assign pp44 = (a[3] & b[5]);
  assign pp45 = (a[3] & b[6]);
  assign pp46 = (a[3] & b[7]);
  assign pp47 = (a[3] & b[8]);
  assign pp48 = (a[3] & b[9]);
  assign pp49 = (a[3] & b[10]);
  assign pp50 = (a[3] & b[11]);
  assign pp51 = ~(a[3] & b[12]);
  assign pp52 = (a[4] & b[0]);
  assign pp53 = (a[4] & b[1]);
  assign pp54 = (a[4] & b[2]);
  assign pp55 = (a[4] & b[3]);
  assign pp56 = (a[4] & b[4]);
  assign pp57 = (a[4] & b[5]);
  assign pp58 = (a[4] & b[6]);
  assign pp59 = (a[4] & b[7]);
  assign pp60 = (a[4] & b[8]);
  assign pp61 = (a[4] & b[9]);
  assign pp62 = (a[4] & b[10]);
  assign pp63 = (a[4] & b[11]);
  assign pp64 = ~(a[4] & b[12]);
  assign pp65 = (a[5] & b[0]);
  assign pp66 = (a[5] & b[1]);
  assign pp67 = (a[5] & b[2]);
  assign pp68 = (a[5] & b[3]);
  assign pp69 = (a[5] & b[4]);
  assign pp70 = (a[5] & b[5]);
  assign pp71 = (a[5] & b[6]);
  assign pp72 = (a[5] & b[7]);
  assign pp73 = (a[5] & b[8]);
  assign pp74 = (a[5] & b[9]);
  assign pp75 = (a[5] & b[10]);
  assign pp76 = (a[5] & b[11]);
  assign pp77 = ~(a[5] & b[12]);
  assign pp78 = (a[6] & b[0]);
  assign pp79 = (a[6] & b[1]);
  assign pp80 = (a[6] & b[2]);
  assign pp81 = (a[6] & b[3]);
  assign pp82 = (a[6] & b[4]);
  assign pp83 = (a[6] & b[5]);
  assign pp84 = (a[6] & b[6]);
  assign pp85 = (a[6] & b[7]);
  assign pp86 = (a[6] & b[8]);
  assign pp87 = (a[6] & b[9]);
  assign pp88 = (a[6] & b[10]);
  assign pp89 = (a[6] & b[11]);
  assign pp90 = ~(a[6] & b[12]);
  assign pp91 = (a[7] & b[0]);
  assign pp92 = (a[7] & b[1]);
  assign pp93 = (a[7] & b[2]);
  assign pp94 = (a[7] & b[3]);
  assign pp95 = (a[7] & b[4]);
  assign pp96 = (a[7] & b[5]);
  assign pp97 = (a[7] & b[6]);
  assign pp98 = (a[7] & b[7]);
  assign pp99 = (a[7] & b[8]);
  assign pp100 = (a[7] & b[9]);
  assign pp101 = (a[7] & b[10]);
  assign pp102 = (a[7] & b[11]);
  assign pp103 = ~(a[7] & b[12]);
  assign pp104 = (a[8] & b[0]);
  assign pp105 = (a[8] & b[1]);
  assign pp106 = (a[8] & b[2]);
  assign pp107 = (a[8] & b[3]);
  assign pp108 = (a[8] & b[4]);
  assign pp109 = (a[8] & b[5]);
  assign pp110 = (a[8] & b[6]);
  assign pp111 = (a[8] & b[7]);
  assign pp112 = (a[8] & b[8]);
  assign pp113 = (a[8] & b[9]);
  assign pp114 = (a[8] & b[10]);
  assign pp115 = (a[8] & b[11]);
  assign pp116 = ~(a[8] & b[12]);
  assign pp117 = (a[9] & b[0]);
  assign pp118 = (a[9] & b[1]);
  assign pp119 = (a[9] & b[2]);
  assign pp120 = (a[9] & b[3]);
  assign pp121 = (a[9] & b[4]);
  assign pp122 = (a[9] & b[5]);
  assign pp123 = (a[9] & b[6]);
  assign pp124 = (a[9] & b[7]);
  assign pp125 = (a[9] & b[8]);
  assign pp126 = (a[9] & b[9]);
  assign pp127 = (a[9] & b[10]);
  assign pp128 = (a[9] & b[11]);
  assign pp129 = ~(a[9] & b[12]);
  assign pp130 = (a[10] & b[0]);
  assign pp131 = (a[10] & b[1]);
  assign pp132 = (a[10] & b[2]);
  assign pp133 = (a[10] & b[3]);
  assign pp134 = (a[10] & b[4]);
  assign pp135 = (a[10] & b[5]);
  assign pp136 = (a[10] & b[6]);
  assign pp137 = (a[10] & b[7]);
  assign pp138 = (a[10] & b[8]);
  assign pp139 = (a[10] & b[9]);
  assign pp140 = (a[10] & b[10]);
  assign pp141 = (a[10] & b[11]);
  assign pp142 = ~(a[10] & b[12]);
  assign pp143 = (a[11] & b[0]);
  assign pp144 = (a[11] & b[1]);
  assign pp145 = (a[11] & b[2]);
  assign pp146 = (a[11] & b[3]);
  assign pp147 = (a[11] & b[4]);
  assign pp148 = (a[11] & b[5]);
  assign pp149 = (a[11] & b[6]);
  assign pp150 = (a[11] & b[7]);
  assign pp151 = (a[11] & b[8]);
  assign pp152 = (a[11] & b[9]);
  assign pp153 = (a[11] & b[10]);
  assign pp154 = (a[11] & b[11]);
  assign pp155 = ~(a[11] & b[12]);
  assign pp156 = ~(a[12] & b[0]);
  assign pp157 = ~(a[12] & b[1]);
  assign pp158 = ~(a[12] & b[2]);
  assign pp159 = ~(a[12] & b[3]);
  assign pp160 = ~(a[12] & b[4]);
  assign pp161 = ~(a[12] & b[5]);
  assign pp162 = ~(a[12] & b[6]);
  assign pp163 = ~(a[12] & b[7]);
  assign pp164 = ~(a[12] & b[8]);
  assign pp165 = ~(a[12] & b[9]);
  assign pp166 = ~(a[12] & b[10]);
  assign pp167 = ~(a[12] & b[11]);
  assign pp168 = (a[12] & b[12]);
  assign t169 = ts39[0] ^ ts42[0] ^ tc3;
  assign t170 = (ts39[0] & ts42[0]) | (ts39[0] & tc3) | (ts42[0] & tc3);
  assign t171 = t169 ^ tc9 ^ 1'b0;
  assign t172 = (t169 & tc9) | (t169 & 1'b0) | (tc9 & 1'b0);
  assign t173 = ts40[0] ^ pp160 ^ tc4;
  assign t174 = (ts40[0] & pp160) | (ts40[0] & tc4) | (pp160 & tc4);
  assign t175 = t173 ^ tc10 ^ 1'b0;
  assign t176 = (t173 & tc10) | (t173 & 1'b0) | (tc10 & 1'b0);
  assign t177 = tc15 ^ tc19 ^ tc22;
  assign t178 = (tc15 & tc19) | (tc15 & tc22) | (tc19 & tc22);
  assign t179 = t177 ^ tc24 ^ 1'b0;
  assign t180 = (t177 & tc24) | (t177 & 1'b0) | (tc24 & 1'b0);
  assign t181 = ts38[0] ^ ts35[0] ^ tc2;
  assign t182 = (ts38[0] & ts35[0]) | (ts38[0] & tc2) | (ts35[0] & tc2);
  assign t183 = t181 ^ tc8 ^ 1'b0;
  assign t184 = (t181 & tc8) | (t181 & 1'b0) | (tc8 & 1'b0);
  assign t185 = tc14 ^ tc18 ^ tc21;
  assign t186 = (tc14 & tc18) | (tc14 & tc21) | (tc18 & tc21);
  assign t187 = t185 ^ tc23 ^ 1'b0;
  assign t188 = (t185 & tc23) | (t185 & 1'b0) | (tc23 & 1'b0);
  assign t189 = tc28 ^ tc33 ^ tc36;
  assign t190 = (tc28 & tc33) | (tc28 & tc36) | (tc33 & tc36);
  assign t191 = t189 ^ tc39 ^ 1'b0;
  assign t192 = (t189 & tc39) | (t189 & 1'b0) | (tc39 & 1'b0);
  assign t193 = ts40[1] ^ t176 ^ t174;
  assign t194 = (ts40[1] & t176) | (ts40[1] & t174) | (t176 & t174);
  assign t195 = t193 ^ t180 ^ 1'b0;
  assign t196 = (t193 & t180) | (t193 & 1'b0) | (t180 & 1'b0);
  assign t197 = ts41[0] ^ tc5 ^ tc11;
  assign t198 = (ts41[0] & tc5) | (ts41[0] & tc11) | (tc5 & tc11);
  assign t199 = t197 ^ tc16 ^ 1'b0;
  assign t200 = (t197 & tc16) | (t197 & 1'b0) | (tc16 & 1'b0);
  assign t201 = tc13 ^ tc17 ^ tc26;
  assign t202 = (tc13 & tc17) | (tc13 & tc26) | (tc17 & tc26);
  assign t203 = t201 ^ tc31 ^ 1'b0;
  assign t204 = (t201 & tc31) | (t201 & 1'b0) | (tc31 & 1'b0);
  assign t205 = ts38[1] ^ ts35[1] ^ t184;
  assign t206 = (ts38[1] & ts35[1]) | (ts38[1] & t184) | (ts35[1] & t184);
  assign t207 = t205 ^ t182 ^ 1'b0;
  assign t208 = (t205 & t182) | (t205 & 1'b0) | (t182 & 1'b0);
  assign t209 = tc27 ^ tc32 ^ tc35;
  assign t210 = (tc27 & tc32) | (tc27 & tc35) | (tc32 & tc35);
  assign t211 = t209 ^ tc38 ^ 1'b0;
  assign t212 = (t209 & tc38) | (t209 & 1'b0) | (tc38 & 1'b0);
  assign t213 = ts39[1] ^ ts42[1] ^ t172;
  assign t214 = (ts39[1] & ts42[1]) | (ts39[1] & t172) | (ts42[1] & t172);
  assign t215 = t213 ^ t170 ^ 1'b0;
  assign t216 = (t213 & t170) | (t213 & 1'b0) | (t170 & 1'b0);
  assign t217 = t188 ^ t186 ^ t212;
  assign t218 = (t188 & t186) | (t188 & t212) | (t186 & t212);
  assign t219 = t217 ^ t210 ^ 1'b0;
  assign t220 = (t217 & t210) | (t217 & 1'b0) | (t210 & 1'b0);
  assign t221 = ts39[2] ^ ts42[2] ^ t216;
  assign t222 = (ts39[2] & ts42[2]) | (ts39[2] & t216) | (ts42[2] & t216);
  assign t223 = t221 ^ t214 ^ 1'b0;
  assign t224 = (t221 & t214) | (t221 & 1'b0) | (t214 & 1'b0);
  assign t225 = tc20 ^ tc29 ^ tc34;
  assign t226 = (tc20 & tc29) | (tc20 & tc34) | (tc29 & tc34);
  assign t227 = t225 ^ tc40 ^ 1'b0;
  assign t228 = (t225 & tc40) | (t225 & 1'b0) | (tc40 & 1'b0);
  assign t229 = ts41[1] ^ t200 ^ t198;
  assign t230 = (ts41[1] & t200) | (ts41[1] & t198) | (t200 & t198);
  assign t231 = t229 ^ t228 ^ 1'b0;
  assign t232 = (t229 & t228) | (t229 & 1'b0) | (t228 & 1'b0);
  assign t233 = pp168 ^ tc6 ^ tc12;
  assign t234 = (pp168 & tc6) | (pp168 & tc12) | (tc6 & tc12);
  assign t235 = t233 ^ tc30 ^ 1'b0;
  assign t236 = (t233 & tc30) | (t233 & 1'b0) | (tc30 & 1'b0);
  assign t237 = ts37[0] ^ tc1 ^ tc7;
  assign t238 = (ts37[0] & tc1) | (ts37[0] & tc7) | (tc1 & tc7);
  assign t239 = t237 ^ tc25 ^ 1'b0;
  assign t240 = (t237 & tc25) | (t237 & 1'b0) | (tc25 & 1'b0);
  assign t241 = ts38[2] ^ ts35[2] ^ t208;
  assign t242 = (ts38[2] & ts35[2]) | (ts38[2] & t208) | (ts35[2] & t208);
  assign t243 = t241 ^ t206 ^ 1'b0;
  assign t244 = (t241 & t206) | (t241 & 1'b0) | (t206 & 1'b0);
  assign t245 = ts38[3] ^ ts35[3] ^ t244;
  assign t246 = (ts38[3] & ts35[3]) | (ts38[3] & t244) | (ts35[3] & t244);
  assign t247 = t245 ^ t242 ^ 1'b0;
  assign t248 = (t245 & t242) | (t245 & 1'b0) | (t242 & 1'b0);
  assign t249 = t171 ^ t187 ^ t211;
  assign t250 = (t171 & t187) | (t171 & t211) | (t187 & t211);
  assign t251 = t249 ^ t248 ^ 1'b0;
  assign t252 = (t249 & t248) | (t249 & 1'b0) | (t248 & 1'b0);
  assign t253 = t215 ^ t219 ^ t252;
  assign t254 = (t215 & t219) | (t215 & t252) | (t219 & t252);
  assign t255 = t253 ^ t250 ^ 1'b0;
  assign t256 = (t253 & t250) | (t253 & 1'b0) | (t250 & 1'b0);
  assign t257 = t220 ^ t218 ^ t223;
  assign t258 = (t220 & t218) | (t220 & t223) | (t218 & t223);
  assign t259 = t257 ^ t256 ^ 1'b0;
  assign t260 = (t257 & t256) | (t257 & 1'b0) | (t256 & 1'b0);
  assign t261 = ts39[3] ^ ts42[3] ^ t224;
  assign t262 = (ts39[3] & ts42[3]) | (ts39[3] & t224) | (ts42[3] & t224);
  assign t263 = t261 ^ t222 ^ 1'b0;
  assign t264 = (t261 & t222) | (t261 & 1'b0) | (t222 & 1'b0);
  assign t265 = tc42 ^ t175 ^ t179;
  assign t266 = (tc42 & t175) | (tc42 & t179) | (t175 & t179);
  assign t267 = t265 ^ t191 ^ 1'b0;
  assign t268 = (t265 & t191) | (t265 & 1'b0) | (t191 & 1'b0);
  assign t269 = t178 ^ t192 ^ t190;
  assign t270 = (t178 & t192) | (t178 & t190) | (t192 & t190);
  assign t271 = t269 ^ t195 ^ 1'b0;
  assign t272 = (t269 & t195) | (t269 & 1'b0) | (t195 & 1'b0);
  assign t273 = ts40[2] ^ t196 ^ t194;
  assign t274 = (ts40[2] & t196) | (ts40[2] & t194) | (t196 & t194);
  assign t275 = t273 ^ t272 ^ 1'b0;
  assign t276 = (t273 & t272) | (t273 & 1'b0) | (t272 & 1'b0);
  assign t277 = ts37[1] ^ t240;
  assign t278 = ts37[1] & t240;
  assign t279 = tc37 ^ t183;
  assign t280 = tc37 & t183;
  assign t281 = t204 ^ t202 ^ t207;
  assign t282 = (t204 & t202) | (t204 & t207) | (t202 & t207);
  assign t283 = t281 ^ t280 ^ 1'b0;
  assign t284 = (t281 & t280) | (t281 & 1'b0) | (t280 & 1'b0);
  assign t285 = t243 ^ t284;
  assign t286 = t243 & t284;
  assign t287 = t260 ^ t258;
  assign t288 = t260 & t258;
  assign t289 = t264 ^ t262 ^ t267;
  assign t290 = (t264 & t262) | (t264 & t267) | (t262 & t267);
  assign t291 = t289 ^ t288 ^ 1'b0;
  assign t292 = (t289 & t288) | (t289 & 1'b0) | (t288 & 1'b0);
  assign t293 = t268 ^ t266 ^ t271;
  assign t294 = (t268 & t266) | (t268 & t271) | (t266 & t271);
  assign t295 = t293 ^ t292 ^ 1'b0;
  assign t296 = (t293 & t292) | (t293 & 1'b0) | (t292 & 1'b0);
  assign t297 = t270 ^ t275 ^ t296;
  assign t298 = (t270 & t275) | (t270 & t296) | (t275 & t296);
  assign t299 = t297 ^ t294 ^ 1'b0;
  assign t300 = (t297 & t294) | (t297 & 1'b0) | (t294 & 1'b0);
  assign t301 = ts40[3] ^ t276 ^ t274;
  assign t302 = (ts40[3] & t276) | (ts40[3] & t274) | (t276 & t274);
  assign t303 = t301 ^ t300 ^ 1'b0;
  assign t304 = (t301 & t300) | (t301 & 1'b0) | (t300 & 1'b0);
  assign t305 = t199 ^ t227 ^ t304;
  assign t306 = (t199 & t227) | (t199 & t304) | (t227 & t304);
  assign t307 = t305 ^ t302 ^ 1'b0;
  assign t308 = (t305 & t302) | (t305 & 1'b0) | (t302 & 1'b0);
  assign t309 = t226 ^ t231 ^ t308;
  assign t310 = (t226 & t231) | (t226 & t308) | (t231 & t308);
  assign t311 = t309 ^ t306 ^ 1'b0;
  assign t312 = (t309 & t306) | (t309 & 1'b0) | (t306 & 1'b0);
  assign t313 = ts41[2] ^ t232 ^ t230;
  assign t314 = (ts41[2] & t232) | (ts41[2] & t230) | (t232 & t230);
  assign t315 = t313 ^ t312 ^ 1'b0;
  assign t316 = (t313 & t312) | (t313 & 1'b0) | (t312 & 1'b0);
  assign t317 = ts41[3] ^ t316;
  assign t318 = ts41[3] & t316;
  assign t319 = tc41 ^ t235;
  assign t320 = tc41 & t235;
  assign t321 = 1'b1 ^ t236 ^ t234;
  assign t322 = (1'b1 & t236) | (1'b1 & t234) | (t236 & t234);
  assign t323 = t321 ^ t320 ^ 1'b0;
  assign t324 = (t321 & t320) | (t321 & 1'b0) | (t320 & 1'b0);
  logic [25:0] row_s, row_c;
  assign row_s = {t323, t318, t314, t310, t311, t307, t298, t299, t290, t291, t263, t254, t255, t246, t247, t282, t283, t203, ts37[3], ts37[2], t238, t239, ts25[3], ts25[2], ts25[1], ts25[0]};
  assign row_c = {1'b0, t319, t317, t315, 1'b0, 1'b0, t303, 1'b0, t295, 1'b0, t287, t259, 1'b0, t251, t286, t285, 1'b0, t279, 1'b0, t278, t277, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
  fam_adder_carry_increment_pc7c2b4652c63065e1c5fbdbc5f21af0ee45e5500e5eeeb5dfc9c34da33e314c3_w26 u_cpa (.a(row_s), .b(row_c), .cin(1'b0), .s(p), .cout());
endmodule

// redundant_binary_multiplier: Booth radix-2 rows as signed digits in the plus_minus_pair code (the pair (p, n) of the positive and negative bits), a 5-level tree of carry-free redundant adders, converted by carry_select
module fam_mul_redundant_binary_multiplier_w16_u_pe58f448b (input logic [15:0] a, input logic [15:0] b, output logic [31:0] p);
  logic sel0, sel1, pp2, pp3, pp4, pp5, pp6, pp7, pp8, pp9, pp10, pp11, pp12, pp13, pp14, pp15, pp16, pp17, pp18, pp19, pp20, pp21, pp22, pp23, pp24, pp25, pp26, pp27, pp28, pp29, pp30, pp31, pp32, pp33, pp34, pp35, pp36, pp37, pp38, pp39, pp40, pp41, pp42, pp43, pp44, pp45, pp46, pp47, pp48, pp49, pp50, pp51, pp52, pp53, pp54, pp55, pp56, pp57, pp58, pp59, pp60, pp61, pp62, pp63, pp64, pp65, pp66, pp67, pp68, pp69, sel70, sel71, pp72, pp73, pp74, pp75, pp76, pp77, pp78, pp79, pp80, pp81, pp82, pp83, pp84, pp85, pp86, pp87, pp88, pp89, pp90, pp91, pp92, pp93, pp94, pp95, pp96, pp97, pp98, pp99, pp100, pp101, pp102, pp103, pp104, pp105, pp106, pp107, pp108, pp109, pp110, pp111, pp112, pp113, pp114, pp115, pp116, pp117, pp118, pp119, pp120, pp121, pp122, pp123, pp124, pp125, pp126, pp127, pp128, pp129, pp130, pp131, pp132, pp133, pp134, pp135, pp136, pp137, sel138, sel139, pp140, pp141, pp142, pp143, pp144, pp145, pp146, pp147, pp148, pp149, pp150, pp151, pp152, pp153, pp154, pp155, pp156, pp157, pp158, pp159, pp160, pp161, pp162, pp163, pp164, pp165, pp166, pp167, pp168, pp169, pp170, pp171, pp172, pp173, pp174, pp175, pp176, pp177, pp178, pp179, pp180, pp181, pp182, pp183, pp184, pp185, pp186, pp187, pp188, pp189, pp190, pp191, pp192, pp193, pp194, pp195, pp196, pp197, pp198, pp199, pp200, pp201, pp202, pp203, sel204, sel205, pp206, pp207, pp208, pp209, pp210, pp211, pp212, pp213, pp214, pp215, pp216, pp217, pp218, pp219, pp220, pp221, pp222, pp223, pp224, pp225, pp226, pp227, pp228, pp229, pp230, pp231, pp232, pp233, pp234, pp235, pp236, pp237, pp238, pp239, pp240, pp241, pp242, pp243, pp244, pp245, pp246, pp247, pp248, pp249, pp250, pp251, pp252, pp253, pp254, pp255, pp256, pp257, pp258, pp259, pp260, pp261, pp262, pp263, pp264, pp265, pp266, pp267, sel268, sel269, pp270, pp271, pp272, pp273, pp274, pp275, pp276, pp277, pp278, pp279, pp280, pp281, pp282, pp283, pp284, pp285, pp286, pp287, pp288, pp289, pp290, pp291, pp292, pp293, pp294, pp295, pp296, pp297, pp298, pp299, pp300, pp301, pp302, pp303, pp304, pp305, pp306, pp307, pp308, pp309, pp310, pp311, pp312, pp313, pp314, pp315, pp316, pp317, pp318, pp319, pp320, pp321, pp322, pp323, pp324, pp325, pp326, pp327, pp328, pp329, sel330, sel331, pp332, pp333, pp334, pp335, pp336, pp337, pp338, pp339, pp340, pp341, pp342, pp343, pp344, pp345, pp346, pp347, pp348, pp349, pp350, pp351, pp352, pp353, pp354, pp355, pp356, pp357, pp358, pp359, pp360, pp361, pp362, pp363, pp364, pp365, pp366, pp367, pp368, pp369, pp370, pp371, pp372, pp373, pp374, pp375, pp376, pp377, pp378, pp379, pp380, pp381, pp382, pp383, pp384, pp385, pp386, pp387, pp388, pp389, sel390, sel391, pp392, pp393, pp394, pp395, pp396, pp397, pp398, pp399, pp400, pp401, pp402, pp403, pp404, pp405, pp406, pp407, pp408, pp409, pp410, pp411, pp412, pp413, pp414, pp415, pp416, pp417, pp418, pp419, pp420, pp421, pp422, pp423, pp424, pp425, pp426, pp427, pp428, pp429, pp430, pp431, pp432, pp433, pp434, pp435, pp436, pp437, pp438, pp439, pp440, pp441, pp442, pp443, pp444, pp445, pp446, pp447, sel448, sel449, pp450, pp451, pp452, pp453, pp454, pp455, pp456, pp457, pp458, pp459, pp460, pp461, pp462, pp463, pp464, pp465, pp466, pp467, pp468, pp469, pp470, pp471, pp472, pp473, pp474, pp475, pp476, pp477, pp478, pp479, pp480, pp481, pp482, pp483, pp484, pp485, pp486, pp487, pp488, pp489, pp490, pp491, pp492, pp493, pp494, pp495, pp496, pp497, pp498, pp499, pp500, pp501, pp502, pp503, sel504, sel505, pp506, pp507, pp508, pp509, pp510, pp511, pp512, pp513, pp514, pp515, pp516, pp517, pp518, pp519, pp520, pp521, pp522, pp523, pp524, pp525, pp526, pp527, pp528, pp529, pp530, pp531, pp532, pp533, pp534, pp535, pp536, pp537, pp538, pp539, pp540, pp541, pp542, pp543, pp544, pp545, pp546, pp547, pp548, pp549, pp550, pp551, pp552, pp553, pp554, pp555, pp556, pp557, sel558, sel559, pp560, pp561, pp562, pp563, pp564, pp565, pp566, pp567, pp568, pp569, pp570, pp571, pp572, pp573, pp574, pp575, pp576, pp577, pp578, pp579, pp580, pp581, pp582, pp583, pp584, pp585, pp586, pp587, pp588, pp589, pp590, pp591, pp592, pp593, pp594, pp595, pp596, pp597, pp598, pp599, pp600, pp601, pp602, pp603, pp604, pp605, pp606, pp607, pp608, pp609, sel610, sel611, pp612, pp613, pp614, pp615, pp616, pp617, pp618, pp619, pp620, pp621, pp622, pp623, pp624, pp625, pp626, pp627, pp628, pp629, pp630, pp631, pp632, pp633, pp634, pp635, pp636, pp637, pp638, pp639, pp640, pp641, pp642, pp643, pp644, pp645, pp646, pp647, pp648, pp649, pp650, pp651, pp652, pp653, pp654, pp655, pp656, pp657, pp658, pp659, sel660, sel661, pp662, pp663, pp664, pp665, pp666, pp667, pp668, pp669, pp670, pp671, pp672, pp673, pp674, pp675, pp676, pp677, pp678, pp679, pp680, pp681, pp682, pp683, pp684, pp685, pp686, pp687, pp688, pp689, pp690, pp691, pp692, pp693, pp694, pp695, pp696, pp697, pp698, pp699, pp700, pp701, pp702, pp703, pp704, pp705, pp706, pp707, sel708, sel709, pp710, pp711, pp712, pp713, pp714, pp715, pp716, pp717, pp718, pp719, pp720, pp721, pp722, pp723, pp724, pp725, pp726, pp727, pp728, pp729, pp730, pp731, pp732, pp733, pp734, pp735, pp736, pp737, pp738, pp739, pp740, pp741, pp742, pp743, pp744, pp745, pp746, pp747, pp748, pp749, pp750, pp751, pp752, pp753, sel754, sel755, pp756, pp757, pp758, pp759, pp760, pp761, pp762, pp763, pp764, pp765, pp766, pp767, pp768, pp769, pp770, pp771, pp772, pp773, pp774, pp775, pp776, pp777, pp778, pp779, pp780, pp781, pp782, pp783, pp784, pp785, pp786, pp787, pp788, pp789, pp790, pp791, pp792, pp793, pp794, pp795, pp796, pp797, sel798, sel799, pp800, pp801, pp802, pp803, pp804, pp805, pp806, pp807, pp808, pp809, pp810, pp811, pp812, pp813, pp814, pp815, pp816, pp817, pp818, pp819, pp820, pp821, pp822, pp823, pp824, pp825, pp826, pp827, pp828, pp829, pp830, pp831, pp832, pp833, pp834, pp835, pp836, pp837, pp838, pp839, sel840, sel841, pp842, pp843, pp844, pp845, pp846, pp847, pp848, pp849, pp850, pp851, pp852, pp853, pp854, pp855, pp856, pp857, pp858, pp859, pp860, pp861, pp862, pp863, pp864, pp865, pp866, pp867, pp868, pp869, pp870, pp871, pp872, pp873, pp874, pp875, pp876, pp877, pp878, pp879, sel880, sel881, pp882, pp883, pp884, pp885, pp886, pp887, pp888, pp889, pp890, pp891, pp892, pp893, pp894, pp895, pp896, pp897, pp898, pp899, pp900, pp901, pp902, pp903, pp904, pp905, pp906, pp907, pp908, pp909, pp910, pp911, pp912, pp913, pp914, pp915, pp916, pp917, rb918, rb919, rb920, rb921, rb922, rb923, rb924, rb925, rb926, rb927, rb928, rb929, rb930, rb931, rb932, rb933, rb934, rb935, rb936, rb937, rb938, rb939, rb940, rb941, rb942, rb943, rb944, rb945, rb946, rb947, rb948, rb949, rb950, rb951, rb952, rb953, rb954, rb955, rb956, rb957, rb958, rb959, rb960, rb961, rb962, rb963, rb964, rb965, rb966, rb967, rb968, rb969, rb970, rb971, rb972, rb973, rb974, rb975, rb976, rb977, rb978, rb979, rb980, rb981, rb982, rb983, rb984, rb985, rb986, rb987, rb988, rb989, rb990, rb991, rb992, rb993, rb994, rb995, rb996, rb997, rb998, rb999, rb1000, rb1001, rb1002, rb1003, rb1004, rb1005, rb1006, rb1007, rb1008, rb1009, rb1010, rb1011, rb1012, rb1013, rb1014, rb1015, rb1016, rb1017, rb1018, rb1019, rb1020, rb1021, rb1022, rb1023, rb1024, rb1025, rb1026, rb1027, rb1028, rb1029, rb1030, rb1031, rb1032, rb1033, rb1034, rb1035, rb1036, rb1037, rb1038, rb1039, rb1040, rb1041, rb1042, rb1043, rb1044, rb1045, rb1046, rb1047, rb1048, rb1049, rb1050, rb1051, rb1052, rb1053, rb1054, rb1055, rb1056, rb1057, rb1058, rb1059, rb1060, rb1061, rb1062, rb1063, rb1064, rb1065, rb1066, rb1067, rb1068, rb1069, rb1070, rb1071, rb1072, rb1073, rb1074, rb1075, rb1076, rb1077, rb1078, rb1079, rb1080, rb1081, rb1082, rb1083, rb1084, rb1085, rb1086, rb1087, rb1088, rb1089, rb1090, rb1091, rb1092, rb1093, rb1094, rb1095, rb1096, rb1097, rb1098, rb1099, rb1100, rb1101, rb1102, rb1103, rb1104, rb1105, rb1106, rb1107, rb1108, rb1109, rb1110, rb1111, rb1112, rb1113, rb1114, rb1115, rb1116, rb1117, rb1118, rb1119, rb1120, rb1121, rb1122, rb1123, rb1124, rb1125, rb1126, rb1127, rb1128, rb1129, rb1130, rb1131, rb1132, rb1133, rb1134, rb1135, rb1136, rb1137, rb1138, rb1139, rb1140, rb1141, rb1142, rb1143, rb1144, rb1145, rb1146, rb1147, rb1148, rb1149, rb1150, rb1151, rb1152, rb1153, rb1154, rb1155, rb1156, rb1157, rb1158, rb1159, rb1160, rb1161, rb1162, rb1163, rb1164, rb1165, rb1166, rb1167, rb1168, rb1169, rb1170, rb1171, rb1172, rb1173, rb1174, rb1175, rb1176, rb1177, rb1178, rb1179, rb1180, rb1181, rb1182, rb1183, rb1184, rb1185, rb1186, rb1187, rb1188, rb1189, rb1190, rb1191, rb1192, rb1193, rb1194, rb1195, rb1196, rb1197, rb1198, rb1199, rb1200, rb1201, rb1202, rb1203, rb1204, rb1205, rb1206, rb1207, rb1208, rb1209, rb1210, rb1211, rb1212, rb1213, rb1214, rb1215, rb1216, rb1217, rb1218, rb1219, rb1220, rb1221, rb1222, rb1223, rb1224, rb1225, rb1226, rb1227, rb1228, rb1229, rb1230, rb1231, rb1232, rb1233, rb1234, rb1235, rb1236, rb1237, rb1238, rb1239, rb1240, rb1241, rb1242, rb1243, rb1244, rb1245, rb1246, rb1247, rb1248, rb1249, rb1250, rb1251, rb1252, rb1253, rb1254, rb1255, rb1256, rb1257, rb1258, rb1259, rb1260, rb1261, rb1262, rb1263, rb1264, rb1265, rb1266, rb1267, rb1268, rb1269, rb1270, rb1271, rb1272, rb1273, rb1274, rb1275, rb1276, rb1277, rb1278, rb1279, rb1280, rb1281, rb1282, rb1283, rb1284, rb1285, rb1286, rb1287, rb1288, rb1289, rb1290, rb1291, rb1292, rb1293, rb1294, rb1295, rb1296, rb1297, rb1298, rb1299, rb1300, rb1301, rb1302, rb1303, rb1304, rb1305, rb1306, rb1307, rb1308, rb1309, rb1310, rb1311, rb1312, rb1313, rb1314, rb1315, rb1316, rb1317, rb1318, rb1319, rb1320, rb1321, rb1322, rb1323, rb1324, rb1325, rb1326, rb1327, rb1328, rb1329, rb1330, rb1331, rb1332, rb1333, rb1334, rb1335, rb1336, rb1337, rb1338, rb1339, rb1340, rb1341, rb1342, rb1343, rb1344, rb1345, rb1346, rb1347, rb1348, rb1349, rb1350, rb1351, rb1352, rb1353, rb1354, rb1355, rb1356, rb1357, rb1358, rb1359, rb1360, rb1361, rb1362, rb1363, rb1364, rb1365, rb1366, rb1367, rb1368, rb1369, rb1370, rb1371, rb1372, rb1373, rb1374, rb1375, rb1376, rb1377, rb1378, rb1379, rb1380, rb1381, rb1382, rb1383, rb1384, rb1385, rb1386, rb1387, rb1388, rb1389, rb1390, rb1391, rb1392, rb1393, rb1394, rb1395, rb1396, rb1397, rb1398, rb1399, rb1400, rb1401, rb1402, rb1403, rb1404, rb1405, rb1406, rb1407, rb1408, rb1409, rb1410, rb1411, rb1412, rb1413, rb1414, rb1415, rb1416, rb1417, rb1418, rb1419, rb1420, rb1421, rb1422, rb1423, rb1424, rb1425, rb1426, rb1427, rb1428, rb1429, rb1430, rb1431, rb1432, rb1433, rb1434, rb1435, rb1436, rb1437, rb1438, rb1439, rb1440, rb1441, rb1442, rb1443, rb1444, rb1445, rb1446, rb1447, rb1448, rb1449, rb1450, rb1451, rb1452, rb1453, rb1454, rb1455, rb1456, rb1457, rb1458, rb1459, rb1460, rb1461, rb1462, rb1463, rb1464, rb1465, rb1466, rb1467, rb1468, rb1469, rb1470, rb1471, rb1472, rb1473, rb1474, rb1475, rb1476, rb1477, rb1478, rb1479, rb1480, rb1481, rb1482, rb1483, rb1484, rb1485, rb1486, rb1487, rb1488, rb1489, rb1490, rb1491, rb1492, rb1493, rb1494, rb1495, rb1496, rb1497, rb1498, rb1499, rb1500, rb1501, rb1502, rb1503, rb1504, rb1505, rb1506, rb1507, rb1508, rb1509, rb1510, rb1511, rb1512, rb1513, rb1514, rb1515, rb1516, rb1517, rb1518, rb1519, rb1520, rb1521, rb1522, rb1523, rb1524, rb1525, rb1526, rb1527, rb1528, rb1529, rb1530, rb1531, rb1532, rb1533, rb1534, rb1535, rb1536, rb1537, rb1538, rb1539, rb1540, rb1541, rb1542, rb1543, rb1544, rb1545, rb1546, rb1547, rb1548, rb1549, rb1550, rb1551, rb1552, rb1553, rb1554, rb1555, rb1556, rb1557, rb1558, rb1559, rb1560, rb1561, rb1562, rb1563, rb1564, rb1565, rb1566, rb1567, rb1568, rb1569, rb1570, rb1571, rb1572, rb1573, rb1574, rb1575, rb1576, rb1577, rb1578, rb1579, rb1580, rb1581, rb1582, rb1583, rb1584, rb1585, rb1586, rb1587, rb1588, rb1589, rb1590, rb1591, rb1592, rb1593, rb1594, rb1595, rb1596, rb1597, rb1598, rb1599, rb1600, rb1601, rb1602, rb1603, rb1604, rb1605, rb1606, rb1607, rb1608, rb1609, rb1610, rb1611, rb1612, rb1613, rb1614, rb1615, rb1616, rb1617, rb1618, rb1619, rb1620, rb1621, rb1622, rb1623, rb1624, rb1625, rb1626, rb1627, rb1628, rb1629, rb1630, rb1631, rb1632, rb1633, rb1634, rb1635, rb1636, rb1637, rb1638, rb1639, rb1640, rb1641, rb1642, rb1643, rb1644, rb1645, rb1646, rb1647, rb1648, rb1649, rb1650, rb1651, rb1652, rb1653, rb1654, rb1655, rb1656, rb1657, rb1658, rb1659, rb1660, rb1661, rb1662, rb1663, rb1664, rb1665, rb1666, rb1667, rb1668, rb1669, rb1670, rb1671, rb1672, rb1673, rb1674, rb1675, rb1676, rb1677, rb1678, rb1679, rb1680, rb1681, rb1682, rb1683, rb1684, rb1685, rb1686, rb1687, rb1688, rb1689, rb1690, rb1691, rb1692, rb1693, rb1694, rb1695, rb1696, rb1697, rb1698, rb1699, rb1700, rb1701, rb1702, rb1703, rb1704, rb1705, rb1706, rb1707, rb1708, rb1709, rb1710, rb1711, rb1712, rb1713, rb1714, rb1715, rb1716, rb1717, rb1718, rb1719, rb1720, rb1721, rb1722, rb1723, rb1724, rb1725, rb1726, rb1727, rb1728, rb1729, rb1730, rb1731, rb1732, rb1733, rb1734, rb1735, rb1736, rb1737, rb1738, rb1739, rb1740, rb1741, rb1742, rb1743, rb1744, rb1745, rb1746, rb1747, rb1748, rb1749, rb1750, rb1751, rb1752, rb1753, rb1754, rb1755, rb1756, rb1757, rb1758, rb1759, rb1760, rb1761, rb1762, rb1763, rb1764, rb1765, rb1766, rb1767, rb1768, rb1769, rb1770, rb1771, rb1772, rb1773, rb1774, rb1775, rb1776, rb1777, rb1778, rb1779, rb1780, rb1781, rb1782, rb1783, rb1784, rb1785, rb1786, rb1787, rb1788, rb1789, rb1790, rb1791, rb1792, rb1793, rb1794, rb1795, rb1796, rb1797, rb1798, rb1799, rb1800, rb1801, rb1802, rb1803, rb1804, rb1805, rb1806, rb1807, rb1808, rb1809, rb1810, rb1811, rb1812, rb1813, rb1814, rb1815, rb1816, rb1817, rb1818, rb1819, rb1820, rb1821, rb1822, rb1823, rb1824, rb1825, rb1826, rb1827, rb1828, rb1829, rb1830, rb1831, rb1832, rb1833, rb1834, rb1835, rb1836, rb1837, rb1838, rb1839, rb1840, rb1841, rb1842, rb1843, rb1844, rb1845, rb1846, rb1847, rb1848, rb1849, rb1850, rb1851, rb1852, rb1853, rb1854, rb1855, rb1856, rb1857, rb1858, rb1859, rb1860, rb1861, rb1862, rb1863, rb1864, rb1865, rb1866, rb1867, rb1868, rb1869, rb1870, rb1871, rb1872, rb1873, rb1874, rb1875, rb1876, rb1877, rb1878, rb1879, rb1880, rb1881, rb1882, rb1883, rb1884, rb1885, rb1886, rb1887, rb1888, rb1889, rb1890, rb1891, rb1892, rb1893, rb1894, rb1895, rb1896, rb1897, rb1898, rb1899, rb1900, rb1901, rb1902, rb1903, rb1904, rb1905, rb1906, rb1907, rb1908, rb1909, rb1910, rb1911, rb1912, rb1913, rb1914, rb1915, rb1916, rb1917, rb1918, rb1919, rb1920, rb1921, rb1922, rb1923, rb1924, rb1925, rb1926, rb1927, rb1928, rb1929, rb1930, rb1931, rb1932, rb1933, rb1934, rb1935, rb1936, rb1937, rb1938, rb1939, rb1940, rb1941, rb1942, rb1943, rb1944, rb1945, rb1946, rb1947, rb1948, rb1949, rb1950, rb1951, rb1952, rb1953, rb1954, rb1955, rb1956, rb1957, rb1958, rb1959, rb1960, rb1961, rb1962, rb1963, rb1964, rb1965, rb1966, rb1967, rb1968, rb1969, rb1970, rb1971, rb1972, rb1973, rb1974, rb1975, rb1976, rb1977, rb1978, rb1979, rb1980, rb1981, rb1982, rb1983, rb1984, rb1985, rb1986, rb1987, rb1988, rb1989, rb1990, rb1991, rb1992, rb1993, rb1994, rb1995, rb1996, rb1997, rb1998, rb1999, rb2000, rb2001, rb2002, rb2003, rb2004, rb2005, rb2006, rb2007, rb2008, rb2009, rb2010, rb2011, rb2012, rb2013, rb2014, rb2015, rb2016, rb2017, rb2018, rb2019, rb2020, rb2021, rb2022, rb2023, rb2024, rb2025, rb2026, rb2027, rb2028, rb2029, rb2030, rb2031, rb2032, rb2033, rb2034, rb2035, rb2036, rb2037, rb2038, rb2039, rb2040, rb2041, rb2042, rb2043, rb2044, rb2045, rb2046, rb2047, rb2048, rb2049, rb2050, rb2051, rb2052, rb2053, rb2054, rb2055, rb2056, rb2057, rb2058, rb2059, rb2060, rb2061, rb2062, rb2063, rb2064, rb2065, rb2066, rb2067, rb2068, rb2069, rb2070, rb2071, rb2072, rb2073, rb2074, rb2075, rb2076, rb2077, rb2078, rb2079, rb2080, rb2081, rb2082, rb2083, rb2084, rb2085, rb2086, rb2087, rb2088, rb2089, rb2090, rb2091, rb2092, rb2093, rb2094, rb2095, rb2096, rb2097, rb2098, rb2099, rb2100, rb2101, rb2102, rb2103, rb2104, rb2105, rb2106, rb2107, rb2108, rb2109, rb2110, rb2111, rb2112, rb2113, rb2114, rb2115, rb2116, rb2117, rb2118, rb2119, rb2120, rb2121, rb2122, rb2123, rb2124, rb2125, rb2126, rb2127, rb2128, rb2129, rb2130, rb2131, rb2132, rb2133, rb2134, rb2135, rb2136, rb2137, rb2138, rb2139, rb2140, rb2141, rb2142, rb2143, rb2144, rb2145, rb2146, rb2147, rb2148, rb2149, rb2150, rb2151, rb2152, rb2153, rb2154, rb2155, rb2156, rb2157, rb2158, rb2159, rb2160, rb2161, rb2162, rb2163, rb2164, rb2165, rb2166, rb2167, rb2168, rb2169, rb2170, rb2171, rb2172, rb2173, rb2174, rb2175, rb2176, rb2177, rb2178, rb2179, rb2180, rb2181, rb2182, rb2183, rb2184, rb2185, rb2186, rb2187, rb2188, rb2189, rb2190, rb2191, rb2192, rb2193, rb2194, rb2195, rb2196, rb2197, rb2198, rb2199, rb2200, rb2201, rb2202, rb2203, rb2204, rb2205, rb2206, rb2207, rb2208, rb2209, rb2210, rb2211, rb2212, rb2213, rb2214, rb2215, rb2216, rb2217, rb2218, rb2219, rb2220, rb2221, rb2222, rb2223, rb2224, rb2225, rb2226, rb2227, rb2228, rb2229, rb2230, rb2231, rb2232, rb2233, rb2234, rb2235, rb2236, rb2237, rb2238, rb2239, rb2240, rb2241, rb2242, rb2243, rb2244, rb2245, rb2246, rb2247, rb2248, rb2249, rb2250, rb2251, rb2252, rb2253, rb2254, rb2255, rb2256, rb2257, rb2258, rb2259, rb2260, rb2261, rb2262, rb2263, rb2264, rb2265, rb2266, rb2267, rb2268, rb2269, rb2270, rb2271, rb2272, rb2273, rb2274, rb2275, rb2276, rb2277, rb2278, rb2279, rb2280, rb2281, rb2282, rb2283, rb2284, rb2285, rb2286, rb2287, rb2288, rb2289, rb2290, rb2291, rb2292, rb2293, rb2294, rb2295, rb2296, rb2297, rb2298, rb2299, rb2300, rb2301, rb2302, rb2303, rb2304, rb2305, rb2306, rb2307, rb2308, rb2309, rb2310, rb2311, rb2312, rb2313, rb2314, rb2315, rb2316, rb2317, rb2318, rb2319, rb2320, rb2321, rb2322, rb2323, rb2324, rb2325, rb2326, rb2327, rb2328, rb2329, rb2330, rb2331, rb2332, rb2333, rb2334, rb2335, rb2336, rb2337, rb2338, rb2339, rb2340, rb2341, rb2342, rb2343, rb2344, rb2345, rb2346, rb2347, rb2348, rb2349, rb2350, rb2351, rb2352, rb2353, rb2354, rb2355, rb2356, rb2357, rb2358, rb2359, rb2360, rb2361, rb2362, rb2363, rb2364, rb2365, rb2366, rb2367, rb2368, rb2369, rb2370, rb2371, rb2372, rb2373, rb2374, rb2375, rb2376, rb2377, rb2378, rb2379, rb2380, rb2381, rb2382, rb2383, rb2384, rb2385, rb2386, rb2387, rb2388, rb2389, rb2390, rb2391, rb2392, rb2393, rb2394, rb2395, rb2396, rb2397, rb2398, rb2399, rb2400, rb2401, rb2402, rb2403, rb2404, rb2405, rb2406, rb2407, rb2408, rb2409, rb2410, rb2411, rb2412, rb2413, rb2414, rb2415, rb2416, rb2417, rb2418, rb2419, rb2420, rb2421, rb2422, rb2423, rb2424, rb2425, rb2426, rb2427, rb2428, rb2429, rb2430, rb2431, rb2432, rb2433, rb2434, rb2435, rb2436, rb2437, rb2438, rb2439, rb2440, rb2441, rb2442, rb2443, rb2444, rb2445, rb2446, rb2447, rb2448, rb2449, rb2450, rb2451, rb2452, rb2453, rb2454, rb2455, rb2456, rb2457, rb2458, rb2459, rb2460, rb2461, rb2462, rb2463, rb2464, rb2465, rb2466, rb2467, rb2468, rb2469, rb2470, rb2471, rb2472, rb2473, rb2474, rb2475, rb2476, rb2477, rb2478, rb2479, rb2480, rb2481, rb2482, rb2483, rb2484, rb2485, rb2486, rb2487, rb2488, rb2489, rb2490, rb2491, rb2492, rb2493, rb2494, rb2495, rb2496, rb2497, rb2498, rb2499, rb2500, rb2501, rb2502, rb2503, rb2504, rb2505, rb2506, rb2507, rb2508, rb2509, rb2510, rb2511, rb2512, rb2513, rb2514, rb2515, rb2516, rb2517, rb2518, rb2519, rb2520, rb2521, rb2522, rb2523, rb2524, rb2525, rb2526, rb2527, rb2528, rb2529, rb2530, rb2531, rb2532, rb2533, rb2534, rb2535, rb2536, rb2537, rb2538, rb2539, rb2540, rb2541, rb2542, rb2543, rb2544, rb2545, rb2546, rb2547, rb2548, rb2549, rb2550, rb2551, rb2552, rb2553, rb2554, rb2555, rb2556, rb2557, rb2558, rb2559, rb2560, rb2561, rb2562, rb2563, rb2564, rb2565, rb2566, rb2567, rb2568, rb2569, rb2570, rb2571, rb2572, rb2573, rb2574, rb2575, rb2576, rb2577, rb2578, rb2579, rb2580, rb2581, rb2582, rb2583, rb2584, rb2585, rb2586, rb2587, rb2588, rb2589, rb2590, rb2591, rb2592, rb2593, rb2594, rb2595, rb2596, rb2597, rb2598, rb2599, rb2600, rb2601, rb2602, rb2603, rb2604, rb2605, rb2606, rb2607, rb2608, rb2609, rb2610, rb2611, rb2612, rb2613, rb2614, rb2615, rb2616, rb2617, rb2618, rb2619, rb2620, rb2621, rb2622, rb2623, rb2624, rb2625, rb2626, rb2627, rb2628, rb2629, rb2630, rb2631, rb2632, rb2633, rb2634, rb2635, rb2636, rb2637, rb2638, rb2639, rb2640, rb2641, rb2642, rb2643, rb2644, rb2645, rb2646, rb2647, rb2648, rb2649, rb2650, rb2651, rb2652, rb2653, rb2654, rb2655, rb2656, rb2657, rb2658, rb2659, rb2660, rb2661, rb2662, rb2663, rb2664, rb2665, rb2666, rb2667, rb2668, rb2669, rb2670, rb2671, rb2672, rb2673, rb2674, rb2675, rb2676, rb2677, rb2678, rb2679, rb2680, rb2681, rb2682, rb2683, rb2684, rb2685, rb2686, rb2687, rb2688, rb2689, rb2690, rb2691, rb2692, rb2693, rb2694, rb2695, rb2696, rb2697, rb2698, rb2699, rb2700, rb2701, rb2702, rb2703, rb2704, rb2705, rb2706, rb2707, rb2708, rb2709, rb2710, rb2711, rb2712, rb2713, rb2714, rb2715, rb2716, rb2717, rb2718, rb2719, rb2720, rb2721, rb2722, rb2723, rb2724, rb2725, rb2726, rb2727, rb2728, rb2729, rb2730, rb2731, rb2732, rb2733, rb2734, rb2735, rb2736, rb2737, rb2738, rb2739, rb2740, rb2741, rb2742, rb2743, rb2744, rb2745, rb2746, rb2747, rb2748, rb2749, rb2750, rb2751, rb2752, rb2753, rb2754, rb2755, rb2756, rb2757, rb2758, rb2759, rb2760, rb2761, rb2762, rb2763, rb2764, rb2765, rb2766, rb2767, rb2768, rb2769, rb2770, rb2771, rb2772, rb2773, rb2774, rb2775, rb2776, rb2777, rb2778, rb2779, rb2780, rb2781, rb2782, rb2783, rb2784, rb2785, rb2786, rb2787, rb2788, rb2789, rb2790, rb2791, rb2792, rb2793, rb2794, rb2795, rb2796, rb2797, rb2798, rb2799, rb2800, rb2801, rb2802, rb2803, rb2804, rb2805, rb2806, rb2807, rb2808, rb2809, rb2810, rb2811, rb2812, rb2813, rb2814, rb2815, rb2816, rb2817, rb2818, rb2819, rb2820, rb2821, rb2822, rb2823, rb2824, rb2825, rb2826, rb2827, rb2828, rb2829, rb2830, rb2831, rb2832, rb2833, rb2834, rb2835, rb2836, rb2837, rb2838, rb2839, rb2840, rb2841, rb2842, rb2843, rb2844, rb2845, rb2846, rb2847, rb2848, rb2849, rb2850, rb2851, rb2852, rb2853, rb2854, rb2855, rb2856, rb2857, rb2858, rb2859, rb2860, rb2861, rb2862, rb2863, rb2864, rb2865, rb2866, rb2867, rb2868, rb2869, rb2870, rb2871, rb2872, rb2873, rb2874, rb2875, rb2876, rb2877, rb2878, rb2879, rb2880, rb2881, rb2882, rb2883, rb2884, rb2885, rb2886, rb2887, rb2888, rb2889, rb2890, rb2891, rb2892, rb2893, rb2894, rb2895, rb2896, rb2897, rb2898, rb2899, rb2900, rb2901, rb2902, rb2903, rb2904, rb2905, rb2906, rb2907, rb2908, rb2909, rb2910, rb2911, rb2912, rb2913, rb2914, rb2915, rb2916, rb2917, rb2918, rb2919, rb2920, rb2921, rb2922, rb2923, rb2924, rb2925, rb2926, rb2927, rb2928, rb2929, rb2930, rb2931, rb2932, rb2933, rb2934, rb2935, rb2936, rb2937, rb2938, rb2939, rb2940, rb2941, rb2942, rb2943, rb2944, rb2945, rb2946, rb2947, rb2948, rb2949, rb2950, rb2951, rb2952, rb2953, rb2954, rb2955, rb2956, rb2957, rb2958, rb2959, rb2960, rb2961, rb2962, rb2963, rb2964, rb2965, rb2966, rb2967, rb2968, rb2969, rb2970, rb2971, rb2972, rb2973, rb2974, rb2975, rb2976, rb2977, rb2978, rb2979, rb2980, rb2981, rb2982, rb2983, rb2984, rb2985, rb2986, rb2987, rb2988, rb2989, rb2990, rb2991, rb2992, rb2993, rb2994, rb2995, rb2996, rb2997, rb2998, rb2999, rb3000, rb3001, rb3002, rb3003, rb3004, rb3005, rb3006, rb3007, rb3008, rb3009, rb3010, rb3011, rb3012, rb3013, rb3014, rb3015, rb3016, rb3017, rb3018, rb3019, rb3020, rb3021, rb3022, rb3023, rb3024, rb3025, rb3026, rb3027, rb3028, rb3029, rb3030, rb3031, rb3032, rb3033, rb3034, rb3035, rb3036, rb3037, rb3038, rb3039, rb3040, rb3041, rb3042, rb3043, rb3044, rb3045, rb3046, rb3047, rb3048, rb3049, rb3050, rb3051, rb3052, rb3053, rb3054, rb3055, rb3056, rb3057, rb3058, rb3059, rb3060, rb3061, rb3062, rb3063, rb3064, rb3065, rb3066, rb3067, rb3068, rb3069, rb3070, rb3071, rb3072, rb3073, rb3074, rb3075, rb3076, rb3077, rb3078, rb3079, rb3080, rb3081, rb3082, rb3083, rb3084, rb3085, rb3086, rb3087, rb3088, rb3089, rb3090, rb3091, rb3092, rb3093, rb3094, rb3095, rb3096, rb3097, rb3098, rb3099, rb3100, rb3101, rb3102, rb3103, rb3104, rb3105, rb3106, rb3107, rb3108, rb3109, rb3110, rb3111, rb3112, rb3113, rb3114, rb3115, rb3116, rb3117, rb3118, rb3119, rb3120, rb3121, rb3122, rb3123, rb3124, rb3125, rb3126, rb3127, rb3128, rb3129, rb3130, rb3131, rb3132, rb3133, rb3134, rb3135, rb3136, rb3137, rb3138, rb3139, rb3140, rb3141, rb3142, rb3143, rb3144, rb3145, rb3146, rb3147, rb3148, rb3149, rb3150, rb3151, rb3152, rb3153, rb3154, rb3155, rb3156, rb3157, rb3158, rb3159, rb3160, rb3161, rb3162, rb3163, rb3164, rb3165, rb3166, rb3167, rb3168, rb3169, rb3170, rb3171, rb3172, rb3173, rb3174, rb3175, rb3176, rb3177, rb3178, rb3179, rb3180, rb3181, rb3182, rb3183, rb3184, rb3185, rb3186, rb3187, rb3188, rb3189, rb3190, rb3191, rb3192, rb3193, rb3194, rb3195, rb3196, rb3197, rb3198, rb3199, rb3200, rb3201, rb3202, rb3203, rb3204, rb3205, rb3206, rb3207, rb3208, rb3209, rb3210, rb3211, rb3212, rb3213, rb3214, rb3215, rb3216, rb3217, rb3218, rb3219, rb3220, rb3221, rb3222, rb3223, rb3224, rb3225, rb3226, rb3227, rb3228, rb3229, rb3230, rb3231, rb3232, rb3233, rb3234, rb3235, rb3236, rb3237, rb3238, rb3239, rb3240, rb3241, rb3242, rb3243, rb3244, rb3245, rb3246, rb3247, rb3248, rb3249, rb3250, rb3251, rb3252, rb3253, rb3254, rb3255, rb3256, rb3257, rb3258, rb3259, rb3260, rb3261, rb3262, rb3263, rb3264, rb3265, rb3266, rb3267, rb3268, rb3269, rb3270, rb3271, rb3272, rb3273, rb3274, rb3275, rb3276, rb3277, rb3278, rb3279, rb3280, rb3281, rb3282, rb3283, rb3284, rb3285, rb3286, rb3287, rb3288, rb3289, rb3290, rb3291, rb3292, rb3293, rb3294, rb3295, rb3296, rb3297, rb3298, rb3299, rb3300, rb3301, rb3302, rb3303, rb3304, rb3305, rb3306, rb3307, rb3308, rb3309, rb3310, rb3311, rb3312, rb3313, rb3314, rb3315, rb3316, rb3317, rb3318, rb3319, rb3320, rb3321, rb3322, rb3323, rb3324, rb3325, rb3326, rb3327, rb3328, rb3329, rb3330, rb3331, rb3332, rb3333, rb3334, rb3335, rb3336, rb3337, rb3338, rb3339, rb3340, rb3341, rb3342, rb3343, rb3344, rb3345, rb3346, rb3347, rb3348, rb3349, rb3350, rb3351, rb3352, rb3353, rb3354, rb3355, rb3356, rb3357, rb3358, rb3359, rb3360, rb3361, rb3362, rb3363, rb3364, rb3365, rb3366, rb3367, rb3368, rb3369, rb3370, rb3371, rb3372, rb3373, rb3374, rb3375, rb3376, rb3377, rb3378, rb3379, rb3380, rb3381, rb3382, rb3383, rb3384, rb3385, rb3386, rb3387, rb3388, rb3389, rb3390, rb3391, rb3392, rb3393, rb3394, rb3395, rb3396, rb3397, rb3398, rb3399, rb3400, rb3401, rb3402, rb3403, rb3404, rb3405, rb3406, rb3407, rb3408, rb3409, rb3410, rb3411, rb3412, rb3413, rb3414, rb3415, rb3416, rb3417, rb3418, rb3419, rb3420, rb3421, rb3422, rb3423, rb3424, rb3425, rb3426, rb3427, rb3428, rb3429, rb3430, rb3431, rb3432, rb3433, rb3434, rb3435, rb3436, rb3437, rb3438, rb3439, rb3440, rb3441, rb3442, rb3443, rb3444, rb3445, rb3446, rb3447, rb3448, rb3449, rb3450, rb3451, rb3452, rb3453, rb3454, rb3455, rb3456, rb3457, rb3458, rb3459, rb3460, rb3461, rb3462, rb3463, rb3464, rb3465, rb3466, rb3467, rb3468, rb3469, rb3470, rb3471, rb3472, rb3473, rb3474, rb3475, rb3476, rb3477, rb3478, rb3479, rb3480, rb3481, rb3482, rb3483, rb3484, rb3485, rb3486, rb3487, rb3488, rb3489, rb3490, rb3491, rb3492, rb3493, rb3494, rb3495, rb3496, rb3497, rb3498, rb3499, rb3500, rb3501, rb3502, rb3503, rb3504, rb3505, rb3506, rb3507, rb3508, rb3509, rb3510, rb3511, rb3512, rb3513, rb3514, rb3515, rb3516, rb3517, rb3518, rb3519, rb3520, rb3521, rb3522, rb3523, rb3524, rb3525, rb3526, rb3527, rb3528, rb3529, rb3530, rb3531, rb3532, rb3533, rb3534, rb3535, rb3536, rb3537, rb3538, rb3539, rb3540, rb3541, rb3542, rb3543, rb3544, rb3545, rb3546, rb3547, rb3548, rb3549, rb3550, rb3551, rb3552, rb3553, rb3554, rb3555, rb3556, rb3557, rb3558, rb3559, rb3560, rb3561, rb3562, rb3563, rb3564, rb3565, rb3566, rb3567, rb3568, rb3569, rb3570, rb3571, rb3572, rb3573, rb3574, rb3575, rb3576, rb3577, rb3578, rb3579, rb3580, rb3581, rb3582, rb3583, rb3584, rb3585, rb3586, rb3587, rb3588, rb3589, rb3590, rb3591, rb3592, rb3593, rb3594, rb3595, rb3596, rb3597, rb3598, rb3599, rb3600, rb3601, rb3602, rb3603, rb3604, rb3605, rb3606, rb3607, rb3608, rb3609, rb3610, rb3611, rb3612, rb3613, rb3614, rb3615, rb3616, rb3617, rb3618, rb3619, rb3620, rb3621, rb3622, rb3623, rb3624, rb3625, rb3626, rb3627, rb3628, rb3629, rb3630, rb3631, rb3632, rb3633, rb3634, rb3635, rb3636, rb3637, rb3638, rb3639, rb3640, rb3641, rb3642, rb3643, rb3644, rb3645, rb3646, rb3647, rb3648, rb3649, rb3650, rb3651, rb3652, rb3653, rb3654, rb3655, rb3656, rb3657, rb3658, rb3659, rb3660, rb3661, rb3662, rb3663, rb3664, rb3665, rb3666, rb3667, rb3668, rb3669, rb3670, rb3671, rb3672, rb3673, rb3674, rb3675, rb3676, rb3677, rb3678, rb3679, rb3680, rb3681, rb3682, rb3683, rb3684, rb3685, rb3686, rb3687, rb3688, rb3689, rb3690, rb3691, rb3692, rb3693, rb3694, rb3695, rb3696, rb3697, rb3698, rb3699, rb3700, rb3701, rb3702, rb3703, rb3704, rb3705, rb3706, rb3707, rb3708, rb3709, rb3710, rb3711, rb3712, rb3713, rb3714, rb3715, rb3716, rb3717, rb3718, rb3719, rb3720, rb3721, rb3722, rb3723, rb3724, rb3725, rb3726, rb3727, rb3728, rb3729, rb3730, rb3731, rb3732, rb3733, rb3734, rb3735, rb3736, rb3737, rb3738, rb3739, rb3740, rb3741, rb3742, rb3743, rb3744, rb3745, rb3746, rb3747, rb3748, rb3749, rb3750, rb3751, rb3752, rb3753, rb3754, rb3755, rb3756, rb3757, rb3758, rb3759, rb3760, rb3761, rb3762, rb3763, rb3764, rb3765, rb3766, rb3767, rb3768, rb3769, rb3770, rb3771, rb3772, rb3773, rb3774, rb3775, rb3776, rb3777, rb3778, rb3779, rb3780, rb3781, rb3782, rb3783, rb3784, rb3785, rb3786, rb3787, rb3788, rb3789, rb3790, rb3791, rb3792, rb3793, rb3794, rb3795, rb3796, rb3797, rb3798, rb3799, rb3800, rb3801, rb3802, rb3803, rb3804, rb3805, rb3806, rb3807, rb3808, rb3809, rb3810, rb3811, rb3812, rb3813, rb3814, rb3815, rb3816, rb3817, rb3818, rb3819, rb3820, rb3821, rb3822, rb3823, rb3824, rb3825, rb3826, rb3827, rb3828, rb3829, rb3830, rb3831, rb3832, rb3833, rb3834, rb3835, rb3836, rb3837, rb3838, rb3839, rb3840, rb3841, rb3842, rb3843, rb3844, rb3845, rb3846, rb3847, rb3848, rb3849, rb3850, rb3851, rb3852, rb3853, rb3854, rb3855, rb3856, rb3857, rb3858, rb3859, rb3860, rb3861, rb3862, rb3863, rb3864, rb3865, rb3866, rb3867, rb3868, rb3869, rb3870, rb3871, rb3872, rb3873, rb3874, rb3875, rb3876, rb3877, rb3878, rb3879, rb3880, rb3881, rb3882, rb3883, rb3884, rb3885, rb3886, rb3887, rb3888, rb3889, rb3890, rb3891, rb3892, rb3893, rb3894, rb3895, rb3896, rb3897, rb3898, rb3899, rb3900, rb3901, rb3902, rb3903, rb3904, rb3905, rb3906, rb3907, rb3908, rb3909, rb3910, rb3911, rb3912, rb3913, rb3914, rb3915, rb3916, rb3917, rb3918, rb3919, rb3920, rb3921, rb3922, rb3923, rb3924, rb3925, rb3926, rb3927, rb3928, rb3929, rb3930, rb3931, rb3932, rb3933, rb3934, rb3935, rb3936, rb3937, rb3938, rb3939, rb3940, rb3941, rb3942, rb3943, rb3944, rb3945, rb3946, rb3947, rb3948, rb3949, rb3950, rb3951, rb3952, rb3953, rb3954, rb3955, rb3956, rb3957, rb3958, rb3959, rb3960, rb3961, rb3962, rb3963, rb3964, rb3965, rb3966, rb3967, rb3968, rb3969, rb3970, rb3971, rb3972, rb3973, rb3974, rb3975, rb3976, rb3977, rb3978, rb3979, rb3980, rb3981, rb3982, rb3983, rb3984, rb3985, rb3986, rb3987, rb3988, rb3989, rb3990, rb3991, rb3992, rb3993, rb3994, rb3995, rb3996, rb3997, rb3998, rb3999, rb4000, rb4001, rb4002, rb4003, rb4004, rb4005, rb4006, rb4007, rb4008, rb4009, rb4010, rb4011, rb4012, rb4013, rb4014, rb4015, rb4016, rb4017, rb4018, rb4019, rb4020, rb4021, rb4022, rb4023, rb4024, rb4025, rb4026, rb4027, rb4028, rb4029, rb4030, rb4031, rb4032, rb4033, rb4034, rb4035, rb4036, rb4037, rb4038, rb4039, rb4040, rb4041, rb4042, rb4043, rb4044, rb4045, rb4046, rb4047, rb4048, rb4049, rb4050, rb4051, rb4052, rb4053, rb4054, rb4055, rb4056, rb4057, rb4058, rb4059, rb4060, rb4061, rb4062, rb4063, rb4064, rb4065, rb4066, rb4067, rb4068, rb4069, rb4070, rb4071, rb4072, rb4073, rb4074, rb4075, rb4076, rb4077, rb4078, rb4079, rb4080, rb4081, rb4082, rb4083, rb4084, rb4085, rb4086, rb4087, rb4088, rb4089, rb4090, rb4091, rb4092, rb4093, rb4094, rb4095, rb4096, rb4097, rb4098, rb4099, rb4100, rb4101, rb4102, rb4103, rb4104, rb4105, rb4106, rb4107, rb4108, rb4109, rb4110, rb4111, rb4112, rb4113, rb4114, rb4115, rb4116, rb4117, rb4118, rb4119, rb4120, rb4121, rb4122, rb4123, rb4124, rb4125, rb4126, rb4127, rb4128, rb4129, rb4130, rb4131, rb4132, rb4133, rb4134, rb4135, rb4136, rb4137, rb4138, rb4139, rb4140, rb4141, rb4142, rb4143, rb4144, rb4145, rb4146, rb4147, rb4148, rb4149, rb4150, rb4151, rb4152, rb4153, rb4154, rb4155, rb4156, rb4157, rb4158, rb4159, rb4160, rb4161, rb4162, rb4163, rb4164, rb4165, rb4166, rb4167, rb4168, rb4169, rb4170, rb4171, rb4172, rb4173, rb4174, rb4175, rb4176, rb4177, rb4178, rb4179, rb4180, rb4181, rb4182, rb4183, rb4184, rb4185, rb4186, rb4187, rb4188, rb4189, rb4190, rb4191, rb4192, rb4193, rb4194, rb4195, rb4196, rb4197, rb4198, rb4199, rb4200, rb4201, rb4202, rb4203, rb4204, rb4205, rb4206, rb4207, rb4208, rb4209, rb4210, rb4211, rb4212, rb4213, rb4214, rb4215, rb4216, rb4217, rb4218, rb4219, rb4220, rb4221, rb4222, rb4223, rb4224, rb4225, rb4226, rb4227, rb4228, rb4229, rb4230, rb4231, rb4232, rb4233, rb4234, rb4235, rb4236, rb4237, rb4238, rb4239, rb4240, rb4241, rb4242, rb4243, rb4244, rb4245, rb4246, rb4247, rb4248, rb4249, rb4250, rb4251, rb4252, rb4253, rb4254, rb4255, rb4256, rb4257, rb4258, rb4259, rb4260, rb4261, rb4262, rb4263, rb4264, rb4265, rb4266, rb4267, rb4268, rb4269, rb4270, rb4271, rb4272, rb4273, rb4274, rb4275, rb4276, rb4277, rb4278, rb4279, rb4280, rb4281, rb4282, rb4283, rb4284, rb4285, rb4286, rb4287, rb4288, rb4289, rb4290, rb4291, rb4292, rb4293, rb4294, rb4295, rb4296, rb4297, rb4298, rb4299, rb4300, rb4301, rb4302, rb4303, rb4304, rb4305, rb4306, rb4307, rb4308, rb4309, rb4310, rb4311, rb4312, rb4313, rb4314, rb4315, rb4316, rb4317, rb4318, rb4319, rb4320, rb4321, rb4322, rb4323, rb4324, rb4325, rb4326, rb4327, rb4328, rb4329, rb4330, rb4331, rb4332, rb4333, rb4334, rb4335, rb4336, rb4337, rb4338, rb4339, rb4340, rb4341, rb4342, rb4343, rb4344, rb4345, rb4346, rb4347, rb4348, rb4349, rb4350, rb4351, rb4352, rb4353, rb4354, rb4355, rb4356, rb4357, rb4358, rb4359, rb4360, rb4361, rb4362, rb4363, rb4364, rb4365, rb4366, rb4367, rb4368, rb4369, rb4370, rb4371, rb4372, rb4373, rb4374, rb4375, rb4376, rb4377, rb4378, rb4379, rb4380, rb4381, rb4382, rb4383, rb4384, rb4385, rb4386, rb4387, rb4388, rb4389, rb4390, rb4391, rb4392, rb4393, rb4394, rb4395, rb4396, rb4397, rb4398, rb4399, rb4400, rb4401, rb4402, rb4403, rb4404, rb4405, rb4406, rb4407, rb4408, rb4409, rb4410, rb4411, rb4412, rb4413, rb4414, rb4415, rb4416, rb4417, rb4418, rb4419, rb4420, rb4421, rb4422, rb4423, rb4424, rb4425, rb4426, rb4427, rb4428, rb4429, rb4430, rb4431, rb4432, rb4433, rb4434, rb4435, rb4436, rb4437, rb4438, rb4439, rb4440, rb4441, rb4442, rb4443, rb4444, rb4445, rb4446, rb4447, rb4448, rb4449, rb4450, rb4451, rb4452, rb4453, rb4454, rb4455, rb4456, rb4457, rb4458, rb4459, rb4460, rb4461, rb4462, rb4463, rb4464, rb4465, rb4466, rb4467, rb4468, rb4469, rb4470, rb4471, rb4472, rb4473, rb4474, rb4475, rb4476, rb4477, rb4478, rb4479, rb4480, rb4481, rb4482, rb4483, rb4484, rb4485, rb4486, rb4487, rb4488, rb4489, rb4490, rb4491, rb4492, rb4493, rb4494, rb4495, rb4496, rb4497, rb4498, rb4499, rb4500, rb4501, rb4502, rb4503, rb4504, rb4505, rb4506, rb4507, rb4508, rb4509, rb4510, rb4511, rb4512, rb4513, rb4514, rb4515, rb4516, rb4517, rb4518, rb4519, rb4520, rb4521, rb4522, rb4523, rb4524, rb4525, rb4526, rb4527, rb4528, rb4529, rb4530, rb4531, rb4532, rb4533, rb4534, rb4535, rb4536, rb4537, rb4538, rb4539, rb4540, rb4541, rb4542, rb4543, rb4544, rb4545, rb4546, rb4547, rb4548, rb4549, rb4550, rb4551, rb4552, rb4553, rb4554, rb4555, rb4556, rb4557, rb4558, rb4559, rb4560, rb4561, rb4562, rb4563, rb4564, rb4565, rb4566, rb4567, rb4568, rb4569, rb4570, rb4571, rb4572, rb4573, rb4574, rb4575, rb4576, rb4577, rb4578, rb4579, rb4580, rb4581, rb4582, rb4583, rb4584, rb4585, rb4586, rb4587, rb4588, rb4589, rb4590, rb4591, rb4592, rb4593, rb4594, rb4595, rb4596, rb4597, rb4598, rb4599, rb4600, rb4601, rb4602, rb4603, rb4604, rb4605, rb4606, rb4607, rb4608, rb4609, rb4610, rb4611, rb4612, rb4613, rb4614, rb4615, rb4616, rb4617, rb4618, rb4619, rb4620, rb4621, rb4622, rb4623, rb4624, rb4625, rb4626, rb4627, rb4628, rb4629, rb4630, rb4631, rb4632, rb4633, rb4634, rb4635, rb4636, rb4637, rb4638, rb4639, rb4640, rb4641, rb4642, rb4643, rb4644, rb4645, rb4646, rb4647, rb4648, rb4649, rb4650, rb4651, rb4652, rb4653, rb4654, rb4655, rb4656, rb4657, rb4658, rb4659, rb4660, rb4661, rb4662, rb4663, rb4664, rb4665, rb4666, rb4667, rb4668, rb4669, rb4670, rb4671, rb4672, rb4673, rb4674, rb4675, rb4676, rb4677, rb4678, rb4679, rb4680, rb4681, rb4682, rb4683, rb4684, rb4685, rb4686, rb4687, rb4688, rb4689, rb4690, rb4691, rb4692, rb4693, rb4694, rb4695, rb4696, rb4697, rb4698, rb4699, rb4700, rb4701, rb4702, rb4703, rb4704, rb4705, rb4706, rb4707, rb4708, rb4709, rb4710, rb4711, rb4712, rb4713, rb4714, rb4715, rb4716, rb4717, rb4718, rb4719, rb4720, rb4721, rb4722, rb4723, rb4724, rb4725, rb4726, rb4727, rb4728, rb4729, rb4730, rb4731, rb4732, rb4733, rb4734, rb4735, rb4736, rb4737, rb4738, rb4739, rb4740, rb4741, rb4742, rb4743, rb4744, rb4745, rb4746, rb4747, rb4748, rb4749, rb4750, rb4751, rb4752, rb4753, rb4754, rb4755, rb4756, rb4757, rb4758, rb4759, rb4760, rb4761, rb4762, rb4763, rb4764, rb4765, rb4766, rb4767, rb4768, rb4769, rb4770, rb4771, rb4772, rb4773, rb4774, rb4775, rb4776, rb4777, rb4778, rb4779, rb4780, rb4781, rb4782, rb4783, rb4784, rb4785, rb4786, rb4787, rb4788, rb4789, rb4790, rb4791, rb4792, rb4793, rb4794, rb4795, rb4796, rb4797, rb4798, rb4799, rb4800, rb4801, rb4802, rb4803, rb4804, rb4805, rb4806, rb4807, rb4808, rb4809, rb4810, rb4811, rb4812, rb4813, rb4814, rb4815, rb4816, rb4817, rb4818, rb4819, rb4820, rb4821, rb4822, rb4823, rb4824, rb4825, rb4826, rb4827, rb4828, rb4829, rb4830, rb4831, rb4832, rb4833, rb4834, rb4835, rb4836, rb4837, rb4838, rb4839, rb4840, rb4841, rb4842, rb4843, rb4844, rb4845, rb4846, rb4847, rb4848, rb4849, rb4850, rb4851, rb4852, rb4853, rb4854, rb4855, rb4856, rb4857, rb4858, rb4859, rb4860, rb4861, rb4862, rb4863, rb4864, rb4865, rb4866, rb4867, rb4868, rb4869, rb4870, rb4871, rb4872, rb4873, rb4874, rb4875, rb4876, rb4877, rb4878, rb4879, rb4880, rb4881, rb4882, rb4883, rb4884, rb4885, rb4886, rb4887, rb4888, rb4889, rb4890, rb4891, rb4892, rb4893, rb4894, rb4895, rb4896, rb4897, rb4898, rb4899, rb4900, rb4901, rb4902, rb4903, rb4904, rb4905, rb4906, rb4907, rb4908, rb4909, rb4910, rb4911, rb4912, rb4913, rb4914, rb4915, rb4916, rb4917, rb4918, rb4919, rb4920, rb4921, rb4922, rb4923, rb4924, rb4925, rb4926, rb4927, rb4928, rb4929, rb4930, rb4931, rb4932, rb4933, rb4934, rb4935, rb4936, rb4937, rb4938, rb4939, rb4940, rb4941, rb4942, rb4943, rb4944, rb4945, rb4946, rb4947, rb4948, rb4949, rb4950, rb4951, rb4952, rb4953, rb4954, rb4955, rb4956, rb4957, rb4958, rb4959, rb4960, rb4961, rb4962, rb4963, rb4964, rb4965, rb4966, rb4967, rb4968, rb4969, rb4970, rb4971, rb4972, rb4973, rb4974, rb4975, rb4976, rb4977, rb4978, rb4979, rb4980, rb4981, rb4982, rb4983, rb4984, rb4985, rb4986, rb4987, rb4988, rb4989, rb4990, rb4991, rb4992, rb4993, rb4994, rb4995, rb4996, rb4997, rb4998, rb4999, rb5000, rb5001, rb5002, rb5003, rb5004, rb5005, rb5006, rb5007, rb5008, rb5009, rb5010, rb5011, rb5012, rb5013, rb5014, rb5015, rb5016, rb5017, rb5018, rb5019, rb5020, rb5021, rb5022, rb5023, rb5024, rb5025, rb5026, rb5027, rb5028, rb5029, rb5030, rb5031, rb5032, rb5033, rb5034, rb5035, rb5036, rb5037, rb5038, rb5039, rb5040, rb5041, rb5042, rb5043, rb5044, rb5045, rb5046, rb5047, rb5048, rb5049, rb5050, rb5051, rb5052, rb5053, rb5054, rb5055, rb5056, rb5057, rb5058, rb5059, rb5060, rb5061, rb5062, rb5063, rb5064, rb5065, rb5066, rb5067, rb5068, rb5069, rb5070, rb5071, rb5072, rb5073, rb5074, rb5075, rb5076, rb5077, rb5078, rb5079, rb5080, rb5081, rb5082, rb5083, rb5084, rb5085, rb5086, rb5087, rb5088, rb5089, rb5090, rb5091, rb5092, rb5093, rb5094, rb5095, rb5096, rb5097, rb5098, rb5099, rb5100, rb5101, rb5102, rb5103, rb5104, rb5105, rb5106, rb5107, rb5108, rb5109, rb5110, rb5111, rb5112, rb5113, rb5114, rb5115, rb5116, rb5117, rb5118, rb5119, rb5120, rb5121, rb5122, rb5123, rb5124, rb5125, rb5126, rb5127, rb5128, rb5129, rb5130, rb5131, rb5132, rb5133, rb5134, rb5135, rb5136, rb5137, rb5138, rb5139, rb5140, rb5141, rb5142, rb5143, rb5144, rb5145, rb5146, rb5147, rb5148, rb5149, rb5150, rb5151, rb5152, rb5153, rb5154, rb5155, rb5156, rb5157, rb5158, rb5159, rb5160, rb5161, rb5162, rb5163, rb5164, rb5165, rb5166, rb5167, rb5168, rb5169, rb5170, rb5171, rb5172, rb5173, rb5174, rb5175, rb5176, rb5177, rb5178, rb5179, rb5180, rb5181, rb5182, rb5183, rb5184, rb5185, rb5186, rb5187, rb5188, rb5189, rb5190, rb5191, rb5192, rb5193, rb5194, rb5195, rb5196, rb5197, rb5198, rb5199, rb5200, rb5201, rb5202, rb5203, rb5204, rb5205, rb5206, rb5207, rb5208, rb5209, rb5210, rb5211, rb5212, rb5213, rb5214, rb5215, rb5216, rb5217, rb5218, rb5219, rb5220, rb5221, rb5222, rb5223, rb5224, rb5225, rb5226, rb5227, rb5228, rb5229, rb5230, rb5231, rb5232, rb5233, rb5234, rb5235, rb5236, rb5237, rb5238, rb5239, rb5240, rb5241, rb5242, rb5243, rb5244, rb5245, rb5246, rb5247, rb5248, rb5249, rb5250, rb5251, rb5252, rb5253, rb5254, rb5255, rb5256, rb5257, rb5258, rb5259, rb5260, rb5261, rb5262, rb5263, rb5264, rb5265, rb5266, rb5267, rb5268, rb5269, rb5270, rb5271, rb5272, rb5273, rb5274, rb5275, rb5276, rb5277, rb5278, rb5279, rb5280, rb5281, rb5282, rb5283, rb5284, rb5285, rb5286, rb5287, rb5288, rb5289, rb5290, rb5291, rb5292, rb5293, rb5294, rb5295, rb5296, rb5297, rb5298, rb5299, rb5300, rb5301, rb5302, rb5303, rb5304, rb5305, rb5306, rb5307, rb5308, rb5309, rb5310, rb5311, rb5312, rb5313, rb5314, rb5315, rb5316, rb5317, rb5318, rb5319, rb5320, rb5321, rb5322, rb5323, rb5324, rb5325, rb5326, rb5327, rb5328, rb5329, rb5330, rb5331, rb5332, rb5333, rb5334, rb5335, rb5336, rb5337, rb5338, rb5339, rb5340, rb5341, rb5342, rb5343, rb5344, rb5345, rb5346, rb5347, rb5348, rb5349, rb5350, rb5351, rb5352, rb5353, rb5354, rb5355, rb5356, rb5357, rb5358, rb5359, rb5360, rb5361, rb5362, rb5363, rb5364, rb5365, rb5366, rb5367, rb5368, rb5369, rb5370, rb5371, rb5372, rb5373, rb5374, rb5375, rb5376, rb5377, rb5378, rb5379, rb5380, rb5381, rb5382, rb5383, rb5384, rb5385, rb5386, rb5387, rb5388, rb5389, rb5390, rb5391, rb5392, rb5393, rb5394, rb5395, rb5396, rb5397, rb5398, rb5399, rb5400, rb5401, rb5402, rb5403, rb5404, rb5405, rb5406, rb5407, rb5408, rb5409, rb5410, rb5411, rb5412, rb5413, rb5414, rb5415, rb5416, rb5417, rb5418, rb5419, rb5420, rb5421, rb5422, rb5423, rb5424, rb5425, rb5426, rb5427, rb5428, rb5429, rb5430, rb5431, rb5432, rb5433, rb5434, rb5435, rb5436, rb5437, rb5438, rb5439, rb5440, rb5441, rb5442, rb5443, rb5444, rb5445, rb5446, rb5447, rb5448, rb5449, rb5450, rb5451, rb5452, rb5453, rb5454, rb5455, rb5456, rb5457, rb5458, rb5459, rb5460, rb5461, rb5462, rb5463, rb5464, rb5465, rb5466, rb5467, rb5468, rb5469, rb5470, rb5471, rb5472, rb5473, rb5474, rb5475, rb5476, rb5477, rb5478, rb5479, rb5480, rb5481, rb5482, rb5483, rb5484, rb5485, rb5486, rb5487, rb5488, rb5489, rb5490, rb5491, rb5492, rb5493, rb5494, rb5495, rb5496, rb5497, rb5498, rb5499, rb5500, rb5501, rb5502, rb5503, rb5504, rb5505, rb5506, rb5507, rb5508, rb5509, rb5510, rb5511, rb5512, rb5513, rb5514, rb5515, rb5516, rb5517, rb5518, rb5519, rb5520, rb5521, rb5522, rb5523, rb5524, rb5525, rb5526, rb5527, rb5528, rb5529, rb5530, rb5531, rb5532, rb5533, rb5534, rb5535, rb5536, rb5537, rb5538, rb5539, rb5540, rb5541, rb5542, rb5543, rb5544, rb5545, rb5546, rb5547, rb5548, rb5549, rb5550, rb5551, rb5552, rb5553, rb5554, rb5555, rb5556, rb5557, rb5558, rb5559, rb5560, rb5561, rb5562, rb5563, rb5564, rb5565, rb5566, rb5567, rb5568, rb5569, rb5570, rb5571, rb5572, rb5573, rb5574, rb5575, rb5576, rb5577, rb5578, rb5579, rb5580, rb5581, rb5582, rb5583, rb5584, rb5585, rb5586, rb5587, rb5588, rb5589, rb5590, rb5591, rb5592, rb5593, rb5594, rb5595, rb5596, rb5597, rb5598, rb5599, rb5600, rb5601, rb5602, rb5603, rb5604, rb5605, rb5606, rb5607, rb5608, rb5609, rb5610, rb5611, rb5612, rb5613, rb5614, rb5615, rb5616, rb5617, rb5618, rb5619, rb5620, rb5621, rb5622, rb5623, rb5624, rb5625, rb5626, rb5627, rb5628, rb5629, rb5630, rb5631, rb5632, rb5633, rb5634, rb5635, rb5636, rb5637, rb5638, rb5639, rb5640, rb5641, rb5642, rb5643, rb5644, rb5645, rb5646, rb5647, rb5648, rb5649, rb5650, rb5651, rb5652, rb5653, rb5654, rb5655, rb5656, rb5657, rb5658, rb5659, rb5660, rb5661, rb5662, rb5663, rb5664, rb5665, rb5666, rb5667, rb5668, rb5669, rb5670, rb5671, rb5672, rb5673, rb5674, rb5675, rb5676, rb5677, rb5678, rb5679, rb5680, rb5681, rb5682, rb5683, rb5684, rb5685, rb5686, rb5687, rb5688, rb5689, rb5690, rb5691, rb5692, rb5693, rb5694, rb5695, rb5696, rb5697, rb5698, rb5699, rb5700, rb5701, rb5702, rb5703, rb5704, rb5705, rb5706, rb5707, rb5708, rb5709, rb5710, rb5711, rb5712, rb5713, rb5714, rb5715, rb5716, rb5717, rb5718, rb5719, rb5720, rb5721, rb5722, rb5723, rb5724, rb5725, rb5726, rb5727, rb5728, rb5729, rb5730, rb5731, rb5732, rb5733, rb5734, rb5735, rb5736, rb5737, rb5738, rb5739, rb5740, rb5741, rb5742, rb5743, rb5744, rb5745, rb5746, rb5747, rb5748, rb5749, rb5750, rb5751, rb5752, rb5753, rb5754, rb5755, rb5756, rb5757, rb5758, rb5759, rb5760, rb5761, rb5762, rb5763, rb5764, rb5765, rb5766, rb5767, rb5768, rb5769, rb5770, rb5771, rb5772, rb5773, rb5774, rb5775, rb5776, rb5777, rb5778, rb5779, rb5780, rb5781, rb5782, rb5783, rb5784, rb5785, rb5786, rb5787, rb5788, rb5789, rb5790, rb5791, rb5792, rb5793, rb5794, rb5795, rb5796, rb5797, rb5798, rb5799, rb5800, rb5801, rb5802, rb5803, rb5804, rb5805, rb5806, rb5807, rb5808, rb5809, rb5810, rb5811, rb5812, rb5813, rb5814, rb5815, rb5816, rb5817, rb5818, rb5819, rb5820, rb5821, rb5822, rb5823, rb5824, rb5825, rb5826, rb5827, rb5828, rb5829, rb5830, rb5831, rb5832, rb5833, rb5834, rb5835, rb5836, rb5837, rb5838, rb5839, rb5840, rb5841, rb5842, rb5843, rb5844, rb5845, rb5846, rb5847, rb5848, rb5849, rb5850, rb5851, rb5852, rb5853, rb5854, rb5855, rb5856, rb5857, rb5858, rb5859, rb5860, rb5861, rb5862, rb5863, rb5864, rb5865, rb5866, rb5867, rb5868, rb5869, rb5870, rb5871, rb5872, rb5873, rb5874, rb5875, rb5876, rb5877, rb5878, rb5879, rb5880, rb5881, rb5882, rb5883, rb5884, rb5885, rb5886, rb5887, rb5888, rb5889, rb5890, rb5891, rb5892, rb5893, rb5894, rb5895, rb5896, rb5897, rb5898, rb5899, rb5900, rb5901, rb5902, rb5903, rb5904, rb5905, rb5906, rb5907, rb5908, rb5909, rb5910, rb5911, rb5912, rb5913, rb5914, rb5915, rb5916, rb5917, rb5918, rb5919, rb5920, rb5921, rb5922, rb5923, rb5924, rb5925, rb5926, rb5927, rb5928, rb5929, rb5930, rb5931, rb5932, rb5933, rb5934, rb5935, rb5936, rb5937, rb5938, rb5939, rb5940, rb5941, rb5942, rb5943, rb5944, rb5945, rb5946, rb5947, rb5948, rb5949, rb5950, rb5951, rb5952, rb5953, rb5954, rb5955, rb5956, rb5957, rb5958, rb5959, rb5960, rb5961, rb5962, rb5963, rb5964, rb5965, rb5966, rb5967, rb5968, rb5969, rb5970, rb5971, rb5972, rb5973, rb5974, rb5975, rb5976, rb5977, rb5978, rb5979, rb5980, rb5981, rb5982, rb5983, rb5984, rb5985, rb5986, rb5987, rb5988, rb5989, rb5990, rb5991, rb5992, rb5993, rb5994, rb5995, rb5996, rb5997, rb5998, rb5999, rb6000, rb6001, rb6002, rb6003, rb6004, rb6005, rb6006, rb6007, rb6008, rb6009, rb6010, rb6011, rb6012, rb6013, rb6014, rb6015, rb6016, rb6017, rb6018, rb6019, rb6020, rb6021, rb6022, rb6023, rb6024, rb6025, rb6026, rb6027, rb6028, rb6029, rb6030, rb6031, rb6032, rb6033, rb6034, rb6035, rb6036, rb6037, rb6038, rb6039, rb6040, rb6041, rb6042, rb6043, rb6044, rb6045, rb6046, rb6047, rb6048, rb6049, rb6050, rb6051, rb6052, rb6053, rb6054, rb6055, rb6056, rb6057, rb6058, rb6059, rb6060, rb6061, rb6062, rb6063, rb6064, rb6065, rb6066, rb6067, rb6068, rb6069, rb6070, rb6071, rb6072, rb6073, rb6074, rb6075, rb6076, rb6077, rb6078, rb6079, rb6080, rb6081, rb6082, rb6083, rb6084, rb6085, rb6086, rb6087, rb6088, rb6089, rb6090, rb6091, rb6092, rb6093, rb6094, rb6095, rb6096, rb6097, rb6098, rb6099, rb6100, rb6101, rb6102, rb6103, rb6104, rb6105, rb6106, rb6107, rb6108, rb6109, rb6110, rb6111, rb6112, rb6113, rb6114, rb6115, rb6116, rb6117, rb6118, rb6119, rb6120, rb6121, rb6122, rb6123, rb6124, rb6125, rb6126, rb6127, rb6128, rb6129, rb6130, rb6131, rb6132, rb6133, rb6134, rb6135, rb6136, rb6137, rb6138, rb6139, rb6140, rb6141, rb6142, rb6143, rb6144, rb6145, rb6146, rb6147, rb6148, rb6149, rb6150, rb6151, rb6152, rb6153, rb6154, rb6155, rb6156, rb6157, rb6158, rb6159, rb6160, rb6161, rb6162, rb6163, rb6164, rb6165, rb6166, rb6167, rb6168, rb6169, rb6170, rb6171, rb6172, rb6173, rb6174, rb6175, rb6176, rb6177, rb6178, rb6179, rb6180, rb6181, rb6182, rb6183, rb6184, rb6185, rb6186, rb6187, rb6188, rb6189, rb6190, rb6191, rb6192, rb6193, rb6194, rb6195, rb6196, rb6197, rb6198, rb6199, rb6200, rb6201, rb6202, rb6203, rb6204, rb6205, rb6206, rb6207, rb6208, rb6209, rb6210, rb6211, rb6212, rb6213, rb6214, rb6215, rb6216, rb6217, rb6218, rb6219, rb6220, rb6221, rb6222, rb6223, rb6224, rb6225, rb6226, rb6227, rb6228, rb6229, rb6230, rb6231, rb6232, rb6233, rb6234, rb6235, rb6236, rb6237, rb6238, rb6239, rb6240, rb6241, rb6242, rb6243, rb6244, rb6245, rb6246, rb6247, rb6248, rb6249, rb6250, rb6251, rb6252, rb6253, rb6254, rb6255, rb6256, rb6257, rb6258, rb6259, rb6260, rb6261, rb6262, rb6263, rb6264, rb6265, rb6266, rb6267, rb6268, rb6269, rb6270, rb6271, rb6272, rb6273, rb6274, rb6275, rb6276, rb6277, rb6278, rb6279, rb6280, rb6281, rb6282, rb6283, rb6284, rb6285, rb6286, rb6287, rb6288, rb6289, rb6290, rb6291, rb6292, rb6293, rb6294, rb6295, rb6296, rb6297, rb6298, rb6299, rb6300, rb6301, rb6302, rb6303, rb6304, rb6305, rb6306, rb6307, rb6308, rb6309, rb6310, rb6311, rb6312, rb6313, rb6314, rb6315, rb6316, rb6317, rb6318, rb6319, rb6320, rb6321, rb6322, rb6323, rb6324, rb6325, rb6326, rb6327, rb6328, rb6329, rb6330, rb6331, rb6332, rb6333, rb6334, rb6335, rb6336, rb6337, rb6338, rb6339, rb6340, rb6341, rb6342, rb6343, rb6344, rb6345, rb6346, rb6347, rb6348, rb6349, rb6350, rb6351, rb6352, rb6353, rb6354, rb6355, rb6356, rb6357, rb6358, rb6359, rb6360, rb6361, rb6362, rb6363, rb6364, rb6365, rb6366, rb6367, rb6368, rb6369, rb6370, rb6371, rb6372, rb6373, rb6374, rb6375, rb6376, rb6377, rb6378, rb6379, rb6380, rb6381, rb6382, rb6383, rb6384, rb6385, rb6386, rb6387, rb6388, rb6389, rb6390, rb6391, rb6392, rb6393, rb6394, rb6395, rb6396, rb6397, rb6398, rb6399, rb6400, rb6401, rb6402, rb6403, rb6404, rb6405, rb6406, rb6407, rb6408, rb6409, rb6410, rb6411, rb6412, rb6413, rb6414, rb6415, rb6416, rb6417, rb6418, rb6419, rb6420, rb6421, rb6422, rb6423, rb6424, rb6425, rb6426, rb6427, rb6428, rb6429, rb6430, rb6431, rb6432, rb6433, rb6434, rb6435, rb6436, rb6437, rb6438, rb6439, rb6440, rb6441, rb6442, rb6443, rb6444, rb6445, rb6446, rb6447, rb6448, rb6449, rb6450, rb6451, rb6452, rb6453, rb6454, rb6455, rb6456, rb6457, rb6458, rb6459, rb6460, rb6461, rb6462, rb6463, rb6464, rb6465, rb6466, rb6467, rb6468, rb6469, rb6470, rb6471, rb6472, rb6473, rb6474, rb6475, rb6476, rb6477, rb6478, rb6479, rb6480, rb6481, rb6482, rb6483, rb6484, rb6485, rb6486, rb6487, rb6488, rb6489, rb6490, rb6491, rb6492, rb6493, rb6494, rb6495, rb6496, rb6497, rb6498, rb6499, rb6500, rb6501, rb6502, rb6503, rb6504, rb6505, rb6506, rb6507, rb6508, rb6509, rb6510, rb6511, rb6512, rb6513, rb6514, rb6515, rb6516, rb6517, rb6518, rb6519, rb6520, rb6521, rb6522, rb6523, rb6524, rb6525, rb6526, rb6527, rb6528, rb6529, rb6530, rb6531, rb6532, rb6533, rb6534, rb6535, rb6536, rb6537, rb6538, rb6539, rb6540, rb6541, rb6542, rb6543, rb6544, rb6545, rb6546, rb6547, rb6548, rb6549, rb6550, rb6551, rb6552, rb6553, rb6554, rb6555, rb6556, rb6557, rb6558, rb6559, rb6560, rb6561, rb6562, rb6563, rb6564, rb6565, rb6566, rb6567, rb6568, rb6569, rb6570, rb6571, rb6572, rb6573, rb6574, rb6575, rb6576, rb6577, rb6578, rb6579, rb6580, rb6581, rb6582, rb6583, rb6584, rb6585, rb6586, rb6587, rb6588, rb6589, rb6590, rb6591, rb6592, rb6593, rb6594, rb6595, rb6596, rb6597, rb6598, rb6599, rb6600, rb6601, rb6602, rb6603, rb6604, rb6605, rb6606, rb6607, rb6608, rb6609, rb6610, rb6611, rb6612, rb6613, rb6614, rb6615, rb6616, rb6617, rb6618, rb6619, rb6620, rb6621, rb6622, rb6623, rb6624, rb6625, rb6626, rb6627, rb6628, rb6629, rb6630, rb6631, rb6632, rb6633, rb6634, rb6635, rb6636, rb6637, rb6638, rb6639, rb6640, rb6641, rb6642, rb6643, rb6644, rb6645, rb6646, rb6647, rb6648, rb6649, rb6650, rb6651, rb6652, rb6653, rb6654, rb6655, rb6656, rb6657, rb6658, rb6659, rb6660, rb6661, rb6662, rb6663, rb6664, rb6665, rb6666, rb6667, rb6668, rb6669, rb6670, rb6671, rb6672, rb6673, rb6674, rb6675, rb6676, rb6677, rb6678, rb6679, rb6680, rb6681, rb6682, rb6683, rb6684, rb6685, rb6686, rb6687, rb6688, rb6689, rb6690, rb6691, rb6692, rb6693, rb6694, rb6695, rb6696, rb6697, rb6698, rb6699, rb6700, rb6701, rb6702, rb6703, rb6704, rb6705, rb6706, rb6707, rb6708, rb6709, rb6710, rb6711, rb6712, rb6713, rb6714, rb6715, rb6716, rb6717, rb6718, rb6719, rb6720, rb6721, rb6722, rb6723, rb6724, rb6725, rb6726, rb6727, rb6728, rb6729, rb6730, rb6731, rb6732, rb6733, rb6734, rb6735, rb6736, rb6737, rb6738, rb6739, rb6740, rb6741, rb6742, rb6743, rb6744, rb6745, rb6746, rb6747, rb6748, rb6749, rb6750, rb6751, rb6752, rb6753, rb6754, rb6755, rb6756, rb6757, rb6758, rb6759, rb6760, rb6761, rb6762, rb6763, rb6764, rb6765, rb6766, rb6767, rb6768, rb6769, rb6770, rb6771, rb6772, rb6773, rb6774, rb6775, rb6776, rb6777, rb6778, rb6779, rb6780, rb6781, rb6782, rb6783, rb6784, rb6785, rb6786, rb6787, rb6788, rb6789, rb6790, rb6791, rb6792, rb6793, rb6794, rb6795, rb6796, rb6797, rb6798, rb6799, rb6800, rb6801, rb6802, rb6803, rb6804, rb6805, rb6806, rb6807, rb6808, rb6809, rb6810, rb6811, rb6812, rb6813, rb6814, rb6815, rb6816, rb6817, rb6818, rb6819, rb6820, rb6821, rb6822, rb6823, rb6824, rb6825, rb6826, rb6827, rb6828, rb6829, rb6830, rb6831, rb6832, rb6833, rb6834, rb6835, rb6836, rb6837, rb6838, rb6839, rb6840, rb6841, rb6842, rb6843, rb6844, rb6845, rb6846, rb6847, rb6848, rb6849, rb6850, rb6851, rb6852, rb6853, rb6854, rb6855, rb6856, rb6857, rb6858, rb6859, rb6860, rb6861, rb6862, rb6863, rb6864, rb6865, rb6866, rb6867, rb6868, rb6869, rb6870, rb6871, rb6872, rb6873, rb6874, rb6875, rb6876, rb6877, rb6878, rb6879, rb6880, rb6881, rb6882, rb6883, rb6884, rb6885, rb6886, rb6887, rb6888, rb6889, rb6890, rb6891, rb6892, rb6893, rb6894, rb6895, rb6896, rb6897, rb6898, rb6899, rb6900, rb6901, rb6902, rb6903, rb6904, rb6905, rb6906, rb6907, rb6908, rb6909, rb6910, rb6911, rb6912, rb6913, rb6914, rb6915, rb6916, rb6917, rb6918, rb6919, rb6920, rb6921, rb6922, rb6923, rb6924, rb6925, rb6926, rb6927, rb6928, rb6929, rb6930, rb6931, rb6932, rb6933, rb6934, rb6935, rb6936, rb6937, rb6938, rb6939, rb6940, rb6941, rb6942, rb6943, rb6944, rb6945, rb6946, rb6947, rb6948, rb6949, rb6950, rb6951, rb6952, rb6953, rb6954, rb6955, rb6956, rb6957, rb6958, rb6959, rb6960, rb6961, rb6962, rb6963, rb6964, rb6965, rb6966, rb6967, rb6968, rb6969, rb6970, rb6971, rb6972, rb6973, rb6974, rb6975, rb6976, rb6977, rb6978, rb6979, rb6980, rb6981, rb6982, rb6983, rb6984, rb6985, rb6986, rb6987, rb6988, rb6989, rb6990, rb6991, rb6992, rb6993, rb6994, rb6995, rb6996, rb6997, rb6998, rb6999, rb7000, rb7001, rb7002, rb7003, rb7004, rb7005, rb7006, rb7007, rb7008, rb7009, rb7010, rb7011, rb7012, rb7013, rb7014, rb7015, rb7016, rb7017, rb7018, rb7019, rb7020, rb7021, rb7022, rb7023, rb7024, rb7025, rb7026, rb7027, rb7028, rb7029, rb7030, rb7031, rb7032, rb7033, rb7034, rb7035, rb7036, rb7037, rb7038, rb7039, rb7040, rb7041, rb7042, rb7043, rb7044, rb7045, rb7046, rb7047, rb7048, rb7049, rb7050, rb7051, rb7052, rb7053, rb7054, rb7055, rb7056, rb7057, rb7058, rb7059, rb7060, rb7061, rb7062, rb7063, rb7064, rb7065, rb7066, rb7067, rb7068, rb7069, rb7070, rb7071, rb7072, rb7073, rb7074, rb7075, rb7076, rb7077, rb7078, rb7079, rb7080, rb7081, rb7082, rb7083, rb7084, rb7085, rb7086, rb7087, rb7088, rb7089, rb7090, rb7091, rb7092, rb7093, rb7094, rb7095, rb7096, rb7097, rb7098, rb7099, rb7100, rb7101, rb7102, rb7103, rb7104, rb7105, rb7106, rb7107, rb7108, rb7109, rb7110, rb7111, rb7112, rb7113, rb7114, rb7115, rb7116, rb7117, rb7118, rb7119, rb7120, rb7121, rb7122, rb7123, rb7124, rb7125, rb7126, rb7127, rb7128, rb7129, rb7130, rb7131, rb7132, rb7133, rb7134, rb7135, rb7136, rb7137, rb7138, rb7139, rb7140, rb7141, rb7142, rb7143, rb7144, rb7145, rb7146, rb7147, rb7148, rb7149, rb7150, rb7151, rb7152, rb7153, rb7154, rb7155, rb7156, rb7157, rb7158, rb7159, rb7160, rb7161, rb7162, rb7163, rb7164, rb7165, rb7166, rb7167, rb7168, rb7169, rb7170, rb7171, rb7172, rb7173, rb7174, rb7175, rb7176, rb7177, rb7178, rb7179, rb7180, rb7181, rb7182, rb7183, rb7184, rb7185, rb7186, rb7187, rb7188, rb7189, rb7190, rb7191, rb7192, rb7193, rb7194, rb7195, rb7196, rb7197, rb7198, rb7199, rb7200, rb7201, rb7202, rb7203, rb7204, rb7205, rb7206, rb7207, rb7208, rb7209, rb7210, rb7211, rb7212, rb7213, rb7214, rb7215, rb7216, rb7217, rb7218, rb7219, rb7220, rb7221, rb7222, rb7223, rb7224, rb7225, rb7226, rb7227, rb7228, rb7229, rb7230, rb7231, rb7232, rb7233, rb7234, rb7235, rb7236, rb7237, rb7238, rb7239, rb7240, rb7241, rb7242, rb7243, rb7244, rb7245, rb7246, rb7247, rb7248, rb7249, rb7250, rb7251, rb7252, rb7253, rb7254, rb7255, rb7256, rb7257, rb7258, rb7259, rb7260, rb7261, rb7262, rb7263, rb7264, rb7265, rb7266, rb7267, rb7268, rb7269, rb7270, rb7271, rb7272, rb7273, rb7274, rb7275, rb7276, rb7277, rb7278, rb7279, rb7280, rb7281, rb7282, rb7283, rb7284, rb7285, rb7286, rb7287, rb7288, rb7289, rb7290, rb7291, rb7292, rb7293, rb7294, rb7295, rb7296, rb7297, rb7298, rb7299, rb7300, rb7301, rb7302, rb7303, rb7304, rb7305, rb7306, rb7307, rb7308, rb7309, rb7310, rb7311, rb7312, rb7313, rb7314, rb7315, rb7316, rb7317, rb7318, rb7319, rb7320, rb7321, rb7322, rb7323, rb7324, rb7325, rb7326, rb7327, rb7328, rb7329, rb7330, rb7331, rb7332, rb7333, rb7334, rb7335, rb7336, rb7337, rb7338, rb7339, rb7340, rb7341, rb7342, rb7343, rb7344, rb7345, rb7346, rb7347, rb7348, rb7349, rb7350, rb7351, rb7352, rb7353, rb7354, rb7355, rb7356, rb7357, rb7358, rb7359, rb7360, rb7361, rb7362, rb7363, rb7364, rb7365, rb7366, rb7367, rb7368, rb7369, rb7370, rb7371, rb7372, rb7373, rb7374, rb7375, rb7376, rb7377, rb7378, rb7379, rb7380, rb7381, rb7382, rb7383, rb7384, rb7385, rb7386, rb7387, rb7388, rb7389, rb7390, rb7391, rb7392, rb7393, rb7394, rb7395, rb7396, rb7397, rb7398, rb7399, rb7400, rb7401, rb7402, rb7403, rb7404, rb7405, rb7406, rb7407, rb7408, rb7409, rb7410, rb7411, rb7412, rb7413, rb7414, rb7415, rb7416, rb7417, rb7418, rb7419, rb7420, rb7421, rb7422, rb7423, rb7424, rb7425, rb7426, rb7427, rb7428, rb7429, rb7430, rb7431, rb7432, rb7433, rb7434, rb7435, rb7436, rb7437, rb7438, rb7439, rb7440, rb7441, rb7442, rb7443, rb7444, rb7445, rb7446, rb7447, rb7448, rb7449, rb7450, rb7451, rb7452, rb7453, rb7454, rb7455, rb7456, rb7457, rb7458, rb7459, rb7460, rb7461, rb7462, rb7463, rb7464, rb7465, rb7466, rb7467, rb7468, rb7469, rb7470, rb7471, rb7472, rb7473, rb7474, rb7475, rb7476, rb7477, rb7478, rb7479, rb7480, rb7481, rb7482, rb7483, rb7484, rb7485, rb7486, rb7487, rb7488, rb7489, rb7490, rb7491, rb7492, rb7493, rb7494, rb7495, rb7496, rb7497, rb7498, rb7499, rb7500, rb7501, rb7502, rb7503, rb7504, rb7505, rb7506, rb7507, rb7508, rb7509, rb7510, rb7511, rb7512, rb7513, rb7514, rb7515, rb7516, rb7517, rb7518, rb7519, rb7520, rb7521, rb7522, rb7523, rb7524, rb7525, rb7526, rb7527, rb7528, rb7529, rb7530, rb7531, rb7532, rb7533, rb7534, rb7535, rb7536, rb7537, rb7538, rb7539, rb7540, rb7541, rb7542, rb7543, rb7544, rb7545, rb7546, rb7547, rb7548, rb7549, rb7550, rb7551, rb7552, rb7553, rb7554, rb7555, rb7556, rb7557, rb7558, rb7559, rb7560, rb7561, rb7562, rb7563, rb7564, rb7565, rb7566, rb7567, rb7568, rb7569, rb7570, rb7571, rb7572, rb7573, rb7574, rb7575, rb7576, rb7577, rb7578, rb7579, rb7580, rb7581, rb7582, rb7583, rb7584, rb7585, rb7586, rb7587, rb7588, rb7589, rb7590, rb7591, rb7592, rb7593, rb7594, rb7595, rb7596, rb7597, rb7598, rb7599, rb7600, rb7601, rb7602, rb7603, rb7604, rb7605, rb7606, rb7607, rb7608, rb7609, rb7610, rb7611, rb7612, rb7613, rb7614, rb7615, rb7616, rb7617, rb7618, rb7619, rb7620, rb7621, rb7622, rb7623, rb7624, rb7625, rb7626, rb7627, rb7628, rb7629, rb7630, rb7631, rb7632, rb7633, rb7634, rb7635, rb7636, rb7637, rb7638, rb7639, rb7640, rb7641, rb7642, rb7643, rb7644, rb7645, rb7646, rb7647, rb7648, rb7649, rb7650, rb7651, rb7652, rb7653, rb7654, rb7655, rb7656, rb7657, rb7658, rb7659, rb7660, rb7661, rb7662, rb7663, rb7664, rb7665, rb7666, rb7667, rb7668, rb7669, rb7670, rb7671, rb7672, rb7673, rb7674, rb7675, rb7676, rb7677, rb7678, rb7679, rb7680, rb7681, rb7682, rb7683, rb7684, rb7685, rb7686, rb7687, rb7688, rb7689, rb7690, rb7691, rb7692, rb7693, rb7694, rb7695, rb7696, rb7697, rb7698, rb7699, rb7700, rb7701, rb7702, rb7703, rb7704, rb7705, rb7706, rb7707, rb7708, rb7709, rb7710, rb7711, rb7712, rb7713, rb7714, rb7715, rb7716, rb7717, rb7718, rb7719, rb7720, rb7721, rb7722, rb7723, rb7724, rb7725, rb7726, rb7727, rb7728, rb7729, rb7730, rb7731, rb7732, rb7733, rb7734, rb7735, rb7736, rb7737, rb7738, rb7739, rb7740, rb7741, rb7742, rb7743, rb7744, rb7745, rb7746, rb7747, rb7748, rb7749, rb7750, rb7751, rb7752, rb7753, rb7754, rb7755, rb7756, rb7757, rb7758, rb7759, rb7760, rb7761, rb7762, rb7763, rb7764, rb7765, rb7766, rb7767, rb7768, rb7769, rb7770, rb7771, rb7772, rb7773, rb7774, rb7775, rb7776, rb7777, rb7778, rb7779, rb7780, rb7781, rb7782, rb7783, rb7784, rb7785, rb7786, rb7787, rb7788, rb7789, rb7790, rb7791, rb7792, rb7793, rb7794, rb7795, rb7796, rb7797, rb7798, rb7799, rb7800, rb7801, rb7802, rb7803, rb7804, rb7805, rb7806, rb7807, rb7808, rb7809, rb7810, rb7811, rb7812, rb7813, rb7814, rb7815, rb7816, rb7817, rb7818, rb7819, rb7820, rb7821, rb7822, rb7823, rb7824, rb7825, rb7826, rb7827, rb7828, rb7829, rb7830, rb7831, rb7832, rb7833, rb7834, rb7835, rb7836, rb7837, rb7838, rb7839, rb7840, rb7841, rb7842, rb7843, rb7844, rb7845, rb7846, rb7847, rb7848, rb7849, rb7850, rb7851, rb7852, rb7853, rb7854, rb7855, rb7856, rb7857, rb7858, rb7859, rb7860, rb7861, rb7862, rb7863, rb7864, rb7865, rb7866, rb7867, rb7868, rb7869, rb7870, rb7871, rb7872, rb7873, rb7874, rb7875, rb7876, rb7877, rb7878, rb7879, rb7880, rb7881, rb7882, rb7883, rb7884, rb7885, rb7886, rb7887, rb7888, rb7889, rb7890, rb7891, rb7892, rb7893, rb7894, rb7895, rb7896, rb7897, rb7898, rb7899, rb7900, rb7901, rb7902, rb7903, rb7904, rb7905, rb7906, rb7907, rb7908, rb7909, rb7910, rb7911, rb7912, rb7913, rb7914, rb7915, rb7916, rb7917, rb7918, rb7919, rb7920, rb7921, rb7922, rb7923, rb7924, rb7925, rb7926, rb7927, rb7928, rb7929, rb7930, rb7931, rb7932, rb7933, rb7934, rb7935, rb7936, rb7937, rb7938, rb7939, rb7940, rb7941, rb7942, rb7943, rb7944, rb7945, rb7946, rb7947, rb7948, rb7949, rb7950, rb7951, rb7952, rb7953, rb7954, rb7955, rb7956, rb7957, rb7958, rb7959, rb7960, rb7961, rb7962, rb7963, rb7964, rb7965, rb7966, rb7967, rb7968, rb7969, rb7970, rb7971, rb7972, rb7973, rb7974, rb7975, rb7976, rb7977, rb7978, rb7979, rb7980, rb7981, rb7982, rb7983, rb7984, rb7985, rb7986, rb7987, rb7988, rb7989, rb7990, rb7991, rb7992, rb7993, rb7994, rb7995, rb7996, rb7997, rb7998, rb7999, rb8000, rb8001, rb8002, rb8003, rb8004, rb8005, rb8006, rb8007, rb8008, rb8009, rb8010, rb8011, rb8012, rb8013, rb8014, rb8015, rb8016, rb8017, rb8018, rb8019, rb8020, rb8021, rb8022, rb8023, rb8024, rb8025, rb8026, rb8027, rb8028, rb8029, rb8030, rb8031, rb8032, rb8033, rb8034, rb8035, rb8036, rb8037, rb8038, rb8039, rb8040, rb8041, rb8042, rb8043, rb8044, rb8045, rb8046, rb8047, rb8048, rb8049, rb8050, rb8051, rb8052, rb8053, rb8054, rb8055, rb8056, rb8057, rb8058, rb8059, rb8060, rb8061, rb8062, rb8063, rb8064, rb8065, rb8066, rb8067, rb8068, rb8069, rb8070, rb8071, rb8072, rb8073, rb8074, rb8075, rb8076, rb8077, rb8078, rb8079, rb8080, rb8081, rb8082, rb8083, rb8084, rb8085, rb8086, rb8087, rb8088, rb8089, rb8090, rb8091, rb8092, rb8093, rb8094, rb8095, rb8096, rb8097, rb8098, rb8099, rb8100, rb8101, rb8102, rb8103, rb8104, rb8105, rb8106, rb8107, rb8108, rb8109, rb8110, rb8111, rb8112, rb8113, rb8114, rb8115, rb8116, rb8117, rb8118, rb8119, rb8120, rb8121, rb8122, rb8123, rb8124, rb8125, rb8126, rb8127, rb8128, rb8129, rb8130, rb8131, rb8132, rb8133, rb8134, rb8135, rb8136, rb8137, rb8138, rb8139, rb8140, rb8141, rb8142, rb8143, rb8144, rb8145, rb8146, rb8147, rb8148, rb8149, rb8150, rb8151, rb8152, rb8153, rb8154, rb8155, rb8156, rb8157, rb8158, rb8159, rb8160, rb8161, rb8162, rb8163, rb8164, rb8165, rb8166, rb8167, rb8168, rb8169, rb8170, rb8171, rb8172, rb8173, rb8174, rb8175, rb8176, rb8177, rb8178, rb8179, rb8180, rb8181, rb8182, rb8183, rb8184, rb8185, rb8186, rb8187, rb8188, rb8189, rb8190, rb8191, rb8192, rb8193, rb8194, rb8195, rb8196, rb8197, rb8198, rb8199, rb8200, rb8201, rb8202, rb8203, rb8204, rb8205, rb8206, rb8207, rb8208, rb8209, rb8210, rb8211, rb8212, rb8213, rb8214, rb8215, rb8216, rb8217, rb8218, rb8219, rb8220, rb8221, rb8222, rb8223, rb8224, rb8225, rb8226, rb8227, rb8228, rb8229, rb8230, rb8231, rb8232, rb8233, rb8234, rb8235, rb8236, rb8237, rb8238, rb8239, rb8240, rb8241, rb8242, rb8243, rb8244, rb8245, rb8246, rb8247, rb8248, rb8249, rb8250, rb8251, rb8252, rb8253, rb8254, rb8255, rb8256, rb8257, rb8258, rb8259, rb8260, rb8261, rb8262, rb8263, rb8264, rb8265, rb8266, rb8267, rb8268, rb8269, rb8270, rb8271, rb8272, rb8273, rb8274, rb8275, rb8276, rb8277, rb8278, rb8279, rb8280, rb8281, rb8282, rb8283, rb8284, rb8285, rb8286, rb8287, rb8288, rb8289, rb8290, rb8291, rb8292, rb8293, rb8294, rb8295, rb8296, rb8297, rb8298, rb8299, rb8300, rb8301, rb8302, rb8303, rb8304, rb8305, rb8306, rb8307, rb8308, rb8309, rb8310, rb8311, rb8312, rb8313, rb8314, rb8315, rb8316, rb8317, rb8318, rb8319, rb8320, rb8321, rb8322, rb8323, rb8324, rb8325, rb8326, rb8327, rb8328, rb8329, rb8330, rb8331, rb8332, rb8333, rb8334, rb8335, rb8336, rb8337, rb8338, rb8339, rb8340, rb8341, rb8342, rb8343, rb8344, rb8345, rb8346, rb8347, rb8348, rb8349, rb8350, rb8351, rb8352, rb8353, rb8354, rb8355, rb8356, rb8357, rb8358, rb8359, rb8360, rb8361, rb8362, rb8363, rb8364, rb8365, rb8366, rb8367, rb8368, rb8369, rb8370, rb8371, rb8372, rb8373, rb8374, rb8375, rb8376, rb8377, rb8378, rb8379, rb8380, rb8381, rb8382, rb8383, rb8384, rb8385, rb8386, rb8387, rb8388, rb8389, rb8390, rb8391, rb8392, rb8393, rb8394, rb8395, rb8396, rb8397, rb8398, rb8399, rb8400, rb8401, rb8402, rb8403, rb8404, rb8405, rb8406, rb8407, rb8408, rb8409, rb8410, rb8411, rb8412, rb8413, rb8414, rb8415, rb8416, rb8417, rb8418, rb8419, rb8420, rb8421, rb8422, rb8423, rb8424, rb8425, rb8426, rb8427, rb8428, rb8429, rb8430, rb8431, rb8432, rb8433, rb8434, rb8435, rb8436, rb8437, rb8438, rb8439, rb8440, rb8441, rb8442, rb8443, rb8444, rb8445, rb8446, rb8447, rb8448, rb8449, rb8450, rb8451, rb8452, rb8453, rb8454, rb8455, rb8456, rb8457, rb8458, rb8459, rb8460, rb8461, rb8462, rb8463, rb8464, rb8465, rb8466, rb8467, rb8468, rb8469, rb8470, rb8471, rb8472, rb8473, rb8474, rb8475, rb8476, rb8477, rb8478, rb8479, rb8480, rb8481, rb8482, rb8483, rb8484, rb8485, rb8486, rb8487, rb8488, rb8489, rb8490, rb8491, rb8492, rb8493, rb8494, rb8495, rb8496, rb8497, rb8498, rb8499, rb8500, rb8501, rb8502, rb8503, rb8504, rb8505, rb8506, rb8507, rb8508, rb8509, rb8510, rb8511, rb8512, rb8513, rb8514, rb8515, rb8516, rb8517, rb8518, rb8519, rb8520, rb8521, rb8522, rb8523, rb8524, rb8525, rb8526, rb8527, rb8528, rb8529, rb8530, rb8531, rb8532, rb8533, rb8534, rb8535, rb8536, rb8537, rb8538, rb8539, rb8540, rb8541, rb8542, rb8543, rb8544, rb8545, rb8546, rb8547, rb8548, rb8549, rb8550, rb8551, rb8552, rb8553, rb8554, rb8555, rb8556, rb8557, rb8558, rb8559, rb8560, rb8561, rb8562, rb8563, rb8564, rb8565, rb8566, rb8567, rb8568, rb8569, rb8570, rb8571, rb8572, rb8573, rb8574, rb8575, rb8576, rb8577, rb8578, rb8579, rb8580, rb8581, rb8582, rb8583, rb8584, rb8585, rb8586, rb8587, rb8588, rb8589, rb8590, rb8591, rb8592, rb8593, rb8594, rb8595, rb8596, rb8597, rb8598, rb8599, rb8600, rb8601, rb8602, rb8603, rb8604, rb8605, rb8606, rb8607, rb8608, rb8609, rb8610, rb8611, rb8612, rb8613, rb8614, rb8615, rb8616, rb8617, rb8618, rb8619, rb8620, rb8621, rb8622, rb8623, rb8624, rb8625, rb8626, rb8627, rb8628, rb8629, rb8630, rb8631, rb8632, rb8633, rb8634, rb8635, rb8636, rb8637, rb8638, rb8639, rb8640, rb8641, rb8642, rb8643, rb8644, rb8645, rb8646, rb8647, rb8648, rb8649, rb8650, rb8651, rb8652, rb8653, rb8654, rb8655, rb8656, rb8657, rb8658, rb8659, rb8660, rb8661, rb8662, rb8663, rb8664, rb8665, rb8666, rb8667, rb8668, rb8669, rb8670, rb8671, rb8672, rb8673, rb8674, rb8675, rb8676, rb8677, rb8678, rb8679, rb8680, rb8681, rb8682, rb8683, rb8684, rb8685, rb8686, rb8687, rb8688, rb8689, rb8690, rb8691, rb8692, rb8693, rb8694, rb8695, rb8696, rb8697, rb8698, rb8699, rb8700, rb8701, rb8702, rb8703, rb8704, rb8705, rb8706, rb8707, rb8708, rb8709, rb8710, rb8711, rb8712, rb8713, rb8714, rb8715, rb8716, rb8717, rb8718, rb8719, rb8720, rb8721, rb8722, rb8723, rb8724, rb8725, rb8726, rb8727, rb8728, rb8729, rb8730, rb8731, rb8732, rb8733, rb8734, rb8735, rb8736, rb8737, rb8738, rb8739, rb8740, rb8741, rb8742, rb8743, rb8744, rb8745, rb8746, rb8747, rb8748, rb8749, rb8750, rb8751, rb8752, rb8753, rb8754, rb8755, rb8756, rb8757, rb8758, rb8759, rb8760, rb8761, rb8762, rb8763, rb8764, rb8765, rb8766, rb8767, rb8768, rb8769, rb8770, rb8771, rb8772, rb8773, rb8774, rb8775, rb8776, rb8777, rb8778, rb8779, rb8780, rb8781, rb8782, rb8783, rb8784, rb8785, rb8786, rb8787, rb8788, rb8789, rb8790, rb8791, rb8792, rb8793, rb8794, rb8795, rb8796, rb8797, rb8798, rb8799, rb8800, rb8801, rb8802, rb8803, rb8804, rb8805, rb8806, rb8807, rb8808, rb8809, rb8810, rb8811, rb8812, rb8813, rb8814, rb8815, rb8816, rb8817, rb8818, rb8819, rb8820, rb8821, rb8822, rb8823, rb8824, rb8825, rb8826, rb8827, rb8828, rb8829, rb8830, rb8831, rb8832, rb8833, rb8834, rb8835, rb8836, rb8837, rb8838, rb8839, rb8840, rb8841, rb8842, rb8843, rb8844, rb8845, rb8846, rb8847, rb8848, rb8849, rb8850, rb8851, rb8852, rb8853, rb8854, rb8855, rb8856, rb8857, rb8858, rb8859, rb8860, rb8861, rb8862, rb8863, rb8864, rb8865, rb8866, rb8867, rb8868, rb8869, rb8870, rb8871, rb8872, rb8873, rb8874, rb8875, rb8876, rb8877, rb8878, rb8879, rb8880, rb8881, rb8882, rb8883, rb8884, rb8885, rb8886, rb8887, rb8888, rb8889, rb8890, rb8891, rb8892, rb8893, rb8894, rb8895, rb8896, rb8897, rb8898, rb8899, rb8900, rb8901, rb8902, rb8903, rb8904, rb8905, rb8906, rb8907, rb8908, rb8909, rb8910, rb8911, rb8912, rb8913, rb8914, rb8915, rb8916, rb8917, rb8918, rb8919, rb8920, rb8921, rb8922, rb8923, rb8924, rb8925, rb8926, rb8927, rb8928, rb8929, rb8930, rb8931, rb8932, rb8933, rb8934, rb8935, rb8936, rb8937, rb8938, rb8939, rb8940, rb8941, rb8942, rb8943, rb8944, rb8945, rb8946, rb8947, rb8948, rb8949, rb8950, rb8951, rb8952, rb8953, rb8954, rb8955, rb8956, rb8957, rb8958, rb8959, rb8960, rb8961, rb8962, rb8963, rb8964, rb8965, rb8966, rb8967, rb8968, rb8969, rb8970, rb8971, rb8972, rb8973, rb8974, rb8975, rb8976, rb8977, rb8978, rb8979, rb8980, rb8981, rb8982, rb8983, rb8984, rb8985, rb8986, rb8987, rb8988, rb8989, rb8990, rb8991, rb8992, rb8993, rb8994, rb8995, rb8996, rb8997, rb8998, rb8999, rb9000, rb9001, rb9002, rb9003, rb9004, rb9005, rb9006, rb9007, rb9008, rb9009, rb9010, rb9011, rb9012, rb9013, rb9014, rb9015, rb9016, rb9017, rb9018, rb9019, rb9020, rb9021, rb9022, rb9023, rb9024, rb9025, rb9026, rb9027, rb9028, rb9029, rb9030, rb9031, rb9032, rb9033, rb9034, rb9035, rb9036, rb9037, rb9038, rb9039, rb9040, rb9041, rb9042, rb9043, rb9044, rb9045, rb9046, rb9047, rb9048, rb9049, rb9050, rb9051, rb9052, rb9053, rb9054, rb9055, rb9056, rb9057, rb9058, rb9059, rb9060, rb9061, rb9062, rb9063, rb9064, rb9065, rb9066, rb9067, rb9068, rb9069, rb9070, rb9071, rb9072, rb9073, rb9074, rb9075, rb9076, rb9077, rb9078, rb9079, rb9080, rb9081, rb9082, rb9083, rb9084, rb9085, rb9086, rb9087, rb9088, rb9089, rb9090, rb9091, rb9092, rb9093, rb9094, rb9095, rb9096, rb9097, rb9098, rb9099, rb9100, rb9101, rb9102, rb9103, rb9104, rb9105, rb9106, rb9107, rb9108, rb9109, rb9110, rb9111, rb9112, rb9113, rb9114, rb9115, rb9116, rb9117, rb9118, rb9119, rb9120, rb9121, rb9122, rb9123, rb9124, rb9125, rb9126, rb9127, rb9128, rb9129, rb9130, rb9131, rb9132, rb9133, rb9134, rb9135, rb9136, rb9137, rb9138, rb9139, rb9140, rb9141, rb9142, rb9143, rb9144, rb9145, rb9146, rb9147, rb9148, rb9149, rb9150, rb9151, rb9152, rb9153, rb9154, rb9155, rb9156, rb9157, rb9158, rb9159, rb9160, rb9161;
  assign sel0 = 1'b0 & ~b[0];
  assign sel1 = ~1'b0 & b[0];
  assign pp2 = sel0 & a[0];
  assign pp3 = sel1 & a[0];
  assign pp4 = sel0 & a[1];
  assign pp5 = sel1 & a[1];
  assign pp6 = sel0 & a[2];
  assign pp7 = sel1 & a[2];
  assign pp8 = sel0 & a[3];
  assign pp9 = sel1 & a[3];
  assign pp10 = sel0 & a[4];
  assign pp11 = sel1 & a[4];
  assign pp12 = sel0 & a[5];
  assign pp13 = sel1 & a[5];
  assign pp14 = sel0 & a[6];
  assign pp15 = sel1 & a[6];
  assign pp16 = sel0 & a[7];
  assign pp17 = sel1 & a[7];
  assign pp18 = sel0 & a[8];
  assign pp19 = sel1 & a[8];
  assign pp20 = sel0 & a[9];
  assign pp21 = sel1 & a[9];
  assign pp22 = sel0 & a[10];
  assign pp23 = sel1 & a[10];
  assign pp24 = sel0 & a[11];
  assign pp25 = sel1 & a[11];
  assign pp26 = sel0 & a[12];
  assign pp27 = sel1 & a[12];
  assign pp28 = sel0 & a[13];
  assign pp29 = sel1 & a[13];
  assign pp30 = sel0 & a[14];
  assign pp31 = sel1 & a[14];
  assign pp32 = sel0 & a[15];
  assign pp33 = sel1 & a[15];
  assign pp34 = sel0 & 1'b0;
  assign pp35 = sel1 & 1'b0;
  assign pp36 = sel0 & 1'b0;
  assign pp37 = sel1 & 1'b0;
  assign pp38 = sel0 & 1'b0;
  assign pp39 = sel1 & 1'b0;
  assign pp40 = sel0 & 1'b0;
  assign pp41 = sel1 & 1'b0;
  assign pp42 = sel0 & 1'b0;
  assign pp43 = sel1 & 1'b0;
  assign pp44 = sel0 & 1'b0;
  assign pp45 = sel1 & 1'b0;
  assign pp46 = sel0 & 1'b0;
  assign pp47 = sel1 & 1'b0;
  assign pp48 = sel0 & 1'b0;
  assign pp49 = sel1 & 1'b0;
  assign pp50 = sel0 & 1'b0;
  assign pp51 = sel1 & 1'b0;
  assign pp52 = sel0 & 1'b0;
  assign pp53 = sel1 & 1'b0;
  assign pp54 = sel0 & 1'b0;
  assign pp55 = sel1 & 1'b0;
  assign pp56 = sel0 & 1'b0;
  assign pp57 = sel1 & 1'b0;
  assign pp58 = sel0 & 1'b0;
  assign pp59 = sel1 & 1'b0;
  assign pp60 = sel0 & 1'b0;
  assign pp61 = sel1 & 1'b0;
  assign pp62 = sel0 & 1'b0;
  assign pp63 = sel1 & 1'b0;
  assign pp64 = sel0 & 1'b0;
  assign pp65 = sel1 & 1'b0;
  assign pp66 = sel0 & 1'b0;
  assign pp67 = sel1 & 1'b0;
  assign pp68 = sel0 & 1'b0;
  assign pp69 = sel1 & 1'b0;
  assign sel70 = b[0] & ~b[1];
  assign sel71 = ~b[0] & b[1];
  assign pp72 = sel70 & a[0];
  assign pp73 = sel71 & a[0];
  assign pp74 = sel70 & a[1];
  assign pp75 = sel71 & a[1];
  assign pp76 = sel70 & a[2];
  assign pp77 = sel71 & a[2];
  assign pp78 = sel70 & a[3];
  assign pp79 = sel71 & a[3];
  assign pp80 = sel70 & a[4];
  assign pp81 = sel71 & a[4];
  assign pp82 = sel70 & a[5];
  assign pp83 = sel71 & a[5];
  assign pp84 = sel70 & a[6];
  assign pp85 = sel71 & a[6];
  assign pp86 = sel70 & a[7];
  assign pp87 = sel71 & a[7];
  assign pp88 = sel70 & a[8];
  assign pp89 = sel71 & a[8];
  assign pp90 = sel70 & a[9];
  assign pp91 = sel71 & a[9];
  assign pp92 = sel70 & a[10];
  assign pp93 = sel71 & a[10];
  assign pp94 = sel70 & a[11];
  assign pp95 = sel71 & a[11];
  assign pp96 = sel70 & a[12];
  assign pp97 = sel71 & a[12];
  assign pp98 = sel70 & a[13];
  assign pp99 = sel71 & a[13];
  assign pp100 = sel70 & a[14];
  assign pp101 = sel71 & a[14];
  assign pp102 = sel70 & a[15];
  assign pp103 = sel71 & a[15];
  assign pp104 = sel70 & 1'b0;
  assign pp105 = sel71 & 1'b0;
  assign pp106 = sel70 & 1'b0;
  assign pp107 = sel71 & 1'b0;
  assign pp108 = sel70 & 1'b0;
  assign pp109 = sel71 & 1'b0;
  assign pp110 = sel70 & 1'b0;
  assign pp111 = sel71 & 1'b0;
  assign pp112 = sel70 & 1'b0;
  assign pp113 = sel71 & 1'b0;
  assign pp114 = sel70 & 1'b0;
  assign pp115 = sel71 & 1'b0;
  assign pp116 = sel70 & 1'b0;
  assign pp117 = sel71 & 1'b0;
  assign pp118 = sel70 & 1'b0;
  assign pp119 = sel71 & 1'b0;
  assign pp120 = sel70 & 1'b0;
  assign pp121 = sel71 & 1'b0;
  assign pp122 = sel70 & 1'b0;
  assign pp123 = sel71 & 1'b0;
  assign pp124 = sel70 & 1'b0;
  assign pp125 = sel71 & 1'b0;
  assign pp126 = sel70 & 1'b0;
  assign pp127 = sel71 & 1'b0;
  assign pp128 = sel70 & 1'b0;
  assign pp129 = sel71 & 1'b0;
  assign pp130 = sel70 & 1'b0;
  assign pp131 = sel71 & 1'b0;
  assign pp132 = sel70 & 1'b0;
  assign pp133 = sel71 & 1'b0;
  assign pp134 = sel70 & 1'b0;
  assign pp135 = sel71 & 1'b0;
  assign pp136 = sel70 & 1'b0;
  assign pp137 = sel71 & 1'b0;
  assign sel138 = b[1] & ~b[2];
  assign sel139 = ~b[1] & b[2];
  assign pp140 = sel138 & a[0];
  assign pp141 = sel139 & a[0];
  assign pp142 = sel138 & a[1];
  assign pp143 = sel139 & a[1];
  assign pp144 = sel138 & a[2];
  assign pp145 = sel139 & a[2];
  assign pp146 = sel138 & a[3];
  assign pp147 = sel139 & a[3];
  assign pp148 = sel138 & a[4];
  assign pp149 = sel139 & a[4];
  assign pp150 = sel138 & a[5];
  assign pp151 = sel139 & a[5];
  assign pp152 = sel138 & a[6];
  assign pp153 = sel139 & a[6];
  assign pp154 = sel138 & a[7];
  assign pp155 = sel139 & a[7];
  assign pp156 = sel138 & a[8];
  assign pp157 = sel139 & a[8];
  assign pp158 = sel138 & a[9];
  assign pp159 = sel139 & a[9];
  assign pp160 = sel138 & a[10];
  assign pp161 = sel139 & a[10];
  assign pp162 = sel138 & a[11];
  assign pp163 = sel139 & a[11];
  assign pp164 = sel138 & a[12];
  assign pp165 = sel139 & a[12];
  assign pp166 = sel138 & a[13];
  assign pp167 = sel139 & a[13];
  assign pp168 = sel138 & a[14];
  assign pp169 = sel139 & a[14];
  assign pp170 = sel138 & a[15];
  assign pp171 = sel139 & a[15];
  assign pp172 = sel138 & 1'b0;
  assign pp173 = sel139 & 1'b0;
  assign pp174 = sel138 & 1'b0;
  assign pp175 = sel139 & 1'b0;
  assign pp176 = sel138 & 1'b0;
  assign pp177 = sel139 & 1'b0;
  assign pp178 = sel138 & 1'b0;
  assign pp179 = sel139 & 1'b0;
  assign pp180 = sel138 & 1'b0;
  assign pp181 = sel139 & 1'b0;
  assign pp182 = sel138 & 1'b0;
  assign pp183 = sel139 & 1'b0;
  assign pp184 = sel138 & 1'b0;
  assign pp185 = sel139 & 1'b0;
  assign pp186 = sel138 & 1'b0;
  assign pp187 = sel139 & 1'b0;
  assign pp188 = sel138 & 1'b0;
  assign pp189 = sel139 & 1'b0;
  assign pp190 = sel138 & 1'b0;
  assign pp191 = sel139 & 1'b0;
  assign pp192 = sel138 & 1'b0;
  assign pp193 = sel139 & 1'b0;
  assign pp194 = sel138 & 1'b0;
  assign pp195 = sel139 & 1'b0;
  assign pp196 = sel138 & 1'b0;
  assign pp197 = sel139 & 1'b0;
  assign pp198 = sel138 & 1'b0;
  assign pp199 = sel139 & 1'b0;
  assign pp200 = sel138 & 1'b0;
  assign pp201 = sel139 & 1'b0;
  assign pp202 = sel138 & 1'b0;
  assign pp203 = sel139 & 1'b0;
  assign sel204 = b[2] & ~b[3];
  assign sel205 = ~b[2] & b[3];
  assign pp206 = sel204 & a[0];
  assign pp207 = sel205 & a[0];
  assign pp208 = sel204 & a[1];
  assign pp209 = sel205 & a[1];
  assign pp210 = sel204 & a[2];
  assign pp211 = sel205 & a[2];
  assign pp212 = sel204 & a[3];
  assign pp213 = sel205 & a[3];
  assign pp214 = sel204 & a[4];
  assign pp215 = sel205 & a[4];
  assign pp216 = sel204 & a[5];
  assign pp217 = sel205 & a[5];
  assign pp218 = sel204 & a[6];
  assign pp219 = sel205 & a[6];
  assign pp220 = sel204 & a[7];
  assign pp221 = sel205 & a[7];
  assign pp222 = sel204 & a[8];
  assign pp223 = sel205 & a[8];
  assign pp224 = sel204 & a[9];
  assign pp225 = sel205 & a[9];
  assign pp226 = sel204 & a[10];
  assign pp227 = sel205 & a[10];
  assign pp228 = sel204 & a[11];
  assign pp229 = sel205 & a[11];
  assign pp230 = sel204 & a[12];
  assign pp231 = sel205 & a[12];
  assign pp232 = sel204 & a[13];
  assign pp233 = sel205 & a[13];
  assign pp234 = sel204 & a[14];
  assign pp235 = sel205 & a[14];
  assign pp236 = sel204 & a[15];
  assign pp237 = sel205 & a[15];
  assign pp238 = sel204 & 1'b0;
  assign pp239 = sel205 & 1'b0;
  assign pp240 = sel204 & 1'b0;
  assign pp241 = sel205 & 1'b0;
  assign pp242 = sel204 & 1'b0;
  assign pp243 = sel205 & 1'b0;
  assign pp244 = sel204 & 1'b0;
  assign pp245 = sel205 & 1'b0;
  assign pp246 = sel204 & 1'b0;
  assign pp247 = sel205 & 1'b0;
  assign pp248 = sel204 & 1'b0;
  assign pp249 = sel205 & 1'b0;
  assign pp250 = sel204 & 1'b0;
  assign pp251 = sel205 & 1'b0;
  assign pp252 = sel204 & 1'b0;
  assign pp253 = sel205 & 1'b0;
  assign pp254 = sel204 & 1'b0;
  assign pp255 = sel205 & 1'b0;
  assign pp256 = sel204 & 1'b0;
  assign pp257 = sel205 & 1'b0;
  assign pp258 = sel204 & 1'b0;
  assign pp259 = sel205 & 1'b0;
  assign pp260 = sel204 & 1'b0;
  assign pp261 = sel205 & 1'b0;
  assign pp262 = sel204 & 1'b0;
  assign pp263 = sel205 & 1'b0;
  assign pp264 = sel204 & 1'b0;
  assign pp265 = sel205 & 1'b0;
  assign pp266 = sel204 & 1'b0;
  assign pp267 = sel205 & 1'b0;
  assign sel268 = b[3] & ~b[4];
  assign sel269 = ~b[3] & b[4];
  assign pp270 = sel268 & a[0];
  assign pp271 = sel269 & a[0];
  assign pp272 = sel268 & a[1];
  assign pp273 = sel269 & a[1];
  assign pp274 = sel268 & a[2];
  assign pp275 = sel269 & a[2];
  assign pp276 = sel268 & a[3];
  assign pp277 = sel269 & a[3];
  assign pp278 = sel268 & a[4];
  assign pp279 = sel269 & a[4];
  assign pp280 = sel268 & a[5];
  assign pp281 = sel269 & a[5];
  assign pp282 = sel268 & a[6];
  assign pp283 = sel269 & a[6];
  assign pp284 = sel268 & a[7];
  assign pp285 = sel269 & a[7];
  assign pp286 = sel268 & a[8];
  assign pp287 = sel269 & a[8];
  assign pp288 = sel268 & a[9];
  assign pp289 = sel269 & a[9];
  assign pp290 = sel268 & a[10];
  assign pp291 = sel269 & a[10];
  assign pp292 = sel268 & a[11];
  assign pp293 = sel269 & a[11];
  assign pp294 = sel268 & a[12];
  assign pp295 = sel269 & a[12];
  assign pp296 = sel268 & a[13];
  assign pp297 = sel269 & a[13];
  assign pp298 = sel268 & a[14];
  assign pp299 = sel269 & a[14];
  assign pp300 = sel268 & a[15];
  assign pp301 = sel269 & a[15];
  assign pp302 = sel268 & 1'b0;
  assign pp303 = sel269 & 1'b0;
  assign pp304 = sel268 & 1'b0;
  assign pp305 = sel269 & 1'b0;
  assign pp306 = sel268 & 1'b0;
  assign pp307 = sel269 & 1'b0;
  assign pp308 = sel268 & 1'b0;
  assign pp309 = sel269 & 1'b0;
  assign pp310 = sel268 & 1'b0;
  assign pp311 = sel269 & 1'b0;
  assign pp312 = sel268 & 1'b0;
  assign pp313 = sel269 & 1'b0;
  assign pp314 = sel268 & 1'b0;
  assign pp315 = sel269 & 1'b0;
  assign pp316 = sel268 & 1'b0;
  assign pp317 = sel269 & 1'b0;
  assign pp318 = sel268 & 1'b0;
  assign pp319 = sel269 & 1'b0;
  assign pp320 = sel268 & 1'b0;
  assign pp321 = sel269 & 1'b0;
  assign pp322 = sel268 & 1'b0;
  assign pp323 = sel269 & 1'b0;
  assign pp324 = sel268 & 1'b0;
  assign pp325 = sel269 & 1'b0;
  assign pp326 = sel268 & 1'b0;
  assign pp327 = sel269 & 1'b0;
  assign pp328 = sel268 & 1'b0;
  assign pp329 = sel269 & 1'b0;
  assign sel330 = b[4] & ~b[5];
  assign sel331 = ~b[4] & b[5];
  assign pp332 = sel330 & a[0];
  assign pp333 = sel331 & a[0];
  assign pp334 = sel330 & a[1];
  assign pp335 = sel331 & a[1];
  assign pp336 = sel330 & a[2];
  assign pp337 = sel331 & a[2];
  assign pp338 = sel330 & a[3];
  assign pp339 = sel331 & a[3];
  assign pp340 = sel330 & a[4];
  assign pp341 = sel331 & a[4];
  assign pp342 = sel330 & a[5];
  assign pp343 = sel331 & a[5];
  assign pp344 = sel330 & a[6];
  assign pp345 = sel331 & a[6];
  assign pp346 = sel330 & a[7];
  assign pp347 = sel331 & a[7];
  assign pp348 = sel330 & a[8];
  assign pp349 = sel331 & a[8];
  assign pp350 = sel330 & a[9];
  assign pp351 = sel331 & a[9];
  assign pp352 = sel330 & a[10];
  assign pp353 = sel331 & a[10];
  assign pp354 = sel330 & a[11];
  assign pp355 = sel331 & a[11];
  assign pp356 = sel330 & a[12];
  assign pp357 = sel331 & a[12];
  assign pp358 = sel330 & a[13];
  assign pp359 = sel331 & a[13];
  assign pp360 = sel330 & a[14];
  assign pp361 = sel331 & a[14];
  assign pp362 = sel330 & a[15];
  assign pp363 = sel331 & a[15];
  assign pp364 = sel330 & 1'b0;
  assign pp365 = sel331 & 1'b0;
  assign pp366 = sel330 & 1'b0;
  assign pp367 = sel331 & 1'b0;
  assign pp368 = sel330 & 1'b0;
  assign pp369 = sel331 & 1'b0;
  assign pp370 = sel330 & 1'b0;
  assign pp371 = sel331 & 1'b0;
  assign pp372 = sel330 & 1'b0;
  assign pp373 = sel331 & 1'b0;
  assign pp374 = sel330 & 1'b0;
  assign pp375 = sel331 & 1'b0;
  assign pp376 = sel330 & 1'b0;
  assign pp377 = sel331 & 1'b0;
  assign pp378 = sel330 & 1'b0;
  assign pp379 = sel331 & 1'b0;
  assign pp380 = sel330 & 1'b0;
  assign pp381 = sel331 & 1'b0;
  assign pp382 = sel330 & 1'b0;
  assign pp383 = sel331 & 1'b0;
  assign pp384 = sel330 & 1'b0;
  assign pp385 = sel331 & 1'b0;
  assign pp386 = sel330 & 1'b0;
  assign pp387 = sel331 & 1'b0;
  assign pp388 = sel330 & 1'b0;
  assign pp389 = sel331 & 1'b0;
  assign sel390 = b[5] & ~b[6];
  assign sel391 = ~b[5] & b[6];
  assign pp392 = sel390 & a[0];
  assign pp393 = sel391 & a[0];
  assign pp394 = sel390 & a[1];
  assign pp395 = sel391 & a[1];
  assign pp396 = sel390 & a[2];
  assign pp397 = sel391 & a[2];
  assign pp398 = sel390 & a[3];
  assign pp399 = sel391 & a[3];
  assign pp400 = sel390 & a[4];
  assign pp401 = sel391 & a[4];
  assign pp402 = sel390 & a[5];
  assign pp403 = sel391 & a[5];
  assign pp404 = sel390 & a[6];
  assign pp405 = sel391 & a[6];
  assign pp406 = sel390 & a[7];
  assign pp407 = sel391 & a[7];
  assign pp408 = sel390 & a[8];
  assign pp409 = sel391 & a[8];
  assign pp410 = sel390 & a[9];
  assign pp411 = sel391 & a[9];
  assign pp412 = sel390 & a[10];
  assign pp413 = sel391 & a[10];
  assign pp414 = sel390 & a[11];
  assign pp415 = sel391 & a[11];
  assign pp416 = sel390 & a[12];
  assign pp417 = sel391 & a[12];
  assign pp418 = sel390 & a[13];
  assign pp419 = sel391 & a[13];
  assign pp420 = sel390 & a[14];
  assign pp421 = sel391 & a[14];
  assign pp422 = sel390 & a[15];
  assign pp423 = sel391 & a[15];
  assign pp424 = sel390 & 1'b0;
  assign pp425 = sel391 & 1'b0;
  assign pp426 = sel390 & 1'b0;
  assign pp427 = sel391 & 1'b0;
  assign pp428 = sel390 & 1'b0;
  assign pp429 = sel391 & 1'b0;
  assign pp430 = sel390 & 1'b0;
  assign pp431 = sel391 & 1'b0;
  assign pp432 = sel390 & 1'b0;
  assign pp433 = sel391 & 1'b0;
  assign pp434 = sel390 & 1'b0;
  assign pp435 = sel391 & 1'b0;
  assign pp436 = sel390 & 1'b0;
  assign pp437 = sel391 & 1'b0;
  assign pp438 = sel390 & 1'b0;
  assign pp439 = sel391 & 1'b0;
  assign pp440 = sel390 & 1'b0;
  assign pp441 = sel391 & 1'b0;
  assign pp442 = sel390 & 1'b0;
  assign pp443 = sel391 & 1'b0;
  assign pp444 = sel390 & 1'b0;
  assign pp445 = sel391 & 1'b0;
  assign pp446 = sel390 & 1'b0;
  assign pp447 = sel391 & 1'b0;
  assign sel448 = b[6] & ~b[7];
  assign sel449 = ~b[6] & b[7];
  assign pp450 = sel448 & a[0];
  assign pp451 = sel449 & a[0];
  assign pp452 = sel448 & a[1];
  assign pp453 = sel449 & a[1];
  assign pp454 = sel448 & a[2];
  assign pp455 = sel449 & a[2];
  assign pp456 = sel448 & a[3];
  assign pp457 = sel449 & a[3];
  assign pp458 = sel448 & a[4];
  assign pp459 = sel449 & a[4];
  assign pp460 = sel448 & a[5];
  assign pp461 = sel449 & a[5];
  assign pp462 = sel448 & a[6];
  assign pp463 = sel449 & a[6];
  assign pp464 = sel448 & a[7];
  assign pp465 = sel449 & a[7];
  assign pp466 = sel448 & a[8];
  assign pp467 = sel449 & a[8];
  assign pp468 = sel448 & a[9];
  assign pp469 = sel449 & a[9];
  assign pp470 = sel448 & a[10];
  assign pp471 = sel449 & a[10];
  assign pp472 = sel448 & a[11];
  assign pp473 = sel449 & a[11];
  assign pp474 = sel448 & a[12];
  assign pp475 = sel449 & a[12];
  assign pp476 = sel448 & a[13];
  assign pp477 = sel449 & a[13];
  assign pp478 = sel448 & a[14];
  assign pp479 = sel449 & a[14];
  assign pp480 = sel448 & a[15];
  assign pp481 = sel449 & a[15];
  assign pp482 = sel448 & 1'b0;
  assign pp483 = sel449 & 1'b0;
  assign pp484 = sel448 & 1'b0;
  assign pp485 = sel449 & 1'b0;
  assign pp486 = sel448 & 1'b0;
  assign pp487 = sel449 & 1'b0;
  assign pp488 = sel448 & 1'b0;
  assign pp489 = sel449 & 1'b0;
  assign pp490 = sel448 & 1'b0;
  assign pp491 = sel449 & 1'b0;
  assign pp492 = sel448 & 1'b0;
  assign pp493 = sel449 & 1'b0;
  assign pp494 = sel448 & 1'b0;
  assign pp495 = sel449 & 1'b0;
  assign pp496 = sel448 & 1'b0;
  assign pp497 = sel449 & 1'b0;
  assign pp498 = sel448 & 1'b0;
  assign pp499 = sel449 & 1'b0;
  assign pp500 = sel448 & 1'b0;
  assign pp501 = sel449 & 1'b0;
  assign pp502 = sel448 & 1'b0;
  assign pp503 = sel449 & 1'b0;
  assign sel504 = b[7] & ~b[8];
  assign sel505 = ~b[7] & b[8];
  assign pp506 = sel504 & a[0];
  assign pp507 = sel505 & a[0];
  assign pp508 = sel504 & a[1];
  assign pp509 = sel505 & a[1];
  assign pp510 = sel504 & a[2];
  assign pp511 = sel505 & a[2];
  assign pp512 = sel504 & a[3];
  assign pp513 = sel505 & a[3];
  assign pp514 = sel504 & a[4];
  assign pp515 = sel505 & a[4];
  assign pp516 = sel504 & a[5];
  assign pp517 = sel505 & a[5];
  assign pp518 = sel504 & a[6];
  assign pp519 = sel505 & a[6];
  assign pp520 = sel504 & a[7];
  assign pp521 = sel505 & a[7];
  assign pp522 = sel504 & a[8];
  assign pp523 = sel505 & a[8];
  assign pp524 = sel504 & a[9];
  assign pp525 = sel505 & a[9];
  assign pp526 = sel504 & a[10];
  assign pp527 = sel505 & a[10];
  assign pp528 = sel504 & a[11];
  assign pp529 = sel505 & a[11];
  assign pp530 = sel504 & a[12];
  assign pp531 = sel505 & a[12];
  assign pp532 = sel504 & a[13];
  assign pp533 = sel505 & a[13];
  assign pp534 = sel504 & a[14];
  assign pp535 = sel505 & a[14];
  assign pp536 = sel504 & a[15];
  assign pp537 = sel505 & a[15];
  assign pp538 = sel504 & 1'b0;
  assign pp539 = sel505 & 1'b0;
  assign pp540 = sel504 & 1'b0;
  assign pp541 = sel505 & 1'b0;
  assign pp542 = sel504 & 1'b0;
  assign pp543 = sel505 & 1'b0;
  assign pp544 = sel504 & 1'b0;
  assign pp545 = sel505 & 1'b0;
  assign pp546 = sel504 & 1'b0;
  assign pp547 = sel505 & 1'b0;
  assign pp548 = sel504 & 1'b0;
  assign pp549 = sel505 & 1'b0;
  assign pp550 = sel504 & 1'b0;
  assign pp551 = sel505 & 1'b0;
  assign pp552 = sel504 & 1'b0;
  assign pp553 = sel505 & 1'b0;
  assign pp554 = sel504 & 1'b0;
  assign pp555 = sel505 & 1'b0;
  assign pp556 = sel504 & 1'b0;
  assign pp557 = sel505 & 1'b0;
  assign sel558 = b[8] & ~b[9];
  assign sel559 = ~b[8] & b[9];
  assign pp560 = sel558 & a[0];
  assign pp561 = sel559 & a[0];
  assign pp562 = sel558 & a[1];
  assign pp563 = sel559 & a[1];
  assign pp564 = sel558 & a[2];
  assign pp565 = sel559 & a[2];
  assign pp566 = sel558 & a[3];
  assign pp567 = sel559 & a[3];
  assign pp568 = sel558 & a[4];
  assign pp569 = sel559 & a[4];
  assign pp570 = sel558 & a[5];
  assign pp571 = sel559 & a[5];
  assign pp572 = sel558 & a[6];
  assign pp573 = sel559 & a[6];
  assign pp574 = sel558 & a[7];
  assign pp575 = sel559 & a[7];
  assign pp576 = sel558 & a[8];
  assign pp577 = sel559 & a[8];
  assign pp578 = sel558 & a[9];
  assign pp579 = sel559 & a[9];
  assign pp580 = sel558 & a[10];
  assign pp581 = sel559 & a[10];
  assign pp582 = sel558 & a[11];
  assign pp583 = sel559 & a[11];
  assign pp584 = sel558 & a[12];
  assign pp585 = sel559 & a[12];
  assign pp586 = sel558 & a[13];
  assign pp587 = sel559 & a[13];
  assign pp588 = sel558 & a[14];
  assign pp589 = sel559 & a[14];
  assign pp590 = sel558 & a[15];
  assign pp591 = sel559 & a[15];
  assign pp592 = sel558 & 1'b0;
  assign pp593 = sel559 & 1'b0;
  assign pp594 = sel558 & 1'b0;
  assign pp595 = sel559 & 1'b0;
  assign pp596 = sel558 & 1'b0;
  assign pp597 = sel559 & 1'b0;
  assign pp598 = sel558 & 1'b0;
  assign pp599 = sel559 & 1'b0;
  assign pp600 = sel558 & 1'b0;
  assign pp601 = sel559 & 1'b0;
  assign pp602 = sel558 & 1'b0;
  assign pp603 = sel559 & 1'b0;
  assign pp604 = sel558 & 1'b0;
  assign pp605 = sel559 & 1'b0;
  assign pp606 = sel558 & 1'b0;
  assign pp607 = sel559 & 1'b0;
  assign pp608 = sel558 & 1'b0;
  assign pp609 = sel559 & 1'b0;
  assign sel610 = b[9] & ~b[10];
  assign sel611 = ~b[9] & b[10];
  assign pp612 = sel610 & a[0];
  assign pp613 = sel611 & a[0];
  assign pp614 = sel610 & a[1];
  assign pp615 = sel611 & a[1];
  assign pp616 = sel610 & a[2];
  assign pp617 = sel611 & a[2];
  assign pp618 = sel610 & a[3];
  assign pp619 = sel611 & a[3];
  assign pp620 = sel610 & a[4];
  assign pp621 = sel611 & a[4];
  assign pp622 = sel610 & a[5];
  assign pp623 = sel611 & a[5];
  assign pp624 = sel610 & a[6];
  assign pp625 = sel611 & a[6];
  assign pp626 = sel610 & a[7];
  assign pp627 = sel611 & a[7];
  assign pp628 = sel610 & a[8];
  assign pp629 = sel611 & a[8];
  assign pp630 = sel610 & a[9];
  assign pp631 = sel611 & a[9];
  assign pp632 = sel610 & a[10];
  assign pp633 = sel611 & a[10];
  assign pp634 = sel610 & a[11];
  assign pp635 = sel611 & a[11];
  assign pp636 = sel610 & a[12];
  assign pp637 = sel611 & a[12];
  assign pp638 = sel610 & a[13];
  assign pp639 = sel611 & a[13];
  assign pp640 = sel610 & a[14];
  assign pp641 = sel611 & a[14];
  assign pp642 = sel610 & a[15];
  assign pp643 = sel611 & a[15];
  assign pp644 = sel610 & 1'b0;
  assign pp645 = sel611 & 1'b0;
  assign pp646 = sel610 & 1'b0;
  assign pp647 = sel611 & 1'b0;
  assign pp648 = sel610 & 1'b0;
  assign pp649 = sel611 & 1'b0;
  assign pp650 = sel610 & 1'b0;
  assign pp651 = sel611 & 1'b0;
  assign pp652 = sel610 & 1'b0;
  assign pp653 = sel611 & 1'b0;
  assign pp654 = sel610 & 1'b0;
  assign pp655 = sel611 & 1'b0;
  assign pp656 = sel610 & 1'b0;
  assign pp657 = sel611 & 1'b0;
  assign pp658 = sel610 & 1'b0;
  assign pp659 = sel611 & 1'b0;
  assign sel660 = b[10] & ~b[11];
  assign sel661 = ~b[10] & b[11];
  assign pp662 = sel660 & a[0];
  assign pp663 = sel661 & a[0];
  assign pp664 = sel660 & a[1];
  assign pp665 = sel661 & a[1];
  assign pp666 = sel660 & a[2];
  assign pp667 = sel661 & a[2];
  assign pp668 = sel660 & a[3];
  assign pp669 = sel661 & a[3];
  assign pp670 = sel660 & a[4];
  assign pp671 = sel661 & a[4];
  assign pp672 = sel660 & a[5];
  assign pp673 = sel661 & a[5];
  assign pp674 = sel660 & a[6];
  assign pp675 = sel661 & a[6];
  assign pp676 = sel660 & a[7];
  assign pp677 = sel661 & a[7];
  assign pp678 = sel660 & a[8];
  assign pp679 = sel661 & a[8];
  assign pp680 = sel660 & a[9];
  assign pp681 = sel661 & a[9];
  assign pp682 = sel660 & a[10];
  assign pp683 = sel661 & a[10];
  assign pp684 = sel660 & a[11];
  assign pp685 = sel661 & a[11];
  assign pp686 = sel660 & a[12];
  assign pp687 = sel661 & a[12];
  assign pp688 = sel660 & a[13];
  assign pp689 = sel661 & a[13];
  assign pp690 = sel660 & a[14];
  assign pp691 = sel661 & a[14];
  assign pp692 = sel660 & a[15];
  assign pp693 = sel661 & a[15];
  assign pp694 = sel660 & 1'b0;
  assign pp695 = sel661 & 1'b0;
  assign pp696 = sel660 & 1'b0;
  assign pp697 = sel661 & 1'b0;
  assign pp698 = sel660 & 1'b0;
  assign pp699 = sel661 & 1'b0;
  assign pp700 = sel660 & 1'b0;
  assign pp701 = sel661 & 1'b0;
  assign pp702 = sel660 & 1'b0;
  assign pp703 = sel661 & 1'b0;
  assign pp704 = sel660 & 1'b0;
  assign pp705 = sel661 & 1'b0;
  assign pp706 = sel660 & 1'b0;
  assign pp707 = sel661 & 1'b0;
  assign sel708 = b[11] & ~b[12];
  assign sel709 = ~b[11] & b[12];
  assign pp710 = sel708 & a[0];
  assign pp711 = sel709 & a[0];
  assign pp712 = sel708 & a[1];
  assign pp713 = sel709 & a[1];
  assign pp714 = sel708 & a[2];
  assign pp715 = sel709 & a[2];
  assign pp716 = sel708 & a[3];
  assign pp717 = sel709 & a[3];
  assign pp718 = sel708 & a[4];
  assign pp719 = sel709 & a[4];
  assign pp720 = sel708 & a[5];
  assign pp721 = sel709 & a[5];
  assign pp722 = sel708 & a[6];
  assign pp723 = sel709 & a[6];
  assign pp724 = sel708 & a[7];
  assign pp725 = sel709 & a[7];
  assign pp726 = sel708 & a[8];
  assign pp727 = sel709 & a[8];
  assign pp728 = sel708 & a[9];
  assign pp729 = sel709 & a[9];
  assign pp730 = sel708 & a[10];
  assign pp731 = sel709 & a[10];
  assign pp732 = sel708 & a[11];
  assign pp733 = sel709 & a[11];
  assign pp734 = sel708 & a[12];
  assign pp735 = sel709 & a[12];
  assign pp736 = sel708 & a[13];
  assign pp737 = sel709 & a[13];
  assign pp738 = sel708 & a[14];
  assign pp739 = sel709 & a[14];
  assign pp740 = sel708 & a[15];
  assign pp741 = sel709 & a[15];
  assign pp742 = sel708 & 1'b0;
  assign pp743 = sel709 & 1'b0;
  assign pp744 = sel708 & 1'b0;
  assign pp745 = sel709 & 1'b0;
  assign pp746 = sel708 & 1'b0;
  assign pp747 = sel709 & 1'b0;
  assign pp748 = sel708 & 1'b0;
  assign pp749 = sel709 & 1'b0;
  assign pp750 = sel708 & 1'b0;
  assign pp751 = sel709 & 1'b0;
  assign pp752 = sel708 & 1'b0;
  assign pp753 = sel709 & 1'b0;
  assign sel754 = b[12] & ~b[13];
  assign sel755 = ~b[12] & b[13];
  assign pp756 = sel754 & a[0];
  assign pp757 = sel755 & a[0];
  assign pp758 = sel754 & a[1];
  assign pp759 = sel755 & a[1];
  assign pp760 = sel754 & a[2];
  assign pp761 = sel755 & a[2];
  assign pp762 = sel754 & a[3];
  assign pp763 = sel755 & a[3];
  assign pp764 = sel754 & a[4];
  assign pp765 = sel755 & a[4];
  assign pp766 = sel754 & a[5];
  assign pp767 = sel755 & a[5];
  assign pp768 = sel754 & a[6];
  assign pp769 = sel755 & a[6];
  assign pp770 = sel754 & a[7];
  assign pp771 = sel755 & a[7];
  assign pp772 = sel754 & a[8];
  assign pp773 = sel755 & a[8];
  assign pp774 = sel754 & a[9];
  assign pp775 = sel755 & a[9];
  assign pp776 = sel754 & a[10];
  assign pp777 = sel755 & a[10];
  assign pp778 = sel754 & a[11];
  assign pp779 = sel755 & a[11];
  assign pp780 = sel754 & a[12];
  assign pp781 = sel755 & a[12];
  assign pp782 = sel754 & a[13];
  assign pp783 = sel755 & a[13];
  assign pp784 = sel754 & a[14];
  assign pp785 = sel755 & a[14];
  assign pp786 = sel754 & a[15];
  assign pp787 = sel755 & a[15];
  assign pp788 = sel754 & 1'b0;
  assign pp789 = sel755 & 1'b0;
  assign pp790 = sel754 & 1'b0;
  assign pp791 = sel755 & 1'b0;
  assign pp792 = sel754 & 1'b0;
  assign pp793 = sel755 & 1'b0;
  assign pp794 = sel754 & 1'b0;
  assign pp795 = sel755 & 1'b0;
  assign pp796 = sel754 & 1'b0;
  assign pp797 = sel755 & 1'b0;
  assign sel798 = b[13] & ~b[14];
  assign sel799 = ~b[13] & b[14];
  assign pp800 = sel798 & a[0];
  assign pp801 = sel799 & a[0];
  assign pp802 = sel798 & a[1];
  assign pp803 = sel799 & a[1];
  assign pp804 = sel798 & a[2];
  assign pp805 = sel799 & a[2];
  assign pp806 = sel798 & a[3];
  assign pp807 = sel799 & a[3];
  assign pp808 = sel798 & a[4];
  assign pp809 = sel799 & a[4];
  assign pp810 = sel798 & a[5];
  assign pp811 = sel799 & a[5];
  assign pp812 = sel798 & a[6];
  assign pp813 = sel799 & a[6];
  assign pp814 = sel798 & a[7];
  assign pp815 = sel799 & a[7];
  assign pp816 = sel798 & a[8];
  assign pp817 = sel799 & a[8];
  assign pp818 = sel798 & a[9];
  assign pp819 = sel799 & a[9];
  assign pp820 = sel798 & a[10];
  assign pp821 = sel799 & a[10];
  assign pp822 = sel798 & a[11];
  assign pp823 = sel799 & a[11];
  assign pp824 = sel798 & a[12];
  assign pp825 = sel799 & a[12];
  assign pp826 = sel798 & a[13];
  assign pp827 = sel799 & a[13];
  assign pp828 = sel798 & a[14];
  assign pp829 = sel799 & a[14];
  assign pp830 = sel798 & a[15];
  assign pp831 = sel799 & a[15];
  assign pp832 = sel798 & 1'b0;
  assign pp833 = sel799 & 1'b0;
  assign pp834 = sel798 & 1'b0;
  assign pp835 = sel799 & 1'b0;
  assign pp836 = sel798 & 1'b0;
  assign pp837 = sel799 & 1'b0;
  assign pp838 = sel798 & 1'b0;
  assign pp839 = sel799 & 1'b0;
  assign sel840 = b[14] & ~b[15];
  assign sel841 = ~b[14] & b[15];
  assign pp842 = sel840 & a[0];
  assign pp843 = sel841 & a[0];
  assign pp844 = sel840 & a[1];
  assign pp845 = sel841 & a[1];
  assign pp846 = sel840 & a[2];
  assign pp847 = sel841 & a[2];
  assign pp848 = sel840 & a[3];
  assign pp849 = sel841 & a[3];
  assign pp850 = sel840 & a[4];
  assign pp851 = sel841 & a[4];
  assign pp852 = sel840 & a[5];
  assign pp853 = sel841 & a[5];
  assign pp854 = sel840 & a[6];
  assign pp855 = sel841 & a[6];
  assign pp856 = sel840 & a[7];
  assign pp857 = sel841 & a[7];
  assign pp858 = sel840 & a[8];
  assign pp859 = sel841 & a[8];
  assign pp860 = sel840 & a[9];
  assign pp861 = sel841 & a[9];
  assign pp862 = sel840 & a[10];
  assign pp863 = sel841 & a[10];
  assign pp864 = sel840 & a[11];
  assign pp865 = sel841 & a[11];
  assign pp866 = sel840 & a[12];
  assign pp867 = sel841 & a[12];
  assign pp868 = sel840 & a[13];
  assign pp869 = sel841 & a[13];
  assign pp870 = sel840 & a[14];
  assign pp871 = sel841 & a[14];
  assign pp872 = sel840 & a[15];
  assign pp873 = sel841 & a[15];
  assign pp874 = sel840 & 1'b0;
  assign pp875 = sel841 & 1'b0;
  assign pp876 = sel840 & 1'b0;
  assign pp877 = sel841 & 1'b0;
  assign pp878 = sel840 & 1'b0;
  assign pp879 = sel841 & 1'b0;
  assign sel880 = b[15] & ~1'b0;
  assign sel881 = ~b[15] & 1'b0;
  assign pp882 = sel880 & a[0];
  assign pp883 = sel881 & a[0];
  assign pp884 = sel880 & a[1];
  assign pp885 = sel881 & a[1];
  assign pp886 = sel880 & a[2];
  assign pp887 = sel881 & a[2];
  assign pp888 = sel880 & a[3];
  assign pp889 = sel881 & a[3];
  assign pp890 = sel880 & a[4];
  assign pp891 = sel881 & a[4];
  assign pp892 = sel880 & a[5];
  assign pp893 = sel881 & a[5];
  assign pp894 = sel880 & a[6];
  assign pp895 = sel881 & a[6];
  assign pp896 = sel880 & a[7];
  assign pp897 = sel881 & a[7];
  assign pp898 = sel880 & a[8];
  assign pp899 = sel881 & a[8];
  assign pp900 = sel880 & a[9];
  assign pp901 = sel881 & a[9];
  assign pp902 = sel880 & a[10];
  assign pp903 = sel881 & a[10];
  assign pp904 = sel880 & a[11];
  assign pp905 = sel881 & a[11];
  assign pp906 = sel880 & a[12];
  assign pp907 = sel881 & a[12];
  assign pp908 = sel880 & a[13];
  assign pp909 = sel881 & a[13];
  assign pp910 = sel880 & a[14];
  assign pp911 = sel881 & a[14];
  assign pp912 = sel880 & a[15];
  assign pp913 = sel881 & a[15];
  assign pp914 = sel880 & 1'b0;
  assign pp915 = sel881 & 1'b0;
  assign pp916 = sel880 & 1'b0;
  assign pp917 = sel881 & 1'b0;
  assign rb918 = pp2;
  assign rb919 = pp3;
  assign rb920 = 1'b0;
  assign rb921 = 1'b0;
  assign rb922 = rb918 & rb920;
  assign rb923 = rb919 & rb921;
  assign rb924 = (rb918 & ~rb920 & ~rb921) | (rb920 & ~rb918 & ~rb919);
  assign rb925 = (rb919 & ~rb920 & ~rb921) | (rb921 & ~rb918 & ~rb919);
  assign rb926 = rb922 | (rb924 & ~1'b0);
  assign rb927 = rb923 | (rb925 & 1'b0);
  assign rb928 = (rb924 | rb925) & 1'b0;
  assign rb929 = (rb924 | rb925) & ~1'b0;
  assign rb930 = pp4;
  assign rb931 = pp5;
  assign rb932 = pp72;
  assign rb933 = pp73;
  assign rb934 = pp3 | 1'b0;
  assign rb935 = rb930 & rb932;
  assign rb936 = rb931 & rb933;
  assign rb937 = (rb930 & ~rb932 & ~rb933) | (rb932 & ~rb930 & ~rb931);
  assign rb938 = (rb931 & ~rb932 & ~rb933) | (rb933 & ~rb930 & ~rb931);
  assign rb939 = rb935 | (rb937 & ~rb934);
  assign rb940 = rb936 | (rb938 & rb934);
  assign rb941 = (rb937 | rb938) & rb934;
  assign rb942 = (rb937 | rb938) & ~rb934;
  assign rb943 = pp6;
  assign rb944 = pp7;
  assign rb945 = pp74;
  assign rb946 = pp75;
  assign rb947 = pp5 | pp73;
  assign rb948 = rb943 & rb945;
  assign rb949 = rb944 & rb946;
  assign rb950 = (rb943 & ~rb945 & ~rb946) | (rb945 & ~rb943 & ~rb944);
  assign rb951 = (rb944 & ~rb945 & ~rb946) | (rb946 & ~rb943 & ~rb944);
  assign rb952 = rb948 | (rb950 & ~rb947);
  assign rb953 = rb949 | (rb951 & rb947);
  assign rb954 = (rb950 | rb951) & rb947;
  assign rb955 = (rb950 | rb951) & ~rb947;
  assign rb956 = pp8;
  assign rb957 = pp9;
  assign rb958 = pp76;
  assign rb959 = pp77;
  assign rb960 = pp7 | pp75;
  assign rb961 = rb956 & rb958;
  assign rb962 = rb957 & rb959;
  assign rb963 = (rb956 & ~rb958 & ~rb959) | (rb958 & ~rb956 & ~rb957);
  assign rb964 = (rb957 & ~rb958 & ~rb959) | (rb959 & ~rb956 & ~rb957);
  assign rb965 = rb961 | (rb963 & ~rb960);
  assign rb966 = rb962 | (rb964 & rb960);
  assign rb967 = (rb963 | rb964) & rb960;
  assign rb968 = (rb963 | rb964) & ~rb960;
  assign rb969 = pp10;
  assign rb970 = pp11;
  assign rb971 = pp78;
  assign rb972 = pp79;
  assign rb973 = pp9 | pp77;
  assign rb974 = rb969 & rb971;
  assign rb975 = rb970 & rb972;
  assign rb976 = (rb969 & ~rb971 & ~rb972) | (rb971 & ~rb969 & ~rb970);
  assign rb977 = (rb970 & ~rb971 & ~rb972) | (rb972 & ~rb969 & ~rb970);
  assign rb978 = rb974 | (rb976 & ~rb973);
  assign rb979 = rb975 | (rb977 & rb973);
  assign rb980 = (rb976 | rb977) & rb973;
  assign rb981 = (rb976 | rb977) & ~rb973;
  assign rb982 = pp12;
  assign rb983 = pp13;
  assign rb984 = pp80;
  assign rb985 = pp81;
  assign rb986 = pp11 | pp79;
  assign rb987 = rb982 & rb984;
  assign rb988 = rb983 & rb985;
  assign rb989 = (rb982 & ~rb984 & ~rb985) | (rb984 & ~rb982 & ~rb983);
  assign rb990 = (rb983 & ~rb984 & ~rb985) | (rb985 & ~rb982 & ~rb983);
  assign rb991 = rb987 | (rb989 & ~rb986);
  assign rb992 = rb988 | (rb990 & rb986);
  assign rb993 = (rb989 | rb990) & rb986;
  assign rb994 = (rb989 | rb990) & ~rb986;
  assign rb995 = pp14;
  assign rb996 = pp15;
  assign rb997 = pp82;
  assign rb998 = pp83;
  assign rb999 = pp13 | pp81;
  assign rb1000 = rb995 & rb997;
  assign rb1001 = rb996 & rb998;
  assign rb1002 = (rb995 & ~rb997 & ~rb998) | (rb997 & ~rb995 & ~rb996);
  assign rb1003 = (rb996 & ~rb997 & ~rb998) | (rb998 & ~rb995 & ~rb996);
  assign rb1004 = rb1000 | (rb1002 & ~rb999);
  assign rb1005 = rb1001 | (rb1003 & rb999);
  assign rb1006 = (rb1002 | rb1003) & rb999;
  assign rb1007 = (rb1002 | rb1003) & ~rb999;
  assign rb1008 = pp16;
  assign rb1009 = pp17;
  assign rb1010 = pp84;
  assign rb1011 = pp85;
  assign rb1012 = pp15 | pp83;
  assign rb1013 = rb1008 & rb1010;
  assign rb1014 = rb1009 & rb1011;
  assign rb1015 = (rb1008 & ~rb1010 & ~rb1011) | (rb1010 & ~rb1008 & ~rb1009);
  assign rb1016 = (rb1009 & ~rb1010 & ~rb1011) | (rb1011 & ~rb1008 & ~rb1009);
  assign rb1017 = rb1013 | (rb1015 & ~rb1012);
  assign rb1018 = rb1014 | (rb1016 & rb1012);
  assign rb1019 = (rb1015 | rb1016) & rb1012;
  assign rb1020 = (rb1015 | rb1016) & ~rb1012;
  assign rb1021 = pp18;
  assign rb1022 = pp19;
  assign rb1023 = pp86;
  assign rb1024 = pp87;
  assign rb1025 = pp17 | pp85;
  assign rb1026 = rb1021 & rb1023;
  assign rb1027 = rb1022 & rb1024;
  assign rb1028 = (rb1021 & ~rb1023 & ~rb1024) | (rb1023 & ~rb1021 & ~rb1022);
  assign rb1029 = (rb1022 & ~rb1023 & ~rb1024) | (rb1024 & ~rb1021 & ~rb1022);
  assign rb1030 = rb1026 | (rb1028 & ~rb1025);
  assign rb1031 = rb1027 | (rb1029 & rb1025);
  assign rb1032 = (rb1028 | rb1029) & rb1025;
  assign rb1033 = (rb1028 | rb1029) & ~rb1025;
  assign rb1034 = pp20;
  assign rb1035 = pp21;
  assign rb1036 = pp88;
  assign rb1037 = pp89;
  assign rb1038 = pp19 | pp87;
  assign rb1039 = rb1034 & rb1036;
  assign rb1040 = rb1035 & rb1037;
  assign rb1041 = (rb1034 & ~rb1036 & ~rb1037) | (rb1036 & ~rb1034 & ~rb1035);
  assign rb1042 = (rb1035 & ~rb1036 & ~rb1037) | (rb1037 & ~rb1034 & ~rb1035);
  assign rb1043 = rb1039 | (rb1041 & ~rb1038);
  assign rb1044 = rb1040 | (rb1042 & rb1038);
  assign rb1045 = (rb1041 | rb1042) & rb1038;
  assign rb1046 = (rb1041 | rb1042) & ~rb1038;
  assign rb1047 = pp22;
  assign rb1048 = pp23;
  assign rb1049 = pp90;
  assign rb1050 = pp91;
  assign rb1051 = pp21 | pp89;
  assign rb1052 = rb1047 & rb1049;
  assign rb1053 = rb1048 & rb1050;
  assign rb1054 = (rb1047 & ~rb1049 & ~rb1050) | (rb1049 & ~rb1047 & ~rb1048);
  assign rb1055 = (rb1048 & ~rb1049 & ~rb1050) | (rb1050 & ~rb1047 & ~rb1048);
  assign rb1056 = rb1052 | (rb1054 & ~rb1051);
  assign rb1057 = rb1053 | (rb1055 & rb1051);
  assign rb1058 = (rb1054 | rb1055) & rb1051;
  assign rb1059 = (rb1054 | rb1055) & ~rb1051;
  assign rb1060 = pp24;
  assign rb1061 = pp25;
  assign rb1062 = pp92;
  assign rb1063 = pp93;
  assign rb1064 = pp23 | pp91;
  assign rb1065 = rb1060 & rb1062;
  assign rb1066 = rb1061 & rb1063;
  assign rb1067 = (rb1060 & ~rb1062 & ~rb1063) | (rb1062 & ~rb1060 & ~rb1061);
  assign rb1068 = (rb1061 & ~rb1062 & ~rb1063) | (rb1063 & ~rb1060 & ~rb1061);
  assign rb1069 = rb1065 | (rb1067 & ~rb1064);
  assign rb1070 = rb1066 | (rb1068 & rb1064);
  assign rb1071 = (rb1067 | rb1068) & rb1064;
  assign rb1072 = (rb1067 | rb1068) & ~rb1064;
  assign rb1073 = pp26;
  assign rb1074 = pp27;
  assign rb1075 = pp94;
  assign rb1076 = pp95;
  assign rb1077 = pp25 | pp93;
  assign rb1078 = rb1073 & rb1075;
  assign rb1079 = rb1074 & rb1076;
  assign rb1080 = (rb1073 & ~rb1075 & ~rb1076) | (rb1075 & ~rb1073 & ~rb1074);
  assign rb1081 = (rb1074 & ~rb1075 & ~rb1076) | (rb1076 & ~rb1073 & ~rb1074);
  assign rb1082 = rb1078 | (rb1080 & ~rb1077);
  assign rb1083 = rb1079 | (rb1081 & rb1077);
  assign rb1084 = (rb1080 | rb1081) & rb1077;
  assign rb1085 = (rb1080 | rb1081) & ~rb1077;
  assign rb1086 = pp28;
  assign rb1087 = pp29;
  assign rb1088 = pp96;
  assign rb1089 = pp97;
  assign rb1090 = pp27 | pp95;
  assign rb1091 = rb1086 & rb1088;
  assign rb1092 = rb1087 & rb1089;
  assign rb1093 = (rb1086 & ~rb1088 & ~rb1089) | (rb1088 & ~rb1086 & ~rb1087);
  assign rb1094 = (rb1087 & ~rb1088 & ~rb1089) | (rb1089 & ~rb1086 & ~rb1087);
  assign rb1095 = rb1091 | (rb1093 & ~rb1090);
  assign rb1096 = rb1092 | (rb1094 & rb1090);
  assign rb1097 = (rb1093 | rb1094) & rb1090;
  assign rb1098 = (rb1093 | rb1094) & ~rb1090;
  assign rb1099 = pp30;
  assign rb1100 = pp31;
  assign rb1101 = pp98;
  assign rb1102 = pp99;
  assign rb1103 = pp29 | pp97;
  assign rb1104 = rb1099 & rb1101;
  assign rb1105 = rb1100 & rb1102;
  assign rb1106 = (rb1099 & ~rb1101 & ~rb1102) | (rb1101 & ~rb1099 & ~rb1100);
  assign rb1107 = (rb1100 & ~rb1101 & ~rb1102) | (rb1102 & ~rb1099 & ~rb1100);
  assign rb1108 = rb1104 | (rb1106 & ~rb1103);
  assign rb1109 = rb1105 | (rb1107 & rb1103);
  assign rb1110 = (rb1106 | rb1107) & rb1103;
  assign rb1111 = (rb1106 | rb1107) & ~rb1103;
  assign rb1112 = pp32;
  assign rb1113 = pp33;
  assign rb1114 = pp100;
  assign rb1115 = pp101;
  assign rb1116 = pp31 | pp99;
  assign rb1117 = rb1112 & rb1114;
  assign rb1118 = rb1113 & rb1115;
  assign rb1119 = (rb1112 & ~rb1114 & ~rb1115) | (rb1114 & ~rb1112 & ~rb1113);
  assign rb1120 = (rb1113 & ~rb1114 & ~rb1115) | (rb1115 & ~rb1112 & ~rb1113);
  assign rb1121 = rb1117 | (rb1119 & ~rb1116);
  assign rb1122 = rb1118 | (rb1120 & rb1116);
  assign rb1123 = (rb1119 | rb1120) & rb1116;
  assign rb1124 = (rb1119 | rb1120) & ~rb1116;
  assign rb1125 = pp34;
  assign rb1126 = pp35;
  assign rb1127 = pp102;
  assign rb1128 = pp103;
  assign rb1129 = pp33 | pp101;
  assign rb1130 = rb1125 & rb1127;
  assign rb1131 = rb1126 & rb1128;
  assign rb1132 = (rb1125 & ~rb1127 & ~rb1128) | (rb1127 & ~rb1125 & ~rb1126);
  assign rb1133 = (rb1126 & ~rb1127 & ~rb1128) | (rb1128 & ~rb1125 & ~rb1126);
  assign rb1134 = rb1130 | (rb1132 & ~rb1129);
  assign rb1135 = rb1131 | (rb1133 & rb1129);
  assign rb1136 = (rb1132 | rb1133) & rb1129;
  assign rb1137 = (rb1132 | rb1133) & ~rb1129;
  assign rb1138 = pp36;
  assign rb1139 = pp37;
  assign rb1140 = pp104;
  assign rb1141 = pp105;
  assign rb1142 = pp35 | pp103;
  assign rb1143 = rb1138 & rb1140;
  assign rb1144 = rb1139 & rb1141;
  assign rb1145 = (rb1138 & ~rb1140 & ~rb1141) | (rb1140 & ~rb1138 & ~rb1139);
  assign rb1146 = (rb1139 & ~rb1140 & ~rb1141) | (rb1141 & ~rb1138 & ~rb1139);
  assign rb1147 = rb1143 | (rb1145 & ~rb1142);
  assign rb1148 = rb1144 | (rb1146 & rb1142);
  assign rb1149 = (rb1145 | rb1146) & rb1142;
  assign rb1150 = (rb1145 | rb1146) & ~rb1142;
  assign rb1151 = pp38;
  assign rb1152 = pp39;
  assign rb1153 = pp106;
  assign rb1154 = pp107;
  assign rb1155 = pp37 | pp105;
  assign rb1156 = rb1151 & rb1153;
  assign rb1157 = rb1152 & rb1154;
  assign rb1158 = (rb1151 & ~rb1153 & ~rb1154) | (rb1153 & ~rb1151 & ~rb1152);
  assign rb1159 = (rb1152 & ~rb1153 & ~rb1154) | (rb1154 & ~rb1151 & ~rb1152);
  assign rb1160 = rb1156 | (rb1158 & ~rb1155);
  assign rb1161 = rb1157 | (rb1159 & rb1155);
  assign rb1162 = (rb1158 | rb1159) & rb1155;
  assign rb1163 = (rb1158 | rb1159) & ~rb1155;
  assign rb1164 = pp40;
  assign rb1165 = pp41;
  assign rb1166 = pp108;
  assign rb1167 = pp109;
  assign rb1168 = pp39 | pp107;
  assign rb1169 = rb1164 & rb1166;
  assign rb1170 = rb1165 & rb1167;
  assign rb1171 = (rb1164 & ~rb1166 & ~rb1167) | (rb1166 & ~rb1164 & ~rb1165);
  assign rb1172 = (rb1165 & ~rb1166 & ~rb1167) | (rb1167 & ~rb1164 & ~rb1165);
  assign rb1173 = rb1169 | (rb1171 & ~rb1168);
  assign rb1174 = rb1170 | (rb1172 & rb1168);
  assign rb1175 = (rb1171 | rb1172) & rb1168;
  assign rb1176 = (rb1171 | rb1172) & ~rb1168;
  assign rb1177 = pp42;
  assign rb1178 = pp43;
  assign rb1179 = pp110;
  assign rb1180 = pp111;
  assign rb1181 = pp41 | pp109;
  assign rb1182 = rb1177 & rb1179;
  assign rb1183 = rb1178 & rb1180;
  assign rb1184 = (rb1177 & ~rb1179 & ~rb1180) | (rb1179 & ~rb1177 & ~rb1178);
  assign rb1185 = (rb1178 & ~rb1179 & ~rb1180) | (rb1180 & ~rb1177 & ~rb1178);
  assign rb1186 = rb1182 | (rb1184 & ~rb1181);
  assign rb1187 = rb1183 | (rb1185 & rb1181);
  assign rb1188 = (rb1184 | rb1185) & rb1181;
  assign rb1189 = (rb1184 | rb1185) & ~rb1181;
  assign rb1190 = pp44;
  assign rb1191 = pp45;
  assign rb1192 = pp112;
  assign rb1193 = pp113;
  assign rb1194 = pp43 | pp111;
  assign rb1195 = rb1190 & rb1192;
  assign rb1196 = rb1191 & rb1193;
  assign rb1197 = (rb1190 & ~rb1192 & ~rb1193) | (rb1192 & ~rb1190 & ~rb1191);
  assign rb1198 = (rb1191 & ~rb1192 & ~rb1193) | (rb1193 & ~rb1190 & ~rb1191);
  assign rb1199 = rb1195 | (rb1197 & ~rb1194);
  assign rb1200 = rb1196 | (rb1198 & rb1194);
  assign rb1201 = (rb1197 | rb1198) & rb1194;
  assign rb1202 = (rb1197 | rb1198) & ~rb1194;
  assign rb1203 = pp46;
  assign rb1204 = pp47;
  assign rb1205 = pp114;
  assign rb1206 = pp115;
  assign rb1207 = pp45 | pp113;
  assign rb1208 = rb1203 & rb1205;
  assign rb1209 = rb1204 & rb1206;
  assign rb1210 = (rb1203 & ~rb1205 & ~rb1206) | (rb1205 & ~rb1203 & ~rb1204);
  assign rb1211 = (rb1204 & ~rb1205 & ~rb1206) | (rb1206 & ~rb1203 & ~rb1204);
  assign rb1212 = rb1208 | (rb1210 & ~rb1207);
  assign rb1213 = rb1209 | (rb1211 & rb1207);
  assign rb1214 = (rb1210 | rb1211) & rb1207;
  assign rb1215 = (rb1210 | rb1211) & ~rb1207;
  assign rb1216 = pp48;
  assign rb1217 = pp49;
  assign rb1218 = pp116;
  assign rb1219 = pp117;
  assign rb1220 = pp47 | pp115;
  assign rb1221 = rb1216 & rb1218;
  assign rb1222 = rb1217 & rb1219;
  assign rb1223 = (rb1216 & ~rb1218 & ~rb1219) | (rb1218 & ~rb1216 & ~rb1217);
  assign rb1224 = (rb1217 & ~rb1218 & ~rb1219) | (rb1219 & ~rb1216 & ~rb1217);
  assign rb1225 = rb1221 | (rb1223 & ~rb1220);
  assign rb1226 = rb1222 | (rb1224 & rb1220);
  assign rb1227 = (rb1223 | rb1224) & rb1220;
  assign rb1228 = (rb1223 | rb1224) & ~rb1220;
  assign rb1229 = pp50;
  assign rb1230 = pp51;
  assign rb1231 = pp118;
  assign rb1232 = pp119;
  assign rb1233 = pp49 | pp117;
  assign rb1234 = rb1229 & rb1231;
  assign rb1235 = rb1230 & rb1232;
  assign rb1236 = (rb1229 & ~rb1231 & ~rb1232) | (rb1231 & ~rb1229 & ~rb1230);
  assign rb1237 = (rb1230 & ~rb1231 & ~rb1232) | (rb1232 & ~rb1229 & ~rb1230);
  assign rb1238 = rb1234 | (rb1236 & ~rb1233);
  assign rb1239 = rb1235 | (rb1237 & rb1233);
  assign rb1240 = (rb1236 | rb1237) & rb1233;
  assign rb1241 = (rb1236 | rb1237) & ~rb1233;
  assign rb1242 = pp52;
  assign rb1243 = pp53;
  assign rb1244 = pp120;
  assign rb1245 = pp121;
  assign rb1246 = pp51 | pp119;
  assign rb1247 = rb1242 & rb1244;
  assign rb1248 = rb1243 & rb1245;
  assign rb1249 = (rb1242 & ~rb1244 & ~rb1245) | (rb1244 & ~rb1242 & ~rb1243);
  assign rb1250 = (rb1243 & ~rb1244 & ~rb1245) | (rb1245 & ~rb1242 & ~rb1243);
  assign rb1251 = rb1247 | (rb1249 & ~rb1246);
  assign rb1252 = rb1248 | (rb1250 & rb1246);
  assign rb1253 = (rb1249 | rb1250) & rb1246;
  assign rb1254 = (rb1249 | rb1250) & ~rb1246;
  assign rb1255 = pp54;
  assign rb1256 = pp55;
  assign rb1257 = pp122;
  assign rb1258 = pp123;
  assign rb1259 = pp53 | pp121;
  assign rb1260 = rb1255 & rb1257;
  assign rb1261 = rb1256 & rb1258;
  assign rb1262 = (rb1255 & ~rb1257 & ~rb1258) | (rb1257 & ~rb1255 & ~rb1256);
  assign rb1263 = (rb1256 & ~rb1257 & ~rb1258) | (rb1258 & ~rb1255 & ~rb1256);
  assign rb1264 = rb1260 | (rb1262 & ~rb1259);
  assign rb1265 = rb1261 | (rb1263 & rb1259);
  assign rb1266 = (rb1262 | rb1263) & rb1259;
  assign rb1267 = (rb1262 | rb1263) & ~rb1259;
  assign rb1268 = pp56;
  assign rb1269 = pp57;
  assign rb1270 = pp124;
  assign rb1271 = pp125;
  assign rb1272 = pp55 | pp123;
  assign rb1273 = rb1268 & rb1270;
  assign rb1274 = rb1269 & rb1271;
  assign rb1275 = (rb1268 & ~rb1270 & ~rb1271) | (rb1270 & ~rb1268 & ~rb1269);
  assign rb1276 = (rb1269 & ~rb1270 & ~rb1271) | (rb1271 & ~rb1268 & ~rb1269);
  assign rb1277 = rb1273 | (rb1275 & ~rb1272);
  assign rb1278 = rb1274 | (rb1276 & rb1272);
  assign rb1279 = (rb1275 | rb1276) & rb1272;
  assign rb1280 = (rb1275 | rb1276) & ~rb1272;
  assign rb1281 = pp58;
  assign rb1282 = pp59;
  assign rb1283 = pp126;
  assign rb1284 = pp127;
  assign rb1285 = pp57 | pp125;
  assign rb1286 = rb1281 & rb1283;
  assign rb1287 = rb1282 & rb1284;
  assign rb1288 = (rb1281 & ~rb1283 & ~rb1284) | (rb1283 & ~rb1281 & ~rb1282);
  assign rb1289 = (rb1282 & ~rb1283 & ~rb1284) | (rb1284 & ~rb1281 & ~rb1282);
  assign rb1290 = rb1286 | (rb1288 & ~rb1285);
  assign rb1291 = rb1287 | (rb1289 & rb1285);
  assign rb1292 = (rb1288 | rb1289) & rb1285;
  assign rb1293 = (rb1288 | rb1289) & ~rb1285;
  assign rb1294 = pp60;
  assign rb1295 = pp61;
  assign rb1296 = pp128;
  assign rb1297 = pp129;
  assign rb1298 = pp59 | pp127;
  assign rb1299 = rb1294 & rb1296;
  assign rb1300 = rb1295 & rb1297;
  assign rb1301 = (rb1294 & ~rb1296 & ~rb1297) | (rb1296 & ~rb1294 & ~rb1295);
  assign rb1302 = (rb1295 & ~rb1296 & ~rb1297) | (rb1297 & ~rb1294 & ~rb1295);
  assign rb1303 = rb1299 | (rb1301 & ~rb1298);
  assign rb1304 = rb1300 | (rb1302 & rb1298);
  assign rb1305 = (rb1301 | rb1302) & rb1298;
  assign rb1306 = (rb1301 | rb1302) & ~rb1298;
  assign rb1307 = pp62;
  assign rb1308 = pp63;
  assign rb1309 = pp130;
  assign rb1310 = pp131;
  assign rb1311 = pp61 | pp129;
  assign rb1312 = rb1307 & rb1309;
  assign rb1313 = rb1308 & rb1310;
  assign rb1314 = (rb1307 & ~rb1309 & ~rb1310) | (rb1309 & ~rb1307 & ~rb1308);
  assign rb1315 = (rb1308 & ~rb1309 & ~rb1310) | (rb1310 & ~rb1307 & ~rb1308);
  assign rb1316 = rb1312 | (rb1314 & ~rb1311);
  assign rb1317 = rb1313 | (rb1315 & rb1311);
  assign rb1318 = (rb1314 | rb1315) & rb1311;
  assign rb1319 = (rb1314 | rb1315) & ~rb1311;
  assign rb1320 = pp64;
  assign rb1321 = pp65;
  assign rb1322 = pp132;
  assign rb1323 = pp133;
  assign rb1324 = pp63 | pp131;
  assign rb1325 = rb1320 & rb1322;
  assign rb1326 = rb1321 & rb1323;
  assign rb1327 = (rb1320 & ~rb1322 & ~rb1323) | (rb1322 & ~rb1320 & ~rb1321);
  assign rb1328 = (rb1321 & ~rb1322 & ~rb1323) | (rb1323 & ~rb1320 & ~rb1321);
  assign rb1329 = rb1325 | (rb1327 & ~rb1324);
  assign rb1330 = rb1326 | (rb1328 & rb1324);
  assign rb1331 = (rb1327 | rb1328) & rb1324;
  assign rb1332 = (rb1327 | rb1328) & ~rb1324;
  assign rb1333 = pp66;
  assign rb1334 = pp67;
  assign rb1335 = pp134;
  assign rb1336 = pp135;
  assign rb1337 = pp65 | pp133;
  assign rb1338 = rb1333 & rb1335;
  assign rb1339 = rb1334 & rb1336;
  assign rb1340 = (rb1333 & ~rb1335 & ~rb1336) | (rb1335 & ~rb1333 & ~rb1334);
  assign rb1341 = (rb1334 & ~rb1335 & ~rb1336) | (rb1336 & ~rb1333 & ~rb1334);
  assign rb1342 = rb1338 | (rb1340 & ~rb1337);
  assign rb1343 = rb1339 | (rb1341 & rb1337);
  assign rb1344 = (rb1340 | rb1341) & rb1337;
  assign rb1345 = (rb1340 | rb1341) & ~rb1337;
  assign rb1346 = pp68;
  assign rb1347 = pp69;
  assign rb1348 = pp136;
  assign rb1349 = pp137;
  assign rb1350 = pp67 | pp135;
  assign rb1351 = rb1346 & rb1348;
  assign rb1352 = rb1347 & rb1349;
  assign rb1353 = (rb1346 & ~rb1348 & ~rb1349) | (rb1348 & ~rb1346 & ~rb1347);
  assign rb1354 = (rb1347 & ~rb1348 & ~rb1349) | (rb1349 & ~rb1346 & ~rb1347);
  assign rb1355 = rb1351 | (rb1353 & ~rb1350);
  assign rb1356 = rb1352 | (rb1354 & rb1350);
  assign rb1357 = (rb1353 | rb1354) & rb1350;
  assign rb1358 = (rb1353 | rb1354) & ~rb1350;
  assign rb1359 = (rb928 & ~1'b0) | (1'b0 & ~rb929);
  assign rb1360 = (rb929 & ~1'b0) | (1'b0 & ~rb928);
  assign rb1361 = (rb941 & ~rb927) | (rb926 & ~rb942);
  assign rb1362 = (rb942 & ~rb926) | (rb927 & ~rb941);
  assign rb1363 = (rb954 & ~rb940) | (rb939 & ~rb955);
  assign rb1364 = (rb955 & ~rb939) | (rb940 & ~rb954);
  assign rb1365 = (rb967 & ~rb953) | (rb952 & ~rb968);
  assign rb1366 = (rb968 & ~rb952) | (rb953 & ~rb967);
  assign rb1367 = (rb980 & ~rb966) | (rb965 & ~rb981);
  assign rb1368 = (rb981 & ~rb965) | (rb966 & ~rb980);
  assign rb1369 = (rb993 & ~rb979) | (rb978 & ~rb994);
  assign rb1370 = (rb994 & ~rb978) | (rb979 & ~rb993);
  assign rb1371 = (rb1006 & ~rb992) | (rb991 & ~rb1007);
  assign rb1372 = (rb1007 & ~rb991) | (rb992 & ~rb1006);
  assign rb1373 = (rb1019 & ~rb1005) | (rb1004 & ~rb1020);
  assign rb1374 = (rb1020 & ~rb1004) | (rb1005 & ~rb1019);
  assign rb1375 = (rb1032 & ~rb1018) | (rb1017 & ~rb1033);
  assign rb1376 = (rb1033 & ~rb1017) | (rb1018 & ~rb1032);
  assign rb1377 = (rb1045 & ~rb1031) | (rb1030 & ~rb1046);
  assign rb1378 = (rb1046 & ~rb1030) | (rb1031 & ~rb1045);
  assign rb1379 = (rb1058 & ~rb1044) | (rb1043 & ~rb1059);
  assign rb1380 = (rb1059 & ~rb1043) | (rb1044 & ~rb1058);
  assign rb1381 = (rb1071 & ~rb1057) | (rb1056 & ~rb1072);
  assign rb1382 = (rb1072 & ~rb1056) | (rb1057 & ~rb1071);
  assign rb1383 = (rb1084 & ~rb1070) | (rb1069 & ~rb1085);
  assign rb1384 = (rb1085 & ~rb1069) | (rb1070 & ~rb1084);
  assign rb1385 = (rb1097 & ~rb1083) | (rb1082 & ~rb1098);
  assign rb1386 = (rb1098 & ~rb1082) | (rb1083 & ~rb1097);
  assign rb1387 = (rb1110 & ~rb1096) | (rb1095 & ~rb1111);
  assign rb1388 = (rb1111 & ~rb1095) | (rb1096 & ~rb1110);
  assign rb1389 = (rb1123 & ~rb1109) | (rb1108 & ~rb1124);
  assign rb1390 = (rb1124 & ~rb1108) | (rb1109 & ~rb1123);
  assign rb1391 = (rb1136 & ~rb1122) | (rb1121 & ~rb1137);
  assign rb1392 = (rb1137 & ~rb1121) | (rb1122 & ~rb1136);
  assign rb1393 = (rb1149 & ~rb1135) | (rb1134 & ~rb1150);
  assign rb1394 = (rb1150 & ~rb1134) | (rb1135 & ~rb1149);
  assign rb1395 = (rb1162 & ~rb1148) | (rb1147 & ~rb1163);
  assign rb1396 = (rb1163 & ~rb1147) | (rb1148 & ~rb1162);
  assign rb1397 = (rb1175 & ~rb1161) | (rb1160 & ~rb1176);
  assign rb1398 = (rb1176 & ~rb1160) | (rb1161 & ~rb1175);
  assign rb1399 = (rb1188 & ~rb1174) | (rb1173 & ~rb1189);
  assign rb1400 = (rb1189 & ~rb1173) | (rb1174 & ~rb1188);
  assign rb1401 = (rb1201 & ~rb1187) | (rb1186 & ~rb1202);
  assign rb1402 = (rb1202 & ~rb1186) | (rb1187 & ~rb1201);
  assign rb1403 = (rb1214 & ~rb1200) | (rb1199 & ~rb1215);
  assign rb1404 = (rb1215 & ~rb1199) | (rb1200 & ~rb1214);
  assign rb1405 = (rb1227 & ~rb1213) | (rb1212 & ~rb1228);
  assign rb1406 = (rb1228 & ~rb1212) | (rb1213 & ~rb1227);
  assign rb1407 = (rb1240 & ~rb1226) | (rb1225 & ~rb1241);
  assign rb1408 = (rb1241 & ~rb1225) | (rb1226 & ~rb1240);
  assign rb1409 = (rb1253 & ~rb1239) | (rb1238 & ~rb1254);
  assign rb1410 = (rb1254 & ~rb1238) | (rb1239 & ~rb1253);
  assign rb1411 = (rb1266 & ~rb1252) | (rb1251 & ~rb1267);
  assign rb1412 = (rb1267 & ~rb1251) | (rb1252 & ~rb1266);
  assign rb1413 = (rb1279 & ~rb1265) | (rb1264 & ~rb1280);
  assign rb1414 = (rb1280 & ~rb1264) | (rb1265 & ~rb1279);
  assign rb1415 = (rb1292 & ~rb1278) | (rb1277 & ~rb1293);
  assign rb1416 = (rb1293 & ~rb1277) | (rb1278 & ~rb1292);
  assign rb1417 = (rb1305 & ~rb1291) | (rb1290 & ~rb1306);
  assign rb1418 = (rb1306 & ~rb1290) | (rb1291 & ~rb1305);
  assign rb1419 = (rb1318 & ~rb1304) | (rb1303 & ~rb1319);
  assign rb1420 = (rb1319 & ~rb1303) | (rb1304 & ~rb1318);
  assign rb1421 = (rb1331 & ~rb1317) | (rb1316 & ~rb1332);
  assign rb1422 = (rb1332 & ~rb1316) | (rb1317 & ~rb1331);
  assign rb1423 = (rb1344 & ~rb1330) | (rb1329 & ~rb1345);
  assign rb1424 = (rb1345 & ~rb1329) | (rb1330 & ~rb1344);
  assign rb1425 = (rb1357 & ~rb1343) | (rb1342 & ~rb1358);
  assign rb1426 = (rb1358 & ~rb1342) | (rb1343 & ~rb1357);
  assign rb1427 = (1'b0 & ~rb1356) | (rb1355 & ~1'b0);
  assign rb1428 = (1'b0 & ~rb1355) | (rb1356 & ~1'b0);
  assign rb1429 = 1'b0;
  assign rb1430 = 1'b0;
  assign rb1431 = 1'b0;
  assign rb1432 = 1'b0;
  assign rb1433 = rb1429 & rb1431;
  assign rb1434 = rb1430 & rb1432;
  assign rb1435 = (rb1429 & ~rb1431 & ~rb1432) | (rb1431 & ~rb1429 & ~rb1430);
  assign rb1436 = (rb1430 & ~rb1431 & ~rb1432) | (rb1432 & ~rb1429 & ~rb1430);
  assign rb1437 = rb1433 | (rb1435 & ~1'b0);
  assign rb1438 = rb1434 | (rb1436 & 1'b0);
  assign rb1439 = (rb1435 | rb1436) & 1'b0;
  assign rb1440 = (rb1435 | rb1436) & ~1'b0;
  assign rb1441 = 1'b0;
  assign rb1442 = 1'b0;
  assign rb1443 = 1'b0;
  assign rb1444 = 1'b0;
  assign rb1445 = 1'b0 | 1'b0;
  assign rb1446 = rb1441 & rb1443;
  assign rb1447 = rb1442 & rb1444;
  assign rb1448 = (rb1441 & ~rb1443 & ~rb1444) | (rb1443 & ~rb1441 & ~rb1442);
  assign rb1449 = (rb1442 & ~rb1443 & ~rb1444) | (rb1444 & ~rb1441 & ~rb1442);
  assign rb1450 = rb1446 | (rb1448 & ~rb1445);
  assign rb1451 = rb1447 | (rb1449 & rb1445);
  assign rb1452 = (rb1448 | rb1449) & rb1445;
  assign rb1453 = (rb1448 | rb1449) & ~rb1445;
  assign rb1454 = pp140;
  assign rb1455 = pp141;
  assign rb1456 = 1'b0;
  assign rb1457 = 1'b0;
  assign rb1458 = 1'b0 | 1'b0;
  assign rb1459 = rb1454 & rb1456;
  assign rb1460 = rb1455 & rb1457;
  assign rb1461 = (rb1454 & ~rb1456 & ~rb1457) | (rb1456 & ~rb1454 & ~rb1455);
  assign rb1462 = (rb1455 & ~rb1456 & ~rb1457) | (rb1457 & ~rb1454 & ~rb1455);
  assign rb1463 = rb1459 | (rb1461 & ~rb1458);
  assign rb1464 = rb1460 | (rb1462 & rb1458);
  assign rb1465 = (rb1461 | rb1462) & rb1458;
  assign rb1466 = (rb1461 | rb1462) & ~rb1458;
  assign rb1467 = pp142;
  assign rb1468 = pp143;
  assign rb1469 = pp206;
  assign rb1470 = pp207;
  assign rb1471 = pp141 | 1'b0;
  assign rb1472 = rb1467 & rb1469;
  assign rb1473 = rb1468 & rb1470;
  assign rb1474 = (rb1467 & ~rb1469 & ~rb1470) | (rb1469 & ~rb1467 & ~rb1468);
  assign rb1475 = (rb1468 & ~rb1469 & ~rb1470) | (rb1470 & ~rb1467 & ~rb1468);
  assign rb1476 = rb1472 | (rb1474 & ~rb1471);
  assign rb1477 = rb1473 | (rb1475 & rb1471);
  assign rb1478 = (rb1474 | rb1475) & rb1471;
  assign rb1479 = (rb1474 | rb1475) & ~rb1471;
  assign rb1480 = pp144;
  assign rb1481 = pp145;
  assign rb1482 = pp208;
  assign rb1483 = pp209;
  assign rb1484 = pp143 | pp207;
  assign rb1485 = rb1480 & rb1482;
  assign rb1486 = rb1481 & rb1483;
  assign rb1487 = (rb1480 & ~rb1482 & ~rb1483) | (rb1482 & ~rb1480 & ~rb1481);
  assign rb1488 = (rb1481 & ~rb1482 & ~rb1483) | (rb1483 & ~rb1480 & ~rb1481);
  assign rb1489 = rb1485 | (rb1487 & ~rb1484);
  assign rb1490 = rb1486 | (rb1488 & rb1484);
  assign rb1491 = (rb1487 | rb1488) & rb1484;
  assign rb1492 = (rb1487 | rb1488) & ~rb1484;
  assign rb1493 = pp146;
  assign rb1494 = pp147;
  assign rb1495 = pp210;
  assign rb1496 = pp211;
  assign rb1497 = pp145 | pp209;
  assign rb1498 = rb1493 & rb1495;
  assign rb1499 = rb1494 & rb1496;
  assign rb1500 = (rb1493 & ~rb1495 & ~rb1496) | (rb1495 & ~rb1493 & ~rb1494);
  assign rb1501 = (rb1494 & ~rb1495 & ~rb1496) | (rb1496 & ~rb1493 & ~rb1494);
  assign rb1502 = rb1498 | (rb1500 & ~rb1497);
  assign rb1503 = rb1499 | (rb1501 & rb1497);
  assign rb1504 = (rb1500 | rb1501) & rb1497;
  assign rb1505 = (rb1500 | rb1501) & ~rb1497;
  assign rb1506 = pp148;
  assign rb1507 = pp149;
  assign rb1508 = pp212;
  assign rb1509 = pp213;
  assign rb1510 = pp147 | pp211;
  assign rb1511 = rb1506 & rb1508;
  assign rb1512 = rb1507 & rb1509;
  assign rb1513 = (rb1506 & ~rb1508 & ~rb1509) | (rb1508 & ~rb1506 & ~rb1507);
  assign rb1514 = (rb1507 & ~rb1508 & ~rb1509) | (rb1509 & ~rb1506 & ~rb1507);
  assign rb1515 = rb1511 | (rb1513 & ~rb1510);
  assign rb1516 = rb1512 | (rb1514 & rb1510);
  assign rb1517 = (rb1513 | rb1514) & rb1510;
  assign rb1518 = (rb1513 | rb1514) & ~rb1510;
  assign rb1519 = pp150;
  assign rb1520 = pp151;
  assign rb1521 = pp214;
  assign rb1522 = pp215;
  assign rb1523 = pp149 | pp213;
  assign rb1524 = rb1519 & rb1521;
  assign rb1525 = rb1520 & rb1522;
  assign rb1526 = (rb1519 & ~rb1521 & ~rb1522) | (rb1521 & ~rb1519 & ~rb1520);
  assign rb1527 = (rb1520 & ~rb1521 & ~rb1522) | (rb1522 & ~rb1519 & ~rb1520);
  assign rb1528 = rb1524 | (rb1526 & ~rb1523);
  assign rb1529 = rb1525 | (rb1527 & rb1523);
  assign rb1530 = (rb1526 | rb1527) & rb1523;
  assign rb1531 = (rb1526 | rb1527) & ~rb1523;
  assign rb1532 = pp152;
  assign rb1533 = pp153;
  assign rb1534 = pp216;
  assign rb1535 = pp217;
  assign rb1536 = pp151 | pp215;
  assign rb1537 = rb1532 & rb1534;
  assign rb1538 = rb1533 & rb1535;
  assign rb1539 = (rb1532 & ~rb1534 & ~rb1535) | (rb1534 & ~rb1532 & ~rb1533);
  assign rb1540 = (rb1533 & ~rb1534 & ~rb1535) | (rb1535 & ~rb1532 & ~rb1533);
  assign rb1541 = rb1537 | (rb1539 & ~rb1536);
  assign rb1542 = rb1538 | (rb1540 & rb1536);
  assign rb1543 = (rb1539 | rb1540) & rb1536;
  assign rb1544 = (rb1539 | rb1540) & ~rb1536;
  assign rb1545 = pp154;
  assign rb1546 = pp155;
  assign rb1547 = pp218;
  assign rb1548 = pp219;
  assign rb1549 = pp153 | pp217;
  assign rb1550 = rb1545 & rb1547;
  assign rb1551 = rb1546 & rb1548;
  assign rb1552 = (rb1545 & ~rb1547 & ~rb1548) | (rb1547 & ~rb1545 & ~rb1546);
  assign rb1553 = (rb1546 & ~rb1547 & ~rb1548) | (rb1548 & ~rb1545 & ~rb1546);
  assign rb1554 = rb1550 | (rb1552 & ~rb1549);
  assign rb1555 = rb1551 | (rb1553 & rb1549);
  assign rb1556 = (rb1552 | rb1553) & rb1549;
  assign rb1557 = (rb1552 | rb1553) & ~rb1549;
  assign rb1558 = pp156;
  assign rb1559 = pp157;
  assign rb1560 = pp220;
  assign rb1561 = pp221;
  assign rb1562 = pp155 | pp219;
  assign rb1563 = rb1558 & rb1560;
  assign rb1564 = rb1559 & rb1561;
  assign rb1565 = (rb1558 & ~rb1560 & ~rb1561) | (rb1560 & ~rb1558 & ~rb1559);
  assign rb1566 = (rb1559 & ~rb1560 & ~rb1561) | (rb1561 & ~rb1558 & ~rb1559);
  assign rb1567 = rb1563 | (rb1565 & ~rb1562);
  assign rb1568 = rb1564 | (rb1566 & rb1562);
  assign rb1569 = (rb1565 | rb1566) & rb1562;
  assign rb1570 = (rb1565 | rb1566) & ~rb1562;
  assign rb1571 = pp158;
  assign rb1572 = pp159;
  assign rb1573 = pp222;
  assign rb1574 = pp223;
  assign rb1575 = pp157 | pp221;
  assign rb1576 = rb1571 & rb1573;
  assign rb1577 = rb1572 & rb1574;
  assign rb1578 = (rb1571 & ~rb1573 & ~rb1574) | (rb1573 & ~rb1571 & ~rb1572);
  assign rb1579 = (rb1572 & ~rb1573 & ~rb1574) | (rb1574 & ~rb1571 & ~rb1572);
  assign rb1580 = rb1576 | (rb1578 & ~rb1575);
  assign rb1581 = rb1577 | (rb1579 & rb1575);
  assign rb1582 = (rb1578 | rb1579) & rb1575;
  assign rb1583 = (rb1578 | rb1579) & ~rb1575;
  assign rb1584 = pp160;
  assign rb1585 = pp161;
  assign rb1586 = pp224;
  assign rb1587 = pp225;
  assign rb1588 = pp159 | pp223;
  assign rb1589 = rb1584 & rb1586;
  assign rb1590 = rb1585 & rb1587;
  assign rb1591 = (rb1584 & ~rb1586 & ~rb1587) | (rb1586 & ~rb1584 & ~rb1585);
  assign rb1592 = (rb1585 & ~rb1586 & ~rb1587) | (rb1587 & ~rb1584 & ~rb1585);
  assign rb1593 = rb1589 | (rb1591 & ~rb1588);
  assign rb1594 = rb1590 | (rb1592 & rb1588);
  assign rb1595 = (rb1591 | rb1592) & rb1588;
  assign rb1596 = (rb1591 | rb1592) & ~rb1588;
  assign rb1597 = pp162;
  assign rb1598 = pp163;
  assign rb1599 = pp226;
  assign rb1600 = pp227;
  assign rb1601 = pp161 | pp225;
  assign rb1602 = rb1597 & rb1599;
  assign rb1603 = rb1598 & rb1600;
  assign rb1604 = (rb1597 & ~rb1599 & ~rb1600) | (rb1599 & ~rb1597 & ~rb1598);
  assign rb1605 = (rb1598 & ~rb1599 & ~rb1600) | (rb1600 & ~rb1597 & ~rb1598);
  assign rb1606 = rb1602 | (rb1604 & ~rb1601);
  assign rb1607 = rb1603 | (rb1605 & rb1601);
  assign rb1608 = (rb1604 | rb1605) & rb1601;
  assign rb1609 = (rb1604 | rb1605) & ~rb1601;
  assign rb1610 = pp164;
  assign rb1611 = pp165;
  assign rb1612 = pp228;
  assign rb1613 = pp229;
  assign rb1614 = pp163 | pp227;
  assign rb1615 = rb1610 & rb1612;
  assign rb1616 = rb1611 & rb1613;
  assign rb1617 = (rb1610 & ~rb1612 & ~rb1613) | (rb1612 & ~rb1610 & ~rb1611);
  assign rb1618 = (rb1611 & ~rb1612 & ~rb1613) | (rb1613 & ~rb1610 & ~rb1611);
  assign rb1619 = rb1615 | (rb1617 & ~rb1614);
  assign rb1620 = rb1616 | (rb1618 & rb1614);
  assign rb1621 = (rb1617 | rb1618) & rb1614;
  assign rb1622 = (rb1617 | rb1618) & ~rb1614;
  assign rb1623 = pp166;
  assign rb1624 = pp167;
  assign rb1625 = pp230;
  assign rb1626 = pp231;
  assign rb1627 = pp165 | pp229;
  assign rb1628 = rb1623 & rb1625;
  assign rb1629 = rb1624 & rb1626;
  assign rb1630 = (rb1623 & ~rb1625 & ~rb1626) | (rb1625 & ~rb1623 & ~rb1624);
  assign rb1631 = (rb1624 & ~rb1625 & ~rb1626) | (rb1626 & ~rb1623 & ~rb1624);
  assign rb1632 = rb1628 | (rb1630 & ~rb1627);
  assign rb1633 = rb1629 | (rb1631 & rb1627);
  assign rb1634 = (rb1630 | rb1631) & rb1627;
  assign rb1635 = (rb1630 | rb1631) & ~rb1627;
  assign rb1636 = pp168;
  assign rb1637 = pp169;
  assign rb1638 = pp232;
  assign rb1639 = pp233;
  assign rb1640 = pp167 | pp231;
  assign rb1641 = rb1636 & rb1638;
  assign rb1642 = rb1637 & rb1639;
  assign rb1643 = (rb1636 & ~rb1638 & ~rb1639) | (rb1638 & ~rb1636 & ~rb1637);
  assign rb1644 = (rb1637 & ~rb1638 & ~rb1639) | (rb1639 & ~rb1636 & ~rb1637);
  assign rb1645 = rb1641 | (rb1643 & ~rb1640);
  assign rb1646 = rb1642 | (rb1644 & rb1640);
  assign rb1647 = (rb1643 | rb1644) & rb1640;
  assign rb1648 = (rb1643 | rb1644) & ~rb1640;
  assign rb1649 = pp170;
  assign rb1650 = pp171;
  assign rb1651 = pp234;
  assign rb1652 = pp235;
  assign rb1653 = pp169 | pp233;
  assign rb1654 = rb1649 & rb1651;
  assign rb1655 = rb1650 & rb1652;
  assign rb1656 = (rb1649 & ~rb1651 & ~rb1652) | (rb1651 & ~rb1649 & ~rb1650);
  assign rb1657 = (rb1650 & ~rb1651 & ~rb1652) | (rb1652 & ~rb1649 & ~rb1650);
  assign rb1658 = rb1654 | (rb1656 & ~rb1653);
  assign rb1659 = rb1655 | (rb1657 & rb1653);
  assign rb1660 = (rb1656 | rb1657) & rb1653;
  assign rb1661 = (rb1656 | rb1657) & ~rb1653;
  assign rb1662 = pp172;
  assign rb1663 = pp173;
  assign rb1664 = pp236;
  assign rb1665 = pp237;
  assign rb1666 = pp171 | pp235;
  assign rb1667 = rb1662 & rb1664;
  assign rb1668 = rb1663 & rb1665;
  assign rb1669 = (rb1662 & ~rb1664 & ~rb1665) | (rb1664 & ~rb1662 & ~rb1663);
  assign rb1670 = (rb1663 & ~rb1664 & ~rb1665) | (rb1665 & ~rb1662 & ~rb1663);
  assign rb1671 = rb1667 | (rb1669 & ~rb1666);
  assign rb1672 = rb1668 | (rb1670 & rb1666);
  assign rb1673 = (rb1669 | rb1670) & rb1666;
  assign rb1674 = (rb1669 | rb1670) & ~rb1666;
  assign rb1675 = pp174;
  assign rb1676 = pp175;
  assign rb1677 = pp238;
  assign rb1678 = pp239;
  assign rb1679 = pp173 | pp237;
  assign rb1680 = rb1675 & rb1677;
  assign rb1681 = rb1676 & rb1678;
  assign rb1682 = (rb1675 & ~rb1677 & ~rb1678) | (rb1677 & ~rb1675 & ~rb1676);
  assign rb1683 = (rb1676 & ~rb1677 & ~rb1678) | (rb1678 & ~rb1675 & ~rb1676);
  assign rb1684 = rb1680 | (rb1682 & ~rb1679);
  assign rb1685 = rb1681 | (rb1683 & rb1679);
  assign rb1686 = (rb1682 | rb1683) & rb1679;
  assign rb1687 = (rb1682 | rb1683) & ~rb1679;
  assign rb1688 = pp176;
  assign rb1689 = pp177;
  assign rb1690 = pp240;
  assign rb1691 = pp241;
  assign rb1692 = pp175 | pp239;
  assign rb1693 = rb1688 & rb1690;
  assign rb1694 = rb1689 & rb1691;
  assign rb1695 = (rb1688 & ~rb1690 & ~rb1691) | (rb1690 & ~rb1688 & ~rb1689);
  assign rb1696 = (rb1689 & ~rb1690 & ~rb1691) | (rb1691 & ~rb1688 & ~rb1689);
  assign rb1697 = rb1693 | (rb1695 & ~rb1692);
  assign rb1698 = rb1694 | (rb1696 & rb1692);
  assign rb1699 = (rb1695 | rb1696) & rb1692;
  assign rb1700 = (rb1695 | rb1696) & ~rb1692;
  assign rb1701 = pp178;
  assign rb1702 = pp179;
  assign rb1703 = pp242;
  assign rb1704 = pp243;
  assign rb1705 = pp177 | pp241;
  assign rb1706 = rb1701 & rb1703;
  assign rb1707 = rb1702 & rb1704;
  assign rb1708 = (rb1701 & ~rb1703 & ~rb1704) | (rb1703 & ~rb1701 & ~rb1702);
  assign rb1709 = (rb1702 & ~rb1703 & ~rb1704) | (rb1704 & ~rb1701 & ~rb1702);
  assign rb1710 = rb1706 | (rb1708 & ~rb1705);
  assign rb1711 = rb1707 | (rb1709 & rb1705);
  assign rb1712 = (rb1708 | rb1709) & rb1705;
  assign rb1713 = (rb1708 | rb1709) & ~rb1705;
  assign rb1714 = pp180;
  assign rb1715 = pp181;
  assign rb1716 = pp244;
  assign rb1717 = pp245;
  assign rb1718 = pp179 | pp243;
  assign rb1719 = rb1714 & rb1716;
  assign rb1720 = rb1715 & rb1717;
  assign rb1721 = (rb1714 & ~rb1716 & ~rb1717) | (rb1716 & ~rb1714 & ~rb1715);
  assign rb1722 = (rb1715 & ~rb1716 & ~rb1717) | (rb1717 & ~rb1714 & ~rb1715);
  assign rb1723 = rb1719 | (rb1721 & ~rb1718);
  assign rb1724 = rb1720 | (rb1722 & rb1718);
  assign rb1725 = (rb1721 | rb1722) & rb1718;
  assign rb1726 = (rb1721 | rb1722) & ~rb1718;
  assign rb1727 = pp182;
  assign rb1728 = pp183;
  assign rb1729 = pp246;
  assign rb1730 = pp247;
  assign rb1731 = pp181 | pp245;
  assign rb1732 = rb1727 & rb1729;
  assign rb1733 = rb1728 & rb1730;
  assign rb1734 = (rb1727 & ~rb1729 & ~rb1730) | (rb1729 & ~rb1727 & ~rb1728);
  assign rb1735 = (rb1728 & ~rb1729 & ~rb1730) | (rb1730 & ~rb1727 & ~rb1728);
  assign rb1736 = rb1732 | (rb1734 & ~rb1731);
  assign rb1737 = rb1733 | (rb1735 & rb1731);
  assign rb1738 = (rb1734 | rb1735) & rb1731;
  assign rb1739 = (rb1734 | rb1735) & ~rb1731;
  assign rb1740 = pp184;
  assign rb1741 = pp185;
  assign rb1742 = pp248;
  assign rb1743 = pp249;
  assign rb1744 = pp183 | pp247;
  assign rb1745 = rb1740 & rb1742;
  assign rb1746 = rb1741 & rb1743;
  assign rb1747 = (rb1740 & ~rb1742 & ~rb1743) | (rb1742 & ~rb1740 & ~rb1741);
  assign rb1748 = (rb1741 & ~rb1742 & ~rb1743) | (rb1743 & ~rb1740 & ~rb1741);
  assign rb1749 = rb1745 | (rb1747 & ~rb1744);
  assign rb1750 = rb1746 | (rb1748 & rb1744);
  assign rb1751 = (rb1747 | rb1748) & rb1744;
  assign rb1752 = (rb1747 | rb1748) & ~rb1744;
  assign rb1753 = pp186;
  assign rb1754 = pp187;
  assign rb1755 = pp250;
  assign rb1756 = pp251;
  assign rb1757 = pp185 | pp249;
  assign rb1758 = rb1753 & rb1755;
  assign rb1759 = rb1754 & rb1756;
  assign rb1760 = (rb1753 & ~rb1755 & ~rb1756) | (rb1755 & ~rb1753 & ~rb1754);
  assign rb1761 = (rb1754 & ~rb1755 & ~rb1756) | (rb1756 & ~rb1753 & ~rb1754);
  assign rb1762 = rb1758 | (rb1760 & ~rb1757);
  assign rb1763 = rb1759 | (rb1761 & rb1757);
  assign rb1764 = (rb1760 | rb1761) & rb1757;
  assign rb1765 = (rb1760 | rb1761) & ~rb1757;
  assign rb1766 = pp188;
  assign rb1767 = pp189;
  assign rb1768 = pp252;
  assign rb1769 = pp253;
  assign rb1770 = pp187 | pp251;
  assign rb1771 = rb1766 & rb1768;
  assign rb1772 = rb1767 & rb1769;
  assign rb1773 = (rb1766 & ~rb1768 & ~rb1769) | (rb1768 & ~rb1766 & ~rb1767);
  assign rb1774 = (rb1767 & ~rb1768 & ~rb1769) | (rb1769 & ~rb1766 & ~rb1767);
  assign rb1775 = rb1771 | (rb1773 & ~rb1770);
  assign rb1776 = rb1772 | (rb1774 & rb1770);
  assign rb1777 = (rb1773 | rb1774) & rb1770;
  assign rb1778 = (rb1773 | rb1774) & ~rb1770;
  assign rb1779 = pp190;
  assign rb1780 = pp191;
  assign rb1781 = pp254;
  assign rb1782 = pp255;
  assign rb1783 = pp189 | pp253;
  assign rb1784 = rb1779 & rb1781;
  assign rb1785 = rb1780 & rb1782;
  assign rb1786 = (rb1779 & ~rb1781 & ~rb1782) | (rb1781 & ~rb1779 & ~rb1780);
  assign rb1787 = (rb1780 & ~rb1781 & ~rb1782) | (rb1782 & ~rb1779 & ~rb1780);
  assign rb1788 = rb1784 | (rb1786 & ~rb1783);
  assign rb1789 = rb1785 | (rb1787 & rb1783);
  assign rb1790 = (rb1786 | rb1787) & rb1783;
  assign rb1791 = (rb1786 | rb1787) & ~rb1783;
  assign rb1792 = pp192;
  assign rb1793 = pp193;
  assign rb1794 = pp256;
  assign rb1795 = pp257;
  assign rb1796 = pp191 | pp255;
  assign rb1797 = rb1792 & rb1794;
  assign rb1798 = rb1793 & rb1795;
  assign rb1799 = (rb1792 & ~rb1794 & ~rb1795) | (rb1794 & ~rb1792 & ~rb1793);
  assign rb1800 = (rb1793 & ~rb1794 & ~rb1795) | (rb1795 & ~rb1792 & ~rb1793);
  assign rb1801 = rb1797 | (rb1799 & ~rb1796);
  assign rb1802 = rb1798 | (rb1800 & rb1796);
  assign rb1803 = (rb1799 | rb1800) & rb1796;
  assign rb1804 = (rb1799 | rb1800) & ~rb1796;
  assign rb1805 = pp194;
  assign rb1806 = pp195;
  assign rb1807 = pp258;
  assign rb1808 = pp259;
  assign rb1809 = pp193 | pp257;
  assign rb1810 = rb1805 & rb1807;
  assign rb1811 = rb1806 & rb1808;
  assign rb1812 = (rb1805 & ~rb1807 & ~rb1808) | (rb1807 & ~rb1805 & ~rb1806);
  assign rb1813 = (rb1806 & ~rb1807 & ~rb1808) | (rb1808 & ~rb1805 & ~rb1806);
  assign rb1814 = rb1810 | (rb1812 & ~rb1809);
  assign rb1815 = rb1811 | (rb1813 & rb1809);
  assign rb1816 = (rb1812 | rb1813) & rb1809;
  assign rb1817 = (rb1812 | rb1813) & ~rb1809;
  assign rb1818 = pp196;
  assign rb1819 = pp197;
  assign rb1820 = pp260;
  assign rb1821 = pp261;
  assign rb1822 = pp195 | pp259;
  assign rb1823 = rb1818 & rb1820;
  assign rb1824 = rb1819 & rb1821;
  assign rb1825 = (rb1818 & ~rb1820 & ~rb1821) | (rb1820 & ~rb1818 & ~rb1819);
  assign rb1826 = (rb1819 & ~rb1820 & ~rb1821) | (rb1821 & ~rb1818 & ~rb1819);
  assign rb1827 = rb1823 | (rb1825 & ~rb1822);
  assign rb1828 = rb1824 | (rb1826 & rb1822);
  assign rb1829 = (rb1825 | rb1826) & rb1822;
  assign rb1830 = (rb1825 | rb1826) & ~rb1822;
  assign rb1831 = pp198;
  assign rb1832 = pp199;
  assign rb1833 = pp262;
  assign rb1834 = pp263;
  assign rb1835 = pp197 | pp261;
  assign rb1836 = rb1831 & rb1833;
  assign rb1837 = rb1832 & rb1834;
  assign rb1838 = (rb1831 & ~rb1833 & ~rb1834) | (rb1833 & ~rb1831 & ~rb1832);
  assign rb1839 = (rb1832 & ~rb1833 & ~rb1834) | (rb1834 & ~rb1831 & ~rb1832);
  assign rb1840 = rb1836 | (rb1838 & ~rb1835);
  assign rb1841 = rb1837 | (rb1839 & rb1835);
  assign rb1842 = (rb1838 | rb1839) & rb1835;
  assign rb1843 = (rb1838 | rb1839) & ~rb1835;
  assign rb1844 = pp200;
  assign rb1845 = pp201;
  assign rb1846 = pp264;
  assign rb1847 = pp265;
  assign rb1848 = pp199 | pp263;
  assign rb1849 = rb1844 & rb1846;
  assign rb1850 = rb1845 & rb1847;
  assign rb1851 = (rb1844 & ~rb1846 & ~rb1847) | (rb1846 & ~rb1844 & ~rb1845);
  assign rb1852 = (rb1845 & ~rb1846 & ~rb1847) | (rb1847 & ~rb1844 & ~rb1845);
  assign rb1853 = rb1849 | (rb1851 & ~rb1848);
  assign rb1854 = rb1850 | (rb1852 & rb1848);
  assign rb1855 = (rb1851 | rb1852) & rb1848;
  assign rb1856 = (rb1851 | rb1852) & ~rb1848;
  assign rb1857 = pp202;
  assign rb1858 = pp203;
  assign rb1859 = pp266;
  assign rb1860 = pp267;
  assign rb1861 = pp201 | pp265;
  assign rb1862 = rb1857 & rb1859;
  assign rb1863 = rb1858 & rb1860;
  assign rb1864 = (rb1857 & ~rb1859 & ~rb1860) | (rb1859 & ~rb1857 & ~rb1858);
  assign rb1865 = (rb1858 & ~rb1859 & ~rb1860) | (rb1860 & ~rb1857 & ~rb1858);
  assign rb1866 = rb1862 | (rb1864 & ~rb1861);
  assign rb1867 = rb1863 | (rb1865 & rb1861);
  assign rb1868 = (rb1864 | rb1865) & rb1861;
  assign rb1869 = (rb1864 | rb1865) & ~rb1861;
  assign rb1870 = (rb1439 & ~1'b0) | (1'b0 & ~rb1440);
  assign rb1871 = (rb1440 & ~1'b0) | (1'b0 & ~rb1439);
  assign rb1872 = (rb1452 & ~rb1438) | (rb1437 & ~rb1453);
  assign rb1873 = (rb1453 & ~rb1437) | (rb1438 & ~rb1452);
  assign rb1874 = (rb1465 & ~rb1451) | (rb1450 & ~rb1466);
  assign rb1875 = (rb1466 & ~rb1450) | (rb1451 & ~rb1465);
  assign rb1876 = (rb1478 & ~rb1464) | (rb1463 & ~rb1479);
  assign rb1877 = (rb1479 & ~rb1463) | (rb1464 & ~rb1478);
  assign rb1878 = (rb1491 & ~rb1477) | (rb1476 & ~rb1492);
  assign rb1879 = (rb1492 & ~rb1476) | (rb1477 & ~rb1491);
  assign rb1880 = (rb1504 & ~rb1490) | (rb1489 & ~rb1505);
  assign rb1881 = (rb1505 & ~rb1489) | (rb1490 & ~rb1504);
  assign rb1882 = (rb1517 & ~rb1503) | (rb1502 & ~rb1518);
  assign rb1883 = (rb1518 & ~rb1502) | (rb1503 & ~rb1517);
  assign rb1884 = (rb1530 & ~rb1516) | (rb1515 & ~rb1531);
  assign rb1885 = (rb1531 & ~rb1515) | (rb1516 & ~rb1530);
  assign rb1886 = (rb1543 & ~rb1529) | (rb1528 & ~rb1544);
  assign rb1887 = (rb1544 & ~rb1528) | (rb1529 & ~rb1543);
  assign rb1888 = (rb1556 & ~rb1542) | (rb1541 & ~rb1557);
  assign rb1889 = (rb1557 & ~rb1541) | (rb1542 & ~rb1556);
  assign rb1890 = (rb1569 & ~rb1555) | (rb1554 & ~rb1570);
  assign rb1891 = (rb1570 & ~rb1554) | (rb1555 & ~rb1569);
  assign rb1892 = (rb1582 & ~rb1568) | (rb1567 & ~rb1583);
  assign rb1893 = (rb1583 & ~rb1567) | (rb1568 & ~rb1582);
  assign rb1894 = (rb1595 & ~rb1581) | (rb1580 & ~rb1596);
  assign rb1895 = (rb1596 & ~rb1580) | (rb1581 & ~rb1595);
  assign rb1896 = (rb1608 & ~rb1594) | (rb1593 & ~rb1609);
  assign rb1897 = (rb1609 & ~rb1593) | (rb1594 & ~rb1608);
  assign rb1898 = (rb1621 & ~rb1607) | (rb1606 & ~rb1622);
  assign rb1899 = (rb1622 & ~rb1606) | (rb1607 & ~rb1621);
  assign rb1900 = (rb1634 & ~rb1620) | (rb1619 & ~rb1635);
  assign rb1901 = (rb1635 & ~rb1619) | (rb1620 & ~rb1634);
  assign rb1902 = (rb1647 & ~rb1633) | (rb1632 & ~rb1648);
  assign rb1903 = (rb1648 & ~rb1632) | (rb1633 & ~rb1647);
  assign rb1904 = (rb1660 & ~rb1646) | (rb1645 & ~rb1661);
  assign rb1905 = (rb1661 & ~rb1645) | (rb1646 & ~rb1660);
  assign rb1906 = (rb1673 & ~rb1659) | (rb1658 & ~rb1674);
  assign rb1907 = (rb1674 & ~rb1658) | (rb1659 & ~rb1673);
  assign rb1908 = (rb1686 & ~rb1672) | (rb1671 & ~rb1687);
  assign rb1909 = (rb1687 & ~rb1671) | (rb1672 & ~rb1686);
  assign rb1910 = (rb1699 & ~rb1685) | (rb1684 & ~rb1700);
  assign rb1911 = (rb1700 & ~rb1684) | (rb1685 & ~rb1699);
  assign rb1912 = (rb1712 & ~rb1698) | (rb1697 & ~rb1713);
  assign rb1913 = (rb1713 & ~rb1697) | (rb1698 & ~rb1712);
  assign rb1914 = (rb1725 & ~rb1711) | (rb1710 & ~rb1726);
  assign rb1915 = (rb1726 & ~rb1710) | (rb1711 & ~rb1725);
  assign rb1916 = (rb1738 & ~rb1724) | (rb1723 & ~rb1739);
  assign rb1917 = (rb1739 & ~rb1723) | (rb1724 & ~rb1738);
  assign rb1918 = (rb1751 & ~rb1737) | (rb1736 & ~rb1752);
  assign rb1919 = (rb1752 & ~rb1736) | (rb1737 & ~rb1751);
  assign rb1920 = (rb1764 & ~rb1750) | (rb1749 & ~rb1765);
  assign rb1921 = (rb1765 & ~rb1749) | (rb1750 & ~rb1764);
  assign rb1922 = (rb1777 & ~rb1763) | (rb1762 & ~rb1778);
  assign rb1923 = (rb1778 & ~rb1762) | (rb1763 & ~rb1777);
  assign rb1924 = (rb1790 & ~rb1776) | (rb1775 & ~rb1791);
  assign rb1925 = (rb1791 & ~rb1775) | (rb1776 & ~rb1790);
  assign rb1926 = (rb1803 & ~rb1789) | (rb1788 & ~rb1804);
  assign rb1927 = (rb1804 & ~rb1788) | (rb1789 & ~rb1803);
  assign rb1928 = (rb1816 & ~rb1802) | (rb1801 & ~rb1817);
  assign rb1929 = (rb1817 & ~rb1801) | (rb1802 & ~rb1816);
  assign rb1930 = (rb1829 & ~rb1815) | (rb1814 & ~rb1830);
  assign rb1931 = (rb1830 & ~rb1814) | (rb1815 & ~rb1829);
  assign rb1932 = (rb1842 & ~rb1828) | (rb1827 & ~rb1843);
  assign rb1933 = (rb1843 & ~rb1827) | (rb1828 & ~rb1842);
  assign rb1934 = (rb1855 & ~rb1841) | (rb1840 & ~rb1856);
  assign rb1935 = (rb1856 & ~rb1840) | (rb1841 & ~rb1855);
  assign rb1936 = (rb1868 & ~rb1854) | (rb1853 & ~rb1869);
  assign rb1937 = (rb1869 & ~rb1853) | (rb1854 & ~rb1868);
  assign rb1938 = (1'b0 & ~rb1867) | (rb1866 & ~1'b0);
  assign rb1939 = (1'b0 & ~rb1866) | (rb1867 & ~1'b0);
  assign rb1940 = 1'b0;
  assign rb1941 = 1'b0;
  assign rb1942 = 1'b0;
  assign rb1943 = 1'b0;
  assign rb1944 = rb1940 & rb1942;
  assign rb1945 = rb1941 & rb1943;
  assign rb1946 = (rb1940 & ~rb1942 & ~rb1943) | (rb1942 & ~rb1940 & ~rb1941);
  assign rb1947 = (rb1941 & ~rb1942 & ~rb1943) | (rb1943 & ~rb1940 & ~rb1941);
  assign rb1948 = rb1944 | (rb1946 & ~1'b0);
  assign rb1949 = rb1945 | (rb1947 & 1'b0);
  assign rb1950 = (rb1946 | rb1947) & 1'b0;
  assign rb1951 = (rb1946 | rb1947) & ~1'b0;
  assign rb1952 = 1'b0;
  assign rb1953 = 1'b0;
  assign rb1954 = 1'b0;
  assign rb1955 = 1'b0;
  assign rb1956 = 1'b0 | 1'b0;
  assign rb1957 = rb1952 & rb1954;
  assign rb1958 = rb1953 & rb1955;
  assign rb1959 = (rb1952 & ~rb1954 & ~rb1955) | (rb1954 & ~rb1952 & ~rb1953);
  assign rb1960 = (rb1953 & ~rb1954 & ~rb1955) | (rb1955 & ~rb1952 & ~rb1953);
  assign rb1961 = rb1957 | (rb1959 & ~rb1956);
  assign rb1962 = rb1958 | (rb1960 & rb1956);
  assign rb1963 = (rb1959 | rb1960) & rb1956;
  assign rb1964 = (rb1959 | rb1960) & ~rb1956;
  assign rb1965 = 1'b0;
  assign rb1966 = 1'b0;
  assign rb1967 = 1'b0;
  assign rb1968 = 1'b0;
  assign rb1969 = 1'b0 | 1'b0;
  assign rb1970 = rb1965 & rb1967;
  assign rb1971 = rb1966 & rb1968;
  assign rb1972 = (rb1965 & ~rb1967 & ~rb1968) | (rb1967 & ~rb1965 & ~rb1966);
  assign rb1973 = (rb1966 & ~rb1967 & ~rb1968) | (rb1968 & ~rb1965 & ~rb1966);
  assign rb1974 = rb1970 | (rb1972 & ~rb1969);
  assign rb1975 = rb1971 | (rb1973 & rb1969);
  assign rb1976 = (rb1972 | rb1973) & rb1969;
  assign rb1977 = (rb1972 | rb1973) & ~rb1969;
  assign rb1978 = 1'b0;
  assign rb1979 = 1'b0;
  assign rb1980 = 1'b0;
  assign rb1981 = 1'b0;
  assign rb1982 = 1'b0 | 1'b0;
  assign rb1983 = rb1978 & rb1980;
  assign rb1984 = rb1979 & rb1981;
  assign rb1985 = (rb1978 & ~rb1980 & ~rb1981) | (rb1980 & ~rb1978 & ~rb1979);
  assign rb1986 = (rb1979 & ~rb1980 & ~rb1981) | (rb1981 & ~rb1978 & ~rb1979);
  assign rb1987 = rb1983 | (rb1985 & ~rb1982);
  assign rb1988 = rb1984 | (rb1986 & rb1982);
  assign rb1989 = (rb1985 | rb1986) & rb1982;
  assign rb1990 = (rb1985 | rb1986) & ~rb1982;
  assign rb1991 = pp270;
  assign rb1992 = pp271;
  assign rb1993 = 1'b0;
  assign rb1994 = 1'b0;
  assign rb1995 = 1'b0 | 1'b0;
  assign rb1996 = rb1991 & rb1993;
  assign rb1997 = rb1992 & rb1994;
  assign rb1998 = (rb1991 & ~rb1993 & ~rb1994) | (rb1993 & ~rb1991 & ~rb1992);
  assign rb1999 = (rb1992 & ~rb1993 & ~rb1994) | (rb1994 & ~rb1991 & ~rb1992);
  assign rb2000 = rb1996 | (rb1998 & ~rb1995);
  assign rb2001 = rb1997 | (rb1999 & rb1995);
  assign rb2002 = (rb1998 | rb1999) & rb1995;
  assign rb2003 = (rb1998 | rb1999) & ~rb1995;
  assign rb2004 = pp272;
  assign rb2005 = pp273;
  assign rb2006 = pp332;
  assign rb2007 = pp333;
  assign rb2008 = pp271 | 1'b0;
  assign rb2009 = rb2004 & rb2006;
  assign rb2010 = rb2005 & rb2007;
  assign rb2011 = (rb2004 & ~rb2006 & ~rb2007) | (rb2006 & ~rb2004 & ~rb2005);
  assign rb2012 = (rb2005 & ~rb2006 & ~rb2007) | (rb2007 & ~rb2004 & ~rb2005);
  assign rb2013 = rb2009 | (rb2011 & ~rb2008);
  assign rb2014 = rb2010 | (rb2012 & rb2008);
  assign rb2015 = (rb2011 | rb2012) & rb2008;
  assign rb2016 = (rb2011 | rb2012) & ~rb2008;
  assign rb2017 = pp274;
  assign rb2018 = pp275;
  assign rb2019 = pp334;
  assign rb2020 = pp335;
  assign rb2021 = pp273 | pp333;
  assign rb2022 = rb2017 & rb2019;
  assign rb2023 = rb2018 & rb2020;
  assign rb2024 = (rb2017 & ~rb2019 & ~rb2020) | (rb2019 & ~rb2017 & ~rb2018);
  assign rb2025 = (rb2018 & ~rb2019 & ~rb2020) | (rb2020 & ~rb2017 & ~rb2018);
  assign rb2026 = rb2022 | (rb2024 & ~rb2021);
  assign rb2027 = rb2023 | (rb2025 & rb2021);
  assign rb2028 = (rb2024 | rb2025) & rb2021;
  assign rb2029 = (rb2024 | rb2025) & ~rb2021;
  assign rb2030 = pp276;
  assign rb2031 = pp277;
  assign rb2032 = pp336;
  assign rb2033 = pp337;
  assign rb2034 = pp275 | pp335;
  assign rb2035 = rb2030 & rb2032;
  assign rb2036 = rb2031 & rb2033;
  assign rb2037 = (rb2030 & ~rb2032 & ~rb2033) | (rb2032 & ~rb2030 & ~rb2031);
  assign rb2038 = (rb2031 & ~rb2032 & ~rb2033) | (rb2033 & ~rb2030 & ~rb2031);
  assign rb2039 = rb2035 | (rb2037 & ~rb2034);
  assign rb2040 = rb2036 | (rb2038 & rb2034);
  assign rb2041 = (rb2037 | rb2038) & rb2034;
  assign rb2042 = (rb2037 | rb2038) & ~rb2034;
  assign rb2043 = pp278;
  assign rb2044 = pp279;
  assign rb2045 = pp338;
  assign rb2046 = pp339;
  assign rb2047 = pp277 | pp337;
  assign rb2048 = rb2043 & rb2045;
  assign rb2049 = rb2044 & rb2046;
  assign rb2050 = (rb2043 & ~rb2045 & ~rb2046) | (rb2045 & ~rb2043 & ~rb2044);
  assign rb2051 = (rb2044 & ~rb2045 & ~rb2046) | (rb2046 & ~rb2043 & ~rb2044);
  assign rb2052 = rb2048 | (rb2050 & ~rb2047);
  assign rb2053 = rb2049 | (rb2051 & rb2047);
  assign rb2054 = (rb2050 | rb2051) & rb2047;
  assign rb2055 = (rb2050 | rb2051) & ~rb2047;
  assign rb2056 = pp280;
  assign rb2057 = pp281;
  assign rb2058 = pp340;
  assign rb2059 = pp341;
  assign rb2060 = pp279 | pp339;
  assign rb2061 = rb2056 & rb2058;
  assign rb2062 = rb2057 & rb2059;
  assign rb2063 = (rb2056 & ~rb2058 & ~rb2059) | (rb2058 & ~rb2056 & ~rb2057);
  assign rb2064 = (rb2057 & ~rb2058 & ~rb2059) | (rb2059 & ~rb2056 & ~rb2057);
  assign rb2065 = rb2061 | (rb2063 & ~rb2060);
  assign rb2066 = rb2062 | (rb2064 & rb2060);
  assign rb2067 = (rb2063 | rb2064) & rb2060;
  assign rb2068 = (rb2063 | rb2064) & ~rb2060;
  assign rb2069 = pp282;
  assign rb2070 = pp283;
  assign rb2071 = pp342;
  assign rb2072 = pp343;
  assign rb2073 = pp281 | pp341;
  assign rb2074 = rb2069 & rb2071;
  assign rb2075 = rb2070 & rb2072;
  assign rb2076 = (rb2069 & ~rb2071 & ~rb2072) | (rb2071 & ~rb2069 & ~rb2070);
  assign rb2077 = (rb2070 & ~rb2071 & ~rb2072) | (rb2072 & ~rb2069 & ~rb2070);
  assign rb2078 = rb2074 | (rb2076 & ~rb2073);
  assign rb2079 = rb2075 | (rb2077 & rb2073);
  assign rb2080 = (rb2076 | rb2077) & rb2073;
  assign rb2081 = (rb2076 | rb2077) & ~rb2073;
  assign rb2082 = pp284;
  assign rb2083 = pp285;
  assign rb2084 = pp344;
  assign rb2085 = pp345;
  assign rb2086 = pp283 | pp343;
  assign rb2087 = rb2082 & rb2084;
  assign rb2088 = rb2083 & rb2085;
  assign rb2089 = (rb2082 & ~rb2084 & ~rb2085) | (rb2084 & ~rb2082 & ~rb2083);
  assign rb2090 = (rb2083 & ~rb2084 & ~rb2085) | (rb2085 & ~rb2082 & ~rb2083);
  assign rb2091 = rb2087 | (rb2089 & ~rb2086);
  assign rb2092 = rb2088 | (rb2090 & rb2086);
  assign rb2093 = (rb2089 | rb2090) & rb2086;
  assign rb2094 = (rb2089 | rb2090) & ~rb2086;
  assign rb2095 = pp286;
  assign rb2096 = pp287;
  assign rb2097 = pp346;
  assign rb2098 = pp347;
  assign rb2099 = pp285 | pp345;
  assign rb2100 = rb2095 & rb2097;
  assign rb2101 = rb2096 & rb2098;
  assign rb2102 = (rb2095 & ~rb2097 & ~rb2098) | (rb2097 & ~rb2095 & ~rb2096);
  assign rb2103 = (rb2096 & ~rb2097 & ~rb2098) | (rb2098 & ~rb2095 & ~rb2096);
  assign rb2104 = rb2100 | (rb2102 & ~rb2099);
  assign rb2105 = rb2101 | (rb2103 & rb2099);
  assign rb2106 = (rb2102 | rb2103) & rb2099;
  assign rb2107 = (rb2102 | rb2103) & ~rb2099;
  assign rb2108 = pp288;
  assign rb2109 = pp289;
  assign rb2110 = pp348;
  assign rb2111 = pp349;
  assign rb2112 = pp287 | pp347;
  assign rb2113 = rb2108 & rb2110;
  assign rb2114 = rb2109 & rb2111;
  assign rb2115 = (rb2108 & ~rb2110 & ~rb2111) | (rb2110 & ~rb2108 & ~rb2109);
  assign rb2116 = (rb2109 & ~rb2110 & ~rb2111) | (rb2111 & ~rb2108 & ~rb2109);
  assign rb2117 = rb2113 | (rb2115 & ~rb2112);
  assign rb2118 = rb2114 | (rb2116 & rb2112);
  assign rb2119 = (rb2115 | rb2116) & rb2112;
  assign rb2120 = (rb2115 | rb2116) & ~rb2112;
  assign rb2121 = pp290;
  assign rb2122 = pp291;
  assign rb2123 = pp350;
  assign rb2124 = pp351;
  assign rb2125 = pp289 | pp349;
  assign rb2126 = rb2121 & rb2123;
  assign rb2127 = rb2122 & rb2124;
  assign rb2128 = (rb2121 & ~rb2123 & ~rb2124) | (rb2123 & ~rb2121 & ~rb2122);
  assign rb2129 = (rb2122 & ~rb2123 & ~rb2124) | (rb2124 & ~rb2121 & ~rb2122);
  assign rb2130 = rb2126 | (rb2128 & ~rb2125);
  assign rb2131 = rb2127 | (rb2129 & rb2125);
  assign rb2132 = (rb2128 | rb2129) & rb2125;
  assign rb2133 = (rb2128 | rb2129) & ~rb2125;
  assign rb2134 = pp292;
  assign rb2135 = pp293;
  assign rb2136 = pp352;
  assign rb2137 = pp353;
  assign rb2138 = pp291 | pp351;
  assign rb2139 = rb2134 & rb2136;
  assign rb2140 = rb2135 & rb2137;
  assign rb2141 = (rb2134 & ~rb2136 & ~rb2137) | (rb2136 & ~rb2134 & ~rb2135);
  assign rb2142 = (rb2135 & ~rb2136 & ~rb2137) | (rb2137 & ~rb2134 & ~rb2135);
  assign rb2143 = rb2139 | (rb2141 & ~rb2138);
  assign rb2144 = rb2140 | (rb2142 & rb2138);
  assign rb2145 = (rb2141 | rb2142) & rb2138;
  assign rb2146 = (rb2141 | rb2142) & ~rb2138;
  assign rb2147 = pp294;
  assign rb2148 = pp295;
  assign rb2149 = pp354;
  assign rb2150 = pp355;
  assign rb2151 = pp293 | pp353;
  assign rb2152 = rb2147 & rb2149;
  assign rb2153 = rb2148 & rb2150;
  assign rb2154 = (rb2147 & ~rb2149 & ~rb2150) | (rb2149 & ~rb2147 & ~rb2148);
  assign rb2155 = (rb2148 & ~rb2149 & ~rb2150) | (rb2150 & ~rb2147 & ~rb2148);
  assign rb2156 = rb2152 | (rb2154 & ~rb2151);
  assign rb2157 = rb2153 | (rb2155 & rb2151);
  assign rb2158 = (rb2154 | rb2155) & rb2151;
  assign rb2159 = (rb2154 | rb2155) & ~rb2151;
  assign rb2160 = pp296;
  assign rb2161 = pp297;
  assign rb2162 = pp356;
  assign rb2163 = pp357;
  assign rb2164 = pp295 | pp355;
  assign rb2165 = rb2160 & rb2162;
  assign rb2166 = rb2161 & rb2163;
  assign rb2167 = (rb2160 & ~rb2162 & ~rb2163) | (rb2162 & ~rb2160 & ~rb2161);
  assign rb2168 = (rb2161 & ~rb2162 & ~rb2163) | (rb2163 & ~rb2160 & ~rb2161);
  assign rb2169 = rb2165 | (rb2167 & ~rb2164);
  assign rb2170 = rb2166 | (rb2168 & rb2164);
  assign rb2171 = (rb2167 | rb2168) & rb2164;
  assign rb2172 = (rb2167 | rb2168) & ~rb2164;
  assign rb2173 = pp298;
  assign rb2174 = pp299;
  assign rb2175 = pp358;
  assign rb2176 = pp359;
  assign rb2177 = pp297 | pp357;
  assign rb2178 = rb2173 & rb2175;
  assign rb2179 = rb2174 & rb2176;
  assign rb2180 = (rb2173 & ~rb2175 & ~rb2176) | (rb2175 & ~rb2173 & ~rb2174);
  assign rb2181 = (rb2174 & ~rb2175 & ~rb2176) | (rb2176 & ~rb2173 & ~rb2174);
  assign rb2182 = rb2178 | (rb2180 & ~rb2177);
  assign rb2183 = rb2179 | (rb2181 & rb2177);
  assign rb2184 = (rb2180 | rb2181) & rb2177;
  assign rb2185 = (rb2180 | rb2181) & ~rb2177;
  assign rb2186 = pp300;
  assign rb2187 = pp301;
  assign rb2188 = pp360;
  assign rb2189 = pp361;
  assign rb2190 = pp299 | pp359;
  assign rb2191 = rb2186 & rb2188;
  assign rb2192 = rb2187 & rb2189;
  assign rb2193 = (rb2186 & ~rb2188 & ~rb2189) | (rb2188 & ~rb2186 & ~rb2187);
  assign rb2194 = (rb2187 & ~rb2188 & ~rb2189) | (rb2189 & ~rb2186 & ~rb2187);
  assign rb2195 = rb2191 | (rb2193 & ~rb2190);
  assign rb2196 = rb2192 | (rb2194 & rb2190);
  assign rb2197 = (rb2193 | rb2194) & rb2190;
  assign rb2198 = (rb2193 | rb2194) & ~rb2190;
  assign rb2199 = pp302;
  assign rb2200 = pp303;
  assign rb2201 = pp362;
  assign rb2202 = pp363;
  assign rb2203 = pp301 | pp361;
  assign rb2204 = rb2199 & rb2201;
  assign rb2205 = rb2200 & rb2202;
  assign rb2206 = (rb2199 & ~rb2201 & ~rb2202) | (rb2201 & ~rb2199 & ~rb2200);
  assign rb2207 = (rb2200 & ~rb2201 & ~rb2202) | (rb2202 & ~rb2199 & ~rb2200);
  assign rb2208 = rb2204 | (rb2206 & ~rb2203);
  assign rb2209 = rb2205 | (rb2207 & rb2203);
  assign rb2210 = (rb2206 | rb2207) & rb2203;
  assign rb2211 = (rb2206 | rb2207) & ~rb2203;
  assign rb2212 = pp304;
  assign rb2213 = pp305;
  assign rb2214 = pp364;
  assign rb2215 = pp365;
  assign rb2216 = pp303 | pp363;
  assign rb2217 = rb2212 & rb2214;
  assign rb2218 = rb2213 & rb2215;
  assign rb2219 = (rb2212 & ~rb2214 & ~rb2215) | (rb2214 & ~rb2212 & ~rb2213);
  assign rb2220 = (rb2213 & ~rb2214 & ~rb2215) | (rb2215 & ~rb2212 & ~rb2213);
  assign rb2221 = rb2217 | (rb2219 & ~rb2216);
  assign rb2222 = rb2218 | (rb2220 & rb2216);
  assign rb2223 = (rb2219 | rb2220) & rb2216;
  assign rb2224 = (rb2219 | rb2220) & ~rb2216;
  assign rb2225 = pp306;
  assign rb2226 = pp307;
  assign rb2227 = pp366;
  assign rb2228 = pp367;
  assign rb2229 = pp305 | pp365;
  assign rb2230 = rb2225 & rb2227;
  assign rb2231 = rb2226 & rb2228;
  assign rb2232 = (rb2225 & ~rb2227 & ~rb2228) | (rb2227 & ~rb2225 & ~rb2226);
  assign rb2233 = (rb2226 & ~rb2227 & ~rb2228) | (rb2228 & ~rb2225 & ~rb2226);
  assign rb2234 = rb2230 | (rb2232 & ~rb2229);
  assign rb2235 = rb2231 | (rb2233 & rb2229);
  assign rb2236 = (rb2232 | rb2233) & rb2229;
  assign rb2237 = (rb2232 | rb2233) & ~rb2229;
  assign rb2238 = pp308;
  assign rb2239 = pp309;
  assign rb2240 = pp368;
  assign rb2241 = pp369;
  assign rb2242 = pp307 | pp367;
  assign rb2243 = rb2238 & rb2240;
  assign rb2244 = rb2239 & rb2241;
  assign rb2245 = (rb2238 & ~rb2240 & ~rb2241) | (rb2240 & ~rb2238 & ~rb2239);
  assign rb2246 = (rb2239 & ~rb2240 & ~rb2241) | (rb2241 & ~rb2238 & ~rb2239);
  assign rb2247 = rb2243 | (rb2245 & ~rb2242);
  assign rb2248 = rb2244 | (rb2246 & rb2242);
  assign rb2249 = (rb2245 | rb2246) & rb2242;
  assign rb2250 = (rb2245 | rb2246) & ~rb2242;
  assign rb2251 = pp310;
  assign rb2252 = pp311;
  assign rb2253 = pp370;
  assign rb2254 = pp371;
  assign rb2255 = pp309 | pp369;
  assign rb2256 = rb2251 & rb2253;
  assign rb2257 = rb2252 & rb2254;
  assign rb2258 = (rb2251 & ~rb2253 & ~rb2254) | (rb2253 & ~rb2251 & ~rb2252);
  assign rb2259 = (rb2252 & ~rb2253 & ~rb2254) | (rb2254 & ~rb2251 & ~rb2252);
  assign rb2260 = rb2256 | (rb2258 & ~rb2255);
  assign rb2261 = rb2257 | (rb2259 & rb2255);
  assign rb2262 = (rb2258 | rb2259) & rb2255;
  assign rb2263 = (rb2258 | rb2259) & ~rb2255;
  assign rb2264 = pp312;
  assign rb2265 = pp313;
  assign rb2266 = pp372;
  assign rb2267 = pp373;
  assign rb2268 = pp311 | pp371;
  assign rb2269 = rb2264 & rb2266;
  assign rb2270 = rb2265 & rb2267;
  assign rb2271 = (rb2264 & ~rb2266 & ~rb2267) | (rb2266 & ~rb2264 & ~rb2265);
  assign rb2272 = (rb2265 & ~rb2266 & ~rb2267) | (rb2267 & ~rb2264 & ~rb2265);
  assign rb2273 = rb2269 | (rb2271 & ~rb2268);
  assign rb2274 = rb2270 | (rb2272 & rb2268);
  assign rb2275 = (rb2271 | rb2272) & rb2268;
  assign rb2276 = (rb2271 | rb2272) & ~rb2268;
  assign rb2277 = pp314;
  assign rb2278 = pp315;
  assign rb2279 = pp374;
  assign rb2280 = pp375;
  assign rb2281 = pp313 | pp373;
  assign rb2282 = rb2277 & rb2279;
  assign rb2283 = rb2278 & rb2280;
  assign rb2284 = (rb2277 & ~rb2279 & ~rb2280) | (rb2279 & ~rb2277 & ~rb2278);
  assign rb2285 = (rb2278 & ~rb2279 & ~rb2280) | (rb2280 & ~rb2277 & ~rb2278);
  assign rb2286 = rb2282 | (rb2284 & ~rb2281);
  assign rb2287 = rb2283 | (rb2285 & rb2281);
  assign rb2288 = (rb2284 | rb2285) & rb2281;
  assign rb2289 = (rb2284 | rb2285) & ~rb2281;
  assign rb2290 = pp316;
  assign rb2291 = pp317;
  assign rb2292 = pp376;
  assign rb2293 = pp377;
  assign rb2294 = pp315 | pp375;
  assign rb2295 = rb2290 & rb2292;
  assign rb2296 = rb2291 & rb2293;
  assign rb2297 = (rb2290 & ~rb2292 & ~rb2293) | (rb2292 & ~rb2290 & ~rb2291);
  assign rb2298 = (rb2291 & ~rb2292 & ~rb2293) | (rb2293 & ~rb2290 & ~rb2291);
  assign rb2299 = rb2295 | (rb2297 & ~rb2294);
  assign rb2300 = rb2296 | (rb2298 & rb2294);
  assign rb2301 = (rb2297 | rb2298) & rb2294;
  assign rb2302 = (rb2297 | rb2298) & ~rb2294;
  assign rb2303 = pp318;
  assign rb2304 = pp319;
  assign rb2305 = pp378;
  assign rb2306 = pp379;
  assign rb2307 = pp317 | pp377;
  assign rb2308 = rb2303 & rb2305;
  assign rb2309 = rb2304 & rb2306;
  assign rb2310 = (rb2303 & ~rb2305 & ~rb2306) | (rb2305 & ~rb2303 & ~rb2304);
  assign rb2311 = (rb2304 & ~rb2305 & ~rb2306) | (rb2306 & ~rb2303 & ~rb2304);
  assign rb2312 = rb2308 | (rb2310 & ~rb2307);
  assign rb2313 = rb2309 | (rb2311 & rb2307);
  assign rb2314 = (rb2310 | rb2311) & rb2307;
  assign rb2315 = (rb2310 | rb2311) & ~rb2307;
  assign rb2316 = pp320;
  assign rb2317 = pp321;
  assign rb2318 = pp380;
  assign rb2319 = pp381;
  assign rb2320 = pp319 | pp379;
  assign rb2321 = rb2316 & rb2318;
  assign rb2322 = rb2317 & rb2319;
  assign rb2323 = (rb2316 & ~rb2318 & ~rb2319) | (rb2318 & ~rb2316 & ~rb2317);
  assign rb2324 = (rb2317 & ~rb2318 & ~rb2319) | (rb2319 & ~rb2316 & ~rb2317);
  assign rb2325 = rb2321 | (rb2323 & ~rb2320);
  assign rb2326 = rb2322 | (rb2324 & rb2320);
  assign rb2327 = (rb2323 | rb2324) & rb2320;
  assign rb2328 = (rb2323 | rb2324) & ~rb2320;
  assign rb2329 = pp322;
  assign rb2330 = pp323;
  assign rb2331 = pp382;
  assign rb2332 = pp383;
  assign rb2333 = pp321 | pp381;
  assign rb2334 = rb2329 & rb2331;
  assign rb2335 = rb2330 & rb2332;
  assign rb2336 = (rb2329 & ~rb2331 & ~rb2332) | (rb2331 & ~rb2329 & ~rb2330);
  assign rb2337 = (rb2330 & ~rb2331 & ~rb2332) | (rb2332 & ~rb2329 & ~rb2330);
  assign rb2338 = rb2334 | (rb2336 & ~rb2333);
  assign rb2339 = rb2335 | (rb2337 & rb2333);
  assign rb2340 = (rb2336 | rb2337) & rb2333;
  assign rb2341 = (rb2336 | rb2337) & ~rb2333;
  assign rb2342 = pp324;
  assign rb2343 = pp325;
  assign rb2344 = pp384;
  assign rb2345 = pp385;
  assign rb2346 = pp323 | pp383;
  assign rb2347 = rb2342 & rb2344;
  assign rb2348 = rb2343 & rb2345;
  assign rb2349 = (rb2342 & ~rb2344 & ~rb2345) | (rb2344 & ~rb2342 & ~rb2343);
  assign rb2350 = (rb2343 & ~rb2344 & ~rb2345) | (rb2345 & ~rb2342 & ~rb2343);
  assign rb2351 = rb2347 | (rb2349 & ~rb2346);
  assign rb2352 = rb2348 | (rb2350 & rb2346);
  assign rb2353 = (rb2349 | rb2350) & rb2346;
  assign rb2354 = (rb2349 | rb2350) & ~rb2346;
  assign rb2355 = pp326;
  assign rb2356 = pp327;
  assign rb2357 = pp386;
  assign rb2358 = pp387;
  assign rb2359 = pp325 | pp385;
  assign rb2360 = rb2355 & rb2357;
  assign rb2361 = rb2356 & rb2358;
  assign rb2362 = (rb2355 & ~rb2357 & ~rb2358) | (rb2357 & ~rb2355 & ~rb2356);
  assign rb2363 = (rb2356 & ~rb2357 & ~rb2358) | (rb2358 & ~rb2355 & ~rb2356);
  assign rb2364 = rb2360 | (rb2362 & ~rb2359);
  assign rb2365 = rb2361 | (rb2363 & rb2359);
  assign rb2366 = (rb2362 | rb2363) & rb2359;
  assign rb2367 = (rb2362 | rb2363) & ~rb2359;
  assign rb2368 = pp328;
  assign rb2369 = pp329;
  assign rb2370 = pp388;
  assign rb2371 = pp389;
  assign rb2372 = pp327 | pp387;
  assign rb2373 = rb2368 & rb2370;
  assign rb2374 = rb2369 & rb2371;
  assign rb2375 = (rb2368 & ~rb2370 & ~rb2371) | (rb2370 & ~rb2368 & ~rb2369);
  assign rb2376 = (rb2369 & ~rb2370 & ~rb2371) | (rb2371 & ~rb2368 & ~rb2369);
  assign rb2377 = rb2373 | (rb2375 & ~rb2372);
  assign rb2378 = rb2374 | (rb2376 & rb2372);
  assign rb2379 = (rb2375 | rb2376) & rb2372;
  assign rb2380 = (rb2375 | rb2376) & ~rb2372;
  assign rb2381 = (rb1950 & ~1'b0) | (1'b0 & ~rb1951);
  assign rb2382 = (rb1951 & ~1'b0) | (1'b0 & ~rb1950);
  assign rb2383 = (rb1963 & ~rb1949) | (rb1948 & ~rb1964);
  assign rb2384 = (rb1964 & ~rb1948) | (rb1949 & ~rb1963);
  assign rb2385 = (rb1976 & ~rb1962) | (rb1961 & ~rb1977);
  assign rb2386 = (rb1977 & ~rb1961) | (rb1962 & ~rb1976);
  assign rb2387 = (rb1989 & ~rb1975) | (rb1974 & ~rb1990);
  assign rb2388 = (rb1990 & ~rb1974) | (rb1975 & ~rb1989);
  assign rb2389 = (rb2002 & ~rb1988) | (rb1987 & ~rb2003);
  assign rb2390 = (rb2003 & ~rb1987) | (rb1988 & ~rb2002);
  assign rb2391 = (rb2015 & ~rb2001) | (rb2000 & ~rb2016);
  assign rb2392 = (rb2016 & ~rb2000) | (rb2001 & ~rb2015);
  assign rb2393 = (rb2028 & ~rb2014) | (rb2013 & ~rb2029);
  assign rb2394 = (rb2029 & ~rb2013) | (rb2014 & ~rb2028);
  assign rb2395 = (rb2041 & ~rb2027) | (rb2026 & ~rb2042);
  assign rb2396 = (rb2042 & ~rb2026) | (rb2027 & ~rb2041);
  assign rb2397 = (rb2054 & ~rb2040) | (rb2039 & ~rb2055);
  assign rb2398 = (rb2055 & ~rb2039) | (rb2040 & ~rb2054);
  assign rb2399 = (rb2067 & ~rb2053) | (rb2052 & ~rb2068);
  assign rb2400 = (rb2068 & ~rb2052) | (rb2053 & ~rb2067);
  assign rb2401 = (rb2080 & ~rb2066) | (rb2065 & ~rb2081);
  assign rb2402 = (rb2081 & ~rb2065) | (rb2066 & ~rb2080);
  assign rb2403 = (rb2093 & ~rb2079) | (rb2078 & ~rb2094);
  assign rb2404 = (rb2094 & ~rb2078) | (rb2079 & ~rb2093);
  assign rb2405 = (rb2106 & ~rb2092) | (rb2091 & ~rb2107);
  assign rb2406 = (rb2107 & ~rb2091) | (rb2092 & ~rb2106);
  assign rb2407 = (rb2119 & ~rb2105) | (rb2104 & ~rb2120);
  assign rb2408 = (rb2120 & ~rb2104) | (rb2105 & ~rb2119);
  assign rb2409 = (rb2132 & ~rb2118) | (rb2117 & ~rb2133);
  assign rb2410 = (rb2133 & ~rb2117) | (rb2118 & ~rb2132);
  assign rb2411 = (rb2145 & ~rb2131) | (rb2130 & ~rb2146);
  assign rb2412 = (rb2146 & ~rb2130) | (rb2131 & ~rb2145);
  assign rb2413 = (rb2158 & ~rb2144) | (rb2143 & ~rb2159);
  assign rb2414 = (rb2159 & ~rb2143) | (rb2144 & ~rb2158);
  assign rb2415 = (rb2171 & ~rb2157) | (rb2156 & ~rb2172);
  assign rb2416 = (rb2172 & ~rb2156) | (rb2157 & ~rb2171);
  assign rb2417 = (rb2184 & ~rb2170) | (rb2169 & ~rb2185);
  assign rb2418 = (rb2185 & ~rb2169) | (rb2170 & ~rb2184);
  assign rb2419 = (rb2197 & ~rb2183) | (rb2182 & ~rb2198);
  assign rb2420 = (rb2198 & ~rb2182) | (rb2183 & ~rb2197);
  assign rb2421 = (rb2210 & ~rb2196) | (rb2195 & ~rb2211);
  assign rb2422 = (rb2211 & ~rb2195) | (rb2196 & ~rb2210);
  assign rb2423 = (rb2223 & ~rb2209) | (rb2208 & ~rb2224);
  assign rb2424 = (rb2224 & ~rb2208) | (rb2209 & ~rb2223);
  assign rb2425 = (rb2236 & ~rb2222) | (rb2221 & ~rb2237);
  assign rb2426 = (rb2237 & ~rb2221) | (rb2222 & ~rb2236);
  assign rb2427 = (rb2249 & ~rb2235) | (rb2234 & ~rb2250);
  assign rb2428 = (rb2250 & ~rb2234) | (rb2235 & ~rb2249);
  assign rb2429 = (rb2262 & ~rb2248) | (rb2247 & ~rb2263);
  assign rb2430 = (rb2263 & ~rb2247) | (rb2248 & ~rb2262);
  assign rb2431 = (rb2275 & ~rb2261) | (rb2260 & ~rb2276);
  assign rb2432 = (rb2276 & ~rb2260) | (rb2261 & ~rb2275);
  assign rb2433 = (rb2288 & ~rb2274) | (rb2273 & ~rb2289);
  assign rb2434 = (rb2289 & ~rb2273) | (rb2274 & ~rb2288);
  assign rb2435 = (rb2301 & ~rb2287) | (rb2286 & ~rb2302);
  assign rb2436 = (rb2302 & ~rb2286) | (rb2287 & ~rb2301);
  assign rb2437 = (rb2314 & ~rb2300) | (rb2299 & ~rb2315);
  assign rb2438 = (rb2315 & ~rb2299) | (rb2300 & ~rb2314);
  assign rb2439 = (rb2327 & ~rb2313) | (rb2312 & ~rb2328);
  assign rb2440 = (rb2328 & ~rb2312) | (rb2313 & ~rb2327);
  assign rb2441 = (rb2340 & ~rb2326) | (rb2325 & ~rb2341);
  assign rb2442 = (rb2341 & ~rb2325) | (rb2326 & ~rb2340);
  assign rb2443 = (rb2353 & ~rb2339) | (rb2338 & ~rb2354);
  assign rb2444 = (rb2354 & ~rb2338) | (rb2339 & ~rb2353);
  assign rb2445 = (rb2366 & ~rb2352) | (rb2351 & ~rb2367);
  assign rb2446 = (rb2367 & ~rb2351) | (rb2352 & ~rb2366);
  assign rb2447 = (rb2379 & ~rb2365) | (rb2364 & ~rb2380);
  assign rb2448 = (rb2380 & ~rb2364) | (rb2365 & ~rb2379);
  assign rb2449 = (1'b0 & ~rb2378) | (rb2377 & ~1'b0);
  assign rb2450 = (1'b0 & ~rb2377) | (rb2378 & ~1'b0);
  assign rb2451 = 1'b0;
  assign rb2452 = 1'b0;
  assign rb2453 = 1'b0;
  assign rb2454 = 1'b0;
  assign rb2455 = rb2451 & rb2453;
  assign rb2456 = rb2452 & rb2454;
  assign rb2457 = (rb2451 & ~rb2453 & ~rb2454) | (rb2453 & ~rb2451 & ~rb2452);
  assign rb2458 = (rb2452 & ~rb2453 & ~rb2454) | (rb2454 & ~rb2451 & ~rb2452);
  assign rb2459 = rb2455 | (rb2457 & ~1'b0);
  assign rb2460 = rb2456 | (rb2458 & 1'b0);
  assign rb2461 = (rb2457 | rb2458) & 1'b0;
  assign rb2462 = (rb2457 | rb2458) & ~1'b0;
  assign rb2463 = 1'b0;
  assign rb2464 = 1'b0;
  assign rb2465 = 1'b0;
  assign rb2466 = 1'b0;
  assign rb2467 = 1'b0 | 1'b0;
  assign rb2468 = rb2463 & rb2465;
  assign rb2469 = rb2464 & rb2466;
  assign rb2470 = (rb2463 & ~rb2465 & ~rb2466) | (rb2465 & ~rb2463 & ~rb2464);
  assign rb2471 = (rb2464 & ~rb2465 & ~rb2466) | (rb2466 & ~rb2463 & ~rb2464);
  assign rb2472 = rb2468 | (rb2470 & ~rb2467);
  assign rb2473 = rb2469 | (rb2471 & rb2467);
  assign rb2474 = (rb2470 | rb2471) & rb2467;
  assign rb2475 = (rb2470 | rb2471) & ~rb2467;
  assign rb2476 = 1'b0;
  assign rb2477 = 1'b0;
  assign rb2478 = 1'b0;
  assign rb2479 = 1'b0;
  assign rb2480 = 1'b0 | 1'b0;
  assign rb2481 = rb2476 & rb2478;
  assign rb2482 = rb2477 & rb2479;
  assign rb2483 = (rb2476 & ~rb2478 & ~rb2479) | (rb2478 & ~rb2476 & ~rb2477);
  assign rb2484 = (rb2477 & ~rb2478 & ~rb2479) | (rb2479 & ~rb2476 & ~rb2477);
  assign rb2485 = rb2481 | (rb2483 & ~rb2480);
  assign rb2486 = rb2482 | (rb2484 & rb2480);
  assign rb2487 = (rb2483 | rb2484) & rb2480;
  assign rb2488 = (rb2483 | rb2484) & ~rb2480;
  assign rb2489 = 1'b0;
  assign rb2490 = 1'b0;
  assign rb2491 = 1'b0;
  assign rb2492 = 1'b0;
  assign rb2493 = 1'b0 | 1'b0;
  assign rb2494 = rb2489 & rb2491;
  assign rb2495 = rb2490 & rb2492;
  assign rb2496 = (rb2489 & ~rb2491 & ~rb2492) | (rb2491 & ~rb2489 & ~rb2490);
  assign rb2497 = (rb2490 & ~rb2491 & ~rb2492) | (rb2492 & ~rb2489 & ~rb2490);
  assign rb2498 = rb2494 | (rb2496 & ~rb2493);
  assign rb2499 = rb2495 | (rb2497 & rb2493);
  assign rb2500 = (rb2496 | rb2497) & rb2493;
  assign rb2501 = (rb2496 | rb2497) & ~rb2493;
  assign rb2502 = 1'b0;
  assign rb2503 = 1'b0;
  assign rb2504 = 1'b0;
  assign rb2505 = 1'b0;
  assign rb2506 = 1'b0 | 1'b0;
  assign rb2507 = rb2502 & rb2504;
  assign rb2508 = rb2503 & rb2505;
  assign rb2509 = (rb2502 & ~rb2504 & ~rb2505) | (rb2504 & ~rb2502 & ~rb2503);
  assign rb2510 = (rb2503 & ~rb2504 & ~rb2505) | (rb2505 & ~rb2502 & ~rb2503);
  assign rb2511 = rb2507 | (rb2509 & ~rb2506);
  assign rb2512 = rb2508 | (rb2510 & rb2506);
  assign rb2513 = (rb2509 | rb2510) & rb2506;
  assign rb2514 = (rb2509 | rb2510) & ~rb2506;
  assign rb2515 = 1'b0;
  assign rb2516 = 1'b0;
  assign rb2517 = 1'b0;
  assign rb2518 = 1'b0;
  assign rb2519 = 1'b0 | 1'b0;
  assign rb2520 = rb2515 & rb2517;
  assign rb2521 = rb2516 & rb2518;
  assign rb2522 = (rb2515 & ~rb2517 & ~rb2518) | (rb2517 & ~rb2515 & ~rb2516);
  assign rb2523 = (rb2516 & ~rb2517 & ~rb2518) | (rb2518 & ~rb2515 & ~rb2516);
  assign rb2524 = rb2520 | (rb2522 & ~rb2519);
  assign rb2525 = rb2521 | (rb2523 & rb2519);
  assign rb2526 = (rb2522 | rb2523) & rb2519;
  assign rb2527 = (rb2522 | rb2523) & ~rb2519;
  assign rb2528 = pp392;
  assign rb2529 = pp393;
  assign rb2530 = 1'b0;
  assign rb2531 = 1'b0;
  assign rb2532 = 1'b0 | 1'b0;
  assign rb2533 = rb2528 & rb2530;
  assign rb2534 = rb2529 & rb2531;
  assign rb2535 = (rb2528 & ~rb2530 & ~rb2531) | (rb2530 & ~rb2528 & ~rb2529);
  assign rb2536 = (rb2529 & ~rb2530 & ~rb2531) | (rb2531 & ~rb2528 & ~rb2529);
  assign rb2537 = rb2533 | (rb2535 & ~rb2532);
  assign rb2538 = rb2534 | (rb2536 & rb2532);
  assign rb2539 = (rb2535 | rb2536) & rb2532;
  assign rb2540 = (rb2535 | rb2536) & ~rb2532;
  assign rb2541 = pp394;
  assign rb2542 = pp395;
  assign rb2543 = pp450;
  assign rb2544 = pp451;
  assign rb2545 = pp393 | 1'b0;
  assign rb2546 = rb2541 & rb2543;
  assign rb2547 = rb2542 & rb2544;
  assign rb2548 = (rb2541 & ~rb2543 & ~rb2544) | (rb2543 & ~rb2541 & ~rb2542);
  assign rb2549 = (rb2542 & ~rb2543 & ~rb2544) | (rb2544 & ~rb2541 & ~rb2542);
  assign rb2550 = rb2546 | (rb2548 & ~rb2545);
  assign rb2551 = rb2547 | (rb2549 & rb2545);
  assign rb2552 = (rb2548 | rb2549) & rb2545;
  assign rb2553 = (rb2548 | rb2549) & ~rb2545;
  assign rb2554 = pp396;
  assign rb2555 = pp397;
  assign rb2556 = pp452;
  assign rb2557 = pp453;
  assign rb2558 = pp395 | pp451;
  assign rb2559 = rb2554 & rb2556;
  assign rb2560 = rb2555 & rb2557;
  assign rb2561 = (rb2554 & ~rb2556 & ~rb2557) | (rb2556 & ~rb2554 & ~rb2555);
  assign rb2562 = (rb2555 & ~rb2556 & ~rb2557) | (rb2557 & ~rb2554 & ~rb2555);
  assign rb2563 = rb2559 | (rb2561 & ~rb2558);
  assign rb2564 = rb2560 | (rb2562 & rb2558);
  assign rb2565 = (rb2561 | rb2562) & rb2558;
  assign rb2566 = (rb2561 | rb2562) & ~rb2558;
  assign rb2567 = pp398;
  assign rb2568 = pp399;
  assign rb2569 = pp454;
  assign rb2570 = pp455;
  assign rb2571 = pp397 | pp453;
  assign rb2572 = rb2567 & rb2569;
  assign rb2573 = rb2568 & rb2570;
  assign rb2574 = (rb2567 & ~rb2569 & ~rb2570) | (rb2569 & ~rb2567 & ~rb2568);
  assign rb2575 = (rb2568 & ~rb2569 & ~rb2570) | (rb2570 & ~rb2567 & ~rb2568);
  assign rb2576 = rb2572 | (rb2574 & ~rb2571);
  assign rb2577 = rb2573 | (rb2575 & rb2571);
  assign rb2578 = (rb2574 | rb2575) & rb2571;
  assign rb2579 = (rb2574 | rb2575) & ~rb2571;
  assign rb2580 = pp400;
  assign rb2581 = pp401;
  assign rb2582 = pp456;
  assign rb2583 = pp457;
  assign rb2584 = pp399 | pp455;
  assign rb2585 = rb2580 & rb2582;
  assign rb2586 = rb2581 & rb2583;
  assign rb2587 = (rb2580 & ~rb2582 & ~rb2583) | (rb2582 & ~rb2580 & ~rb2581);
  assign rb2588 = (rb2581 & ~rb2582 & ~rb2583) | (rb2583 & ~rb2580 & ~rb2581);
  assign rb2589 = rb2585 | (rb2587 & ~rb2584);
  assign rb2590 = rb2586 | (rb2588 & rb2584);
  assign rb2591 = (rb2587 | rb2588) & rb2584;
  assign rb2592 = (rb2587 | rb2588) & ~rb2584;
  assign rb2593 = pp402;
  assign rb2594 = pp403;
  assign rb2595 = pp458;
  assign rb2596 = pp459;
  assign rb2597 = pp401 | pp457;
  assign rb2598 = rb2593 & rb2595;
  assign rb2599 = rb2594 & rb2596;
  assign rb2600 = (rb2593 & ~rb2595 & ~rb2596) | (rb2595 & ~rb2593 & ~rb2594);
  assign rb2601 = (rb2594 & ~rb2595 & ~rb2596) | (rb2596 & ~rb2593 & ~rb2594);
  assign rb2602 = rb2598 | (rb2600 & ~rb2597);
  assign rb2603 = rb2599 | (rb2601 & rb2597);
  assign rb2604 = (rb2600 | rb2601) & rb2597;
  assign rb2605 = (rb2600 | rb2601) & ~rb2597;
  assign rb2606 = pp404;
  assign rb2607 = pp405;
  assign rb2608 = pp460;
  assign rb2609 = pp461;
  assign rb2610 = pp403 | pp459;
  assign rb2611 = rb2606 & rb2608;
  assign rb2612 = rb2607 & rb2609;
  assign rb2613 = (rb2606 & ~rb2608 & ~rb2609) | (rb2608 & ~rb2606 & ~rb2607);
  assign rb2614 = (rb2607 & ~rb2608 & ~rb2609) | (rb2609 & ~rb2606 & ~rb2607);
  assign rb2615 = rb2611 | (rb2613 & ~rb2610);
  assign rb2616 = rb2612 | (rb2614 & rb2610);
  assign rb2617 = (rb2613 | rb2614) & rb2610;
  assign rb2618 = (rb2613 | rb2614) & ~rb2610;
  assign rb2619 = pp406;
  assign rb2620 = pp407;
  assign rb2621 = pp462;
  assign rb2622 = pp463;
  assign rb2623 = pp405 | pp461;
  assign rb2624 = rb2619 & rb2621;
  assign rb2625 = rb2620 & rb2622;
  assign rb2626 = (rb2619 & ~rb2621 & ~rb2622) | (rb2621 & ~rb2619 & ~rb2620);
  assign rb2627 = (rb2620 & ~rb2621 & ~rb2622) | (rb2622 & ~rb2619 & ~rb2620);
  assign rb2628 = rb2624 | (rb2626 & ~rb2623);
  assign rb2629 = rb2625 | (rb2627 & rb2623);
  assign rb2630 = (rb2626 | rb2627) & rb2623;
  assign rb2631 = (rb2626 | rb2627) & ~rb2623;
  assign rb2632 = pp408;
  assign rb2633 = pp409;
  assign rb2634 = pp464;
  assign rb2635 = pp465;
  assign rb2636 = pp407 | pp463;
  assign rb2637 = rb2632 & rb2634;
  assign rb2638 = rb2633 & rb2635;
  assign rb2639 = (rb2632 & ~rb2634 & ~rb2635) | (rb2634 & ~rb2632 & ~rb2633);
  assign rb2640 = (rb2633 & ~rb2634 & ~rb2635) | (rb2635 & ~rb2632 & ~rb2633);
  assign rb2641 = rb2637 | (rb2639 & ~rb2636);
  assign rb2642 = rb2638 | (rb2640 & rb2636);
  assign rb2643 = (rb2639 | rb2640) & rb2636;
  assign rb2644 = (rb2639 | rb2640) & ~rb2636;
  assign rb2645 = pp410;
  assign rb2646 = pp411;
  assign rb2647 = pp466;
  assign rb2648 = pp467;
  assign rb2649 = pp409 | pp465;
  assign rb2650 = rb2645 & rb2647;
  assign rb2651 = rb2646 & rb2648;
  assign rb2652 = (rb2645 & ~rb2647 & ~rb2648) | (rb2647 & ~rb2645 & ~rb2646);
  assign rb2653 = (rb2646 & ~rb2647 & ~rb2648) | (rb2648 & ~rb2645 & ~rb2646);
  assign rb2654 = rb2650 | (rb2652 & ~rb2649);
  assign rb2655 = rb2651 | (rb2653 & rb2649);
  assign rb2656 = (rb2652 | rb2653) & rb2649;
  assign rb2657 = (rb2652 | rb2653) & ~rb2649;
  assign rb2658 = pp412;
  assign rb2659 = pp413;
  assign rb2660 = pp468;
  assign rb2661 = pp469;
  assign rb2662 = pp411 | pp467;
  assign rb2663 = rb2658 & rb2660;
  assign rb2664 = rb2659 & rb2661;
  assign rb2665 = (rb2658 & ~rb2660 & ~rb2661) | (rb2660 & ~rb2658 & ~rb2659);
  assign rb2666 = (rb2659 & ~rb2660 & ~rb2661) | (rb2661 & ~rb2658 & ~rb2659);
  assign rb2667 = rb2663 | (rb2665 & ~rb2662);
  assign rb2668 = rb2664 | (rb2666 & rb2662);
  assign rb2669 = (rb2665 | rb2666) & rb2662;
  assign rb2670 = (rb2665 | rb2666) & ~rb2662;
  assign rb2671 = pp414;
  assign rb2672 = pp415;
  assign rb2673 = pp470;
  assign rb2674 = pp471;
  assign rb2675 = pp413 | pp469;
  assign rb2676 = rb2671 & rb2673;
  assign rb2677 = rb2672 & rb2674;
  assign rb2678 = (rb2671 & ~rb2673 & ~rb2674) | (rb2673 & ~rb2671 & ~rb2672);
  assign rb2679 = (rb2672 & ~rb2673 & ~rb2674) | (rb2674 & ~rb2671 & ~rb2672);
  assign rb2680 = rb2676 | (rb2678 & ~rb2675);
  assign rb2681 = rb2677 | (rb2679 & rb2675);
  assign rb2682 = (rb2678 | rb2679) & rb2675;
  assign rb2683 = (rb2678 | rb2679) & ~rb2675;
  assign rb2684 = pp416;
  assign rb2685 = pp417;
  assign rb2686 = pp472;
  assign rb2687 = pp473;
  assign rb2688 = pp415 | pp471;
  assign rb2689 = rb2684 & rb2686;
  assign rb2690 = rb2685 & rb2687;
  assign rb2691 = (rb2684 & ~rb2686 & ~rb2687) | (rb2686 & ~rb2684 & ~rb2685);
  assign rb2692 = (rb2685 & ~rb2686 & ~rb2687) | (rb2687 & ~rb2684 & ~rb2685);
  assign rb2693 = rb2689 | (rb2691 & ~rb2688);
  assign rb2694 = rb2690 | (rb2692 & rb2688);
  assign rb2695 = (rb2691 | rb2692) & rb2688;
  assign rb2696 = (rb2691 | rb2692) & ~rb2688;
  assign rb2697 = pp418;
  assign rb2698 = pp419;
  assign rb2699 = pp474;
  assign rb2700 = pp475;
  assign rb2701 = pp417 | pp473;
  assign rb2702 = rb2697 & rb2699;
  assign rb2703 = rb2698 & rb2700;
  assign rb2704 = (rb2697 & ~rb2699 & ~rb2700) | (rb2699 & ~rb2697 & ~rb2698);
  assign rb2705 = (rb2698 & ~rb2699 & ~rb2700) | (rb2700 & ~rb2697 & ~rb2698);
  assign rb2706 = rb2702 | (rb2704 & ~rb2701);
  assign rb2707 = rb2703 | (rb2705 & rb2701);
  assign rb2708 = (rb2704 | rb2705) & rb2701;
  assign rb2709 = (rb2704 | rb2705) & ~rb2701;
  assign rb2710 = pp420;
  assign rb2711 = pp421;
  assign rb2712 = pp476;
  assign rb2713 = pp477;
  assign rb2714 = pp419 | pp475;
  assign rb2715 = rb2710 & rb2712;
  assign rb2716 = rb2711 & rb2713;
  assign rb2717 = (rb2710 & ~rb2712 & ~rb2713) | (rb2712 & ~rb2710 & ~rb2711);
  assign rb2718 = (rb2711 & ~rb2712 & ~rb2713) | (rb2713 & ~rb2710 & ~rb2711);
  assign rb2719 = rb2715 | (rb2717 & ~rb2714);
  assign rb2720 = rb2716 | (rb2718 & rb2714);
  assign rb2721 = (rb2717 | rb2718) & rb2714;
  assign rb2722 = (rb2717 | rb2718) & ~rb2714;
  assign rb2723 = pp422;
  assign rb2724 = pp423;
  assign rb2725 = pp478;
  assign rb2726 = pp479;
  assign rb2727 = pp421 | pp477;
  assign rb2728 = rb2723 & rb2725;
  assign rb2729 = rb2724 & rb2726;
  assign rb2730 = (rb2723 & ~rb2725 & ~rb2726) | (rb2725 & ~rb2723 & ~rb2724);
  assign rb2731 = (rb2724 & ~rb2725 & ~rb2726) | (rb2726 & ~rb2723 & ~rb2724);
  assign rb2732 = rb2728 | (rb2730 & ~rb2727);
  assign rb2733 = rb2729 | (rb2731 & rb2727);
  assign rb2734 = (rb2730 | rb2731) & rb2727;
  assign rb2735 = (rb2730 | rb2731) & ~rb2727;
  assign rb2736 = pp424;
  assign rb2737 = pp425;
  assign rb2738 = pp480;
  assign rb2739 = pp481;
  assign rb2740 = pp423 | pp479;
  assign rb2741 = rb2736 & rb2738;
  assign rb2742 = rb2737 & rb2739;
  assign rb2743 = (rb2736 & ~rb2738 & ~rb2739) | (rb2738 & ~rb2736 & ~rb2737);
  assign rb2744 = (rb2737 & ~rb2738 & ~rb2739) | (rb2739 & ~rb2736 & ~rb2737);
  assign rb2745 = rb2741 | (rb2743 & ~rb2740);
  assign rb2746 = rb2742 | (rb2744 & rb2740);
  assign rb2747 = (rb2743 | rb2744) & rb2740;
  assign rb2748 = (rb2743 | rb2744) & ~rb2740;
  assign rb2749 = pp426;
  assign rb2750 = pp427;
  assign rb2751 = pp482;
  assign rb2752 = pp483;
  assign rb2753 = pp425 | pp481;
  assign rb2754 = rb2749 & rb2751;
  assign rb2755 = rb2750 & rb2752;
  assign rb2756 = (rb2749 & ~rb2751 & ~rb2752) | (rb2751 & ~rb2749 & ~rb2750);
  assign rb2757 = (rb2750 & ~rb2751 & ~rb2752) | (rb2752 & ~rb2749 & ~rb2750);
  assign rb2758 = rb2754 | (rb2756 & ~rb2753);
  assign rb2759 = rb2755 | (rb2757 & rb2753);
  assign rb2760 = (rb2756 | rb2757) & rb2753;
  assign rb2761 = (rb2756 | rb2757) & ~rb2753;
  assign rb2762 = pp428;
  assign rb2763 = pp429;
  assign rb2764 = pp484;
  assign rb2765 = pp485;
  assign rb2766 = pp427 | pp483;
  assign rb2767 = rb2762 & rb2764;
  assign rb2768 = rb2763 & rb2765;
  assign rb2769 = (rb2762 & ~rb2764 & ~rb2765) | (rb2764 & ~rb2762 & ~rb2763);
  assign rb2770 = (rb2763 & ~rb2764 & ~rb2765) | (rb2765 & ~rb2762 & ~rb2763);
  assign rb2771 = rb2767 | (rb2769 & ~rb2766);
  assign rb2772 = rb2768 | (rb2770 & rb2766);
  assign rb2773 = (rb2769 | rb2770) & rb2766;
  assign rb2774 = (rb2769 | rb2770) & ~rb2766;
  assign rb2775 = pp430;
  assign rb2776 = pp431;
  assign rb2777 = pp486;
  assign rb2778 = pp487;
  assign rb2779 = pp429 | pp485;
  assign rb2780 = rb2775 & rb2777;
  assign rb2781 = rb2776 & rb2778;
  assign rb2782 = (rb2775 & ~rb2777 & ~rb2778) | (rb2777 & ~rb2775 & ~rb2776);
  assign rb2783 = (rb2776 & ~rb2777 & ~rb2778) | (rb2778 & ~rb2775 & ~rb2776);
  assign rb2784 = rb2780 | (rb2782 & ~rb2779);
  assign rb2785 = rb2781 | (rb2783 & rb2779);
  assign rb2786 = (rb2782 | rb2783) & rb2779;
  assign rb2787 = (rb2782 | rb2783) & ~rb2779;
  assign rb2788 = pp432;
  assign rb2789 = pp433;
  assign rb2790 = pp488;
  assign rb2791 = pp489;
  assign rb2792 = pp431 | pp487;
  assign rb2793 = rb2788 & rb2790;
  assign rb2794 = rb2789 & rb2791;
  assign rb2795 = (rb2788 & ~rb2790 & ~rb2791) | (rb2790 & ~rb2788 & ~rb2789);
  assign rb2796 = (rb2789 & ~rb2790 & ~rb2791) | (rb2791 & ~rb2788 & ~rb2789);
  assign rb2797 = rb2793 | (rb2795 & ~rb2792);
  assign rb2798 = rb2794 | (rb2796 & rb2792);
  assign rb2799 = (rb2795 | rb2796) & rb2792;
  assign rb2800 = (rb2795 | rb2796) & ~rb2792;
  assign rb2801 = pp434;
  assign rb2802 = pp435;
  assign rb2803 = pp490;
  assign rb2804 = pp491;
  assign rb2805 = pp433 | pp489;
  assign rb2806 = rb2801 & rb2803;
  assign rb2807 = rb2802 & rb2804;
  assign rb2808 = (rb2801 & ~rb2803 & ~rb2804) | (rb2803 & ~rb2801 & ~rb2802);
  assign rb2809 = (rb2802 & ~rb2803 & ~rb2804) | (rb2804 & ~rb2801 & ~rb2802);
  assign rb2810 = rb2806 | (rb2808 & ~rb2805);
  assign rb2811 = rb2807 | (rb2809 & rb2805);
  assign rb2812 = (rb2808 | rb2809) & rb2805;
  assign rb2813 = (rb2808 | rb2809) & ~rb2805;
  assign rb2814 = pp436;
  assign rb2815 = pp437;
  assign rb2816 = pp492;
  assign rb2817 = pp493;
  assign rb2818 = pp435 | pp491;
  assign rb2819 = rb2814 & rb2816;
  assign rb2820 = rb2815 & rb2817;
  assign rb2821 = (rb2814 & ~rb2816 & ~rb2817) | (rb2816 & ~rb2814 & ~rb2815);
  assign rb2822 = (rb2815 & ~rb2816 & ~rb2817) | (rb2817 & ~rb2814 & ~rb2815);
  assign rb2823 = rb2819 | (rb2821 & ~rb2818);
  assign rb2824 = rb2820 | (rb2822 & rb2818);
  assign rb2825 = (rb2821 | rb2822) & rb2818;
  assign rb2826 = (rb2821 | rb2822) & ~rb2818;
  assign rb2827 = pp438;
  assign rb2828 = pp439;
  assign rb2829 = pp494;
  assign rb2830 = pp495;
  assign rb2831 = pp437 | pp493;
  assign rb2832 = rb2827 & rb2829;
  assign rb2833 = rb2828 & rb2830;
  assign rb2834 = (rb2827 & ~rb2829 & ~rb2830) | (rb2829 & ~rb2827 & ~rb2828);
  assign rb2835 = (rb2828 & ~rb2829 & ~rb2830) | (rb2830 & ~rb2827 & ~rb2828);
  assign rb2836 = rb2832 | (rb2834 & ~rb2831);
  assign rb2837 = rb2833 | (rb2835 & rb2831);
  assign rb2838 = (rb2834 | rb2835) & rb2831;
  assign rb2839 = (rb2834 | rb2835) & ~rb2831;
  assign rb2840 = pp440;
  assign rb2841 = pp441;
  assign rb2842 = pp496;
  assign rb2843 = pp497;
  assign rb2844 = pp439 | pp495;
  assign rb2845 = rb2840 & rb2842;
  assign rb2846 = rb2841 & rb2843;
  assign rb2847 = (rb2840 & ~rb2842 & ~rb2843) | (rb2842 & ~rb2840 & ~rb2841);
  assign rb2848 = (rb2841 & ~rb2842 & ~rb2843) | (rb2843 & ~rb2840 & ~rb2841);
  assign rb2849 = rb2845 | (rb2847 & ~rb2844);
  assign rb2850 = rb2846 | (rb2848 & rb2844);
  assign rb2851 = (rb2847 | rb2848) & rb2844;
  assign rb2852 = (rb2847 | rb2848) & ~rb2844;
  assign rb2853 = pp442;
  assign rb2854 = pp443;
  assign rb2855 = pp498;
  assign rb2856 = pp499;
  assign rb2857 = pp441 | pp497;
  assign rb2858 = rb2853 & rb2855;
  assign rb2859 = rb2854 & rb2856;
  assign rb2860 = (rb2853 & ~rb2855 & ~rb2856) | (rb2855 & ~rb2853 & ~rb2854);
  assign rb2861 = (rb2854 & ~rb2855 & ~rb2856) | (rb2856 & ~rb2853 & ~rb2854);
  assign rb2862 = rb2858 | (rb2860 & ~rb2857);
  assign rb2863 = rb2859 | (rb2861 & rb2857);
  assign rb2864 = (rb2860 | rb2861) & rb2857;
  assign rb2865 = (rb2860 | rb2861) & ~rb2857;
  assign rb2866 = pp444;
  assign rb2867 = pp445;
  assign rb2868 = pp500;
  assign rb2869 = pp501;
  assign rb2870 = pp443 | pp499;
  assign rb2871 = rb2866 & rb2868;
  assign rb2872 = rb2867 & rb2869;
  assign rb2873 = (rb2866 & ~rb2868 & ~rb2869) | (rb2868 & ~rb2866 & ~rb2867);
  assign rb2874 = (rb2867 & ~rb2868 & ~rb2869) | (rb2869 & ~rb2866 & ~rb2867);
  assign rb2875 = rb2871 | (rb2873 & ~rb2870);
  assign rb2876 = rb2872 | (rb2874 & rb2870);
  assign rb2877 = (rb2873 | rb2874) & rb2870;
  assign rb2878 = (rb2873 | rb2874) & ~rb2870;
  assign rb2879 = pp446;
  assign rb2880 = pp447;
  assign rb2881 = pp502;
  assign rb2882 = pp503;
  assign rb2883 = pp445 | pp501;
  assign rb2884 = rb2879 & rb2881;
  assign rb2885 = rb2880 & rb2882;
  assign rb2886 = (rb2879 & ~rb2881 & ~rb2882) | (rb2881 & ~rb2879 & ~rb2880);
  assign rb2887 = (rb2880 & ~rb2881 & ~rb2882) | (rb2882 & ~rb2879 & ~rb2880);
  assign rb2888 = rb2884 | (rb2886 & ~rb2883);
  assign rb2889 = rb2885 | (rb2887 & rb2883);
  assign rb2890 = (rb2886 | rb2887) & rb2883;
  assign rb2891 = (rb2886 | rb2887) & ~rb2883;
  assign rb2892 = (rb2461 & ~1'b0) | (1'b0 & ~rb2462);
  assign rb2893 = (rb2462 & ~1'b0) | (1'b0 & ~rb2461);
  assign rb2894 = (rb2474 & ~rb2460) | (rb2459 & ~rb2475);
  assign rb2895 = (rb2475 & ~rb2459) | (rb2460 & ~rb2474);
  assign rb2896 = (rb2487 & ~rb2473) | (rb2472 & ~rb2488);
  assign rb2897 = (rb2488 & ~rb2472) | (rb2473 & ~rb2487);
  assign rb2898 = (rb2500 & ~rb2486) | (rb2485 & ~rb2501);
  assign rb2899 = (rb2501 & ~rb2485) | (rb2486 & ~rb2500);
  assign rb2900 = (rb2513 & ~rb2499) | (rb2498 & ~rb2514);
  assign rb2901 = (rb2514 & ~rb2498) | (rb2499 & ~rb2513);
  assign rb2902 = (rb2526 & ~rb2512) | (rb2511 & ~rb2527);
  assign rb2903 = (rb2527 & ~rb2511) | (rb2512 & ~rb2526);
  assign rb2904 = (rb2539 & ~rb2525) | (rb2524 & ~rb2540);
  assign rb2905 = (rb2540 & ~rb2524) | (rb2525 & ~rb2539);
  assign rb2906 = (rb2552 & ~rb2538) | (rb2537 & ~rb2553);
  assign rb2907 = (rb2553 & ~rb2537) | (rb2538 & ~rb2552);
  assign rb2908 = (rb2565 & ~rb2551) | (rb2550 & ~rb2566);
  assign rb2909 = (rb2566 & ~rb2550) | (rb2551 & ~rb2565);
  assign rb2910 = (rb2578 & ~rb2564) | (rb2563 & ~rb2579);
  assign rb2911 = (rb2579 & ~rb2563) | (rb2564 & ~rb2578);
  assign rb2912 = (rb2591 & ~rb2577) | (rb2576 & ~rb2592);
  assign rb2913 = (rb2592 & ~rb2576) | (rb2577 & ~rb2591);
  assign rb2914 = (rb2604 & ~rb2590) | (rb2589 & ~rb2605);
  assign rb2915 = (rb2605 & ~rb2589) | (rb2590 & ~rb2604);
  assign rb2916 = (rb2617 & ~rb2603) | (rb2602 & ~rb2618);
  assign rb2917 = (rb2618 & ~rb2602) | (rb2603 & ~rb2617);
  assign rb2918 = (rb2630 & ~rb2616) | (rb2615 & ~rb2631);
  assign rb2919 = (rb2631 & ~rb2615) | (rb2616 & ~rb2630);
  assign rb2920 = (rb2643 & ~rb2629) | (rb2628 & ~rb2644);
  assign rb2921 = (rb2644 & ~rb2628) | (rb2629 & ~rb2643);
  assign rb2922 = (rb2656 & ~rb2642) | (rb2641 & ~rb2657);
  assign rb2923 = (rb2657 & ~rb2641) | (rb2642 & ~rb2656);
  assign rb2924 = (rb2669 & ~rb2655) | (rb2654 & ~rb2670);
  assign rb2925 = (rb2670 & ~rb2654) | (rb2655 & ~rb2669);
  assign rb2926 = (rb2682 & ~rb2668) | (rb2667 & ~rb2683);
  assign rb2927 = (rb2683 & ~rb2667) | (rb2668 & ~rb2682);
  assign rb2928 = (rb2695 & ~rb2681) | (rb2680 & ~rb2696);
  assign rb2929 = (rb2696 & ~rb2680) | (rb2681 & ~rb2695);
  assign rb2930 = (rb2708 & ~rb2694) | (rb2693 & ~rb2709);
  assign rb2931 = (rb2709 & ~rb2693) | (rb2694 & ~rb2708);
  assign rb2932 = (rb2721 & ~rb2707) | (rb2706 & ~rb2722);
  assign rb2933 = (rb2722 & ~rb2706) | (rb2707 & ~rb2721);
  assign rb2934 = (rb2734 & ~rb2720) | (rb2719 & ~rb2735);
  assign rb2935 = (rb2735 & ~rb2719) | (rb2720 & ~rb2734);
  assign rb2936 = (rb2747 & ~rb2733) | (rb2732 & ~rb2748);
  assign rb2937 = (rb2748 & ~rb2732) | (rb2733 & ~rb2747);
  assign rb2938 = (rb2760 & ~rb2746) | (rb2745 & ~rb2761);
  assign rb2939 = (rb2761 & ~rb2745) | (rb2746 & ~rb2760);
  assign rb2940 = (rb2773 & ~rb2759) | (rb2758 & ~rb2774);
  assign rb2941 = (rb2774 & ~rb2758) | (rb2759 & ~rb2773);
  assign rb2942 = (rb2786 & ~rb2772) | (rb2771 & ~rb2787);
  assign rb2943 = (rb2787 & ~rb2771) | (rb2772 & ~rb2786);
  assign rb2944 = (rb2799 & ~rb2785) | (rb2784 & ~rb2800);
  assign rb2945 = (rb2800 & ~rb2784) | (rb2785 & ~rb2799);
  assign rb2946 = (rb2812 & ~rb2798) | (rb2797 & ~rb2813);
  assign rb2947 = (rb2813 & ~rb2797) | (rb2798 & ~rb2812);
  assign rb2948 = (rb2825 & ~rb2811) | (rb2810 & ~rb2826);
  assign rb2949 = (rb2826 & ~rb2810) | (rb2811 & ~rb2825);
  assign rb2950 = (rb2838 & ~rb2824) | (rb2823 & ~rb2839);
  assign rb2951 = (rb2839 & ~rb2823) | (rb2824 & ~rb2838);
  assign rb2952 = (rb2851 & ~rb2837) | (rb2836 & ~rb2852);
  assign rb2953 = (rb2852 & ~rb2836) | (rb2837 & ~rb2851);
  assign rb2954 = (rb2864 & ~rb2850) | (rb2849 & ~rb2865);
  assign rb2955 = (rb2865 & ~rb2849) | (rb2850 & ~rb2864);
  assign rb2956 = (rb2877 & ~rb2863) | (rb2862 & ~rb2878);
  assign rb2957 = (rb2878 & ~rb2862) | (rb2863 & ~rb2877);
  assign rb2958 = (rb2890 & ~rb2876) | (rb2875 & ~rb2891);
  assign rb2959 = (rb2891 & ~rb2875) | (rb2876 & ~rb2890);
  assign rb2960 = (1'b0 & ~rb2889) | (rb2888 & ~1'b0);
  assign rb2961 = (1'b0 & ~rb2888) | (rb2889 & ~1'b0);
  assign rb2962 = 1'b0;
  assign rb2963 = 1'b0;
  assign rb2964 = 1'b0;
  assign rb2965 = 1'b0;
  assign rb2966 = rb2962 & rb2964;
  assign rb2967 = rb2963 & rb2965;
  assign rb2968 = (rb2962 & ~rb2964 & ~rb2965) | (rb2964 & ~rb2962 & ~rb2963);
  assign rb2969 = (rb2963 & ~rb2964 & ~rb2965) | (rb2965 & ~rb2962 & ~rb2963);
  assign rb2970 = rb2966 | (rb2968 & ~1'b0);
  assign rb2971 = rb2967 | (rb2969 & 1'b0);
  assign rb2972 = (rb2968 | rb2969) & 1'b0;
  assign rb2973 = (rb2968 | rb2969) & ~1'b0;
  assign rb2974 = 1'b0;
  assign rb2975 = 1'b0;
  assign rb2976 = 1'b0;
  assign rb2977 = 1'b0;
  assign rb2978 = 1'b0 | 1'b0;
  assign rb2979 = rb2974 & rb2976;
  assign rb2980 = rb2975 & rb2977;
  assign rb2981 = (rb2974 & ~rb2976 & ~rb2977) | (rb2976 & ~rb2974 & ~rb2975);
  assign rb2982 = (rb2975 & ~rb2976 & ~rb2977) | (rb2977 & ~rb2974 & ~rb2975);
  assign rb2983 = rb2979 | (rb2981 & ~rb2978);
  assign rb2984 = rb2980 | (rb2982 & rb2978);
  assign rb2985 = (rb2981 | rb2982) & rb2978;
  assign rb2986 = (rb2981 | rb2982) & ~rb2978;
  assign rb2987 = 1'b0;
  assign rb2988 = 1'b0;
  assign rb2989 = 1'b0;
  assign rb2990 = 1'b0;
  assign rb2991 = 1'b0 | 1'b0;
  assign rb2992 = rb2987 & rb2989;
  assign rb2993 = rb2988 & rb2990;
  assign rb2994 = (rb2987 & ~rb2989 & ~rb2990) | (rb2989 & ~rb2987 & ~rb2988);
  assign rb2995 = (rb2988 & ~rb2989 & ~rb2990) | (rb2990 & ~rb2987 & ~rb2988);
  assign rb2996 = rb2992 | (rb2994 & ~rb2991);
  assign rb2997 = rb2993 | (rb2995 & rb2991);
  assign rb2998 = (rb2994 | rb2995) & rb2991;
  assign rb2999 = (rb2994 | rb2995) & ~rb2991;
  assign rb3000 = 1'b0;
  assign rb3001 = 1'b0;
  assign rb3002 = 1'b0;
  assign rb3003 = 1'b0;
  assign rb3004 = 1'b0 | 1'b0;
  assign rb3005 = rb3000 & rb3002;
  assign rb3006 = rb3001 & rb3003;
  assign rb3007 = (rb3000 & ~rb3002 & ~rb3003) | (rb3002 & ~rb3000 & ~rb3001);
  assign rb3008 = (rb3001 & ~rb3002 & ~rb3003) | (rb3003 & ~rb3000 & ~rb3001);
  assign rb3009 = rb3005 | (rb3007 & ~rb3004);
  assign rb3010 = rb3006 | (rb3008 & rb3004);
  assign rb3011 = (rb3007 | rb3008) & rb3004;
  assign rb3012 = (rb3007 | rb3008) & ~rb3004;
  assign rb3013 = 1'b0;
  assign rb3014 = 1'b0;
  assign rb3015 = 1'b0;
  assign rb3016 = 1'b0;
  assign rb3017 = 1'b0 | 1'b0;
  assign rb3018 = rb3013 & rb3015;
  assign rb3019 = rb3014 & rb3016;
  assign rb3020 = (rb3013 & ~rb3015 & ~rb3016) | (rb3015 & ~rb3013 & ~rb3014);
  assign rb3021 = (rb3014 & ~rb3015 & ~rb3016) | (rb3016 & ~rb3013 & ~rb3014);
  assign rb3022 = rb3018 | (rb3020 & ~rb3017);
  assign rb3023 = rb3019 | (rb3021 & rb3017);
  assign rb3024 = (rb3020 | rb3021) & rb3017;
  assign rb3025 = (rb3020 | rb3021) & ~rb3017;
  assign rb3026 = 1'b0;
  assign rb3027 = 1'b0;
  assign rb3028 = 1'b0;
  assign rb3029 = 1'b0;
  assign rb3030 = 1'b0 | 1'b0;
  assign rb3031 = rb3026 & rb3028;
  assign rb3032 = rb3027 & rb3029;
  assign rb3033 = (rb3026 & ~rb3028 & ~rb3029) | (rb3028 & ~rb3026 & ~rb3027);
  assign rb3034 = (rb3027 & ~rb3028 & ~rb3029) | (rb3029 & ~rb3026 & ~rb3027);
  assign rb3035 = rb3031 | (rb3033 & ~rb3030);
  assign rb3036 = rb3032 | (rb3034 & rb3030);
  assign rb3037 = (rb3033 | rb3034) & rb3030;
  assign rb3038 = (rb3033 | rb3034) & ~rb3030;
  assign rb3039 = 1'b0;
  assign rb3040 = 1'b0;
  assign rb3041 = 1'b0;
  assign rb3042 = 1'b0;
  assign rb3043 = 1'b0 | 1'b0;
  assign rb3044 = rb3039 & rb3041;
  assign rb3045 = rb3040 & rb3042;
  assign rb3046 = (rb3039 & ~rb3041 & ~rb3042) | (rb3041 & ~rb3039 & ~rb3040);
  assign rb3047 = (rb3040 & ~rb3041 & ~rb3042) | (rb3042 & ~rb3039 & ~rb3040);
  assign rb3048 = rb3044 | (rb3046 & ~rb3043);
  assign rb3049 = rb3045 | (rb3047 & rb3043);
  assign rb3050 = (rb3046 | rb3047) & rb3043;
  assign rb3051 = (rb3046 | rb3047) & ~rb3043;
  assign rb3052 = 1'b0;
  assign rb3053 = 1'b0;
  assign rb3054 = 1'b0;
  assign rb3055 = 1'b0;
  assign rb3056 = 1'b0 | 1'b0;
  assign rb3057 = rb3052 & rb3054;
  assign rb3058 = rb3053 & rb3055;
  assign rb3059 = (rb3052 & ~rb3054 & ~rb3055) | (rb3054 & ~rb3052 & ~rb3053);
  assign rb3060 = (rb3053 & ~rb3054 & ~rb3055) | (rb3055 & ~rb3052 & ~rb3053);
  assign rb3061 = rb3057 | (rb3059 & ~rb3056);
  assign rb3062 = rb3058 | (rb3060 & rb3056);
  assign rb3063 = (rb3059 | rb3060) & rb3056;
  assign rb3064 = (rb3059 | rb3060) & ~rb3056;
  assign rb3065 = pp506;
  assign rb3066 = pp507;
  assign rb3067 = 1'b0;
  assign rb3068 = 1'b0;
  assign rb3069 = 1'b0 | 1'b0;
  assign rb3070 = rb3065 & rb3067;
  assign rb3071 = rb3066 & rb3068;
  assign rb3072 = (rb3065 & ~rb3067 & ~rb3068) | (rb3067 & ~rb3065 & ~rb3066);
  assign rb3073 = (rb3066 & ~rb3067 & ~rb3068) | (rb3068 & ~rb3065 & ~rb3066);
  assign rb3074 = rb3070 | (rb3072 & ~rb3069);
  assign rb3075 = rb3071 | (rb3073 & rb3069);
  assign rb3076 = (rb3072 | rb3073) & rb3069;
  assign rb3077 = (rb3072 | rb3073) & ~rb3069;
  assign rb3078 = pp508;
  assign rb3079 = pp509;
  assign rb3080 = pp560;
  assign rb3081 = pp561;
  assign rb3082 = pp507 | 1'b0;
  assign rb3083 = rb3078 & rb3080;
  assign rb3084 = rb3079 & rb3081;
  assign rb3085 = (rb3078 & ~rb3080 & ~rb3081) | (rb3080 & ~rb3078 & ~rb3079);
  assign rb3086 = (rb3079 & ~rb3080 & ~rb3081) | (rb3081 & ~rb3078 & ~rb3079);
  assign rb3087 = rb3083 | (rb3085 & ~rb3082);
  assign rb3088 = rb3084 | (rb3086 & rb3082);
  assign rb3089 = (rb3085 | rb3086) & rb3082;
  assign rb3090 = (rb3085 | rb3086) & ~rb3082;
  assign rb3091 = pp510;
  assign rb3092 = pp511;
  assign rb3093 = pp562;
  assign rb3094 = pp563;
  assign rb3095 = pp509 | pp561;
  assign rb3096 = rb3091 & rb3093;
  assign rb3097 = rb3092 & rb3094;
  assign rb3098 = (rb3091 & ~rb3093 & ~rb3094) | (rb3093 & ~rb3091 & ~rb3092);
  assign rb3099 = (rb3092 & ~rb3093 & ~rb3094) | (rb3094 & ~rb3091 & ~rb3092);
  assign rb3100 = rb3096 | (rb3098 & ~rb3095);
  assign rb3101 = rb3097 | (rb3099 & rb3095);
  assign rb3102 = (rb3098 | rb3099) & rb3095;
  assign rb3103 = (rb3098 | rb3099) & ~rb3095;
  assign rb3104 = pp512;
  assign rb3105 = pp513;
  assign rb3106 = pp564;
  assign rb3107 = pp565;
  assign rb3108 = pp511 | pp563;
  assign rb3109 = rb3104 & rb3106;
  assign rb3110 = rb3105 & rb3107;
  assign rb3111 = (rb3104 & ~rb3106 & ~rb3107) | (rb3106 & ~rb3104 & ~rb3105);
  assign rb3112 = (rb3105 & ~rb3106 & ~rb3107) | (rb3107 & ~rb3104 & ~rb3105);
  assign rb3113 = rb3109 | (rb3111 & ~rb3108);
  assign rb3114 = rb3110 | (rb3112 & rb3108);
  assign rb3115 = (rb3111 | rb3112) & rb3108;
  assign rb3116 = (rb3111 | rb3112) & ~rb3108;
  assign rb3117 = pp514;
  assign rb3118 = pp515;
  assign rb3119 = pp566;
  assign rb3120 = pp567;
  assign rb3121 = pp513 | pp565;
  assign rb3122 = rb3117 & rb3119;
  assign rb3123 = rb3118 & rb3120;
  assign rb3124 = (rb3117 & ~rb3119 & ~rb3120) | (rb3119 & ~rb3117 & ~rb3118);
  assign rb3125 = (rb3118 & ~rb3119 & ~rb3120) | (rb3120 & ~rb3117 & ~rb3118);
  assign rb3126 = rb3122 | (rb3124 & ~rb3121);
  assign rb3127 = rb3123 | (rb3125 & rb3121);
  assign rb3128 = (rb3124 | rb3125) & rb3121;
  assign rb3129 = (rb3124 | rb3125) & ~rb3121;
  assign rb3130 = pp516;
  assign rb3131 = pp517;
  assign rb3132 = pp568;
  assign rb3133 = pp569;
  assign rb3134 = pp515 | pp567;
  assign rb3135 = rb3130 & rb3132;
  assign rb3136 = rb3131 & rb3133;
  assign rb3137 = (rb3130 & ~rb3132 & ~rb3133) | (rb3132 & ~rb3130 & ~rb3131);
  assign rb3138 = (rb3131 & ~rb3132 & ~rb3133) | (rb3133 & ~rb3130 & ~rb3131);
  assign rb3139 = rb3135 | (rb3137 & ~rb3134);
  assign rb3140 = rb3136 | (rb3138 & rb3134);
  assign rb3141 = (rb3137 | rb3138) & rb3134;
  assign rb3142 = (rb3137 | rb3138) & ~rb3134;
  assign rb3143 = pp518;
  assign rb3144 = pp519;
  assign rb3145 = pp570;
  assign rb3146 = pp571;
  assign rb3147 = pp517 | pp569;
  assign rb3148 = rb3143 & rb3145;
  assign rb3149 = rb3144 & rb3146;
  assign rb3150 = (rb3143 & ~rb3145 & ~rb3146) | (rb3145 & ~rb3143 & ~rb3144);
  assign rb3151 = (rb3144 & ~rb3145 & ~rb3146) | (rb3146 & ~rb3143 & ~rb3144);
  assign rb3152 = rb3148 | (rb3150 & ~rb3147);
  assign rb3153 = rb3149 | (rb3151 & rb3147);
  assign rb3154 = (rb3150 | rb3151) & rb3147;
  assign rb3155 = (rb3150 | rb3151) & ~rb3147;
  assign rb3156 = pp520;
  assign rb3157 = pp521;
  assign rb3158 = pp572;
  assign rb3159 = pp573;
  assign rb3160 = pp519 | pp571;
  assign rb3161 = rb3156 & rb3158;
  assign rb3162 = rb3157 & rb3159;
  assign rb3163 = (rb3156 & ~rb3158 & ~rb3159) | (rb3158 & ~rb3156 & ~rb3157);
  assign rb3164 = (rb3157 & ~rb3158 & ~rb3159) | (rb3159 & ~rb3156 & ~rb3157);
  assign rb3165 = rb3161 | (rb3163 & ~rb3160);
  assign rb3166 = rb3162 | (rb3164 & rb3160);
  assign rb3167 = (rb3163 | rb3164) & rb3160;
  assign rb3168 = (rb3163 | rb3164) & ~rb3160;
  assign rb3169 = pp522;
  assign rb3170 = pp523;
  assign rb3171 = pp574;
  assign rb3172 = pp575;
  assign rb3173 = pp521 | pp573;
  assign rb3174 = rb3169 & rb3171;
  assign rb3175 = rb3170 & rb3172;
  assign rb3176 = (rb3169 & ~rb3171 & ~rb3172) | (rb3171 & ~rb3169 & ~rb3170);
  assign rb3177 = (rb3170 & ~rb3171 & ~rb3172) | (rb3172 & ~rb3169 & ~rb3170);
  assign rb3178 = rb3174 | (rb3176 & ~rb3173);
  assign rb3179 = rb3175 | (rb3177 & rb3173);
  assign rb3180 = (rb3176 | rb3177) & rb3173;
  assign rb3181 = (rb3176 | rb3177) & ~rb3173;
  assign rb3182 = pp524;
  assign rb3183 = pp525;
  assign rb3184 = pp576;
  assign rb3185 = pp577;
  assign rb3186 = pp523 | pp575;
  assign rb3187 = rb3182 & rb3184;
  assign rb3188 = rb3183 & rb3185;
  assign rb3189 = (rb3182 & ~rb3184 & ~rb3185) | (rb3184 & ~rb3182 & ~rb3183);
  assign rb3190 = (rb3183 & ~rb3184 & ~rb3185) | (rb3185 & ~rb3182 & ~rb3183);
  assign rb3191 = rb3187 | (rb3189 & ~rb3186);
  assign rb3192 = rb3188 | (rb3190 & rb3186);
  assign rb3193 = (rb3189 | rb3190) & rb3186;
  assign rb3194 = (rb3189 | rb3190) & ~rb3186;
  assign rb3195 = pp526;
  assign rb3196 = pp527;
  assign rb3197 = pp578;
  assign rb3198 = pp579;
  assign rb3199 = pp525 | pp577;
  assign rb3200 = rb3195 & rb3197;
  assign rb3201 = rb3196 & rb3198;
  assign rb3202 = (rb3195 & ~rb3197 & ~rb3198) | (rb3197 & ~rb3195 & ~rb3196);
  assign rb3203 = (rb3196 & ~rb3197 & ~rb3198) | (rb3198 & ~rb3195 & ~rb3196);
  assign rb3204 = rb3200 | (rb3202 & ~rb3199);
  assign rb3205 = rb3201 | (rb3203 & rb3199);
  assign rb3206 = (rb3202 | rb3203) & rb3199;
  assign rb3207 = (rb3202 | rb3203) & ~rb3199;
  assign rb3208 = pp528;
  assign rb3209 = pp529;
  assign rb3210 = pp580;
  assign rb3211 = pp581;
  assign rb3212 = pp527 | pp579;
  assign rb3213 = rb3208 & rb3210;
  assign rb3214 = rb3209 & rb3211;
  assign rb3215 = (rb3208 & ~rb3210 & ~rb3211) | (rb3210 & ~rb3208 & ~rb3209);
  assign rb3216 = (rb3209 & ~rb3210 & ~rb3211) | (rb3211 & ~rb3208 & ~rb3209);
  assign rb3217 = rb3213 | (rb3215 & ~rb3212);
  assign rb3218 = rb3214 | (rb3216 & rb3212);
  assign rb3219 = (rb3215 | rb3216) & rb3212;
  assign rb3220 = (rb3215 | rb3216) & ~rb3212;
  assign rb3221 = pp530;
  assign rb3222 = pp531;
  assign rb3223 = pp582;
  assign rb3224 = pp583;
  assign rb3225 = pp529 | pp581;
  assign rb3226 = rb3221 & rb3223;
  assign rb3227 = rb3222 & rb3224;
  assign rb3228 = (rb3221 & ~rb3223 & ~rb3224) | (rb3223 & ~rb3221 & ~rb3222);
  assign rb3229 = (rb3222 & ~rb3223 & ~rb3224) | (rb3224 & ~rb3221 & ~rb3222);
  assign rb3230 = rb3226 | (rb3228 & ~rb3225);
  assign rb3231 = rb3227 | (rb3229 & rb3225);
  assign rb3232 = (rb3228 | rb3229) & rb3225;
  assign rb3233 = (rb3228 | rb3229) & ~rb3225;
  assign rb3234 = pp532;
  assign rb3235 = pp533;
  assign rb3236 = pp584;
  assign rb3237 = pp585;
  assign rb3238 = pp531 | pp583;
  assign rb3239 = rb3234 & rb3236;
  assign rb3240 = rb3235 & rb3237;
  assign rb3241 = (rb3234 & ~rb3236 & ~rb3237) | (rb3236 & ~rb3234 & ~rb3235);
  assign rb3242 = (rb3235 & ~rb3236 & ~rb3237) | (rb3237 & ~rb3234 & ~rb3235);
  assign rb3243 = rb3239 | (rb3241 & ~rb3238);
  assign rb3244 = rb3240 | (rb3242 & rb3238);
  assign rb3245 = (rb3241 | rb3242) & rb3238;
  assign rb3246 = (rb3241 | rb3242) & ~rb3238;
  assign rb3247 = pp534;
  assign rb3248 = pp535;
  assign rb3249 = pp586;
  assign rb3250 = pp587;
  assign rb3251 = pp533 | pp585;
  assign rb3252 = rb3247 & rb3249;
  assign rb3253 = rb3248 & rb3250;
  assign rb3254 = (rb3247 & ~rb3249 & ~rb3250) | (rb3249 & ~rb3247 & ~rb3248);
  assign rb3255 = (rb3248 & ~rb3249 & ~rb3250) | (rb3250 & ~rb3247 & ~rb3248);
  assign rb3256 = rb3252 | (rb3254 & ~rb3251);
  assign rb3257 = rb3253 | (rb3255 & rb3251);
  assign rb3258 = (rb3254 | rb3255) & rb3251;
  assign rb3259 = (rb3254 | rb3255) & ~rb3251;
  assign rb3260 = pp536;
  assign rb3261 = pp537;
  assign rb3262 = pp588;
  assign rb3263 = pp589;
  assign rb3264 = pp535 | pp587;
  assign rb3265 = rb3260 & rb3262;
  assign rb3266 = rb3261 & rb3263;
  assign rb3267 = (rb3260 & ~rb3262 & ~rb3263) | (rb3262 & ~rb3260 & ~rb3261);
  assign rb3268 = (rb3261 & ~rb3262 & ~rb3263) | (rb3263 & ~rb3260 & ~rb3261);
  assign rb3269 = rb3265 | (rb3267 & ~rb3264);
  assign rb3270 = rb3266 | (rb3268 & rb3264);
  assign rb3271 = (rb3267 | rb3268) & rb3264;
  assign rb3272 = (rb3267 | rb3268) & ~rb3264;
  assign rb3273 = pp538;
  assign rb3274 = pp539;
  assign rb3275 = pp590;
  assign rb3276 = pp591;
  assign rb3277 = pp537 | pp589;
  assign rb3278 = rb3273 & rb3275;
  assign rb3279 = rb3274 & rb3276;
  assign rb3280 = (rb3273 & ~rb3275 & ~rb3276) | (rb3275 & ~rb3273 & ~rb3274);
  assign rb3281 = (rb3274 & ~rb3275 & ~rb3276) | (rb3276 & ~rb3273 & ~rb3274);
  assign rb3282 = rb3278 | (rb3280 & ~rb3277);
  assign rb3283 = rb3279 | (rb3281 & rb3277);
  assign rb3284 = (rb3280 | rb3281) & rb3277;
  assign rb3285 = (rb3280 | rb3281) & ~rb3277;
  assign rb3286 = pp540;
  assign rb3287 = pp541;
  assign rb3288 = pp592;
  assign rb3289 = pp593;
  assign rb3290 = pp539 | pp591;
  assign rb3291 = rb3286 & rb3288;
  assign rb3292 = rb3287 & rb3289;
  assign rb3293 = (rb3286 & ~rb3288 & ~rb3289) | (rb3288 & ~rb3286 & ~rb3287);
  assign rb3294 = (rb3287 & ~rb3288 & ~rb3289) | (rb3289 & ~rb3286 & ~rb3287);
  assign rb3295 = rb3291 | (rb3293 & ~rb3290);
  assign rb3296 = rb3292 | (rb3294 & rb3290);
  assign rb3297 = (rb3293 | rb3294) & rb3290;
  assign rb3298 = (rb3293 | rb3294) & ~rb3290;
  assign rb3299 = pp542;
  assign rb3300 = pp543;
  assign rb3301 = pp594;
  assign rb3302 = pp595;
  assign rb3303 = pp541 | pp593;
  assign rb3304 = rb3299 & rb3301;
  assign rb3305 = rb3300 & rb3302;
  assign rb3306 = (rb3299 & ~rb3301 & ~rb3302) | (rb3301 & ~rb3299 & ~rb3300);
  assign rb3307 = (rb3300 & ~rb3301 & ~rb3302) | (rb3302 & ~rb3299 & ~rb3300);
  assign rb3308 = rb3304 | (rb3306 & ~rb3303);
  assign rb3309 = rb3305 | (rb3307 & rb3303);
  assign rb3310 = (rb3306 | rb3307) & rb3303;
  assign rb3311 = (rb3306 | rb3307) & ~rb3303;
  assign rb3312 = pp544;
  assign rb3313 = pp545;
  assign rb3314 = pp596;
  assign rb3315 = pp597;
  assign rb3316 = pp543 | pp595;
  assign rb3317 = rb3312 & rb3314;
  assign rb3318 = rb3313 & rb3315;
  assign rb3319 = (rb3312 & ~rb3314 & ~rb3315) | (rb3314 & ~rb3312 & ~rb3313);
  assign rb3320 = (rb3313 & ~rb3314 & ~rb3315) | (rb3315 & ~rb3312 & ~rb3313);
  assign rb3321 = rb3317 | (rb3319 & ~rb3316);
  assign rb3322 = rb3318 | (rb3320 & rb3316);
  assign rb3323 = (rb3319 | rb3320) & rb3316;
  assign rb3324 = (rb3319 | rb3320) & ~rb3316;
  assign rb3325 = pp546;
  assign rb3326 = pp547;
  assign rb3327 = pp598;
  assign rb3328 = pp599;
  assign rb3329 = pp545 | pp597;
  assign rb3330 = rb3325 & rb3327;
  assign rb3331 = rb3326 & rb3328;
  assign rb3332 = (rb3325 & ~rb3327 & ~rb3328) | (rb3327 & ~rb3325 & ~rb3326);
  assign rb3333 = (rb3326 & ~rb3327 & ~rb3328) | (rb3328 & ~rb3325 & ~rb3326);
  assign rb3334 = rb3330 | (rb3332 & ~rb3329);
  assign rb3335 = rb3331 | (rb3333 & rb3329);
  assign rb3336 = (rb3332 | rb3333) & rb3329;
  assign rb3337 = (rb3332 | rb3333) & ~rb3329;
  assign rb3338 = pp548;
  assign rb3339 = pp549;
  assign rb3340 = pp600;
  assign rb3341 = pp601;
  assign rb3342 = pp547 | pp599;
  assign rb3343 = rb3338 & rb3340;
  assign rb3344 = rb3339 & rb3341;
  assign rb3345 = (rb3338 & ~rb3340 & ~rb3341) | (rb3340 & ~rb3338 & ~rb3339);
  assign rb3346 = (rb3339 & ~rb3340 & ~rb3341) | (rb3341 & ~rb3338 & ~rb3339);
  assign rb3347 = rb3343 | (rb3345 & ~rb3342);
  assign rb3348 = rb3344 | (rb3346 & rb3342);
  assign rb3349 = (rb3345 | rb3346) & rb3342;
  assign rb3350 = (rb3345 | rb3346) & ~rb3342;
  assign rb3351 = pp550;
  assign rb3352 = pp551;
  assign rb3353 = pp602;
  assign rb3354 = pp603;
  assign rb3355 = pp549 | pp601;
  assign rb3356 = rb3351 & rb3353;
  assign rb3357 = rb3352 & rb3354;
  assign rb3358 = (rb3351 & ~rb3353 & ~rb3354) | (rb3353 & ~rb3351 & ~rb3352);
  assign rb3359 = (rb3352 & ~rb3353 & ~rb3354) | (rb3354 & ~rb3351 & ~rb3352);
  assign rb3360 = rb3356 | (rb3358 & ~rb3355);
  assign rb3361 = rb3357 | (rb3359 & rb3355);
  assign rb3362 = (rb3358 | rb3359) & rb3355;
  assign rb3363 = (rb3358 | rb3359) & ~rb3355;
  assign rb3364 = pp552;
  assign rb3365 = pp553;
  assign rb3366 = pp604;
  assign rb3367 = pp605;
  assign rb3368 = pp551 | pp603;
  assign rb3369 = rb3364 & rb3366;
  assign rb3370 = rb3365 & rb3367;
  assign rb3371 = (rb3364 & ~rb3366 & ~rb3367) | (rb3366 & ~rb3364 & ~rb3365);
  assign rb3372 = (rb3365 & ~rb3366 & ~rb3367) | (rb3367 & ~rb3364 & ~rb3365);
  assign rb3373 = rb3369 | (rb3371 & ~rb3368);
  assign rb3374 = rb3370 | (rb3372 & rb3368);
  assign rb3375 = (rb3371 | rb3372) & rb3368;
  assign rb3376 = (rb3371 | rb3372) & ~rb3368;
  assign rb3377 = pp554;
  assign rb3378 = pp555;
  assign rb3379 = pp606;
  assign rb3380 = pp607;
  assign rb3381 = pp553 | pp605;
  assign rb3382 = rb3377 & rb3379;
  assign rb3383 = rb3378 & rb3380;
  assign rb3384 = (rb3377 & ~rb3379 & ~rb3380) | (rb3379 & ~rb3377 & ~rb3378);
  assign rb3385 = (rb3378 & ~rb3379 & ~rb3380) | (rb3380 & ~rb3377 & ~rb3378);
  assign rb3386 = rb3382 | (rb3384 & ~rb3381);
  assign rb3387 = rb3383 | (rb3385 & rb3381);
  assign rb3388 = (rb3384 | rb3385) & rb3381;
  assign rb3389 = (rb3384 | rb3385) & ~rb3381;
  assign rb3390 = pp556;
  assign rb3391 = pp557;
  assign rb3392 = pp608;
  assign rb3393 = pp609;
  assign rb3394 = pp555 | pp607;
  assign rb3395 = rb3390 & rb3392;
  assign rb3396 = rb3391 & rb3393;
  assign rb3397 = (rb3390 & ~rb3392 & ~rb3393) | (rb3392 & ~rb3390 & ~rb3391);
  assign rb3398 = (rb3391 & ~rb3392 & ~rb3393) | (rb3393 & ~rb3390 & ~rb3391);
  assign rb3399 = rb3395 | (rb3397 & ~rb3394);
  assign rb3400 = rb3396 | (rb3398 & rb3394);
  assign rb3401 = (rb3397 | rb3398) & rb3394;
  assign rb3402 = (rb3397 | rb3398) & ~rb3394;
  assign rb3403 = (rb2972 & ~1'b0) | (1'b0 & ~rb2973);
  assign rb3404 = (rb2973 & ~1'b0) | (1'b0 & ~rb2972);
  assign rb3405 = (rb2985 & ~rb2971) | (rb2970 & ~rb2986);
  assign rb3406 = (rb2986 & ~rb2970) | (rb2971 & ~rb2985);
  assign rb3407 = (rb2998 & ~rb2984) | (rb2983 & ~rb2999);
  assign rb3408 = (rb2999 & ~rb2983) | (rb2984 & ~rb2998);
  assign rb3409 = (rb3011 & ~rb2997) | (rb2996 & ~rb3012);
  assign rb3410 = (rb3012 & ~rb2996) | (rb2997 & ~rb3011);
  assign rb3411 = (rb3024 & ~rb3010) | (rb3009 & ~rb3025);
  assign rb3412 = (rb3025 & ~rb3009) | (rb3010 & ~rb3024);
  assign rb3413 = (rb3037 & ~rb3023) | (rb3022 & ~rb3038);
  assign rb3414 = (rb3038 & ~rb3022) | (rb3023 & ~rb3037);
  assign rb3415 = (rb3050 & ~rb3036) | (rb3035 & ~rb3051);
  assign rb3416 = (rb3051 & ~rb3035) | (rb3036 & ~rb3050);
  assign rb3417 = (rb3063 & ~rb3049) | (rb3048 & ~rb3064);
  assign rb3418 = (rb3064 & ~rb3048) | (rb3049 & ~rb3063);
  assign rb3419 = (rb3076 & ~rb3062) | (rb3061 & ~rb3077);
  assign rb3420 = (rb3077 & ~rb3061) | (rb3062 & ~rb3076);
  assign rb3421 = (rb3089 & ~rb3075) | (rb3074 & ~rb3090);
  assign rb3422 = (rb3090 & ~rb3074) | (rb3075 & ~rb3089);
  assign rb3423 = (rb3102 & ~rb3088) | (rb3087 & ~rb3103);
  assign rb3424 = (rb3103 & ~rb3087) | (rb3088 & ~rb3102);
  assign rb3425 = (rb3115 & ~rb3101) | (rb3100 & ~rb3116);
  assign rb3426 = (rb3116 & ~rb3100) | (rb3101 & ~rb3115);
  assign rb3427 = (rb3128 & ~rb3114) | (rb3113 & ~rb3129);
  assign rb3428 = (rb3129 & ~rb3113) | (rb3114 & ~rb3128);
  assign rb3429 = (rb3141 & ~rb3127) | (rb3126 & ~rb3142);
  assign rb3430 = (rb3142 & ~rb3126) | (rb3127 & ~rb3141);
  assign rb3431 = (rb3154 & ~rb3140) | (rb3139 & ~rb3155);
  assign rb3432 = (rb3155 & ~rb3139) | (rb3140 & ~rb3154);
  assign rb3433 = (rb3167 & ~rb3153) | (rb3152 & ~rb3168);
  assign rb3434 = (rb3168 & ~rb3152) | (rb3153 & ~rb3167);
  assign rb3435 = (rb3180 & ~rb3166) | (rb3165 & ~rb3181);
  assign rb3436 = (rb3181 & ~rb3165) | (rb3166 & ~rb3180);
  assign rb3437 = (rb3193 & ~rb3179) | (rb3178 & ~rb3194);
  assign rb3438 = (rb3194 & ~rb3178) | (rb3179 & ~rb3193);
  assign rb3439 = (rb3206 & ~rb3192) | (rb3191 & ~rb3207);
  assign rb3440 = (rb3207 & ~rb3191) | (rb3192 & ~rb3206);
  assign rb3441 = (rb3219 & ~rb3205) | (rb3204 & ~rb3220);
  assign rb3442 = (rb3220 & ~rb3204) | (rb3205 & ~rb3219);
  assign rb3443 = (rb3232 & ~rb3218) | (rb3217 & ~rb3233);
  assign rb3444 = (rb3233 & ~rb3217) | (rb3218 & ~rb3232);
  assign rb3445 = (rb3245 & ~rb3231) | (rb3230 & ~rb3246);
  assign rb3446 = (rb3246 & ~rb3230) | (rb3231 & ~rb3245);
  assign rb3447 = (rb3258 & ~rb3244) | (rb3243 & ~rb3259);
  assign rb3448 = (rb3259 & ~rb3243) | (rb3244 & ~rb3258);
  assign rb3449 = (rb3271 & ~rb3257) | (rb3256 & ~rb3272);
  assign rb3450 = (rb3272 & ~rb3256) | (rb3257 & ~rb3271);
  assign rb3451 = (rb3284 & ~rb3270) | (rb3269 & ~rb3285);
  assign rb3452 = (rb3285 & ~rb3269) | (rb3270 & ~rb3284);
  assign rb3453 = (rb3297 & ~rb3283) | (rb3282 & ~rb3298);
  assign rb3454 = (rb3298 & ~rb3282) | (rb3283 & ~rb3297);
  assign rb3455 = (rb3310 & ~rb3296) | (rb3295 & ~rb3311);
  assign rb3456 = (rb3311 & ~rb3295) | (rb3296 & ~rb3310);
  assign rb3457 = (rb3323 & ~rb3309) | (rb3308 & ~rb3324);
  assign rb3458 = (rb3324 & ~rb3308) | (rb3309 & ~rb3323);
  assign rb3459 = (rb3336 & ~rb3322) | (rb3321 & ~rb3337);
  assign rb3460 = (rb3337 & ~rb3321) | (rb3322 & ~rb3336);
  assign rb3461 = (rb3349 & ~rb3335) | (rb3334 & ~rb3350);
  assign rb3462 = (rb3350 & ~rb3334) | (rb3335 & ~rb3349);
  assign rb3463 = (rb3362 & ~rb3348) | (rb3347 & ~rb3363);
  assign rb3464 = (rb3363 & ~rb3347) | (rb3348 & ~rb3362);
  assign rb3465 = (rb3375 & ~rb3361) | (rb3360 & ~rb3376);
  assign rb3466 = (rb3376 & ~rb3360) | (rb3361 & ~rb3375);
  assign rb3467 = (rb3388 & ~rb3374) | (rb3373 & ~rb3389);
  assign rb3468 = (rb3389 & ~rb3373) | (rb3374 & ~rb3388);
  assign rb3469 = (rb3401 & ~rb3387) | (rb3386 & ~rb3402);
  assign rb3470 = (rb3402 & ~rb3386) | (rb3387 & ~rb3401);
  assign rb3471 = (1'b0 & ~rb3400) | (rb3399 & ~1'b0);
  assign rb3472 = (1'b0 & ~rb3399) | (rb3400 & ~1'b0);
  assign rb3473 = 1'b0;
  assign rb3474 = 1'b0;
  assign rb3475 = 1'b0;
  assign rb3476 = 1'b0;
  assign rb3477 = rb3473 & rb3475;
  assign rb3478 = rb3474 & rb3476;
  assign rb3479 = (rb3473 & ~rb3475 & ~rb3476) | (rb3475 & ~rb3473 & ~rb3474);
  assign rb3480 = (rb3474 & ~rb3475 & ~rb3476) | (rb3476 & ~rb3473 & ~rb3474);
  assign rb3481 = rb3477 | (rb3479 & ~1'b0);
  assign rb3482 = rb3478 | (rb3480 & 1'b0);
  assign rb3483 = (rb3479 | rb3480) & 1'b0;
  assign rb3484 = (rb3479 | rb3480) & ~1'b0;
  assign rb3485 = 1'b0;
  assign rb3486 = 1'b0;
  assign rb3487 = 1'b0;
  assign rb3488 = 1'b0;
  assign rb3489 = 1'b0 | 1'b0;
  assign rb3490 = rb3485 & rb3487;
  assign rb3491 = rb3486 & rb3488;
  assign rb3492 = (rb3485 & ~rb3487 & ~rb3488) | (rb3487 & ~rb3485 & ~rb3486);
  assign rb3493 = (rb3486 & ~rb3487 & ~rb3488) | (rb3488 & ~rb3485 & ~rb3486);
  assign rb3494 = rb3490 | (rb3492 & ~rb3489);
  assign rb3495 = rb3491 | (rb3493 & rb3489);
  assign rb3496 = (rb3492 | rb3493) & rb3489;
  assign rb3497 = (rb3492 | rb3493) & ~rb3489;
  assign rb3498 = 1'b0;
  assign rb3499 = 1'b0;
  assign rb3500 = 1'b0;
  assign rb3501 = 1'b0;
  assign rb3502 = 1'b0 | 1'b0;
  assign rb3503 = rb3498 & rb3500;
  assign rb3504 = rb3499 & rb3501;
  assign rb3505 = (rb3498 & ~rb3500 & ~rb3501) | (rb3500 & ~rb3498 & ~rb3499);
  assign rb3506 = (rb3499 & ~rb3500 & ~rb3501) | (rb3501 & ~rb3498 & ~rb3499);
  assign rb3507 = rb3503 | (rb3505 & ~rb3502);
  assign rb3508 = rb3504 | (rb3506 & rb3502);
  assign rb3509 = (rb3505 | rb3506) & rb3502;
  assign rb3510 = (rb3505 | rb3506) & ~rb3502;
  assign rb3511 = 1'b0;
  assign rb3512 = 1'b0;
  assign rb3513 = 1'b0;
  assign rb3514 = 1'b0;
  assign rb3515 = 1'b0 | 1'b0;
  assign rb3516 = rb3511 & rb3513;
  assign rb3517 = rb3512 & rb3514;
  assign rb3518 = (rb3511 & ~rb3513 & ~rb3514) | (rb3513 & ~rb3511 & ~rb3512);
  assign rb3519 = (rb3512 & ~rb3513 & ~rb3514) | (rb3514 & ~rb3511 & ~rb3512);
  assign rb3520 = rb3516 | (rb3518 & ~rb3515);
  assign rb3521 = rb3517 | (rb3519 & rb3515);
  assign rb3522 = (rb3518 | rb3519) & rb3515;
  assign rb3523 = (rb3518 | rb3519) & ~rb3515;
  assign rb3524 = 1'b0;
  assign rb3525 = 1'b0;
  assign rb3526 = 1'b0;
  assign rb3527 = 1'b0;
  assign rb3528 = 1'b0 | 1'b0;
  assign rb3529 = rb3524 & rb3526;
  assign rb3530 = rb3525 & rb3527;
  assign rb3531 = (rb3524 & ~rb3526 & ~rb3527) | (rb3526 & ~rb3524 & ~rb3525);
  assign rb3532 = (rb3525 & ~rb3526 & ~rb3527) | (rb3527 & ~rb3524 & ~rb3525);
  assign rb3533 = rb3529 | (rb3531 & ~rb3528);
  assign rb3534 = rb3530 | (rb3532 & rb3528);
  assign rb3535 = (rb3531 | rb3532) & rb3528;
  assign rb3536 = (rb3531 | rb3532) & ~rb3528;
  assign rb3537 = 1'b0;
  assign rb3538 = 1'b0;
  assign rb3539 = 1'b0;
  assign rb3540 = 1'b0;
  assign rb3541 = 1'b0 | 1'b0;
  assign rb3542 = rb3537 & rb3539;
  assign rb3543 = rb3538 & rb3540;
  assign rb3544 = (rb3537 & ~rb3539 & ~rb3540) | (rb3539 & ~rb3537 & ~rb3538);
  assign rb3545 = (rb3538 & ~rb3539 & ~rb3540) | (rb3540 & ~rb3537 & ~rb3538);
  assign rb3546 = rb3542 | (rb3544 & ~rb3541);
  assign rb3547 = rb3543 | (rb3545 & rb3541);
  assign rb3548 = (rb3544 | rb3545) & rb3541;
  assign rb3549 = (rb3544 | rb3545) & ~rb3541;
  assign rb3550 = 1'b0;
  assign rb3551 = 1'b0;
  assign rb3552 = 1'b0;
  assign rb3553 = 1'b0;
  assign rb3554 = 1'b0 | 1'b0;
  assign rb3555 = rb3550 & rb3552;
  assign rb3556 = rb3551 & rb3553;
  assign rb3557 = (rb3550 & ~rb3552 & ~rb3553) | (rb3552 & ~rb3550 & ~rb3551);
  assign rb3558 = (rb3551 & ~rb3552 & ~rb3553) | (rb3553 & ~rb3550 & ~rb3551);
  assign rb3559 = rb3555 | (rb3557 & ~rb3554);
  assign rb3560 = rb3556 | (rb3558 & rb3554);
  assign rb3561 = (rb3557 | rb3558) & rb3554;
  assign rb3562 = (rb3557 | rb3558) & ~rb3554;
  assign rb3563 = 1'b0;
  assign rb3564 = 1'b0;
  assign rb3565 = 1'b0;
  assign rb3566 = 1'b0;
  assign rb3567 = 1'b0 | 1'b0;
  assign rb3568 = rb3563 & rb3565;
  assign rb3569 = rb3564 & rb3566;
  assign rb3570 = (rb3563 & ~rb3565 & ~rb3566) | (rb3565 & ~rb3563 & ~rb3564);
  assign rb3571 = (rb3564 & ~rb3565 & ~rb3566) | (rb3566 & ~rb3563 & ~rb3564);
  assign rb3572 = rb3568 | (rb3570 & ~rb3567);
  assign rb3573 = rb3569 | (rb3571 & rb3567);
  assign rb3574 = (rb3570 | rb3571) & rb3567;
  assign rb3575 = (rb3570 | rb3571) & ~rb3567;
  assign rb3576 = 1'b0;
  assign rb3577 = 1'b0;
  assign rb3578 = 1'b0;
  assign rb3579 = 1'b0;
  assign rb3580 = 1'b0 | 1'b0;
  assign rb3581 = rb3576 & rb3578;
  assign rb3582 = rb3577 & rb3579;
  assign rb3583 = (rb3576 & ~rb3578 & ~rb3579) | (rb3578 & ~rb3576 & ~rb3577);
  assign rb3584 = (rb3577 & ~rb3578 & ~rb3579) | (rb3579 & ~rb3576 & ~rb3577);
  assign rb3585 = rb3581 | (rb3583 & ~rb3580);
  assign rb3586 = rb3582 | (rb3584 & rb3580);
  assign rb3587 = (rb3583 | rb3584) & rb3580;
  assign rb3588 = (rb3583 | rb3584) & ~rb3580;
  assign rb3589 = 1'b0;
  assign rb3590 = 1'b0;
  assign rb3591 = 1'b0;
  assign rb3592 = 1'b0;
  assign rb3593 = 1'b0 | 1'b0;
  assign rb3594 = rb3589 & rb3591;
  assign rb3595 = rb3590 & rb3592;
  assign rb3596 = (rb3589 & ~rb3591 & ~rb3592) | (rb3591 & ~rb3589 & ~rb3590);
  assign rb3597 = (rb3590 & ~rb3591 & ~rb3592) | (rb3592 & ~rb3589 & ~rb3590);
  assign rb3598 = rb3594 | (rb3596 & ~rb3593);
  assign rb3599 = rb3595 | (rb3597 & rb3593);
  assign rb3600 = (rb3596 | rb3597) & rb3593;
  assign rb3601 = (rb3596 | rb3597) & ~rb3593;
  assign rb3602 = pp612;
  assign rb3603 = pp613;
  assign rb3604 = 1'b0;
  assign rb3605 = 1'b0;
  assign rb3606 = 1'b0 | 1'b0;
  assign rb3607 = rb3602 & rb3604;
  assign rb3608 = rb3603 & rb3605;
  assign rb3609 = (rb3602 & ~rb3604 & ~rb3605) | (rb3604 & ~rb3602 & ~rb3603);
  assign rb3610 = (rb3603 & ~rb3604 & ~rb3605) | (rb3605 & ~rb3602 & ~rb3603);
  assign rb3611 = rb3607 | (rb3609 & ~rb3606);
  assign rb3612 = rb3608 | (rb3610 & rb3606);
  assign rb3613 = (rb3609 | rb3610) & rb3606;
  assign rb3614 = (rb3609 | rb3610) & ~rb3606;
  assign rb3615 = pp614;
  assign rb3616 = pp615;
  assign rb3617 = pp662;
  assign rb3618 = pp663;
  assign rb3619 = pp613 | 1'b0;
  assign rb3620 = rb3615 & rb3617;
  assign rb3621 = rb3616 & rb3618;
  assign rb3622 = (rb3615 & ~rb3617 & ~rb3618) | (rb3617 & ~rb3615 & ~rb3616);
  assign rb3623 = (rb3616 & ~rb3617 & ~rb3618) | (rb3618 & ~rb3615 & ~rb3616);
  assign rb3624 = rb3620 | (rb3622 & ~rb3619);
  assign rb3625 = rb3621 | (rb3623 & rb3619);
  assign rb3626 = (rb3622 | rb3623) & rb3619;
  assign rb3627 = (rb3622 | rb3623) & ~rb3619;
  assign rb3628 = pp616;
  assign rb3629 = pp617;
  assign rb3630 = pp664;
  assign rb3631 = pp665;
  assign rb3632 = pp615 | pp663;
  assign rb3633 = rb3628 & rb3630;
  assign rb3634 = rb3629 & rb3631;
  assign rb3635 = (rb3628 & ~rb3630 & ~rb3631) | (rb3630 & ~rb3628 & ~rb3629);
  assign rb3636 = (rb3629 & ~rb3630 & ~rb3631) | (rb3631 & ~rb3628 & ~rb3629);
  assign rb3637 = rb3633 | (rb3635 & ~rb3632);
  assign rb3638 = rb3634 | (rb3636 & rb3632);
  assign rb3639 = (rb3635 | rb3636) & rb3632;
  assign rb3640 = (rb3635 | rb3636) & ~rb3632;
  assign rb3641 = pp618;
  assign rb3642 = pp619;
  assign rb3643 = pp666;
  assign rb3644 = pp667;
  assign rb3645 = pp617 | pp665;
  assign rb3646 = rb3641 & rb3643;
  assign rb3647 = rb3642 & rb3644;
  assign rb3648 = (rb3641 & ~rb3643 & ~rb3644) | (rb3643 & ~rb3641 & ~rb3642);
  assign rb3649 = (rb3642 & ~rb3643 & ~rb3644) | (rb3644 & ~rb3641 & ~rb3642);
  assign rb3650 = rb3646 | (rb3648 & ~rb3645);
  assign rb3651 = rb3647 | (rb3649 & rb3645);
  assign rb3652 = (rb3648 | rb3649) & rb3645;
  assign rb3653 = (rb3648 | rb3649) & ~rb3645;
  assign rb3654 = pp620;
  assign rb3655 = pp621;
  assign rb3656 = pp668;
  assign rb3657 = pp669;
  assign rb3658 = pp619 | pp667;
  assign rb3659 = rb3654 & rb3656;
  assign rb3660 = rb3655 & rb3657;
  assign rb3661 = (rb3654 & ~rb3656 & ~rb3657) | (rb3656 & ~rb3654 & ~rb3655);
  assign rb3662 = (rb3655 & ~rb3656 & ~rb3657) | (rb3657 & ~rb3654 & ~rb3655);
  assign rb3663 = rb3659 | (rb3661 & ~rb3658);
  assign rb3664 = rb3660 | (rb3662 & rb3658);
  assign rb3665 = (rb3661 | rb3662) & rb3658;
  assign rb3666 = (rb3661 | rb3662) & ~rb3658;
  assign rb3667 = pp622;
  assign rb3668 = pp623;
  assign rb3669 = pp670;
  assign rb3670 = pp671;
  assign rb3671 = pp621 | pp669;
  assign rb3672 = rb3667 & rb3669;
  assign rb3673 = rb3668 & rb3670;
  assign rb3674 = (rb3667 & ~rb3669 & ~rb3670) | (rb3669 & ~rb3667 & ~rb3668);
  assign rb3675 = (rb3668 & ~rb3669 & ~rb3670) | (rb3670 & ~rb3667 & ~rb3668);
  assign rb3676 = rb3672 | (rb3674 & ~rb3671);
  assign rb3677 = rb3673 | (rb3675 & rb3671);
  assign rb3678 = (rb3674 | rb3675) & rb3671;
  assign rb3679 = (rb3674 | rb3675) & ~rb3671;
  assign rb3680 = pp624;
  assign rb3681 = pp625;
  assign rb3682 = pp672;
  assign rb3683 = pp673;
  assign rb3684 = pp623 | pp671;
  assign rb3685 = rb3680 & rb3682;
  assign rb3686 = rb3681 & rb3683;
  assign rb3687 = (rb3680 & ~rb3682 & ~rb3683) | (rb3682 & ~rb3680 & ~rb3681);
  assign rb3688 = (rb3681 & ~rb3682 & ~rb3683) | (rb3683 & ~rb3680 & ~rb3681);
  assign rb3689 = rb3685 | (rb3687 & ~rb3684);
  assign rb3690 = rb3686 | (rb3688 & rb3684);
  assign rb3691 = (rb3687 | rb3688) & rb3684;
  assign rb3692 = (rb3687 | rb3688) & ~rb3684;
  assign rb3693 = pp626;
  assign rb3694 = pp627;
  assign rb3695 = pp674;
  assign rb3696 = pp675;
  assign rb3697 = pp625 | pp673;
  assign rb3698 = rb3693 & rb3695;
  assign rb3699 = rb3694 & rb3696;
  assign rb3700 = (rb3693 & ~rb3695 & ~rb3696) | (rb3695 & ~rb3693 & ~rb3694);
  assign rb3701 = (rb3694 & ~rb3695 & ~rb3696) | (rb3696 & ~rb3693 & ~rb3694);
  assign rb3702 = rb3698 | (rb3700 & ~rb3697);
  assign rb3703 = rb3699 | (rb3701 & rb3697);
  assign rb3704 = (rb3700 | rb3701) & rb3697;
  assign rb3705 = (rb3700 | rb3701) & ~rb3697;
  assign rb3706 = pp628;
  assign rb3707 = pp629;
  assign rb3708 = pp676;
  assign rb3709 = pp677;
  assign rb3710 = pp627 | pp675;
  assign rb3711 = rb3706 & rb3708;
  assign rb3712 = rb3707 & rb3709;
  assign rb3713 = (rb3706 & ~rb3708 & ~rb3709) | (rb3708 & ~rb3706 & ~rb3707);
  assign rb3714 = (rb3707 & ~rb3708 & ~rb3709) | (rb3709 & ~rb3706 & ~rb3707);
  assign rb3715 = rb3711 | (rb3713 & ~rb3710);
  assign rb3716 = rb3712 | (rb3714 & rb3710);
  assign rb3717 = (rb3713 | rb3714) & rb3710;
  assign rb3718 = (rb3713 | rb3714) & ~rb3710;
  assign rb3719 = pp630;
  assign rb3720 = pp631;
  assign rb3721 = pp678;
  assign rb3722 = pp679;
  assign rb3723 = pp629 | pp677;
  assign rb3724 = rb3719 & rb3721;
  assign rb3725 = rb3720 & rb3722;
  assign rb3726 = (rb3719 & ~rb3721 & ~rb3722) | (rb3721 & ~rb3719 & ~rb3720);
  assign rb3727 = (rb3720 & ~rb3721 & ~rb3722) | (rb3722 & ~rb3719 & ~rb3720);
  assign rb3728 = rb3724 | (rb3726 & ~rb3723);
  assign rb3729 = rb3725 | (rb3727 & rb3723);
  assign rb3730 = (rb3726 | rb3727) & rb3723;
  assign rb3731 = (rb3726 | rb3727) & ~rb3723;
  assign rb3732 = pp632;
  assign rb3733 = pp633;
  assign rb3734 = pp680;
  assign rb3735 = pp681;
  assign rb3736 = pp631 | pp679;
  assign rb3737 = rb3732 & rb3734;
  assign rb3738 = rb3733 & rb3735;
  assign rb3739 = (rb3732 & ~rb3734 & ~rb3735) | (rb3734 & ~rb3732 & ~rb3733);
  assign rb3740 = (rb3733 & ~rb3734 & ~rb3735) | (rb3735 & ~rb3732 & ~rb3733);
  assign rb3741 = rb3737 | (rb3739 & ~rb3736);
  assign rb3742 = rb3738 | (rb3740 & rb3736);
  assign rb3743 = (rb3739 | rb3740) & rb3736;
  assign rb3744 = (rb3739 | rb3740) & ~rb3736;
  assign rb3745 = pp634;
  assign rb3746 = pp635;
  assign rb3747 = pp682;
  assign rb3748 = pp683;
  assign rb3749 = pp633 | pp681;
  assign rb3750 = rb3745 & rb3747;
  assign rb3751 = rb3746 & rb3748;
  assign rb3752 = (rb3745 & ~rb3747 & ~rb3748) | (rb3747 & ~rb3745 & ~rb3746);
  assign rb3753 = (rb3746 & ~rb3747 & ~rb3748) | (rb3748 & ~rb3745 & ~rb3746);
  assign rb3754 = rb3750 | (rb3752 & ~rb3749);
  assign rb3755 = rb3751 | (rb3753 & rb3749);
  assign rb3756 = (rb3752 | rb3753) & rb3749;
  assign rb3757 = (rb3752 | rb3753) & ~rb3749;
  assign rb3758 = pp636;
  assign rb3759 = pp637;
  assign rb3760 = pp684;
  assign rb3761 = pp685;
  assign rb3762 = pp635 | pp683;
  assign rb3763 = rb3758 & rb3760;
  assign rb3764 = rb3759 & rb3761;
  assign rb3765 = (rb3758 & ~rb3760 & ~rb3761) | (rb3760 & ~rb3758 & ~rb3759);
  assign rb3766 = (rb3759 & ~rb3760 & ~rb3761) | (rb3761 & ~rb3758 & ~rb3759);
  assign rb3767 = rb3763 | (rb3765 & ~rb3762);
  assign rb3768 = rb3764 | (rb3766 & rb3762);
  assign rb3769 = (rb3765 | rb3766) & rb3762;
  assign rb3770 = (rb3765 | rb3766) & ~rb3762;
  assign rb3771 = pp638;
  assign rb3772 = pp639;
  assign rb3773 = pp686;
  assign rb3774 = pp687;
  assign rb3775 = pp637 | pp685;
  assign rb3776 = rb3771 & rb3773;
  assign rb3777 = rb3772 & rb3774;
  assign rb3778 = (rb3771 & ~rb3773 & ~rb3774) | (rb3773 & ~rb3771 & ~rb3772);
  assign rb3779 = (rb3772 & ~rb3773 & ~rb3774) | (rb3774 & ~rb3771 & ~rb3772);
  assign rb3780 = rb3776 | (rb3778 & ~rb3775);
  assign rb3781 = rb3777 | (rb3779 & rb3775);
  assign rb3782 = (rb3778 | rb3779) & rb3775;
  assign rb3783 = (rb3778 | rb3779) & ~rb3775;
  assign rb3784 = pp640;
  assign rb3785 = pp641;
  assign rb3786 = pp688;
  assign rb3787 = pp689;
  assign rb3788 = pp639 | pp687;
  assign rb3789 = rb3784 & rb3786;
  assign rb3790 = rb3785 & rb3787;
  assign rb3791 = (rb3784 & ~rb3786 & ~rb3787) | (rb3786 & ~rb3784 & ~rb3785);
  assign rb3792 = (rb3785 & ~rb3786 & ~rb3787) | (rb3787 & ~rb3784 & ~rb3785);
  assign rb3793 = rb3789 | (rb3791 & ~rb3788);
  assign rb3794 = rb3790 | (rb3792 & rb3788);
  assign rb3795 = (rb3791 | rb3792) & rb3788;
  assign rb3796 = (rb3791 | rb3792) & ~rb3788;
  assign rb3797 = pp642;
  assign rb3798 = pp643;
  assign rb3799 = pp690;
  assign rb3800 = pp691;
  assign rb3801 = pp641 | pp689;
  assign rb3802 = rb3797 & rb3799;
  assign rb3803 = rb3798 & rb3800;
  assign rb3804 = (rb3797 & ~rb3799 & ~rb3800) | (rb3799 & ~rb3797 & ~rb3798);
  assign rb3805 = (rb3798 & ~rb3799 & ~rb3800) | (rb3800 & ~rb3797 & ~rb3798);
  assign rb3806 = rb3802 | (rb3804 & ~rb3801);
  assign rb3807 = rb3803 | (rb3805 & rb3801);
  assign rb3808 = (rb3804 | rb3805) & rb3801;
  assign rb3809 = (rb3804 | rb3805) & ~rb3801;
  assign rb3810 = pp644;
  assign rb3811 = pp645;
  assign rb3812 = pp692;
  assign rb3813 = pp693;
  assign rb3814 = pp643 | pp691;
  assign rb3815 = rb3810 & rb3812;
  assign rb3816 = rb3811 & rb3813;
  assign rb3817 = (rb3810 & ~rb3812 & ~rb3813) | (rb3812 & ~rb3810 & ~rb3811);
  assign rb3818 = (rb3811 & ~rb3812 & ~rb3813) | (rb3813 & ~rb3810 & ~rb3811);
  assign rb3819 = rb3815 | (rb3817 & ~rb3814);
  assign rb3820 = rb3816 | (rb3818 & rb3814);
  assign rb3821 = (rb3817 | rb3818) & rb3814;
  assign rb3822 = (rb3817 | rb3818) & ~rb3814;
  assign rb3823 = pp646;
  assign rb3824 = pp647;
  assign rb3825 = pp694;
  assign rb3826 = pp695;
  assign rb3827 = pp645 | pp693;
  assign rb3828 = rb3823 & rb3825;
  assign rb3829 = rb3824 & rb3826;
  assign rb3830 = (rb3823 & ~rb3825 & ~rb3826) | (rb3825 & ~rb3823 & ~rb3824);
  assign rb3831 = (rb3824 & ~rb3825 & ~rb3826) | (rb3826 & ~rb3823 & ~rb3824);
  assign rb3832 = rb3828 | (rb3830 & ~rb3827);
  assign rb3833 = rb3829 | (rb3831 & rb3827);
  assign rb3834 = (rb3830 | rb3831) & rb3827;
  assign rb3835 = (rb3830 | rb3831) & ~rb3827;
  assign rb3836 = pp648;
  assign rb3837 = pp649;
  assign rb3838 = pp696;
  assign rb3839 = pp697;
  assign rb3840 = pp647 | pp695;
  assign rb3841 = rb3836 & rb3838;
  assign rb3842 = rb3837 & rb3839;
  assign rb3843 = (rb3836 & ~rb3838 & ~rb3839) | (rb3838 & ~rb3836 & ~rb3837);
  assign rb3844 = (rb3837 & ~rb3838 & ~rb3839) | (rb3839 & ~rb3836 & ~rb3837);
  assign rb3845 = rb3841 | (rb3843 & ~rb3840);
  assign rb3846 = rb3842 | (rb3844 & rb3840);
  assign rb3847 = (rb3843 | rb3844) & rb3840;
  assign rb3848 = (rb3843 | rb3844) & ~rb3840;
  assign rb3849 = pp650;
  assign rb3850 = pp651;
  assign rb3851 = pp698;
  assign rb3852 = pp699;
  assign rb3853 = pp649 | pp697;
  assign rb3854 = rb3849 & rb3851;
  assign rb3855 = rb3850 & rb3852;
  assign rb3856 = (rb3849 & ~rb3851 & ~rb3852) | (rb3851 & ~rb3849 & ~rb3850);
  assign rb3857 = (rb3850 & ~rb3851 & ~rb3852) | (rb3852 & ~rb3849 & ~rb3850);
  assign rb3858 = rb3854 | (rb3856 & ~rb3853);
  assign rb3859 = rb3855 | (rb3857 & rb3853);
  assign rb3860 = (rb3856 | rb3857) & rb3853;
  assign rb3861 = (rb3856 | rb3857) & ~rb3853;
  assign rb3862 = pp652;
  assign rb3863 = pp653;
  assign rb3864 = pp700;
  assign rb3865 = pp701;
  assign rb3866 = pp651 | pp699;
  assign rb3867 = rb3862 & rb3864;
  assign rb3868 = rb3863 & rb3865;
  assign rb3869 = (rb3862 & ~rb3864 & ~rb3865) | (rb3864 & ~rb3862 & ~rb3863);
  assign rb3870 = (rb3863 & ~rb3864 & ~rb3865) | (rb3865 & ~rb3862 & ~rb3863);
  assign rb3871 = rb3867 | (rb3869 & ~rb3866);
  assign rb3872 = rb3868 | (rb3870 & rb3866);
  assign rb3873 = (rb3869 | rb3870) & rb3866;
  assign rb3874 = (rb3869 | rb3870) & ~rb3866;
  assign rb3875 = pp654;
  assign rb3876 = pp655;
  assign rb3877 = pp702;
  assign rb3878 = pp703;
  assign rb3879 = pp653 | pp701;
  assign rb3880 = rb3875 & rb3877;
  assign rb3881 = rb3876 & rb3878;
  assign rb3882 = (rb3875 & ~rb3877 & ~rb3878) | (rb3877 & ~rb3875 & ~rb3876);
  assign rb3883 = (rb3876 & ~rb3877 & ~rb3878) | (rb3878 & ~rb3875 & ~rb3876);
  assign rb3884 = rb3880 | (rb3882 & ~rb3879);
  assign rb3885 = rb3881 | (rb3883 & rb3879);
  assign rb3886 = (rb3882 | rb3883) & rb3879;
  assign rb3887 = (rb3882 | rb3883) & ~rb3879;
  assign rb3888 = pp656;
  assign rb3889 = pp657;
  assign rb3890 = pp704;
  assign rb3891 = pp705;
  assign rb3892 = pp655 | pp703;
  assign rb3893 = rb3888 & rb3890;
  assign rb3894 = rb3889 & rb3891;
  assign rb3895 = (rb3888 & ~rb3890 & ~rb3891) | (rb3890 & ~rb3888 & ~rb3889);
  assign rb3896 = (rb3889 & ~rb3890 & ~rb3891) | (rb3891 & ~rb3888 & ~rb3889);
  assign rb3897 = rb3893 | (rb3895 & ~rb3892);
  assign rb3898 = rb3894 | (rb3896 & rb3892);
  assign rb3899 = (rb3895 | rb3896) & rb3892;
  assign rb3900 = (rb3895 | rb3896) & ~rb3892;
  assign rb3901 = pp658;
  assign rb3902 = pp659;
  assign rb3903 = pp706;
  assign rb3904 = pp707;
  assign rb3905 = pp657 | pp705;
  assign rb3906 = rb3901 & rb3903;
  assign rb3907 = rb3902 & rb3904;
  assign rb3908 = (rb3901 & ~rb3903 & ~rb3904) | (rb3903 & ~rb3901 & ~rb3902);
  assign rb3909 = (rb3902 & ~rb3903 & ~rb3904) | (rb3904 & ~rb3901 & ~rb3902);
  assign rb3910 = rb3906 | (rb3908 & ~rb3905);
  assign rb3911 = rb3907 | (rb3909 & rb3905);
  assign rb3912 = (rb3908 | rb3909) & rb3905;
  assign rb3913 = (rb3908 | rb3909) & ~rb3905;
  assign rb3914 = (rb3483 & ~1'b0) | (1'b0 & ~rb3484);
  assign rb3915 = (rb3484 & ~1'b0) | (1'b0 & ~rb3483);
  assign rb3916 = (rb3496 & ~rb3482) | (rb3481 & ~rb3497);
  assign rb3917 = (rb3497 & ~rb3481) | (rb3482 & ~rb3496);
  assign rb3918 = (rb3509 & ~rb3495) | (rb3494 & ~rb3510);
  assign rb3919 = (rb3510 & ~rb3494) | (rb3495 & ~rb3509);
  assign rb3920 = (rb3522 & ~rb3508) | (rb3507 & ~rb3523);
  assign rb3921 = (rb3523 & ~rb3507) | (rb3508 & ~rb3522);
  assign rb3922 = (rb3535 & ~rb3521) | (rb3520 & ~rb3536);
  assign rb3923 = (rb3536 & ~rb3520) | (rb3521 & ~rb3535);
  assign rb3924 = (rb3548 & ~rb3534) | (rb3533 & ~rb3549);
  assign rb3925 = (rb3549 & ~rb3533) | (rb3534 & ~rb3548);
  assign rb3926 = (rb3561 & ~rb3547) | (rb3546 & ~rb3562);
  assign rb3927 = (rb3562 & ~rb3546) | (rb3547 & ~rb3561);
  assign rb3928 = (rb3574 & ~rb3560) | (rb3559 & ~rb3575);
  assign rb3929 = (rb3575 & ~rb3559) | (rb3560 & ~rb3574);
  assign rb3930 = (rb3587 & ~rb3573) | (rb3572 & ~rb3588);
  assign rb3931 = (rb3588 & ~rb3572) | (rb3573 & ~rb3587);
  assign rb3932 = (rb3600 & ~rb3586) | (rb3585 & ~rb3601);
  assign rb3933 = (rb3601 & ~rb3585) | (rb3586 & ~rb3600);
  assign rb3934 = (rb3613 & ~rb3599) | (rb3598 & ~rb3614);
  assign rb3935 = (rb3614 & ~rb3598) | (rb3599 & ~rb3613);
  assign rb3936 = (rb3626 & ~rb3612) | (rb3611 & ~rb3627);
  assign rb3937 = (rb3627 & ~rb3611) | (rb3612 & ~rb3626);
  assign rb3938 = (rb3639 & ~rb3625) | (rb3624 & ~rb3640);
  assign rb3939 = (rb3640 & ~rb3624) | (rb3625 & ~rb3639);
  assign rb3940 = (rb3652 & ~rb3638) | (rb3637 & ~rb3653);
  assign rb3941 = (rb3653 & ~rb3637) | (rb3638 & ~rb3652);
  assign rb3942 = (rb3665 & ~rb3651) | (rb3650 & ~rb3666);
  assign rb3943 = (rb3666 & ~rb3650) | (rb3651 & ~rb3665);
  assign rb3944 = (rb3678 & ~rb3664) | (rb3663 & ~rb3679);
  assign rb3945 = (rb3679 & ~rb3663) | (rb3664 & ~rb3678);
  assign rb3946 = (rb3691 & ~rb3677) | (rb3676 & ~rb3692);
  assign rb3947 = (rb3692 & ~rb3676) | (rb3677 & ~rb3691);
  assign rb3948 = (rb3704 & ~rb3690) | (rb3689 & ~rb3705);
  assign rb3949 = (rb3705 & ~rb3689) | (rb3690 & ~rb3704);
  assign rb3950 = (rb3717 & ~rb3703) | (rb3702 & ~rb3718);
  assign rb3951 = (rb3718 & ~rb3702) | (rb3703 & ~rb3717);
  assign rb3952 = (rb3730 & ~rb3716) | (rb3715 & ~rb3731);
  assign rb3953 = (rb3731 & ~rb3715) | (rb3716 & ~rb3730);
  assign rb3954 = (rb3743 & ~rb3729) | (rb3728 & ~rb3744);
  assign rb3955 = (rb3744 & ~rb3728) | (rb3729 & ~rb3743);
  assign rb3956 = (rb3756 & ~rb3742) | (rb3741 & ~rb3757);
  assign rb3957 = (rb3757 & ~rb3741) | (rb3742 & ~rb3756);
  assign rb3958 = (rb3769 & ~rb3755) | (rb3754 & ~rb3770);
  assign rb3959 = (rb3770 & ~rb3754) | (rb3755 & ~rb3769);
  assign rb3960 = (rb3782 & ~rb3768) | (rb3767 & ~rb3783);
  assign rb3961 = (rb3783 & ~rb3767) | (rb3768 & ~rb3782);
  assign rb3962 = (rb3795 & ~rb3781) | (rb3780 & ~rb3796);
  assign rb3963 = (rb3796 & ~rb3780) | (rb3781 & ~rb3795);
  assign rb3964 = (rb3808 & ~rb3794) | (rb3793 & ~rb3809);
  assign rb3965 = (rb3809 & ~rb3793) | (rb3794 & ~rb3808);
  assign rb3966 = (rb3821 & ~rb3807) | (rb3806 & ~rb3822);
  assign rb3967 = (rb3822 & ~rb3806) | (rb3807 & ~rb3821);
  assign rb3968 = (rb3834 & ~rb3820) | (rb3819 & ~rb3835);
  assign rb3969 = (rb3835 & ~rb3819) | (rb3820 & ~rb3834);
  assign rb3970 = (rb3847 & ~rb3833) | (rb3832 & ~rb3848);
  assign rb3971 = (rb3848 & ~rb3832) | (rb3833 & ~rb3847);
  assign rb3972 = (rb3860 & ~rb3846) | (rb3845 & ~rb3861);
  assign rb3973 = (rb3861 & ~rb3845) | (rb3846 & ~rb3860);
  assign rb3974 = (rb3873 & ~rb3859) | (rb3858 & ~rb3874);
  assign rb3975 = (rb3874 & ~rb3858) | (rb3859 & ~rb3873);
  assign rb3976 = (rb3886 & ~rb3872) | (rb3871 & ~rb3887);
  assign rb3977 = (rb3887 & ~rb3871) | (rb3872 & ~rb3886);
  assign rb3978 = (rb3899 & ~rb3885) | (rb3884 & ~rb3900);
  assign rb3979 = (rb3900 & ~rb3884) | (rb3885 & ~rb3899);
  assign rb3980 = (rb3912 & ~rb3898) | (rb3897 & ~rb3913);
  assign rb3981 = (rb3913 & ~rb3897) | (rb3898 & ~rb3912);
  assign rb3982 = (1'b0 & ~rb3911) | (rb3910 & ~1'b0);
  assign rb3983 = (1'b0 & ~rb3910) | (rb3911 & ~1'b0);
  assign rb3984 = 1'b0;
  assign rb3985 = 1'b0;
  assign rb3986 = 1'b0;
  assign rb3987 = 1'b0;
  assign rb3988 = rb3984 & rb3986;
  assign rb3989 = rb3985 & rb3987;
  assign rb3990 = (rb3984 & ~rb3986 & ~rb3987) | (rb3986 & ~rb3984 & ~rb3985);
  assign rb3991 = (rb3985 & ~rb3986 & ~rb3987) | (rb3987 & ~rb3984 & ~rb3985);
  assign rb3992 = rb3988 | (rb3990 & ~1'b0);
  assign rb3993 = rb3989 | (rb3991 & 1'b0);
  assign rb3994 = (rb3990 | rb3991) & 1'b0;
  assign rb3995 = (rb3990 | rb3991) & ~1'b0;
  assign rb3996 = 1'b0;
  assign rb3997 = 1'b0;
  assign rb3998 = 1'b0;
  assign rb3999 = 1'b0;
  assign rb4000 = 1'b0 | 1'b0;
  assign rb4001 = rb3996 & rb3998;
  assign rb4002 = rb3997 & rb3999;
  assign rb4003 = (rb3996 & ~rb3998 & ~rb3999) | (rb3998 & ~rb3996 & ~rb3997);
  assign rb4004 = (rb3997 & ~rb3998 & ~rb3999) | (rb3999 & ~rb3996 & ~rb3997);
  assign rb4005 = rb4001 | (rb4003 & ~rb4000);
  assign rb4006 = rb4002 | (rb4004 & rb4000);
  assign rb4007 = (rb4003 | rb4004) & rb4000;
  assign rb4008 = (rb4003 | rb4004) & ~rb4000;
  assign rb4009 = 1'b0;
  assign rb4010 = 1'b0;
  assign rb4011 = 1'b0;
  assign rb4012 = 1'b0;
  assign rb4013 = 1'b0 | 1'b0;
  assign rb4014 = rb4009 & rb4011;
  assign rb4015 = rb4010 & rb4012;
  assign rb4016 = (rb4009 & ~rb4011 & ~rb4012) | (rb4011 & ~rb4009 & ~rb4010);
  assign rb4017 = (rb4010 & ~rb4011 & ~rb4012) | (rb4012 & ~rb4009 & ~rb4010);
  assign rb4018 = rb4014 | (rb4016 & ~rb4013);
  assign rb4019 = rb4015 | (rb4017 & rb4013);
  assign rb4020 = (rb4016 | rb4017) & rb4013;
  assign rb4021 = (rb4016 | rb4017) & ~rb4013;
  assign rb4022 = 1'b0;
  assign rb4023 = 1'b0;
  assign rb4024 = 1'b0;
  assign rb4025 = 1'b0;
  assign rb4026 = 1'b0 | 1'b0;
  assign rb4027 = rb4022 & rb4024;
  assign rb4028 = rb4023 & rb4025;
  assign rb4029 = (rb4022 & ~rb4024 & ~rb4025) | (rb4024 & ~rb4022 & ~rb4023);
  assign rb4030 = (rb4023 & ~rb4024 & ~rb4025) | (rb4025 & ~rb4022 & ~rb4023);
  assign rb4031 = rb4027 | (rb4029 & ~rb4026);
  assign rb4032 = rb4028 | (rb4030 & rb4026);
  assign rb4033 = (rb4029 | rb4030) & rb4026;
  assign rb4034 = (rb4029 | rb4030) & ~rb4026;
  assign rb4035 = 1'b0;
  assign rb4036 = 1'b0;
  assign rb4037 = 1'b0;
  assign rb4038 = 1'b0;
  assign rb4039 = 1'b0 | 1'b0;
  assign rb4040 = rb4035 & rb4037;
  assign rb4041 = rb4036 & rb4038;
  assign rb4042 = (rb4035 & ~rb4037 & ~rb4038) | (rb4037 & ~rb4035 & ~rb4036);
  assign rb4043 = (rb4036 & ~rb4037 & ~rb4038) | (rb4038 & ~rb4035 & ~rb4036);
  assign rb4044 = rb4040 | (rb4042 & ~rb4039);
  assign rb4045 = rb4041 | (rb4043 & rb4039);
  assign rb4046 = (rb4042 | rb4043) & rb4039;
  assign rb4047 = (rb4042 | rb4043) & ~rb4039;
  assign rb4048 = 1'b0;
  assign rb4049 = 1'b0;
  assign rb4050 = 1'b0;
  assign rb4051 = 1'b0;
  assign rb4052 = 1'b0 | 1'b0;
  assign rb4053 = rb4048 & rb4050;
  assign rb4054 = rb4049 & rb4051;
  assign rb4055 = (rb4048 & ~rb4050 & ~rb4051) | (rb4050 & ~rb4048 & ~rb4049);
  assign rb4056 = (rb4049 & ~rb4050 & ~rb4051) | (rb4051 & ~rb4048 & ~rb4049);
  assign rb4057 = rb4053 | (rb4055 & ~rb4052);
  assign rb4058 = rb4054 | (rb4056 & rb4052);
  assign rb4059 = (rb4055 | rb4056) & rb4052;
  assign rb4060 = (rb4055 | rb4056) & ~rb4052;
  assign rb4061 = 1'b0;
  assign rb4062 = 1'b0;
  assign rb4063 = 1'b0;
  assign rb4064 = 1'b0;
  assign rb4065 = 1'b0 | 1'b0;
  assign rb4066 = rb4061 & rb4063;
  assign rb4067 = rb4062 & rb4064;
  assign rb4068 = (rb4061 & ~rb4063 & ~rb4064) | (rb4063 & ~rb4061 & ~rb4062);
  assign rb4069 = (rb4062 & ~rb4063 & ~rb4064) | (rb4064 & ~rb4061 & ~rb4062);
  assign rb4070 = rb4066 | (rb4068 & ~rb4065);
  assign rb4071 = rb4067 | (rb4069 & rb4065);
  assign rb4072 = (rb4068 | rb4069) & rb4065;
  assign rb4073 = (rb4068 | rb4069) & ~rb4065;
  assign rb4074 = 1'b0;
  assign rb4075 = 1'b0;
  assign rb4076 = 1'b0;
  assign rb4077 = 1'b0;
  assign rb4078 = 1'b0 | 1'b0;
  assign rb4079 = rb4074 & rb4076;
  assign rb4080 = rb4075 & rb4077;
  assign rb4081 = (rb4074 & ~rb4076 & ~rb4077) | (rb4076 & ~rb4074 & ~rb4075);
  assign rb4082 = (rb4075 & ~rb4076 & ~rb4077) | (rb4077 & ~rb4074 & ~rb4075);
  assign rb4083 = rb4079 | (rb4081 & ~rb4078);
  assign rb4084 = rb4080 | (rb4082 & rb4078);
  assign rb4085 = (rb4081 | rb4082) & rb4078;
  assign rb4086 = (rb4081 | rb4082) & ~rb4078;
  assign rb4087 = 1'b0;
  assign rb4088 = 1'b0;
  assign rb4089 = 1'b0;
  assign rb4090 = 1'b0;
  assign rb4091 = 1'b0 | 1'b0;
  assign rb4092 = rb4087 & rb4089;
  assign rb4093 = rb4088 & rb4090;
  assign rb4094 = (rb4087 & ~rb4089 & ~rb4090) | (rb4089 & ~rb4087 & ~rb4088);
  assign rb4095 = (rb4088 & ~rb4089 & ~rb4090) | (rb4090 & ~rb4087 & ~rb4088);
  assign rb4096 = rb4092 | (rb4094 & ~rb4091);
  assign rb4097 = rb4093 | (rb4095 & rb4091);
  assign rb4098 = (rb4094 | rb4095) & rb4091;
  assign rb4099 = (rb4094 | rb4095) & ~rb4091;
  assign rb4100 = 1'b0;
  assign rb4101 = 1'b0;
  assign rb4102 = 1'b0;
  assign rb4103 = 1'b0;
  assign rb4104 = 1'b0 | 1'b0;
  assign rb4105 = rb4100 & rb4102;
  assign rb4106 = rb4101 & rb4103;
  assign rb4107 = (rb4100 & ~rb4102 & ~rb4103) | (rb4102 & ~rb4100 & ~rb4101);
  assign rb4108 = (rb4101 & ~rb4102 & ~rb4103) | (rb4103 & ~rb4100 & ~rb4101);
  assign rb4109 = rb4105 | (rb4107 & ~rb4104);
  assign rb4110 = rb4106 | (rb4108 & rb4104);
  assign rb4111 = (rb4107 | rb4108) & rb4104;
  assign rb4112 = (rb4107 | rb4108) & ~rb4104;
  assign rb4113 = 1'b0;
  assign rb4114 = 1'b0;
  assign rb4115 = 1'b0;
  assign rb4116 = 1'b0;
  assign rb4117 = 1'b0 | 1'b0;
  assign rb4118 = rb4113 & rb4115;
  assign rb4119 = rb4114 & rb4116;
  assign rb4120 = (rb4113 & ~rb4115 & ~rb4116) | (rb4115 & ~rb4113 & ~rb4114);
  assign rb4121 = (rb4114 & ~rb4115 & ~rb4116) | (rb4116 & ~rb4113 & ~rb4114);
  assign rb4122 = rb4118 | (rb4120 & ~rb4117);
  assign rb4123 = rb4119 | (rb4121 & rb4117);
  assign rb4124 = (rb4120 | rb4121) & rb4117;
  assign rb4125 = (rb4120 | rb4121) & ~rb4117;
  assign rb4126 = 1'b0;
  assign rb4127 = 1'b0;
  assign rb4128 = 1'b0;
  assign rb4129 = 1'b0;
  assign rb4130 = 1'b0 | 1'b0;
  assign rb4131 = rb4126 & rb4128;
  assign rb4132 = rb4127 & rb4129;
  assign rb4133 = (rb4126 & ~rb4128 & ~rb4129) | (rb4128 & ~rb4126 & ~rb4127);
  assign rb4134 = (rb4127 & ~rb4128 & ~rb4129) | (rb4129 & ~rb4126 & ~rb4127);
  assign rb4135 = rb4131 | (rb4133 & ~rb4130);
  assign rb4136 = rb4132 | (rb4134 & rb4130);
  assign rb4137 = (rb4133 | rb4134) & rb4130;
  assign rb4138 = (rb4133 | rb4134) & ~rb4130;
  assign rb4139 = pp710;
  assign rb4140 = pp711;
  assign rb4141 = 1'b0;
  assign rb4142 = 1'b0;
  assign rb4143 = 1'b0 | 1'b0;
  assign rb4144 = rb4139 & rb4141;
  assign rb4145 = rb4140 & rb4142;
  assign rb4146 = (rb4139 & ~rb4141 & ~rb4142) | (rb4141 & ~rb4139 & ~rb4140);
  assign rb4147 = (rb4140 & ~rb4141 & ~rb4142) | (rb4142 & ~rb4139 & ~rb4140);
  assign rb4148 = rb4144 | (rb4146 & ~rb4143);
  assign rb4149 = rb4145 | (rb4147 & rb4143);
  assign rb4150 = (rb4146 | rb4147) & rb4143;
  assign rb4151 = (rb4146 | rb4147) & ~rb4143;
  assign rb4152 = pp712;
  assign rb4153 = pp713;
  assign rb4154 = pp756;
  assign rb4155 = pp757;
  assign rb4156 = pp711 | 1'b0;
  assign rb4157 = rb4152 & rb4154;
  assign rb4158 = rb4153 & rb4155;
  assign rb4159 = (rb4152 & ~rb4154 & ~rb4155) | (rb4154 & ~rb4152 & ~rb4153);
  assign rb4160 = (rb4153 & ~rb4154 & ~rb4155) | (rb4155 & ~rb4152 & ~rb4153);
  assign rb4161 = rb4157 | (rb4159 & ~rb4156);
  assign rb4162 = rb4158 | (rb4160 & rb4156);
  assign rb4163 = (rb4159 | rb4160) & rb4156;
  assign rb4164 = (rb4159 | rb4160) & ~rb4156;
  assign rb4165 = pp714;
  assign rb4166 = pp715;
  assign rb4167 = pp758;
  assign rb4168 = pp759;
  assign rb4169 = pp713 | pp757;
  assign rb4170 = rb4165 & rb4167;
  assign rb4171 = rb4166 & rb4168;
  assign rb4172 = (rb4165 & ~rb4167 & ~rb4168) | (rb4167 & ~rb4165 & ~rb4166);
  assign rb4173 = (rb4166 & ~rb4167 & ~rb4168) | (rb4168 & ~rb4165 & ~rb4166);
  assign rb4174 = rb4170 | (rb4172 & ~rb4169);
  assign rb4175 = rb4171 | (rb4173 & rb4169);
  assign rb4176 = (rb4172 | rb4173) & rb4169;
  assign rb4177 = (rb4172 | rb4173) & ~rb4169;
  assign rb4178 = pp716;
  assign rb4179 = pp717;
  assign rb4180 = pp760;
  assign rb4181 = pp761;
  assign rb4182 = pp715 | pp759;
  assign rb4183 = rb4178 & rb4180;
  assign rb4184 = rb4179 & rb4181;
  assign rb4185 = (rb4178 & ~rb4180 & ~rb4181) | (rb4180 & ~rb4178 & ~rb4179);
  assign rb4186 = (rb4179 & ~rb4180 & ~rb4181) | (rb4181 & ~rb4178 & ~rb4179);
  assign rb4187 = rb4183 | (rb4185 & ~rb4182);
  assign rb4188 = rb4184 | (rb4186 & rb4182);
  assign rb4189 = (rb4185 | rb4186) & rb4182;
  assign rb4190 = (rb4185 | rb4186) & ~rb4182;
  assign rb4191 = pp718;
  assign rb4192 = pp719;
  assign rb4193 = pp762;
  assign rb4194 = pp763;
  assign rb4195 = pp717 | pp761;
  assign rb4196 = rb4191 & rb4193;
  assign rb4197 = rb4192 & rb4194;
  assign rb4198 = (rb4191 & ~rb4193 & ~rb4194) | (rb4193 & ~rb4191 & ~rb4192);
  assign rb4199 = (rb4192 & ~rb4193 & ~rb4194) | (rb4194 & ~rb4191 & ~rb4192);
  assign rb4200 = rb4196 | (rb4198 & ~rb4195);
  assign rb4201 = rb4197 | (rb4199 & rb4195);
  assign rb4202 = (rb4198 | rb4199) & rb4195;
  assign rb4203 = (rb4198 | rb4199) & ~rb4195;
  assign rb4204 = pp720;
  assign rb4205 = pp721;
  assign rb4206 = pp764;
  assign rb4207 = pp765;
  assign rb4208 = pp719 | pp763;
  assign rb4209 = rb4204 & rb4206;
  assign rb4210 = rb4205 & rb4207;
  assign rb4211 = (rb4204 & ~rb4206 & ~rb4207) | (rb4206 & ~rb4204 & ~rb4205);
  assign rb4212 = (rb4205 & ~rb4206 & ~rb4207) | (rb4207 & ~rb4204 & ~rb4205);
  assign rb4213 = rb4209 | (rb4211 & ~rb4208);
  assign rb4214 = rb4210 | (rb4212 & rb4208);
  assign rb4215 = (rb4211 | rb4212) & rb4208;
  assign rb4216 = (rb4211 | rb4212) & ~rb4208;
  assign rb4217 = pp722;
  assign rb4218 = pp723;
  assign rb4219 = pp766;
  assign rb4220 = pp767;
  assign rb4221 = pp721 | pp765;
  assign rb4222 = rb4217 & rb4219;
  assign rb4223 = rb4218 & rb4220;
  assign rb4224 = (rb4217 & ~rb4219 & ~rb4220) | (rb4219 & ~rb4217 & ~rb4218);
  assign rb4225 = (rb4218 & ~rb4219 & ~rb4220) | (rb4220 & ~rb4217 & ~rb4218);
  assign rb4226 = rb4222 | (rb4224 & ~rb4221);
  assign rb4227 = rb4223 | (rb4225 & rb4221);
  assign rb4228 = (rb4224 | rb4225) & rb4221;
  assign rb4229 = (rb4224 | rb4225) & ~rb4221;
  assign rb4230 = pp724;
  assign rb4231 = pp725;
  assign rb4232 = pp768;
  assign rb4233 = pp769;
  assign rb4234 = pp723 | pp767;
  assign rb4235 = rb4230 & rb4232;
  assign rb4236 = rb4231 & rb4233;
  assign rb4237 = (rb4230 & ~rb4232 & ~rb4233) | (rb4232 & ~rb4230 & ~rb4231);
  assign rb4238 = (rb4231 & ~rb4232 & ~rb4233) | (rb4233 & ~rb4230 & ~rb4231);
  assign rb4239 = rb4235 | (rb4237 & ~rb4234);
  assign rb4240 = rb4236 | (rb4238 & rb4234);
  assign rb4241 = (rb4237 | rb4238) & rb4234;
  assign rb4242 = (rb4237 | rb4238) & ~rb4234;
  assign rb4243 = pp726;
  assign rb4244 = pp727;
  assign rb4245 = pp770;
  assign rb4246 = pp771;
  assign rb4247 = pp725 | pp769;
  assign rb4248 = rb4243 & rb4245;
  assign rb4249 = rb4244 & rb4246;
  assign rb4250 = (rb4243 & ~rb4245 & ~rb4246) | (rb4245 & ~rb4243 & ~rb4244);
  assign rb4251 = (rb4244 & ~rb4245 & ~rb4246) | (rb4246 & ~rb4243 & ~rb4244);
  assign rb4252 = rb4248 | (rb4250 & ~rb4247);
  assign rb4253 = rb4249 | (rb4251 & rb4247);
  assign rb4254 = (rb4250 | rb4251) & rb4247;
  assign rb4255 = (rb4250 | rb4251) & ~rb4247;
  assign rb4256 = pp728;
  assign rb4257 = pp729;
  assign rb4258 = pp772;
  assign rb4259 = pp773;
  assign rb4260 = pp727 | pp771;
  assign rb4261 = rb4256 & rb4258;
  assign rb4262 = rb4257 & rb4259;
  assign rb4263 = (rb4256 & ~rb4258 & ~rb4259) | (rb4258 & ~rb4256 & ~rb4257);
  assign rb4264 = (rb4257 & ~rb4258 & ~rb4259) | (rb4259 & ~rb4256 & ~rb4257);
  assign rb4265 = rb4261 | (rb4263 & ~rb4260);
  assign rb4266 = rb4262 | (rb4264 & rb4260);
  assign rb4267 = (rb4263 | rb4264) & rb4260;
  assign rb4268 = (rb4263 | rb4264) & ~rb4260;
  assign rb4269 = pp730;
  assign rb4270 = pp731;
  assign rb4271 = pp774;
  assign rb4272 = pp775;
  assign rb4273 = pp729 | pp773;
  assign rb4274 = rb4269 & rb4271;
  assign rb4275 = rb4270 & rb4272;
  assign rb4276 = (rb4269 & ~rb4271 & ~rb4272) | (rb4271 & ~rb4269 & ~rb4270);
  assign rb4277 = (rb4270 & ~rb4271 & ~rb4272) | (rb4272 & ~rb4269 & ~rb4270);
  assign rb4278 = rb4274 | (rb4276 & ~rb4273);
  assign rb4279 = rb4275 | (rb4277 & rb4273);
  assign rb4280 = (rb4276 | rb4277) & rb4273;
  assign rb4281 = (rb4276 | rb4277) & ~rb4273;
  assign rb4282 = pp732;
  assign rb4283 = pp733;
  assign rb4284 = pp776;
  assign rb4285 = pp777;
  assign rb4286 = pp731 | pp775;
  assign rb4287 = rb4282 & rb4284;
  assign rb4288 = rb4283 & rb4285;
  assign rb4289 = (rb4282 & ~rb4284 & ~rb4285) | (rb4284 & ~rb4282 & ~rb4283);
  assign rb4290 = (rb4283 & ~rb4284 & ~rb4285) | (rb4285 & ~rb4282 & ~rb4283);
  assign rb4291 = rb4287 | (rb4289 & ~rb4286);
  assign rb4292 = rb4288 | (rb4290 & rb4286);
  assign rb4293 = (rb4289 | rb4290) & rb4286;
  assign rb4294 = (rb4289 | rb4290) & ~rb4286;
  assign rb4295 = pp734;
  assign rb4296 = pp735;
  assign rb4297 = pp778;
  assign rb4298 = pp779;
  assign rb4299 = pp733 | pp777;
  assign rb4300 = rb4295 & rb4297;
  assign rb4301 = rb4296 & rb4298;
  assign rb4302 = (rb4295 & ~rb4297 & ~rb4298) | (rb4297 & ~rb4295 & ~rb4296);
  assign rb4303 = (rb4296 & ~rb4297 & ~rb4298) | (rb4298 & ~rb4295 & ~rb4296);
  assign rb4304 = rb4300 | (rb4302 & ~rb4299);
  assign rb4305 = rb4301 | (rb4303 & rb4299);
  assign rb4306 = (rb4302 | rb4303) & rb4299;
  assign rb4307 = (rb4302 | rb4303) & ~rb4299;
  assign rb4308 = pp736;
  assign rb4309 = pp737;
  assign rb4310 = pp780;
  assign rb4311 = pp781;
  assign rb4312 = pp735 | pp779;
  assign rb4313 = rb4308 & rb4310;
  assign rb4314 = rb4309 & rb4311;
  assign rb4315 = (rb4308 & ~rb4310 & ~rb4311) | (rb4310 & ~rb4308 & ~rb4309);
  assign rb4316 = (rb4309 & ~rb4310 & ~rb4311) | (rb4311 & ~rb4308 & ~rb4309);
  assign rb4317 = rb4313 | (rb4315 & ~rb4312);
  assign rb4318 = rb4314 | (rb4316 & rb4312);
  assign rb4319 = (rb4315 | rb4316) & rb4312;
  assign rb4320 = (rb4315 | rb4316) & ~rb4312;
  assign rb4321 = pp738;
  assign rb4322 = pp739;
  assign rb4323 = pp782;
  assign rb4324 = pp783;
  assign rb4325 = pp737 | pp781;
  assign rb4326 = rb4321 & rb4323;
  assign rb4327 = rb4322 & rb4324;
  assign rb4328 = (rb4321 & ~rb4323 & ~rb4324) | (rb4323 & ~rb4321 & ~rb4322);
  assign rb4329 = (rb4322 & ~rb4323 & ~rb4324) | (rb4324 & ~rb4321 & ~rb4322);
  assign rb4330 = rb4326 | (rb4328 & ~rb4325);
  assign rb4331 = rb4327 | (rb4329 & rb4325);
  assign rb4332 = (rb4328 | rb4329) & rb4325;
  assign rb4333 = (rb4328 | rb4329) & ~rb4325;
  assign rb4334 = pp740;
  assign rb4335 = pp741;
  assign rb4336 = pp784;
  assign rb4337 = pp785;
  assign rb4338 = pp739 | pp783;
  assign rb4339 = rb4334 & rb4336;
  assign rb4340 = rb4335 & rb4337;
  assign rb4341 = (rb4334 & ~rb4336 & ~rb4337) | (rb4336 & ~rb4334 & ~rb4335);
  assign rb4342 = (rb4335 & ~rb4336 & ~rb4337) | (rb4337 & ~rb4334 & ~rb4335);
  assign rb4343 = rb4339 | (rb4341 & ~rb4338);
  assign rb4344 = rb4340 | (rb4342 & rb4338);
  assign rb4345 = (rb4341 | rb4342) & rb4338;
  assign rb4346 = (rb4341 | rb4342) & ~rb4338;
  assign rb4347 = pp742;
  assign rb4348 = pp743;
  assign rb4349 = pp786;
  assign rb4350 = pp787;
  assign rb4351 = pp741 | pp785;
  assign rb4352 = rb4347 & rb4349;
  assign rb4353 = rb4348 & rb4350;
  assign rb4354 = (rb4347 & ~rb4349 & ~rb4350) | (rb4349 & ~rb4347 & ~rb4348);
  assign rb4355 = (rb4348 & ~rb4349 & ~rb4350) | (rb4350 & ~rb4347 & ~rb4348);
  assign rb4356 = rb4352 | (rb4354 & ~rb4351);
  assign rb4357 = rb4353 | (rb4355 & rb4351);
  assign rb4358 = (rb4354 | rb4355) & rb4351;
  assign rb4359 = (rb4354 | rb4355) & ~rb4351;
  assign rb4360 = pp744;
  assign rb4361 = pp745;
  assign rb4362 = pp788;
  assign rb4363 = pp789;
  assign rb4364 = pp743 | pp787;
  assign rb4365 = rb4360 & rb4362;
  assign rb4366 = rb4361 & rb4363;
  assign rb4367 = (rb4360 & ~rb4362 & ~rb4363) | (rb4362 & ~rb4360 & ~rb4361);
  assign rb4368 = (rb4361 & ~rb4362 & ~rb4363) | (rb4363 & ~rb4360 & ~rb4361);
  assign rb4369 = rb4365 | (rb4367 & ~rb4364);
  assign rb4370 = rb4366 | (rb4368 & rb4364);
  assign rb4371 = (rb4367 | rb4368) & rb4364;
  assign rb4372 = (rb4367 | rb4368) & ~rb4364;
  assign rb4373 = pp746;
  assign rb4374 = pp747;
  assign rb4375 = pp790;
  assign rb4376 = pp791;
  assign rb4377 = pp745 | pp789;
  assign rb4378 = rb4373 & rb4375;
  assign rb4379 = rb4374 & rb4376;
  assign rb4380 = (rb4373 & ~rb4375 & ~rb4376) | (rb4375 & ~rb4373 & ~rb4374);
  assign rb4381 = (rb4374 & ~rb4375 & ~rb4376) | (rb4376 & ~rb4373 & ~rb4374);
  assign rb4382 = rb4378 | (rb4380 & ~rb4377);
  assign rb4383 = rb4379 | (rb4381 & rb4377);
  assign rb4384 = (rb4380 | rb4381) & rb4377;
  assign rb4385 = (rb4380 | rb4381) & ~rb4377;
  assign rb4386 = pp748;
  assign rb4387 = pp749;
  assign rb4388 = pp792;
  assign rb4389 = pp793;
  assign rb4390 = pp747 | pp791;
  assign rb4391 = rb4386 & rb4388;
  assign rb4392 = rb4387 & rb4389;
  assign rb4393 = (rb4386 & ~rb4388 & ~rb4389) | (rb4388 & ~rb4386 & ~rb4387);
  assign rb4394 = (rb4387 & ~rb4388 & ~rb4389) | (rb4389 & ~rb4386 & ~rb4387);
  assign rb4395 = rb4391 | (rb4393 & ~rb4390);
  assign rb4396 = rb4392 | (rb4394 & rb4390);
  assign rb4397 = (rb4393 | rb4394) & rb4390;
  assign rb4398 = (rb4393 | rb4394) & ~rb4390;
  assign rb4399 = pp750;
  assign rb4400 = pp751;
  assign rb4401 = pp794;
  assign rb4402 = pp795;
  assign rb4403 = pp749 | pp793;
  assign rb4404 = rb4399 & rb4401;
  assign rb4405 = rb4400 & rb4402;
  assign rb4406 = (rb4399 & ~rb4401 & ~rb4402) | (rb4401 & ~rb4399 & ~rb4400);
  assign rb4407 = (rb4400 & ~rb4401 & ~rb4402) | (rb4402 & ~rb4399 & ~rb4400);
  assign rb4408 = rb4404 | (rb4406 & ~rb4403);
  assign rb4409 = rb4405 | (rb4407 & rb4403);
  assign rb4410 = (rb4406 | rb4407) & rb4403;
  assign rb4411 = (rb4406 | rb4407) & ~rb4403;
  assign rb4412 = pp752;
  assign rb4413 = pp753;
  assign rb4414 = pp796;
  assign rb4415 = pp797;
  assign rb4416 = pp751 | pp795;
  assign rb4417 = rb4412 & rb4414;
  assign rb4418 = rb4413 & rb4415;
  assign rb4419 = (rb4412 & ~rb4414 & ~rb4415) | (rb4414 & ~rb4412 & ~rb4413);
  assign rb4420 = (rb4413 & ~rb4414 & ~rb4415) | (rb4415 & ~rb4412 & ~rb4413);
  assign rb4421 = rb4417 | (rb4419 & ~rb4416);
  assign rb4422 = rb4418 | (rb4420 & rb4416);
  assign rb4423 = (rb4419 | rb4420) & rb4416;
  assign rb4424 = (rb4419 | rb4420) & ~rb4416;
  assign rb4425 = (rb3994 & ~1'b0) | (1'b0 & ~rb3995);
  assign rb4426 = (rb3995 & ~1'b0) | (1'b0 & ~rb3994);
  assign rb4427 = (rb4007 & ~rb3993) | (rb3992 & ~rb4008);
  assign rb4428 = (rb4008 & ~rb3992) | (rb3993 & ~rb4007);
  assign rb4429 = (rb4020 & ~rb4006) | (rb4005 & ~rb4021);
  assign rb4430 = (rb4021 & ~rb4005) | (rb4006 & ~rb4020);
  assign rb4431 = (rb4033 & ~rb4019) | (rb4018 & ~rb4034);
  assign rb4432 = (rb4034 & ~rb4018) | (rb4019 & ~rb4033);
  assign rb4433 = (rb4046 & ~rb4032) | (rb4031 & ~rb4047);
  assign rb4434 = (rb4047 & ~rb4031) | (rb4032 & ~rb4046);
  assign rb4435 = (rb4059 & ~rb4045) | (rb4044 & ~rb4060);
  assign rb4436 = (rb4060 & ~rb4044) | (rb4045 & ~rb4059);
  assign rb4437 = (rb4072 & ~rb4058) | (rb4057 & ~rb4073);
  assign rb4438 = (rb4073 & ~rb4057) | (rb4058 & ~rb4072);
  assign rb4439 = (rb4085 & ~rb4071) | (rb4070 & ~rb4086);
  assign rb4440 = (rb4086 & ~rb4070) | (rb4071 & ~rb4085);
  assign rb4441 = (rb4098 & ~rb4084) | (rb4083 & ~rb4099);
  assign rb4442 = (rb4099 & ~rb4083) | (rb4084 & ~rb4098);
  assign rb4443 = (rb4111 & ~rb4097) | (rb4096 & ~rb4112);
  assign rb4444 = (rb4112 & ~rb4096) | (rb4097 & ~rb4111);
  assign rb4445 = (rb4124 & ~rb4110) | (rb4109 & ~rb4125);
  assign rb4446 = (rb4125 & ~rb4109) | (rb4110 & ~rb4124);
  assign rb4447 = (rb4137 & ~rb4123) | (rb4122 & ~rb4138);
  assign rb4448 = (rb4138 & ~rb4122) | (rb4123 & ~rb4137);
  assign rb4449 = (rb4150 & ~rb4136) | (rb4135 & ~rb4151);
  assign rb4450 = (rb4151 & ~rb4135) | (rb4136 & ~rb4150);
  assign rb4451 = (rb4163 & ~rb4149) | (rb4148 & ~rb4164);
  assign rb4452 = (rb4164 & ~rb4148) | (rb4149 & ~rb4163);
  assign rb4453 = (rb4176 & ~rb4162) | (rb4161 & ~rb4177);
  assign rb4454 = (rb4177 & ~rb4161) | (rb4162 & ~rb4176);
  assign rb4455 = (rb4189 & ~rb4175) | (rb4174 & ~rb4190);
  assign rb4456 = (rb4190 & ~rb4174) | (rb4175 & ~rb4189);
  assign rb4457 = (rb4202 & ~rb4188) | (rb4187 & ~rb4203);
  assign rb4458 = (rb4203 & ~rb4187) | (rb4188 & ~rb4202);
  assign rb4459 = (rb4215 & ~rb4201) | (rb4200 & ~rb4216);
  assign rb4460 = (rb4216 & ~rb4200) | (rb4201 & ~rb4215);
  assign rb4461 = (rb4228 & ~rb4214) | (rb4213 & ~rb4229);
  assign rb4462 = (rb4229 & ~rb4213) | (rb4214 & ~rb4228);
  assign rb4463 = (rb4241 & ~rb4227) | (rb4226 & ~rb4242);
  assign rb4464 = (rb4242 & ~rb4226) | (rb4227 & ~rb4241);
  assign rb4465 = (rb4254 & ~rb4240) | (rb4239 & ~rb4255);
  assign rb4466 = (rb4255 & ~rb4239) | (rb4240 & ~rb4254);
  assign rb4467 = (rb4267 & ~rb4253) | (rb4252 & ~rb4268);
  assign rb4468 = (rb4268 & ~rb4252) | (rb4253 & ~rb4267);
  assign rb4469 = (rb4280 & ~rb4266) | (rb4265 & ~rb4281);
  assign rb4470 = (rb4281 & ~rb4265) | (rb4266 & ~rb4280);
  assign rb4471 = (rb4293 & ~rb4279) | (rb4278 & ~rb4294);
  assign rb4472 = (rb4294 & ~rb4278) | (rb4279 & ~rb4293);
  assign rb4473 = (rb4306 & ~rb4292) | (rb4291 & ~rb4307);
  assign rb4474 = (rb4307 & ~rb4291) | (rb4292 & ~rb4306);
  assign rb4475 = (rb4319 & ~rb4305) | (rb4304 & ~rb4320);
  assign rb4476 = (rb4320 & ~rb4304) | (rb4305 & ~rb4319);
  assign rb4477 = (rb4332 & ~rb4318) | (rb4317 & ~rb4333);
  assign rb4478 = (rb4333 & ~rb4317) | (rb4318 & ~rb4332);
  assign rb4479 = (rb4345 & ~rb4331) | (rb4330 & ~rb4346);
  assign rb4480 = (rb4346 & ~rb4330) | (rb4331 & ~rb4345);
  assign rb4481 = (rb4358 & ~rb4344) | (rb4343 & ~rb4359);
  assign rb4482 = (rb4359 & ~rb4343) | (rb4344 & ~rb4358);
  assign rb4483 = (rb4371 & ~rb4357) | (rb4356 & ~rb4372);
  assign rb4484 = (rb4372 & ~rb4356) | (rb4357 & ~rb4371);
  assign rb4485 = (rb4384 & ~rb4370) | (rb4369 & ~rb4385);
  assign rb4486 = (rb4385 & ~rb4369) | (rb4370 & ~rb4384);
  assign rb4487 = (rb4397 & ~rb4383) | (rb4382 & ~rb4398);
  assign rb4488 = (rb4398 & ~rb4382) | (rb4383 & ~rb4397);
  assign rb4489 = (rb4410 & ~rb4396) | (rb4395 & ~rb4411);
  assign rb4490 = (rb4411 & ~rb4395) | (rb4396 & ~rb4410);
  assign rb4491 = (rb4423 & ~rb4409) | (rb4408 & ~rb4424);
  assign rb4492 = (rb4424 & ~rb4408) | (rb4409 & ~rb4423);
  assign rb4493 = (1'b0 & ~rb4422) | (rb4421 & ~1'b0);
  assign rb4494 = (1'b0 & ~rb4421) | (rb4422 & ~1'b0);
  assign rb4495 = 1'b0;
  assign rb4496 = 1'b0;
  assign rb4497 = 1'b0;
  assign rb4498 = 1'b0;
  assign rb4499 = rb4495 & rb4497;
  assign rb4500 = rb4496 & rb4498;
  assign rb4501 = (rb4495 & ~rb4497 & ~rb4498) | (rb4497 & ~rb4495 & ~rb4496);
  assign rb4502 = (rb4496 & ~rb4497 & ~rb4498) | (rb4498 & ~rb4495 & ~rb4496);
  assign rb4503 = rb4499 | (rb4501 & ~1'b0);
  assign rb4504 = rb4500 | (rb4502 & 1'b0);
  assign rb4505 = (rb4501 | rb4502) & 1'b0;
  assign rb4506 = (rb4501 | rb4502) & ~1'b0;
  assign rb4507 = 1'b0;
  assign rb4508 = 1'b0;
  assign rb4509 = 1'b0;
  assign rb4510 = 1'b0;
  assign rb4511 = 1'b0 | 1'b0;
  assign rb4512 = rb4507 & rb4509;
  assign rb4513 = rb4508 & rb4510;
  assign rb4514 = (rb4507 & ~rb4509 & ~rb4510) | (rb4509 & ~rb4507 & ~rb4508);
  assign rb4515 = (rb4508 & ~rb4509 & ~rb4510) | (rb4510 & ~rb4507 & ~rb4508);
  assign rb4516 = rb4512 | (rb4514 & ~rb4511);
  assign rb4517 = rb4513 | (rb4515 & rb4511);
  assign rb4518 = (rb4514 | rb4515) & rb4511;
  assign rb4519 = (rb4514 | rb4515) & ~rb4511;
  assign rb4520 = 1'b0;
  assign rb4521 = 1'b0;
  assign rb4522 = 1'b0;
  assign rb4523 = 1'b0;
  assign rb4524 = 1'b0 | 1'b0;
  assign rb4525 = rb4520 & rb4522;
  assign rb4526 = rb4521 & rb4523;
  assign rb4527 = (rb4520 & ~rb4522 & ~rb4523) | (rb4522 & ~rb4520 & ~rb4521);
  assign rb4528 = (rb4521 & ~rb4522 & ~rb4523) | (rb4523 & ~rb4520 & ~rb4521);
  assign rb4529 = rb4525 | (rb4527 & ~rb4524);
  assign rb4530 = rb4526 | (rb4528 & rb4524);
  assign rb4531 = (rb4527 | rb4528) & rb4524;
  assign rb4532 = (rb4527 | rb4528) & ~rb4524;
  assign rb4533 = 1'b0;
  assign rb4534 = 1'b0;
  assign rb4535 = 1'b0;
  assign rb4536 = 1'b0;
  assign rb4537 = 1'b0 | 1'b0;
  assign rb4538 = rb4533 & rb4535;
  assign rb4539 = rb4534 & rb4536;
  assign rb4540 = (rb4533 & ~rb4535 & ~rb4536) | (rb4535 & ~rb4533 & ~rb4534);
  assign rb4541 = (rb4534 & ~rb4535 & ~rb4536) | (rb4536 & ~rb4533 & ~rb4534);
  assign rb4542 = rb4538 | (rb4540 & ~rb4537);
  assign rb4543 = rb4539 | (rb4541 & rb4537);
  assign rb4544 = (rb4540 | rb4541) & rb4537;
  assign rb4545 = (rb4540 | rb4541) & ~rb4537;
  assign rb4546 = 1'b0;
  assign rb4547 = 1'b0;
  assign rb4548 = 1'b0;
  assign rb4549 = 1'b0;
  assign rb4550 = 1'b0 | 1'b0;
  assign rb4551 = rb4546 & rb4548;
  assign rb4552 = rb4547 & rb4549;
  assign rb4553 = (rb4546 & ~rb4548 & ~rb4549) | (rb4548 & ~rb4546 & ~rb4547);
  assign rb4554 = (rb4547 & ~rb4548 & ~rb4549) | (rb4549 & ~rb4546 & ~rb4547);
  assign rb4555 = rb4551 | (rb4553 & ~rb4550);
  assign rb4556 = rb4552 | (rb4554 & rb4550);
  assign rb4557 = (rb4553 | rb4554) & rb4550;
  assign rb4558 = (rb4553 | rb4554) & ~rb4550;
  assign rb4559 = 1'b0;
  assign rb4560 = 1'b0;
  assign rb4561 = 1'b0;
  assign rb4562 = 1'b0;
  assign rb4563 = 1'b0 | 1'b0;
  assign rb4564 = rb4559 & rb4561;
  assign rb4565 = rb4560 & rb4562;
  assign rb4566 = (rb4559 & ~rb4561 & ~rb4562) | (rb4561 & ~rb4559 & ~rb4560);
  assign rb4567 = (rb4560 & ~rb4561 & ~rb4562) | (rb4562 & ~rb4559 & ~rb4560);
  assign rb4568 = rb4564 | (rb4566 & ~rb4563);
  assign rb4569 = rb4565 | (rb4567 & rb4563);
  assign rb4570 = (rb4566 | rb4567) & rb4563;
  assign rb4571 = (rb4566 | rb4567) & ~rb4563;
  assign rb4572 = 1'b0;
  assign rb4573 = 1'b0;
  assign rb4574 = 1'b0;
  assign rb4575 = 1'b0;
  assign rb4576 = 1'b0 | 1'b0;
  assign rb4577 = rb4572 & rb4574;
  assign rb4578 = rb4573 & rb4575;
  assign rb4579 = (rb4572 & ~rb4574 & ~rb4575) | (rb4574 & ~rb4572 & ~rb4573);
  assign rb4580 = (rb4573 & ~rb4574 & ~rb4575) | (rb4575 & ~rb4572 & ~rb4573);
  assign rb4581 = rb4577 | (rb4579 & ~rb4576);
  assign rb4582 = rb4578 | (rb4580 & rb4576);
  assign rb4583 = (rb4579 | rb4580) & rb4576;
  assign rb4584 = (rb4579 | rb4580) & ~rb4576;
  assign rb4585 = 1'b0;
  assign rb4586 = 1'b0;
  assign rb4587 = 1'b0;
  assign rb4588 = 1'b0;
  assign rb4589 = 1'b0 | 1'b0;
  assign rb4590 = rb4585 & rb4587;
  assign rb4591 = rb4586 & rb4588;
  assign rb4592 = (rb4585 & ~rb4587 & ~rb4588) | (rb4587 & ~rb4585 & ~rb4586);
  assign rb4593 = (rb4586 & ~rb4587 & ~rb4588) | (rb4588 & ~rb4585 & ~rb4586);
  assign rb4594 = rb4590 | (rb4592 & ~rb4589);
  assign rb4595 = rb4591 | (rb4593 & rb4589);
  assign rb4596 = (rb4592 | rb4593) & rb4589;
  assign rb4597 = (rb4592 | rb4593) & ~rb4589;
  assign rb4598 = 1'b0;
  assign rb4599 = 1'b0;
  assign rb4600 = 1'b0;
  assign rb4601 = 1'b0;
  assign rb4602 = 1'b0 | 1'b0;
  assign rb4603 = rb4598 & rb4600;
  assign rb4604 = rb4599 & rb4601;
  assign rb4605 = (rb4598 & ~rb4600 & ~rb4601) | (rb4600 & ~rb4598 & ~rb4599);
  assign rb4606 = (rb4599 & ~rb4600 & ~rb4601) | (rb4601 & ~rb4598 & ~rb4599);
  assign rb4607 = rb4603 | (rb4605 & ~rb4602);
  assign rb4608 = rb4604 | (rb4606 & rb4602);
  assign rb4609 = (rb4605 | rb4606) & rb4602;
  assign rb4610 = (rb4605 | rb4606) & ~rb4602;
  assign rb4611 = 1'b0;
  assign rb4612 = 1'b0;
  assign rb4613 = 1'b0;
  assign rb4614 = 1'b0;
  assign rb4615 = 1'b0 | 1'b0;
  assign rb4616 = rb4611 & rb4613;
  assign rb4617 = rb4612 & rb4614;
  assign rb4618 = (rb4611 & ~rb4613 & ~rb4614) | (rb4613 & ~rb4611 & ~rb4612);
  assign rb4619 = (rb4612 & ~rb4613 & ~rb4614) | (rb4614 & ~rb4611 & ~rb4612);
  assign rb4620 = rb4616 | (rb4618 & ~rb4615);
  assign rb4621 = rb4617 | (rb4619 & rb4615);
  assign rb4622 = (rb4618 | rb4619) & rb4615;
  assign rb4623 = (rb4618 | rb4619) & ~rb4615;
  assign rb4624 = 1'b0;
  assign rb4625 = 1'b0;
  assign rb4626 = 1'b0;
  assign rb4627 = 1'b0;
  assign rb4628 = 1'b0 | 1'b0;
  assign rb4629 = rb4624 & rb4626;
  assign rb4630 = rb4625 & rb4627;
  assign rb4631 = (rb4624 & ~rb4626 & ~rb4627) | (rb4626 & ~rb4624 & ~rb4625);
  assign rb4632 = (rb4625 & ~rb4626 & ~rb4627) | (rb4627 & ~rb4624 & ~rb4625);
  assign rb4633 = rb4629 | (rb4631 & ~rb4628);
  assign rb4634 = rb4630 | (rb4632 & rb4628);
  assign rb4635 = (rb4631 | rb4632) & rb4628;
  assign rb4636 = (rb4631 | rb4632) & ~rb4628;
  assign rb4637 = 1'b0;
  assign rb4638 = 1'b0;
  assign rb4639 = 1'b0;
  assign rb4640 = 1'b0;
  assign rb4641 = 1'b0 | 1'b0;
  assign rb4642 = rb4637 & rb4639;
  assign rb4643 = rb4638 & rb4640;
  assign rb4644 = (rb4637 & ~rb4639 & ~rb4640) | (rb4639 & ~rb4637 & ~rb4638);
  assign rb4645 = (rb4638 & ~rb4639 & ~rb4640) | (rb4640 & ~rb4637 & ~rb4638);
  assign rb4646 = rb4642 | (rb4644 & ~rb4641);
  assign rb4647 = rb4643 | (rb4645 & rb4641);
  assign rb4648 = (rb4644 | rb4645) & rb4641;
  assign rb4649 = (rb4644 | rb4645) & ~rb4641;
  assign rb4650 = 1'b0;
  assign rb4651 = 1'b0;
  assign rb4652 = 1'b0;
  assign rb4653 = 1'b0;
  assign rb4654 = 1'b0 | 1'b0;
  assign rb4655 = rb4650 & rb4652;
  assign rb4656 = rb4651 & rb4653;
  assign rb4657 = (rb4650 & ~rb4652 & ~rb4653) | (rb4652 & ~rb4650 & ~rb4651);
  assign rb4658 = (rb4651 & ~rb4652 & ~rb4653) | (rb4653 & ~rb4650 & ~rb4651);
  assign rb4659 = rb4655 | (rb4657 & ~rb4654);
  assign rb4660 = rb4656 | (rb4658 & rb4654);
  assign rb4661 = (rb4657 | rb4658) & rb4654;
  assign rb4662 = (rb4657 | rb4658) & ~rb4654;
  assign rb4663 = 1'b0;
  assign rb4664 = 1'b0;
  assign rb4665 = 1'b0;
  assign rb4666 = 1'b0;
  assign rb4667 = 1'b0 | 1'b0;
  assign rb4668 = rb4663 & rb4665;
  assign rb4669 = rb4664 & rb4666;
  assign rb4670 = (rb4663 & ~rb4665 & ~rb4666) | (rb4665 & ~rb4663 & ~rb4664);
  assign rb4671 = (rb4664 & ~rb4665 & ~rb4666) | (rb4666 & ~rb4663 & ~rb4664);
  assign rb4672 = rb4668 | (rb4670 & ~rb4667);
  assign rb4673 = rb4669 | (rb4671 & rb4667);
  assign rb4674 = (rb4670 | rb4671) & rb4667;
  assign rb4675 = (rb4670 | rb4671) & ~rb4667;
  assign rb4676 = pp800;
  assign rb4677 = pp801;
  assign rb4678 = 1'b0;
  assign rb4679 = 1'b0;
  assign rb4680 = 1'b0 | 1'b0;
  assign rb4681 = rb4676 & rb4678;
  assign rb4682 = rb4677 & rb4679;
  assign rb4683 = (rb4676 & ~rb4678 & ~rb4679) | (rb4678 & ~rb4676 & ~rb4677);
  assign rb4684 = (rb4677 & ~rb4678 & ~rb4679) | (rb4679 & ~rb4676 & ~rb4677);
  assign rb4685 = rb4681 | (rb4683 & ~rb4680);
  assign rb4686 = rb4682 | (rb4684 & rb4680);
  assign rb4687 = (rb4683 | rb4684) & rb4680;
  assign rb4688 = (rb4683 | rb4684) & ~rb4680;
  assign rb4689 = pp802;
  assign rb4690 = pp803;
  assign rb4691 = pp842;
  assign rb4692 = pp843;
  assign rb4693 = pp801 | 1'b0;
  assign rb4694 = rb4689 & rb4691;
  assign rb4695 = rb4690 & rb4692;
  assign rb4696 = (rb4689 & ~rb4691 & ~rb4692) | (rb4691 & ~rb4689 & ~rb4690);
  assign rb4697 = (rb4690 & ~rb4691 & ~rb4692) | (rb4692 & ~rb4689 & ~rb4690);
  assign rb4698 = rb4694 | (rb4696 & ~rb4693);
  assign rb4699 = rb4695 | (rb4697 & rb4693);
  assign rb4700 = (rb4696 | rb4697) & rb4693;
  assign rb4701 = (rb4696 | rb4697) & ~rb4693;
  assign rb4702 = pp804;
  assign rb4703 = pp805;
  assign rb4704 = pp844;
  assign rb4705 = pp845;
  assign rb4706 = pp803 | pp843;
  assign rb4707 = rb4702 & rb4704;
  assign rb4708 = rb4703 & rb4705;
  assign rb4709 = (rb4702 & ~rb4704 & ~rb4705) | (rb4704 & ~rb4702 & ~rb4703);
  assign rb4710 = (rb4703 & ~rb4704 & ~rb4705) | (rb4705 & ~rb4702 & ~rb4703);
  assign rb4711 = rb4707 | (rb4709 & ~rb4706);
  assign rb4712 = rb4708 | (rb4710 & rb4706);
  assign rb4713 = (rb4709 | rb4710) & rb4706;
  assign rb4714 = (rb4709 | rb4710) & ~rb4706;
  assign rb4715 = pp806;
  assign rb4716 = pp807;
  assign rb4717 = pp846;
  assign rb4718 = pp847;
  assign rb4719 = pp805 | pp845;
  assign rb4720 = rb4715 & rb4717;
  assign rb4721 = rb4716 & rb4718;
  assign rb4722 = (rb4715 & ~rb4717 & ~rb4718) | (rb4717 & ~rb4715 & ~rb4716);
  assign rb4723 = (rb4716 & ~rb4717 & ~rb4718) | (rb4718 & ~rb4715 & ~rb4716);
  assign rb4724 = rb4720 | (rb4722 & ~rb4719);
  assign rb4725 = rb4721 | (rb4723 & rb4719);
  assign rb4726 = (rb4722 | rb4723) & rb4719;
  assign rb4727 = (rb4722 | rb4723) & ~rb4719;
  assign rb4728 = pp808;
  assign rb4729 = pp809;
  assign rb4730 = pp848;
  assign rb4731 = pp849;
  assign rb4732 = pp807 | pp847;
  assign rb4733 = rb4728 & rb4730;
  assign rb4734 = rb4729 & rb4731;
  assign rb4735 = (rb4728 & ~rb4730 & ~rb4731) | (rb4730 & ~rb4728 & ~rb4729);
  assign rb4736 = (rb4729 & ~rb4730 & ~rb4731) | (rb4731 & ~rb4728 & ~rb4729);
  assign rb4737 = rb4733 | (rb4735 & ~rb4732);
  assign rb4738 = rb4734 | (rb4736 & rb4732);
  assign rb4739 = (rb4735 | rb4736) & rb4732;
  assign rb4740 = (rb4735 | rb4736) & ~rb4732;
  assign rb4741 = pp810;
  assign rb4742 = pp811;
  assign rb4743 = pp850;
  assign rb4744 = pp851;
  assign rb4745 = pp809 | pp849;
  assign rb4746 = rb4741 & rb4743;
  assign rb4747 = rb4742 & rb4744;
  assign rb4748 = (rb4741 & ~rb4743 & ~rb4744) | (rb4743 & ~rb4741 & ~rb4742);
  assign rb4749 = (rb4742 & ~rb4743 & ~rb4744) | (rb4744 & ~rb4741 & ~rb4742);
  assign rb4750 = rb4746 | (rb4748 & ~rb4745);
  assign rb4751 = rb4747 | (rb4749 & rb4745);
  assign rb4752 = (rb4748 | rb4749) & rb4745;
  assign rb4753 = (rb4748 | rb4749) & ~rb4745;
  assign rb4754 = pp812;
  assign rb4755 = pp813;
  assign rb4756 = pp852;
  assign rb4757 = pp853;
  assign rb4758 = pp811 | pp851;
  assign rb4759 = rb4754 & rb4756;
  assign rb4760 = rb4755 & rb4757;
  assign rb4761 = (rb4754 & ~rb4756 & ~rb4757) | (rb4756 & ~rb4754 & ~rb4755);
  assign rb4762 = (rb4755 & ~rb4756 & ~rb4757) | (rb4757 & ~rb4754 & ~rb4755);
  assign rb4763 = rb4759 | (rb4761 & ~rb4758);
  assign rb4764 = rb4760 | (rb4762 & rb4758);
  assign rb4765 = (rb4761 | rb4762) & rb4758;
  assign rb4766 = (rb4761 | rb4762) & ~rb4758;
  assign rb4767 = pp814;
  assign rb4768 = pp815;
  assign rb4769 = pp854;
  assign rb4770 = pp855;
  assign rb4771 = pp813 | pp853;
  assign rb4772 = rb4767 & rb4769;
  assign rb4773 = rb4768 & rb4770;
  assign rb4774 = (rb4767 & ~rb4769 & ~rb4770) | (rb4769 & ~rb4767 & ~rb4768);
  assign rb4775 = (rb4768 & ~rb4769 & ~rb4770) | (rb4770 & ~rb4767 & ~rb4768);
  assign rb4776 = rb4772 | (rb4774 & ~rb4771);
  assign rb4777 = rb4773 | (rb4775 & rb4771);
  assign rb4778 = (rb4774 | rb4775) & rb4771;
  assign rb4779 = (rb4774 | rb4775) & ~rb4771;
  assign rb4780 = pp816;
  assign rb4781 = pp817;
  assign rb4782 = pp856;
  assign rb4783 = pp857;
  assign rb4784 = pp815 | pp855;
  assign rb4785 = rb4780 & rb4782;
  assign rb4786 = rb4781 & rb4783;
  assign rb4787 = (rb4780 & ~rb4782 & ~rb4783) | (rb4782 & ~rb4780 & ~rb4781);
  assign rb4788 = (rb4781 & ~rb4782 & ~rb4783) | (rb4783 & ~rb4780 & ~rb4781);
  assign rb4789 = rb4785 | (rb4787 & ~rb4784);
  assign rb4790 = rb4786 | (rb4788 & rb4784);
  assign rb4791 = (rb4787 | rb4788) & rb4784;
  assign rb4792 = (rb4787 | rb4788) & ~rb4784;
  assign rb4793 = pp818;
  assign rb4794 = pp819;
  assign rb4795 = pp858;
  assign rb4796 = pp859;
  assign rb4797 = pp817 | pp857;
  assign rb4798 = rb4793 & rb4795;
  assign rb4799 = rb4794 & rb4796;
  assign rb4800 = (rb4793 & ~rb4795 & ~rb4796) | (rb4795 & ~rb4793 & ~rb4794);
  assign rb4801 = (rb4794 & ~rb4795 & ~rb4796) | (rb4796 & ~rb4793 & ~rb4794);
  assign rb4802 = rb4798 | (rb4800 & ~rb4797);
  assign rb4803 = rb4799 | (rb4801 & rb4797);
  assign rb4804 = (rb4800 | rb4801) & rb4797;
  assign rb4805 = (rb4800 | rb4801) & ~rb4797;
  assign rb4806 = pp820;
  assign rb4807 = pp821;
  assign rb4808 = pp860;
  assign rb4809 = pp861;
  assign rb4810 = pp819 | pp859;
  assign rb4811 = rb4806 & rb4808;
  assign rb4812 = rb4807 & rb4809;
  assign rb4813 = (rb4806 & ~rb4808 & ~rb4809) | (rb4808 & ~rb4806 & ~rb4807);
  assign rb4814 = (rb4807 & ~rb4808 & ~rb4809) | (rb4809 & ~rb4806 & ~rb4807);
  assign rb4815 = rb4811 | (rb4813 & ~rb4810);
  assign rb4816 = rb4812 | (rb4814 & rb4810);
  assign rb4817 = (rb4813 | rb4814) & rb4810;
  assign rb4818 = (rb4813 | rb4814) & ~rb4810;
  assign rb4819 = pp822;
  assign rb4820 = pp823;
  assign rb4821 = pp862;
  assign rb4822 = pp863;
  assign rb4823 = pp821 | pp861;
  assign rb4824 = rb4819 & rb4821;
  assign rb4825 = rb4820 & rb4822;
  assign rb4826 = (rb4819 & ~rb4821 & ~rb4822) | (rb4821 & ~rb4819 & ~rb4820);
  assign rb4827 = (rb4820 & ~rb4821 & ~rb4822) | (rb4822 & ~rb4819 & ~rb4820);
  assign rb4828 = rb4824 | (rb4826 & ~rb4823);
  assign rb4829 = rb4825 | (rb4827 & rb4823);
  assign rb4830 = (rb4826 | rb4827) & rb4823;
  assign rb4831 = (rb4826 | rb4827) & ~rb4823;
  assign rb4832 = pp824;
  assign rb4833 = pp825;
  assign rb4834 = pp864;
  assign rb4835 = pp865;
  assign rb4836 = pp823 | pp863;
  assign rb4837 = rb4832 & rb4834;
  assign rb4838 = rb4833 & rb4835;
  assign rb4839 = (rb4832 & ~rb4834 & ~rb4835) | (rb4834 & ~rb4832 & ~rb4833);
  assign rb4840 = (rb4833 & ~rb4834 & ~rb4835) | (rb4835 & ~rb4832 & ~rb4833);
  assign rb4841 = rb4837 | (rb4839 & ~rb4836);
  assign rb4842 = rb4838 | (rb4840 & rb4836);
  assign rb4843 = (rb4839 | rb4840) & rb4836;
  assign rb4844 = (rb4839 | rb4840) & ~rb4836;
  assign rb4845 = pp826;
  assign rb4846 = pp827;
  assign rb4847 = pp866;
  assign rb4848 = pp867;
  assign rb4849 = pp825 | pp865;
  assign rb4850 = rb4845 & rb4847;
  assign rb4851 = rb4846 & rb4848;
  assign rb4852 = (rb4845 & ~rb4847 & ~rb4848) | (rb4847 & ~rb4845 & ~rb4846);
  assign rb4853 = (rb4846 & ~rb4847 & ~rb4848) | (rb4848 & ~rb4845 & ~rb4846);
  assign rb4854 = rb4850 | (rb4852 & ~rb4849);
  assign rb4855 = rb4851 | (rb4853 & rb4849);
  assign rb4856 = (rb4852 | rb4853) & rb4849;
  assign rb4857 = (rb4852 | rb4853) & ~rb4849;
  assign rb4858 = pp828;
  assign rb4859 = pp829;
  assign rb4860 = pp868;
  assign rb4861 = pp869;
  assign rb4862 = pp827 | pp867;
  assign rb4863 = rb4858 & rb4860;
  assign rb4864 = rb4859 & rb4861;
  assign rb4865 = (rb4858 & ~rb4860 & ~rb4861) | (rb4860 & ~rb4858 & ~rb4859);
  assign rb4866 = (rb4859 & ~rb4860 & ~rb4861) | (rb4861 & ~rb4858 & ~rb4859);
  assign rb4867 = rb4863 | (rb4865 & ~rb4862);
  assign rb4868 = rb4864 | (rb4866 & rb4862);
  assign rb4869 = (rb4865 | rb4866) & rb4862;
  assign rb4870 = (rb4865 | rb4866) & ~rb4862;
  assign rb4871 = pp830;
  assign rb4872 = pp831;
  assign rb4873 = pp870;
  assign rb4874 = pp871;
  assign rb4875 = pp829 | pp869;
  assign rb4876 = rb4871 & rb4873;
  assign rb4877 = rb4872 & rb4874;
  assign rb4878 = (rb4871 & ~rb4873 & ~rb4874) | (rb4873 & ~rb4871 & ~rb4872);
  assign rb4879 = (rb4872 & ~rb4873 & ~rb4874) | (rb4874 & ~rb4871 & ~rb4872);
  assign rb4880 = rb4876 | (rb4878 & ~rb4875);
  assign rb4881 = rb4877 | (rb4879 & rb4875);
  assign rb4882 = (rb4878 | rb4879) & rb4875;
  assign rb4883 = (rb4878 | rb4879) & ~rb4875;
  assign rb4884 = pp832;
  assign rb4885 = pp833;
  assign rb4886 = pp872;
  assign rb4887 = pp873;
  assign rb4888 = pp831 | pp871;
  assign rb4889 = rb4884 & rb4886;
  assign rb4890 = rb4885 & rb4887;
  assign rb4891 = (rb4884 & ~rb4886 & ~rb4887) | (rb4886 & ~rb4884 & ~rb4885);
  assign rb4892 = (rb4885 & ~rb4886 & ~rb4887) | (rb4887 & ~rb4884 & ~rb4885);
  assign rb4893 = rb4889 | (rb4891 & ~rb4888);
  assign rb4894 = rb4890 | (rb4892 & rb4888);
  assign rb4895 = (rb4891 | rb4892) & rb4888;
  assign rb4896 = (rb4891 | rb4892) & ~rb4888;
  assign rb4897 = pp834;
  assign rb4898 = pp835;
  assign rb4899 = pp874;
  assign rb4900 = pp875;
  assign rb4901 = pp833 | pp873;
  assign rb4902 = rb4897 & rb4899;
  assign rb4903 = rb4898 & rb4900;
  assign rb4904 = (rb4897 & ~rb4899 & ~rb4900) | (rb4899 & ~rb4897 & ~rb4898);
  assign rb4905 = (rb4898 & ~rb4899 & ~rb4900) | (rb4900 & ~rb4897 & ~rb4898);
  assign rb4906 = rb4902 | (rb4904 & ~rb4901);
  assign rb4907 = rb4903 | (rb4905 & rb4901);
  assign rb4908 = (rb4904 | rb4905) & rb4901;
  assign rb4909 = (rb4904 | rb4905) & ~rb4901;
  assign rb4910 = pp836;
  assign rb4911 = pp837;
  assign rb4912 = pp876;
  assign rb4913 = pp877;
  assign rb4914 = pp835 | pp875;
  assign rb4915 = rb4910 & rb4912;
  assign rb4916 = rb4911 & rb4913;
  assign rb4917 = (rb4910 & ~rb4912 & ~rb4913) | (rb4912 & ~rb4910 & ~rb4911);
  assign rb4918 = (rb4911 & ~rb4912 & ~rb4913) | (rb4913 & ~rb4910 & ~rb4911);
  assign rb4919 = rb4915 | (rb4917 & ~rb4914);
  assign rb4920 = rb4916 | (rb4918 & rb4914);
  assign rb4921 = (rb4917 | rb4918) & rb4914;
  assign rb4922 = (rb4917 | rb4918) & ~rb4914;
  assign rb4923 = pp838;
  assign rb4924 = pp839;
  assign rb4925 = pp878;
  assign rb4926 = pp879;
  assign rb4927 = pp837 | pp877;
  assign rb4928 = rb4923 & rb4925;
  assign rb4929 = rb4924 & rb4926;
  assign rb4930 = (rb4923 & ~rb4925 & ~rb4926) | (rb4925 & ~rb4923 & ~rb4924);
  assign rb4931 = (rb4924 & ~rb4925 & ~rb4926) | (rb4926 & ~rb4923 & ~rb4924);
  assign rb4932 = rb4928 | (rb4930 & ~rb4927);
  assign rb4933 = rb4929 | (rb4931 & rb4927);
  assign rb4934 = (rb4930 | rb4931) & rb4927;
  assign rb4935 = (rb4930 | rb4931) & ~rb4927;
  assign rb4936 = (rb4505 & ~1'b0) | (1'b0 & ~rb4506);
  assign rb4937 = (rb4506 & ~1'b0) | (1'b0 & ~rb4505);
  assign rb4938 = (rb4518 & ~rb4504) | (rb4503 & ~rb4519);
  assign rb4939 = (rb4519 & ~rb4503) | (rb4504 & ~rb4518);
  assign rb4940 = (rb4531 & ~rb4517) | (rb4516 & ~rb4532);
  assign rb4941 = (rb4532 & ~rb4516) | (rb4517 & ~rb4531);
  assign rb4942 = (rb4544 & ~rb4530) | (rb4529 & ~rb4545);
  assign rb4943 = (rb4545 & ~rb4529) | (rb4530 & ~rb4544);
  assign rb4944 = (rb4557 & ~rb4543) | (rb4542 & ~rb4558);
  assign rb4945 = (rb4558 & ~rb4542) | (rb4543 & ~rb4557);
  assign rb4946 = (rb4570 & ~rb4556) | (rb4555 & ~rb4571);
  assign rb4947 = (rb4571 & ~rb4555) | (rb4556 & ~rb4570);
  assign rb4948 = (rb4583 & ~rb4569) | (rb4568 & ~rb4584);
  assign rb4949 = (rb4584 & ~rb4568) | (rb4569 & ~rb4583);
  assign rb4950 = (rb4596 & ~rb4582) | (rb4581 & ~rb4597);
  assign rb4951 = (rb4597 & ~rb4581) | (rb4582 & ~rb4596);
  assign rb4952 = (rb4609 & ~rb4595) | (rb4594 & ~rb4610);
  assign rb4953 = (rb4610 & ~rb4594) | (rb4595 & ~rb4609);
  assign rb4954 = (rb4622 & ~rb4608) | (rb4607 & ~rb4623);
  assign rb4955 = (rb4623 & ~rb4607) | (rb4608 & ~rb4622);
  assign rb4956 = (rb4635 & ~rb4621) | (rb4620 & ~rb4636);
  assign rb4957 = (rb4636 & ~rb4620) | (rb4621 & ~rb4635);
  assign rb4958 = (rb4648 & ~rb4634) | (rb4633 & ~rb4649);
  assign rb4959 = (rb4649 & ~rb4633) | (rb4634 & ~rb4648);
  assign rb4960 = (rb4661 & ~rb4647) | (rb4646 & ~rb4662);
  assign rb4961 = (rb4662 & ~rb4646) | (rb4647 & ~rb4661);
  assign rb4962 = (rb4674 & ~rb4660) | (rb4659 & ~rb4675);
  assign rb4963 = (rb4675 & ~rb4659) | (rb4660 & ~rb4674);
  assign rb4964 = (rb4687 & ~rb4673) | (rb4672 & ~rb4688);
  assign rb4965 = (rb4688 & ~rb4672) | (rb4673 & ~rb4687);
  assign rb4966 = (rb4700 & ~rb4686) | (rb4685 & ~rb4701);
  assign rb4967 = (rb4701 & ~rb4685) | (rb4686 & ~rb4700);
  assign rb4968 = (rb4713 & ~rb4699) | (rb4698 & ~rb4714);
  assign rb4969 = (rb4714 & ~rb4698) | (rb4699 & ~rb4713);
  assign rb4970 = (rb4726 & ~rb4712) | (rb4711 & ~rb4727);
  assign rb4971 = (rb4727 & ~rb4711) | (rb4712 & ~rb4726);
  assign rb4972 = (rb4739 & ~rb4725) | (rb4724 & ~rb4740);
  assign rb4973 = (rb4740 & ~rb4724) | (rb4725 & ~rb4739);
  assign rb4974 = (rb4752 & ~rb4738) | (rb4737 & ~rb4753);
  assign rb4975 = (rb4753 & ~rb4737) | (rb4738 & ~rb4752);
  assign rb4976 = (rb4765 & ~rb4751) | (rb4750 & ~rb4766);
  assign rb4977 = (rb4766 & ~rb4750) | (rb4751 & ~rb4765);
  assign rb4978 = (rb4778 & ~rb4764) | (rb4763 & ~rb4779);
  assign rb4979 = (rb4779 & ~rb4763) | (rb4764 & ~rb4778);
  assign rb4980 = (rb4791 & ~rb4777) | (rb4776 & ~rb4792);
  assign rb4981 = (rb4792 & ~rb4776) | (rb4777 & ~rb4791);
  assign rb4982 = (rb4804 & ~rb4790) | (rb4789 & ~rb4805);
  assign rb4983 = (rb4805 & ~rb4789) | (rb4790 & ~rb4804);
  assign rb4984 = (rb4817 & ~rb4803) | (rb4802 & ~rb4818);
  assign rb4985 = (rb4818 & ~rb4802) | (rb4803 & ~rb4817);
  assign rb4986 = (rb4830 & ~rb4816) | (rb4815 & ~rb4831);
  assign rb4987 = (rb4831 & ~rb4815) | (rb4816 & ~rb4830);
  assign rb4988 = (rb4843 & ~rb4829) | (rb4828 & ~rb4844);
  assign rb4989 = (rb4844 & ~rb4828) | (rb4829 & ~rb4843);
  assign rb4990 = (rb4856 & ~rb4842) | (rb4841 & ~rb4857);
  assign rb4991 = (rb4857 & ~rb4841) | (rb4842 & ~rb4856);
  assign rb4992 = (rb4869 & ~rb4855) | (rb4854 & ~rb4870);
  assign rb4993 = (rb4870 & ~rb4854) | (rb4855 & ~rb4869);
  assign rb4994 = (rb4882 & ~rb4868) | (rb4867 & ~rb4883);
  assign rb4995 = (rb4883 & ~rb4867) | (rb4868 & ~rb4882);
  assign rb4996 = (rb4895 & ~rb4881) | (rb4880 & ~rb4896);
  assign rb4997 = (rb4896 & ~rb4880) | (rb4881 & ~rb4895);
  assign rb4998 = (rb4908 & ~rb4894) | (rb4893 & ~rb4909);
  assign rb4999 = (rb4909 & ~rb4893) | (rb4894 & ~rb4908);
  assign rb5000 = (rb4921 & ~rb4907) | (rb4906 & ~rb4922);
  assign rb5001 = (rb4922 & ~rb4906) | (rb4907 & ~rb4921);
  assign rb5002 = (rb4934 & ~rb4920) | (rb4919 & ~rb4935);
  assign rb5003 = (rb4935 & ~rb4919) | (rb4920 & ~rb4934);
  assign rb5004 = (1'b0 & ~rb4933) | (rb4932 & ~1'b0);
  assign rb5005 = (1'b0 & ~rb4932) | (rb4933 & ~1'b0);
  assign rb5006 = rb1359;
  assign rb5007 = rb1360;
  assign rb5008 = rb1870;
  assign rb5009 = rb1871;
  assign rb5010 = rb5006 & rb5008;
  assign rb5011 = rb5007 & rb5009;
  assign rb5012 = (rb5006 & ~rb5008 & ~rb5009) | (rb5008 & ~rb5006 & ~rb5007);
  assign rb5013 = (rb5007 & ~rb5008 & ~rb5009) | (rb5009 & ~rb5006 & ~rb5007);
  assign rb5014 = rb5010 | (rb5012 & ~1'b0);
  assign rb5015 = rb5011 | (rb5013 & 1'b0);
  assign rb5016 = (rb5012 | rb5013) & 1'b0;
  assign rb5017 = (rb5012 | rb5013) & ~1'b0;
  assign rb5018 = rb1361;
  assign rb5019 = rb1362;
  assign rb5020 = rb1872;
  assign rb5021 = rb1873;
  assign rb5022 = rb1360 | rb1871;
  assign rb5023 = rb5018 & rb5020;
  assign rb5024 = rb5019 & rb5021;
  assign rb5025 = (rb5018 & ~rb5020 & ~rb5021) | (rb5020 & ~rb5018 & ~rb5019);
  assign rb5026 = (rb5019 & ~rb5020 & ~rb5021) | (rb5021 & ~rb5018 & ~rb5019);
  assign rb5027 = rb5023 | (rb5025 & ~rb5022);
  assign rb5028 = rb5024 | (rb5026 & rb5022);
  assign rb5029 = (rb5025 | rb5026) & rb5022;
  assign rb5030 = (rb5025 | rb5026) & ~rb5022;
  assign rb5031 = rb1363;
  assign rb5032 = rb1364;
  assign rb5033 = rb1874;
  assign rb5034 = rb1875;
  assign rb5035 = rb1362 | rb1873;
  assign rb5036 = rb5031 & rb5033;
  assign rb5037 = rb5032 & rb5034;
  assign rb5038 = (rb5031 & ~rb5033 & ~rb5034) | (rb5033 & ~rb5031 & ~rb5032);
  assign rb5039 = (rb5032 & ~rb5033 & ~rb5034) | (rb5034 & ~rb5031 & ~rb5032);
  assign rb5040 = rb5036 | (rb5038 & ~rb5035);
  assign rb5041 = rb5037 | (rb5039 & rb5035);
  assign rb5042 = (rb5038 | rb5039) & rb5035;
  assign rb5043 = (rb5038 | rb5039) & ~rb5035;
  assign rb5044 = rb1365;
  assign rb5045 = rb1366;
  assign rb5046 = rb1876;
  assign rb5047 = rb1877;
  assign rb5048 = rb1364 | rb1875;
  assign rb5049 = rb5044 & rb5046;
  assign rb5050 = rb5045 & rb5047;
  assign rb5051 = (rb5044 & ~rb5046 & ~rb5047) | (rb5046 & ~rb5044 & ~rb5045);
  assign rb5052 = (rb5045 & ~rb5046 & ~rb5047) | (rb5047 & ~rb5044 & ~rb5045);
  assign rb5053 = rb5049 | (rb5051 & ~rb5048);
  assign rb5054 = rb5050 | (rb5052 & rb5048);
  assign rb5055 = (rb5051 | rb5052) & rb5048;
  assign rb5056 = (rb5051 | rb5052) & ~rb5048;
  assign rb5057 = rb1367;
  assign rb5058 = rb1368;
  assign rb5059 = rb1878;
  assign rb5060 = rb1879;
  assign rb5061 = rb1366 | rb1877;
  assign rb5062 = rb5057 & rb5059;
  assign rb5063 = rb5058 & rb5060;
  assign rb5064 = (rb5057 & ~rb5059 & ~rb5060) | (rb5059 & ~rb5057 & ~rb5058);
  assign rb5065 = (rb5058 & ~rb5059 & ~rb5060) | (rb5060 & ~rb5057 & ~rb5058);
  assign rb5066 = rb5062 | (rb5064 & ~rb5061);
  assign rb5067 = rb5063 | (rb5065 & rb5061);
  assign rb5068 = (rb5064 | rb5065) & rb5061;
  assign rb5069 = (rb5064 | rb5065) & ~rb5061;
  assign rb5070 = rb1369;
  assign rb5071 = rb1370;
  assign rb5072 = rb1880;
  assign rb5073 = rb1881;
  assign rb5074 = rb1368 | rb1879;
  assign rb5075 = rb5070 & rb5072;
  assign rb5076 = rb5071 & rb5073;
  assign rb5077 = (rb5070 & ~rb5072 & ~rb5073) | (rb5072 & ~rb5070 & ~rb5071);
  assign rb5078 = (rb5071 & ~rb5072 & ~rb5073) | (rb5073 & ~rb5070 & ~rb5071);
  assign rb5079 = rb5075 | (rb5077 & ~rb5074);
  assign rb5080 = rb5076 | (rb5078 & rb5074);
  assign rb5081 = (rb5077 | rb5078) & rb5074;
  assign rb5082 = (rb5077 | rb5078) & ~rb5074;
  assign rb5083 = rb1371;
  assign rb5084 = rb1372;
  assign rb5085 = rb1882;
  assign rb5086 = rb1883;
  assign rb5087 = rb1370 | rb1881;
  assign rb5088 = rb5083 & rb5085;
  assign rb5089 = rb5084 & rb5086;
  assign rb5090 = (rb5083 & ~rb5085 & ~rb5086) | (rb5085 & ~rb5083 & ~rb5084);
  assign rb5091 = (rb5084 & ~rb5085 & ~rb5086) | (rb5086 & ~rb5083 & ~rb5084);
  assign rb5092 = rb5088 | (rb5090 & ~rb5087);
  assign rb5093 = rb5089 | (rb5091 & rb5087);
  assign rb5094 = (rb5090 | rb5091) & rb5087;
  assign rb5095 = (rb5090 | rb5091) & ~rb5087;
  assign rb5096 = rb1373;
  assign rb5097 = rb1374;
  assign rb5098 = rb1884;
  assign rb5099 = rb1885;
  assign rb5100 = rb1372 | rb1883;
  assign rb5101 = rb5096 & rb5098;
  assign rb5102 = rb5097 & rb5099;
  assign rb5103 = (rb5096 & ~rb5098 & ~rb5099) | (rb5098 & ~rb5096 & ~rb5097);
  assign rb5104 = (rb5097 & ~rb5098 & ~rb5099) | (rb5099 & ~rb5096 & ~rb5097);
  assign rb5105 = rb5101 | (rb5103 & ~rb5100);
  assign rb5106 = rb5102 | (rb5104 & rb5100);
  assign rb5107 = (rb5103 | rb5104) & rb5100;
  assign rb5108 = (rb5103 | rb5104) & ~rb5100;
  assign rb5109 = rb1375;
  assign rb5110 = rb1376;
  assign rb5111 = rb1886;
  assign rb5112 = rb1887;
  assign rb5113 = rb1374 | rb1885;
  assign rb5114 = rb5109 & rb5111;
  assign rb5115 = rb5110 & rb5112;
  assign rb5116 = (rb5109 & ~rb5111 & ~rb5112) | (rb5111 & ~rb5109 & ~rb5110);
  assign rb5117 = (rb5110 & ~rb5111 & ~rb5112) | (rb5112 & ~rb5109 & ~rb5110);
  assign rb5118 = rb5114 | (rb5116 & ~rb5113);
  assign rb5119 = rb5115 | (rb5117 & rb5113);
  assign rb5120 = (rb5116 | rb5117) & rb5113;
  assign rb5121 = (rb5116 | rb5117) & ~rb5113;
  assign rb5122 = rb1377;
  assign rb5123 = rb1378;
  assign rb5124 = rb1888;
  assign rb5125 = rb1889;
  assign rb5126 = rb1376 | rb1887;
  assign rb5127 = rb5122 & rb5124;
  assign rb5128 = rb5123 & rb5125;
  assign rb5129 = (rb5122 & ~rb5124 & ~rb5125) | (rb5124 & ~rb5122 & ~rb5123);
  assign rb5130 = (rb5123 & ~rb5124 & ~rb5125) | (rb5125 & ~rb5122 & ~rb5123);
  assign rb5131 = rb5127 | (rb5129 & ~rb5126);
  assign rb5132 = rb5128 | (rb5130 & rb5126);
  assign rb5133 = (rb5129 | rb5130) & rb5126;
  assign rb5134 = (rb5129 | rb5130) & ~rb5126;
  assign rb5135 = rb1379;
  assign rb5136 = rb1380;
  assign rb5137 = rb1890;
  assign rb5138 = rb1891;
  assign rb5139 = rb1378 | rb1889;
  assign rb5140 = rb5135 & rb5137;
  assign rb5141 = rb5136 & rb5138;
  assign rb5142 = (rb5135 & ~rb5137 & ~rb5138) | (rb5137 & ~rb5135 & ~rb5136);
  assign rb5143 = (rb5136 & ~rb5137 & ~rb5138) | (rb5138 & ~rb5135 & ~rb5136);
  assign rb5144 = rb5140 | (rb5142 & ~rb5139);
  assign rb5145 = rb5141 | (rb5143 & rb5139);
  assign rb5146 = (rb5142 | rb5143) & rb5139;
  assign rb5147 = (rb5142 | rb5143) & ~rb5139;
  assign rb5148 = rb1381;
  assign rb5149 = rb1382;
  assign rb5150 = rb1892;
  assign rb5151 = rb1893;
  assign rb5152 = rb1380 | rb1891;
  assign rb5153 = rb5148 & rb5150;
  assign rb5154 = rb5149 & rb5151;
  assign rb5155 = (rb5148 & ~rb5150 & ~rb5151) | (rb5150 & ~rb5148 & ~rb5149);
  assign rb5156 = (rb5149 & ~rb5150 & ~rb5151) | (rb5151 & ~rb5148 & ~rb5149);
  assign rb5157 = rb5153 | (rb5155 & ~rb5152);
  assign rb5158 = rb5154 | (rb5156 & rb5152);
  assign rb5159 = (rb5155 | rb5156) & rb5152;
  assign rb5160 = (rb5155 | rb5156) & ~rb5152;
  assign rb5161 = rb1383;
  assign rb5162 = rb1384;
  assign rb5163 = rb1894;
  assign rb5164 = rb1895;
  assign rb5165 = rb1382 | rb1893;
  assign rb5166 = rb5161 & rb5163;
  assign rb5167 = rb5162 & rb5164;
  assign rb5168 = (rb5161 & ~rb5163 & ~rb5164) | (rb5163 & ~rb5161 & ~rb5162);
  assign rb5169 = (rb5162 & ~rb5163 & ~rb5164) | (rb5164 & ~rb5161 & ~rb5162);
  assign rb5170 = rb5166 | (rb5168 & ~rb5165);
  assign rb5171 = rb5167 | (rb5169 & rb5165);
  assign rb5172 = (rb5168 | rb5169) & rb5165;
  assign rb5173 = (rb5168 | rb5169) & ~rb5165;
  assign rb5174 = rb1385;
  assign rb5175 = rb1386;
  assign rb5176 = rb1896;
  assign rb5177 = rb1897;
  assign rb5178 = rb1384 | rb1895;
  assign rb5179 = rb5174 & rb5176;
  assign rb5180 = rb5175 & rb5177;
  assign rb5181 = (rb5174 & ~rb5176 & ~rb5177) | (rb5176 & ~rb5174 & ~rb5175);
  assign rb5182 = (rb5175 & ~rb5176 & ~rb5177) | (rb5177 & ~rb5174 & ~rb5175);
  assign rb5183 = rb5179 | (rb5181 & ~rb5178);
  assign rb5184 = rb5180 | (rb5182 & rb5178);
  assign rb5185 = (rb5181 | rb5182) & rb5178;
  assign rb5186 = (rb5181 | rb5182) & ~rb5178;
  assign rb5187 = rb1387;
  assign rb5188 = rb1388;
  assign rb5189 = rb1898;
  assign rb5190 = rb1899;
  assign rb5191 = rb1386 | rb1897;
  assign rb5192 = rb5187 & rb5189;
  assign rb5193 = rb5188 & rb5190;
  assign rb5194 = (rb5187 & ~rb5189 & ~rb5190) | (rb5189 & ~rb5187 & ~rb5188);
  assign rb5195 = (rb5188 & ~rb5189 & ~rb5190) | (rb5190 & ~rb5187 & ~rb5188);
  assign rb5196 = rb5192 | (rb5194 & ~rb5191);
  assign rb5197 = rb5193 | (rb5195 & rb5191);
  assign rb5198 = (rb5194 | rb5195) & rb5191;
  assign rb5199 = (rb5194 | rb5195) & ~rb5191;
  assign rb5200 = rb1389;
  assign rb5201 = rb1390;
  assign rb5202 = rb1900;
  assign rb5203 = rb1901;
  assign rb5204 = rb1388 | rb1899;
  assign rb5205 = rb5200 & rb5202;
  assign rb5206 = rb5201 & rb5203;
  assign rb5207 = (rb5200 & ~rb5202 & ~rb5203) | (rb5202 & ~rb5200 & ~rb5201);
  assign rb5208 = (rb5201 & ~rb5202 & ~rb5203) | (rb5203 & ~rb5200 & ~rb5201);
  assign rb5209 = rb5205 | (rb5207 & ~rb5204);
  assign rb5210 = rb5206 | (rb5208 & rb5204);
  assign rb5211 = (rb5207 | rb5208) & rb5204;
  assign rb5212 = (rb5207 | rb5208) & ~rb5204;
  assign rb5213 = rb1391;
  assign rb5214 = rb1392;
  assign rb5215 = rb1902;
  assign rb5216 = rb1903;
  assign rb5217 = rb1390 | rb1901;
  assign rb5218 = rb5213 & rb5215;
  assign rb5219 = rb5214 & rb5216;
  assign rb5220 = (rb5213 & ~rb5215 & ~rb5216) | (rb5215 & ~rb5213 & ~rb5214);
  assign rb5221 = (rb5214 & ~rb5215 & ~rb5216) | (rb5216 & ~rb5213 & ~rb5214);
  assign rb5222 = rb5218 | (rb5220 & ~rb5217);
  assign rb5223 = rb5219 | (rb5221 & rb5217);
  assign rb5224 = (rb5220 | rb5221) & rb5217;
  assign rb5225 = (rb5220 | rb5221) & ~rb5217;
  assign rb5226 = rb1393;
  assign rb5227 = rb1394;
  assign rb5228 = rb1904;
  assign rb5229 = rb1905;
  assign rb5230 = rb1392 | rb1903;
  assign rb5231 = rb5226 & rb5228;
  assign rb5232 = rb5227 & rb5229;
  assign rb5233 = (rb5226 & ~rb5228 & ~rb5229) | (rb5228 & ~rb5226 & ~rb5227);
  assign rb5234 = (rb5227 & ~rb5228 & ~rb5229) | (rb5229 & ~rb5226 & ~rb5227);
  assign rb5235 = rb5231 | (rb5233 & ~rb5230);
  assign rb5236 = rb5232 | (rb5234 & rb5230);
  assign rb5237 = (rb5233 | rb5234) & rb5230;
  assign rb5238 = (rb5233 | rb5234) & ~rb5230;
  assign rb5239 = rb1395;
  assign rb5240 = rb1396;
  assign rb5241 = rb1906;
  assign rb5242 = rb1907;
  assign rb5243 = rb1394 | rb1905;
  assign rb5244 = rb5239 & rb5241;
  assign rb5245 = rb5240 & rb5242;
  assign rb5246 = (rb5239 & ~rb5241 & ~rb5242) | (rb5241 & ~rb5239 & ~rb5240);
  assign rb5247 = (rb5240 & ~rb5241 & ~rb5242) | (rb5242 & ~rb5239 & ~rb5240);
  assign rb5248 = rb5244 | (rb5246 & ~rb5243);
  assign rb5249 = rb5245 | (rb5247 & rb5243);
  assign rb5250 = (rb5246 | rb5247) & rb5243;
  assign rb5251 = (rb5246 | rb5247) & ~rb5243;
  assign rb5252 = rb1397;
  assign rb5253 = rb1398;
  assign rb5254 = rb1908;
  assign rb5255 = rb1909;
  assign rb5256 = rb1396 | rb1907;
  assign rb5257 = rb5252 & rb5254;
  assign rb5258 = rb5253 & rb5255;
  assign rb5259 = (rb5252 & ~rb5254 & ~rb5255) | (rb5254 & ~rb5252 & ~rb5253);
  assign rb5260 = (rb5253 & ~rb5254 & ~rb5255) | (rb5255 & ~rb5252 & ~rb5253);
  assign rb5261 = rb5257 | (rb5259 & ~rb5256);
  assign rb5262 = rb5258 | (rb5260 & rb5256);
  assign rb5263 = (rb5259 | rb5260) & rb5256;
  assign rb5264 = (rb5259 | rb5260) & ~rb5256;
  assign rb5265 = rb1399;
  assign rb5266 = rb1400;
  assign rb5267 = rb1910;
  assign rb5268 = rb1911;
  assign rb5269 = rb1398 | rb1909;
  assign rb5270 = rb5265 & rb5267;
  assign rb5271 = rb5266 & rb5268;
  assign rb5272 = (rb5265 & ~rb5267 & ~rb5268) | (rb5267 & ~rb5265 & ~rb5266);
  assign rb5273 = (rb5266 & ~rb5267 & ~rb5268) | (rb5268 & ~rb5265 & ~rb5266);
  assign rb5274 = rb5270 | (rb5272 & ~rb5269);
  assign rb5275 = rb5271 | (rb5273 & rb5269);
  assign rb5276 = (rb5272 | rb5273) & rb5269;
  assign rb5277 = (rb5272 | rb5273) & ~rb5269;
  assign rb5278 = rb1401;
  assign rb5279 = rb1402;
  assign rb5280 = rb1912;
  assign rb5281 = rb1913;
  assign rb5282 = rb1400 | rb1911;
  assign rb5283 = rb5278 & rb5280;
  assign rb5284 = rb5279 & rb5281;
  assign rb5285 = (rb5278 & ~rb5280 & ~rb5281) | (rb5280 & ~rb5278 & ~rb5279);
  assign rb5286 = (rb5279 & ~rb5280 & ~rb5281) | (rb5281 & ~rb5278 & ~rb5279);
  assign rb5287 = rb5283 | (rb5285 & ~rb5282);
  assign rb5288 = rb5284 | (rb5286 & rb5282);
  assign rb5289 = (rb5285 | rb5286) & rb5282;
  assign rb5290 = (rb5285 | rb5286) & ~rb5282;
  assign rb5291 = rb1403;
  assign rb5292 = rb1404;
  assign rb5293 = rb1914;
  assign rb5294 = rb1915;
  assign rb5295 = rb1402 | rb1913;
  assign rb5296 = rb5291 & rb5293;
  assign rb5297 = rb5292 & rb5294;
  assign rb5298 = (rb5291 & ~rb5293 & ~rb5294) | (rb5293 & ~rb5291 & ~rb5292);
  assign rb5299 = (rb5292 & ~rb5293 & ~rb5294) | (rb5294 & ~rb5291 & ~rb5292);
  assign rb5300 = rb5296 | (rb5298 & ~rb5295);
  assign rb5301 = rb5297 | (rb5299 & rb5295);
  assign rb5302 = (rb5298 | rb5299) & rb5295;
  assign rb5303 = (rb5298 | rb5299) & ~rb5295;
  assign rb5304 = rb1405;
  assign rb5305 = rb1406;
  assign rb5306 = rb1916;
  assign rb5307 = rb1917;
  assign rb5308 = rb1404 | rb1915;
  assign rb5309 = rb5304 & rb5306;
  assign rb5310 = rb5305 & rb5307;
  assign rb5311 = (rb5304 & ~rb5306 & ~rb5307) | (rb5306 & ~rb5304 & ~rb5305);
  assign rb5312 = (rb5305 & ~rb5306 & ~rb5307) | (rb5307 & ~rb5304 & ~rb5305);
  assign rb5313 = rb5309 | (rb5311 & ~rb5308);
  assign rb5314 = rb5310 | (rb5312 & rb5308);
  assign rb5315 = (rb5311 | rb5312) & rb5308;
  assign rb5316 = (rb5311 | rb5312) & ~rb5308;
  assign rb5317 = rb1407;
  assign rb5318 = rb1408;
  assign rb5319 = rb1918;
  assign rb5320 = rb1919;
  assign rb5321 = rb1406 | rb1917;
  assign rb5322 = rb5317 & rb5319;
  assign rb5323 = rb5318 & rb5320;
  assign rb5324 = (rb5317 & ~rb5319 & ~rb5320) | (rb5319 & ~rb5317 & ~rb5318);
  assign rb5325 = (rb5318 & ~rb5319 & ~rb5320) | (rb5320 & ~rb5317 & ~rb5318);
  assign rb5326 = rb5322 | (rb5324 & ~rb5321);
  assign rb5327 = rb5323 | (rb5325 & rb5321);
  assign rb5328 = (rb5324 | rb5325) & rb5321;
  assign rb5329 = (rb5324 | rb5325) & ~rb5321;
  assign rb5330 = rb1409;
  assign rb5331 = rb1410;
  assign rb5332 = rb1920;
  assign rb5333 = rb1921;
  assign rb5334 = rb1408 | rb1919;
  assign rb5335 = rb5330 & rb5332;
  assign rb5336 = rb5331 & rb5333;
  assign rb5337 = (rb5330 & ~rb5332 & ~rb5333) | (rb5332 & ~rb5330 & ~rb5331);
  assign rb5338 = (rb5331 & ~rb5332 & ~rb5333) | (rb5333 & ~rb5330 & ~rb5331);
  assign rb5339 = rb5335 | (rb5337 & ~rb5334);
  assign rb5340 = rb5336 | (rb5338 & rb5334);
  assign rb5341 = (rb5337 | rb5338) & rb5334;
  assign rb5342 = (rb5337 | rb5338) & ~rb5334;
  assign rb5343 = rb1411;
  assign rb5344 = rb1412;
  assign rb5345 = rb1922;
  assign rb5346 = rb1923;
  assign rb5347 = rb1410 | rb1921;
  assign rb5348 = rb5343 & rb5345;
  assign rb5349 = rb5344 & rb5346;
  assign rb5350 = (rb5343 & ~rb5345 & ~rb5346) | (rb5345 & ~rb5343 & ~rb5344);
  assign rb5351 = (rb5344 & ~rb5345 & ~rb5346) | (rb5346 & ~rb5343 & ~rb5344);
  assign rb5352 = rb5348 | (rb5350 & ~rb5347);
  assign rb5353 = rb5349 | (rb5351 & rb5347);
  assign rb5354 = (rb5350 | rb5351) & rb5347;
  assign rb5355 = (rb5350 | rb5351) & ~rb5347;
  assign rb5356 = rb1413;
  assign rb5357 = rb1414;
  assign rb5358 = rb1924;
  assign rb5359 = rb1925;
  assign rb5360 = rb1412 | rb1923;
  assign rb5361 = rb5356 & rb5358;
  assign rb5362 = rb5357 & rb5359;
  assign rb5363 = (rb5356 & ~rb5358 & ~rb5359) | (rb5358 & ~rb5356 & ~rb5357);
  assign rb5364 = (rb5357 & ~rb5358 & ~rb5359) | (rb5359 & ~rb5356 & ~rb5357);
  assign rb5365 = rb5361 | (rb5363 & ~rb5360);
  assign rb5366 = rb5362 | (rb5364 & rb5360);
  assign rb5367 = (rb5363 | rb5364) & rb5360;
  assign rb5368 = (rb5363 | rb5364) & ~rb5360;
  assign rb5369 = rb1415;
  assign rb5370 = rb1416;
  assign rb5371 = rb1926;
  assign rb5372 = rb1927;
  assign rb5373 = rb1414 | rb1925;
  assign rb5374 = rb5369 & rb5371;
  assign rb5375 = rb5370 & rb5372;
  assign rb5376 = (rb5369 & ~rb5371 & ~rb5372) | (rb5371 & ~rb5369 & ~rb5370);
  assign rb5377 = (rb5370 & ~rb5371 & ~rb5372) | (rb5372 & ~rb5369 & ~rb5370);
  assign rb5378 = rb5374 | (rb5376 & ~rb5373);
  assign rb5379 = rb5375 | (rb5377 & rb5373);
  assign rb5380 = (rb5376 | rb5377) & rb5373;
  assign rb5381 = (rb5376 | rb5377) & ~rb5373;
  assign rb5382 = rb1417;
  assign rb5383 = rb1418;
  assign rb5384 = rb1928;
  assign rb5385 = rb1929;
  assign rb5386 = rb1416 | rb1927;
  assign rb5387 = rb5382 & rb5384;
  assign rb5388 = rb5383 & rb5385;
  assign rb5389 = (rb5382 & ~rb5384 & ~rb5385) | (rb5384 & ~rb5382 & ~rb5383);
  assign rb5390 = (rb5383 & ~rb5384 & ~rb5385) | (rb5385 & ~rb5382 & ~rb5383);
  assign rb5391 = rb5387 | (rb5389 & ~rb5386);
  assign rb5392 = rb5388 | (rb5390 & rb5386);
  assign rb5393 = (rb5389 | rb5390) & rb5386;
  assign rb5394 = (rb5389 | rb5390) & ~rb5386;
  assign rb5395 = rb1419;
  assign rb5396 = rb1420;
  assign rb5397 = rb1930;
  assign rb5398 = rb1931;
  assign rb5399 = rb1418 | rb1929;
  assign rb5400 = rb5395 & rb5397;
  assign rb5401 = rb5396 & rb5398;
  assign rb5402 = (rb5395 & ~rb5397 & ~rb5398) | (rb5397 & ~rb5395 & ~rb5396);
  assign rb5403 = (rb5396 & ~rb5397 & ~rb5398) | (rb5398 & ~rb5395 & ~rb5396);
  assign rb5404 = rb5400 | (rb5402 & ~rb5399);
  assign rb5405 = rb5401 | (rb5403 & rb5399);
  assign rb5406 = (rb5402 | rb5403) & rb5399;
  assign rb5407 = (rb5402 | rb5403) & ~rb5399;
  assign rb5408 = rb1421;
  assign rb5409 = rb1422;
  assign rb5410 = rb1932;
  assign rb5411 = rb1933;
  assign rb5412 = rb1420 | rb1931;
  assign rb5413 = rb5408 & rb5410;
  assign rb5414 = rb5409 & rb5411;
  assign rb5415 = (rb5408 & ~rb5410 & ~rb5411) | (rb5410 & ~rb5408 & ~rb5409);
  assign rb5416 = (rb5409 & ~rb5410 & ~rb5411) | (rb5411 & ~rb5408 & ~rb5409);
  assign rb5417 = rb5413 | (rb5415 & ~rb5412);
  assign rb5418 = rb5414 | (rb5416 & rb5412);
  assign rb5419 = (rb5415 | rb5416) & rb5412;
  assign rb5420 = (rb5415 | rb5416) & ~rb5412;
  assign rb5421 = rb1423;
  assign rb5422 = rb1424;
  assign rb5423 = rb1934;
  assign rb5424 = rb1935;
  assign rb5425 = rb1422 | rb1933;
  assign rb5426 = rb5421 & rb5423;
  assign rb5427 = rb5422 & rb5424;
  assign rb5428 = (rb5421 & ~rb5423 & ~rb5424) | (rb5423 & ~rb5421 & ~rb5422);
  assign rb5429 = (rb5422 & ~rb5423 & ~rb5424) | (rb5424 & ~rb5421 & ~rb5422);
  assign rb5430 = rb5426 | (rb5428 & ~rb5425);
  assign rb5431 = rb5427 | (rb5429 & rb5425);
  assign rb5432 = (rb5428 | rb5429) & rb5425;
  assign rb5433 = (rb5428 | rb5429) & ~rb5425;
  assign rb5434 = rb1425;
  assign rb5435 = rb1426;
  assign rb5436 = rb1936;
  assign rb5437 = rb1937;
  assign rb5438 = rb1424 | rb1935;
  assign rb5439 = rb5434 & rb5436;
  assign rb5440 = rb5435 & rb5437;
  assign rb5441 = (rb5434 & ~rb5436 & ~rb5437) | (rb5436 & ~rb5434 & ~rb5435);
  assign rb5442 = (rb5435 & ~rb5436 & ~rb5437) | (rb5437 & ~rb5434 & ~rb5435);
  assign rb5443 = rb5439 | (rb5441 & ~rb5438);
  assign rb5444 = rb5440 | (rb5442 & rb5438);
  assign rb5445 = (rb5441 | rb5442) & rb5438;
  assign rb5446 = (rb5441 | rb5442) & ~rb5438;
  assign rb5447 = (rb5016 & ~1'b0) | (1'b0 & ~rb5017);
  assign rb5448 = (rb5017 & ~1'b0) | (1'b0 & ~rb5016);
  assign rb5449 = (rb5029 & ~rb5015) | (rb5014 & ~rb5030);
  assign rb5450 = (rb5030 & ~rb5014) | (rb5015 & ~rb5029);
  assign rb5451 = (rb5042 & ~rb5028) | (rb5027 & ~rb5043);
  assign rb5452 = (rb5043 & ~rb5027) | (rb5028 & ~rb5042);
  assign rb5453 = (rb5055 & ~rb5041) | (rb5040 & ~rb5056);
  assign rb5454 = (rb5056 & ~rb5040) | (rb5041 & ~rb5055);
  assign rb5455 = (rb5068 & ~rb5054) | (rb5053 & ~rb5069);
  assign rb5456 = (rb5069 & ~rb5053) | (rb5054 & ~rb5068);
  assign rb5457 = (rb5081 & ~rb5067) | (rb5066 & ~rb5082);
  assign rb5458 = (rb5082 & ~rb5066) | (rb5067 & ~rb5081);
  assign rb5459 = (rb5094 & ~rb5080) | (rb5079 & ~rb5095);
  assign rb5460 = (rb5095 & ~rb5079) | (rb5080 & ~rb5094);
  assign rb5461 = (rb5107 & ~rb5093) | (rb5092 & ~rb5108);
  assign rb5462 = (rb5108 & ~rb5092) | (rb5093 & ~rb5107);
  assign rb5463 = (rb5120 & ~rb5106) | (rb5105 & ~rb5121);
  assign rb5464 = (rb5121 & ~rb5105) | (rb5106 & ~rb5120);
  assign rb5465 = (rb5133 & ~rb5119) | (rb5118 & ~rb5134);
  assign rb5466 = (rb5134 & ~rb5118) | (rb5119 & ~rb5133);
  assign rb5467 = (rb5146 & ~rb5132) | (rb5131 & ~rb5147);
  assign rb5468 = (rb5147 & ~rb5131) | (rb5132 & ~rb5146);
  assign rb5469 = (rb5159 & ~rb5145) | (rb5144 & ~rb5160);
  assign rb5470 = (rb5160 & ~rb5144) | (rb5145 & ~rb5159);
  assign rb5471 = (rb5172 & ~rb5158) | (rb5157 & ~rb5173);
  assign rb5472 = (rb5173 & ~rb5157) | (rb5158 & ~rb5172);
  assign rb5473 = (rb5185 & ~rb5171) | (rb5170 & ~rb5186);
  assign rb5474 = (rb5186 & ~rb5170) | (rb5171 & ~rb5185);
  assign rb5475 = (rb5198 & ~rb5184) | (rb5183 & ~rb5199);
  assign rb5476 = (rb5199 & ~rb5183) | (rb5184 & ~rb5198);
  assign rb5477 = (rb5211 & ~rb5197) | (rb5196 & ~rb5212);
  assign rb5478 = (rb5212 & ~rb5196) | (rb5197 & ~rb5211);
  assign rb5479 = (rb5224 & ~rb5210) | (rb5209 & ~rb5225);
  assign rb5480 = (rb5225 & ~rb5209) | (rb5210 & ~rb5224);
  assign rb5481 = (rb5237 & ~rb5223) | (rb5222 & ~rb5238);
  assign rb5482 = (rb5238 & ~rb5222) | (rb5223 & ~rb5237);
  assign rb5483 = (rb5250 & ~rb5236) | (rb5235 & ~rb5251);
  assign rb5484 = (rb5251 & ~rb5235) | (rb5236 & ~rb5250);
  assign rb5485 = (rb5263 & ~rb5249) | (rb5248 & ~rb5264);
  assign rb5486 = (rb5264 & ~rb5248) | (rb5249 & ~rb5263);
  assign rb5487 = (rb5276 & ~rb5262) | (rb5261 & ~rb5277);
  assign rb5488 = (rb5277 & ~rb5261) | (rb5262 & ~rb5276);
  assign rb5489 = (rb5289 & ~rb5275) | (rb5274 & ~rb5290);
  assign rb5490 = (rb5290 & ~rb5274) | (rb5275 & ~rb5289);
  assign rb5491 = (rb5302 & ~rb5288) | (rb5287 & ~rb5303);
  assign rb5492 = (rb5303 & ~rb5287) | (rb5288 & ~rb5302);
  assign rb5493 = (rb5315 & ~rb5301) | (rb5300 & ~rb5316);
  assign rb5494 = (rb5316 & ~rb5300) | (rb5301 & ~rb5315);
  assign rb5495 = (rb5328 & ~rb5314) | (rb5313 & ~rb5329);
  assign rb5496 = (rb5329 & ~rb5313) | (rb5314 & ~rb5328);
  assign rb5497 = (rb5341 & ~rb5327) | (rb5326 & ~rb5342);
  assign rb5498 = (rb5342 & ~rb5326) | (rb5327 & ~rb5341);
  assign rb5499 = (rb5354 & ~rb5340) | (rb5339 & ~rb5355);
  assign rb5500 = (rb5355 & ~rb5339) | (rb5340 & ~rb5354);
  assign rb5501 = (rb5367 & ~rb5353) | (rb5352 & ~rb5368);
  assign rb5502 = (rb5368 & ~rb5352) | (rb5353 & ~rb5367);
  assign rb5503 = (rb5380 & ~rb5366) | (rb5365 & ~rb5381);
  assign rb5504 = (rb5381 & ~rb5365) | (rb5366 & ~rb5380);
  assign rb5505 = (rb5393 & ~rb5379) | (rb5378 & ~rb5394);
  assign rb5506 = (rb5394 & ~rb5378) | (rb5379 & ~rb5393);
  assign rb5507 = (rb5406 & ~rb5392) | (rb5391 & ~rb5407);
  assign rb5508 = (rb5407 & ~rb5391) | (rb5392 & ~rb5406);
  assign rb5509 = (rb5419 & ~rb5405) | (rb5404 & ~rb5420);
  assign rb5510 = (rb5420 & ~rb5404) | (rb5405 & ~rb5419);
  assign rb5511 = (rb5432 & ~rb5418) | (rb5417 & ~rb5433);
  assign rb5512 = (rb5433 & ~rb5417) | (rb5418 & ~rb5432);
  assign rb5513 = (rb5445 & ~rb5431) | (rb5430 & ~rb5446);
  assign rb5514 = (rb5446 & ~rb5430) | (rb5431 & ~rb5445);
  assign rb5515 = (1'b0 & ~rb5444) | (rb5443 & ~1'b0);
  assign rb5516 = (1'b0 & ~rb5443) | (rb5444 & ~1'b0);
  assign rb5517 = rb2381;
  assign rb5518 = rb2382;
  assign rb5519 = rb2892;
  assign rb5520 = rb2893;
  assign rb5521 = rb5517 & rb5519;
  assign rb5522 = rb5518 & rb5520;
  assign rb5523 = (rb5517 & ~rb5519 & ~rb5520) | (rb5519 & ~rb5517 & ~rb5518);
  assign rb5524 = (rb5518 & ~rb5519 & ~rb5520) | (rb5520 & ~rb5517 & ~rb5518);
  assign rb5525 = rb5521 | (rb5523 & ~1'b0);
  assign rb5526 = rb5522 | (rb5524 & 1'b0);
  assign rb5527 = (rb5523 | rb5524) & 1'b0;
  assign rb5528 = (rb5523 | rb5524) & ~1'b0;
  assign rb5529 = rb2383;
  assign rb5530 = rb2384;
  assign rb5531 = rb2894;
  assign rb5532 = rb2895;
  assign rb5533 = rb2382 | rb2893;
  assign rb5534 = rb5529 & rb5531;
  assign rb5535 = rb5530 & rb5532;
  assign rb5536 = (rb5529 & ~rb5531 & ~rb5532) | (rb5531 & ~rb5529 & ~rb5530);
  assign rb5537 = (rb5530 & ~rb5531 & ~rb5532) | (rb5532 & ~rb5529 & ~rb5530);
  assign rb5538 = rb5534 | (rb5536 & ~rb5533);
  assign rb5539 = rb5535 | (rb5537 & rb5533);
  assign rb5540 = (rb5536 | rb5537) & rb5533;
  assign rb5541 = (rb5536 | rb5537) & ~rb5533;
  assign rb5542 = rb2385;
  assign rb5543 = rb2386;
  assign rb5544 = rb2896;
  assign rb5545 = rb2897;
  assign rb5546 = rb2384 | rb2895;
  assign rb5547 = rb5542 & rb5544;
  assign rb5548 = rb5543 & rb5545;
  assign rb5549 = (rb5542 & ~rb5544 & ~rb5545) | (rb5544 & ~rb5542 & ~rb5543);
  assign rb5550 = (rb5543 & ~rb5544 & ~rb5545) | (rb5545 & ~rb5542 & ~rb5543);
  assign rb5551 = rb5547 | (rb5549 & ~rb5546);
  assign rb5552 = rb5548 | (rb5550 & rb5546);
  assign rb5553 = (rb5549 | rb5550) & rb5546;
  assign rb5554 = (rb5549 | rb5550) & ~rb5546;
  assign rb5555 = rb2387;
  assign rb5556 = rb2388;
  assign rb5557 = rb2898;
  assign rb5558 = rb2899;
  assign rb5559 = rb2386 | rb2897;
  assign rb5560 = rb5555 & rb5557;
  assign rb5561 = rb5556 & rb5558;
  assign rb5562 = (rb5555 & ~rb5557 & ~rb5558) | (rb5557 & ~rb5555 & ~rb5556);
  assign rb5563 = (rb5556 & ~rb5557 & ~rb5558) | (rb5558 & ~rb5555 & ~rb5556);
  assign rb5564 = rb5560 | (rb5562 & ~rb5559);
  assign rb5565 = rb5561 | (rb5563 & rb5559);
  assign rb5566 = (rb5562 | rb5563) & rb5559;
  assign rb5567 = (rb5562 | rb5563) & ~rb5559;
  assign rb5568 = rb2389;
  assign rb5569 = rb2390;
  assign rb5570 = rb2900;
  assign rb5571 = rb2901;
  assign rb5572 = rb2388 | rb2899;
  assign rb5573 = rb5568 & rb5570;
  assign rb5574 = rb5569 & rb5571;
  assign rb5575 = (rb5568 & ~rb5570 & ~rb5571) | (rb5570 & ~rb5568 & ~rb5569);
  assign rb5576 = (rb5569 & ~rb5570 & ~rb5571) | (rb5571 & ~rb5568 & ~rb5569);
  assign rb5577 = rb5573 | (rb5575 & ~rb5572);
  assign rb5578 = rb5574 | (rb5576 & rb5572);
  assign rb5579 = (rb5575 | rb5576) & rb5572;
  assign rb5580 = (rb5575 | rb5576) & ~rb5572;
  assign rb5581 = rb2391;
  assign rb5582 = rb2392;
  assign rb5583 = rb2902;
  assign rb5584 = rb2903;
  assign rb5585 = rb2390 | rb2901;
  assign rb5586 = rb5581 & rb5583;
  assign rb5587 = rb5582 & rb5584;
  assign rb5588 = (rb5581 & ~rb5583 & ~rb5584) | (rb5583 & ~rb5581 & ~rb5582);
  assign rb5589 = (rb5582 & ~rb5583 & ~rb5584) | (rb5584 & ~rb5581 & ~rb5582);
  assign rb5590 = rb5586 | (rb5588 & ~rb5585);
  assign rb5591 = rb5587 | (rb5589 & rb5585);
  assign rb5592 = (rb5588 | rb5589) & rb5585;
  assign rb5593 = (rb5588 | rb5589) & ~rb5585;
  assign rb5594 = rb2393;
  assign rb5595 = rb2394;
  assign rb5596 = rb2904;
  assign rb5597 = rb2905;
  assign rb5598 = rb2392 | rb2903;
  assign rb5599 = rb5594 & rb5596;
  assign rb5600 = rb5595 & rb5597;
  assign rb5601 = (rb5594 & ~rb5596 & ~rb5597) | (rb5596 & ~rb5594 & ~rb5595);
  assign rb5602 = (rb5595 & ~rb5596 & ~rb5597) | (rb5597 & ~rb5594 & ~rb5595);
  assign rb5603 = rb5599 | (rb5601 & ~rb5598);
  assign rb5604 = rb5600 | (rb5602 & rb5598);
  assign rb5605 = (rb5601 | rb5602) & rb5598;
  assign rb5606 = (rb5601 | rb5602) & ~rb5598;
  assign rb5607 = rb2395;
  assign rb5608 = rb2396;
  assign rb5609 = rb2906;
  assign rb5610 = rb2907;
  assign rb5611 = rb2394 | rb2905;
  assign rb5612 = rb5607 & rb5609;
  assign rb5613 = rb5608 & rb5610;
  assign rb5614 = (rb5607 & ~rb5609 & ~rb5610) | (rb5609 & ~rb5607 & ~rb5608);
  assign rb5615 = (rb5608 & ~rb5609 & ~rb5610) | (rb5610 & ~rb5607 & ~rb5608);
  assign rb5616 = rb5612 | (rb5614 & ~rb5611);
  assign rb5617 = rb5613 | (rb5615 & rb5611);
  assign rb5618 = (rb5614 | rb5615) & rb5611;
  assign rb5619 = (rb5614 | rb5615) & ~rb5611;
  assign rb5620 = rb2397;
  assign rb5621 = rb2398;
  assign rb5622 = rb2908;
  assign rb5623 = rb2909;
  assign rb5624 = rb2396 | rb2907;
  assign rb5625 = rb5620 & rb5622;
  assign rb5626 = rb5621 & rb5623;
  assign rb5627 = (rb5620 & ~rb5622 & ~rb5623) | (rb5622 & ~rb5620 & ~rb5621);
  assign rb5628 = (rb5621 & ~rb5622 & ~rb5623) | (rb5623 & ~rb5620 & ~rb5621);
  assign rb5629 = rb5625 | (rb5627 & ~rb5624);
  assign rb5630 = rb5626 | (rb5628 & rb5624);
  assign rb5631 = (rb5627 | rb5628) & rb5624;
  assign rb5632 = (rb5627 | rb5628) & ~rb5624;
  assign rb5633 = rb2399;
  assign rb5634 = rb2400;
  assign rb5635 = rb2910;
  assign rb5636 = rb2911;
  assign rb5637 = rb2398 | rb2909;
  assign rb5638 = rb5633 & rb5635;
  assign rb5639 = rb5634 & rb5636;
  assign rb5640 = (rb5633 & ~rb5635 & ~rb5636) | (rb5635 & ~rb5633 & ~rb5634);
  assign rb5641 = (rb5634 & ~rb5635 & ~rb5636) | (rb5636 & ~rb5633 & ~rb5634);
  assign rb5642 = rb5638 | (rb5640 & ~rb5637);
  assign rb5643 = rb5639 | (rb5641 & rb5637);
  assign rb5644 = (rb5640 | rb5641) & rb5637;
  assign rb5645 = (rb5640 | rb5641) & ~rb5637;
  assign rb5646 = rb2401;
  assign rb5647 = rb2402;
  assign rb5648 = rb2912;
  assign rb5649 = rb2913;
  assign rb5650 = rb2400 | rb2911;
  assign rb5651 = rb5646 & rb5648;
  assign rb5652 = rb5647 & rb5649;
  assign rb5653 = (rb5646 & ~rb5648 & ~rb5649) | (rb5648 & ~rb5646 & ~rb5647);
  assign rb5654 = (rb5647 & ~rb5648 & ~rb5649) | (rb5649 & ~rb5646 & ~rb5647);
  assign rb5655 = rb5651 | (rb5653 & ~rb5650);
  assign rb5656 = rb5652 | (rb5654 & rb5650);
  assign rb5657 = (rb5653 | rb5654) & rb5650;
  assign rb5658 = (rb5653 | rb5654) & ~rb5650;
  assign rb5659 = rb2403;
  assign rb5660 = rb2404;
  assign rb5661 = rb2914;
  assign rb5662 = rb2915;
  assign rb5663 = rb2402 | rb2913;
  assign rb5664 = rb5659 & rb5661;
  assign rb5665 = rb5660 & rb5662;
  assign rb5666 = (rb5659 & ~rb5661 & ~rb5662) | (rb5661 & ~rb5659 & ~rb5660);
  assign rb5667 = (rb5660 & ~rb5661 & ~rb5662) | (rb5662 & ~rb5659 & ~rb5660);
  assign rb5668 = rb5664 | (rb5666 & ~rb5663);
  assign rb5669 = rb5665 | (rb5667 & rb5663);
  assign rb5670 = (rb5666 | rb5667) & rb5663;
  assign rb5671 = (rb5666 | rb5667) & ~rb5663;
  assign rb5672 = rb2405;
  assign rb5673 = rb2406;
  assign rb5674 = rb2916;
  assign rb5675 = rb2917;
  assign rb5676 = rb2404 | rb2915;
  assign rb5677 = rb5672 & rb5674;
  assign rb5678 = rb5673 & rb5675;
  assign rb5679 = (rb5672 & ~rb5674 & ~rb5675) | (rb5674 & ~rb5672 & ~rb5673);
  assign rb5680 = (rb5673 & ~rb5674 & ~rb5675) | (rb5675 & ~rb5672 & ~rb5673);
  assign rb5681 = rb5677 | (rb5679 & ~rb5676);
  assign rb5682 = rb5678 | (rb5680 & rb5676);
  assign rb5683 = (rb5679 | rb5680) & rb5676;
  assign rb5684 = (rb5679 | rb5680) & ~rb5676;
  assign rb5685 = rb2407;
  assign rb5686 = rb2408;
  assign rb5687 = rb2918;
  assign rb5688 = rb2919;
  assign rb5689 = rb2406 | rb2917;
  assign rb5690 = rb5685 & rb5687;
  assign rb5691 = rb5686 & rb5688;
  assign rb5692 = (rb5685 & ~rb5687 & ~rb5688) | (rb5687 & ~rb5685 & ~rb5686);
  assign rb5693 = (rb5686 & ~rb5687 & ~rb5688) | (rb5688 & ~rb5685 & ~rb5686);
  assign rb5694 = rb5690 | (rb5692 & ~rb5689);
  assign rb5695 = rb5691 | (rb5693 & rb5689);
  assign rb5696 = (rb5692 | rb5693) & rb5689;
  assign rb5697 = (rb5692 | rb5693) & ~rb5689;
  assign rb5698 = rb2409;
  assign rb5699 = rb2410;
  assign rb5700 = rb2920;
  assign rb5701 = rb2921;
  assign rb5702 = rb2408 | rb2919;
  assign rb5703 = rb5698 & rb5700;
  assign rb5704 = rb5699 & rb5701;
  assign rb5705 = (rb5698 & ~rb5700 & ~rb5701) | (rb5700 & ~rb5698 & ~rb5699);
  assign rb5706 = (rb5699 & ~rb5700 & ~rb5701) | (rb5701 & ~rb5698 & ~rb5699);
  assign rb5707 = rb5703 | (rb5705 & ~rb5702);
  assign rb5708 = rb5704 | (rb5706 & rb5702);
  assign rb5709 = (rb5705 | rb5706) & rb5702;
  assign rb5710 = (rb5705 | rb5706) & ~rb5702;
  assign rb5711 = rb2411;
  assign rb5712 = rb2412;
  assign rb5713 = rb2922;
  assign rb5714 = rb2923;
  assign rb5715 = rb2410 | rb2921;
  assign rb5716 = rb5711 & rb5713;
  assign rb5717 = rb5712 & rb5714;
  assign rb5718 = (rb5711 & ~rb5713 & ~rb5714) | (rb5713 & ~rb5711 & ~rb5712);
  assign rb5719 = (rb5712 & ~rb5713 & ~rb5714) | (rb5714 & ~rb5711 & ~rb5712);
  assign rb5720 = rb5716 | (rb5718 & ~rb5715);
  assign rb5721 = rb5717 | (rb5719 & rb5715);
  assign rb5722 = (rb5718 | rb5719) & rb5715;
  assign rb5723 = (rb5718 | rb5719) & ~rb5715;
  assign rb5724 = rb2413;
  assign rb5725 = rb2414;
  assign rb5726 = rb2924;
  assign rb5727 = rb2925;
  assign rb5728 = rb2412 | rb2923;
  assign rb5729 = rb5724 & rb5726;
  assign rb5730 = rb5725 & rb5727;
  assign rb5731 = (rb5724 & ~rb5726 & ~rb5727) | (rb5726 & ~rb5724 & ~rb5725);
  assign rb5732 = (rb5725 & ~rb5726 & ~rb5727) | (rb5727 & ~rb5724 & ~rb5725);
  assign rb5733 = rb5729 | (rb5731 & ~rb5728);
  assign rb5734 = rb5730 | (rb5732 & rb5728);
  assign rb5735 = (rb5731 | rb5732) & rb5728;
  assign rb5736 = (rb5731 | rb5732) & ~rb5728;
  assign rb5737 = rb2415;
  assign rb5738 = rb2416;
  assign rb5739 = rb2926;
  assign rb5740 = rb2927;
  assign rb5741 = rb2414 | rb2925;
  assign rb5742 = rb5737 & rb5739;
  assign rb5743 = rb5738 & rb5740;
  assign rb5744 = (rb5737 & ~rb5739 & ~rb5740) | (rb5739 & ~rb5737 & ~rb5738);
  assign rb5745 = (rb5738 & ~rb5739 & ~rb5740) | (rb5740 & ~rb5737 & ~rb5738);
  assign rb5746 = rb5742 | (rb5744 & ~rb5741);
  assign rb5747 = rb5743 | (rb5745 & rb5741);
  assign rb5748 = (rb5744 | rb5745) & rb5741;
  assign rb5749 = (rb5744 | rb5745) & ~rb5741;
  assign rb5750 = rb2417;
  assign rb5751 = rb2418;
  assign rb5752 = rb2928;
  assign rb5753 = rb2929;
  assign rb5754 = rb2416 | rb2927;
  assign rb5755 = rb5750 & rb5752;
  assign rb5756 = rb5751 & rb5753;
  assign rb5757 = (rb5750 & ~rb5752 & ~rb5753) | (rb5752 & ~rb5750 & ~rb5751);
  assign rb5758 = (rb5751 & ~rb5752 & ~rb5753) | (rb5753 & ~rb5750 & ~rb5751);
  assign rb5759 = rb5755 | (rb5757 & ~rb5754);
  assign rb5760 = rb5756 | (rb5758 & rb5754);
  assign rb5761 = (rb5757 | rb5758) & rb5754;
  assign rb5762 = (rb5757 | rb5758) & ~rb5754;
  assign rb5763 = rb2419;
  assign rb5764 = rb2420;
  assign rb5765 = rb2930;
  assign rb5766 = rb2931;
  assign rb5767 = rb2418 | rb2929;
  assign rb5768 = rb5763 & rb5765;
  assign rb5769 = rb5764 & rb5766;
  assign rb5770 = (rb5763 & ~rb5765 & ~rb5766) | (rb5765 & ~rb5763 & ~rb5764);
  assign rb5771 = (rb5764 & ~rb5765 & ~rb5766) | (rb5766 & ~rb5763 & ~rb5764);
  assign rb5772 = rb5768 | (rb5770 & ~rb5767);
  assign rb5773 = rb5769 | (rb5771 & rb5767);
  assign rb5774 = (rb5770 | rb5771) & rb5767;
  assign rb5775 = (rb5770 | rb5771) & ~rb5767;
  assign rb5776 = rb2421;
  assign rb5777 = rb2422;
  assign rb5778 = rb2932;
  assign rb5779 = rb2933;
  assign rb5780 = rb2420 | rb2931;
  assign rb5781 = rb5776 & rb5778;
  assign rb5782 = rb5777 & rb5779;
  assign rb5783 = (rb5776 & ~rb5778 & ~rb5779) | (rb5778 & ~rb5776 & ~rb5777);
  assign rb5784 = (rb5777 & ~rb5778 & ~rb5779) | (rb5779 & ~rb5776 & ~rb5777);
  assign rb5785 = rb5781 | (rb5783 & ~rb5780);
  assign rb5786 = rb5782 | (rb5784 & rb5780);
  assign rb5787 = (rb5783 | rb5784) & rb5780;
  assign rb5788 = (rb5783 | rb5784) & ~rb5780;
  assign rb5789 = rb2423;
  assign rb5790 = rb2424;
  assign rb5791 = rb2934;
  assign rb5792 = rb2935;
  assign rb5793 = rb2422 | rb2933;
  assign rb5794 = rb5789 & rb5791;
  assign rb5795 = rb5790 & rb5792;
  assign rb5796 = (rb5789 & ~rb5791 & ~rb5792) | (rb5791 & ~rb5789 & ~rb5790);
  assign rb5797 = (rb5790 & ~rb5791 & ~rb5792) | (rb5792 & ~rb5789 & ~rb5790);
  assign rb5798 = rb5794 | (rb5796 & ~rb5793);
  assign rb5799 = rb5795 | (rb5797 & rb5793);
  assign rb5800 = (rb5796 | rb5797) & rb5793;
  assign rb5801 = (rb5796 | rb5797) & ~rb5793;
  assign rb5802 = rb2425;
  assign rb5803 = rb2426;
  assign rb5804 = rb2936;
  assign rb5805 = rb2937;
  assign rb5806 = rb2424 | rb2935;
  assign rb5807 = rb5802 & rb5804;
  assign rb5808 = rb5803 & rb5805;
  assign rb5809 = (rb5802 & ~rb5804 & ~rb5805) | (rb5804 & ~rb5802 & ~rb5803);
  assign rb5810 = (rb5803 & ~rb5804 & ~rb5805) | (rb5805 & ~rb5802 & ~rb5803);
  assign rb5811 = rb5807 | (rb5809 & ~rb5806);
  assign rb5812 = rb5808 | (rb5810 & rb5806);
  assign rb5813 = (rb5809 | rb5810) & rb5806;
  assign rb5814 = (rb5809 | rb5810) & ~rb5806;
  assign rb5815 = rb2427;
  assign rb5816 = rb2428;
  assign rb5817 = rb2938;
  assign rb5818 = rb2939;
  assign rb5819 = rb2426 | rb2937;
  assign rb5820 = rb5815 & rb5817;
  assign rb5821 = rb5816 & rb5818;
  assign rb5822 = (rb5815 & ~rb5817 & ~rb5818) | (rb5817 & ~rb5815 & ~rb5816);
  assign rb5823 = (rb5816 & ~rb5817 & ~rb5818) | (rb5818 & ~rb5815 & ~rb5816);
  assign rb5824 = rb5820 | (rb5822 & ~rb5819);
  assign rb5825 = rb5821 | (rb5823 & rb5819);
  assign rb5826 = (rb5822 | rb5823) & rb5819;
  assign rb5827 = (rb5822 | rb5823) & ~rb5819;
  assign rb5828 = rb2429;
  assign rb5829 = rb2430;
  assign rb5830 = rb2940;
  assign rb5831 = rb2941;
  assign rb5832 = rb2428 | rb2939;
  assign rb5833 = rb5828 & rb5830;
  assign rb5834 = rb5829 & rb5831;
  assign rb5835 = (rb5828 & ~rb5830 & ~rb5831) | (rb5830 & ~rb5828 & ~rb5829);
  assign rb5836 = (rb5829 & ~rb5830 & ~rb5831) | (rb5831 & ~rb5828 & ~rb5829);
  assign rb5837 = rb5833 | (rb5835 & ~rb5832);
  assign rb5838 = rb5834 | (rb5836 & rb5832);
  assign rb5839 = (rb5835 | rb5836) & rb5832;
  assign rb5840 = (rb5835 | rb5836) & ~rb5832;
  assign rb5841 = rb2431;
  assign rb5842 = rb2432;
  assign rb5843 = rb2942;
  assign rb5844 = rb2943;
  assign rb5845 = rb2430 | rb2941;
  assign rb5846 = rb5841 & rb5843;
  assign rb5847 = rb5842 & rb5844;
  assign rb5848 = (rb5841 & ~rb5843 & ~rb5844) | (rb5843 & ~rb5841 & ~rb5842);
  assign rb5849 = (rb5842 & ~rb5843 & ~rb5844) | (rb5844 & ~rb5841 & ~rb5842);
  assign rb5850 = rb5846 | (rb5848 & ~rb5845);
  assign rb5851 = rb5847 | (rb5849 & rb5845);
  assign rb5852 = (rb5848 | rb5849) & rb5845;
  assign rb5853 = (rb5848 | rb5849) & ~rb5845;
  assign rb5854 = rb2433;
  assign rb5855 = rb2434;
  assign rb5856 = rb2944;
  assign rb5857 = rb2945;
  assign rb5858 = rb2432 | rb2943;
  assign rb5859 = rb5854 & rb5856;
  assign rb5860 = rb5855 & rb5857;
  assign rb5861 = (rb5854 & ~rb5856 & ~rb5857) | (rb5856 & ~rb5854 & ~rb5855);
  assign rb5862 = (rb5855 & ~rb5856 & ~rb5857) | (rb5857 & ~rb5854 & ~rb5855);
  assign rb5863 = rb5859 | (rb5861 & ~rb5858);
  assign rb5864 = rb5860 | (rb5862 & rb5858);
  assign rb5865 = (rb5861 | rb5862) & rb5858;
  assign rb5866 = (rb5861 | rb5862) & ~rb5858;
  assign rb5867 = rb2435;
  assign rb5868 = rb2436;
  assign rb5869 = rb2946;
  assign rb5870 = rb2947;
  assign rb5871 = rb2434 | rb2945;
  assign rb5872 = rb5867 & rb5869;
  assign rb5873 = rb5868 & rb5870;
  assign rb5874 = (rb5867 & ~rb5869 & ~rb5870) | (rb5869 & ~rb5867 & ~rb5868);
  assign rb5875 = (rb5868 & ~rb5869 & ~rb5870) | (rb5870 & ~rb5867 & ~rb5868);
  assign rb5876 = rb5872 | (rb5874 & ~rb5871);
  assign rb5877 = rb5873 | (rb5875 & rb5871);
  assign rb5878 = (rb5874 | rb5875) & rb5871;
  assign rb5879 = (rb5874 | rb5875) & ~rb5871;
  assign rb5880 = rb2437;
  assign rb5881 = rb2438;
  assign rb5882 = rb2948;
  assign rb5883 = rb2949;
  assign rb5884 = rb2436 | rb2947;
  assign rb5885 = rb5880 & rb5882;
  assign rb5886 = rb5881 & rb5883;
  assign rb5887 = (rb5880 & ~rb5882 & ~rb5883) | (rb5882 & ~rb5880 & ~rb5881);
  assign rb5888 = (rb5881 & ~rb5882 & ~rb5883) | (rb5883 & ~rb5880 & ~rb5881);
  assign rb5889 = rb5885 | (rb5887 & ~rb5884);
  assign rb5890 = rb5886 | (rb5888 & rb5884);
  assign rb5891 = (rb5887 | rb5888) & rb5884;
  assign rb5892 = (rb5887 | rb5888) & ~rb5884;
  assign rb5893 = rb2439;
  assign rb5894 = rb2440;
  assign rb5895 = rb2950;
  assign rb5896 = rb2951;
  assign rb5897 = rb2438 | rb2949;
  assign rb5898 = rb5893 & rb5895;
  assign rb5899 = rb5894 & rb5896;
  assign rb5900 = (rb5893 & ~rb5895 & ~rb5896) | (rb5895 & ~rb5893 & ~rb5894);
  assign rb5901 = (rb5894 & ~rb5895 & ~rb5896) | (rb5896 & ~rb5893 & ~rb5894);
  assign rb5902 = rb5898 | (rb5900 & ~rb5897);
  assign rb5903 = rb5899 | (rb5901 & rb5897);
  assign rb5904 = (rb5900 | rb5901) & rb5897;
  assign rb5905 = (rb5900 | rb5901) & ~rb5897;
  assign rb5906 = rb2441;
  assign rb5907 = rb2442;
  assign rb5908 = rb2952;
  assign rb5909 = rb2953;
  assign rb5910 = rb2440 | rb2951;
  assign rb5911 = rb5906 & rb5908;
  assign rb5912 = rb5907 & rb5909;
  assign rb5913 = (rb5906 & ~rb5908 & ~rb5909) | (rb5908 & ~rb5906 & ~rb5907);
  assign rb5914 = (rb5907 & ~rb5908 & ~rb5909) | (rb5909 & ~rb5906 & ~rb5907);
  assign rb5915 = rb5911 | (rb5913 & ~rb5910);
  assign rb5916 = rb5912 | (rb5914 & rb5910);
  assign rb5917 = (rb5913 | rb5914) & rb5910;
  assign rb5918 = (rb5913 | rb5914) & ~rb5910;
  assign rb5919 = rb2443;
  assign rb5920 = rb2444;
  assign rb5921 = rb2954;
  assign rb5922 = rb2955;
  assign rb5923 = rb2442 | rb2953;
  assign rb5924 = rb5919 & rb5921;
  assign rb5925 = rb5920 & rb5922;
  assign rb5926 = (rb5919 & ~rb5921 & ~rb5922) | (rb5921 & ~rb5919 & ~rb5920);
  assign rb5927 = (rb5920 & ~rb5921 & ~rb5922) | (rb5922 & ~rb5919 & ~rb5920);
  assign rb5928 = rb5924 | (rb5926 & ~rb5923);
  assign rb5929 = rb5925 | (rb5927 & rb5923);
  assign rb5930 = (rb5926 | rb5927) & rb5923;
  assign rb5931 = (rb5926 | rb5927) & ~rb5923;
  assign rb5932 = rb2445;
  assign rb5933 = rb2446;
  assign rb5934 = rb2956;
  assign rb5935 = rb2957;
  assign rb5936 = rb2444 | rb2955;
  assign rb5937 = rb5932 & rb5934;
  assign rb5938 = rb5933 & rb5935;
  assign rb5939 = (rb5932 & ~rb5934 & ~rb5935) | (rb5934 & ~rb5932 & ~rb5933);
  assign rb5940 = (rb5933 & ~rb5934 & ~rb5935) | (rb5935 & ~rb5932 & ~rb5933);
  assign rb5941 = rb5937 | (rb5939 & ~rb5936);
  assign rb5942 = rb5938 | (rb5940 & rb5936);
  assign rb5943 = (rb5939 | rb5940) & rb5936;
  assign rb5944 = (rb5939 | rb5940) & ~rb5936;
  assign rb5945 = rb2447;
  assign rb5946 = rb2448;
  assign rb5947 = rb2958;
  assign rb5948 = rb2959;
  assign rb5949 = rb2446 | rb2957;
  assign rb5950 = rb5945 & rb5947;
  assign rb5951 = rb5946 & rb5948;
  assign rb5952 = (rb5945 & ~rb5947 & ~rb5948) | (rb5947 & ~rb5945 & ~rb5946);
  assign rb5953 = (rb5946 & ~rb5947 & ~rb5948) | (rb5948 & ~rb5945 & ~rb5946);
  assign rb5954 = rb5950 | (rb5952 & ~rb5949);
  assign rb5955 = rb5951 | (rb5953 & rb5949);
  assign rb5956 = (rb5952 | rb5953) & rb5949;
  assign rb5957 = (rb5952 | rb5953) & ~rb5949;
  assign rb5958 = (rb5527 & ~1'b0) | (1'b0 & ~rb5528);
  assign rb5959 = (rb5528 & ~1'b0) | (1'b0 & ~rb5527);
  assign rb5960 = (rb5540 & ~rb5526) | (rb5525 & ~rb5541);
  assign rb5961 = (rb5541 & ~rb5525) | (rb5526 & ~rb5540);
  assign rb5962 = (rb5553 & ~rb5539) | (rb5538 & ~rb5554);
  assign rb5963 = (rb5554 & ~rb5538) | (rb5539 & ~rb5553);
  assign rb5964 = (rb5566 & ~rb5552) | (rb5551 & ~rb5567);
  assign rb5965 = (rb5567 & ~rb5551) | (rb5552 & ~rb5566);
  assign rb5966 = (rb5579 & ~rb5565) | (rb5564 & ~rb5580);
  assign rb5967 = (rb5580 & ~rb5564) | (rb5565 & ~rb5579);
  assign rb5968 = (rb5592 & ~rb5578) | (rb5577 & ~rb5593);
  assign rb5969 = (rb5593 & ~rb5577) | (rb5578 & ~rb5592);
  assign rb5970 = (rb5605 & ~rb5591) | (rb5590 & ~rb5606);
  assign rb5971 = (rb5606 & ~rb5590) | (rb5591 & ~rb5605);
  assign rb5972 = (rb5618 & ~rb5604) | (rb5603 & ~rb5619);
  assign rb5973 = (rb5619 & ~rb5603) | (rb5604 & ~rb5618);
  assign rb5974 = (rb5631 & ~rb5617) | (rb5616 & ~rb5632);
  assign rb5975 = (rb5632 & ~rb5616) | (rb5617 & ~rb5631);
  assign rb5976 = (rb5644 & ~rb5630) | (rb5629 & ~rb5645);
  assign rb5977 = (rb5645 & ~rb5629) | (rb5630 & ~rb5644);
  assign rb5978 = (rb5657 & ~rb5643) | (rb5642 & ~rb5658);
  assign rb5979 = (rb5658 & ~rb5642) | (rb5643 & ~rb5657);
  assign rb5980 = (rb5670 & ~rb5656) | (rb5655 & ~rb5671);
  assign rb5981 = (rb5671 & ~rb5655) | (rb5656 & ~rb5670);
  assign rb5982 = (rb5683 & ~rb5669) | (rb5668 & ~rb5684);
  assign rb5983 = (rb5684 & ~rb5668) | (rb5669 & ~rb5683);
  assign rb5984 = (rb5696 & ~rb5682) | (rb5681 & ~rb5697);
  assign rb5985 = (rb5697 & ~rb5681) | (rb5682 & ~rb5696);
  assign rb5986 = (rb5709 & ~rb5695) | (rb5694 & ~rb5710);
  assign rb5987 = (rb5710 & ~rb5694) | (rb5695 & ~rb5709);
  assign rb5988 = (rb5722 & ~rb5708) | (rb5707 & ~rb5723);
  assign rb5989 = (rb5723 & ~rb5707) | (rb5708 & ~rb5722);
  assign rb5990 = (rb5735 & ~rb5721) | (rb5720 & ~rb5736);
  assign rb5991 = (rb5736 & ~rb5720) | (rb5721 & ~rb5735);
  assign rb5992 = (rb5748 & ~rb5734) | (rb5733 & ~rb5749);
  assign rb5993 = (rb5749 & ~rb5733) | (rb5734 & ~rb5748);
  assign rb5994 = (rb5761 & ~rb5747) | (rb5746 & ~rb5762);
  assign rb5995 = (rb5762 & ~rb5746) | (rb5747 & ~rb5761);
  assign rb5996 = (rb5774 & ~rb5760) | (rb5759 & ~rb5775);
  assign rb5997 = (rb5775 & ~rb5759) | (rb5760 & ~rb5774);
  assign rb5998 = (rb5787 & ~rb5773) | (rb5772 & ~rb5788);
  assign rb5999 = (rb5788 & ~rb5772) | (rb5773 & ~rb5787);
  assign rb6000 = (rb5800 & ~rb5786) | (rb5785 & ~rb5801);
  assign rb6001 = (rb5801 & ~rb5785) | (rb5786 & ~rb5800);
  assign rb6002 = (rb5813 & ~rb5799) | (rb5798 & ~rb5814);
  assign rb6003 = (rb5814 & ~rb5798) | (rb5799 & ~rb5813);
  assign rb6004 = (rb5826 & ~rb5812) | (rb5811 & ~rb5827);
  assign rb6005 = (rb5827 & ~rb5811) | (rb5812 & ~rb5826);
  assign rb6006 = (rb5839 & ~rb5825) | (rb5824 & ~rb5840);
  assign rb6007 = (rb5840 & ~rb5824) | (rb5825 & ~rb5839);
  assign rb6008 = (rb5852 & ~rb5838) | (rb5837 & ~rb5853);
  assign rb6009 = (rb5853 & ~rb5837) | (rb5838 & ~rb5852);
  assign rb6010 = (rb5865 & ~rb5851) | (rb5850 & ~rb5866);
  assign rb6011 = (rb5866 & ~rb5850) | (rb5851 & ~rb5865);
  assign rb6012 = (rb5878 & ~rb5864) | (rb5863 & ~rb5879);
  assign rb6013 = (rb5879 & ~rb5863) | (rb5864 & ~rb5878);
  assign rb6014 = (rb5891 & ~rb5877) | (rb5876 & ~rb5892);
  assign rb6015 = (rb5892 & ~rb5876) | (rb5877 & ~rb5891);
  assign rb6016 = (rb5904 & ~rb5890) | (rb5889 & ~rb5905);
  assign rb6017 = (rb5905 & ~rb5889) | (rb5890 & ~rb5904);
  assign rb6018 = (rb5917 & ~rb5903) | (rb5902 & ~rb5918);
  assign rb6019 = (rb5918 & ~rb5902) | (rb5903 & ~rb5917);
  assign rb6020 = (rb5930 & ~rb5916) | (rb5915 & ~rb5931);
  assign rb6021 = (rb5931 & ~rb5915) | (rb5916 & ~rb5930);
  assign rb6022 = (rb5943 & ~rb5929) | (rb5928 & ~rb5944);
  assign rb6023 = (rb5944 & ~rb5928) | (rb5929 & ~rb5943);
  assign rb6024 = (rb5956 & ~rb5942) | (rb5941 & ~rb5957);
  assign rb6025 = (rb5957 & ~rb5941) | (rb5942 & ~rb5956);
  assign rb6026 = (1'b0 & ~rb5955) | (rb5954 & ~1'b0);
  assign rb6027 = (1'b0 & ~rb5954) | (rb5955 & ~1'b0);
  assign rb6028 = rb3403;
  assign rb6029 = rb3404;
  assign rb6030 = rb3914;
  assign rb6031 = rb3915;
  assign rb6032 = rb6028 & rb6030;
  assign rb6033 = rb6029 & rb6031;
  assign rb6034 = (rb6028 & ~rb6030 & ~rb6031) | (rb6030 & ~rb6028 & ~rb6029);
  assign rb6035 = (rb6029 & ~rb6030 & ~rb6031) | (rb6031 & ~rb6028 & ~rb6029);
  assign rb6036 = rb6032 | (rb6034 & ~1'b0);
  assign rb6037 = rb6033 | (rb6035 & 1'b0);
  assign rb6038 = (rb6034 | rb6035) & 1'b0;
  assign rb6039 = (rb6034 | rb6035) & ~1'b0;
  assign rb6040 = rb3405;
  assign rb6041 = rb3406;
  assign rb6042 = rb3916;
  assign rb6043 = rb3917;
  assign rb6044 = rb3404 | rb3915;
  assign rb6045 = rb6040 & rb6042;
  assign rb6046 = rb6041 & rb6043;
  assign rb6047 = (rb6040 & ~rb6042 & ~rb6043) | (rb6042 & ~rb6040 & ~rb6041);
  assign rb6048 = (rb6041 & ~rb6042 & ~rb6043) | (rb6043 & ~rb6040 & ~rb6041);
  assign rb6049 = rb6045 | (rb6047 & ~rb6044);
  assign rb6050 = rb6046 | (rb6048 & rb6044);
  assign rb6051 = (rb6047 | rb6048) & rb6044;
  assign rb6052 = (rb6047 | rb6048) & ~rb6044;
  assign rb6053 = rb3407;
  assign rb6054 = rb3408;
  assign rb6055 = rb3918;
  assign rb6056 = rb3919;
  assign rb6057 = rb3406 | rb3917;
  assign rb6058 = rb6053 & rb6055;
  assign rb6059 = rb6054 & rb6056;
  assign rb6060 = (rb6053 & ~rb6055 & ~rb6056) | (rb6055 & ~rb6053 & ~rb6054);
  assign rb6061 = (rb6054 & ~rb6055 & ~rb6056) | (rb6056 & ~rb6053 & ~rb6054);
  assign rb6062 = rb6058 | (rb6060 & ~rb6057);
  assign rb6063 = rb6059 | (rb6061 & rb6057);
  assign rb6064 = (rb6060 | rb6061) & rb6057;
  assign rb6065 = (rb6060 | rb6061) & ~rb6057;
  assign rb6066 = rb3409;
  assign rb6067 = rb3410;
  assign rb6068 = rb3920;
  assign rb6069 = rb3921;
  assign rb6070 = rb3408 | rb3919;
  assign rb6071 = rb6066 & rb6068;
  assign rb6072 = rb6067 & rb6069;
  assign rb6073 = (rb6066 & ~rb6068 & ~rb6069) | (rb6068 & ~rb6066 & ~rb6067);
  assign rb6074 = (rb6067 & ~rb6068 & ~rb6069) | (rb6069 & ~rb6066 & ~rb6067);
  assign rb6075 = rb6071 | (rb6073 & ~rb6070);
  assign rb6076 = rb6072 | (rb6074 & rb6070);
  assign rb6077 = (rb6073 | rb6074) & rb6070;
  assign rb6078 = (rb6073 | rb6074) & ~rb6070;
  assign rb6079 = rb3411;
  assign rb6080 = rb3412;
  assign rb6081 = rb3922;
  assign rb6082 = rb3923;
  assign rb6083 = rb3410 | rb3921;
  assign rb6084 = rb6079 & rb6081;
  assign rb6085 = rb6080 & rb6082;
  assign rb6086 = (rb6079 & ~rb6081 & ~rb6082) | (rb6081 & ~rb6079 & ~rb6080);
  assign rb6087 = (rb6080 & ~rb6081 & ~rb6082) | (rb6082 & ~rb6079 & ~rb6080);
  assign rb6088 = rb6084 | (rb6086 & ~rb6083);
  assign rb6089 = rb6085 | (rb6087 & rb6083);
  assign rb6090 = (rb6086 | rb6087) & rb6083;
  assign rb6091 = (rb6086 | rb6087) & ~rb6083;
  assign rb6092 = rb3413;
  assign rb6093 = rb3414;
  assign rb6094 = rb3924;
  assign rb6095 = rb3925;
  assign rb6096 = rb3412 | rb3923;
  assign rb6097 = rb6092 & rb6094;
  assign rb6098 = rb6093 & rb6095;
  assign rb6099 = (rb6092 & ~rb6094 & ~rb6095) | (rb6094 & ~rb6092 & ~rb6093);
  assign rb6100 = (rb6093 & ~rb6094 & ~rb6095) | (rb6095 & ~rb6092 & ~rb6093);
  assign rb6101 = rb6097 | (rb6099 & ~rb6096);
  assign rb6102 = rb6098 | (rb6100 & rb6096);
  assign rb6103 = (rb6099 | rb6100) & rb6096;
  assign rb6104 = (rb6099 | rb6100) & ~rb6096;
  assign rb6105 = rb3415;
  assign rb6106 = rb3416;
  assign rb6107 = rb3926;
  assign rb6108 = rb3927;
  assign rb6109 = rb3414 | rb3925;
  assign rb6110 = rb6105 & rb6107;
  assign rb6111 = rb6106 & rb6108;
  assign rb6112 = (rb6105 & ~rb6107 & ~rb6108) | (rb6107 & ~rb6105 & ~rb6106);
  assign rb6113 = (rb6106 & ~rb6107 & ~rb6108) | (rb6108 & ~rb6105 & ~rb6106);
  assign rb6114 = rb6110 | (rb6112 & ~rb6109);
  assign rb6115 = rb6111 | (rb6113 & rb6109);
  assign rb6116 = (rb6112 | rb6113) & rb6109;
  assign rb6117 = (rb6112 | rb6113) & ~rb6109;
  assign rb6118 = rb3417;
  assign rb6119 = rb3418;
  assign rb6120 = rb3928;
  assign rb6121 = rb3929;
  assign rb6122 = rb3416 | rb3927;
  assign rb6123 = rb6118 & rb6120;
  assign rb6124 = rb6119 & rb6121;
  assign rb6125 = (rb6118 & ~rb6120 & ~rb6121) | (rb6120 & ~rb6118 & ~rb6119);
  assign rb6126 = (rb6119 & ~rb6120 & ~rb6121) | (rb6121 & ~rb6118 & ~rb6119);
  assign rb6127 = rb6123 | (rb6125 & ~rb6122);
  assign rb6128 = rb6124 | (rb6126 & rb6122);
  assign rb6129 = (rb6125 | rb6126) & rb6122;
  assign rb6130 = (rb6125 | rb6126) & ~rb6122;
  assign rb6131 = rb3419;
  assign rb6132 = rb3420;
  assign rb6133 = rb3930;
  assign rb6134 = rb3931;
  assign rb6135 = rb3418 | rb3929;
  assign rb6136 = rb6131 & rb6133;
  assign rb6137 = rb6132 & rb6134;
  assign rb6138 = (rb6131 & ~rb6133 & ~rb6134) | (rb6133 & ~rb6131 & ~rb6132);
  assign rb6139 = (rb6132 & ~rb6133 & ~rb6134) | (rb6134 & ~rb6131 & ~rb6132);
  assign rb6140 = rb6136 | (rb6138 & ~rb6135);
  assign rb6141 = rb6137 | (rb6139 & rb6135);
  assign rb6142 = (rb6138 | rb6139) & rb6135;
  assign rb6143 = (rb6138 | rb6139) & ~rb6135;
  assign rb6144 = rb3421;
  assign rb6145 = rb3422;
  assign rb6146 = rb3932;
  assign rb6147 = rb3933;
  assign rb6148 = rb3420 | rb3931;
  assign rb6149 = rb6144 & rb6146;
  assign rb6150 = rb6145 & rb6147;
  assign rb6151 = (rb6144 & ~rb6146 & ~rb6147) | (rb6146 & ~rb6144 & ~rb6145);
  assign rb6152 = (rb6145 & ~rb6146 & ~rb6147) | (rb6147 & ~rb6144 & ~rb6145);
  assign rb6153 = rb6149 | (rb6151 & ~rb6148);
  assign rb6154 = rb6150 | (rb6152 & rb6148);
  assign rb6155 = (rb6151 | rb6152) & rb6148;
  assign rb6156 = (rb6151 | rb6152) & ~rb6148;
  assign rb6157 = rb3423;
  assign rb6158 = rb3424;
  assign rb6159 = rb3934;
  assign rb6160 = rb3935;
  assign rb6161 = rb3422 | rb3933;
  assign rb6162 = rb6157 & rb6159;
  assign rb6163 = rb6158 & rb6160;
  assign rb6164 = (rb6157 & ~rb6159 & ~rb6160) | (rb6159 & ~rb6157 & ~rb6158);
  assign rb6165 = (rb6158 & ~rb6159 & ~rb6160) | (rb6160 & ~rb6157 & ~rb6158);
  assign rb6166 = rb6162 | (rb6164 & ~rb6161);
  assign rb6167 = rb6163 | (rb6165 & rb6161);
  assign rb6168 = (rb6164 | rb6165) & rb6161;
  assign rb6169 = (rb6164 | rb6165) & ~rb6161;
  assign rb6170 = rb3425;
  assign rb6171 = rb3426;
  assign rb6172 = rb3936;
  assign rb6173 = rb3937;
  assign rb6174 = rb3424 | rb3935;
  assign rb6175 = rb6170 & rb6172;
  assign rb6176 = rb6171 & rb6173;
  assign rb6177 = (rb6170 & ~rb6172 & ~rb6173) | (rb6172 & ~rb6170 & ~rb6171);
  assign rb6178 = (rb6171 & ~rb6172 & ~rb6173) | (rb6173 & ~rb6170 & ~rb6171);
  assign rb6179 = rb6175 | (rb6177 & ~rb6174);
  assign rb6180 = rb6176 | (rb6178 & rb6174);
  assign rb6181 = (rb6177 | rb6178) & rb6174;
  assign rb6182 = (rb6177 | rb6178) & ~rb6174;
  assign rb6183 = rb3427;
  assign rb6184 = rb3428;
  assign rb6185 = rb3938;
  assign rb6186 = rb3939;
  assign rb6187 = rb3426 | rb3937;
  assign rb6188 = rb6183 & rb6185;
  assign rb6189 = rb6184 & rb6186;
  assign rb6190 = (rb6183 & ~rb6185 & ~rb6186) | (rb6185 & ~rb6183 & ~rb6184);
  assign rb6191 = (rb6184 & ~rb6185 & ~rb6186) | (rb6186 & ~rb6183 & ~rb6184);
  assign rb6192 = rb6188 | (rb6190 & ~rb6187);
  assign rb6193 = rb6189 | (rb6191 & rb6187);
  assign rb6194 = (rb6190 | rb6191) & rb6187;
  assign rb6195 = (rb6190 | rb6191) & ~rb6187;
  assign rb6196 = rb3429;
  assign rb6197 = rb3430;
  assign rb6198 = rb3940;
  assign rb6199 = rb3941;
  assign rb6200 = rb3428 | rb3939;
  assign rb6201 = rb6196 & rb6198;
  assign rb6202 = rb6197 & rb6199;
  assign rb6203 = (rb6196 & ~rb6198 & ~rb6199) | (rb6198 & ~rb6196 & ~rb6197);
  assign rb6204 = (rb6197 & ~rb6198 & ~rb6199) | (rb6199 & ~rb6196 & ~rb6197);
  assign rb6205 = rb6201 | (rb6203 & ~rb6200);
  assign rb6206 = rb6202 | (rb6204 & rb6200);
  assign rb6207 = (rb6203 | rb6204) & rb6200;
  assign rb6208 = (rb6203 | rb6204) & ~rb6200;
  assign rb6209 = rb3431;
  assign rb6210 = rb3432;
  assign rb6211 = rb3942;
  assign rb6212 = rb3943;
  assign rb6213 = rb3430 | rb3941;
  assign rb6214 = rb6209 & rb6211;
  assign rb6215 = rb6210 & rb6212;
  assign rb6216 = (rb6209 & ~rb6211 & ~rb6212) | (rb6211 & ~rb6209 & ~rb6210);
  assign rb6217 = (rb6210 & ~rb6211 & ~rb6212) | (rb6212 & ~rb6209 & ~rb6210);
  assign rb6218 = rb6214 | (rb6216 & ~rb6213);
  assign rb6219 = rb6215 | (rb6217 & rb6213);
  assign rb6220 = (rb6216 | rb6217) & rb6213;
  assign rb6221 = (rb6216 | rb6217) & ~rb6213;
  assign rb6222 = rb3433;
  assign rb6223 = rb3434;
  assign rb6224 = rb3944;
  assign rb6225 = rb3945;
  assign rb6226 = rb3432 | rb3943;
  assign rb6227 = rb6222 & rb6224;
  assign rb6228 = rb6223 & rb6225;
  assign rb6229 = (rb6222 & ~rb6224 & ~rb6225) | (rb6224 & ~rb6222 & ~rb6223);
  assign rb6230 = (rb6223 & ~rb6224 & ~rb6225) | (rb6225 & ~rb6222 & ~rb6223);
  assign rb6231 = rb6227 | (rb6229 & ~rb6226);
  assign rb6232 = rb6228 | (rb6230 & rb6226);
  assign rb6233 = (rb6229 | rb6230) & rb6226;
  assign rb6234 = (rb6229 | rb6230) & ~rb6226;
  assign rb6235 = rb3435;
  assign rb6236 = rb3436;
  assign rb6237 = rb3946;
  assign rb6238 = rb3947;
  assign rb6239 = rb3434 | rb3945;
  assign rb6240 = rb6235 & rb6237;
  assign rb6241 = rb6236 & rb6238;
  assign rb6242 = (rb6235 & ~rb6237 & ~rb6238) | (rb6237 & ~rb6235 & ~rb6236);
  assign rb6243 = (rb6236 & ~rb6237 & ~rb6238) | (rb6238 & ~rb6235 & ~rb6236);
  assign rb6244 = rb6240 | (rb6242 & ~rb6239);
  assign rb6245 = rb6241 | (rb6243 & rb6239);
  assign rb6246 = (rb6242 | rb6243) & rb6239;
  assign rb6247 = (rb6242 | rb6243) & ~rb6239;
  assign rb6248 = rb3437;
  assign rb6249 = rb3438;
  assign rb6250 = rb3948;
  assign rb6251 = rb3949;
  assign rb6252 = rb3436 | rb3947;
  assign rb6253 = rb6248 & rb6250;
  assign rb6254 = rb6249 & rb6251;
  assign rb6255 = (rb6248 & ~rb6250 & ~rb6251) | (rb6250 & ~rb6248 & ~rb6249);
  assign rb6256 = (rb6249 & ~rb6250 & ~rb6251) | (rb6251 & ~rb6248 & ~rb6249);
  assign rb6257 = rb6253 | (rb6255 & ~rb6252);
  assign rb6258 = rb6254 | (rb6256 & rb6252);
  assign rb6259 = (rb6255 | rb6256) & rb6252;
  assign rb6260 = (rb6255 | rb6256) & ~rb6252;
  assign rb6261 = rb3439;
  assign rb6262 = rb3440;
  assign rb6263 = rb3950;
  assign rb6264 = rb3951;
  assign rb6265 = rb3438 | rb3949;
  assign rb6266 = rb6261 & rb6263;
  assign rb6267 = rb6262 & rb6264;
  assign rb6268 = (rb6261 & ~rb6263 & ~rb6264) | (rb6263 & ~rb6261 & ~rb6262);
  assign rb6269 = (rb6262 & ~rb6263 & ~rb6264) | (rb6264 & ~rb6261 & ~rb6262);
  assign rb6270 = rb6266 | (rb6268 & ~rb6265);
  assign rb6271 = rb6267 | (rb6269 & rb6265);
  assign rb6272 = (rb6268 | rb6269) & rb6265;
  assign rb6273 = (rb6268 | rb6269) & ~rb6265;
  assign rb6274 = rb3441;
  assign rb6275 = rb3442;
  assign rb6276 = rb3952;
  assign rb6277 = rb3953;
  assign rb6278 = rb3440 | rb3951;
  assign rb6279 = rb6274 & rb6276;
  assign rb6280 = rb6275 & rb6277;
  assign rb6281 = (rb6274 & ~rb6276 & ~rb6277) | (rb6276 & ~rb6274 & ~rb6275);
  assign rb6282 = (rb6275 & ~rb6276 & ~rb6277) | (rb6277 & ~rb6274 & ~rb6275);
  assign rb6283 = rb6279 | (rb6281 & ~rb6278);
  assign rb6284 = rb6280 | (rb6282 & rb6278);
  assign rb6285 = (rb6281 | rb6282) & rb6278;
  assign rb6286 = (rb6281 | rb6282) & ~rb6278;
  assign rb6287 = rb3443;
  assign rb6288 = rb3444;
  assign rb6289 = rb3954;
  assign rb6290 = rb3955;
  assign rb6291 = rb3442 | rb3953;
  assign rb6292 = rb6287 & rb6289;
  assign rb6293 = rb6288 & rb6290;
  assign rb6294 = (rb6287 & ~rb6289 & ~rb6290) | (rb6289 & ~rb6287 & ~rb6288);
  assign rb6295 = (rb6288 & ~rb6289 & ~rb6290) | (rb6290 & ~rb6287 & ~rb6288);
  assign rb6296 = rb6292 | (rb6294 & ~rb6291);
  assign rb6297 = rb6293 | (rb6295 & rb6291);
  assign rb6298 = (rb6294 | rb6295) & rb6291;
  assign rb6299 = (rb6294 | rb6295) & ~rb6291;
  assign rb6300 = rb3445;
  assign rb6301 = rb3446;
  assign rb6302 = rb3956;
  assign rb6303 = rb3957;
  assign rb6304 = rb3444 | rb3955;
  assign rb6305 = rb6300 & rb6302;
  assign rb6306 = rb6301 & rb6303;
  assign rb6307 = (rb6300 & ~rb6302 & ~rb6303) | (rb6302 & ~rb6300 & ~rb6301);
  assign rb6308 = (rb6301 & ~rb6302 & ~rb6303) | (rb6303 & ~rb6300 & ~rb6301);
  assign rb6309 = rb6305 | (rb6307 & ~rb6304);
  assign rb6310 = rb6306 | (rb6308 & rb6304);
  assign rb6311 = (rb6307 | rb6308) & rb6304;
  assign rb6312 = (rb6307 | rb6308) & ~rb6304;
  assign rb6313 = rb3447;
  assign rb6314 = rb3448;
  assign rb6315 = rb3958;
  assign rb6316 = rb3959;
  assign rb6317 = rb3446 | rb3957;
  assign rb6318 = rb6313 & rb6315;
  assign rb6319 = rb6314 & rb6316;
  assign rb6320 = (rb6313 & ~rb6315 & ~rb6316) | (rb6315 & ~rb6313 & ~rb6314);
  assign rb6321 = (rb6314 & ~rb6315 & ~rb6316) | (rb6316 & ~rb6313 & ~rb6314);
  assign rb6322 = rb6318 | (rb6320 & ~rb6317);
  assign rb6323 = rb6319 | (rb6321 & rb6317);
  assign rb6324 = (rb6320 | rb6321) & rb6317;
  assign rb6325 = (rb6320 | rb6321) & ~rb6317;
  assign rb6326 = rb3449;
  assign rb6327 = rb3450;
  assign rb6328 = rb3960;
  assign rb6329 = rb3961;
  assign rb6330 = rb3448 | rb3959;
  assign rb6331 = rb6326 & rb6328;
  assign rb6332 = rb6327 & rb6329;
  assign rb6333 = (rb6326 & ~rb6328 & ~rb6329) | (rb6328 & ~rb6326 & ~rb6327);
  assign rb6334 = (rb6327 & ~rb6328 & ~rb6329) | (rb6329 & ~rb6326 & ~rb6327);
  assign rb6335 = rb6331 | (rb6333 & ~rb6330);
  assign rb6336 = rb6332 | (rb6334 & rb6330);
  assign rb6337 = (rb6333 | rb6334) & rb6330;
  assign rb6338 = (rb6333 | rb6334) & ~rb6330;
  assign rb6339 = rb3451;
  assign rb6340 = rb3452;
  assign rb6341 = rb3962;
  assign rb6342 = rb3963;
  assign rb6343 = rb3450 | rb3961;
  assign rb6344 = rb6339 & rb6341;
  assign rb6345 = rb6340 & rb6342;
  assign rb6346 = (rb6339 & ~rb6341 & ~rb6342) | (rb6341 & ~rb6339 & ~rb6340);
  assign rb6347 = (rb6340 & ~rb6341 & ~rb6342) | (rb6342 & ~rb6339 & ~rb6340);
  assign rb6348 = rb6344 | (rb6346 & ~rb6343);
  assign rb6349 = rb6345 | (rb6347 & rb6343);
  assign rb6350 = (rb6346 | rb6347) & rb6343;
  assign rb6351 = (rb6346 | rb6347) & ~rb6343;
  assign rb6352 = rb3453;
  assign rb6353 = rb3454;
  assign rb6354 = rb3964;
  assign rb6355 = rb3965;
  assign rb6356 = rb3452 | rb3963;
  assign rb6357 = rb6352 & rb6354;
  assign rb6358 = rb6353 & rb6355;
  assign rb6359 = (rb6352 & ~rb6354 & ~rb6355) | (rb6354 & ~rb6352 & ~rb6353);
  assign rb6360 = (rb6353 & ~rb6354 & ~rb6355) | (rb6355 & ~rb6352 & ~rb6353);
  assign rb6361 = rb6357 | (rb6359 & ~rb6356);
  assign rb6362 = rb6358 | (rb6360 & rb6356);
  assign rb6363 = (rb6359 | rb6360) & rb6356;
  assign rb6364 = (rb6359 | rb6360) & ~rb6356;
  assign rb6365 = rb3455;
  assign rb6366 = rb3456;
  assign rb6367 = rb3966;
  assign rb6368 = rb3967;
  assign rb6369 = rb3454 | rb3965;
  assign rb6370 = rb6365 & rb6367;
  assign rb6371 = rb6366 & rb6368;
  assign rb6372 = (rb6365 & ~rb6367 & ~rb6368) | (rb6367 & ~rb6365 & ~rb6366);
  assign rb6373 = (rb6366 & ~rb6367 & ~rb6368) | (rb6368 & ~rb6365 & ~rb6366);
  assign rb6374 = rb6370 | (rb6372 & ~rb6369);
  assign rb6375 = rb6371 | (rb6373 & rb6369);
  assign rb6376 = (rb6372 | rb6373) & rb6369;
  assign rb6377 = (rb6372 | rb6373) & ~rb6369;
  assign rb6378 = rb3457;
  assign rb6379 = rb3458;
  assign rb6380 = rb3968;
  assign rb6381 = rb3969;
  assign rb6382 = rb3456 | rb3967;
  assign rb6383 = rb6378 & rb6380;
  assign rb6384 = rb6379 & rb6381;
  assign rb6385 = (rb6378 & ~rb6380 & ~rb6381) | (rb6380 & ~rb6378 & ~rb6379);
  assign rb6386 = (rb6379 & ~rb6380 & ~rb6381) | (rb6381 & ~rb6378 & ~rb6379);
  assign rb6387 = rb6383 | (rb6385 & ~rb6382);
  assign rb6388 = rb6384 | (rb6386 & rb6382);
  assign rb6389 = (rb6385 | rb6386) & rb6382;
  assign rb6390 = (rb6385 | rb6386) & ~rb6382;
  assign rb6391 = rb3459;
  assign rb6392 = rb3460;
  assign rb6393 = rb3970;
  assign rb6394 = rb3971;
  assign rb6395 = rb3458 | rb3969;
  assign rb6396 = rb6391 & rb6393;
  assign rb6397 = rb6392 & rb6394;
  assign rb6398 = (rb6391 & ~rb6393 & ~rb6394) | (rb6393 & ~rb6391 & ~rb6392);
  assign rb6399 = (rb6392 & ~rb6393 & ~rb6394) | (rb6394 & ~rb6391 & ~rb6392);
  assign rb6400 = rb6396 | (rb6398 & ~rb6395);
  assign rb6401 = rb6397 | (rb6399 & rb6395);
  assign rb6402 = (rb6398 | rb6399) & rb6395;
  assign rb6403 = (rb6398 | rb6399) & ~rb6395;
  assign rb6404 = rb3461;
  assign rb6405 = rb3462;
  assign rb6406 = rb3972;
  assign rb6407 = rb3973;
  assign rb6408 = rb3460 | rb3971;
  assign rb6409 = rb6404 & rb6406;
  assign rb6410 = rb6405 & rb6407;
  assign rb6411 = (rb6404 & ~rb6406 & ~rb6407) | (rb6406 & ~rb6404 & ~rb6405);
  assign rb6412 = (rb6405 & ~rb6406 & ~rb6407) | (rb6407 & ~rb6404 & ~rb6405);
  assign rb6413 = rb6409 | (rb6411 & ~rb6408);
  assign rb6414 = rb6410 | (rb6412 & rb6408);
  assign rb6415 = (rb6411 | rb6412) & rb6408;
  assign rb6416 = (rb6411 | rb6412) & ~rb6408;
  assign rb6417 = rb3463;
  assign rb6418 = rb3464;
  assign rb6419 = rb3974;
  assign rb6420 = rb3975;
  assign rb6421 = rb3462 | rb3973;
  assign rb6422 = rb6417 & rb6419;
  assign rb6423 = rb6418 & rb6420;
  assign rb6424 = (rb6417 & ~rb6419 & ~rb6420) | (rb6419 & ~rb6417 & ~rb6418);
  assign rb6425 = (rb6418 & ~rb6419 & ~rb6420) | (rb6420 & ~rb6417 & ~rb6418);
  assign rb6426 = rb6422 | (rb6424 & ~rb6421);
  assign rb6427 = rb6423 | (rb6425 & rb6421);
  assign rb6428 = (rb6424 | rb6425) & rb6421;
  assign rb6429 = (rb6424 | rb6425) & ~rb6421;
  assign rb6430 = rb3465;
  assign rb6431 = rb3466;
  assign rb6432 = rb3976;
  assign rb6433 = rb3977;
  assign rb6434 = rb3464 | rb3975;
  assign rb6435 = rb6430 & rb6432;
  assign rb6436 = rb6431 & rb6433;
  assign rb6437 = (rb6430 & ~rb6432 & ~rb6433) | (rb6432 & ~rb6430 & ~rb6431);
  assign rb6438 = (rb6431 & ~rb6432 & ~rb6433) | (rb6433 & ~rb6430 & ~rb6431);
  assign rb6439 = rb6435 | (rb6437 & ~rb6434);
  assign rb6440 = rb6436 | (rb6438 & rb6434);
  assign rb6441 = (rb6437 | rb6438) & rb6434;
  assign rb6442 = (rb6437 | rb6438) & ~rb6434;
  assign rb6443 = rb3467;
  assign rb6444 = rb3468;
  assign rb6445 = rb3978;
  assign rb6446 = rb3979;
  assign rb6447 = rb3466 | rb3977;
  assign rb6448 = rb6443 & rb6445;
  assign rb6449 = rb6444 & rb6446;
  assign rb6450 = (rb6443 & ~rb6445 & ~rb6446) | (rb6445 & ~rb6443 & ~rb6444);
  assign rb6451 = (rb6444 & ~rb6445 & ~rb6446) | (rb6446 & ~rb6443 & ~rb6444);
  assign rb6452 = rb6448 | (rb6450 & ~rb6447);
  assign rb6453 = rb6449 | (rb6451 & rb6447);
  assign rb6454 = (rb6450 | rb6451) & rb6447;
  assign rb6455 = (rb6450 | rb6451) & ~rb6447;
  assign rb6456 = rb3469;
  assign rb6457 = rb3470;
  assign rb6458 = rb3980;
  assign rb6459 = rb3981;
  assign rb6460 = rb3468 | rb3979;
  assign rb6461 = rb6456 & rb6458;
  assign rb6462 = rb6457 & rb6459;
  assign rb6463 = (rb6456 & ~rb6458 & ~rb6459) | (rb6458 & ~rb6456 & ~rb6457);
  assign rb6464 = (rb6457 & ~rb6458 & ~rb6459) | (rb6459 & ~rb6456 & ~rb6457);
  assign rb6465 = rb6461 | (rb6463 & ~rb6460);
  assign rb6466 = rb6462 | (rb6464 & rb6460);
  assign rb6467 = (rb6463 | rb6464) & rb6460;
  assign rb6468 = (rb6463 | rb6464) & ~rb6460;
  assign rb6469 = (rb6038 & ~1'b0) | (1'b0 & ~rb6039);
  assign rb6470 = (rb6039 & ~1'b0) | (1'b0 & ~rb6038);
  assign rb6471 = (rb6051 & ~rb6037) | (rb6036 & ~rb6052);
  assign rb6472 = (rb6052 & ~rb6036) | (rb6037 & ~rb6051);
  assign rb6473 = (rb6064 & ~rb6050) | (rb6049 & ~rb6065);
  assign rb6474 = (rb6065 & ~rb6049) | (rb6050 & ~rb6064);
  assign rb6475 = (rb6077 & ~rb6063) | (rb6062 & ~rb6078);
  assign rb6476 = (rb6078 & ~rb6062) | (rb6063 & ~rb6077);
  assign rb6477 = (rb6090 & ~rb6076) | (rb6075 & ~rb6091);
  assign rb6478 = (rb6091 & ~rb6075) | (rb6076 & ~rb6090);
  assign rb6479 = (rb6103 & ~rb6089) | (rb6088 & ~rb6104);
  assign rb6480 = (rb6104 & ~rb6088) | (rb6089 & ~rb6103);
  assign rb6481 = (rb6116 & ~rb6102) | (rb6101 & ~rb6117);
  assign rb6482 = (rb6117 & ~rb6101) | (rb6102 & ~rb6116);
  assign rb6483 = (rb6129 & ~rb6115) | (rb6114 & ~rb6130);
  assign rb6484 = (rb6130 & ~rb6114) | (rb6115 & ~rb6129);
  assign rb6485 = (rb6142 & ~rb6128) | (rb6127 & ~rb6143);
  assign rb6486 = (rb6143 & ~rb6127) | (rb6128 & ~rb6142);
  assign rb6487 = (rb6155 & ~rb6141) | (rb6140 & ~rb6156);
  assign rb6488 = (rb6156 & ~rb6140) | (rb6141 & ~rb6155);
  assign rb6489 = (rb6168 & ~rb6154) | (rb6153 & ~rb6169);
  assign rb6490 = (rb6169 & ~rb6153) | (rb6154 & ~rb6168);
  assign rb6491 = (rb6181 & ~rb6167) | (rb6166 & ~rb6182);
  assign rb6492 = (rb6182 & ~rb6166) | (rb6167 & ~rb6181);
  assign rb6493 = (rb6194 & ~rb6180) | (rb6179 & ~rb6195);
  assign rb6494 = (rb6195 & ~rb6179) | (rb6180 & ~rb6194);
  assign rb6495 = (rb6207 & ~rb6193) | (rb6192 & ~rb6208);
  assign rb6496 = (rb6208 & ~rb6192) | (rb6193 & ~rb6207);
  assign rb6497 = (rb6220 & ~rb6206) | (rb6205 & ~rb6221);
  assign rb6498 = (rb6221 & ~rb6205) | (rb6206 & ~rb6220);
  assign rb6499 = (rb6233 & ~rb6219) | (rb6218 & ~rb6234);
  assign rb6500 = (rb6234 & ~rb6218) | (rb6219 & ~rb6233);
  assign rb6501 = (rb6246 & ~rb6232) | (rb6231 & ~rb6247);
  assign rb6502 = (rb6247 & ~rb6231) | (rb6232 & ~rb6246);
  assign rb6503 = (rb6259 & ~rb6245) | (rb6244 & ~rb6260);
  assign rb6504 = (rb6260 & ~rb6244) | (rb6245 & ~rb6259);
  assign rb6505 = (rb6272 & ~rb6258) | (rb6257 & ~rb6273);
  assign rb6506 = (rb6273 & ~rb6257) | (rb6258 & ~rb6272);
  assign rb6507 = (rb6285 & ~rb6271) | (rb6270 & ~rb6286);
  assign rb6508 = (rb6286 & ~rb6270) | (rb6271 & ~rb6285);
  assign rb6509 = (rb6298 & ~rb6284) | (rb6283 & ~rb6299);
  assign rb6510 = (rb6299 & ~rb6283) | (rb6284 & ~rb6298);
  assign rb6511 = (rb6311 & ~rb6297) | (rb6296 & ~rb6312);
  assign rb6512 = (rb6312 & ~rb6296) | (rb6297 & ~rb6311);
  assign rb6513 = (rb6324 & ~rb6310) | (rb6309 & ~rb6325);
  assign rb6514 = (rb6325 & ~rb6309) | (rb6310 & ~rb6324);
  assign rb6515 = (rb6337 & ~rb6323) | (rb6322 & ~rb6338);
  assign rb6516 = (rb6338 & ~rb6322) | (rb6323 & ~rb6337);
  assign rb6517 = (rb6350 & ~rb6336) | (rb6335 & ~rb6351);
  assign rb6518 = (rb6351 & ~rb6335) | (rb6336 & ~rb6350);
  assign rb6519 = (rb6363 & ~rb6349) | (rb6348 & ~rb6364);
  assign rb6520 = (rb6364 & ~rb6348) | (rb6349 & ~rb6363);
  assign rb6521 = (rb6376 & ~rb6362) | (rb6361 & ~rb6377);
  assign rb6522 = (rb6377 & ~rb6361) | (rb6362 & ~rb6376);
  assign rb6523 = (rb6389 & ~rb6375) | (rb6374 & ~rb6390);
  assign rb6524 = (rb6390 & ~rb6374) | (rb6375 & ~rb6389);
  assign rb6525 = (rb6402 & ~rb6388) | (rb6387 & ~rb6403);
  assign rb6526 = (rb6403 & ~rb6387) | (rb6388 & ~rb6402);
  assign rb6527 = (rb6415 & ~rb6401) | (rb6400 & ~rb6416);
  assign rb6528 = (rb6416 & ~rb6400) | (rb6401 & ~rb6415);
  assign rb6529 = (rb6428 & ~rb6414) | (rb6413 & ~rb6429);
  assign rb6530 = (rb6429 & ~rb6413) | (rb6414 & ~rb6428);
  assign rb6531 = (rb6441 & ~rb6427) | (rb6426 & ~rb6442);
  assign rb6532 = (rb6442 & ~rb6426) | (rb6427 & ~rb6441);
  assign rb6533 = (rb6454 & ~rb6440) | (rb6439 & ~rb6455);
  assign rb6534 = (rb6455 & ~rb6439) | (rb6440 & ~rb6454);
  assign rb6535 = (rb6467 & ~rb6453) | (rb6452 & ~rb6468);
  assign rb6536 = (rb6468 & ~rb6452) | (rb6453 & ~rb6467);
  assign rb6537 = (1'b0 & ~rb6466) | (rb6465 & ~1'b0);
  assign rb6538 = (1'b0 & ~rb6465) | (rb6466 & ~1'b0);
  assign rb6539 = rb4425;
  assign rb6540 = rb4426;
  assign rb6541 = rb4936;
  assign rb6542 = rb4937;
  assign rb6543 = rb6539 & rb6541;
  assign rb6544 = rb6540 & rb6542;
  assign rb6545 = (rb6539 & ~rb6541 & ~rb6542) | (rb6541 & ~rb6539 & ~rb6540);
  assign rb6546 = (rb6540 & ~rb6541 & ~rb6542) | (rb6542 & ~rb6539 & ~rb6540);
  assign rb6547 = rb6543 | (rb6545 & ~1'b0);
  assign rb6548 = rb6544 | (rb6546 & 1'b0);
  assign rb6549 = (rb6545 | rb6546) & 1'b0;
  assign rb6550 = (rb6545 | rb6546) & ~1'b0;
  assign rb6551 = rb4427;
  assign rb6552 = rb4428;
  assign rb6553 = rb4938;
  assign rb6554 = rb4939;
  assign rb6555 = rb4426 | rb4937;
  assign rb6556 = rb6551 & rb6553;
  assign rb6557 = rb6552 & rb6554;
  assign rb6558 = (rb6551 & ~rb6553 & ~rb6554) | (rb6553 & ~rb6551 & ~rb6552);
  assign rb6559 = (rb6552 & ~rb6553 & ~rb6554) | (rb6554 & ~rb6551 & ~rb6552);
  assign rb6560 = rb6556 | (rb6558 & ~rb6555);
  assign rb6561 = rb6557 | (rb6559 & rb6555);
  assign rb6562 = (rb6558 | rb6559) & rb6555;
  assign rb6563 = (rb6558 | rb6559) & ~rb6555;
  assign rb6564 = rb4429;
  assign rb6565 = rb4430;
  assign rb6566 = rb4940;
  assign rb6567 = rb4941;
  assign rb6568 = rb4428 | rb4939;
  assign rb6569 = rb6564 & rb6566;
  assign rb6570 = rb6565 & rb6567;
  assign rb6571 = (rb6564 & ~rb6566 & ~rb6567) | (rb6566 & ~rb6564 & ~rb6565);
  assign rb6572 = (rb6565 & ~rb6566 & ~rb6567) | (rb6567 & ~rb6564 & ~rb6565);
  assign rb6573 = rb6569 | (rb6571 & ~rb6568);
  assign rb6574 = rb6570 | (rb6572 & rb6568);
  assign rb6575 = (rb6571 | rb6572) & rb6568;
  assign rb6576 = (rb6571 | rb6572) & ~rb6568;
  assign rb6577 = rb4431;
  assign rb6578 = rb4432;
  assign rb6579 = rb4942;
  assign rb6580 = rb4943;
  assign rb6581 = rb4430 | rb4941;
  assign rb6582 = rb6577 & rb6579;
  assign rb6583 = rb6578 & rb6580;
  assign rb6584 = (rb6577 & ~rb6579 & ~rb6580) | (rb6579 & ~rb6577 & ~rb6578);
  assign rb6585 = (rb6578 & ~rb6579 & ~rb6580) | (rb6580 & ~rb6577 & ~rb6578);
  assign rb6586 = rb6582 | (rb6584 & ~rb6581);
  assign rb6587 = rb6583 | (rb6585 & rb6581);
  assign rb6588 = (rb6584 | rb6585) & rb6581;
  assign rb6589 = (rb6584 | rb6585) & ~rb6581;
  assign rb6590 = rb4433;
  assign rb6591 = rb4434;
  assign rb6592 = rb4944;
  assign rb6593 = rb4945;
  assign rb6594 = rb4432 | rb4943;
  assign rb6595 = rb6590 & rb6592;
  assign rb6596 = rb6591 & rb6593;
  assign rb6597 = (rb6590 & ~rb6592 & ~rb6593) | (rb6592 & ~rb6590 & ~rb6591);
  assign rb6598 = (rb6591 & ~rb6592 & ~rb6593) | (rb6593 & ~rb6590 & ~rb6591);
  assign rb6599 = rb6595 | (rb6597 & ~rb6594);
  assign rb6600 = rb6596 | (rb6598 & rb6594);
  assign rb6601 = (rb6597 | rb6598) & rb6594;
  assign rb6602 = (rb6597 | rb6598) & ~rb6594;
  assign rb6603 = rb4435;
  assign rb6604 = rb4436;
  assign rb6605 = rb4946;
  assign rb6606 = rb4947;
  assign rb6607 = rb4434 | rb4945;
  assign rb6608 = rb6603 & rb6605;
  assign rb6609 = rb6604 & rb6606;
  assign rb6610 = (rb6603 & ~rb6605 & ~rb6606) | (rb6605 & ~rb6603 & ~rb6604);
  assign rb6611 = (rb6604 & ~rb6605 & ~rb6606) | (rb6606 & ~rb6603 & ~rb6604);
  assign rb6612 = rb6608 | (rb6610 & ~rb6607);
  assign rb6613 = rb6609 | (rb6611 & rb6607);
  assign rb6614 = (rb6610 | rb6611) & rb6607;
  assign rb6615 = (rb6610 | rb6611) & ~rb6607;
  assign rb6616 = rb4437;
  assign rb6617 = rb4438;
  assign rb6618 = rb4948;
  assign rb6619 = rb4949;
  assign rb6620 = rb4436 | rb4947;
  assign rb6621 = rb6616 & rb6618;
  assign rb6622 = rb6617 & rb6619;
  assign rb6623 = (rb6616 & ~rb6618 & ~rb6619) | (rb6618 & ~rb6616 & ~rb6617);
  assign rb6624 = (rb6617 & ~rb6618 & ~rb6619) | (rb6619 & ~rb6616 & ~rb6617);
  assign rb6625 = rb6621 | (rb6623 & ~rb6620);
  assign rb6626 = rb6622 | (rb6624 & rb6620);
  assign rb6627 = (rb6623 | rb6624) & rb6620;
  assign rb6628 = (rb6623 | rb6624) & ~rb6620;
  assign rb6629 = rb4439;
  assign rb6630 = rb4440;
  assign rb6631 = rb4950;
  assign rb6632 = rb4951;
  assign rb6633 = rb4438 | rb4949;
  assign rb6634 = rb6629 & rb6631;
  assign rb6635 = rb6630 & rb6632;
  assign rb6636 = (rb6629 & ~rb6631 & ~rb6632) | (rb6631 & ~rb6629 & ~rb6630);
  assign rb6637 = (rb6630 & ~rb6631 & ~rb6632) | (rb6632 & ~rb6629 & ~rb6630);
  assign rb6638 = rb6634 | (rb6636 & ~rb6633);
  assign rb6639 = rb6635 | (rb6637 & rb6633);
  assign rb6640 = (rb6636 | rb6637) & rb6633;
  assign rb6641 = (rb6636 | rb6637) & ~rb6633;
  assign rb6642 = rb4441;
  assign rb6643 = rb4442;
  assign rb6644 = rb4952;
  assign rb6645 = rb4953;
  assign rb6646 = rb4440 | rb4951;
  assign rb6647 = rb6642 & rb6644;
  assign rb6648 = rb6643 & rb6645;
  assign rb6649 = (rb6642 & ~rb6644 & ~rb6645) | (rb6644 & ~rb6642 & ~rb6643);
  assign rb6650 = (rb6643 & ~rb6644 & ~rb6645) | (rb6645 & ~rb6642 & ~rb6643);
  assign rb6651 = rb6647 | (rb6649 & ~rb6646);
  assign rb6652 = rb6648 | (rb6650 & rb6646);
  assign rb6653 = (rb6649 | rb6650) & rb6646;
  assign rb6654 = (rb6649 | rb6650) & ~rb6646;
  assign rb6655 = rb4443;
  assign rb6656 = rb4444;
  assign rb6657 = rb4954;
  assign rb6658 = rb4955;
  assign rb6659 = rb4442 | rb4953;
  assign rb6660 = rb6655 & rb6657;
  assign rb6661 = rb6656 & rb6658;
  assign rb6662 = (rb6655 & ~rb6657 & ~rb6658) | (rb6657 & ~rb6655 & ~rb6656);
  assign rb6663 = (rb6656 & ~rb6657 & ~rb6658) | (rb6658 & ~rb6655 & ~rb6656);
  assign rb6664 = rb6660 | (rb6662 & ~rb6659);
  assign rb6665 = rb6661 | (rb6663 & rb6659);
  assign rb6666 = (rb6662 | rb6663) & rb6659;
  assign rb6667 = (rb6662 | rb6663) & ~rb6659;
  assign rb6668 = rb4445;
  assign rb6669 = rb4446;
  assign rb6670 = rb4956;
  assign rb6671 = rb4957;
  assign rb6672 = rb4444 | rb4955;
  assign rb6673 = rb6668 & rb6670;
  assign rb6674 = rb6669 & rb6671;
  assign rb6675 = (rb6668 & ~rb6670 & ~rb6671) | (rb6670 & ~rb6668 & ~rb6669);
  assign rb6676 = (rb6669 & ~rb6670 & ~rb6671) | (rb6671 & ~rb6668 & ~rb6669);
  assign rb6677 = rb6673 | (rb6675 & ~rb6672);
  assign rb6678 = rb6674 | (rb6676 & rb6672);
  assign rb6679 = (rb6675 | rb6676) & rb6672;
  assign rb6680 = (rb6675 | rb6676) & ~rb6672;
  assign rb6681 = rb4447;
  assign rb6682 = rb4448;
  assign rb6683 = rb4958;
  assign rb6684 = rb4959;
  assign rb6685 = rb4446 | rb4957;
  assign rb6686 = rb6681 & rb6683;
  assign rb6687 = rb6682 & rb6684;
  assign rb6688 = (rb6681 & ~rb6683 & ~rb6684) | (rb6683 & ~rb6681 & ~rb6682);
  assign rb6689 = (rb6682 & ~rb6683 & ~rb6684) | (rb6684 & ~rb6681 & ~rb6682);
  assign rb6690 = rb6686 | (rb6688 & ~rb6685);
  assign rb6691 = rb6687 | (rb6689 & rb6685);
  assign rb6692 = (rb6688 | rb6689) & rb6685;
  assign rb6693 = (rb6688 | rb6689) & ~rb6685;
  assign rb6694 = rb4449;
  assign rb6695 = rb4450;
  assign rb6696 = rb4960;
  assign rb6697 = rb4961;
  assign rb6698 = rb4448 | rb4959;
  assign rb6699 = rb6694 & rb6696;
  assign rb6700 = rb6695 & rb6697;
  assign rb6701 = (rb6694 & ~rb6696 & ~rb6697) | (rb6696 & ~rb6694 & ~rb6695);
  assign rb6702 = (rb6695 & ~rb6696 & ~rb6697) | (rb6697 & ~rb6694 & ~rb6695);
  assign rb6703 = rb6699 | (rb6701 & ~rb6698);
  assign rb6704 = rb6700 | (rb6702 & rb6698);
  assign rb6705 = (rb6701 | rb6702) & rb6698;
  assign rb6706 = (rb6701 | rb6702) & ~rb6698;
  assign rb6707 = rb4451;
  assign rb6708 = rb4452;
  assign rb6709 = rb4962;
  assign rb6710 = rb4963;
  assign rb6711 = rb4450 | rb4961;
  assign rb6712 = rb6707 & rb6709;
  assign rb6713 = rb6708 & rb6710;
  assign rb6714 = (rb6707 & ~rb6709 & ~rb6710) | (rb6709 & ~rb6707 & ~rb6708);
  assign rb6715 = (rb6708 & ~rb6709 & ~rb6710) | (rb6710 & ~rb6707 & ~rb6708);
  assign rb6716 = rb6712 | (rb6714 & ~rb6711);
  assign rb6717 = rb6713 | (rb6715 & rb6711);
  assign rb6718 = (rb6714 | rb6715) & rb6711;
  assign rb6719 = (rb6714 | rb6715) & ~rb6711;
  assign rb6720 = rb4453;
  assign rb6721 = rb4454;
  assign rb6722 = rb4964;
  assign rb6723 = rb4965;
  assign rb6724 = rb4452 | rb4963;
  assign rb6725 = rb6720 & rb6722;
  assign rb6726 = rb6721 & rb6723;
  assign rb6727 = (rb6720 & ~rb6722 & ~rb6723) | (rb6722 & ~rb6720 & ~rb6721);
  assign rb6728 = (rb6721 & ~rb6722 & ~rb6723) | (rb6723 & ~rb6720 & ~rb6721);
  assign rb6729 = rb6725 | (rb6727 & ~rb6724);
  assign rb6730 = rb6726 | (rb6728 & rb6724);
  assign rb6731 = (rb6727 | rb6728) & rb6724;
  assign rb6732 = (rb6727 | rb6728) & ~rb6724;
  assign rb6733 = rb4455;
  assign rb6734 = rb4456;
  assign rb6735 = rb4966;
  assign rb6736 = rb4967;
  assign rb6737 = rb4454 | rb4965;
  assign rb6738 = rb6733 & rb6735;
  assign rb6739 = rb6734 & rb6736;
  assign rb6740 = (rb6733 & ~rb6735 & ~rb6736) | (rb6735 & ~rb6733 & ~rb6734);
  assign rb6741 = (rb6734 & ~rb6735 & ~rb6736) | (rb6736 & ~rb6733 & ~rb6734);
  assign rb6742 = rb6738 | (rb6740 & ~rb6737);
  assign rb6743 = rb6739 | (rb6741 & rb6737);
  assign rb6744 = (rb6740 | rb6741) & rb6737;
  assign rb6745 = (rb6740 | rb6741) & ~rb6737;
  assign rb6746 = rb4457;
  assign rb6747 = rb4458;
  assign rb6748 = rb4968;
  assign rb6749 = rb4969;
  assign rb6750 = rb4456 | rb4967;
  assign rb6751 = rb6746 & rb6748;
  assign rb6752 = rb6747 & rb6749;
  assign rb6753 = (rb6746 & ~rb6748 & ~rb6749) | (rb6748 & ~rb6746 & ~rb6747);
  assign rb6754 = (rb6747 & ~rb6748 & ~rb6749) | (rb6749 & ~rb6746 & ~rb6747);
  assign rb6755 = rb6751 | (rb6753 & ~rb6750);
  assign rb6756 = rb6752 | (rb6754 & rb6750);
  assign rb6757 = (rb6753 | rb6754) & rb6750;
  assign rb6758 = (rb6753 | rb6754) & ~rb6750;
  assign rb6759 = rb4459;
  assign rb6760 = rb4460;
  assign rb6761 = rb4970;
  assign rb6762 = rb4971;
  assign rb6763 = rb4458 | rb4969;
  assign rb6764 = rb6759 & rb6761;
  assign rb6765 = rb6760 & rb6762;
  assign rb6766 = (rb6759 & ~rb6761 & ~rb6762) | (rb6761 & ~rb6759 & ~rb6760);
  assign rb6767 = (rb6760 & ~rb6761 & ~rb6762) | (rb6762 & ~rb6759 & ~rb6760);
  assign rb6768 = rb6764 | (rb6766 & ~rb6763);
  assign rb6769 = rb6765 | (rb6767 & rb6763);
  assign rb6770 = (rb6766 | rb6767) & rb6763;
  assign rb6771 = (rb6766 | rb6767) & ~rb6763;
  assign rb6772 = rb4461;
  assign rb6773 = rb4462;
  assign rb6774 = rb4972;
  assign rb6775 = rb4973;
  assign rb6776 = rb4460 | rb4971;
  assign rb6777 = rb6772 & rb6774;
  assign rb6778 = rb6773 & rb6775;
  assign rb6779 = (rb6772 & ~rb6774 & ~rb6775) | (rb6774 & ~rb6772 & ~rb6773);
  assign rb6780 = (rb6773 & ~rb6774 & ~rb6775) | (rb6775 & ~rb6772 & ~rb6773);
  assign rb6781 = rb6777 | (rb6779 & ~rb6776);
  assign rb6782 = rb6778 | (rb6780 & rb6776);
  assign rb6783 = (rb6779 | rb6780) & rb6776;
  assign rb6784 = (rb6779 | rb6780) & ~rb6776;
  assign rb6785 = rb4463;
  assign rb6786 = rb4464;
  assign rb6787 = rb4974;
  assign rb6788 = rb4975;
  assign rb6789 = rb4462 | rb4973;
  assign rb6790 = rb6785 & rb6787;
  assign rb6791 = rb6786 & rb6788;
  assign rb6792 = (rb6785 & ~rb6787 & ~rb6788) | (rb6787 & ~rb6785 & ~rb6786);
  assign rb6793 = (rb6786 & ~rb6787 & ~rb6788) | (rb6788 & ~rb6785 & ~rb6786);
  assign rb6794 = rb6790 | (rb6792 & ~rb6789);
  assign rb6795 = rb6791 | (rb6793 & rb6789);
  assign rb6796 = (rb6792 | rb6793) & rb6789;
  assign rb6797 = (rb6792 | rb6793) & ~rb6789;
  assign rb6798 = rb4465;
  assign rb6799 = rb4466;
  assign rb6800 = rb4976;
  assign rb6801 = rb4977;
  assign rb6802 = rb4464 | rb4975;
  assign rb6803 = rb6798 & rb6800;
  assign rb6804 = rb6799 & rb6801;
  assign rb6805 = (rb6798 & ~rb6800 & ~rb6801) | (rb6800 & ~rb6798 & ~rb6799);
  assign rb6806 = (rb6799 & ~rb6800 & ~rb6801) | (rb6801 & ~rb6798 & ~rb6799);
  assign rb6807 = rb6803 | (rb6805 & ~rb6802);
  assign rb6808 = rb6804 | (rb6806 & rb6802);
  assign rb6809 = (rb6805 | rb6806) & rb6802;
  assign rb6810 = (rb6805 | rb6806) & ~rb6802;
  assign rb6811 = rb4467;
  assign rb6812 = rb4468;
  assign rb6813 = rb4978;
  assign rb6814 = rb4979;
  assign rb6815 = rb4466 | rb4977;
  assign rb6816 = rb6811 & rb6813;
  assign rb6817 = rb6812 & rb6814;
  assign rb6818 = (rb6811 & ~rb6813 & ~rb6814) | (rb6813 & ~rb6811 & ~rb6812);
  assign rb6819 = (rb6812 & ~rb6813 & ~rb6814) | (rb6814 & ~rb6811 & ~rb6812);
  assign rb6820 = rb6816 | (rb6818 & ~rb6815);
  assign rb6821 = rb6817 | (rb6819 & rb6815);
  assign rb6822 = (rb6818 | rb6819) & rb6815;
  assign rb6823 = (rb6818 | rb6819) & ~rb6815;
  assign rb6824 = rb4469;
  assign rb6825 = rb4470;
  assign rb6826 = rb4980;
  assign rb6827 = rb4981;
  assign rb6828 = rb4468 | rb4979;
  assign rb6829 = rb6824 & rb6826;
  assign rb6830 = rb6825 & rb6827;
  assign rb6831 = (rb6824 & ~rb6826 & ~rb6827) | (rb6826 & ~rb6824 & ~rb6825);
  assign rb6832 = (rb6825 & ~rb6826 & ~rb6827) | (rb6827 & ~rb6824 & ~rb6825);
  assign rb6833 = rb6829 | (rb6831 & ~rb6828);
  assign rb6834 = rb6830 | (rb6832 & rb6828);
  assign rb6835 = (rb6831 | rb6832) & rb6828;
  assign rb6836 = (rb6831 | rb6832) & ~rb6828;
  assign rb6837 = rb4471;
  assign rb6838 = rb4472;
  assign rb6839 = rb4982;
  assign rb6840 = rb4983;
  assign rb6841 = rb4470 | rb4981;
  assign rb6842 = rb6837 & rb6839;
  assign rb6843 = rb6838 & rb6840;
  assign rb6844 = (rb6837 & ~rb6839 & ~rb6840) | (rb6839 & ~rb6837 & ~rb6838);
  assign rb6845 = (rb6838 & ~rb6839 & ~rb6840) | (rb6840 & ~rb6837 & ~rb6838);
  assign rb6846 = rb6842 | (rb6844 & ~rb6841);
  assign rb6847 = rb6843 | (rb6845 & rb6841);
  assign rb6848 = (rb6844 | rb6845) & rb6841;
  assign rb6849 = (rb6844 | rb6845) & ~rb6841;
  assign rb6850 = rb4473;
  assign rb6851 = rb4474;
  assign rb6852 = rb4984;
  assign rb6853 = rb4985;
  assign rb6854 = rb4472 | rb4983;
  assign rb6855 = rb6850 & rb6852;
  assign rb6856 = rb6851 & rb6853;
  assign rb6857 = (rb6850 & ~rb6852 & ~rb6853) | (rb6852 & ~rb6850 & ~rb6851);
  assign rb6858 = (rb6851 & ~rb6852 & ~rb6853) | (rb6853 & ~rb6850 & ~rb6851);
  assign rb6859 = rb6855 | (rb6857 & ~rb6854);
  assign rb6860 = rb6856 | (rb6858 & rb6854);
  assign rb6861 = (rb6857 | rb6858) & rb6854;
  assign rb6862 = (rb6857 | rb6858) & ~rb6854;
  assign rb6863 = rb4475;
  assign rb6864 = rb4476;
  assign rb6865 = rb4986;
  assign rb6866 = rb4987;
  assign rb6867 = rb4474 | rb4985;
  assign rb6868 = rb6863 & rb6865;
  assign rb6869 = rb6864 & rb6866;
  assign rb6870 = (rb6863 & ~rb6865 & ~rb6866) | (rb6865 & ~rb6863 & ~rb6864);
  assign rb6871 = (rb6864 & ~rb6865 & ~rb6866) | (rb6866 & ~rb6863 & ~rb6864);
  assign rb6872 = rb6868 | (rb6870 & ~rb6867);
  assign rb6873 = rb6869 | (rb6871 & rb6867);
  assign rb6874 = (rb6870 | rb6871) & rb6867;
  assign rb6875 = (rb6870 | rb6871) & ~rb6867;
  assign rb6876 = rb4477;
  assign rb6877 = rb4478;
  assign rb6878 = rb4988;
  assign rb6879 = rb4989;
  assign rb6880 = rb4476 | rb4987;
  assign rb6881 = rb6876 & rb6878;
  assign rb6882 = rb6877 & rb6879;
  assign rb6883 = (rb6876 & ~rb6878 & ~rb6879) | (rb6878 & ~rb6876 & ~rb6877);
  assign rb6884 = (rb6877 & ~rb6878 & ~rb6879) | (rb6879 & ~rb6876 & ~rb6877);
  assign rb6885 = rb6881 | (rb6883 & ~rb6880);
  assign rb6886 = rb6882 | (rb6884 & rb6880);
  assign rb6887 = (rb6883 | rb6884) & rb6880;
  assign rb6888 = (rb6883 | rb6884) & ~rb6880;
  assign rb6889 = rb4479;
  assign rb6890 = rb4480;
  assign rb6891 = rb4990;
  assign rb6892 = rb4991;
  assign rb6893 = rb4478 | rb4989;
  assign rb6894 = rb6889 & rb6891;
  assign rb6895 = rb6890 & rb6892;
  assign rb6896 = (rb6889 & ~rb6891 & ~rb6892) | (rb6891 & ~rb6889 & ~rb6890);
  assign rb6897 = (rb6890 & ~rb6891 & ~rb6892) | (rb6892 & ~rb6889 & ~rb6890);
  assign rb6898 = rb6894 | (rb6896 & ~rb6893);
  assign rb6899 = rb6895 | (rb6897 & rb6893);
  assign rb6900 = (rb6896 | rb6897) & rb6893;
  assign rb6901 = (rb6896 | rb6897) & ~rb6893;
  assign rb6902 = rb4481;
  assign rb6903 = rb4482;
  assign rb6904 = rb4992;
  assign rb6905 = rb4993;
  assign rb6906 = rb4480 | rb4991;
  assign rb6907 = rb6902 & rb6904;
  assign rb6908 = rb6903 & rb6905;
  assign rb6909 = (rb6902 & ~rb6904 & ~rb6905) | (rb6904 & ~rb6902 & ~rb6903);
  assign rb6910 = (rb6903 & ~rb6904 & ~rb6905) | (rb6905 & ~rb6902 & ~rb6903);
  assign rb6911 = rb6907 | (rb6909 & ~rb6906);
  assign rb6912 = rb6908 | (rb6910 & rb6906);
  assign rb6913 = (rb6909 | rb6910) & rb6906;
  assign rb6914 = (rb6909 | rb6910) & ~rb6906;
  assign rb6915 = rb4483;
  assign rb6916 = rb4484;
  assign rb6917 = rb4994;
  assign rb6918 = rb4995;
  assign rb6919 = rb4482 | rb4993;
  assign rb6920 = rb6915 & rb6917;
  assign rb6921 = rb6916 & rb6918;
  assign rb6922 = (rb6915 & ~rb6917 & ~rb6918) | (rb6917 & ~rb6915 & ~rb6916);
  assign rb6923 = (rb6916 & ~rb6917 & ~rb6918) | (rb6918 & ~rb6915 & ~rb6916);
  assign rb6924 = rb6920 | (rb6922 & ~rb6919);
  assign rb6925 = rb6921 | (rb6923 & rb6919);
  assign rb6926 = (rb6922 | rb6923) & rb6919;
  assign rb6927 = (rb6922 | rb6923) & ~rb6919;
  assign rb6928 = rb4485;
  assign rb6929 = rb4486;
  assign rb6930 = rb4996;
  assign rb6931 = rb4997;
  assign rb6932 = rb4484 | rb4995;
  assign rb6933 = rb6928 & rb6930;
  assign rb6934 = rb6929 & rb6931;
  assign rb6935 = (rb6928 & ~rb6930 & ~rb6931) | (rb6930 & ~rb6928 & ~rb6929);
  assign rb6936 = (rb6929 & ~rb6930 & ~rb6931) | (rb6931 & ~rb6928 & ~rb6929);
  assign rb6937 = rb6933 | (rb6935 & ~rb6932);
  assign rb6938 = rb6934 | (rb6936 & rb6932);
  assign rb6939 = (rb6935 | rb6936) & rb6932;
  assign rb6940 = (rb6935 | rb6936) & ~rb6932;
  assign rb6941 = rb4487;
  assign rb6942 = rb4488;
  assign rb6943 = rb4998;
  assign rb6944 = rb4999;
  assign rb6945 = rb4486 | rb4997;
  assign rb6946 = rb6941 & rb6943;
  assign rb6947 = rb6942 & rb6944;
  assign rb6948 = (rb6941 & ~rb6943 & ~rb6944) | (rb6943 & ~rb6941 & ~rb6942);
  assign rb6949 = (rb6942 & ~rb6943 & ~rb6944) | (rb6944 & ~rb6941 & ~rb6942);
  assign rb6950 = rb6946 | (rb6948 & ~rb6945);
  assign rb6951 = rb6947 | (rb6949 & rb6945);
  assign rb6952 = (rb6948 | rb6949) & rb6945;
  assign rb6953 = (rb6948 | rb6949) & ~rb6945;
  assign rb6954 = rb4489;
  assign rb6955 = rb4490;
  assign rb6956 = rb5000;
  assign rb6957 = rb5001;
  assign rb6958 = rb4488 | rb4999;
  assign rb6959 = rb6954 & rb6956;
  assign rb6960 = rb6955 & rb6957;
  assign rb6961 = (rb6954 & ~rb6956 & ~rb6957) | (rb6956 & ~rb6954 & ~rb6955);
  assign rb6962 = (rb6955 & ~rb6956 & ~rb6957) | (rb6957 & ~rb6954 & ~rb6955);
  assign rb6963 = rb6959 | (rb6961 & ~rb6958);
  assign rb6964 = rb6960 | (rb6962 & rb6958);
  assign rb6965 = (rb6961 | rb6962) & rb6958;
  assign rb6966 = (rb6961 | rb6962) & ~rb6958;
  assign rb6967 = rb4491;
  assign rb6968 = rb4492;
  assign rb6969 = rb5002;
  assign rb6970 = rb5003;
  assign rb6971 = rb4490 | rb5001;
  assign rb6972 = rb6967 & rb6969;
  assign rb6973 = rb6968 & rb6970;
  assign rb6974 = (rb6967 & ~rb6969 & ~rb6970) | (rb6969 & ~rb6967 & ~rb6968);
  assign rb6975 = (rb6968 & ~rb6969 & ~rb6970) | (rb6970 & ~rb6967 & ~rb6968);
  assign rb6976 = rb6972 | (rb6974 & ~rb6971);
  assign rb6977 = rb6973 | (rb6975 & rb6971);
  assign rb6978 = (rb6974 | rb6975) & rb6971;
  assign rb6979 = (rb6974 | rb6975) & ~rb6971;
  assign rb6980 = (rb6549 & ~1'b0) | (1'b0 & ~rb6550);
  assign rb6981 = (rb6550 & ~1'b0) | (1'b0 & ~rb6549);
  assign rb6982 = (rb6562 & ~rb6548) | (rb6547 & ~rb6563);
  assign rb6983 = (rb6563 & ~rb6547) | (rb6548 & ~rb6562);
  assign rb6984 = (rb6575 & ~rb6561) | (rb6560 & ~rb6576);
  assign rb6985 = (rb6576 & ~rb6560) | (rb6561 & ~rb6575);
  assign rb6986 = (rb6588 & ~rb6574) | (rb6573 & ~rb6589);
  assign rb6987 = (rb6589 & ~rb6573) | (rb6574 & ~rb6588);
  assign rb6988 = (rb6601 & ~rb6587) | (rb6586 & ~rb6602);
  assign rb6989 = (rb6602 & ~rb6586) | (rb6587 & ~rb6601);
  assign rb6990 = (rb6614 & ~rb6600) | (rb6599 & ~rb6615);
  assign rb6991 = (rb6615 & ~rb6599) | (rb6600 & ~rb6614);
  assign rb6992 = (rb6627 & ~rb6613) | (rb6612 & ~rb6628);
  assign rb6993 = (rb6628 & ~rb6612) | (rb6613 & ~rb6627);
  assign rb6994 = (rb6640 & ~rb6626) | (rb6625 & ~rb6641);
  assign rb6995 = (rb6641 & ~rb6625) | (rb6626 & ~rb6640);
  assign rb6996 = (rb6653 & ~rb6639) | (rb6638 & ~rb6654);
  assign rb6997 = (rb6654 & ~rb6638) | (rb6639 & ~rb6653);
  assign rb6998 = (rb6666 & ~rb6652) | (rb6651 & ~rb6667);
  assign rb6999 = (rb6667 & ~rb6651) | (rb6652 & ~rb6666);
  assign rb7000 = (rb6679 & ~rb6665) | (rb6664 & ~rb6680);
  assign rb7001 = (rb6680 & ~rb6664) | (rb6665 & ~rb6679);
  assign rb7002 = (rb6692 & ~rb6678) | (rb6677 & ~rb6693);
  assign rb7003 = (rb6693 & ~rb6677) | (rb6678 & ~rb6692);
  assign rb7004 = (rb6705 & ~rb6691) | (rb6690 & ~rb6706);
  assign rb7005 = (rb6706 & ~rb6690) | (rb6691 & ~rb6705);
  assign rb7006 = (rb6718 & ~rb6704) | (rb6703 & ~rb6719);
  assign rb7007 = (rb6719 & ~rb6703) | (rb6704 & ~rb6718);
  assign rb7008 = (rb6731 & ~rb6717) | (rb6716 & ~rb6732);
  assign rb7009 = (rb6732 & ~rb6716) | (rb6717 & ~rb6731);
  assign rb7010 = (rb6744 & ~rb6730) | (rb6729 & ~rb6745);
  assign rb7011 = (rb6745 & ~rb6729) | (rb6730 & ~rb6744);
  assign rb7012 = (rb6757 & ~rb6743) | (rb6742 & ~rb6758);
  assign rb7013 = (rb6758 & ~rb6742) | (rb6743 & ~rb6757);
  assign rb7014 = (rb6770 & ~rb6756) | (rb6755 & ~rb6771);
  assign rb7015 = (rb6771 & ~rb6755) | (rb6756 & ~rb6770);
  assign rb7016 = (rb6783 & ~rb6769) | (rb6768 & ~rb6784);
  assign rb7017 = (rb6784 & ~rb6768) | (rb6769 & ~rb6783);
  assign rb7018 = (rb6796 & ~rb6782) | (rb6781 & ~rb6797);
  assign rb7019 = (rb6797 & ~rb6781) | (rb6782 & ~rb6796);
  assign rb7020 = (rb6809 & ~rb6795) | (rb6794 & ~rb6810);
  assign rb7021 = (rb6810 & ~rb6794) | (rb6795 & ~rb6809);
  assign rb7022 = (rb6822 & ~rb6808) | (rb6807 & ~rb6823);
  assign rb7023 = (rb6823 & ~rb6807) | (rb6808 & ~rb6822);
  assign rb7024 = (rb6835 & ~rb6821) | (rb6820 & ~rb6836);
  assign rb7025 = (rb6836 & ~rb6820) | (rb6821 & ~rb6835);
  assign rb7026 = (rb6848 & ~rb6834) | (rb6833 & ~rb6849);
  assign rb7027 = (rb6849 & ~rb6833) | (rb6834 & ~rb6848);
  assign rb7028 = (rb6861 & ~rb6847) | (rb6846 & ~rb6862);
  assign rb7029 = (rb6862 & ~rb6846) | (rb6847 & ~rb6861);
  assign rb7030 = (rb6874 & ~rb6860) | (rb6859 & ~rb6875);
  assign rb7031 = (rb6875 & ~rb6859) | (rb6860 & ~rb6874);
  assign rb7032 = (rb6887 & ~rb6873) | (rb6872 & ~rb6888);
  assign rb7033 = (rb6888 & ~rb6872) | (rb6873 & ~rb6887);
  assign rb7034 = (rb6900 & ~rb6886) | (rb6885 & ~rb6901);
  assign rb7035 = (rb6901 & ~rb6885) | (rb6886 & ~rb6900);
  assign rb7036 = (rb6913 & ~rb6899) | (rb6898 & ~rb6914);
  assign rb7037 = (rb6914 & ~rb6898) | (rb6899 & ~rb6913);
  assign rb7038 = (rb6926 & ~rb6912) | (rb6911 & ~rb6927);
  assign rb7039 = (rb6927 & ~rb6911) | (rb6912 & ~rb6926);
  assign rb7040 = (rb6939 & ~rb6925) | (rb6924 & ~rb6940);
  assign rb7041 = (rb6940 & ~rb6924) | (rb6925 & ~rb6939);
  assign rb7042 = (rb6952 & ~rb6938) | (rb6937 & ~rb6953);
  assign rb7043 = (rb6953 & ~rb6937) | (rb6938 & ~rb6952);
  assign rb7044 = (rb6965 & ~rb6951) | (rb6950 & ~rb6966);
  assign rb7045 = (rb6966 & ~rb6950) | (rb6951 & ~rb6965);
  assign rb7046 = (rb6978 & ~rb6964) | (rb6963 & ~rb6979);
  assign rb7047 = (rb6979 & ~rb6963) | (rb6964 & ~rb6978);
  assign rb7048 = (1'b0 & ~rb6977) | (rb6976 & ~1'b0);
  assign rb7049 = (1'b0 & ~rb6976) | (rb6977 & ~1'b0);
  assign rb7050 = rb5447;
  assign rb7051 = rb5448;
  assign rb7052 = rb5958;
  assign rb7053 = rb5959;
  assign rb7054 = rb7050 & rb7052;
  assign rb7055 = rb7051 & rb7053;
  assign rb7056 = (rb7050 & ~rb7052 & ~rb7053) | (rb7052 & ~rb7050 & ~rb7051);
  assign rb7057 = (rb7051 & ~rb7052 & ~rb7053) | (rb7053 & ~rb7050 & ~rb7051);
  assign rb7058 = rb7054 | (rb7056 & ~1'b0);
  assign rb7059 = rb7055 | (rb7057 & 1'b0);
  assign rb7060 = (rb7056 | rb7057) & 1'b0;
  assign rb7061 = (rb7056 | rb7057) & ~1'b0;
  assign rb7062 = rb5449;
  assign rb7063 = rb5450;
  assign rb7064 = rb5960;
  assign rb7065 = rb5961;
  assign rb7066 = rb5448 | rb5959;
  assign rb7067 = rb7062 & rb7064;
  assign rb7068 = rb7063 & rb7065;
  assign rb7069 = (rb7062 & ~rb7064 & ~rb7065) | (rb7064 & ~rb7062 & ~rb7063);
  assign rb7070 = (rb7063 & ~rb7064 & ~rb7065) | (rb7065 & ~rb7062 & ~rb7063);
  assign rb7071 = rb7067 | (rb7069 & ~rb7066);
  assign rb7072 = rb7068 | (rb7070 & rb7066);
  assign rb7073 = (rb7069 | rb7070) & rb7066;
  assign rb7074 = (rb7069 | rb7070) & ~rb7066;
  assign rb7075 = rb5451;
  assign rb7076 = rb5452;
  assign rb7077 = rb5962;
  assign rb7078 = rb5963;
  assign rb7079 = rb5450 | rb5961;
  assign rb7080 = rb7075 & rb7077;
  assign rb7081 = rb7076 & rb7078;
  assign rb7082 = (rb7075 & ~rb7077 & ~rb7078) | (rb7077 & ~rb7075 & ~rb7076);
  assign rb7083 = (rb7076 & ~rb7077 & ~rb7078) | (rb7078 & ~rb7075 & ~rb7076);
  assign rb7084 = rb7080 | (rb7082 & ~rb7079);
  assign rb7085 = rb7081 | (rb7083 & rb7079);
  assign rb7086 = (rb7082 | rb7083) & rb7079;
  assign rb7087 = (rb7082 | rb7083) & ~rb7079;
  assign rb7088 = rb5453;
  assign rb7089 = rb5454;
  assign rb7090 = rb5964;
  assign rb7091 = rb5965;
  assign rb7092 = rb5452 | rb5963;
  assign rb7093 = rb7088 & rb7090;
  assign rb7094 = rb7089 & rb7091;
  assign rb7095 = (rb7088 & ~rb7090 & ~rb7091) | (rb7090 & ~rb7088 & ~rb7089);
  assign rb7096 = (rb7089 & ~rb7090 & ~rb7091) | (rb7091 & ~rb7088 & ~rb7089);
  assign rb7097 = rb7093 | (rb7095 & ~rb7092);
  assign rb7098 = rb7094 | (rb7096 & rb7092);
  assign rb7099 = (rb7095 | rb7096) & rb7092;
  assign rb7100 = (rb7095 | rb7096) & ~rb7092;
  assign rb7101 = rb5455;
  assign rb7102 = rb5456;
  assign rb7103 = rb5966;
  assign rb7104 = rb5967;
  assign rb7105 = rb5454 | rb5965;
  assign rb7106 = rb7101 & rb7103;
  assign rb7107 = rb7102 & rb7104;
  assign rb7108 = (rb7101 & ~rb7103 & ~rb7104) | (rb7103 & ~rb7101 & ~rb7102);
  assign rb7109 = (rb7102 & ~rb7103 & ~rb7104) | (rb7104 & ~rb7101 & ~rb7102);
  assign rb7110 = rb7106 | (rb7108 & ~rb7105);
  assign rb7111 = rb7107 | (rb7109 & rb7105);
  assign rb7112 = (rb7108 | rb7109) & rb7105;
  assign rb7113 = (rb7108 | rb7109) & ~rb7105;
  assign rb7114 = rb5457;
  assign rb7115 = rb5458;
  assign rb7116 = rb5968;
  assign rb7117 = rb5969;
  assign rb7118 = rb5456 | rb5967;
  assign rb7119 = rb7114 & rb7116;
  assign rb7120 = rb7115 & rb7117;
  assign rb7121 = (rb7114 & ~rb7116 & ~rb7117) | (rb7116 & ~rb7114 & ~rb7115);
  assign rb7122 = (rb7115 & ~rb7116 & ~rb7117) | (rb7117 & ~rb7114 & ~rb7115);
  assign rb7123 = rb7119 | (rb7121 & ~rb7118);
  assign rb7124 = rb7120 | (rb7122 & rb7118);
  assign rb7125 = (rb7121 | rb7122) & rb7118;
  assign rb7126 = (rb7121 | rb7122) & ~rb7118;
  assign rb7127 = rb5459;
  assign rb7128 = rb5460;
  assign rb7129 = rb5970;
  assign rb7130 = rb5971;
  assign rb7131 = rb5458 | rb5969;
  assign rb7132 = rb7127 & rb7129;
  assign rb7133 = rb7128 & rb7130;
  assign rb7134 = (rb7127 & ~rb7129 & ~rb7130) | (rb7129 & ~rb7127 & ~rb7128);
  assign rb7135 = (rb7128 & ~rb7129 & ~rb7130) | (rb7130 & ~rb7127 & ~rb7128);
  assign rb7136 = rb7132 | (rb7134 & ~rb7131);
  assign rb7137 = rb7133 | (rb7135 & rb7131);
  assign rb7138 = (rb7134 | rb7135) & rb7131;
  assign rb7139 = (rb7134 | rb7135) & ~rb7131;
  assign rb7140 = rb5461;
  assign rb7141 = rb5462;
  assign rb7142 = rb5972;
  assign rb7143 = rb5973;
  assign rb7144 = rb5460 | rb5971;
  assign rb7145 = rb7140 & rb7142;
  assign rb7146 = rb7141 & rb7143;
  assign rb7147 = (rb7140 & ~rb7142 & ~rb7143) | (rb7142 & ~rb7140 & ~rb7141);
  assign rb7148 = (rb7141 & ~rb7142 & ~rb7143) | (rb7143 & ~rb7140 & ~rb7141);
  assign rb7149 = rb7145 | (rb7147 & ~rb7144);
  assign rb7150 = rb7146 | (rb7148 & rb7144);
  assign rb7151 = (rb7147 | rb7148) & rb7144;
  assign rb7152 = (rb7147 | rb7148) & ~rb7144;
  assign rb7153 = rb5463;
  assign rb7154 = rb5464;
  assign rb7155 = rb5974;
  assign rb7156 = rb5975;
  assign rb7157 = rb5462 | rb5973;
  assign rb7158 = rb7153 & rb7155;
  assign rb7159 = rb7154 & rb7156;
  assign rb7160 = (rb7153 & ~rb7155 & ~rb7156) | (rb7155 & ~rb7153 & ~rb7154);
  assign rb7161 = (rb7154 & ~rb7155 & ~rb7156) | (rb7156 & ~rb7153 & ~rb7154);
  assign rb7162 = rb7158 | (rb7160 & ~rb7157);
  assign rb7163 = rb7159 | (rb7161 & rb7157);
  assign rb7164 = (rb7160 | rb7161) & rb7157;
  assign rb7165 = (rb7160 | rb7161) & ~rb7157;
  assign rb7166 = rb5465;
  assign rb7167 = rb5466;
  assign rb7168 = rb5976;
  assign rb7169 = rb5977;
  assign rb7170 = rb5464 | rb5975;
  assign rb7171 = rb7166 & rb7168;
  assign rb7172 = rb7167 & rb7169;
  assign rb7173 = (rb7166 & ~rb7168 & ~rb7169) | (rb7168 & ~rb7166 & ~rb7167);
  assign rb7174 = (rb7167 & ~rb7168 & ~rb7169) | (rb7169 & ~rb7166 & ~rb7167);
  assign rb7175 = rb7171 | (rb7173 & ~rb7170);
  assign rb7176 = rb7172 | (rb7174 & rb7170);
  assign rb7177 = (rb7173 | rb7174) & rb7170;
  assign rb7178 = (rb7173 | rb7174) & ~rb7170;
  assign rb7179 = rb5467;
  assign rb7180 = rb5468;
  assign rb7181 = rb5978;
  assign rb7182 = rb5979;
  assign rb7183 = rb5466 | rb5977;
  assign rb7184 = rb7179 & rb7181;
  assign rb7185 = rb7180 & rb7182;
  assign rb7186 = (rb7179 & ~rb7181 & ~rb7182) | (rb7181 & ~rb7179 & ~rb7180);
  assign rb7187 = (rb7180 & ~rb7181 & ~rb7182) | (rb7182 & ~rb7179 & ~rb7180);
  assign rb7188 = rb7184 | (rb7186 & ~rb7183);
  assign rb7189 = rb7185 | (rb7187 & rb7183);
  assign rb7190 = (rb7186 | rb7187) & rb7183;
  assign rb7191 = (rb7186 | rb7187) & ~rb7183;
  assign rb7192 = rb5469;
  assign rb7193 = rb5470;
  assign rb7194 = rb5980;
  assign rb7195 = rb5981;
  assign rb7196 = rb5468 | rb5979;
  assign rb7197 = rb7192 & rb7194;
  assign rb7198 = rb7193 & rb7195;
  assign rb7199 = (rb7192 & ~rb7194 & ~rb7195) | (rb7194 & ~rb7192 & ~rb7193);
  assign rb7200 = (rb7193 & ~rb7194 & ~rb7195) | (rb7195 & ~rb7192 & ~rb7193);
  assign rb7201 = rb7197 | (rb7199 & ~rb7196);
  assign rb7202 = rb7198 | (rb7200 & rb7196);
  assign rb7203 = (rb7199 | rb7200) & rb7196;
  assign rb7204 = (rb7199 | rb7200) & ~rb7196;
  assign rb7205 = rb5471;
  assign rb7206 = rb5472;
  assign rb7207 = rb5982;
  assign rb7208 = rb5983;
  assign rb7209 = rb5470 | rb5981;
  assign rb7210 = rb7205 & rb7207;
  assign rb7211 = rb7206 & rb7208;
  assign rb7212 = (rb7205 & ~rb7207 & ~rb7208) | (rb7207 & ~rb7205 & ~rb7206);
  assign rb7213 = (rb7206 & ~rb7207 & ~rb7208) | (rb7208 & ~rb7205 & ~rb7206);
  assign rb7214 = rb7210 | (rb7212 & ~rb7209);
  assign rb7215 = rb7211 | (rb7213 & rb7209);
  assign rb7216 = (rb7212 | rb7213) & rb7209;
  assign rb7217 = (rb7212 | rb7213) & ~rb7209;
  assign rb7218 = rb5473;
  assign rb7219 = rb5474;
  assign rb7220 = rb5984;
  assign rb7221 = rb5985;
  assign rb7222 = rb5472 | rb5983;
  assign rb7223 = rb7218 & rb7220;
  assign rb7224 = rb7219 & rb7221;
  assign rb7225 = (rb7218 & ~rb7220 & ~rb7221) | (rb7220 & ~rb7218 & ~rb7219);
  assign rb7226 = (rb7219 & ~rb7220 & ~rb7221) | (rb7221 & ~rb7218 & ~rb7219);
  assign rb7227 = rb7223 | (rb7225 & ~rb7222);
  assign rb7228 = rb7224 | (rb7226 & rb7222);
  assign rb7229 = (rb7225 | rb7226) & rb7222;
  assign rb7230 = (rb7225 | rb7226) & ~rb7222;
  assign rb7231 = rb5475;
  assign rb7232 = rb5476;
  assign rb7233 = rb5986;
  assign rb7234 = rb5987;
  assign rb7235 = rb5474 | rb5985;
  assign rb7236 = rb7231 & rb7233;
  assign rb7237 = rb7232 & rb7234;
  assign rb7238 = (rb7231 & ~rb7233 & ~rb7234) | (rb7233 & ~rb7231 & ~rb7232);
  assign rb7239 = (rb7232 & ~rb7233 & ~rb7234) | (rb7234 & ~rb7231 & ~rb7232);
  assign rb7240 = rb7236 | (rb7238 & ~rb7235);
  assign rb7241 = rb7237 | (rb7239 & rb7235);
  assign rb7242 = (rb7238 | rb7239) & rb7235;
  assign rb7243 = (rb7238 | rb7239) & ~rb7235;
  assign rb7244 = rb5477;
  assign rb7245 = rb5478;
  assign rb7246 = rb5988;
  assign rb7247 = rb5989;
  assign rb7248 = rb5476 | rb5987;
  assign rb7249 = rb7244 & rb7246;
  assign rb7250 = rb7245 & rb7247;
  assign rb7251 = (rb7244 & ~rb7246 & ~rb7247) | (rb7246 & ~rb7244 & ~rb7245);
  assign rb7252 = (rb7245 & ~rb7246 & ~rb7247) | (rb7247 & ~rb7244 & ~rb7245);
  assign rb7253 = rb7249 | (rb7251 & ~rb7248);
  assign rb7254 = rb7250 | (rb7252 & rb7248);
  assign rb7255 = (rb7251 | rb7252) & rb7248;
  assign rb7256 = (rb7251 | rb7252) & ~rb7248;
  assign rb7257 = rb5479;
  assign rb7258 = rb5480;
  assign rb7259 = rb5990;
  assign rb7260 = rb5991;
  assign rb7261 = rb5478 | rb5989;
  assign rb7262 = rb7257 & rb7259;
  assign rb7263 = rb7258 & rb7260;
  assign rb7264 = (rb7257 & ~rb7259 & ~rb7260) | (rb7259 & ~rb7257 & ~rb7258);
  assign rb7265 = (rb7258 & ~rb7259 & ~rb7260) | (rb7260 & ~rb7257 & ~rb7258);
  assign rb7266 = rb7262 | (rb7264 & ~rb7261);
  assign rb7267 = rb7263 | (rb7265 & rb7261);
  assign rb7268 = (rb7264 | rb7265) & rb7261;
  assign rb7269 = (rb7264 | rb7265) & ~rb7261;
  assign rb7270 = rb5481;
  assign rb7271 = rb5482;
  assign rb7272 = rb5992;
  assign rb7273 = rb5993;
  assign rb7274 = rb5480 | rb5991;
  assign rb7275 = rb7270 & rb7272;
  assign rb7276 = rb7271 & rb7273;
  assign rb7277 = (rb7270 & ~rb7272 & ~rb7273) | (rb7272 & ~rb7270 & ~rb7271);
  assign rb7278 = (rb7271 & ~rb7272 & ~rb7273) | (rb7273 & ~rb7270 & ~rb7271);
  assign rb7279 = rb7275 | (rb7277 & ~rb7274);
  assign rb7280 = rb7276 | (rb7278 & rb7274);
  assign rb7281 = (rb7277 | rb7278) & rb7274;
  assign rb7282 = (rb7277 | rb7278) & ~rb7274;
  assign rb7283 = rb5483;
  assign rb7284 = rb5484;
  assign rb7285 = rb5994;
  assign rb7286 = rb5995;
  assign rb7287 = rb5482 | rb5993;
  assign rb7288 = rb7283 & rb7285;
  assign rb7289 = rb7284 & rb7286;
  assign rb7290 = (rb7283 & ~rb7285 & ~rb7286) | (rb7285 & ~rb7283 & ~rb7284);
  assign rb7291 = (rb7284 & ~rb7285 & ~rb7286) | (rb7286 & ~rb7283 & ~rb7284);
  assign rb7292 = rb7288 | (rb7290 & ~rb7287);
  assign rb7293 = rb7289 | (rb7291 & rb7287);
  assign rb7294 = (rb7290 | rb7291) & rb7287;
  assign rb7295 = (rb7290 | rb7291) & ~rb7287;
  assign rb7296 = rb5485;
  assign rb7297 = rb5486;
  assign rb7298 = rb5996;
  assign rb7299 = rb5997;
  assign rb7300 = rb5484 | rb5995;
  assign rb7301 = rb7296 & rb7298;
  assign rb7302 = rb7297 & rb7299;
  assign rb7303 = (rb7296 & ~rb7298 & ~rb7299) | (rb7298 & ~rb7296 & ~rb7297);
  assign rb7304 = (rb7297 & ~rb7298 & ~rb7299) | (rb7299 & ~rb7296 & ~rb7297);
  assign rb7305 = rb7301 | (rb7303 & ~rb7300);
  assign rb7306 = rb7302 | (rb7304 & rb7300);
  assign rb7307 = (rb7303 | rb7304) & rb7300;
  assign rb7308 = (rb7303 | rb7304) & ~rb7300;
  assign rb7309 = rb5487;
  assign rb7310 = rb5488;
  assign rb7311 = rb5998;
  assign rb7312 = rb5999;
  assign rb7313 = rb5486 | rb5997;
  assign rb7314 = rb7309 & rb7311;
  assign rb7315 = rb7310 & rb7312;
  assign rb7316 = (rb7309 & ~rb7311 & ~rb7312) | (rb7311 & ~rb7309 & ~rb7310);
  assign rb7317 = (rb7310 & ~rb7311 & ~rb7312) | (rb7312 & ~rb7309 & ~rb7310);
  assign rb7318 = rb7314 | (rb7316 & ~rb7313);
  assign rb7319 = rb7315 | (rb7317 & rb7313);
  assign rb7320 = (rb7316 | rb7317) & rb7313;
  assign rb7321 = (rb7316 | rb7317) & ~rb7313;
  assign rb7322 = rb5489;
  assign rb7323 = rb5490;
  assign rb7324 = rb6000;
  assign rb7325 = rb6001;
  assign rb7326 = rb5488 | rb5999;
  assign rb7327 = rb7322 & rb7324;
  assign rb7328 = rb7323 & rb7325;
  assign rb7329 = (rb7322 & ~rb7324 & ~rb7325) | (rb7324 & ~rb7322 & ~rb7323);
  assign rb7330 = (rb7323 & ~rb7324 & ~rb7325) | (rb7325 & ~rb7322 & ~rb7323);
  assign rb7331 = rb7327 | (rb7329 & ~rb7326);
  assign rb7332 = rb7328 | (rb7330 & rb7326);
  assign rb7333 = (rb7329 | rb7330) & rb7326;
  assign rb7334 = (rb7329 | rb7330) & ~rb7326;
  assign rb7335 = rb5491;
  assign rb7336 = rb5492;
  assign rb7337 = rb6002;
  assign rb7338 = rb6003;
  assign rb7339 = rb5490 | rb6001;
  assign rb7340 = rb7335 & rb7337;
  assign rb7341 = rb7336 & rb7338;
  assign rb7342 = (rb7335 & ~rb7337 & ~rb7338) | (rb7337 & ~rb7335 & ~rb7336);
  assign rb7343 = (rb7336 & ~rb7337 & ~rb7338) | (rb7338 & ~rb7335 & ~rb7336);
  assign rb7344 = rb7340 | (rb7342 & ~rb7339);
  assign rb7345 = rb7341 | (rb7343 & rb7339);
  assign rb7346 = (rb7342 | rb7343) & rb7339;
  assign rb7347 = (rb7342 | rb7343) & ~rb7339;
  assign rb7348 = rb5493;
  assign rb7349 = rb5494;
  assign rb7350 = rb6004;
  assign rb7351 = rb6005;
  assign rb7352 = rb5492 | rb6003;
  assign rb7353 = rb7348 & rb7350;
  assign rb7354 = rb7349 & rb7351;
  assign rb7355 = (rb7348 & ~rb7350 & ~rb7351) | (rb7350 & ~rb7348 & ~rb7349);
  assign rb7356 = (rb7349 & ~rb7350 & ~rb7351) | (rb7351 & ~rb7348 & ~rb7349);
  assign rb7357 = rb7353 | (rb7355 & ~rb7352);
  assign rb7358 = rb7354 | (rb7356 & rb7352);
  assign rb7359 = (rb7355 | rb7356) & rb7352;
  assign rb7360 = (rb7355 | rb7356) & ~rb7352;
  assign rb7361 = rb5495;
  assign rb7362 = rb5496;
  assign rb7363 = rb6006;
  assign rb7364 = rb6007;
  assign rb7365 = rb5494 | rb6005;
  assign rb7366 = rb7361 & rb7363;
  assign rb7367 = rb7362 & rb7364;
  assign rb7368 = (rb7361 & ~rb7363 & ~rb7364) | (rb7363 & ~rb7361 & ~rb7362);
  assign rb7369 = (rb7362 & ~rb7363 & ~rb7364) | (rb7364 & ~rb7361 & ~rb7362);
  assign rb7370 = rb7366 | (rb7368 & ~rb7365);
  assign rb7371 = rb7367 | (rb7369 & rb7365);
  assign rb7372 = (rb7368 | rb7369) & rb7365;
  assign rb7373 = (rb7368 | rb7369) & ~rb7365;
  assign rb7374 = rb5497;
  assign rb7375 = rb5498;
  assign rb7376 = rb6008;
  assign rb7377 = rb6009;
  assign rb7378 = rb5496 | rb6007;
  assign rb7379 = rb7374 & rb7376;
  assign rb7380 = rb7375 & rb7377;
  assign rb7381 = (rb7374 & ~rb7376 & ~rb7377) | (rb7376 & ~rb7374 & ~rb7375);
  assign rb7382 = (rb7375 & ~rb7376 & ~rb7377) | (rb7377 & ~rb7374 & ~rb7375);
  assign rb7383 = rb7379 | (rb7381 & ~rb7378);
  assign rb7384 = rb7380 | (rb7382 & rb7378);
  assign rb7385 = (rb7381 | rb7382) & rb7378;
  assign rb7386 = (rb7381 | rb7382) & ~rb7378;
  assign rb7387 = rb5499;
  assign rb7388 = rb5500;
  assign rb7389 = rb6010;
  assign rb7390 = rb6011;
  assign rb7391 = rb5498 | rb6009;
  assign rb7392 = rb7387 & rb7389;
  assign rb7393 = rb7388 & rb7390;
  assign rb7394 = (rb7387 & ~rb7389 & ~rb7390) | (rb7389 & ~rb7387 & ~rb7388);
  assign rb7395 = (rb7388 & ~rb7389 & ~rb7390) | (rb7390 & ~rb7387 & ~rb7388);
  assign rb7396 = rb7392 | (rb7394 & ~rb7391);
  assign rb7397 = rb7393 | (rb7395 & rb7391);
  assign rb7398 = (rb7394 | rb7395) & rb7391;
  assign rb7399 = (rb7394 | rb7395) & ~rb7391;
  assign rb7400 = rb5501;
  assign rb7401 = rb5502;
  assign rb7402 = rb6012;
  assign rb7403 = rb6013;
  assign rb7404 = rb5500 | rb6011;
  assign rb7405 = rb7400 & rb7402;
  assign rb7406 = rb7401 & rb7403;
  assign rb7407 = (rb7400 & ~rb7402 & ~rb7403) | (rb7402 & ~rb7400 & ~rb7401);
  assign rb7408 = (rb7401 & ~rb7402 & ~rb7403) | (rb7403 & ~rb7400 & ~rb7401);
  assign rb7409 = rb7405 | (rb7407 & ~rb7404);
  assign rb7410 = rb7406 | (rb7408 & rb7404);
  assign rb7411 = (rb7407 | rb7408) & rb7404;
  assign rb7412 = (rb7407 | rb7408) & ~rb7404;
  assign rb7413 = rb5503;
  assign rb7414 = rb5504;
  assign rb7415 = rb6014;
  assign rb7416 = rb6015;
  assign rb7417 = rb5502 | rb6013;
  assign rb7418 = rb7413 & rb7415;
  assign rb7419 = rb7414 & rb7416;
  assign rb7420 = (rb7413 & ~rb7415 & ~rb7416) | (rb7415 & ~rb7413 & ~rb7414);
  assign rb7421 = (rb7414 & ~rb7415 & ~rb7416) | (rb7416 & ~rb7413 & ~rb7414);
  assign rb7422 = rb7418 | (rb7420 & ~rb7417);
  assign rb7423 = rb7419 | (rb7421 & rb7417);
  assign rb7424 = (rb7420 | rb7421) & rb7417;
  assign rb7425 = (rb7420 | rb7421) & ~rb7417;
  assign rb7426 = rb5505;
  assign rb7427 = rb5506;
  assign rb7428 = rb6016;
  assign rb7429 = rb6017;
  assign rb7430 = rb5504 | rb6015;
  assign rb7431 = rb7426 & rb7428;
  assign rb7432 = rb7427 & rb7429;
  assign rb7433 = (rb7426 & ~rb7428 & ~rb7429) | (rb7428 & ~rb7426 & ~rb7427);
  assign rb7434 = (rb7427 & ~rb7428 & ~rb7429) | (rb7429 & ~rb7426 & ~rb7427);
  assign rb7435 = rb7431 | (rb7433 & ~rb7430);
  assign rb7436 = rb7432 | (rb7434 & rb7430);
  assign rb7437 = (rb7433 | rb7434) & rb7430;
  assign rb7438 = (rb7433 | rb7434) & ~rb7430;
  assign rb7439 = rb5507;
  assign rb7440 = rb5508;
  assign rb7441 = rb6018;
  assign rb7442 = rb6019;
  assign rb7443 = rb5506 | rb6017;
  assign rb7444 = rb7439 & rb7441;
  assign rb7445 = rb7440 & rb7442;
  assign rb7446 = (rb7439 & ~rb7441 & ~rb7442) | (rb7441 & ~rb7439 & ~rb7440);
  assign rb7447 = (rb7440 & ~rb7441 & ~rb7442) | (rb7442 & ~rb7439 & ~rb7440);
  assign rb7448 = rb7444 | (rb7446 & ~rb7443);
  assign rb7449 = rb7445 | (rb7447 & rb7443);
  assign rb7450 = (rb7446 | rb7447) & rb7443;
  assign rb7451 = (rb7446 | rb7447) & ~rb7443;
  assign rb7452 = rb5509;
  assign rb7453 = rb5510;
  assign rb7454 = rb6020;
  assign rb7455 = rb6021;
  assign rb7456 = rb5508 | rb6019;
  assign rb7457 = rb7452 & rb7454;
  assign rb7458 = rb7453 & rb7455;
  assign rb7459 = (rb7452 & ~rb7454 & ~rb7455) | (rb7454 & ~rb7452 & ~rb7453);
  assign rb7460 = (rb7453 & ~rb7454 & ~rb7455) | (rb7455 & ~rb7452 & ~rb7453);
  assign rb7461 = rb7457 | (rb7459 & ~rb7456);
  assign rb7462 = rb7458 | (rb7460 & rb7456);
  assign rb7463 = (rb7459 | rb7460) & rb7456;
  assign rb7464 = (rb7459 | rb7460) & ~rb7456;
  assign rb7465 = rb5511;
  assign rb7466 = rb5512;
  assign rb7467 = rb6022;
  assign rb7468 = rb6023;
  assign rb7469 = rb5510 | rb6021;
  assign rb7470 = rb7465 & rb7467;
  assign rb7471 = rb7466 & rb7468;
  assign rb7472 = (rb7465 & ~rb7467 & ~rb7468) | (rb7467 & ~rb7465 & ~rb7466);
  assign rb7473 = (rb7466 & ~rb7467 & ~rb7468) | (rb7468 & ~rb7465 & ~rb7466);
  assign rb7474 = rb7470 | (rb7472 & ~rb7469);
  assign rb7475 = rb7471 | (rb7473 & rb7469);
  assign rb7476 = (rb7472 | rb7473) & rb7469;
  assign rb7477 = (rb7472 | rb7473) & ~rb7469;
  assign rb7478 = rb5513;
  assign rb7479 = rb5514;
  assign rb7480 = rb6024;
  assign rb7481 = rb6025;
  assign rb7482 = rb5512 | rb6023;
  assign rb7483 = rb7478 & rb7480;
  assign rb7484 = rb7479 & rb7481;
  assign rb7485 = (rb7478 & ~rb7480 & ~rb7481) | (rb7480 & ~rb7478 & ~rb7479);
  assign rb7486 = (rb7479 & ~rb7480 & ~rb7481) | (rb7481 & ~rb7478 & ~rb7479);
  assign rb7487 = rb7483 | (rb7485 & ~rb7482);
  assign rb7488 = rb7484 | (rb7486 & rb7482);
  assign rb7489 = (rb7485 | rb7486) & rb7482;
  assign rb7490 = (rb7485 | rb7486) & ~rb7482;
  assign rb7491 = (rb7060 & ~1'b0) | (1'b0 & ~rb7061);
  assign rb7492 = (rb7061 & ~1'b0) | (1'b0 & ~rb7060);
  assign rb7493 = (rb7073 & ~rb7059) | (rb7058 & ~rb7074);
  assign rb7494 = (rb7074 & ~rb7058) | (rb7059 & ~rb7073);
  assign rb7495 = (rb7086 & ~rb7072) | (rb7071 & ~rb7087);
  assign rb7496 = (rb7087 & ~rb7071) | (rb7072 & ~rb7086);
  assign rb7497 = (rb7099 & ~rb7085) | (rb7084 & ~rb7100);
  assign rb7498 = (rb7100 & ~rb7084) | (rb7085 & ~rb7099);
  assign rb7499 = (rb7112 & ~rb7098) | (rb7097 & ~rb7113);
  assign rb7500 = (rb7113 & ~rb7097) | (rb7098 & ~rb7112);
  assign rb7501 = (rb7125 & ~rb7111) | (rb7110 & ~rb7126);
  assign rb7502 = (rb7126 & ~rb7110) | (rb7111 & ~rb7125);
  assign rb7503 = (rb7138 & ~rb7124) | (rb7123 & ~rb7139);
  assign rb7504 = (rb7139 & ~rb7123) | (rb7124 & ~rb7138);
  assign rb7505 = (rb7151 & ~rb7137) | (rb7136 & ~rb7152);
  assign rb7506 = (rb7152 & ~rb7136) | (rb7137 & ~rb7151);
  assign rb7507 = (rb7164 & ~rb7150) | (rb7149 & ~rb7165);
  assign rb7508 = (rb7165 & ~rb7149) | (rb7150 & ~rb7164);
  assign rb7509 = (rb7177 & ~rb7163) | (rb7162 & ~rb7178);
  assign rb7510 = (rb7178 & ~rb7162) | (rb7163 & ~rb7177);
  assign rb7511 = (rb7190 & ~rb7176) | (rb7175 & ~rb7191);
  assign rb7512 = (rb7191 & ~rb7175) | (rb7176 & ~rb7190);
  assign rb7513 = (rb7203 & ~rb7189) | (rb7188 & ~rb7204);
  assign rb7514 = (rb7204 & ~rb7188) | (rb7189 & ~rb7203);
  assign rb7515 = (rb7216 & ~rb7202) | (rb7201 & ~rb7217);
  assign rb7516 = (rb7217 & ~rb7201) | (rb7202 & ~rb7216);
  assign rb7517 = (rb7229 & ~rb7215) | (rb7214 & ~rb7230);
  assign rb7518 = (rb7230 & ~rb7214) | (rb7215 & ~rb7229);
  assign rb7519 = (rb7242 & ~rb7228) | (rb7227 & ~rb7243);
  assign rb7520 = (rb7243 & ~rb7227) | (rb7228 & ~rb7242);
  assign rb7521 = (rb7255 & ~rb7241) | (rb7240 & ~rb7256);
  assign rb7522 = (rb7256 & ~rb7240) | (rb7241 & ~rb7255);
  assign rb7523 = (rb7268 & ~rb7254) | (rb7253 & ~rb7269);
  assign rb7524 = (rb7269 & ~rb7253) | (rb7254 & ~rb7268);
  assign rb7525 = (rb7281 & ~rb7267) | (rb7266 & ~rb7282);
  assign rb7526 = (rb7282 & ~rb7266) | (rb7267 & ~rb7281);
  assign rb7527 = (rb7294 & ~rb7280) | (rb7279 & ~rb7295);
  assign rb7528 = (rb7295 & ~rb7279) | (rb7280 & ~rb7294);
  assign rb7529 = (rb7307 & ~rb7293) | (rb7292 & ~rb7308);
  assign rb7530 = (rb7308 & ~rb7292) | (rb7293 & ~rb7307);
  assign rb7531 = (rb7320 & ~rb7306) | (rb7305 & ~rb7321);
  assign rb7532 = (rb7321 & ~rb7305) | (rb7306 & ~rb7320);
  assign rb7533 = (rb7333 & ~rb7319) | (rb7318 & ~rb7334);
  assign rb7534 = (rb7334 & ~rb7318) | (rb7319 & ~rb7333);
  assign rb7535 = (rb7346 & ~rb7332) | (rb7331 & ~rb7347);
  assign rb7536 = (rb7347 & ~rb7331) | (rb7332 & ~rb7346);
  assign rb7537 = (rb7359 & ~rb7345) | (rb7344 & ~rb7360);
  assign rb7538 = (rb7360 & ~rb7344) | (rb7345 & ~rb7359);
  assign rb7539 = (rb7372 & ~rb7358) | (rb7357 & ~rb7373);
  assign rb7540 = (rb7373 & ~rb7357) | (rb7358 & ~rb7372);
  assign rb7541 = (rb7385 & ~rb7371) | (rb7370 & ~rb7386);
  assign rb7542 = (rb7386 & ~rb7370) | (rb7371 & ~rb7385);
  assign rb7543 = (rb7398 & ~rb7384) | (rb7383 & ~rb7399);
  assign rb7544 = (rb7399 & ~rb7383) | (rb7384 & ~rb7398);
  assign rb7545 = (rb7411 & ~rb7397) | (rb7396 & ~rb7412);
  assign rb7546 = (rb7412 & ~rb7396) | (rb7397 & ~rb7411);
  assign rb7547 = (rb7424 & ~rb7410) | (rb7409 & ~rb7425);
  assign rb7548 = (rb7425 & ~rb7409) | (rb7410 & ~rb7424);
  assign rb7549 = (rb7437 & ~rb7423) | (rb7422 & ~rb7438);
  assign rb7550 = (rb7438 & ~rb7422) | (rb7423 & ~rb7437);
  assign rb7551 = (rb7450 & ~rb7436) | (rb7435 & ~rb7451);
  assign rb7552 = (rb7451 & ~rb7435) | (rb7436 & ~rb7450);
  assign rb7553 = (rb7463 & ~rb7449) | (rb7448 & ~rb7464);
  assign rb7554 = (rb7464 & ~rb7448) | (rb7449 & ~rb7463);
  assign rb7555 = (rb7476 & ~rb7462) | (rb7461 & ~rb7477);
  assign rb7556 = (rb7477 & ~rb7461) | (rb7462 & ~rb7476);
  assign rb7557 = (rb7489 & ~rb7475) | (rb7474 & ~rb7490);
  assign rb7558 = (rb7490 & ~rb7474) | (rb7475 & ~rb7489);
  assign rb7559 = (1'b0 & ~rb7488) | (rb7487 & ~1'b0);
  assign rb7560 = (1'b0 & ~rb7487) | (rb7488 & ~1'b0);
  assign rb7561 = rb6469;
  assign rb7562 = rb6470;
  assign rb7563 = rb6980;
  assign rb7564 = rb6981;
  assign rb7565 = rb7561 & rb7563;
  assign rb7566 = rb7562 & rb7564;
  assign rb7567 = (rb7561 & ~rb7563 & ~rb7564) | (rb7563 & ~rb7561 & ~rb7562);
  assign rb7568 = (rb7562 & ~rb7563 & ~rb7564) | (rb7564 & ~rb7561 & ~rb7562);
  assign rb7569 = rb7565 | (rb7567 & ~1'b0);
  assign rb7570 = rb7566 | (rb7568 & 1'b0);
  assign rb7571 = (rb7567 | rb7568) & 1'b0;
  assign rb7572 = (rb7567 | rb7568) & ~1'b0;
  assign rb7573 = rb6471;
  assign rb7574 = rb6472;
  assign rb7575 = rb6982;
  assign rb7576 = rb6983;
  assign rb7577 = rb6470 | rb6981;
  assign rb7578 = rb7573 & rb7575;
  assign rb7579 = rb7574 & rb7576;
  assign rb7580 = (rb7573 & ~rb7575 & ~rb7576) | (rb7575 & ~rb7573 & ~rb7574);
  assign rb7581 = (rb7574 & ~rb7575 & ~rb7576) | (rb7576 & ~rb7573 & ~rb7574);
  assign rb7582 = rb7578 | (rb7580 & ~rb7577);
  assign rb7583 = rb7579 | (rb7581 & rb7577);
  assign rb7584 = (rb7580 | rb7581) & rb7577;
  assign rb7585 = (rb7580 | rb7581) & ~rb7577;
  assign rb7586 = rb6473;
  assign rb7587 = rb6474;
  assign rb7588 = rb6984;
  assign rb7589 = rb6985;
  assign rb7590 = rb6472 | rb6983;
  assign rb7591 = rb7586 & rb7588;
  assign rb7592 = rb7587 & rb7589;
  assign rb7593 = (rb7586 & ~rb7588 & ~rb7589) | (rb7588 & ~rb7586 & ~rb7587);
  assign rb7594 = (rb7587 & ~rb7588 & ~rb7589) | (rb7589 & ~rb7586 & ~rb7587);
  assign rb7595 = rb7591 | (rb7593 & ~rb7590);
  assign rb7596 = rb7592 | (rb7594 & rb7590);
  assign rb7597 = (rb7593 | rb7594) & rb7590;
  assign rb7598 = (rb7593 | rb7594) & ~rb7590;
  assign rb7599 = rb6475;
  assign rb7600 = rb6476;
  assign rb7601 = rb6986;
  assign rb7602 = rb6987;
  assign rb7603 = rb6474 | rb6985;
  assign rb7604 = rb7599 & rb7601;
  assign rb7605 = rb7600 & rb7602;
  assign rb7606 = (rb7599 & ~rb7601 & ~rb7602) | (rb7601 & ~rb7599 & ~rb7600);
  assign rb7607 = (rb7600 & ~rb7601 & ~rb7602) | (rb7602 & ~rb7599 & ~rb7600);
  assign rb7608 = rb7604 | (rb7606 & ~rb7603);
  assign rb7609 = rb7605 | (rb7607 & rb7603);
  assign rb7610 = (rb7606 | rb7607) & rb7603;
  assign rb7611 = (rb7606 | rb7607) & ~rb7603;
  assign rb7612 = rb6477;
  assign rb7613 = rb6478;
  assign rb7614 = rb6988;
  assign rb7615 = rb6989;
  assign rb7616 = rb6476 | rb6987;
  assign rb7617 = rb7612 & rb7614;
  assign rb7618 = rb7613 & rb7615;
  assign rb7619 = (rb7612 & ~rb7614 & ~rb7615) | (rb7614 & ~rb7612 & ~rb7613);
  assign rb7620 = (rb7613 & ~rb7614 & ~rb7615) | (rb7615 & ~rb7612 & ~rb7613);
  assign rb7621 = rb7617 | (rb7619 & ~rb7616);
  assign rb7622 = rb7618 | (rb7620 & rb7616);
  assign rb7623 = (rb7619 | rb7620) & rb7616;
  assign rb7624 = (rb7619 | rb7620) & ~rb7616;
  assign rb7625 = rb6479;
  assign rb7626 = rb6480;
  assign rb7627 = rb6990;
  assign rb7628 = rb6991;
  assign rb7629 = rb6478 | rb6989;
  assign rb7630 = rb7625 & rb7627;
  assign rb7631 = rb7626 & rb7628;
  assign rb7632 = (rb7625 & ~rb7627 & ~rb7628) | (rb7627 & ~rb7625 & ~rb7626);
  assign rb7633 = (rb7626 & ~rb7627 & ~rb7628) | (rb7628 & ~rb7625 & ~rb7626);
  assign rb7634 = rb7630 | (rb7632 & ~rb7629);
  assign rb7635 = rb7631 | (rb7633 & rb7629);
  assign rb7636 = (rb7632 | rb7633) & rb7629;
  assign rb7637 = (rb7632 | rb7633) & ~rb7629;
  assign rb7638 = rb6481;
  assign rb7639 = rb6482;
  assign rb7640 = rb6992;
  assign rb7641 = rb6993;
  assign rb7642 = rb6480 | rb6991;
  assign rb7643 = rb7638 & rb7640;
  assign rb7644 = rb7639 & rb7641;
  assign rb7645 = (rb7638 & ~rb7640 & ~rb7641) | (rb7640 & ~rb7638 & ~rb7639);
  assign rb7646 = (rb7639 & ~rb7640 & ~rb7641) | (rb7641 & ~rb7638 & ~rb7639);
  assign rb7647 = rb7643 | (rb7645 & ~rb7642);
  assign rb7648 = rb7644 | (rb7646 & rb7642);
  assign rb7649 = (rb7645 | rb7646) & rb7642;
  assign rb7650 = (rb7645 | rb7646) & ~rb7642;
  assign rb7651 = rb6483;
  assign rb7652 = rb6484;
  assign rb7653 = rb6994;
  assign rb7654 = rb6995;
  assign rb7655 = rb6482 | rb6993;
  assign rb7656 = rb7651 & rb7653;
  assign rb7657 = rb7652 & rb7654;
  assign rb7658 = (rb7651 & ~rb7653 & ~rb7654) | (rb7653 & ~rb7651 & ~rb7652);
  assign rb7659 = (rb7652 & ~rb7653 & ~rb7654) | (rb7654 & ~rb7651 & ~rb7652);
  assign rb7660 = rb7656 | (rb7658 & ~rb7655);
  assign rb7661 = rb7657 | (rb7659 & rb7655);
  assign rb7662 = (rb7658 | rb7659) & rb7655;
  assign rb7663 = (rb7658 | rb7659) & ~rb7655;
  assign rb7664 = rb6485;
  assign rb7665 = rb6486;
  assign rb7666 = rb6996;
  assign rb7667 = rb6997;
  assign rb7668 = rb6484 | rb6995;
  assign rb7669 = rb7664 & rb7666;
  assign rb7670 = rb7665 & rb7667;
  assign rb7671 = (rb7664 & ~rb7666 & ~rb7667) | (rb7666 & ~rb7664 & ~rb7665);
  assign rb7672 = (rb7665 & ~rb7666 & ~rb7667) | (rb7667 & ~rb7664 & ~rb7665);
  assign rb7673 = rb7669 | (rb7671 & ~rb7668);
  assign rb7674 = rb7670 | (rb7672 & rb7668);
  assign rb7675 = (rb7671 | rb7672) & rb7668;
  assign rb7676 = (rb7671 | rb7672) & ~rb7668;
  assign rb7677 = rb6487;
  assign rb7678 = rb6488;
  assign rb7679 = rb6998;
  assign rb7680 = rb6999;
  assign rb7681 = rb6486 | rb6997;
  assign rb7682 = rb7677 & rb7679;
  assign rb7683 = rb7678 & rb7680;
  assign rb7684 = (rb7677 & ~rb7679 & ~rb7680) | (rb7679 & ~rb7677 & ~rb7678);
  assign rb7685 = (rb7678 & ~rb7679 & ~rb7680) | (rb7680 & ~rb7677 & ~rb7678);
  assign rb7686 = rb7682 | (rb7684 & ~rb7681);
  assign rb7687 = rb7683 | (rb7685 & rb7681);
  assign rb7688 = (rb7684 | rb7685) & rb7681;
  assign rb7689 = (rb7684 | rb7685) & ~rb7681;
  assign rb7690 = rb6489;
  assign rb7691 = rb6490;
  assign rb7692 = rb7000;
  assign rb7693 = rb7001;
  assign rb7694 = rb6488 | rb6999;
  assign rb7695 = rb7690 & rb7692;
  assign rb7696 = rb7691 & rb7693;
  assign rb7697 = (rb7690 & ~rb7692 & ~rb7693) | (rb7692 & ~rb7690 & ~rb7691);
  assign rb7698 = (rb7691 & ~rb7692 & ~rb7693) | (rb7693 & ~rb7690 & ~rb7691);
  assign rb7699 = rb7695 | (rb7697 & ~rb7694);
  assign rb7700 = rb7696 | (rb7698 & rb7694);
  assign rb7701 = (rb7697 | rb7698) & rb7694;
  assign rb7702 = (rb7697 | rb7698) & ~rb7694;
  assign rb7703 = rb6491;
  assign rb7704 = rb6492;
  assign rb7705 = rb7002;
  assign rb7706 = rb7003;
  assign rb7707 = rb6490 | rb7001;
  assign rb7708 = rb7703 & rb7705;
  assign rb7709 = rb7704 & rb7706;
  assign rb7710 = (rb7703 & ~rb7705 & ~rb7706) | (rb7705 & ~rb7703 & ~rb7704);
  assign rb7711 = (rb7704 & ~rb7705 & ~rb7706) | (rb7706 & ~rb7703 & ~rb7704);
  assign rb7712 = rb7708 | (rb7710 & ~rb7707);
  assign rb7713 = rb7709 | (rb7711 & rb7707);
  assign rb7714 = (rb7710 | rb7711) & rb7707;
  assign rb7715 = (rb7710 | rb7711) & ~rb7707;
  assign rb7716 = rb6493;
  assign rb7717 = rb6494;
  assign rb7718 = rb7004;
  assign rb7719 = rb7005;
  assign rb7720 = rb6492 | rb7003;
  assign rb7721 = rb7716 & rb7718;
  assign rb7722 = rb7717 & rb7719;
  assign rb7723 = (rb7716 & ~rb7718 & ~rb7719) | (rb7718 & ~rb7716 & ~rb7717);
  assign rb7724 = (rb7717 & ~rb7718 & ~rb7719) | (rb7719 & ~rb7716 & ~rb7717);
  assign rb7725 = rb7721 | (rb7723 & ~rb7720);
  assign rb7726 = rb7722 | (rb7724 & rb7720);
  assign rb7727 = (rb7723 | rb7724) & rb7720;
  assign rb7728 = (rb7723 | rb7724) & ~rb7720;
  assign rb7729 = rb6495;
  assign rb7730 = rb6496;
  assign rb7731 = rb7006;
  assign rb7732 = rb7007;
  assign rb7733 = rb6494 | rb7005;
  assign rb7734 = rb7729 & rb7731;
  assign rb7735 = rb7730 & rb7732;
  assign rb7736 = (rb7729 & ~rb7731 & ~rb7732) | (rb7731 & ~rb7729 & ~rb7730);
  assign rb7737 = (rb7730 & ~rb7731 & ~rb7732) | (rb7732 & ~rb7729 & ~rb7730);
  assign rb7738 = rb7734 | (rb7736 & ~rb7733);
  assign rb7739 = rb7735 | (rb7737 & rb7733);
  assign rb7740 = (rb7736 | rb7737) & rb7733;
  assign rb7741 = (rb7736 | rb7737) & ~rb7733;
  assign rb7742 = rb6497;
  assign rb7743 = rb6498;
  assign rb7744 = rb7008;
  assign rb7745 = rb7009;
  assign rb7746 = rb6496 | rb7007;
  assign rb7747 = rb7742 & rb7744;
  assign rb7748 = rb7743 & rb7745;
  assign rb7749 = (rb7742 & ~rb7744 & ~rb7745) | (rb7744 & ~rb7742 & ~rb7743);
  assign rb7750 = (rb7743 & ~rb7744 & ~rb7745) | (rb7745 & ~rb7742 & ~rb7743);
  assign rb7751 = rb7747 | (rb7749 & ~rb7746);
  assign rb7752 = rb7748 | (rb7750 & rb7746);
  assign rb7753 = (rb7749 | rb7750) & rb7746;
  assign rb7754 = (rb7749 | rb7750) & ~rb7746;
  assign rb7755 = rb6499;
  assign rb7756 = rb6500;
  assign rb7757 = rb7010;
  assign rb7758 = rb7011;
  assign rb7759 = rb6498 | rb7009;
  assign rb7760 = rb7755 & rb7757;
  assign rb7761 = rb7756 & rb7758;
  assign rb7762 = (rb7755 & ~rb7757 & ~rb7758) | (rb7757 & ~rb7755 & ~rb7756);
  assign rb7763 = (rb7756 & ~rb7757 & ~rb7758) | (rb7758 & ~rb7755 & ~rb7756);
  assign rb7764 = rb7760 | (rb7762 & ~rb7759);
  assign rb7765 = rb7761 | (rb7763 & rb7759);
  assign rb7766 = (rb7762 | rb7763) & rb7759;
  assign rb7767 = (rb7762 | rb7763) & ~rb7759;
  assign rb7768 = rb6501;
  assign rb7769 = rb6502;
  assign rb7770 = rb7012;
  assign rb7771 = rb7013;
  assign rb7772 = rb6500 | rb7011;
  assign rb7773 = rb7768 & rb7770;
  assign rb7774 = rb7769 & rb7771;
  assign rb7775 = (rb7768 & ~rb7770 & ~rb7771) | (rb7770 & ~rb7768 & ~rb7769);
  assign rb7776 = (rb7769 & ~rb7770 & ~rb7771) | (rb7771 & ~rb7768 & ~rb7769);
  assign rb7777 = rb7773 | (rb7775 & ~rb7772);
  assign rb7778 = rb7774 | (rb7776 & rb7772);
  assign rb7779 = (rb7775 | rb7776) & rb7772;
  assign rb7780 = (rb7775 | rb7776) & ~rb7772;
  assign rb7781 = rb6503;
  assign rb7782 = rb6504;
  assign rb7783 = rb7014;
  assign rb7784 = rb7015;
  assign rb7785 = rb6502 | rb7013;
  assign rb7786 = rb7781 & rb7783;
  assign rb7787 = rb7782 & rb7784;
  assign rb7788 = (rb7781 & ~rb7783 & ~rb7784) | (rb7783 & ~rb7781 & ~rb7782);
  assign rb7789 = (rb7782 & ~rb7783 & ~rb7784) | (rb7784 & ~rb7781 & ~rb7782);
  assign rb7790 = rb7786 | (rb7788 & ~rb7785);
  assign rb7791 = rb7787 | (rb7789 & rb7785);
  assign rb7792 = (rb7788 | rb7789) & rb7785;
  assign rb7793 = (rb7788 | rb7789) & ~rb7785;
  assign rb7794 = rb6505;
  assign rb7795 = rb6506;
  assign rb7796 = rb7016;
  assign rb7797 = rb7017;
  assign rb7798 = rb6504 | rb7015;
  assign rb7799 = rb7794 & rb7796;
  assign rb7800 = rb7795 & rb7797;
  assign rb7801 = (rb7794 & ~rb7796 & ~rb7797) | (rb7796 & ~rb7794 & ~rb7795);
  assign rb7802 = (rb7795 & ~rb7796 & ~rb7797) | (rb7797 & ~rb7794 & ~rb7795);
  assign rb7803 = rb7799 | (rb7801 & ~rb7798);
  assign rb7804 = rb7800 | (rb7802 & rb7798);
  assign rb7805 = (rb7801 | rb7802) & rb7798;
  assign rb7806 = (rb7801 | rb7802) & ~rb7798;
  assign rb7807 = rb6507;
  assign rb7808 = rb6508;
  assign rb7809 = rb7018;
  assign rb7810 = rb7019;
  assign rb7811 = rb6506 | rb7017;
  assign rb7812 = rb7807 & rb7809;
  assign rb7813 = rb7808 & rb7810;
  assign rb7814 = (rb7807 & ~rb7809 & ~rb7810) | (rb7809 & ~rb7807 & ~rb7808);
  assign rb7815 = (rb7808 & ~rb7809 & ~rb7810) | (rb7810 & ~rb7807 & ~rb7808);
  assign rb7816 = rb7812 | (rb7814 & ~rb7811);
  assign rb7817 = rb7813 | (rb7815 & rb7811);
  assign rb7818 = (rb7814 | rb7815) & rb7811;
  assign rb7819 = (rb7814 | rb7815) & ~rb7811;
  assign rb7820 = rb6509;
  assign rb7821 = rb6510;
  assign rb7822 = rb7020;
  assign rb7823 = rb7021;
  assign rb7824 = rb6508 | rb7019;
  assign rb7825 = rb7820 & rb7822;
  assign rb7826 = rb7821 & rb7823;
  assign rb7827 = (rb7820 & ~rb7822 & ~rb7823) | (rb7822 & ~rb7820 & ~rb7821);
  assign rb7828 = (rb7821 & ~rb7822 & ~rb7823) | (rb7823 & ~rb7820 & ~rb7821);
  assign rb7829 = rb7825 | (rb7827 & ~rb7824);
  assign rb7830 = rb7826 | (rb7828 & rb7824);
  assign rb7831 = (rb7827 | rb7828) & rb7824;
  assign rb7832 = (rb7827 | rb7828) & ~rb7824;
  assign rb7833 = rb6511;
  assign rb7834 = rb6512;
  assign rb7835 = rb7022;
  assign rb7836 = rb7023;
  assign rb7837 = rb6510 | rb7021;
  assign rb7838 = rb7833 & rb7835;
  assign rb7839 = rb7834 & rb7836;
  assign rb7840 = (rb7833 & ~rb7835 & ~rb7836) | (rb7835 & ~rb7833 & ~rb7834);
  assign rb7841 = (rb7834 & ~rb7835 & ~rb7836) | (rb7836 & ~rb7833 & ~rb7834);
  assign rb7842 = rb7838 | (rb7840 & ~rb7837);
  assign rb7843 = rb7839 | (rb7841 & rb7837);
  assign rb7844 = (rb7840 | rb7841) & rb7837;
  assign rb7845 = (rb7840 | rb7841) & ~rb7837;
  assign rb7846 = rb6513;
  assign rb7847 = rb6514;
  assign rb7848 = rb7024;
  assign rb7849 = rb7025;
  assign rb7850 = rb6512 | rb7023;
  assign rb7851 = rb7846 & rb7848;
  assign rb7852 = rb7847 & rb7849;
  assign rb7853 = (rb7846 & ~rb7848 & ~rb7849) | (rb7848 & ~rb7846 & ~rb7847);
  assign rb7854 = (rb7847 & ~rb7848 & ~rb7849) | (rb7849 & ~rb7846 & ~rb7847);
  assign rb7855 = rb7851 | (rb7853 & ~rb7850);
  assign rb7856 = rb7852 | (rb7854 & rb7850);
  assign rb7857 = (rb7853 | rb7854) & rb7850;
  assign rb7858 = (rb7853 | rb7854) & ~rb7850;
  assign rb7859 = rb6515;
  assign rb7860 = rb6516;
  assign rb7861 = rb7026;
  assign rb7862 = rb7027;
  assign rb7863 = rb6514 | rb7025;
  assign rb7864 = rb7859 & rb7861;
  assign rb7865 = rb7860 & rb7862;
  assign rb7866 = (rb7859 & ~rb7861 & ~rb7862) | (rb7861 & ~rb7859 & ~rb7860);
  assign rb7867 = (rb7860 & ~rb7861 & ~rb7862) | (rb7862 & ~rb7859 & ~rb7860);
  assign rb7868 = rb7864 | (rb7866 & ~rb7863);
  assign rb7869 = rb7865 | (rb7867 & rb7863);
  assign rb7870 = (rb7866 | rb7867) & rb7863;
  assign rb7871 = (rb7866 | rb7867) & ~rb7863;
  assign rb7872 = rb6517;
  assign rb7873 = rb6518;
  assign rb7874 = rb7028;
  assign rb7875 = rb7029;
  assign rb7876 = rb6516 | rb7027;
  assign rb7877 = rb7872 & rb7874;
  assign rb7878 = rb7873 & rb7875;
  assign rb7879 = (rb7872 & ~rb7874 & ~rb7875) | (rb7874 & ~rb7872 & ~rb7873);
  assign rb7880 = (rb7873 & ~rb7874 & ~rb7875) | (rb7875 & ~rb7872 & ~rb7873);
  assign rb7881 = rb7877 | (rb7879 & ~rb7876);
  assign rb7882 = rb7878 | (rb7880 & rb7876);
  assign rb7883 = (rb7879 | rb7880) & rb7876;
  assign rb7884 = (rb7879 | rb7880) & ~rb7876;
  assign rb7885 = rb6519;
  assign rb7886 = rb6520;
  assign rb7887 = rb7030;
  assign rb7888 = rb7031;
  assign rb7889 = rb6518 | rb7029;
  assign rb7890 = rb7885 & rb7887;
  assign rb7891 = rb7886 & rb7888;
  assign rb7892 = (rb7885 & ~rb7887 & ~rb7888) | (rb7887 & ~rb7885 & ~rb7886);
  assign rb7893 = (rb7886 & ~rb7887 & ~rb7888) | (rb7888 & ~rb7885 & ~rb7886);
  assign rb7894 = rb7890 | (rb7892 & ~rb7889);
  assign rb7895 = rb7891 | (rb7893 & rb7889);
  assign rb7896 = (rb7892 | rb7893) & rb7889;
  assign rb7897 = (rb7892 | rb7893) & ~rb7889;
  assign rb7898 = rb6521;
  assign rb7899 = rb6522;
  assign rb7900 = rb7032;
  assign rb7901 = rb7033;
  assign rb7902 = rb6520 | rb7031;
  assign rb7903 = rb7898 & rb7900;
  assign rb7904 = rb7899 & rb7901;
  assign rb7905 = (rb7898 & ~rb7900 & ~rb7901) | (rb7900 & ~rb7898 & ~rb7899);
  assign rb7906 = (rb7899 & ~rb7900 & ~rb7901) | (rb7901 & ~rb7898 & ~rb7899);
  assign rb7907 = rb7903 | (rb7905 & ~rb7902);
  assign rb7908 = rb7904 | (rb7906 & rb7902);
  assign rb7909 = (rb7905 | rb7906) & rb7902;
  assign rb7910 = (rb7905 | rb7906) & ~rb7902;
  assign rb7911 = rb6523;
  assign rb7912 = rb6524;
  assign rb7913 = rb7034;
  assign rb7914 = rb7035;
  assign rb7915 = rb6522 | rb7033;
  assign rb7916 = rb7911 & rb7913;
  assign rb7917 = rb7912 & rb7914;
  assign rb7918 = (rb7911 & ~rb7913 & ~rb7914) | (rb7913 & ~rb7911 & ~rb7912);
  assign rb7919 = (rb7912 & ~rb7913 & ~rb7914) | (rb7914 & ~rb7911 & ~rb7912);
  assign rb7920 = rb7916 | (rb7918 & ~rb7915);
  assign rb7921 = rb7917 | (rb7919 & rb7915);
  assign rb7922 = (rb7918 | rb7919) & rb7915;
  assign rb7923 = (rb7918 | rb7919) & ~rb7915;
  assign rb7924 = rb6525;
  assign rb7925 = rb6526;
  assign rb7926 = rb7036;
  assign rb7927 = rb7037;
  assign rb7928 = rb6524 | rb7035;
  assign rb7929 = rb7924 & rb7926;
  assign rb7930 = rb7925 & rb7927;
  assign rb7931 = (rb7924 & ~rb7926 & ~rb7927) | (rb7926 & ~rb7924 & ~rb7925);
  assign rb7932 = (rb7925 & ~rb7926 & ~rb7927) | (rb7927 & ~rb7924 & ~rb7925);
  assign rb7933 = rb7929 | (rb7931 & ~rb7928);
  assign rb7934 = rb7930 | (rb7932 & rb7928);
  assign rb7935 = (rb7931 | rb7932) & rb7928;
  assign rb7936 = (rb7931 | rb7932) & ~rb7928;
  assign rb7937 = rb6527;
  assign rb7938 = rb6528;
  assign rb7939 = rb7038;
  assign rb7940 = rb7039;
  assign rb7941 = rb6526 | rb7037;
  assign rb7942 = rb7937 & rb7939;
  assign rb7943 = rb7938 & rb7940;
  assign rb7944 = (rb7937 & ~rb7939 & ~rb7940) | (rb7939 & ~rb7937 & ~rb7938);
  assign rb7945 = (rb7938 & ~rb7939 & ~rb7940) | (rb7940 & ~rb7937 & ~rb7938);
  assign rb7946 = rb7942 | (rb7944 & ~rb7941);
  assign rb7947 = rb7943 | (rb7945 & rb7941);
  assign rb7948 = (rb7944 | rb7945) & rb7941;
  assign rb7949 = (rb7944 | rb7945) & ~rb7941;
  assign rb7950 = rb6529;
  assign rb7951 = rb6530;
  assign rb7952 = rb7040;
  assign rb7953 = rb7041;
  assign rb7954 = rb6528 | rb7039;
  assign rb7955 = rb7950 & rb7952;
  assign rb7956 = rb7951 & rb7953;
  assign rb7957 = (rb7950 & ~rb7952 & ~rb7953) | (rb7952 & ~rb7950 & ~rb7951);
  assign rb7958 = (rb7951 & ~rb7952 & ~rb7953) | (rb7953 & ~rb7950 & ~rb7951);
  assign rb7959 = rb7955 | (rb7957 & ~rb7954);
  assign rb7960 = rb7956 | (rb7958 & rb7954);
  assign rb7961 = (rb7957 | rb7958) & rb7954;
  assign rb7962 = (rb7957 | rb7958) & ~rb7954;
  assign rb7963 = rb6531;
  assign rb7964 = rb6532;
  assign rb7965 = rb7042;
  assign rb7966 = rb7043;
  assign rb7967 = rb6530 | rb7041;
  assign rb7968 = rb7963 & rb7965;
  assign rb7969 = rb7964 & rb7966;
  assign rb7970 = (rb7963 & ~rb7965 & ~rb7966) | (rb7965 & ~rb7963 & ~rb7964);
  assign rb7971 = (rb7964 & ~rb7965 & ~rb7966) | (rb7966 & ~rb7963 & ~rb7964);
  assign rb7972 = rb7968 | (rb7970 & ~rb7967);
  assign rb7973 = rb7969 | (rb7971 & rb7967);
  assign rb7974 = (rb7970 | rb7971) & rb7967;
  assign rb7975 = (rb7970 | rb7971) & ~rb7967;
  assign rb7976 = rb6533;
  assign rb7977 = rb6534;
  assign rb7978 = rb7044;
  assign rb7979 = rb7045;
  assign rb7980 = rb6532 | rb7043;
  assign rb7981 = rb7976 & rb7978;
  assign rb7982 = rb7977 & rb7979;
  assign rb7983 = (rb7976 & ~rb7978 & ~rb7979) | (rb7978 & ~rb7976 & ~rb7977);
  assign rb7984 = (rb7977 & ~rb7978 & ~rb7979) | (rb7979 & ~rb7976 & ~rb7977);
  assign rb7985 = rb7981 | (rb7983 & ~rb7980);
  assign rb7986 = rb7982 | (rb7984 & rb7980);
  assign rb7987 = (rb7983 | rb7984) & rb7980;
  assign rb7988 = (rb7983 | rb7984) & ~rb7980;
  assign rb7989 = rb6535;
  assign rb7990 = rb6536;
  assign rb7991 = rb7046;
  assign rb7992 = rb7047;
  assign rb7993 = rb6534 | rb7045;
  assign rb7994 = rb7989 & rb7991;
  assign rb7995 = rb7990 & rb7992;
  assign rb7996 = (rb7989 & ~rb7991 & ~rb7992) | (rb7991 & ~rb7989 & ~rb7990);
  assign rb7997 = (rb7990 & ~rb7991 & ~rb7992) | (rb7992 & ~rb7989 & ~rb7990);
  assign rb7998 = rb7994 | (rb7996 & ~rb7993);
  assign rb7999 = rb7995 | (rb7997 & rb7993);
  assign rb8000 = (rb7996 | rb7997) & rb7993;
  assign rb8001 = (rb7996 | rb7997) & ~rb7993;
  assign rb8002 = (rb7571 & ~1'b0) | (1'b0 & ~rb7572);
  assign rb8003 = (rb7572 & ~1'b0) | (1'b0 & ~rb7571);
  assign rb8004 = (rb7584 & ~rb7570) | (rb7569 & ~rb7585);
  assign rb8005 = (rb7585 & ~rb7569) | (rb7570 & ~rb7584);
  assign rb8006 = (rb7597 & ~rb7583) | (rb7582 & ~rb7598);
  assign rb8007 = (rb7598 & ~rb7582) | (rb7583 & ~rb7597);
  assign rb8008 = (rb7610 & ~rb7596) | (rb7595 & ~rb7611);
  assign rb8009 = (rb7611 & ~rb7595) | (rb7596 & ~rb7610);
  assign rb8010 = (rb7623 & ~rb7609) | (rb7608 & ~rb7624);
  assign rb8011 = (rb7624 & ~rb7608) | (rb7609 & ~rb7623);
  assign rb8012 = (rb7636 & ~rb7622) | (rb7621 & ~rb7637);
  assign rb8013 = (rb7637 & ~rb7621) | (rb7622 & ~rb7636);
  assign rb8014 = (rb7649 & ~rb7635) | (rb7634 & ~rb7650);
  assign rb8015 = (rb7650 & ~rb7634) | (rb7635 & ~rb7649);
  assign rb8016 = (rb7662 & ~rb7648) | (rb7647 & ~rb7663);
  assign rb8017 = (rb7663 & ~rb7647) | (rb7648 & ~rb7662);
  assign rb8018 = (rb7675 & ~rb7661) | (rb7660 & ~rb7676);
  assign rb8019 = (rb7676 & ~rb7660) | (rb7661 & ~rb7675);
  assign rb8020 = (rb7688 & ~rb7674) | (rb7673 & ~rb7689);
  assign rb8021 = (rb7689 & ~rb7673) | (rb7674 & ~rb7688);
  assign rb8022 = (rb7701 & ~rb7687) | (rb7686 & ~rb7702);
  assign rb8023 = (rb7702 & ~rb7686) | (rb7687 & ~rb7701);
  assign rb8024 = (rb7714 & ~rb7700) | (rb7699 & ~rb7715);
  assign rb8025 = (rb7715 & ~rb7699) | (rb7700 & ~rb7714);
  assign rb8026 = (rb7727 & ~rb7713) | (rb7712 & ~rb7728);
  assign rb8027 = (rb7728 & ~rb7712) | (rb7713 & ~rb7727);
  assign rb8028 = (rb7740 & ~rb7726) | (rb7725 & ~rb7741);
  assign rb8029 = (rb7741 & ~rb7725) | (rb7726 & ~rb7740);
  assign rb8030 = (rb7753 & ~rb7739) | (rb7738 & ~rb7754);
  assign rb8031 = (rb7754 & ~rb7738) | (rb7739 & ~rb7753);
  assign rb8032 = (rb7766 & ~rb7752) | (rb7751 & ~rb7767);
  assign rb8033 = (rb7767 & ~rb7751) | (rb7752 & ~rb7766);
  assign rb8034 = (rb7779 & ~rb7765) | (rb7764 & ~rb7780);
  assign rb8035 = (rb7780 & ~rb7764) | (rb7765 & ~rb7779);
  assign rb8036 = (rb7792 & ~rb7778) | (rb7777 & ~rb7793);
  assign rb8037 = (rb7793 & ~rb7777) | (rb7778 & ~rb7792);
  assign rb8038 = (rb7805 & ~rb7791) | (rb7790 & ~rb7806);
  assign rb8039 = (rb7806 & ~rb7790) | (rb7791 & ~rb7805);
  assign rb8040 = (rb7818 & ~rb7804) | (rb7803 & ~rb7819);
  assign rb8041 = (rb7819 & ~rb7803) | (rb7804 & ~rb7818);
  assign rb8042 = (rb7831 & ~rb7817) | (rb7816 & ~rb7832);
  assign rb8043 = (rb7832 & ~rb7816) | (rb7817 & ~rb7831);
  assign rb8044 = (rb7844 & ~rb7830) | (rb7829 & ~rb7845);
  assign rb8045 = (rb7845 & ~rb7829) | (rb7830 & ~rb7844);
  assign rb8046 = (rb7857 & ~rb7843) | (rb7842 & ~rb7858);
  assign rb8047 = (rb7858 & ~rb7842) | (rb7843 & ~rb7857);
  assign rb8048 = (rb7870 & ~rb7856) | (rb7855 & ~rb7871);
  assign rb8049 = (rb7871 & ~rb7855) | (rb7856 & ~rb7870);
  assign rb8050 = (rb7883 & ~rb7869) | (rb7868 & ~rb7884);
  assign rb8051 = (rb7884 & ~rb7868) | (rb7869 & ~rb7883);
  assign rb8052 = (rb7896 & ~rb7882) | (rb7881 & ~rb7897);
  assign rb8053 = (rb7897 & ~rb7881) | (rb7882 & ~rb7896);
  assign rb8054 = (rb7909 & ~rb7895) | (rb7894 & ~rb7910);
  assign rb8055 = (rb7910 & ~rb7894) | (rb7895 & ~rb7909);
  assign rb8056 = (rb7922 & ~rb7908) | (rb7907 & ~rb7923);
  assign rb8057 = (rb7923 & ~rb7907) | (rb7908 & ~rb7922);
  assign rb8058 = (rb7935 & ~rb7921) | (rb7920 & ~rb7936);
  assign rb8059 = (rb7936 & ~rb7920) | (rb7921 & ~rb7935);
  assign rb8060 = (rb7948 & ~rb7934) | (rb7933 & ~rb7949);
  assign rb8061 = (rb7949 & ~rb7933) | (rb7934 & ~rb7948);
  assign rb8062 = (rb7961 & ~rb7947) | (rb7946 & ~rb7962);
  assign rb8063 = (rb7962 & ~rb7946) | (rb7947 & ~rb7961);
  assign rb8064 = (rb7974 & ~rb7960) | (rb7959 & ~rb7975);
  assign rb8065 = (rb7975 & ~rb7959) | (rb7960 & ~rb7974);
  assign rb8066 = (rb7987 & ~rb7973) | (rb7972 & ~rb7988);
  assign rb8067 = (rb7988 & ~rb7972) | (rb7973 & ~rb7987);
  assign rb8068 = (rb8000 & ~rb7986) | (rb7985 & ~rb8001);
  assign rb8069 = (rb8001 & ~rb7985) | (rb7986 & ~rb8000);
  assign rb8070 = (1'b0 & ~rb7999) | (rb7998 & ~1'b0);
  assign rb8071 = (1'b0 & ~rb7998) | (rb7999 & ~1'b0);
  assign rb8072 = rb7491;
  assign rb8073 = rb7492;
  assign rb8074 = rb8002;
  assign rb8075 = rb8003;
  assign rb8076 = rb8072 & rb8074;
  assign rb8077 = rb8073 & rb8075;
  assign rb8078 = (rb8072 & ~rb8074 & ~rb8075) | (rb8074 & ~rb8072 & ~rb8073);
  assign rb8079 = (rb8073 & ~rb8074 & ~rb8075) | (rb8075 & ~rb8072 & ~rb8073);
  assign rb8080 = rb8076 | (rb8078 & ~1'b0);
  assign rb8081 = rb8077 | (rb8079 & 1'b0);
  assign rb8082 = (rb8078 | rb8079) & 1'b0;
  assign rb8083 = (rb8078 | rb8079) & ~1'b0;
  assign rb8084 = rb7493;
  assign rb8085 = rb7494;
  assign rb8086 = rb8004;
  assign rb8087 = rb8005;
  assign rb8088 = rb7492 | rb8003;
  assign rb8089 = rb8084 & rb8086;
  assign rb8090 = rb8085 & rb8087;
  assign rb8091 = (rb8084 & ~rb8086 & ~rb8087) | (rb8086 & ~rb8084 & ~rb8085);
  assign rb8092 = (rb8085 & ~rb8086 & ~rb8087) | (rb8087 & ~rb8084 & ~rb8085);
  assign rb8093 = rb8089 | (rb8091 & ~rb8088);
  assign rb8094 = rb8090 | (rb8092 & rb8088);
  assign rb8095 = (rb8091 | rb8092) & rb8088;
  assign rb8096 = (rb8091 | rb8092) & ~rb8088;
  assign rb8097 = rb7495;
  assign rb8098 = rb7496;
  assign rb8099 = rb8006;
  assign rb8100 = rb8007;
  assign rb8101 = rb7494 | rb8005;
  assign rb8102 = rb8097 & rb8099;
  assign rb8103 = rb8098 & rb8100;
  assign rb8104 = (rb8097 & ~rb8099 & ~rb8100) | (rb8099 & ~rb8097 & ~rb8098);
  assign rb8105 = (rb8098 & ~rb8099 & ~rb8100) | (rb8100 & ~rb8097 & ~rb8098);
  assign rb8106 = rb8102 | (rb8104 & ~rb8101);
  assign rb8107 = rb8103 | (rb8105 & rb8101);
  assign rb8108 = (rb8104 | rb8105) & rb8101;
  assign rb8109 = (rb8104 | rb8105) & ~rb8101;
  assign rb8110 = rb7497;
  assign rb8111 = rb7498;
  assign rb8112 = rb8008;
  assign rb8113 = rb8009;
  assign rb8114 = rb7496 | rb8007;
  assign rb8115 = rb8110 & rb8112;
  assign rb8116 = rb8111 & rb8113;
  assign rb8117 = (rb8110 & ~rb8112 & ~rb8113) | (rb8112 & ~rb8110 & ~rb8111);
  assign rb8118 = (rb8111 & ~rb8112 & ~rb8113) | (rb8113 & ~rb8110 & ~rb8111);
  assign rb8119 = rb8115 | (rb8117 & ~rb8114);
  assign rb8120 = rb8116 | (rb8118 & rb8114);
  assign rb8121 = (rb8117 | rb8118) & rb8114;
  assign rb8122 = (rb8117 | rb8118) & ~rb8114;
  assign rb8123 = rb7499;
  assign rb8124 = rb7500;
  assign rb8125 = rb8010;
  assign rb8126 = rb8011;
  assign rb8127 = rb7498 | rb8009;
  assign rb8128 = rb8123 & rb8125;
  assign rb8129 = rb8124 & rb8126;
  assign rb8130 = (rb8123 & ~rb8125 & ~rb8126) | (rb8125 & ~rb8123 & ~rb8124);
  assign rb8131 = (rb8124 & ~rb8125 & ~rb8126) | (rb8126 & ~rb8123 & ~rb8124);
  assign rb8132 = rb8128 | (rb8130 & ~rb8127);
  assign rb8133 = rb8129 | (rb8131 & rb8127);
  assign rb8134 = (rb8130 | rb8131) & rb8127;
  assign rb8135 = (rb8130 | rb8131) & ~rb8127;
  assign rb8136 = rb7501;
  assign rb8137 = rb7502;
  assign rb8138 = rb8012;
  assign rb8139 = rb8013;
  assign rb8140 = rb7500 | rb8011;
  assign rb8141 = rb8136 & rb8138;
  assign rb8142 = rb8137 & rb8139;
  assign rb8143 = (rb8136 & ~rb8138 & ~rb8139) | (rb8138 & ~rb8136 & ~rb8137);
  assign rb8144 = (rb8137 & ~rb8138 & ~rb8139) | (rb8139 & ~rb8136 & ~rb8137);
  assign rb8145 = rb8141 | (rb8143 & ~rb8140);
  assign rb8146 = rb8142 | (rb8144 & rb8140);
  assign rb8147 = (rb8143 | rb8144) & rb8140;
  assign rb8148 = (rb8143 | rb8144) & ~rb8140;
  assign rb8149 = rb7503;
  assign rb8150 = rb7504;
  assign rb8151 = rb8014;
  assign rb8152 = rb8015;
  assign rb8153 = rb7502 | rb8013;
  assign rb8154 = rb8149 & rb8151;
  assign rb8155 = rb8150 & rb8152;
  assign rb8156 = (rb8149 & ~rb8151 & ~rb8152) | (rb8151 & ~rb8149 & ~rb8150);
  assign rb8157 = (rb8150 & ~rb8151 & ~rb8152) | (rb8152 & ~rb8149 & ~rb8150);
  assign rb8158 = rb8154 | (rb8156 & ~rb8153);
  assign rb8159 = rb8155 | (rb8157 & rb8153);
  assign rb8160 = (rb8156 | rb8157) & rb8153;
  assign rb8161 = (rb8156 | rb8157) & ~rb8153;
  assign rb8162 = rb7505;
  assign rb8163 = rb7506;
  assign rb8164 = rb8016;
  assign rb8165 = rb8017;
  assign rb8166 = rb7504 | rb8015;
  assign rb8167 = rb8162 & rb8164;
  assign rb8168 = rb8163 & rb8165;
  assign rb8169 = (rb8162 & ~rb8164 & ~rb8165) | (rb8164 & ~rb8162 & ~rb8163);
  assign rb8170 = (rb8163 & ~rb8164 & ~rb8165) | (rb8165 & ~rb8162 & ~rb8163);
  assign rb8171 = rb8167 | (rb8169 & ~rb8166);
  assign rb8172 = rb8168 | (rb8170 & rb8166);
  assign rb8173 = (rb8169 | rb8170) & rb8166;
  assign rb8174 = (rb8169 | rb8170) & ~rb8166;
  assign rb8175 = rb7507;
  assign rb8176 = rb7508;
  assign rb8177 = rb8018;
  assign rb8178 = rb8019;
  assign rb8179 = rb7506 | rb8017;
  assign rb8180 = rb8175 & rb8177;
  assign rb8181 = rb8176 & rb8178;
  assign rb8182 = (rb8175 & ~rb8177 & ~rb8178) | (rb8177 & ~rb8175 & ~rb8176);
  assign rb8183 = (rb8176 & ~rb8177 & ~rb8178) | (rb8178 & ~rb8175 & ~rb8176);
  assign rb8184 = rb8180 | (rb8182 & ~rb8179);
  assign rb8185 = rb8181 | (rb8183 & rb8179);
  assign rb8186 = (rb8182 | rb8183) & rb8179;
  assign rb8187 = (rb8182 | rb8183) & ~rb8179;
  assign rb8188 = rb7509;
  assign rb8189 = rb7510;
  assign rb8190 = rb8020;
  assign rb8191 = rb8021;
  assign rb8192 = rb7508 | rb8019;
  assign rb8193 = rb8188 & rb8190;
  assign rb8194 = rb8189 & rb8191;
  assign rb8195 = (rb8188 & ~rb8190 & ~rb8191) | (rb8190 & ~rb8188 & ~rb8189);
  assign rb8196 = (rb8189 & ~rb8190 & ~rb8191) | (rb8191 & ~rb8188 & ~rb8189);
  assign rb8197 = rb8193 | (rb8195 & ~rb8192);
  assign rb8198 = rb8194 | (rb8196 & rb8192);
  assign rb8199 = (rb8195 | rb8196) & rb8192;
  assign rb8200 = (rb8195 | rb8196) & ~rb8192;
  assign rb8201 = rb7511;
  assign rb8202 = rb7512;
  assign rb8203 = rb8022;
  assign rb8204 = rb8023;
  assign rb8205 = rb7510 | rb8021;
  assign rb8206 = rb8201 & rb8203;
  assign rb8207 = rb8202 & rb8204;
  assign rb8208 = (rb8201 & ~rb8203 & ~rb8204) | (rb8203 & ~rb8201 & ~rb8202);
  assign rb8209 = (rb8202 & ~rb8203 & ~rb8204) | (rb8204 & ~rb8201 & ~rb8202);
  assign rb8210 = rb8206 | (rb8208 & ~rb8205);
  assign rb8211 = rb8207 | (rb8209 & rb8205);
  assign rb8212 = (rb8208 | rb8209) & rb8205;
  assign rb8213 = (rb8208 | rb8209) & ~rb8205;
  assign rb8214 = rb7513;
  assign rb8215 = rb7514;
  assign rb8216 = rb8024;
  assign rb8217 = rb8025;
  assign rb8218 = rb7512 | rb8023;
  assign rb8219 = rb8214 & rb8216;
  assign rb8220 = rb8215 & rb8217;
  assign rb8221 = (rb8214 & ~rb8216 & ~rb8217) | (rb8216 & ~rb8214 & ~rb8215);
  assign rb8222 = (rb8215 & ~rb8216 & ~rb8217) | (rb8217 & ~rb8214 & ~rb8215);
  assign rb8223 = rb8219 | (rb8221 & ~rb8218);
  assign rb8224 = rb8220 | (rb8222 & rb8218);
  assign rb8225 = (rb8221 | rb8222) & rb8218;
  assign rb8226 = (rb8221 | rb8222) & ~rb8218;
  assign rb8227 = rb7515;
  assign rb8228 = rb7516;
  assign rb8229 = rb8026;
  assign rb8230 = rb8027;
  assign rb8231 = rb7514 | rb8025;
  assign rb8232 = rb8227 & rb8229;
  assign rb8233 = rb8228 & rb8230;
  assign rb8234 = (rb8227 & ~rb8229 & ~rb8230) | (rb8229 & ~rb8227 & ~rb8228);
  assign rb8235 = (rb8228 & ~rb8229 & ~rb8230) | (rb8230 & ~rb8227 & ~rb8228);
  assign rb8236 = rb8232 | (rb8234 & ~rb8231);
  assign rb8237 = rb8233 | (rb8235 & rb8231);
  assign rb8238 = (rb8234 | rb8235) & rb8231;
  assign rb8239 = (rb8234 | rb8235) & ~rb8231;
  assign rb8240 = rb7517;
  assign rb8241 = rb7518;
  assign rb8242 = rb8028;
  assign rb8243 = rb8029;
  assign rb8244 = rb7516 | rb8027;
  assign rb8245 = rb8240 & rb8242;
  assign rb8246 = rb8241 & rb8243;
  assign rb8247 = (rb8240 & ~rb8242 & ~rb8243) | (rb8242 & ~rb8240 & ~rb8241);
  assign rb8248 = (rb8241 & ~rb8242 & ~rb8243) | (rb8243 & ~rb8240 & ~rb8241);
  assign rb8249 = rb8245 | (rb8247 & ~rb8244);
  assign rb8250 = rb8246 | (rb8248 & rb8244);
  assign rb8251 = (rb8247 | rb8248) & rb8244;
  assign rb8252 = (rb8247 | rb8248) & ~rb8244;
  assign rb8253 = rb7519;
  assign rb8254 = rb7520;
  assign rb8255 = rb8030;
  assign rb8256 = rb8031;
  assign rb8257 = rb7518 | rb8029;
  assign rb8258 = rb8253 & rb8255;
  assign rb8259 = rb8254 & rb8256;
  assign rb8260 = (rb8253 & ~rb8255 & ~rb8256) | (rb8255 & ~rb8253 & ~rb8254);
  assign rb8261 = (rb8254 & ~rb8255 & ~rb8256) | (rb8256 & ~rb8253 & ~rb8254);
  assign rb8262 = rb8258 | (rb8260 & ~rb8257);
  assign rb8263 = rb8259 | (rb8261 & rb8257);
  assign rb8264 = (rb8260 | rb8261) & rb8257;
  assign rb8265 = (rb8260 | rb8261) & ~rb8257;
  assign rb8266 = rb7521;
  assign rb8267 = rb7522;
  assign rb8268 = rb8032;
  assign rb8269 = rb8033;
  assign rb8270 = rb7520 | rb8031;
  assign rb8271 = rb8266 & rb8268;
  assign rb8272 = rb8267 & rb8269;
  assign rb8273 = (rb8266 & ~rb8268 & ~rb8269) | (rb8268 & ~rb8266 & ~rb8267);
  assign rb8274 = (rb8267 & ~rb8268 & ~rb8269) | (rb8269 & ~rb8266 & ~rb8267);
  assign rb8275 = rb8271 | (rb8273 & ~rb8270);
  assign rb8276 = rb8272 | (rb8274 & rb8270);
  assign rb8277 = (rb8273 | rb8274) & rb8270;
  assign rb8278 = (rb8273 | rb8274) & ~rb8270;
  assign rb8279 = rb7523;
  assign rb8280 = rb7524;
  assign rb8281 = rb8034;
  assign rb8282 = rb8035;
  assign rb8283 = rb7522 | rb8033;
  assign rb8284 = rb8279 & rb8281;
  assign rb8285 = rb8280 & rb8282;
  assign rb8286 = (rb8279 & ~rb8281 & ~rb8282) | (rb8281 & ~rb8279 & ~rb8280);
  assign rb8287 = (rb8280 & ~rb8281 & ~rb8282) | (rb8282 & ~rb8279 & ~rb8280);
  assign rb8288 = rb8284 | (rb8286 & ~rb8283);
  assign rb8289 = rb8285 | (rb8287 & rb8283);
  assign rb8290 = (rb8286 | rb8287) & rb8283;
  assign rb8291 = (rb8286 | rb8287) & ~rb8283;
  assign rb8292 = rb7525;
  assign rb8293 = rb7526;
  assign rb8294 = rb8036;
  assign rb8295 = rb8037;
  assign rb8296 = rb7524 | rb8035;
  assign rb8297 = rb8292 & rb8294;
  assign rb8298 = rb8293 & rb8295;
  assign rb8299 = (rb8292 & ~rb8294 & ~rb8295) | (rb8294 & ~rb8292 & ~rb8293);
  assign rb8300 = (rb8293 & ~rb8294 & ~rb8295) | (rb8295 & ~rb8292 & ~rb8293);
  assign rb8301 = rb8297 | (rb8299 & ~rb8296);
  assign rb8302 = rb8298 | (rb8300 & rb8296);
  assign rb8303 = (rb8299 | rb8300) & rb8296;
  assign rb8304 = (rb8299 | rb8300) & ~rb8296;
  assign rb8305 = rb7527;
  assign rb8306 = rb7528;
  assign rb8307 = rb8038;
  assign rb8308 = rb8039;
  assign rb8309 = rb7526 | rb8037;
  assign rb8310 = rb8305 & rb8307;
  assign rb8311 = rb8306 & rb8308;
  assign rb8312 = (rb8305 & ~rb8307 & ~rb8308) | (rb8307 & ~rb8305 & ~rb8306);
  assign rb8313 = (rb8306 & ~rb8307 & ~rb8308) | (rb8308 & ~rb8305 & ~rb8306);
  assign rb8314 = rb8310 | (rb8312 & ~rb8309);
  assign rb8315 = rb8311 | (rb8313 & rb8309);
  assign rb8316 = (rb8312 | rb8313) & rb8309;
  assign rb8317 = (rb8312 | rb8313) & ~rb8309;
  assign rb8318 = rb7529;
  assign rb8319 = rb7530;
  assign rb8320 = rb8040;
  assign rb8321 = rb8041;
  assign rb8322 = rb7528 | rb8039;
  assign rb8323 = rb8318 & rb8320;
  assign rb8324 = rb8319 & rb8321;
  assign rb8325 = (rb8318 & ~rb8320 & ~rb8321) | (rb8320 & ~rb8318 & ~rb8319);
  assign rb8326 = (rb8319 & ~rb8320 & ~rb8321) | (rb8321 & ~rb8318 & ~rb8319);
  assign rb8327 = rb8323 | (rb8325 & ~rb8322);
  assign rb8328 = rb8324 | (rb8326 & rb8322);
  assign rb8329 = (rb8325 | rb8326) & rb8322;
  assign rb8330 = (rb8325 | rb8326) & ~rb8322;
  assign rb8331 = rb7531;
  assign rb8332 = rb7532;
  assign rb8333 = rb8042;
  assign rb8334 = rb8043;
  assign rb8335 = rb7530 | rb8041;
  assign rb8336 = rb8331 & rb8333;
  assign rb8337 = rb8332 & rb8334;
  assign rb8338 = (rb8331 & ~rb8333 & ~rb8334) | (rb8333 & ~rb8331 & ~rb8332);
  assign rb8339 = (rb8332 & ~rb8333 & ~rb8334) | (rb8334 & ~rb8331 & ~rb8332);
  assign rb8340 = rb8336 | (rb8338 & ~rb8335);
  assign rb8341 = rb8337 | (rb8339 & rb8335);
  assign rb8342 = (rb8338 | rb8339) & rb8335;
  assign rb8343 = (rb8338 | rb8339) & ~rb8335;
  assign rb8344 = rb7533;
  assign rb8345 = rb7534;
  assign rb8346 = rb8044;
  assign rb8347 = rb8045;
  assign rb8348 = rb7532 | rb8043;
  assign rb8349 = rb8344 & rb8346;
  assign rb8350 = rb8345 & rb8347;
  assign rb8351 = (rb8344 & ~rb8346 & ~rb8347) | (rb8346 & ~rb8344 & ~rb8345);
  assign rb8352 = (rb8345 & ~rb8346 & ~rb8347) | (rb8347 & ~rb8344 & ~rb8345);
  assign rb8353 = rb8349 | (rb8351 & ~rb8348);
  assign rb8354 = rb8350 | (rb8352 & rb8348);
  assign rb8355 = (rb8351 | rb8352) & rb8348;
  assign rb8356 = (rb8351 | rb8352) & ~rb8348;
  assign rb8357 = rb7535;
  assign rb8358 = rb7536;
  assign rb8359 = rb8046;
  assign rb8360 = rb8047;
  assign rb8361 = rb7534 | rb8045;
  assign rb8362 = rb8357 & rb8359;
  assign rb8363 = rb8358 & rb8360;
  assign rb8364 = (rb8357 & ~rb8359 & ~rb8360) | (rb8359 & ~rb8357 & ~rb8358);
  assign rb8365 = (rb8358 & ~rb8359 & ~rb8360) | (rb8360 & ~rb8357 & ~rb8358);
  assign rb8366 = rb8362 | (rb8364 & ~rb8361);
  assign rb8367 = rb8363 | (rb8365 & rb8361);
  assign rb8368 = (rb8364 | rb8365) & rb8361;
  assign rb8369 = (rb8364 | rb8365) & ~rb8361;
  assign rb8370 = rb7537;
  assign rb8371 = rb7538;
  assign rb8372 = rb8048;
  assign rb8373 = rb8049;
  assign rb8374 = rb7536 | rb8047;
  assign rb8375 = rb8370 & rb8372;
  assign rb8376 = rb8371 & rb8373;
  assign rb8377 = (rb8370 & ~rb8372 & ~rb8373) | (rb8372 & ~rb8370 & ~rb8371);
  assign rb8378 = (rb8371 & ~rb8372 & ~rb8373) | (rb8373 & ~rb8370 & ~rb8371);
  assign rb8379 = rb8375 | (rb8377 & ~rb8374);
  assign rb8380 = rb8376 | (rb8378 & rb8374);
  assign rb8381 = (rb8377 | rb8378) & rb8374;
  assign rb8382 = (rb8377 | rb8378) & ~rb8374;
  assign rb8383 = rb7539;
  assign rb8384 = rb7540;
  assign rb8385 = rb8050;
  assign rb8386 = rb8051;
  assign rb8387 = rb7538 | rb8049;
  assign rb8388 = rb8383 & rb8385;
  assign rb8389 = rb8384 & rb8386;
  assign rb8390 = (rb8383 & ~rb8385 & ~rb8386) | (rb8385 & ~rb8383 & ~rb8384);
  assign rb8391 = (rb8384 & ~rb8385 & ~rb8386) | (rb8386 & ~rb8383 & ~rb8384);
  assign rb8392 = rb8388 | (rb8390 & ~rb8387);
  assign rb8393 = rb8389 | (rb8391 & rb8387);
  assign rb8394 = (rb8390 | rb8391) & rb8387;
  assign rb8395 = (rb8390 | rb8391) & ~rb8387;
  assign rb8396 = rb7541;
  assign rb8397 = rb7542;
  assign rb8398 = rb8052;
  assign rb8399 = rb8053;
  assign rb8400 = rb7540 | rb8051;
  assign rb8401 = rb8396 & rb8398;
  assign rb8402 = rb8397 & rb8399;
  assign rb8403 = (rb8396 & ~rb8398 & ~rb8399) | (rb8398 & ~rb8396 & ~rb8397);
  assign rb8404 = (rb8397 & ~rb8398 & ~rb8399) | (rb8399 & ~rb8396 & ~rb8397);
  assign rb8405 = rb8401 | (rb8403 & ~rb8400);
  assign rb8406 = rb8402 | (rb8404 & rb8400);
  assign rb8407 = (rb8403 | rb8404) & rb8400;
  assign rb8408 = (rb8403 | rb8404) & ~rb8400;
  assign rb8409 = rb7543;
  assign rb8410 = rb7544;
  assign rb8411 = rb8054;
  assign rb8412 = rb8055;
  assign rb8413 = rb7542 | rb8053;
  assign rb8414 = rb8409 & rb8411;
  assign rb8415 = rb8410 & rb8412;
  assign rb8416 = (rb8409 & ~rb8411 & ~rb8412) | (rb8411 & ~rb8409 & ~rb8410);
  assign rb8417 = (rb8410 & ~rb8411 & ~rb8412) | (rb8412 & ~rb8409 & ~rb8410);
  assign rb8418 = rb8414 | (rb8416 & ~rb8413);
  assign rb8419 = rb8415 | (rb8417 & rb8413);
  assign rb8420 = (rb8416 | rb8417) & rb8413;
  assign rb8421 = (rb8416 | rb8417) & ~rb8413;
  assign rb8422 = rb7545;
  assign rb8423 = rb7546;
  assign rb8424 = rb8056;
  assign rb8425 = rb8057;
  assign rb8426 = rb7544 | rb8055;
  assign rb8427 = rb8422 & rb8424;
  assign rb8428 = rb8423 & rb8425;
  assign rb8429 = (rb8422 & ~rb8424 & ~rb8425) | (rb8424 & ~rb8422 & ~rb8423);
  assign rb8430 = (rb8423 & ~rb8424 & ~rb8425) | (rb8425 & ~rb8422 & ~rb8423);
  assign rb8431 = rb8427 | (rb8429 & ~rb8426);
  assign rb8432 = rb8428 | (rb8430 & rb8426);
  assign rb8433 = (rb8429 | rb8430) & rb8426;
  assign rb8434 = (rb8429 | rb8430) & ~rb8426;
  assign rb8435 = rb7547;
  assign rb8436 = rb7548;
  assign rb8437 = rb8058;
  assign rb8438 = rb8059;
  assign rb8439 = rb7546 | rb8057;
  assign rb8440 = rb8435 & rb8437;
  assign rb8441 = rb8436 & rb8438;
  assign rb8442 = (rb8435 & ~rb8437 & ~rb8438) | (rb8437 & ~rb8435 & ~rb8436);
  assign rb8443 = (rb8436 & ~rb8437 & ~rb8438) | (rb8438 & ~rb8435 & ~rb8436);
  assign rb8444 = rb8440 | (rb8442 & ~rb8439);
  assign rb8445 = rb8441 | (rb8443 & rb8439);
  assign rb8446 = (rb8442 | rb8443) & rb8439;
  assign rb8447 = (rb8442 | rb8443) & ~rb8439;
  assign rb8448 = rb7549;
  assign rb8449 = rb7550;
  assign rb8450 = rb8060;
  assign rb8451 = rb8061;
  assign rb8452 = rb7548 | rb8059;
  assign rb8453 = rb8448 & rb8450;
  assign rb8454 = rb8449 & rb8451;
  assign rb8455 = (rb8448 & ~rb8450 & ~rb8451) | (rb8450 & ~rb8448 & ~rb8449);
  assign rb8456 = (rb8449 & ~rb8450 & ~rb8451) | (rb8451 & ~rb8448 & ~rb8449);
  assign rb8457 = rb8453 | (rb8455 & ~rb8452);
  assign rb8458 = rb8454 | (rb8456 & rb8452);
  assign rb8459 = (rb8455 | rb8456) & rb8452;
  assign rb8460 = (rb8455 | rb8456) & ~rb8452;
  assign rb8461 = rb7551;
  assign rb8462 = rb7552;
  assign rb8463 = rb8062;
  assign rb8464 = rb8063;
  assign rb8465 = rb7550 | rb8061;
  assign rb8466 = rb8461 & rb8463;
  assign rb8467 = rb8462 & rb8464;
  assign rb8468 = (rb8461 & ~rb8463 & ~rb8464) | (rb8463 & ~rb8461 & ~rb8462);
  assign rb8469 = (rb8462 & ~rb8463 & ~rb8464) | (rb8464 & ~rb8461 & ~rb8462);
  assign rb8470 = rb8466 | (rb8468 & ~rb8465);
  assign rb8471 = rb8467 | (rb8469 & rb8465);
  assign rb8472 = (rb8468 | rb8469) & rb8465;
  assign rb8473 = (rb8468 | rb8469) & ~rb8465;
  assign rb8474 = rb7553;
  assign rb8475 = rb7554;
  assign rb8476 = rb8064;
  assign rb8477 = rb8065;
  assign rb8478 = rb7552 | rb8063;
  assign rb8479 = rb8474 & rb8476;
  assign rb8480 = rb8475 & rb8477;
  assign rb8481 = (rb8474 & ~rb8476 & ~rb8477) | (rb8476 & ~rb8474 & ~rb8475);
  assign rb8482 = (rb8475 & ~rb8476 & ~rb8477) | (rb8477 & ~rb8474 & ~rb8475);
  assign rb8483 = rb8479 | (rb8481 & ~rb8478);
  assign rb8484 = rb8480 | (rb8482 & rb8478);
  assign rb8485 = (rb8481 | rb8482) & rb8478;
  assign rb8486 = (rb8481 | rb8482) & ~rb8478;
  assign rb8487 = rb7555;
  assign rb8488 = rb7556;
  assign rb8489 = rb8066;
  assign rb8490 = rb8067;
  assign rb8491 = rb7554 | rb8065;
  assign rb8492 = rb8487 & rb8489;
  assign rb8493 = rb8488 & rb8490;
  assign rb8494 = (rb8487 & ~rb8489 & ~rb8490) | (rb8489 & ~rb8487 & ~rb8488);
  assign rb8495 = (rb8488 & ~rb8489 & ~rb8490) | (rb8490 & ~rb8487 & ~rb8488);
  assign rb8496 = rb8492 | (rb8494 & ~rb8491);
  assign rb8497 = rb8493 | (rb8495 & rb8491);
  assign rb8498 = (rb8494 | rb8495) & rb8491;
  assign rb8499 = (rb8494 | rb8495) & ~rb8491;
  assign rb8500 = rb7557;
  assign rb8501 = rb7558;
  assign rb8502 = rb8068;
  assign rb8503 = rb8069;
  assign rb8504 = rb7556 | rb8067;
  assign rb8505 = rb8500 & rb8502;
  assign rb8506 = rb8501 & rb8503;
  assign rb8507 = (rb8500 & ~rb8502 & ~rb8503) | (rb8502 & ~rb8500 & ~rb8501);
  assign rb8508 = (rb8501 & ~rb8502 & ~rb8503) | (rb8503 & ~rb8500 & ~rb8501);
  assign rb8509 = rb8505 | (rb8507 & ~rb8504);
  assign rb8510 = rb8506 | (rb8508 & rb8504);
  assign rb8511 = (rb8507 | rb8508) & rb8504;
  assign rb8512 = (rb8507 | rb8508) & ~rb8504;
  assign rb8513 = (rb8082 & ~1'b0) | (1'b0 & ~rb8083);
  assign rb8514 = (rb8083 & ~1'b0) | (1'b0 & ~rb8082);
  assign rb8515 = (rb8095 & ~rb8081) | (rb8080 & ~rb8096);
  assign rb8516 = (rb8096 & ~rb8080) | (rb8081 & ~rb8095);
  assign rb8517 = (rb8108 & ~rb8094) | (rb8093 & ~rb8109);
  assign rb8518 = (rb8109 & ~rb8093) | (rb8094 & ~rb8108);
  assign rb8519 = (rb8121 & ~rb8107) | (rb8106 & ~rb8122);
  assign rb8520 = (rb8122 & ~rb8106) | (rb8107 & ~rb8121);
  assign rb8521 = (rb8134 & ~rb8120) | (rb8119 & ~rb8135);
  assign rb8522 = (rb8135 & ~rb8119) | (rb8120 & ~rb8134);
  assign rb8523 = (rb8147 & ~rb8133) | (rb8132 & ~rb8148);
  assign rb8524 = (rb8148 & ~rb8132) | (rb8133 & ~rb8147);
  assign rb8525 = (rb8160 & ~rb8146) | (rb8145 & ~rb8161);
  assign rb8526 = (rb8161 & ~rb8145) | (rb8146 & ~rb8160);
  assign rb8527 = (rb8173 & ~rb8159) | (rb8158 & ~rb8174);
  assign rb8528 = (rb8174 & ~rb8158) | (rb8159 & ~rb8173);
  assign rb8529 = (rb8186 & ~rb8172) | (rb8171 & ~rb8187);
  assign rb8530 = (rb8187 & ~rb8171) | (rb8172 & ~rb8186);
  assign rb8531 = (rb8199 & ~rb8185) | (rb8184 & ~rb8200);
  assign rb8532 = (rb8200 & ~rb8184) | (rb8185 & ~rb8199);
  assign rb8533 = (rb8212 & ~rb8198) | (rb8197 & ~rb8213);
  assign rb8534 = (rb8213 & ~rb8197) | (rb8198 & ~rb8212);
  assign rb8535 = (rb8225 & ~rb8211) | (rb8210 & ~rb8226);
  assign rb8536 = (rb8226 & ~rb8210) | (rb8211 & ~rb8225);
  assign rb8537 = (rb8238 & ~rb8224) | (rb8223 & ~rb8239);
  assign rb8538 = (rb8239 & ~rb8223) | (rb8224 & ~rb8238);
  assign rb8539 = (rb8251 & ~rb8237) | (rb8236 & ~rb8252);
  assign rb8540 = (rb8252 & ~rb8236) | (rb8237 & ~rb8251);
  assign rb8541 = (rb8264 & ~rb8250) | (rb8249 & ~rb8265);
  assign rb8542 = (rb8265 & ~rb8249) | (rb8250 & ~rb8264);
  assign rb8543 = (rb8277 & ~rb8263) | (rb8262 & ~rb8278);
  assign rb8544 = (rb8278 & ~rb8262) | (rb8263 & ~rb8277);
  assign rb8545 = (rb8290 & ~rb8276) | (rb8275 & ~rb8291);
  assign rb8546 = (rb8291 & ~rb8275) | (rb8276 & ~rb8290);
  assign rb8547 = (rb8303 & ~rb8289) | (rb8288 & ~rb8304);
  assign rb8548 = (rb8304 & ~rb8288) | (rb8289 & ~rb8303);
  assign rb8549 = (rb8316 & ~rb8302) | (rb8301 & ~rb8317);
  assign rb8550 = (rb8317 & ~rb8301) | (rb8302 & ~rb8316);
  assign rb8551 = (rb8329 & ~rb8315) | (rb8314 & ~rb8330);
  assign rb8552 = (rb8330 & ~rb8314) | (rb8315 & ~rb8329);
  assign rb8553 = (rb8342 & ~rb8328) | (rb8327 & ~rb8343);
  assign rb8554 = (rb8343 & ~rb8327) | (rb8328 & ~rb8342);
  assign rb8555 = (rb8355 & ~rb8341) | (rb8340 & ~rb8356);
  assign rb8556 = (rb8356 & ~rb8340) | (rb8341 & ~rb8355);
  assign rb8557 = (rb8368 & ~rb8354) | (rb8353 & ~rb8369);
  assign rb8558 = (rb8369 & ~rb8353) | (rb8354 & ~rb8368);
  assign rb8559 = (rb8381 & ~rb8367) | (rb8366 & ~rb8382);
  assign rb8560 = (rb8382 & ~rb8366) | (rb8367 & ~rb8381);
  assign rb8561 = (rb8394 & ~rb8380) | (rb8379 & ~rb8395);
  assign rb8562 = (rb8395 & ~rb8379) | (rb8380 & ~rb8394);
  assign rb8563 = (rb8407 & ~rb8393) | (rb8392 & ~rb8408);
  assign rb8564 = (rb8408 & ~rb8392) | (rb8393 & ~rb8407);
  assign rb8565 = (rb8420 & ~rb8406) | (rb8405 & ~rb8421);
  assign rb8566 = (rb8421 & ~rb8405) | (rb8406 & ~rb8420);
  assign rb8567 = (rb8433 & ~rb8419) | (rb8418 & ~rb8434);
  assign rb8568 = (rb8434 & ~rb8418) | (rb8419 & ~rb8433);
  assign rb8569 = (rb8446 & ~rb8432) | (rb8431 & ~rb8447);
  assign rb8570 = (rb8447 & ~rb8431) | (rb8432 & ~rb8446);
  assign rb8571 = (rb8459 & ~rb8445) | (rb8444 & ~rb8460);
  assign rb8572 = (rb8460 & ~rb8444) | (rb8445 & ~rb8459);
  assign rb8573 = (rb8472 & ~rb8458) | (rb8457 & ~rb8473);
  assign rb8574 = (rb8473 & ~rb8457) | (rb8458 & ~rb8472);
  assign rb8575 = (rb8485 & ~rb8471) | (rb8470 & ~rb8486);
  assign rb8576 = (rb8486 & ~rb8470) | (rb8471 & ~rb8485);
  assign rb8577 = (rb8498 & ~rb8484) | (rb8483 & ~rb8499);
  assign rb8578 = (rb8499 & ~rb8483) | (rb8484 & ~rb8498);
  assign rb8579 = (rb8511 & ~rb8497) | (rb8496 & ~rb8512);
  assign rb8580 = (rb8512 & ~rb8496) | (rb8497 & ~rb8511);
  assign rb8581 = (1'b0 & ~rb8510) | (rb8509 & ~1'b0);
  assign rb8582 = (1'b0 & ~rb8509) | (rb8510 & ~1'b0);
  assign rb8583 = rb8513;
  assign rb8584 = rb8514;
  assign rb8585 = 1'b0;
  assign rb8586 = 1'b0;
  assign rb8587 = rb8583 & rb8585;
  assign rb8588 = rb8584 & rb8586;
  assign rb8589 = (rb8583 & ~rb8585 & ~rb8586) | (rb8585 & ~rb8583 & ~rb8584);
  assign rb8590 = (rb8584 & ~rb8585 & ~rb8586) | (rb8586 & ~rb8583 & ~rb8584);
  assign rb8591 = rb8587 | (rb8589 & ~1'b0);
  assign rb8592 = rb8588 | (rb8590 & 1'b0);
  assign rb8593 = (rb8589 | rb8590) & 1'b0;
  assign rb8594 = (rb8589 | rb8590) & ~1'b0;
  assign rb8595 = rb8515;
  assign rb8596 = rb8516;
  assign rb8597 = 1'b0;
  assign rb8598 = 1'b0;
  assign rb8599 = rb8514 | 1'b0;
  assign rb8600 = rb8595 & rb8597;
  assign rb8601 = rb8596 & rb8598;
  assign rb8602 = (rb8595 & ~rb8597 & ~rb8598) | (rb8597 & ~rb8595 & ~rb8596);
  assign rb8603 = (rb8596 & ~rb8597 & ~rb8598) | (rb8598 & ~rb8595 & ~rb8596);
  assign rb8604 = rb8600 | (rb8602 & ~rb8599);
  assign rb8605 = rb8601 | (rb8603 & rb8599);
  assign rb8606 = (rb8602 | rb8603) & rb8599;
  assign rb8607 = (rb8602 | rb8603) & ~rb8599;
  assign rb8608 = rb8517;
  assign rb8609 = rb8518;
  assign rb8610 = 1'b0;
  assign rb8611 = 1'b0;
  assign rb8612 = rb8516 | 1'b0;
  assign rb8613 = rb8608 & rb8610;
  assign rb8614 = rb8609 & rb8611;
  assign rb8615 = (rb8608 & ~rb8610 & ~rb8611) | (rb8610 & ~rb8608 & ~rb8609);
  assign rb8616 = (rb8609 & ~rb8610 & ~rb8611) | (rb8611 & ~rb8608 & ~rb8609);
  assign rb8617 = rb8613 | (rb8615 & ~rb8612);
  assign rb8618 = rb8614 | (rb8616 & rb8612);
  assign rb8619 = (rb8615 | rb8616) & rb8612;
  assign rb8620 = (rb8615 | rb8616) & ~rb8612;
  assign rb8621 = rb8519;
  assign rb8622 = rb8520;
  assign rb8623 = 1'b0;
  assign rb8624 = 1'b0;
  assign rb8625 = rb8518 | 1'b0;
  assign rb8626 = rb8621 & rb8623;
  assign rb8627 = rb8622 & rb8624;
  assign rb8628 = (rb8621 & ~rb8623 & ~rb8624) | (rb8623 & ~rb8621 & ~rb8622);
  assign rb8629 = (rb8622 & ~rb8623 & ~rb8624) | (rb8624 & ~rb8621 & ~rb8622);
  assign rb8630 = rb8626 | (rb8628 & ~rb8625);
  assign rb8631 = rb8627 | (rb8629 & rb8625);
  assign rb8632 = (rb8628 | rb8629) & rb8625;
  assign rb8633 = (rb8628 | rb8629) & ~rb8625;
  assign rb8634 = rb8521;
  assign rb8635 = rb8522;
  assign rb8636 = 1'b0;
  assign rb8637 = 1'b0;
  assign rb8638 = rb8520 | 1'b0;
  assign rb8639 = rb8634 & rb8636;
  assign rb8640 = rb8635 & rb8637;
  assign rb8641 = (rb8634 & ~rb8636 & ~rb8637) | (rb8636 & ~rb8634 & ~rb8635);
  assign rb8642 = (rb8635 & ~rb8636 & ~rb8637) | (rb8637 & ~rb8634 & ~rb8635);
  assign rb8643 = rb8639 | (rb8641 & ~rb8638);
  assign rb8644 = rb8640 | (rb8642 & rb8638);
  assign rb8645 = (rb8641 | rb8642) & rb8638;
  assign rb8646 = (rb8641 | rb8642) & ~rb8638;
  assign rb8647 = rb8523;
  assign rb8648 = rb8524;
  assign rb8649 = 1'b0;
  assign rb8650 = 1'b0;
  assign rb8651 = rb8522 | 1'b0;
  assign rb8652 = rb8647 & rb8649;
  assign rb8653 = rb8648 & rb8650;
  assign rb8654 = (rb8647 & ~rb8649 & ~rb8650) | (rb8649 & ~rb8647 & ~rb8648);
  assign rb8655 = (rb8648 & ~rb8649 & ~rb8650) | (rb8650 & ~rb8647 & ~rb8648);
  assign rb8656 = rb8652 | (rb8654 & ~rb8651);
  assign rb8657 = rb8653 | (rb8655 & rb8651);
  assign rb8658 = (rb8654 | rb8655) & rb8651;
  assign rb8659 = (rb8654 | rb8655) & ~rb8651;
  assign rb8660 = rb8525;
  assign rb8661 = rb8526;
  assign rb8662 = 1'b0;
  assign rb8663 = 1'b0;
  assign rb8664 = rb8524 | 1'b0;
  assign rb8665 = rb8660 & rb8662;
  assign rb8666 = rb8661 & rb8663;
  assign rb8667 = (rb8660 & ~rb8662 & ~rb8663) | (rb8662 & ~rb8660 & ~rb8661);
  assign rb8668 = (rb8661 & ~rb8662 & ~rb8663) | (rb8663 & ~rb8660 & ~rb8661);
  assign rb8669 = rb8665 | (rb8667 & ~rb8664);
  assign rb8670 = rb8666 | (rb8668 & rb8664);
  assign rb8671 = (rb8667 | rb8668) & rb8664;
  assign rb8672 = (rb8667 | rb8668) & ~rb8664;
  assign rb8673 = rb8527;
  assign rb8674 = rb8528;
  assign rb8675 = 1'b0;
  assign rb8676 = 1'b0;
  assign rb8677 = rb8526 | 1'b0;
  assign rb8678 = rb8673 & rb8675;
  assign rb8679 = rb8674 & rb8676;
  assign rb8680 = (rb8673 & ~rb8675 & ~rb8676) | (rb8675 & ~rb8673 & ~rb8674);
  assign rb8681 = (rb8674 & ~rb8675 & ~rb8676) | (rb8676 & ~rb8673 & ~rb8674);
  assign rb8682 = rb8678 | (rb8680 & ~rb8677);
  assign rb8683 = rb8679 | (rb8681 & rb8677);
  assign rb8684 = (rb8680 | rb8681) & rb8677;
  assign rb8685 = (rb8680 | rb8681) & ~rb8677;
  assign rb8686 = rb8529;
  assign rb8687 = rb8530;
  assign rb8688 = 1'b0;
  assign rb8689 = 1'b0;
  assign rb8690 = rb8528 | 1'b0;
  assign rb8691 = rb8686 & rb8688;
  assign rb8692 = rb8687 & rb8689;
  assign rb8693 = (rb8686 & ~rb8688 & ~rb8689) | (rb8688 & ~rb8686 & ~rb8687);
  assign rb8694 = (rb8687 & ~rb8688 & ~rb8689) | (rb8689 & ~rb8686 & ~rb8687);
  assign rb8695 = rb8691 | (rb8693 & ~rb8690);
  assign rb8696 = rb8692 | (rb8694 & rb8690);
  assign rb8697 = (rb8693 | rb8694) & rb8690;
  assign rb8698 = (rb8693 | rb8694) & ~rb8690;
  assign rb8699 = rb8531;
  assign rb8700 = rb8532;
  assign rb8701 = 1'b0;
  assign rb8702 = 1'b0;
  assign rb8703 = rb8530 | 1'b0;
  assign rb8704 = rb8699 & rb8701;
  assign rb8705 = rb8700 & rb8702;
  assign rb8706 = (rb8699 & ~rb8701 & ~rb8702) | (rb8701 & ~rb8699 & ~rb8700);
  assign rb8707 = (rb8700 & ~rb8701 & ~rb8702) | (rb8702 & ~rb8699 & ~rb8700);
  assign rb8708 = rb8704 | (rb8706 & ~rb8703);
  assign rb8709 = rb8705 | (rb8707 & rb8703);
  assign rb8710 = (rb8706 | rb8707) & rb8703;
  assign rb8711 = (rb8706 | rb8707) & ~rb8703;
  assign rb8712 = rb8533;
  assign rb8713 = rb8534;
  assign rb8714 = 1'b0;
  assign rb8715 = 1'b0;
  assign rb8716 = rb8532 | 1'b0;
  assign rb8717 = rb8712 & rb8714;
  assign rb8718 = rb8713 & rb8715;
  assign rb8719 = (rb8712 & ~rb8714 & ~rb8715) | (rb8714 & ~rb8712 & ~rb8713);
  assign rb8720 = (rb8713 & ~rb8714 & ~rb8715) | (rb8715 & ~rb8712 & ~rb8713);
  assign rb8721 = rb8717 | (rb8719 & ~rb8716);
  assign rb8722 = rb8718 | (rb8720 & rb8716);
  assign rb8723 = (rb8719 | rb8720) & rb8716;
  assign rb8724 = (rb8719 | rb8720) & ~rb8716;
  assign rb8725 = rb8535;
  assign rb8726 = rb8536;
  assign rb8727 = 1'b0;
  assign rb8728 = 1'b0;
  assign rb8729 = rb8534 | 1'b0;
  assign rb8730 = rb8725 & rb8727;
  assign rb8731 = rb8726 & rb8728;
  assign rb8732 = (rb8725 & ~rb8727 & ~rb8728) | (rb8727 & ~rb8725 & ~rb8726);
  assign rb8733 = (rb8726 & ~rb8727 & ~rb8728) | (rb8728 & ~rb8725 & ~rb8726);
  assign rb8734 = rb8730 | (rb8732 & ~rb8729);
  assign rb8735 = rb8731 | (rb8733 & rb8729);
  assign rb8736 = (rb8732 | rb8733) & rb8729;
  assign rb8737 = (rb8732 | rb8733) & ~rb8729;
  assign rb8738 = rb8537;
  assign rb8739 = rb8538;
  assign rb8740 = 1'b0;
  assign rb8741 = 1'b0;
  assign rb8742 = rb8536 | 1'b0;
  assign rb8743 = rb8738 & rb8740;
  assign rb8744 = rb8739 & rb8741;
  assign rb8745 = (rb8738 & ~rb8740 & ~rb8741) | (rb8740 & ~rb8738 & ~rb8739);
  assign rb8746 = (rb8739 & ~rb8740 & ~rb8741) | (rb8741 & ~rb8738 & ~rb8739);
  assign rb8747 = rb8743 | (rb8745 & ~rb8742);
  assign rb8748 = rb8744 | (rb8746 & rb8742);
  assign rb8749 = (rb8745 | rb8746) & rb8742;
  assign rb8750 = (rb8745 | rb8746) & ~rb8742;
  assign rb8751 = rb8539;
  assign rb8752 = rb8540;
  assign rb8753 = 1'b0;
  assign rb8754 = 1'b0;
  assign rb8755 = rb8538 | 1'b0;
  assign rb8756 = rb8751 & rb8753;
  assign rb8757 = rb8752 & rb8754;
  assign rb8758 = (rb8751 & ~rb8753 & ~rb8754) | (rb8753 & ~rb8751 & ~rb8752);
  assign rb8759 = (rb8752 & ~rb8753 & ~rb8754) | (rb8754 & ~rb8751 & ~rb8752);
  assign rb8760 = rb8756 | (rb8758 & ~rb8755);
  assign rb8761 = rb8757 | (rb8759 & rb8755);
  assign rb8762 = (rb8758 | rb8759) & rb8755;
  assign rb8763 = (rb8758 | rb8759) & ~rb8755;
  assign rb8764 = rb8541;
  assign rb8765 = rb8542;
  assign rb8766 = 1'b0;
  assign rb8767 = 1'b0;
  assign rb8768 = rb8540 | 1'b0;
  assign rb8769 = rb8764 & rb8766;
  assign rb8770 = rb8765 & rb8767;
  assign rb8771 = (rb8764 & ~rb8766 & ~rb8767) | (rb8766 & ~rb8764 & ~rb8765);
  assign rb8772 = (rb8765 & ~rb8766 & ~rb8767) | (rb8767 & ~rb8764 & ~rb8765);
  assign rb8773 = rb8769 | (rb8771 & ~rb8768);
  assign rb8774 = rb8770 | (rb8772 & rb8768);
  assign rb8775 = (rb8771 | rb8772) & rb8768;
  assign rb8776 = (rb8771 | rb8772) & ~rb8768;
  assign rb8777 = rb8543;
  assign rb8778 = rb8544;
  assign rb8779 = 1'b0;
  assign rb8780 = 1'b0;
  assign rb8781 = rb8542 | 1'b0;
  assign rb8782 = rb8777 & rb8779;
  assign rb8783 = rb8778 & rb8780;
  assign rb8784 = (rb8777 & ~rb8779 & ~rb8780) | (rb8779 & ~rb8777 & ~rb8778);
  assign rb8785 = (rb8778 & ~rb8779 & ~rb8780) | (rb8780 & ~rb8777 & ~rb8778);
  assign rb8786 = rb8782 | (rb8784 & ~rb8781);
  assign rb8787 = rb8783 | (rb8785 & rb8781);
  assign rb8788 = (rb8784 | rb8785) & rb8781;
  assign rb8789 = (rb8784 | rb8785) & ~rb8781;
  assign rb8790 = rb8545;
  assign rb8791 = rb8546;
  assign rb8792 = pp882;
  assign rb8793 = pp883;
  assign rb8794 = rb8544 | 1'b0;
  assign rb8795 = rb8790 & rb8792;
  assign rb8796 = rb8791 & rb8793;
  assign rb8797 = (rb8790 & ~rb8792 & ~rb8793) | (rb8792 & ~rb8790 & ~rb8791);
  assign rb8798 = (rb8791 & ~rb8792 & ~rb8793) | (rb8793 & ~rb8790 & ~rb8791);
  assign rb8799 = rb8795 | (rb8797 & ~rb8794);
  assign rb8800 = rb8796 | (rb8798 & rb8794);
  assign rb8801 = (rb8797 | rb8798) & rb8794;
  assign rb8802 = (rb8797 | rb8798) & ~rb8794;
  assign rb8803 = rb8547;
  assign rb8804 = rb8548;
  assign rb8805 = pp884;
  assign rb8806 = pp885;
  assign rb8807 = rb8546 | pp883;
  assign rb8808 = rb8803 & rb8805;
  assign rb8809 = rb8804 & rb8806;
  assign rb8810 = (rb8803 & ~rb8805 & ~rb8806) | (rb8805 & ~rb8803 & ~rb8804);
  assign rb8811 = (rb8804 & ~rb8805 & ~rb8806) | (rb8806 & ~rb8803 & ~rb8804);
  assign rb8812 = rb8808 | (rb8810 & ~rb8807);
  assign rb8813 = rb8809 | (rb8811 & rb8807);
  assign rb8814 = (rb8810 | rb8811) & rb8807;
  assign rb8815 = (rb8810 | rb8811) & ~rb8807;
  assign rb8816 = rb8549;
  assign rb8817 = rb8550;
  assign rb8818 = pp886;
  assign rb8819 = pp887;
  assign rb8820 = rb8548 | pp885;
  assign rb8821 = rb8816 & rb8818;
  assign rb8822 = rb8817 & rb8819;
  assign rb8823 = (rb8816 & ~rb8818 & ~rb8819) | (rb8818 & ~rb8816 & ~rb8817);
  assign rb8824 = (rb8817 & ~rb8818 & ~rb8819) | (rb8819 & ~rb8816 & ~rb8817);
  assign rb8825 = rb8821 | (rb8823 & ~rb8820);
  assign rb8826 = rb8822 | (rb8824 & rb8820);
  assign rb8827 = (rb8823 | rb8824) & rb8820;
  assign rb8828 = (rb8823 | rb8824) & ~rb8820;
  assign rb8829 = rb8551;
  assign rb8830 = rb8552;
  assign rb8831 = pp888;
  assign rb8832 = pp889;
  assign rb8833 = rb8550 | pp887;
  assign rb8834 = rb8829 & rb8831;
  assign rb8835 = rb8830 & rb8832;
  assign rb8836 = (rb8829 & ~rb8831 & ~rb8832) | (rb8831 & ~rb8829 & ~rb8830);
  assign rb8837 = (rb8830 & ~rb8831 & ~rb8832) | (rb8832 & ~rb8829 & ~rb8830);
  assign rb8838 = rb8834 | (rb8836 & ~rb8833);
  assign rb8839 = rb8835 | (rb8837 & rb8833);
  assign rb8840 = (rb8836 | rb8837) & rb8833;
  assign rb8841 = (rb8836 | rb8837) & ~rb8833;
  assign rb8842 = rb8553;
  assign rb8843 = rb8554;
  assign rb8844 = pp890;
  assign rb8845 = pp891;
  assign rb8846 = rb8552 | pp889;
  assign rb8847 = rb8842 & rb8844;
  assign rb8848 = rb8843 & rb8845;
  assign rb8849 = (rb8842 & ~rb8844 & ~rb8845) | (rb8844 & ~rb8842 & ~rb8843);
  assign rb8850 = (rb8843 & ~rb8844 & ~rb8845) | (rb8845 & ~rb8842 & ~rb8843);
  assign rb8851 = rb8847 | (rb8849 & ~rb8846);
  assign rb8852 = rb8848 | (rb8850 & rb8846);
  assign rb8853 = (rb8849 | rb8850) & rb8846;
  assign rb8854 = (rb8849 | rb8850) & ~rb8846;
  assign rb8855 = rb8555;
  assign rb8856 = rb8556;
  assign rb8857 = pp892;
  assign rb8858 = pp893;
  assign rb8859 = rb8554 | pp891;
  assign rb8860 = rb8855 & rb8857;
  assign rb8861 = rb8856 & rb8858;
  assign rb8862 = (rb8855 & ~rb8857 & ~rb8858) | (rb8857 & ~rb8855 & ~rb8856);
  assign rb8863 = (rb8856 & ~rb8857 & ~rb8858) | (rb8858 & ~rb8855 & ~rb8856);
  assign rb8864 = rb8860 | (rb8862 & ~rb8859);
  assign rb8865 = rb8861 | (rb8863 & rb8859);
  assign rb8866 = (rb8862 | rb8863) & rb8859;
  assign rb8867 = (rb8862 | rb8863) & ~rb8859;
  assign rb8868 = rb8557;
  assign rb8869 = rb8558;
  assign rb8870 = pp894;
  assign rb8871 = pp895;
  assign rb8872 = rb8556 | pp893;
  assign rb8873 = rb8868 & rb8870;
  assign rb8874 = rb8869 & rb8871;
  assign rb8875 = (rb8868 & ~rb8870 & ~rb8871) | (rb8870 & ~rb8868 & ~rb8869);
  assign rb8876 = (rb8869 & ~rb8870 & ~rb8871) | (rb8871 & ~rb8868 & ~rb8869);
  assign rb8877 = rb8873 | (rb8875 & ~rb8872);
  assign rb8878 = rb8874 | (rb8876 & rb8872);
  assign rb8879 = (rb8875 | rb8876) & rb8872;
  assign rb8880 = (rb8875 | rb8876) & ~rb8872;
  assign rb8881 = rb8559;
  assign rb8882 = rb8560;
  assign rb8883 = pp896;
  assign rb8884 = pp897;
  assign rb8885 = rb8558 | pp895;
  assign rb8886 = rb8881 & rb8883;
  assign rb8887 = rb8882 & rb8884;
  assign rb8888 = (rb8881 & ~rb8883 & ~rb8884) | (rb8883 & ~rb8881 & ~rb8882);
  assign rb8889 = (rb8882 & ~rb8883 & ~rb8884) | (rb8884 & ~rb8881 & ~rb8882);
  assign rb8890 = rb8886 | (rb8888 & ~rb8885);
  assign rb8891 = rb8887 | (rb8889 & rb8885);
  assign rb8892 = (rb8888 | rb8889) & rb8885;
  assign rb8893 = (rb8888 | rb8889) & ~rb8885;
  assign rb8894 = rb8561;
  assign rb8895 = rb8562;
  assign rb8896 = pp898;
  assign rb8897 = pp899;
  assign rb8898 = rb8560 | pp897;
  assign rb8899 = rb8894 & rb8896;
  assign rb8900 = rb8895 & rb8897;
  assign rb8901 = (rb8894 & ~rb8896 & ~rb8897) | (rb8896 & ~rb8894 & ~rb8895);
  assign rb8902 = (rb8895 & ~rb8896 & ~rb8897) | (rb8897 & ~rb8894 & ~rb8895);
  assign rb8903 = rb8899 | (rb8901 & ~rb8898);
  assign rb8904 = rb8900 | (rb8902 & rb8898);
  assign rb8905 = (rb8901 | rb8902) & rb8898;
  assign rb8906 = (rb8901 | rb8902) & ~rb8898;
  assign rb8907 = rb8563;
  assign rb8908 = rb8564;
  assign rb8909 = pp900;
  assign rb8910 = pp901;
  assign rb8911 = rb8562 | pp899;
  assign rb8912 = rb8907 & rb8909;
  assign rb8913 = rb8908 & rb8910;
  assign rb8914 = (rb8907 & ~rb8909 & ~rb8910) | (rb8909 & ~rb8907 & ~rb8908);
  assign rb8915 = (rb8908 & ~rb8909 & ~rb8910) | (rb8910 & ~rb8907 & ~rb8908);
  assign rb8916 = rb8912 | (rb8914 & ~rb8911);
  assign rb8917 = rb8913 | (rb8915 & rb8911);
  assign rb8918 = (rb8914 | rb8915) & rb8911;
  assign rb8919 = (rb8914 | rb8915) & ~rb8911;
  assign rb8920 = rb8565;
  assign rb8921 = rb8566;
  assign rb8922 = pp902;
  assign rb8923 = pp903;
  assign rb8924 = rb8564 | pp901;
  assign rb8925 = rb8920 & rb8922;
  assign rb8926 = rb8921 & rb8923;
  assign rb8927 = (rb8920 & ~rb8922 & ~rb8923) | (rb8922 & ~rb8920 & ~rb8921);
  assign rb8928 = (rb8921 & ~rb8922 & ~rb8923) | (rb8923 & ~rb8920 & ~rb8921);
  assign rb8929 = rb8925 | (rb8927 & ~rb8924);
  assign rb8930 = rb8926 | (rb8928 & rb8924);
  assign rb8931 = (rb8927 | rb8928) & rb8924;
  assign rb8932 = (rb8927 | rb8928) & ~rb8924;
  assign rb8933 = rb8567;
  assign rb8934 = rb8568;
  assign rb8935 = pp904;
  assign rb8936 = pp905;
  assign rb8937 = rb8566 | pp903;
  assign rb8938 = rb8933 & rb8935;
  assign rb8939 = rb8934 & rb8936;
  assign rb8940 = (rb8933 & ~rb8935 & ~rb8936) | (rb8935 & ~rb8933 & ~rb8934);
  assign rb8941 = (rb8934 & ~rb8935 & ~rb8936) | (rb8936 & ~rb8933 & ~rb8934);
  assign rb8942 = rb8938 | (rb8940 & ~rb8937);
  assign rb8943 = rb8939 | (rb8941 & rb8937);
  assign rb8944 = (rb8940 | rb8941) & rb8937;
  assign rb8945 = (rb8940 | rb8941) & ~rb8937;
  assign rb8946 = rb8569;
  assign rb8947 = rb8570;
  assign rb8948 = pp906;
  assign rb8949 = pp907;
  assign rb8950 = rb8568 | pp905;
  assign rb8951 = rb8946 & rb8948;
  assign rb8952 = rb8947 & rb8949;
  assign rb8953 = (rb8946 & ~rb8948 & ~rb8949) | (rb8948 & ~rb8946 & ~rb8947);
  assign rb8954 = (rb8947 & ~rb8948 & ~rb8949) | (rb8949 & ~rb8946 & ~rb8947);
  assign rb8955 = rb8951 | (rb8953 & ~rb8950);
  assign rb8956 = rb8952 | (rb8954 & rb8950);
  assign rb8957 = (rb8953 | rb8954) & rb8950;
  assign rb8958 = (rb8953 | rb8954) & ~rb8950;
  assign rb8959 = rb8571;
  assign rb8960 = rb8572;
  assign rb8961 = pp908;
  assign rb8962 = pp909;
  assign rb8963 = rb8570 | pp907;
  assign rb8964 = rb8959 & rb8961;
  assign rb8965 = rb8960 & rb8962;
  assign rb8966 = (rb8959 & ~rb8961 & ~rb8962) | (rb8961 & ~rb8959 & ~rb8960);
  assign rb8967 = (rb8960 & ~rb8961 & ~rb8962) | (rb8962 & ~rb8959 & ~rb8960);
  assign rb8968 = rb8964 | (rb8966 & ~rb8963);
  assign rb8969 = rb8965 | (rb8967 & rb8963);
  assign rb8970 = (rb8966 | rb8967) & rb8963;
  assign rb8971 = (rb8966 | rb8967) & ~rb8963;
  assign rb8972 = rb8573;
  assign rb8973 = rb8574;
  assign rb8974 = pp910;
  assign rb8975 = pp911;
  assign rb8976 = rb8572 | pp909;
  assign rb8977 = rb8972 & rb8974;
  assign rb8978 = rb8973 & rb8975;
  assign rb8979 = (rb8972 & ~rb8974 & ~rb8975) | (rb8974 & ~rb8972 & ~rb8973);
  assign rb8980 = (rb8973 & ~rb8974 & ~rb8975) | (rb8975 & ~rb8972 & ~rb8973);
  assign rb8981 = rb8977 | (rb8979 & ~rb8976);
  assign rb8982 = rb8978 | (rb8980 & rb8976);
  assign rb8983 = (rb8979 | rb8980) & rb8976;
  assign rb8984 = (rb8979 | rb8980) & ~rb8976;
  assign rb8985 = rb8575;
  assign rb8986 = rb8576;
  assign rb8987 = pp912;
  assign rb8988 = pp913;
  assign rb8989 = rb8574 | pp911;
  assign rb8990 = rb8985 & rb8987;
  assign rb8991 = rb8986 & rb8988;
  assign rb8992 = (rb8985 & ~rb8987 & ~rb8988) | (rb8987 & ~rb8985 & ~rb8986);
  assign rb8993 = (rb8986 & ~rb8987 & ~rb8988) | (rb8988 & ~rb8985 & ~rb8986);
  assign rb8994 = rb8990 | (rb8992 & ~rb8989);
  assign rb8995 = rb8991 | (rb8993 & rb8989);
  assign rb8996 = (rb8992 | rb8993) & rb8989;
  assign rb8997 = (rb8992 | rb8993) & ~rb8989;
  assign rb8998 = rb8577;
  assign rb8999 = rb8578;
  assign rb9000 = pp914;
  assign rb9001 = pp915;
  assign rb9002 = rb8576 | pp913;
  assign rb9003 = rb8998 & rb9000;
  assign rb9004 = rb8999 & rb9001;
  assign rb9005 = (rb8998 & ~rb9000 & ~rb9001) | (rb9000 & ~rb8998 & ~rb8999);
  assign rb9006 = (rb8999 & ~rb9000 & ~rb9001) | (rb9001 & ~rb8998 & ~rb8999);
  assign rb9007 = rb9003 | (rb9005 & ~rb9002);
  assign rb9008 = rb9004 | (rb9006 & rb9002);
  assign rb9009 = (rb9005 | rb9006) & rb9002;
  assign rb9010 = (rb9005 | rb9006) & ~rb9002;
  assign rb9011 = rb8579;
  assign rb9012 = rb8580;
  assign rb9013 = pp916;
  assign rb9014 = pp917;
  assign rb9015 = rb8578 | pp915;
  assign rb9016 = rb9011 & rb9013;
  assign rb9017 = rb9012 & rb9014;
  assign rb9018 = (rb9011 & ~rb9013 & ~rb9014) | (rb9013 & ~rb9011 & ~rb9012);
  assign rb9019 = (rb9012 & ~rb9013 & ~rb9014) | (rb9014 & ~rb9011 & ~rb9012);
  assign rb9020 = rb9016 | (rb9018 & ~rb9015);
  assign rb9021 = rb9017 | (rb9019 & rb9015);
  assign rb9022 = (rb9018 | rb9019) & rb9015;
  assign rb9023 = (rb9018 | rb9019) & ~rb9015;
  assign rb9024 = (rb8593 & ~1'b0) | (1'b0 & ~rb8594);
  assign rb9025 = (rb8594 & ~1'b0) | (1'b0 & ~rb8593);
  assign rb9026 = (rb8606 & ~rb8592) | (rb8591 & ~rb8607);
  assign rb9027 = (rb8607 & ~rb8591) | (rb8592 & ~rb8606);
  assign rb9028 = (rb8619 & ~rb8605) | (rb8604 & ~rb8620);
  assign rb9029 = (rb8620 & ~rb8604) | (rb8605 & ~rb8619);
  assign rb9030 = (rb8632 & ~rb8618) | (rb8617 & ~rb8633);
  assign rb9031 = (rb8633 & ~rb8617) | (rb8618 & ~rb8632);
  assign rb9032 = (rb8645 & ~rb8631) | (rb8630 & ~rb8646);
  assign rb9033 = (rb8646 & ~rb8630) | (rb8631 & ~rb8645);
  assign rb9034 = (rb8658 & ~rb8644) | (rb8643 & ~rb8659);
  assign rb9035 = (rb8659 & ~rb8643) | (rb8644 & ~rb8658);
  assign rb9036 = (rb8671 & ~rb8657) | (rb8656 & ~rb8672);
  assign rb9037 = (rb8672 & ~rb8656) | (rb8657 & ~rb8671);
  assign rb9038 = (rb8684 & ~rb8670) | (rb8669 & ~rb8685);
  assign rb9039 = (rb8685 & ~rb8669) | (rb8670 & ~rb8684);
  assign rb9040 = (rb8697 & ~rb8683) | (rb8682 & ~rb8698);
  assign rb9041 = (rb8698 & ~rb8682) | (rb8683 & ~rb8697);
  assign rb9042 = (rb8710 & ~rb8696) | (rb8695 & ~rb8711);
  assign rb9043 = (rb8711 & ~rb8695) | (rb8696 & ~rb8710);
  assign rb9044 = (rb8723 & ~rb8709) | (rb8708 & ~rb8724);
  assign rb9045 = (rb8724 & ~rb8708) | (rb8709 & ~rb8723);
  assign rb9046 = (rb8736 & ~rb8722) | (rb8721 & ~rb8737);
  assign rb9047 = (rb8737 & ~rb8721) | (rb8722 & ~rb8736);
  assign rb9048 = (rb8749 & ~rb8735) | (rb8734 & ~rb8750);
  assign rb9049 = (rb8750 & ~rb8734) | (rb8735 & ~rb8749);
  assign rb9050 = (rb8762 & ~rb8748) | (rb8747 & ~rb8763);
  assign rb9051 = (rb8763 & ~rb8747) | (rb8748 & ~rb8762);
  assign rb9052 = (rb8775 & ~rb8761) | (rb8760 & ~rb8776);
  assign rb9053 = (rb8776 & ~rb8760) | (rb8761 & ~rb8775);
  assign rb9054 = (rb8788 & ~rb8774) | (rb8773 & ~rb8789);
  assign rb9055 = (rb8789 & ~rb8773) | (rb8774 & ~rb8788);
  assign rb9056 = (rb8801 & ~rb8787) | (rb8786 & ~rb8802);
  assign rb9057 = (rb8802 & ~rb8786) | (rb8787 & ~rb8801);
  assign rb9058 = (rb8814 & ~rb8800) | (rb8799 & ~rb8815);
  assign rb9059 = (rb8815 & ~rb8799) | (rb8800 & ~rb8814);
  assign rb9060 = (rb8827 & ~rb8813) | (rb8812 & ~rb8828);
  assign rb9061 = (rb8828 & ~rb8812) | (rb8813 & ~rb8827);
  assign rb9062 = (rb8840 & ~rb8826) | (rb8825 & ~rb8841);
  assign rb9063 = (rb8841 & ~rb8825) | (rb8826 & ~rb8840);
  assign rb9064 = (rb8853 & ~rb8839) | (rb8838 & ~rb8854);
  assign rb9065 = (rb8854 & ~rb8838) | (rb8839 & ~rb8853);
  assign rb9066 = (rb8866 & ~rb8852) | (rb8851 & ~rb8867);
  assign rb9067 = (rb8867 & ~rb8851) | (rb8852 & ~rb8866);
  assign rb9068 = (rb8879 & ~rb8865) | (rb8864 & ~rb8880);
  assign rb9069 = (rb8880 & ~rb8864) | (rb8865 & ~rb8879);
  assign rb9070 = (rb8892 & ~rb8878) | (rb8877 & ~rb8893);
  assign rb9071 = (rb8893 & ~rb8877) | (rb8878 & ~rb8892);
  assign rb9072 = (rb8905 & ~rb8891) | (rb8890 & ~rb8906);
  assign rb9073 = (rb8906 & ~rb8890) | (rb8891 & ~rb8905);
  assign rb9074 = (rb8918 & ~rb8904) | (rb8903 & ~rb8919);
  assign rb9075 = (rb8919 & ~rb8903) | (rb8904 & ~rb8918);
  assign rb9076 = (rb8931 & ~rb8917) | (rb8916 & ~rb8932);
  assign rb9077 = (rb8932 & ~rb8916) | (rb8917 & ~rb8931);
  assign rb9078 = (rb8944 & ~rb8930) | (rb8929 & ~rb8945);
  assign rb9079 = (rb8945 & ~rb8929) | (rb8930 & ~rb8944);
  assign rb9080 = (rb8957 & ~rb8943) | (rb8942 & ~rb8958);
  assign rb9081 = (rb8958 & ~rb8942) | (rb8943 & ~rb8957);
  assign rb9082 = (rb8970 & ~rb8956) | (rb8955 & ~rb8971);
  assign rb9083 = (rb8971 & ~rb8955) | (rb8956 & ~rb8970);
  assign rb9084 = (rb8983 & ~rb8969) | (rb8968 & ~rb8984);
  assign rb9085 = (rb8984 & ~rb8968) | (rb8969 & ~rb8983);
  assign rb9086 = (rb8996 & ~rb8982) | (rb8981 & ~rb8997);
  assign rb9087 = (rb8997 & ~rb8981) | (rb8982 & ~rb8996);
  assign rb9088 = (rb9009 & ~rb8995) | (rb8994 & ~rb9010);
  assign rb9089 = (rb9010 & ~rb8994) | (rb8995 & ~rb9009);
  assign rb9090 = (rb9022 & ~rb9008) | (rb9007 & ~rb9023);
  assign rb9091 = (rb9023 & ~rb9007) | (rb9008 & ~rb9022);
  assign rb9092 = (1'b0 & ~rb9021) | (rb9020 & ~1'b0);
  assign rb9093 = (1'b0 & ~rb9020) | (rb9021 & ~1'b0);
  assign rb9094 = rb9024;
  assign rb9095 = rb9026;
  assign rb9096 = rb9028;
  assign rb9097 = rb9030;
  assign rb9098 = rb9032;
  assign rb9099 = rb9034;
  assign rb9100 = rb9036;
  assign rb9101 = rb9038;
  assign rb9102 = rb9040;
  assign rb9103 = rb9042;
  assign rb9104 = rb9044;
  assign rb9105 = rb9046;
  assign rb9106 = rb9048;
  assign rb9107 = rb9050;
  assign rb9108 = rb9052;
  assign rb9109 = rb9054;
  assign rb9110 = rb9056;
  assign rb9111 = rb9058;
  assign rb9112 = rb9060;
  assign rb9113 = rb9062;
  assign rb9114 = rb9064;
  assign rb9115 = rb9066;
  assign rb9116 = rb9068;
  assign rb9117 = rb9070;
  assign rb9118 = rb9072;
  assign rb9119 = rb9074;
  assign rb9120 = rb9076;
  assign rb9121 = rb9078;
  assign rb9122 = rb9080;
  assign rb9123 = rb9082;
  assign rb9124 = rb9084;
  assign rb9125 = rb9086;
  assign rb9126 = rb9088;
  assign rb9127 = rb9090;
  assign rb9128 = rb9025;
  assign rb9129 = rb9027;
  assign rb9130 = rb9029;
  assign rb9131 = rb9031;
  assign rb9132 = rb9033;
  assign rb9133 = rb9035;
  assign rb9134 = rb9037;
  assign rb9135 = rb9039;
  assign rb9136 = rb9041;
  assign rb9137 = rb9043;
  assign rb9138 = rb9045;
  assign rb9139 = rb9047;
  assign rb9140 = rb9049;
  assign rb9141 = rb9051;
  assign rb9142 = rb9053;
  assign rb9143 = rb9055;
  assign rb9144 = rb9057;
  assign rb9145 = rb9059;
  assign rb9146 = rb9061;
  assign rb9147 = rb9063;
  assign rb9148 = rb9065;
  assign rb9149 = rb9067;
  assign rb9150 = rb9069;
  assign rb9151 = rb9071;
  assign rb9152 = rb9073;
  assign rb9153 = rb9075;
  assign rb9154 = rb9077;
  assign rb9155 = rb9079;
  assign rb9156 = rb9081;
  assign rb9157 = rb9083;
  assign rb9158 = rb9085;
  assign rb9159 = rb9087;
  assign rb9160 = rb9089;
  assign rb9161 = rb9091;
  logic [33:0] zp, zm;
  assign zp = {rb9127, rb9126, rb9125, rb9124, rb9123, rb9122, rb9121, rb9120, rb9119, rb9118, rb9117, rb9116, rb9115, rb9114, rb9113, rb9112, rb9111, rb9110, rb9109, rb9108, rb9107, rb9106, rb9105, rb9104, rb9103, rb9102, rb9101, rb9100, rb9099, rb9098, rb9097, rb9096, rb9095, rb9094};
  assign zm = {rb9161, rb9160, rb9159, rb9158, rb9157, rb9156, rb9155, rb9154, rb9153, rb9152, rb9151, rb9150, rb9149, rb9148, rb9147, rb9146, rb9145, rb9144, rb9143, rb9142, rb9141, rb9140, rb9139, rb9138, rb9137, rb9136, rb9135, rb9134, rb9133, rb9132, rb9131, rb9130, rb9129, rb9128};
  logic [33:0] nz; assign nz = ~zm;
  logic [33:0] dif; logic co;
  // the converter: plus word less minus word through the carry_select adder
  fam_adder_carry_select_w34 u_conv (.a(zp), .b(nz), .cin(1'b1), .s(dif), .cout(co));
  assign p = dif[31:0];
endmodule

// segmented_grid (square, depth 2): 2 x 2 segment products of 8 x 8 bits (booth_recoded_parallel) merged by carry_save_tree (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p012a83fa (input logic [15:0] a, input logic [15:0] b, output logic [31:0] p);
  logic [15:0] ae; assign ae = a;
  logic [15:0] be; assign be = b;
  logic [7:0] sa00; assign sa00 = ae[7:0];
  logic [7:0] sb00; assign sb00 = be[7:0];
  logic [15:0] sp00;
  // segment product (0, 0): a segmented grid of depth 1
  fam_mul_segmented_grid_w16_s_p012a83fa_g00 u_g00 (.a(sa00), .b(sb00), .p(sp00));
  logic [8:0] sa01; assign sa01 = {{1{1'b0}}, ae[7:0]};
  logic [8:0] sb01; assign sb01 = {{1{be[15]}}, be[15:8]};
  logic [17:0] sp01;
  // segment product (0, 1): a segmented grid of depth 1
  fam_mul_segmented_grid_w16_s_p012a83fa_g01 u_g01 (.a(sa01), .b(sb01), .p(sp01));
  logic [8:0] sa10; assign sa10 = {{1{ae[15]}}, ae[15:8]};
  logic [8:0] sb10; assign sb10 = {{1{1'b0}}, be[7:0]};
  logic [17:0] sp10;
  // segment product (1, 0): a segmented grid of depth 1
  fam_mul_segmented_grid_w16_s_p012a83fa_g10 u_g10 (.a(sa10), .b(sb10), .p(sp10));
  logic [8:0] sa11; assign sa11 = {{1{ae[15]}}, ae[15:8]};
  logic [8:0] sb11; assign sb11 = {{1{be[15]}}, be[15:8]};
  logic [17:0] sp11;
  // segment product (1, 1): a segmented grid of depth 1
  fam_mul_segmented_grid_w16_s_p012a83fa_g11 u_g11 (.a(sa11), .b(sb11), .p(sp11));
  logic t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15, t16, t17, t18, t19, t20, t21, t22, t23, t24, t25, t26, t27, t28, t29, t30, t31, t32, t33, t34, t35, t36, t37, t38, t39, t40, t41, t42, t43, t44, t45, t46, t47, t48, t49, t50, t51;
  assign t0 = sp00[8] ^ sp01[0];
  assign t1 = sp00[8] & sp01[0];
  assign t2 = sp00[9] ^ sp01[1] ^ sp10[1];
  assign t3 = (sp00[9] & sp01[1]) | (sp00[9] & sp10[1]) | (sp01[1] & sp10[1]);
  assign t4 = sp00[10] ^ sp01[2] ^ sp10[2];
  assign t5 = (sp00[10] & sp01[2]) | (sp00[10] & sp10[2]) | (sp01[2] & sp10[2]);
  assign t6 = sp00[11] ^ sp01[3] ^ sp10[3];
  assign t7 = (sp00[11] & sp01[3]) | (sp00[11] & sp10[3]) | (sp01[3] & sp10[3]);
  assign t8 = sp00[12] ^ sp01[4] ^ sp10[4];
  assign t9 = (sp00[12] & sp01[4]) | (sp00[12] & sp10[4]) | (sp01[4] & sp10[4]);
  assign t10 = sp00[13] ^ sp01[5] ^ sp10[5];
  assign t11 = (sp00[13] & sp01[5]) | (sp00[13] & sp10[5]) | (sp01[5] & sp10[5]);
  assign t12 = sp00[14] ^ sp01[6] ^ sp10[6];
  assign t13 = (sp00[14] & sp01[6]) | (sp00[14] & sp10[6]) | (sp01[6] & sp10[6]);
  assign t14 = sp00[15] ^ sp01[7] ^ sp10[7];
  assign t15 = (sp00[15] & sp01[7]) | (sp00[15] & sp10[7]) | (sp01[7] & sp10[7]);
  assign t16 = sp01[8] ^ sp10[8] ^ sp11[0];
  assign t17 = (sp01[8] & sp10[8]) | (sp01[8] & sp11[0]) | (sp10[8] & sp11[0]);
  assign t18 = sp01[9] ^ sp10[9] ^ sp11[1];
  assign t19 = (sp01[9] & sp10[9]) | (sp01[9] & sp11[1]) | (sp10[9] & sp11[1]);
  assign t20 = sp01[10] ^ sp10[10] ^ sp11[2];
  assign t21 = (sp01[10] & sp10[10]) | (sp01[10] & sp11[2]) | (sp10[10] & sp11[2]);
  assign t22 = sp01[11] ^ sp10[11] ^ sp11[3];
  assign t23 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[3]) | (sp10[11] & sp11[3]);
  assign t24 = sp01[12] ^ sp10[12] ^ sp11[4];
  assign t25 = (sp01[12] & sp10[12]) | (sp01[12] & sp11[4]) | (sp10[12] & sp11[4]);
  assign t26 = sp01[13] ^ sp10[13] ^ sp11[5];
  assign t27 = (sp01[13] & sp10[13]) | (sp01[13] & sp11[5]) | (sp10[13] & sp11[5]);
  assign t28 = sp01[14] ^ sp10[14] ^ sp11[6];
  assign t29 = (sp01[14] & sp10[14]) | (sp01[14] & sp11[6]) | (sp10[14] & sp11[6]);
  assign t30 = sp01[15] ^ sp10[15] ^ sp11[7];
  assign t31 = (sp01[15] & sp10[15]) | (sp01[15] & sp11[7]) | (sp10[15] & sp11[7]);
  assign t32 = sp01[16] ^ sp10[16] ^ sp11[8];
  assign t33 = (sp01[16] & sp10[16]) | (sp01[16] & sp11[8]) | (sp10[16] & sp11[8]);
  assign t34 = sp01[17] ^ sp10[17] ^ sp11[9];
  assign t35 = (sp01[17] & sp10[17]) | (sp01[17] & sp11[9]) | (sp10[17] & sp11[9]);
  assign t36 = sp01[17] ^ sp10[17] ^ sp11[10];
  assign t37 = (sp01[17] & sp10[17]) | (sp01[17] & sp11[10]) | (sp10[17] & sp11[10]);
  assign t38 = sp01[17] ^ sp10[17] ^ sp11[11];
  assign t39 = (sp01[17] & sp10[17]) | (sp01[17] & sp11[11]) | (sp10[17] & sp11[11]);
  assign t40 = sp01[17] ^ sp10[17] ^ sp11[12];
  assign t41 = (sp01[17] & sp10[17]) | (sp01[17] & sp11[12]) | (sp10[17] & sp11[12]);
  assign t42 = sp01[17] ^ sp10[17] ^ sp11[13];
  assign t43 = (sp01[17] & sp10[17]) | (sp01[17] & sp11[13]) | (sp10[17] & sp11[13]);
  assign t44 = sp01[17] ^ sp10[17] ^ sp11[14];
  assign t45 = (sp01[17] & sp10[17]) | (sp01[17] & sp11[14]) | (sp10[17] & sp11[14]);
  assign t46 = sp01[17] ^ sp10[17] ^ sp11[15];
  assign t47 = (sp01[17] & sp10[17]) | (sp01[17] & sp11[15]) | (sp10[17] & sp11[15]);
  assign t48 = sp01[17] ^ sp10[17] ^ sp11[16];
  assign t49 = (sp01[17] & sp10[17]) | (sp01[17] & sp11[16]) | (sp10[17] & sp11[16]);
  assign t50 = sp01[17] ^ sp10[17] ^ sp11[17];
  assign t51 = (sp01[17] & sp10[17]) | (sp01[17] & sp11[17]) | (sp10[17] & sp11[17]);
  logic [33:0] full;
  logic [33:0] row_s, row_c;
  assign row_s = {t49, t47, t45, t43, t41, t39, t37, t35, t33, t31, t29, t27, t25, t23, t21, t19, t17, t15, t13, t11, t9, t7, t5, t3, t1, sp10[0], sp00[7], sp00[6], sp00[5], sp00[4], sp00[3], sp00[2], sp00[1], sp00[0]};
  assign row_c = {t50, t48, t46, t44, t42, t40, t38, t36, t34, t32, t30, t28, t26, t24, t22, t20, t18, t16, t14, t12, t10, t8, t6, t4, t2, t0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
  // hybrid final adder: regions [0, 8, 17, 25, 34] of kinds ['ripple', 'cla', 'select', 'select'] on the measured_tree_profile profile (delay_bound_boundary_enumeration)
  logic rg0_co;
  fam_adder_ripple_carry #(.W(8), .CHUNK(1), .FORM(0)) u_rg0 (.a(row_s[7:0]), .b(row_c[7:0]), .cin(1'b0), .s(full[7:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_lookahead #(.W(9), .G(4), .INTER(0), .LEVELS(1)) u_rg1 (.a(row_s[16:8]), .b(row_c[16:8]), .cin(rg0_co), .s(full[16:8]), .cout(rg1_co));
  logic rg2_co;
  fam_adder_carry_select_w8 u_rg2 (.a(row_s[24:17]), .b(row_c[24:17]), .cin(rg1_co), .s(full[24:17]), .cout(rg2_co));
  logic rg3_co;
  fam_adder_carry_select_w9 u_rg3 (.a(row_s[33:25]), .b(row_c[33:25]), .cin(rg2_co), .s(full[33:25]), .cout(rg3_co));
  assign p = full[31:0];
endmodule


// segmented_grid (square, depth 1): 2 x 2 segment products of 4 x 4 bits (booth_recoded_parallel) merged by carry_save_tree (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p012a83fa_g00 (input logic [7:0] a, input logic [7:0] b, output logic [15:0] p);
  logic [7:0] ae; assign ae = a;
  logic [7:0] be; assign be = b;
  logic [3:0] sa00; assign sa00 = ae[3:0];
  logic [3:0] sb00; assign sb00 = be[3:0];
  logic [7:0] sp00;
  // segment product (0, 0) (booth_recoded_parallel)
  fam_mul_booth16_dadda_3_2_w4_u_pe5d7a1e3 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [3:0] sa01; assign sa01 = ae[3:0];
  logic [3:0] sb01; assign sb01 = be[7:4];
  logic [7:0] sp01;
  // segment product (0, 1) (booth_recoded_parallel)
  fam_mul_booth16_dadda_3_2_w4_u_pe5d7a1e3 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [3:0] sa10; assign sa10 = ae[7:4];
  logic [3:0] sb10; assign sb10 = be[3:0];
  logic [7:0] sp10;
  // segment product (1, 0) (booth_recoded_parallel)
  fam_mul_booth16_dadda_3_2_w4_u_pe5d7a1e3 u3 (.a(sa10), .b(sb10), .p(sp10));
  logic [3:0] sa11; assign sa11 = ae[7:4];
  logic [3:0] sb11; assign sb11 = be[7:4];
  logic [7:0] sp11;
  // segment product (1, 1) (booth_recoded_parallel)
  fam_mul_booth16_dadda_3_2_w4_u_pe5d7a1e3 u4 (.a(sa11), .b(sb11), .p(sp11));
  logic t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15;
  assign t0 = sp00[4] ^ sp01[0];
  assign t1 = sp00[4] & sp01[0];
  assign t2 = sp00[5] ^ sp01[1] ^ sp10[1];
  assign t3 = (sp00[5] & sp01[1]) | (sp00[5] & sp10[1]) | (sp01[1] & sp10[1]);
  assign t4 = sp00[6] ^ sp01[2] ^ sp10[2];
  assign t5 = (sp00[6] & sp01[2]) | (sp00[6] & sp10[2]) | (sp01[2] & sp10[2]);
  assign t6 = sp00[7] ^ sp01[3] ^ sp10[3];
  assign t7 = (sp00[7] & sp01[3]) | (sp00[7] & sp10[3]) | (sp01[3] & sp10[3]);
  assign t8 = sp01[4] ^ sp10[4] ^ sp11[0];
  assign t9 = (sp01[4] & sp10[4]) | (sp01[4] & sp11[0]) | (sp10[4] & sp11[0]);
  assign t10 = sp01[5] ^ sp10[5] ^ sp11[1];
  assign t11 = (sp01[5] & sp10[5]) | (sp01[5] & sp11[1]) | (sp10[5] & sp11[1]);
  assign t12 = sp01[6] ^ sp10[6] ^ sp11[2];
  assign t13 = (sp01[6] & sp10[6]) | (sp01[6] & sp11[2]) | (sp10[6] & sp11[2]);
  assign t14 = sp01[7] ^ sp10[7] ^ sp11[3];
  assign t15 = (sp01[7] & sp10[7]) | (sp01[7] & sp11[3]) | (sp10[7] & sp11[3]);
  logic [17:0] full;
  logic [17:0] row_s, row_c;
  assign row_s = {1'b0, 1'b0, sp11[7], sp11[6], sp11[5], sp11[4], t13, t11, t9, t7, t5, t3, t1, sp10[0], sp00[3], sp00[2], sp00[1], sp00[0]};
  assign row_c = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, t15, t14, t12, t10, t8, t6, t4, t2, t0, 1'b0, 1'b0, 1'b0, 1'b0};
  // hybrid final adder: regions [0, 4, 9, 13, 18] of kinds ['ripple', 'cla', 'select', 'select'] on the measured_tree_profile profile (delay_bound_boundary_enumeration)
  logic rg0_co;
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) u_rg0 (.a(row_s[3:0]), .b(row_c[3:0]), .cin(1'b0), .s(full[3:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_lookahead #(.W(5), .G(4), .INTER(0), .LEVELS(1)) u_rg1 (.a(row_s[8:4]), .b(row_c[8:4]), .cin(rg0_co), .s(full[8:4]), .cout(rg1_co));
  logic rg2_co;
  fam_adder_carry_select_w4 u_rg2 (.a(row_s[12:9]), .b(row_c[12:9]), .cin(rg1_co), .s(full[12:9]), .cout(rg2_co));
  logic rg3_co;
  fam_adder_carry_select_w5 u_rg3 (.a(row_s[17:13]), .b(row_c[17:13]), .cin(rg2_co), .s(full[17:13]), .cout(rg3_co));
  assign p = full[15:0];
endmodule


// segmented_grid (square, depth 1): 2 x 2 segment products of 5 x 5 bits (booth_recoded_parallel) merged by carry_save_tree (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p012a83fa_g01 (input logic [8:0] a, input logic [8:0] b, output logic [17:0] p);
  logic [9:0] ae; assign ae = {{(10-9){a[8]}}, a};
  logic [9:0] be; assign be = {{(10-9){b[8]}}, b};
  logic [4:0] sa00; assign sa00 = ae[4:0];
  logic [4:0] sb00; assign sb00 = be[4:0];
  logic [9:0] sp00;
  // segment product (0, 0) (booth_recoded_parallel)
  fam_mul_booth16_dadda_3_2_w5_u_pe5d7a1e3 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [5:0] sa01; assign sa01 = {{1{1'b0}}, ae[4:0]};
  logic [5:0] sb01; assign sb01 = {{1{be[9]}}, be[9:5]};
  logic [11:0] sp01;
  // segment product (0, 1) (booth_recoded_parallel)
  fam_mul_booth16_dadda_3_2_w6_s_pe5d7a1e3 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [5:0] sa10; assign sa10 = {{1{ae[9]}}, ae[9:5]};
  logic [5:0] sb10; assign sb10 = {{1{1'b0}}, be[4:0]};
  logic [11:0] sp10;
  // segment product (1, 0) (booth_recoded_parallel)
  fam_mul_booth16_dadda_3_2_w6_s_pe5d7a1e3 u3 (.a(sa10), .b(sb10), .p(sp10));
  logic [5:0] sa11; assign sa11 = {{1{ae[9]}}, ae[9:5]};
  logic [5:0] sb11; assign sb11 = {{1{be[9]}}, be[9:5]};
  logic [11:0] sp11;
  // segment product (1, 1) (booth_recoded_parallel)
  fam_mul_booth16_dadda_3_2_w6_s_pe5d7a1e3 u4 (.a(sa11), .b(sb11), .p(sp11));
  logic t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15, t16, t17, t18, t19, t20, t21, t22, t23, t24, t25, t26, t27, t28, t29, t30, t31, t32, t33;
  assign t0 = sp00[5] ^ sp01[0];
  assign t1 = sp00[5] & sp01[0];
  assign t2 = sp00[6] ^ sp01[1] ^ sp10[1];
  assign t3 = (sp00[6] & sp01[1]) | (sp00[6] & sp10[1]) | (sp01[1] & sp10[1]);
  assign t4 = sp00[7] ^ sp01[2] ^ sp10[2];
  assign t5 = (sp00[7] & sp01[2]) | (sp00[7] & sp10[2]) | (sp01[2] & sp10[2]);
  assign t6 = sp00[8] ^ sp01[3] ^ sp10[3];
  assign t7 = (sp00[8] & sp01[3]) | (sp00[8] & sp10[3]) | (sp01[3] & sp10[3]);
  assign t8 = sp00[9] ^ sp01[4] ^ sp10[4];
  assign t9 = (sp00[9] & sp01[4]) | (sp00[9] & sp10[4]) | (sp01[4] & sp10[4]);
  assign t10 = sp01[5] ^ sp10[5] ^ sp11[0];
  assign t11 = (sp01[5] & sp10[5]) | (sp01[5] & sp11[0]) | (sp10[5] & sp11[0]);
  assign t12 = sp01[6] ^ sp10[6] ^ sp11[1];
  assign t13 = (sp01[6] & sp10[6]) | (sp01[6] & sp11[1]) | (sp10[6] & sp11[1]);
  assign t14 = sp01[7] ^ sp10[7] ^ sp11[2];
  assign t15 = (sp01[7] & sp10[7]) | (sp01[7] & sp11[2]) | (sp10[7] & sp11[2]);
  assign t16 = sp01[8] ^ sp10[8] ^ sp11[3];
  assign t17 = (sp01[8] & sp10[8]) | (sp01[8] & sp11[3]) | (sp10[8] & sp11[3]);
  assign t18 = sp01[9] ^ sp10[9] ^ sp11[4];
  assign t19 = (sp01[9] & sp10[9]) | (sp01[9] & sp11[4]) | (sp10[9] & sp11[4]);
  assign t20 = sp01[10] ^ sp10[10] ^ sp11[5];
  assign t21 = (sp01[10] & sp10[10]) | (sp01[10] & sp11[5]) | (sp10[10] & sp11[5]);
  assign t22 = sp01[11] ^ sp10[11] ^ sp11[6];
  assign t23 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[6]) | (sp10[11] & sp11[6]);
  assign t24 = sp01[11] ^ sp10[11] ^ sp11[7];
  assign t25 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[7]) | (sp10[11] & sp11[7]);
  assign t26 = sp01[11] ^ sp10[11] ^ sp11[8];
  assign t27 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[8]) | (sp10[11] & sp11[8]);
  assign t28 = sp01[11] ^ sp10[11] ^ sp11[9];
  assign t29 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[9]) | (sp10[11] & sp11[9]);
  assign t30 = sp01[11] ^ sp10[11] ^ sp11[10];
  assign t31 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[10]) | (sp10[11] & sp11[10]);
  assign t32 = sp01[11] ^ sp10[11] ^ sp11[11];
  assign t33 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[11]) | (sp10[11] & sp11[11]);
  logic [21:0] full;
  logic [21:0] row_s, row_c;
  assign row_s = {t31, t29, t27, t25, t23, t21, t19, t17, t15, t13, t11, t9, t7, t5, t3, t1, sp10[0], sp00[4], sp00[3], sp00[2], sp00[1], sp00[0]};
  assign row_c = {t32, t30, t28, t26, t24, t22, t20, t18, t16, t14, t12, t10, t8, t6, t4, t2, t0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
  // hybrid final adder: regions [0, 5, 11, 16, 22] of kinds ['ripple', 'cla', 'select', 'select'] on the measured_tree_profile profile (delay_bound_boundary_enumeration)
  logic rg0_co;
  fam_adder_ripple_carry #(.W(5), .CHUNK(1), .FORM(0)) u_rg0 (.a(row_s[4:0]), .b(row_c[4:0]), .cin(1'b0), .s(full[4:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_lookahead #(.W(6), .G(4), .INTER(0), .LEVELS(1)) u_rg1 (.a(row_s[10:5]), .b(row_c[10:5]), .cin(rg0_co), .s(full[10:5]), .cout(rg1_co));
  logic rg2_co;
  fam_adder_carry_select_w5 u_rg2 (.a(row_s[15:11]), .b(row_c[15:11]), .cin(rg1_co), .s(full[15:11]), .cout(rg2_co));
  logic rg3_co;
  fam_adder_carry_select_w6 u_rg3 (.a(row_s[21:16]), .b(row_c[21:16]), .cin(rg2_co), .s(full[21:16]), .cout(rg3_co));
  assign p = full[17:0];
endmodule


// segmented_grid (square, depth 1): 2 x 2 segment products of 5 x 5 bits (booth_recoded_parallel) merged by carry_save_tree (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p012a83fa_g10 (input logic [8:0] a, input logic [8:0] b, output logic [17:0] p);
  logic [9:0] ae; assign ae = {{(10-9){a[8]}}, a};
  logic [9:0] be; assign be = {{(10-9){b[8]}}, b};
  logic [4:0] sa00; assign sa00 = ae[4:0];
  logic [4:0] sb00; assign sb00 = be[4:0];
  logic [9:0] sp00;
  // segment product (0, 0) (booth_recoded_parallel)
  fam_mul_booth16_dadda_3_2_w5_u_pe5d7a1e3 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [5:0] sa01; assign sa01 = {{1{1'b0}}, ae[4:0]};
  logic [5:0] sb01; assign sb01 = {{1{be[9]}}, be[9:5]};
  logic [11:0] sp01;
  // segment product (0, 1) (booth_recoded_parallel)
  fam_mul_booth16_dadda_3_2_w6_s_pe5d7a1e3 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [5:0] sa10; assign sa10 = {{1{ae[9]}}, ae[9:5]};
  logic [5:0] sb10; assign sb10 = {{1{1'b0}}, be[4:0]};
  logic [11:0] sp10;
  // segment product (1, 0) (booth_recoded_parallel)
  fam_mul_booth16_dadda_3_2_w6_s_pe5d7a1e3 u3 (.a(sa10), .b(sb10), .p(sp10));
  logic [5:0] sa11; assign sa11 = {{1{ae[9]}}, ae[9:5]};
  logic [5:0] sb11; assign sb11 = {{1{be[9]}}, be[9:5]};
  logic [11:0] sp11;
  // segment product (1, 1) (booth_recoded_parallel)
  fam_mul_booth16_dadda_3_2_w6_s_pe5d7a1e3 u4 (.a(sa11), .b(sb11), .p(sp11));
  logic t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15, t16, t17, t18, t19, t20, t21, t22, t23, t24, t25, t26, t27, t28, t29, t30, t31, t32, t33;
  assign t0 = sp00[5] ^ sp01[0];
  assign t1 = sp00[5] & sp01[0];
  assign t2 = sp00[6] ^ sp01[1] ^ sp10[1];
  assign t3 = (sp00[6] & sp01[1]) | (sp00[6] & sp10[1]) | (sp01[1] & sp10[1]);
  assign t4 = sp00[7] ^ sp01[2] ^ sp10[2];
  assign t5 = (sp00[7] & sp01[2]) | (sp00[7] & sp10[2]) | (sp01[2] & sp10[2]);
  assign t6 = sp00[8] ^ sp01[3] ^ sp10[3];
  assign t7 = (sp00[8] & sp01[3]) | (sp00[8] & sp10[3]) | (sp01[3] & sp10[3]);
  assign t8 = sp00[9] ^ sp01[4] ^ sp10[4];
  assign t9 = (sp00[9] & sp01[4]) | (sp00[9] & sp10[4]) | (sp01[4] & sp10[4]);
  assign t10 = sp01[5] ^ sp10[5] ^ sp11[0];
  assign t11 = (sp01[5] & sp10[5]) | (sp01[5] & sp11[0]) | (sp10[5] & sp11[0]);
  assign t12 = sp01[6] ^ sp10[6] ^ sp11[1];
  assign t13 = (sp01[6] & sp10[6]) | (sp01[6] & sp11[1]) | (sp10[6] & sp11[1]);
  assign t14 = sp01[7] ^ sp10[7] ^ sp11[2];
  assign t15 = (sp01[7] & sp10[7]) | (sp01[7] & sp11[2]) | (sp10[7] & sp11[2]);
  assign t16 = sp01[8] ^ sp10[8] ^ sp11[3];
  assign t17 = (sp01[8] & sp10[8]) | (sp01[8] & sp11[3]) | (sp10[8] & sp11[3]);
  assign t18 = sp01[9] ^ sp10[9] ^ sp11[4];
  assign t19 = (sp01[9] & sp10[9]) | (sp01[9] & sp11[4]) | (sp10[9] & sp11[4]);
  assign t20 = sp01[10] ^ sp10[10] ^ sp11[5];
  assign t21 = (sp01[10] & sp10[10]) | (sp01[10] & sp11[5]) | (sp10[10] & sp11[5]);
  assign t22 = sp01[11] ^ sp10[11] ^ sp11[6];
  assign t23 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[6]) | (sp10[11] & sp11[6]);
  assign t24 = sp01[11] ^ sp10[11] ^ sp11[7];
  assign t25 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[7]) | (sp10[11] & sp11[7]);
  assign t26 = sp01[11] ^ sp10[11] ^ sp11[8];
  assign t27 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[8]) | (sp10[11] & sp11[8]);
  assign t28 = sp01[11] ^ sp10[11] ^ sp11[9];
  assign t29 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[9]) | (sp10[11] & sp11[9]);
  assign t30 = sp01[11] ^ sp10[11] ^ sp11[10];
  assign t31 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[10]) | (sp10[11] & sp11[10]);
  assign t32 = sp01[11] ^ sp10[11] ^ sp11[11];
  assign t33 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[11]) | (sp10[11] & sp11[11]);
  logic [21:0] full;
  logic [21:0] row_s, row_c;
  assign row_s = {t31, t29, t27, t25, t23, t21, t19, t17, t15, t13, t11, t9, t7, t5, t3, t1, sp10[0], sp00[4], sp00[3], sp00[2], sp00[1], sp00[0]};
  assign row_c = {t32, t30, t28, t26, t24, t22, t20, t18, t16, t14, t12, t10, t8, t6, t4, t2, t0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
  // hybrid final adder: regions [0, 5, 11, 16, 22] of kinds ['ripple', 'cla', 'select', 'select'] on the measured_tree_profile profile (delay_bound_boundary_enumeration)
  logic rg0_co;
  fam_adder_ripple_carry #(.W(5), .CHUNK(1), .FORM(0)) u_rg0 (.a(row_s[4:0]), .b(row_c[4:0]), .cin(1'b0), .s(full[4:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_lookahead #(.W(6), .G(4), .INTER(0), .LEVELS(1)) u_rg1 (.a(row_s[10:5]), .b(row_c[10:5]), .cin(rg0_co), .s(full[10:5]), .cout(rg1_co));
  logic rg2_co;
  fam_adder_carry_select_w5 u_rg2 (.a(row_s[15:11]), .b(row_c[15:11]), .cin(rg1_co), .s(full[15:11]), .cout(rg2_co));
  logic rg3_co;
  fam_adder_carry_select_w6 u_rg3 (.a(row_s[21:16]), .b(row_c[21:16]), .cin(rg2_co), .s(full[21:16]), .cout(rg3_co));
  assign p = full[17:0];
endmodule














// carry_select: blocks [4, 1] (uniform), full_duplicate, selects rippled_block_carries






// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).










// carry_select: blocks [4, 2] (uniform), full_duplicate, selects rippled_block_carries






// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).










// segmented_grid (square, depth 1): 2 x 2 segment products of 5 x 5 bits (booth_recoded_parallel) merged by carry_save_tree (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p012a83fa_g11 (input logic [8:0] a, input logic [8:0] b, output logic [17:0] p);
  logic [9:0] ae; assign ae = {{(10-9){a[8]}}, a};
  logic [9:0] be; assign be = {{(10-9){b[8]}}, b};
  logic [4:0] sa00; assign sa00 = ae[4:0];
  logic [4:0] sb00; assign sb00 = be[4:0];
  logic [9:0] sp00;
  // segment product (0, 0) (booth_recoded_parallel)
  fam_mul_booth16_dadda_3_2_w5_u_pe5d7a1e3 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [5:0] sa01; assign sa01 = {{1{1'b0}}, ae[4:0]};
  logic [5:0] sb01; assign sb01 = {{1{be[9]}}, be[9:5]};
  logic [11:0] sp01;
  // segment product (0, 1) (booth_recoded_parallel)
  fam_mul_booth16_dadda_3_2_w6_s_pe5d7a1e3 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [5:0] sa10; assign sa10 = {{1{ae[9]}}, ae[9:5]};
  logic [5:0] sb10; assign sb10 = {{1{1'b0}}, be[4:0]};
  logic [11:0] sp10;
  // segment product (1, 0) (booth_recoded_parallel)
  fam_mul_booth16_dadda_3_2_w6_s_pe5d7a1e3 u3 (.a(sa10), .b(sb10), .p(sp10));
  logic [5:0] sa11; assign sa11 = {{1{ae[9]}}, ae[9:5]};
  logic [5:0] sb11; assign sb11 = {{1{be[9]}}, be[9:5]};
  logic [11:0] sp11;
  // segment product (1, 1) (booth_recoded_parallel)
  fam_mul_booth16_dadda_3_2_w6_s_pe5d7a1e3 u4 (.a(sa11), .b(sb11), .p(sp11));
  logic t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15, t16, t17, t18, t19, t20, t21, t22, t23, t24, t25, t26, t27, t28, t29, t30, t31, t32, t33;
  assign t0 = sp00[5] ^ sp01[0];
  assign t1 = sp00[5] & sp01[0];
  assign t2 = sp00[6] ^ sp01[1] ^ sp10[1];
  assign t3 = (sp00[6] & sp01[1]) | (sp00[6] & sp10[1]) | (sp01[1] & sp10[1]);
  assign t4 = sp00[7] ^ sp01[2] ^ sp10[2];
  assign t5 = (sp00[7] & sp01[2]) | (sp00[7] & sp10[2]) | (sp01[2] & sp10[2]);
  assign t6 = sp00[8] ^ sp01[3] ^ sp10[3];
  assign t7 = (sp00[8] & sp01[3]) | (sp00[8] & sp10[3]) | (sp01[3] & sp10[3]);
  assign t8 = sp00[9] ^ sp01[4] ^ sp10[4];
  assign t9 = (sp00[9] & sp01[4]) | (sp00[9] & sp10[4]) | (sp01[4] & sp10[4]);
  assign t10 = sp01[5] ^ sp10[5] ^ sp11[0];
  assign t11 = (sp01[5] & sp10[5]) | (sp01[5] & sp11[0]) | (sp10[5] & sp11[0]);
  assign t12 = sp01[6] ^ sp10[6] ^ sp11[1];
  assign t13 = (sp01[6] & sp10[6]) | (sp01[6] & sp11[1]) | (sp10[6] & sp11[1]);
  assign t14 = sp01[7] ^ sp10[7] ^ sp11[2];
  assign t15 = (sp01[7] & sp10[7]) | (sp01[7] & sp11[2]) | (sp10[7] & sp11[2]);
  assign t16 = sp01[8] ^ sp10[8] ^ sp11[3];
  assign t17 = (sp01[8] & sp10[8]) | (sp01[8] & sp11[3]) | (sp10[8] & sp11[3]);
  assign t18 = sp01[9] ^ sp10[9] ^ sp11[4];
  assign t19 = (sp01[9] & sp10[9]) | (sp01[9] & sp11[4]) | (sp10[9] & sp11[4]);
  assign t20 = sp01[10] ^ sp10[10] ^ sp11[5];
  assign t21 = (sp01[10] & sp10[10]) | (sp01[10] & sp11[5]) | (sp10[10] & sp11[5]);
  assign t22 = sp01[11] ^ sp10[11] ^ sp11[6];
  assign t23 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[6]) | (sp10[11] & sp11[6]);
  assign t24 = sp01[11] ^ sp10[11] ^ sp11[7];
  assign t25 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[7]) | (sp10[11] & sp11[7]);
  assign t26 = sp01[11] ^ sp10[11] ^ sp11[8];
  assign t27 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[8]) | (sp10[11] & sp11[8]);
  assign t28 = sp01[11] ^ sp10[11] ^ sp11[9];
  assign t29 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[9]) | (sp10[11] & sp11[9]);
  assign t30 = sp01[11] ^ sp10[11] ^ sp11[10];
  assign t31 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[10]) | (sp10[11] & sp11[10]);
  assign t32 = sp01[11] ^ sp10[11] ^ sp11[11];
  assign t33 = (sp01[11] & sp10[11]) | (sp01[11] & sp11[11]) | (sp10[11] & sp11[11]);
  logic [21:0] full;
  logic [21:0] row_s, row_c;
  assign row_s = {t31, t29, t27, t25, t23, t21, t19, t17, t15, t13, t11, t9, t7, t5, t3, t1, sp10[0], sp00[4], sp00[3], sp00[2], sp00[1], sp00[0]};
  assign row_c = {t32, t30, t28, t26, t24, t22, t20, t18, t16, t14, t12, t10, t8, t6, t4, t2, t0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
  // hybrid final adder: regions [0, 5, 11, 16, 22] of kinds ['ripple', 'cla', 'select', 'select'] on the measured_tree_profile profile (delay_bound_boundary_enumeration)
  logic rg0_co;
  fam_adder_ripple_carry #(.W(5), .CHUNK(1), .FORM(0)) u_rg0 (.a(row_s[4:0]), .b(row_c[4:0]), .cin(1'b0), .s(full[4:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_lookahead #(.W(6), .G(4), .INTER(0), .LEVELS(1)) u_rg1 (.a(row_s[10:5]), .b(row_c[10:5]), .cin(rg0_co), .s(full[10:5]), .cout(rg1_co));
  logic rg2_co;
  fam_adder_carry_select_w5 u_rg2 (.a(row_s[15:11]), .b(row_c[15:11]), .cin(rg1_co), .s(full[15:11]), .cout(rg2_co));
  logic rg3_co;
  fam_adder_carry_select_w6 u_rg3 (.a(row_s[21:16]), .b(row_c[21:16]), .cin(rg2_co), .s(full[21:16]), .cout(rg3_co));
  assign p = full[17:0];
endmodule

// segmented_grid (rectangular, depth 3): 2 x 1 segment products of 4 x 8 bits (direct_pp_parallel) merged by carry_save_tree (merge adder carry_increment)
module fam_mul_segmented_grid_w8_s_pda2147ed (input logic [7:0] a, input logic [7:0] b, output logic [15:0] p);
  logic [7:0] ae; assign ae = a;
  logic [7:0] be; assign be = b;
  logic [8:0] sa00; assign sa00 = {{5{1'b0}}, ae[3:0]};
  logic [8:0] sb00; assign sb00 = {{1{be[7]}}, be[7:0]};
  logic [17:0] sp00;
  // segment product (0, 0): a segmented grid of depth 2
  fam_mul_segmented_grid_w8_s_pda2147ed_g00 u_g00 (.a(sa00), .b(sb00), .p(sp00));
  logic [8:0] sa10; assign sa10 = {{5{ae[7]}}, ae[7:4]};
  logic [8:0] sb10; assign sb10 = {{1{be[7]}}, be[7:0]};
  logic [17:0] sp10;
  // segment product (1, 0): a segmented grid of depth 2
  fam_mul_segmented_grid_w8_s_pda2147ed_g10 u_g10 (.a(sa10), .b(sb10), .p(sp10));
  logic [17:0] full;
  logic [17:0] row_s, row_c;
  assign row_s = {sp00[17], sp00[16], sp00[15], sp00[14], sp00[13], sp00[12], sp00[11], sp00[10], sp00[9], sp00[8], sp00[7], sp00[6], sp00[5], sp00[4], sp00[3], sp00[2], sp00[1], sp00[0]};
  assign row_c = {sp10[13], sp10[12], sp10[11], sp10[10], sp10[9], sp10[8], sp10[7], sp10[6], sp10[5], sp10[4], sp10[3], sp10[2], sp10[1], sp10[0], 1'b0, 1'b0, 1'b0, 1'b0};
  // hybrid final adder: regions [0, 9, 18] of kinds ['ripple', 'select'] on the measured_tree_profile profile (delay_bound_boundary_enumeration)
  logic rg0_co;
  fam_adder_ripple_carry #(.W(9), .CHUNK(1), .FORM(0)) u_rg0 (.a(row_s[8:0]), .b(row_c[8:0]), .cin(1'b0), .s(full[8:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_select_w9 u_rg1 (.a(row_s[17:9]), .b(row_c[17:9]), .cin(rg0_co), .s(full[17:9]), .cout(rg1_co));
  assign p = full[15:0];
endmodule


// segmented_grid (rectangular, depth 2): 2 x 1 segment products of 5 x 10 bits (direct_pp_parallel) merged by carry_save_tree (merge adder carry_increment)
module fam_mul_segmented_grid_w8_s_pda2147ed_g00 (input logic [8:0] a, input logic [8:0] b, output logic [17:0] p);
  logic [9:0] ae; assign ae = {{(10-9){a[8]}}, a};
  logic [9:0] be; assign be = {{(10-9){b[8]}}, b};
  logic [10:0] sa00; assign sa00 = {{6{1'b0}}, ae[4:0]};
  logic [10:0] sb00; assign sb00 = {{1{be[9]}}, be[9:0]};
  logic [21:0] sp00;
  // segment product (0, 0): a segmented grid of depth 1
  fam_mul_segmented_grid_w8_s_pda2147ed_g00_g00 u_g00 (.a(sa00), .b(sb00), .p(sp00));
  logic [10:0] sa10; assign sa10 = {{6{ae[9]}}, ae[9:5]};
  logic [10:0] sb10; assign sb10 = {{1{be[9]}}, be[9:0]};
  logic [21:0] sp10;
  // segment product (1, 0): a segmented grid of depth 1
  fam_mul_segmented_grid_w8_s_pda2147ed_g00_g10 u_g10 (.a(sa10), .b(sb10), .p(sp10));
  logic [21:0] full;
  logic [21:0] row_s, row_c;
  assign row_s = {sp00[21], sp00[20], sp00[19], sp00[18], sp00[17], sp00[16], sp00[15], sp00[14], sp00[13], sp00[12], sp00[11], sp00[10], sp00[9], sp00[8], sp00[7], sp00[6], sp00[5], sp00[4], sp00[3], sp00[2], sp00[1], sp00[0]};
  assign row_c = {sp10[16], sp10[15], sp10[14], sp10[13], sp10[12], sp10[11], sp10[10], sp10[9], sp10[8], sp10[7], sp10[6], sp10[5], sp10[4], sp10[3], sp10[2], sp10[1], sp10[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
  // hybrid final adder: regions [0, 11, 22] of kinds ['ripple', 'select'] on the measured_tree_profile profile (delay_bound_boundary_enumeration)
  logic rg0_co;
  fam_adder_ripple_carry #(.W(11), .CHUNK(1), .FORM(0)) u_rg0 (.a(row_s[10:0]), .b(row_c[10:0]), .cin(1'b0), .s(full[10:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_select_w11 u_rg1 (.a(row_s[21:11]), .b(row_c[21:11]), .cin(rg0_co), .s(full[21:11]), .cout(rg1_co));
  assign p = full[17:0];
endmodule


// segmented_grid (rectangular, depth 1): 2 x 1 segment products of 6 x 12 bits (direct_pp_parallel) merged by carry_save_tree (merge adder carry_increment)
module fam_mul_segmented_grid_w8_s_pda2147ed_g00_g00 (input logic [10:0] a, input logic [10:0] b, output logic [21:0] p);
  logic [11:0] ae; assign ae = {{(12-11){a[10]}}, a};
  logic [11:0] be; assign be = {{(12-11){b[10]}}, b};
  logic [12:0] sa00; assign sa00 = {{7{1'b0}}, ae[5:0]};
  logic [12:0] sb00; assign sb00 = {{1{be[11]}}, be[11:0]};
  logic [25:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w13_s_pbe89483b u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [12:0] sa10; assign sa10 = {{7{ae[11]}}, ae[11:6]};
  logic [12:0] sb10; assign sb10 = {{1{be[11]}}, be[11:0]};
  logic [25:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w13_s_pbe89483b u2 (.a(sa10), .b(sb10), .p(sp10));
  logic [25:0] full;
  logic [25:0] row_s, row_c;
  assign row_s = {sp00[25], sp00[24], sp00[23], sp00[22], sp00[21], sp00[20], sp00[19], sp00[18], sp00[17], sp00[16], sp00[15], sp00[14], sp00[13], sp00[12], sp00[11], sp00[10], sp00[9], sp00[8], sp00[7], sp00[6], sp00[5], sp00[4], sp00[3], sp00[2], sp00[1], sp00[0]};
  assign row_c = {sp10[19], sp10[18], sp10[17], sp10[16], sp10[15], sp10[14], sp10[13], sp10[12], sp10[11], sp10[10], sp10[9], sp10[8], sp10[7], sp10[6], sp10[5], sp10[4], sp10[3], sp10[2], sp10[1], sp10[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
  // hybrid final adder: regions [0, 13, 26] of kinds ['ripple', 'select'] on the measured_tree_profile profile (delay_bound_boundary_enumeration)
  logic rg0_co;
  fam_adder_ripple_carry #(.W(13), .CHUNK(1), .FORM(0)) u_rg0 (.a(row_s[12:0]), .b(row_c[12:0]), .cin(1'b0), .s(full[12:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_select_w13 u_rg1 (.a(row_s[25:13]), .b(row_c[25:13]), .cin(rg0_co), .s(full[25:13]), .cout(rg1_co));
  assign p = full[21:0];
endmodule


// segmented_grid (rectangular, depth 1): 2 x 1 segment products of 6 x 12 bits (direct_pp_parallel) merged by carry_save_tree (merge adder carry_increment)
module fam_mul_segmented_grid_w8_s_pda2147ed_g00_g10 (input logic [10:0] a, input logic [10:0] b, output logic [21:0] p);
  logic [11:0] ae; assign ae = {{(12-11){a[10]}}, a};
  logic [11:0] be; assign be = {{(12-11){b[10]}}, b};
  logic [12:0] sa00; assign sa00 = {{7{1'b0}}, ae[5:0]};
  logic [12:0] sb00; assign sb00 = {{1{be[11]}}, be[11:0]};
  logic [25:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w13_s_pbe89483b u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [12:0] sa10; assign sa10 = {{7{ae[11]}}, ae[11:6]};
  logic [12:0] sb10; assign sb10 = {{1{be[11]}}, be[11:0]};
  logic [25:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w13_s_pbe89483b u2 (.a(sa10), .b(sb10), .p(sp10));
  logic [25:0] full;
  logic [25:0] row_s, row_c;
  assign row_s = {sp00[25], sp00[24], sp00[23], sp00[22], sp00[21], sp00[20], sp00[19], sp00[18], sp00[17], sp00[16], sp00[15], sp00[14], sp00[13], sp00[12], sp00[11], sp00[10], sp00[9], sp00[8], sp00[7], sp00[6], sp00[5], sp00[4], sp00[3], sp00[2], sp00[1], sp00[0]};
  assign row_c = {sp10[19], sp10[18], sp10[17], sp10[16], sp10[15], sp10[14], sp10[13], sp10[12], sp10[11], sp10[10], sp10[9], sp10[8], sp10[7], sp10[6], sp10[5], sp10[4], sp10[3], sp10[2], sp10[1], sp10[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
  // hybrid final adder: regions [0, 13, 26] of kinds ['ripple', 'select'] on the measured_tree_profile profile (delay_bound_boundary_enumeration)
  logic rg0_co;
  fam_adder_ripple_carry #(.W(13), .CHUNK(1), .FORM(0)) u_rg0 (.a(row_s[12:0]), .b(row_c[12:0]), .cin(1'b0), .s(full[12:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_select_w13 u_rg1 (.a(row_s[25:13]), .b(row_c[25:13]), .cin(rg0_co), .s(full[25:13]), .cout(rg1_co));
  assign p = full[21:0];
endmodule


// segmented_grid (rectangular, depth 2): 2 x 1 segment products of 5 x 10 bits (direct_pp_parallel) merged by carry_save_tree (merge adder carry_increment)
module fam_mul_segmented_grid_w8_s_pda2147ed_g10 (input logic [8:0] a, input logic [8:0] b, output logic [17:0] p);
  logic [9:0] ae; assign ae = {{(10-9){a[8]}}, a};
  logic [9:0] be; assign be = {{(10-9){b[8]}}, b};
  logic [10:0] sa00; assign sa00 = {{6{1'b0}}, ae[4:0]};
  logic [10:0] sb00; assign sb00 = {{1{be[9]}}, be[9:0]};
  logic [21:0] sp00;
  // segment product (0, 0): a segmented grid of depth 1
  fam_mul_segmented_grid_w8_s_pda2147ed_g10_g00 u_g00 (.a(sa00), .b(sb00), .p(sp00));
  logic [10:0] sa10; assign sa10 = {{6{ae[9]}}, ae[9:5]};
  logic [10:0] sb10; assign sb10 = {{1{be[9]}}, be[9:0]};
  logic [21:0] sp10;
  // segment product (1, 0): a segmented grid of depth 1
  fam_mul_segmented_grid_w8_s_pda2147ed_g10_g10 u_g10 (.a(sa10), .b(sb10), .p(sp10));
  logic [21:0] full;
  logic [21:0] row_s, row_c;
  assign row_s = {sp00[21], sp00[20], sp00[19], sp00[18], sp00[17], sp00[16], sp00[15], sp00[14], sp00[13], sp00[12], sp00[11], sp00[10], sp00[9], sp00[8], sp00[7], sp00[6], sp00[5], sp00[4], sp00[3], sp00[2], sp00[1], sp00[0]};
  assign row_c = {sp10[16], sp10[15], sp10[14], sp10[13], sp10[12], sp10[11], sp10[10], sp10[9], sp10[8], sp10[7], sp10[6], sp10[5], sp10[4], sp10[3], sp10[2], sp10[1], sp10[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
  // hybrid final adder: regions [0, 11, 22] of kinds ['ripple', 'select'] on the measured_tree_profile profile (delay_bound_boundary_enumeration)
  logic rg0_co;
  fam_adder_ripple_carry #(.W(11), .CHUNK(1), .FORM(0)) u_rg0 (.a(row_s[10:0]), .b(row_c[10:0]), .cin(1'b0), .s(full[10:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_select_w11 u_rg1 (.a(row_s[21:11]), .b(row_c[21:11]), .cin(rg0_co), .s(full[21:11]), .cout(rg1_co));
  assign p = full[17:0];
endmodule


// segmented_grid (rectangular, depth 1): 2 x 1 segment products of 6 x 12 bits (direct_pp_parallel) merged by carry_save_tree (merge adder carry_increment)
module fam_mul_segmented_grid_w8_s_pda2147ed_g10_g00 (input logic [10:0] a, input logic [10:0] b, output logic [21:0] p);
  logic [11:0] ae; assign ae = {{(12-11){a[10]}}, a};
  logic [11:0] be; assign be = {{(12-11){b[10]}}, b};
  logic [12:0] sa00; assign sa00 = {{7{1'b0}}, ae[5:0]};
  logic [12:0] sb00; assign sb00 = {{1{be[11]}}, be[11:0]};
  logic [25:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w13_s_pbe89483b u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [12:0] sa10; assign sa10 = {{7{ae[11]}}, ae[11:6]};
  logic [12:0] sb10; assign sb10 = {{1{be[11]}}, be[11:0]};
  logic [25:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w13_s_pbe89483b u2 (.a(sa10), .b(sb10), .p(sp10));
  logic [25:0] full;
  logic [25:0] row_s, row_c;
  assign row_s = {sp00[25], sp00[24], sp00[23], sp00[22], sp00[21], sp00[20], sp00[19], sp00[18], sp00[17], sp00[16], sp00[15], sp00[14], sp00[13], sp00[12], sp00[11], sp00[10], sp00[9], sp00[8], sp00[7], sp00[6], sp00[5], sp00[4], sp00[3], sp00[2], sp00[1], sp00[0]};
  assign row_c = {sp10[19], sp10[18], sp10[17], sp10[16], sp10[15], sp10[14], sp10[13], sp10[12], sp10[11], sp10[10], sp10[9], sp10[8], sp10[7], sp10[6], sp10[5], sp10[4], sp10[3], sp10[2], sp10[1], sp10[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
  // hybrid final adder: regions [0, 13, 26] of kinds ['ripple', 'select'] on the measured_tree_profile profile (delay_bound_boundary_enumeration)
  logic rg0_co;
  fam_adder_ripple_carry #(.W(13), .CHUNK(1), .FORM(0)) u_rg0 (.a(row_s[12:0]), .b(row_c[12:0]), .cin(1'b0), .s(full[12:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_select_w13 u_rg1 (.a(row_s[25:13]), .b(row_c[25:13]), .cin(rg0_co), .s(full[25:13]), .cout(rg1_co));
  assign p = full[21:0];
endmodule



// carry_increment: blocks [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] (uniform), group carries lookahead_tree, 1 increment level






// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).














// ------------------------------------------------------------ prefix_and_incrementer
// s = a + cin: the carry into bit i is cin AND every lower bit, a prefix AND
// (STRUCTURE 0 a ripple AND chain, 1 a prefix AND tree of topology TOPO, 2
// select blocks of B bits whose block carry is the AND of the block)





// carry_increment: blocks [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] (uniform), group carries lookahead_tree, 1 increment level






// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).














// ------------------------------------------------------------ prefix_and_incrementer
// s = a + cin: the carry into bit i is cin AND every lower bit, a prefix AND
// (STRUCTURE 0 a ripple AND chain, 1 a prefix AND tree of topology TOPO, 2
// select blocks of B bits whose block carry is the AND of the block)




// carry_select: blocks [4, 4, 4, 1] (uniform), full_duplicate, selects rippled_block_carries






// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).










// segmented_grid (rectangular, depth 1): 2 x 1 segment products of 6 x 12 bits (direct_pp_parallel) merged by carry_save_tree (merge adder carry_increment)
module fam_mul_segmented_grid_w8_s_pda2147ed_g10_g10 (input logic [10:0] a, input logic [10:0] b, output logic [21:0] p);
  logic [11:0] ae; assign ae = {{(12-11){a[10]}}, a};
  logic [11:0] be; assign be = {{(12-11){b[10]}}, b};
  logic [12:0] sa00; assign sa00 = {{7{1'b0}}, ae[5:0]};
  logic [12:0] sb00; assign sb00 = {{1{be[11]}}, be[11:0]};
  logic [25:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w13_s_pbe89483b u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [12:0] sa10; assign sa10 = {{7{ae[11]}}, ae[11:6]};
  logic [12:0] sb10; assign sb10 = {{1{be[11]}}, be[11:0]};
  logic [25:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w13_s_pbe89483b u2 (.a(sa10), .b(sb10), .p(sp10));
  logic [25:0] full;
  logic [25:0] row_s, row_c;
  assign row_s = {sp00[25], sp00[24], sp00[23], sp00[22], sp00[21], sp00[20], sp00[19], sp00[18], sp00[17], sp00[16], sp00[15], sp00[14], sp00[13], sp00[12], sp00[11], sp00[10], sp00[9], sp00[8], sp00[7], sp00[6], sp00[5], sp00[4], sp00[3], sp00[2], sp00[1], sp00[0]};
  assign row_c = {sp10[19], sp10[18], sp10[17], sp10[16], sp10[15], sp10[14], sp10[13], sp10[12], sp10[11], sp10[10], sp10[9], sp10[8], sp10[7], sp10[6], sp10[5], sp10[4], sp10[3], sp10[2], sp10[1], sp10[0], 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
  // hybrid final adder: regions [0, 13, 26] of kinds ['ripple', 'select'] on the measured_tree_profile profile (delay_bound_boundary_enumeration)
  logic rg0_co;
  fam_adder_ripple_carry #(.W(13), .CHUNK(1), .FORM(0)) u_rg0 (.a(row_s[12:0]), .b(row_c[12:0]), .cin(1'b0), .s(full[12:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_select_w13 u_rg1 (.a(row_s[25:13]), .b(row_c[25:13]), .cin(rg0_co), .s(full[25:13]), .cout(rg1_co));
  assign p = full[21:0];
endmodule


module fam_prefix_arrival_0_1_2_2_3_2_2_1_w8 (input logic [7:0] a, input logic [7:0] b, input logic cin,
  output logic [7:0] s, output logic cout);
  // prefix graph: {'n': 8, 'levels': 4, 'size': 15, 'fanout': 4, 'tracks': 2, 'exact_split': True, 'valency': 2}
  logic [7:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [7:0] g0, p0;
  assign g0 = {gi[7:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_5_6, P_5_6, G_6_7, P_6_7, G_0_2, G_0_3, G_2_4, P_2_4, G_4_6, P_4_6, G_5_7, P_5_7, G_0_4, G_0_5, G_0_6, G_2_7, P_2_7, G_0_7;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_5_6 = g0[6] | (p0[6] & g0[5]);
  assign P_5_6 = p0[6] & p0[5];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_2_4 = g0[4] | (p0[4] & G_2_3);
  assign P_2_4 = p0[4] & P_2_3;
  assign G_4_6 = G_5_6 | (P_5_6 & g0[4]);
  assign P_4_6 = P_5_6 & p0[4];
  assign G_5_7 = G_6_7 | (P_6_7 & g0[5]);
  assign P_5_7 = P_6_7 & p0[5];
  assign G_0_4 = G_2_4 | (P_2_4 & G_0_1);
  assign G_0_5 = G_4_5 | (P_4_5 & G_0_3);
  assign G_0_6 = G_4_6 | (P_4_6 & G_0_3);
  assign G_2_7 = G_5_7 | (P_5_7 & G_2_4);
  assign P_2_7 = P_5_7 & P_2_4;
  assign G_0_7 = G_2_7 | (P_2_7 & G_0_1);
  logic [8:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign s = pi_ ^ c[7:0];
  assign cout = c[8];
endmodule



module fam_prefix_kogge_stone_w10_ling4 (input logic [9:0] a, input logic [9:0] b, input logic cin,
  output logic [9:0] s, output logic cout);
  // prefix graph: {'n': 3, 'levels': 2, 'size': 3, 'fanout': 2, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [9:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [9:0] gc;
  assign gc = {gi[9:1], gi[0] | (pi_[0] & cin)};
  logic [2:0] g0, p0;
  assign g0[0] = gc[3] | gc[2] | (ti[2] & gc[1]) | (ti[2] & ti[1] & gc[0]);
  assign p0[0] = 1'b0;
  assign g0[1] = gc[7] | gc[6] | (ti[6] & gc[5]) | (ti[6] & ti[5] & gc[4]);
  assign p0[1] = ti[4] & ti[5] & ti[6] & ti[3];
  assign g0[2] = gc[9] | gc[8];
  assign p0[2] = ti[8] & ti[7];
  logic G_0_1, G_1_2, P_1_2, G_0_2;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  logic [3:0] bc;
  assign bc[0] = cin;
  assign bc[1] = ti[3] & g0[0];
  assign bc[2] = ti[7] & G_0_1;
  assign bc[3] = ti[9] & G_0_2;
  logic [4:0] r_0;
  assign r_0[0] = bc[0];
  assign r_0[1] = gc[0] | (pi_[0] & r_0[0]);
  assign s[0] = pi_[0] ^ r_0[0];
  assign r_0[2] = gc[1] | (pi_[1] & r_0[1]);
  assign s[1] = pi_[1] ^ r_0[1];
  assign r_0[3] = gc[2] | (pi_[2] & r_0[2]);
  assign s[2] = pi_[2] ^ r_0[2];
  assign r_0[4] = gc[3] | (pi_[3] & r_0[3]);
  assign s[3] = pi_[3] ^ r_0[3];
  logic [4:0] r_1;
  assign r_1[0] = bc[1];
  assign r_1[1] = gc[4] | (pi_[4] & r_1[0]);
  assign s[4] = pi_[4] ^ r_1[0];
  assign r_1[2] = gc[5] | (pi_[5] & r_1[1]);
  assign s[5] = pi_[5] ^ r_1[1];
  assign r_1[3] = gc[6] | (pi_[6] & r_1[2]);
  assign s[6] = pi_[6] ^ r_1[2];
  assign r_1[4] = gc[7] | (pi_[7] & r_1[3]);
  assign s[7] = pi_[7] ^ r_1[3];
  logic [2:0] r_2;
  assign r_2[0] = bc[2];
  assign r_2[1] = gc[8] | (pi_[8] & r_2[0]);
  assign s[8] = pi_[8] ^ r_2[0];
  assign r_2[2] = gc[9] | (pi_[9] & r_2[1]);
  assign s[9] = pi_[9] ^ r_2[1];
  assign cout = bc[3];
endmodule


module fam_prefix_kogge_stone_w12_ling4 (input logic [11:0] a, input logic [11:0] b, input logic cin,
  output logic [11:0] s, output logic cout);
  // prefix graph: {'n': 3, 'levels': 2, 'size': 3, 'fanout': 2, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [11:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [11:0] gc;
  assign gc = {gi[11:1], gi[0] | (pi_[0] & cin)};
  logic [2:0] g0, p0;
  assign g0[0] = gc[3] | gc[2] | (ti[2] & gc[1]) | (ti[2] & ti[1] & gc[0]);
  assign p0[0] = 1'b0;
  assign g0[1] = gc[7] | gc[6] | (ti[6] & gc[5]) | (ti[6] & ti[5] & gc[4]);
  assign p0[1] = ti[4] & ti[5] & ti[6] & ti[3];
  assign g0[2] = gc[11] | gc[10] | (ti[10] & gc[9]) | (ti[10] & ti[9] & gc[8]);
  assign p0[2] = ti[8] & ti[9] & ti[10] & ti[7];
  logic G_0_1, G_1_2, P_1_2, G_0_2;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  logic [3:0] bc;
  assign bc[0] = cin;
  assign bc[1] = ti[3] & g0[0];
  assign bc[2] = ti[7] & G_0_1;
  assign bc[3] = ti[11] & G_0_2;
  logic [4:0] r_0;
  assign r_0[0] = bc[0];
  assign r_0[1] = gc[0] | (pi_[0] & r_0[0]);
  assign s[0] = pi_[0] ^ r_0[0];
  assign r_0[2] = gc[1] | (pi_[1] & r_0[1]);
  assign s[1] = pi_[1] ^ r_0[1];
  assign r_0[3] = gc[2] | (pi_[2] & r_0[2]);
  assign s[2] = pi_[2] ^ r_0[2];
  assign r_0[4] = gc[3] | (pi_[3] & r_0[3]);
  assign s[3] = pi_[3] ^ r_0[3];
  logic [4:0] r_1;
  assign r_1[0] = bc[1];
  assign r_1[1] = gc[4] | (pi_[4] & r_1[0]);
  assign s[4] = pi_[4] ^ r_1[0];
  assign r_1[2] = gc[5] | (pi_[5] & r_1[1]);
  assign s[5] = pi_[5] ^ r_1[1];
  assign r_1[3] = gc[6] | (pi_[6] & r_1[2]);
  assign s[6] = pi_[6] ^ r_1[2];
  assign r_1[4] = gc[7] | (pi_[7] & r_1[3]);
  assign s[7] = pi_[7] ^ r_1[3];
  logic [4:0] r_2;
  assign r_2[0] = bc[2];
  assign r_2[1] = gc[8] | (pi_[8] & r_2[0]);
  assign s[8] = pi_[8] ^ r_2[0];
  assign r_2[2] = gc[9] | (pi_[9] & r_2[1]);
  assign s[9] = pi_[9] ^ r_2[1];
  assign r_2[3] = gc[10] | (pi_[10] & r_2[2]);
  assign s[10] = pi_[10] ^ r_2[2];
  assign r_2[4] = gc[11] | (pi_[11] & r_2[3]);
  assign s[11] = pi_[11] ^ r_2[3];
  assign cout = bc[3];
endmodule




module fam_prefix_kogge_stone_w2_v3 (input logic [1:0] a, input logic [1:0] b, input logic cin,
  output logic [1:0] s, output logic cout);
  // prefix graph: {'n': 2, 'levels': 1, 'size': 1, 'fanout': 1, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [1:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [1:0] g0, p0;
  assign g0 = {gi[1:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  logic [2:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign s = pi_ ^ c[1:0];
  assign cout = c[2];
endmodule




module fam_prefix_kogge_stone_w7_v3 (input logic [6:0] a, input logic [6:0] b, input logic cin,
  output logic [6:0] s, output logic cout);
  // prefix graph: {'n': 7, 'levels': 2, 'size': 10, 'fanout': 4, 'tracks': 3, 'exact_split': False, 'valency': 3}
  logic [6:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [6:0] g0, p0;
  assign g0 = {gi[6:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_0_2, G_1_3, P_1_3, G_2_4, P_2_4, G_3_5, P_3_5, G_4_6, P_4_6, G_0_3, G_0_4, G_0_5, G_0_6;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_0_2 = g0[2] | (p0[2] & (g0[1] | (p0[1] & g0[0])));
  assign G_1_3 = g0[3] | (p0[3] & (g0[2] | (p0[2] & g0[1])));
  assign P_1_3 = p0[3] & p0[2] & p0[1];
  assign G_2_4 = g0[4] | (p0[4] & (g0[3] | (p0[3] & g0[2])));
  assign P_2_4 = p0[4] & p0[3] & p0[2];
  assign G_3_5 = g0[5] | (p0[5] & (g0[4] | (p0[4] & g0[3])));
  assign P_3_5 = p0[5] & p0[4] & p0[3];
  assign G_4_6 = g0[6] | (p0[6] & (g0[5] | (p0[5] & g0[4])));
  assign P_4_6 = p0[6] & p0[5] & p0[4];
  assign G_0_3 = G_1_3 | (P_1_3 & g0[0]);
  assign G_0_4 = G_2_4 | (P_2_4 & G_0_1);
  assign G_0_5 = G_3_5 | (P_3_5 & G_0_2);
  assign G_0_6 = G_4_6 | (P_4_6 & (G_1_3 | (P_1_3 & g0[0])));
  logic [7:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign s = pi_ ^ c[6:0];
  assign cout = c[7];
endmodule


module fam_prefix_kogge_stone_w8_ling4 (input logic [7:0] a, input logic [7:0] b, input logic cin,
  output logic [7:0] s, output logic cout);
  // prefix graph: {'n': 2, 'levels': 1, 'size': 1, 'fanout': 1, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [7:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [7:0] gc;
  assign gc = {gi[7:1], gi[0] | (pi_[0] & cin)};
  logic [1:0] g0, p0;
  assign g0[0] = gc[3] | gc[2] | (ti[2] & gc[1]) | (ti[2] & ti[1] & gc[0]);
  assign p0[0] = 1'b0;
  assign g0[1] = gc[7] | gc[6] | (ti[6] & gc[5]) | (ti[6] & ti[5] & gc[4]);
  assign p0[1] = ti[4] & ti[5] & ti[6] & ti[3];
  logic G_0_1;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  logic [2:0] bc;
  assign bc[0] = cin;
  assign bc[1] = ti[3] & g0[0];
  assign bc[2] = ti[7] & G_0_1;
  logic [4:0] r_0;
  assign r_0[0] = bc[0];
  assign r_0[1] = gc[0] | (pi_[0] & r_0[0]);
  assign s[0] = pi_[0] ^ r_0[0];
  assign r_0[2] = gc[1] | (pi_[1] & r_0[1]);
  assign s[1] = pi_[1] ^ r_0[1];
  assign r_0[3] = gc[2] | (pi_[2] & r_0[2]);
  assign s[2] = pi_[2] ^ r_0[2];
  assign r_0[4] = gc[3] | (pi_[3] & r_0[3]);
  assign s[3] = pi_[3] ^ r_0[3];
  logic [4:0] r_1;
  assign r_1[0] = bc[1];
  assign r_1[1] = gc[4] | (pi_[4] & r_1[0]);
  assign s[4] = pi_[4] ^ r_1[0];
  assign r_1[2] = gc[5] | (pi_[5] & r_1[1]);
  assign s[5] = pi_[5] ^ r_1[1];
  assign r_1[3] = gc[6] | (pi_[6] & r_1[2]);
  assign s[6] = pi_[6] ^ r_1[2];
  assign r_1[4] = gc[7] | (pi_[7] & r_1[3]);
  assign s[7] = pi_[7] ^ r_1[3];
  assign cout = bc[2];
endmodule




// ---------------------------------------------------------------------- funnel
// a window of the word beside itself (a rotate), beside zeros (a left shift) or
// beside its fill (a right shift), and a W-bit slice selected at the position by
// ceil((AW + 1) / K) stages of 2^K:1 muxes (RADIX_LOG2 = K, the window mux radix).
// AMT_PRE: 1 subtract_from_n (a left operation reads the slice at W - amt of a
// 2W-bit window), 0 ones_complement_for_right (the window is 2W - 1 bits and a
// left operation reads the slice at ~amt = W - 1 - amt, which needs W a power of
// two; at another width the position is W - 1 - amt).
module fam_shift_funnel #(parameter int W = 16, parameter int RADIX_LOG2 = 1, parameter int AMT_PRE = 1, parameter int STICKY = 0)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic [2:0] op, output logic [W-1:0] y, output logic sticky);
  localparam int AW = $clog2(W);
  localparam int WW = AMT_PRE ? 2 * W : 2 * W - 1;               // the window width
  localparam int PW = AW + 1;                                    // the position width
  localparam int K = (RADIX_LOG2 == 0 || RADIX_LOG2 > PW) ? PW : RADIX_LOG2;
  localparam int NS = (PW + K - 1) / K;
  wire rot = (op == 3'd3) || (op == 3'd4);
  wire left = (op == 3'd0) || (op == 3'd3);
  wire right = ~left;
  wire arith = (op == 3'd2);
  wire fill = arith & a[W-1];
  logic [W-1:0] mask;
  fam_shift_keep_mask #(.W(W), .STICKY(STICKY)) u_mask (.a(a), .amt(amt), .right(right), .rot(rot), .mask(mask), .sticky(sticky));
  logic [WW-1:0] win;
  logic [PW-1:0] pos;
  genvar s;
  generate
    if (AMT_PRE) begin : subtract
      // {hi, lo}: a left operation by k reads the slice at W - k (0 reads the low word for a
      // rotate and the high for a shift), a right one at k
      assign win = rot ? {a, a} : (left ? {a, {W{1'b0}}} : {{W{fill}}, a});
      assign pos = left ? ((amt == 0) ? {PW{1'b0}} : (W - amt)) : {1'b0, amt};
    end else begin : complement
      // a 2W - 1-bit window: a left operation by k reads the slice at W - 1 - k, which is the
      // one's complement of k when W is a power of two
      assign win = rot ? (left ? {a, a[W-1:1]} : {a[W-2:0], a}) : (left ? {a, {(W-1){1'b0}}} : {{(W-1){fill}}, a});
      if ((W & (W - 1)) == 0) begin : pow2
        assign pos = left ? {1'b0, ~amt} : {1'b0, amt};
      end else begin : other
        assign pos = left ? (W - 1 - amt) : {1'b0, amt};
      end
    end
    // the slice: the window shifted right by the position through the mux stages, the low W bits
    logic [WW-1:0] st [0:NS];
    assign st[0] = win;
    for (s = 0; s < NS; s = s + 1) begin : stage
      localparam int KB = (s * K + K <= PW) ? K : PW - s * K;
      fam_shift_stage #(.W(WW), .K(KB), .SH(s * K), .RIGHT(1), .ONE_HOT(0))
        u (.x(st[s]), .digit(pos[s*K +: KB]), .rot(1'b0), .fill(1'b0), .y(st[s+1]));
    end
    if (AMT_PRE) begin : y_sub
      assign y = (left & (amt == 0)) ? a : st[NS][W-1:0];
    end else begin : y_cpl
      assign y = st[NS][W-1:0];
    end
  endgenerate
endmodule



// ----------------------------------------------------------- the keep mask
// mask[i] = 1 where a shift keeps the input bit that lands at i (a rotate keeps
// every bit): the thermometer of the amount for the direction. sticky is the OR
// of the input bits a shift moves out (the low amt bits of a right shift, the
// top amt bits of a left one; none for a rotate), read through the mask of the
// opposite direction, in parallel with the datapath.
module fam_shift_keep_mask #(parameter int W = 16, parameter int STICKY = 1)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic right, input logic rot,
   output logic [W-1:0] mask, output logic sticky);
  logic [W-1:0] kept_in;
  genvar i;
  generate
    for (i = 0; i < W; i = i + 1) begin : mk
      assign mask[i] = rot | (right ? (i < W - amt) : (i >= amt));
      assign kept_in[i] = rot | (right ? (i >= amt) : (i < W - amt));
    end
  endgenerate
  assign sticky = STICKY ? |(a & ~kept_in) : 1'b0;
endmodule




// ------------------------------------------------------------------ masked_merged
// a left rotator (the `rotator` slot's barrel: R_RADIX_LOG2, R_ONE_HOT, R_ORDER)
// plus a mask that turns the rotation into a shift by merging in the fill bits.
// MASKGEN: 0 thermometer_decode (one thermometer per direction, selected), 1
// two_thermometer_and (a low and a high bound thermometer ANDed), 2 lut (a table
// over the direction and the amount). MERGE: 0 and_or_merge, 1 per_bit_mux.
module fam_shift_masked_merged #(parameter int W = 16, parameter int MASKGEN = 0, parameter int MERGE = 0,
                                 parameter int R_RADIX_LOG2 = 1, parameter int R_ONE_HOT = 0, parameter int R_ORDER = 0, parameter int STICKY = 0)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic [2:0] op, output logic [W-1:0] y, output logic sticky);
  localparam int AW = $clog2(W);
  localparam int K = (R_RADIX_LOG2 == 0 || R_RADIX_LOG2 > AW) ? AW : R_RADIX_LOG2;
  localparam int NS = (AW + K - 1) / K;
  wire right = (op == 3'd1) || (op == 3'd2) || (op == 3'd4);
  wire rot = (op == 3'd3) || (op == 3'd4);
  wire arith = (op == 3'd2);
  wire fill = arith & a[W-1];
  // rotate left by amt (a right operation by k is a left rotation by W - k)
  logic [AW-1:0] lamt;
  assign lamt = right ? (W - amt) : amt;
  logic [W-1:0] st [0:NS];
  assign st[0] = a;
  genvar s, i;
  logic [W-1:0] mask;                 // 1 where the rotated bit is kept
  generate
    for (s = 0; s < NS; s = s + 1) begin : stage
      localparam int G = R_ORDER ? (NS - 1 - s) : s;
      localparam int KB = (G * K + K <= AW) ? K : AW - G * K;
      fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(0), .ONE_HOT(R_ONE_HOT))
        u (.x(st[s]), .digit(lamt[G*K +: KB]), .rot(1'b1), .fill(1'b0), .y(st[s+1]));
    end
    if (MASKGEN == 0) begin : thermo
      for (i = 0; i < W; i = i + 1) begin : mk
        assign mask[i] = right ? (i < W - amt) : (i >= amt);
      end
    end else if (MASKGEN == 1) begin : two_thermo
      // the field kept lies between a low and a high bound: [amt, W-1] for a left shift,
      // [0, W-1-amt] for a right one; each bound is a thermometer, the mask their AND. The
      // high bound is signed: a right amount at or past W (an amount code W leaves the whole
      // word when W is below a power of two) puts it below zero, and no bit is kept
      logic [AW:0] lo;
      logic signed [AW+1:0] hi;
      assign lo = right ? {(AW+1){1'b0}} : {1'b0, amt};
      assign hi = right ? ($signed(W - 1) - $signed({2'b00, amt})) : $signed(W - 1);
      logic [W-1:0] ge_lo, le_hi;
      for (i = 0; i < W; i = i + 1) begin : mk
        assign ge_lo[i] = (i >= lo);
        assign le_hi[i] = (hi >= 0) && (i <= hi);
      end
      assign mask = ge_lo & le_hi;
    end else begin : lut
      // the mask read from a table over the direction and the amount
      logic [AW:0] idx;
      assign idx = {right, amt};
      logic [W-1:0] tab [0:2*(1<<AW)-1];
      for (i = 0; i < 2 * (1 << AW); i = i + 1) begin : t
        localparam int RT = i >> AW;
        localparam int AM = i & ((1 << AW) - 1);
        genvar j;
        for (j = 0; j < W; j = j + 1) begin : bt
          assign tab[i][j] = RT ? (j < W - AM) : (j >= AM);
        end
      end
      assign mask = tab[idx];
    end
  endgenerate
  logic [W-1:0] mask_unused;
  fam_shift_keep_mask #(.W(W), .STICKY(STICKY)) u_sticky (.a(a), .amt(amt), .right(right), .rot(rot), .mask(mask_unused), .sticky(sticky));
  generate
    if (MERGE == 0) begin : and_or
      assign y = rot ? st[NS] : ((st[NS] & mask) | ({W{fill}} & ~mask));
    end else begin : per_bit
      for (i = 0; i < W; i = i + 1) begin : mx
        assign y[i] = (rot | mask[i]) ? st[NS][i] : fill;
      end
    end
  endgenerate
endmodule

// The shifter families of chiALU. One interface:
//   #(parameter int W) (input [W-1:0] a, input [AW-1:0] amt, input [2:0] op, output [W-1:0] y)
// op: 0 shl, 1 shr_logical, 2 shr_arith, 3 rol, 4 ror; amt is below W.
// Every family has `output sticky`, the OR of the bits a shift moves out (0 for a rotate), built
// when STICKY = 1 (the sticky_collect choice; an alignment shifter asks for it) and tied to 0
// otherwise; a consumer that does not collect it leaves the port unconnected.

// ------------------------------------------------------------------ one mux stage
// One stage of a shifter: the K-bit digit of the amount selects among R = 2^K
// candidates, candidate d being the input displaced by d * 2^SH to the left
// (RIGHT = 0) or to the right (RIGHT = 1), the vacated bits taken from the
// other end under `rot` or from `fill`. ONE_HOT = 1 decodes the digit to R
// select lines and forms the mux as an AND-OR (the select_encoding choice);
// ONE_HOT = 0 indexes the candidates by the binary digit.
module fam_shift_stage #(parameter int W = 16, parameter int K = 1, parameter int SH = 0,
                         parameter int RIGHT = 0, parameter int ONE_HOT = 0)
  (input logic [W-1:0] x, input logic [K-1:0] digit, input logic rot, input logic fill, output logic [W-1:0] y);
  localparam int R = 1 << K;
  localparam int D = 1 << SH;
  logic [W*R-1:0] cand;                       // candidate d at [d*W +: W]
  genvar d, i;
  generate
    for (d = 0; d < R; d = d + 1) begin : c
      for (i = 0; i < W; i = i + 1) begin : b
        localparam int S = d * D;             // the displacement of this candidate
        if (S >= W) begin : far
          // a displacement past the word: a rotate wraps it (mod W), a shift clears the word
          localparam int IDX = ((RIGHT ? (i + S) : (i - S)) % W + W) % W;
          assign cand[d*W + i] = rot ? x[IDX] : fill;
        end else if (RIGHT) begin : r
          if (i + S < W) begin : in_
            assign cand[d*W + i] = x[i + S];
          end else begin : out_
            assign cand[d*W + i] = rot ? x[i + S - W] : fill;
          end
        end else begin : l
          if (i >= S) begin : in_
            assign cand[d*W + i] = x[i - S];
          end else begin : out_
            assign cand[d*W + i] = rot ? x[W - S + i] : fill;
          end
        end
      end
    end
    if (ONE_HOT) begin : onehot
      logic [R-1:0] sel;
      for (d = 0; d < R; d = d + 1) begin : dec
        assign sel[d] = (digit == d);
      end
      for (i = 0; i < W; i = i + 1) begin : orb
        logic [R-1:0] t;
        for (d = 0; d < R; d = d + 1) begin : and_
          assign t[d] = sel[d] & cand[d*W + i];
        end
        assign y[i] = |t;
      end
    end else begin : binary
      assign y = cand[digit*W +: W];
    end
  endgenerate
endmodule
