// ADIR-MEMBER packages
// alu_core_m0_pkg: the exact-arithmetic functions of mode 0 (1xint16_twos_complement)
package alu_core_m0_pkg;

  // ---- m0: V = {special[1:0], sign, exp[8] (signed), sig[17]}
  //           X = {special[1:0], sign, exp[8] (signed), sig[38], sticky}
  localparam int m0_SW = 17, m0_EW = 8, m0_XW = 38;
  localparam int m0_VW = 28, m0_XT = 50;
  function automatic [27:0] m0_mkv(input [1:0] sp, input s, input signed [7:0] e, input [16:0] sig);
    m0_mkv = {sp, s, e, sig};
  endfunction
  function automatic [49:0] m0_mkx(input [1:0] sp, input s, input signed [7:0] e, input [37:0] sig, input st);
    m0_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [49:0] m0_x(input [27:0] v);   // widen V to X
    m0_x = {v[27:27-1], v[27-2], v[27-3 -: 8], {{(38-17){1'b0}}, v[16:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [49:0] m0_norm(input [49:0] x);
    logic [37:0] s; logic signed [7:0] e; integer k;
    s = x[38:1]; e = x[38+8:38+1];
    if (s != 0) begin
      for (k = 32; k >= 1; k = k / 2) begin
        if (k < 38) begin
          if (s[37 -: 1] == 1'b0 && (s >> (38 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m0_norm = {x[49:49-1], x[49-2], e, s, x[0]};
  endfunction

  function automatic m0_rup(input [2:0] rnd, input s, input inexact, input [38:0] rest, input [38:0] halfv,
                             input st, input lsb, input [38+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m0_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m0_rup = 1'b0;
      3'd2: m0_rup = inexact && s;
      3'd3: m0_rup = inexact && !s;
      3'd4: m0_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m0_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [49:0] m0_add(input [49:0] a, input [49:0] b, input sub);
    logic [49:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [7:0] ea, eb, d; logic [38:0] ms, mb, r; logic st, stb; integer sh;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1];
    sa = na[49-2]; sb = nb[49-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m0_add = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m0_add = (sa == sb) ? m0_mkx(2'd2, sa, 0, 0, 1'b0) : m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_add = m0_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m0_add = m0_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[38:1] == 0 && !na[0]) m0_add = {nb[49:49-1], sb, nb[49-3:0]};
    else if (nb[38:1] == 0 && !nb[0]) m0_add = na;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[38:1] >= nb[38:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[38+8:38+1] - sml[38+8:38+1];
      ms = {1'b0, sml[38:1]}; stb = sml[0];
      if (d > 38 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 38 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[38:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[38]) begin st = st | r[0]; r = r >> 1; m0_add = m0_mkx(2'd0, sr, big[38+8:38+1] + 1, r[37:0], st); end
      else m0_add = m0_mkx(2'd0, sr, big[38+8:38+1], r[37:0], st);
    end
  endfunction
  function automatic [49:0] m0_mul(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38-1:0] pr; logic st; integer k;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m0_mul = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[38:1] == 0 && !na[0]) || (spb == 2'd0 && nb[38:1] == 0 && !nb[0]))
        m0_mul = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m0_mul = m0_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[38:1] * nb[38:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[37:0] != 0);
      m0_mul = m0_mkx(2'd0, s, na[38+8:38+1] + nb[38+8:38+1] + 38, pr[2*38-1:38], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*38+1:0] m0_udiv(input [37:0] a, input [37:0] dv);
    logic [38+1:0] r; logic [38:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 38; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[37:0], ge};
      if (i > 0) r = {r[38:0], 1'b0};
    end
    m0_udiv = {q, r[38:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*38+8+2:0] m0_mulx(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*38-1:0] pr;
    na = m0_norm(a); nb = m0_norm(b);
    pr = na[38:1] * nb[38:1];
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[38:1] == 0) || (spb == 2'd0 && nb[38:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m0_mulx = {sp, s, na[38+8:38+1] + nb[38+8:38+1], pr};
  endfunction
  function automatic [49:0] m0_div(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38+1:0] qr; logic [38:0] q, r;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_div = m0_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m0_div = m0_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[38:1] == 0 && !nb[0]) begin
      if (na[38:1] == 0 && !na[0]) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m0_div = m0_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[38:1] == 0 && !na[0]) m0_div = m0_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m0_udiv(na[38:1], nb[38:1]);     // both normalized: nonzero finite
      q = qr[2*38+1:38+1]; r = qr[38:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[38]) m0_div = m0_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38 + 1, q[38:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m0_div = m0_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38, q[37:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [49:0] m0_sqrt(input [49:0] a);
    logic [49:0] na; logic [1:0] spa; logic signed [7:0] e; logic [38:0] m; logic [2*38+3:0] rad;
    logic [38+2:0] rem, trial; logic [38:0] root; logic ge; integer i;
    na = m0_norm(a); spa = na[49:49-1];
    if (spa == 2'd1) m0_sqrt = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_sqrt = na[49-2] ? m0_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[38:1] == 0 && !na[0]) m0_sqrt = na;
    else if (na[49-2]) m0_sqrt = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[38+8:38+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[38:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[38:1]};
      rad = {{(38+3){1'b0}}, m} << 38;
      rem = 0; root = 0;
      for (i = 38; i >= 0; i = i - 1) begin
        rem = {rem[38:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[37:0], ge};
      end
      m0_sqrt = m0_mkx(2'd0, 1'b0, (e >>> 1) - 19 + 1, root[38:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m0_lt(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [7:0] ea, eb;
    na = m0_norm(a); nb = m0_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    sa = na[49-2] && !za; sb = nb[49-2] && !zb;
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m0_lt = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2) begin
      if (na[49:49-1] == 2'd2 && nb[49:49-1] == 2'd2) m0_lt = na[49-2] && !nb[49-2];
      else if (na[49:49-1] == 2'd2) m0_lt = na[49-2];
      else m0_lt = !nb[49-2];
    end else if (za && zb) m0_lt = 1'b0;
    else if (sa != sb) m0_lt = sa;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[38:1] < nb[38:1] || (na[38:1] == nb[38:1] && !na[0] && nb[0])));
      m0_lt = sa ? !mag_lt && !(za && zb) && !m0_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m0_eq(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb;
    na = m0_norm(a); nb = m0_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m0_eq = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2)
      m0_eq = (na[49:49-1] == nb[49:49-1]) && (na[49-2] == nb[49-2]);
    else if (za || zb) m0_eq = za && zb;
    else m0_eq = (na[49-2] == nb[49-2]) && (na[38+8:38+1] == nb[38+8:38+1]) && (na[38:1] == nb[38:1]) && (na[0] == nb[0]);
  endfunction

  function automatic [28:0] m0_unpack_s(input [15:0] b, input daz);
    logic s; logic [15:0] mag; integer i;
    s = b[15]; mag = s ? (~b + 1'b1) : b;
    m0_unpack_s = {1'b0, m0_mkv(2'd0, s && (mag != 0), -0, {{(17-16){1'b0}}, mag})};
  endfunction

  function automatic [15:0] m0_enc(input signed [34:0] v); m0_enc = v[15:0]; endfunction
  function automatic [15:0] m0_wrap(input signed [34:0] v); m0_wrap = v[15:0]; endfunction
  function automatic [15:0] m0_sat(input signed [34:0] v);
    m0_sat = (v > 35'sd32767) ? {1'b0, {15{1'b1}}} : (v < -35'sd32768) ? {1'b1, {15{1'b0}}} : v[15:0];
  endfunction

  // round v / 2^f under rnd (the SR word applies to the fraction bits)
  function automatic signed [34:0] m0_rshift(input signed [34:0] v, input integer f, input [2:0] rnd, input [7:0] word);
    logic s; logic [34:0] mag, keep, rest, halfv; logic [43:0] fint; logic up, inexact;
    s = v < 0; mag = s ? -v : v;
    if (f <= 0) m0_rshift = v;
    else begin
      keep = mag >> f; rest = mag & (((35'd1) << f) - 1); halfv = (35'd1) << (f - 1);
      inexact = rest != 0;
      fint = (f >= 8) ? (rest >> (f - 8)) : (rest << (8 - f));
      case (rnd)
        3'd0: up = (rest > halfv) || (rest == halfv && keep[0]);
        3'd1: up = 1'b0;
        3'd2: up = inexact && s;
        3'd3: up = inexact && !s;
        3'd4: up = inexact && (0 ? (fint >= word) : (fint > word));
        default: up = inexact;
      endcase
      keep = keep + up;
      m0_rshift = s ? -$signed(keep) : $signed(keep);
    end
  endfunction
  // the SR word of a division: floor(|r| * 2^sb / |b|)
  function automatic [7:0] m0_divfrac(input [34:0] r, input [34:0] b);
    logic [43:0] t;
    t = ({{9{1'b0}}, r} << 8) / {{9{1'b0}}, b};
    m0_divfrac = t[7:0];
  endfunction
endpackage

// alu_core_m1_pkg: the exact-arithmetic functions of mode 1 (1xint16_unsigned)
package alu_core_m1_pkg;

  // ---- m1: V = {special[1:0], sign, exp[8] (signed), sig[17]}
  //           X = {special[1:0], sign, exp[8] (signed), sig[38], sticky}
  localparam int m1_SW = 17, m1_EW = 8, m1_XW = 38;
  localparam int m1_VW = 28, m1_XT = 50;
  function automatic [27:0] m1_mkv(input [1:0] sp, input s, input signed [7:0] e, input [16:0] sig);
    m1_mkv = {sp, s, e, sig};
  endfunction
  function automatic [49:0] m1_mkx(input [1:0] sp, input s, input signed [7:0] e, input [37:0] sig, input st);
    m1_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [49:0] m1_x(input [27:0] v);   // widen V to X
    m1_x = {v[27:27-1], v[27-2], v[27-3 -: 8], {{(38-17){1'b0}}, v[16:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [49:0] m1_norm(input [49:0] x);
    logic [37:0] s; logic signed [7:0] e; integer k;
    s = x[38:1]; e = x[38+8:38+1];
    if (s != 0) begin
      for (k = 32; k >= 1; k = k / 2) begin
        if (k < 38) begin
          if (s[37 -: 1] == 1'b0 && (s >> (38 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m1_norm = {x[49:49-1], x[49-2], e, s, x[0]};
  endfunction

  function automatic m1_rup(input [2:0] rnd, input s, input inexact, input [38:0] rest, input [38:0] halfv,
                             input st, input lsb, input [38+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m1_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m1_rup = 1'b0;
      3'd2: m1_rup = inexact && s;
      3'd3: m1_rup = inexact && !s;
      3'd4: m1_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m1_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [49:0] m1_add(input [49:0] a, input [49:0] b, input sub);
    logic [49:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [7:0] ea, eb, d; logic [38:0] ms, mb, r; logic st, stb; integer sh;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1];
    sa = na[49-2]; sb = nb[49-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m1_add = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m1_add = (sa == sb) ? m1_mkx(2'd2, sa, 0, 0, 1'b0) : m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_add = m1_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m1_add = m1_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[38:1] == 0 && !na[0]) m1_add = {nb[49:49-1], sb, nb[49-3:0]};
    else if (nb[38:1] == 0 && !nb[0]) m1_add = na;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[38:1] >= nb[38:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[38+8:38+1] - sml[38+8:38+1];
      ms = {1'b0, sml[38:1]}; stb = sml[0];
      if (d > 38 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 38 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[38:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[38]) begin st = st | r[0]; r = r >> 1; m1_add = m1_mkx(2'd0, sr, big[38+8:38+1] + 1, r[37:0], st); end
      else m1_add = m1_mkx(2'd0, sr, big[38+8:38+1], r[37:0], st);
    end
  endfunction
  function automatic [49:0] m1_mul(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38-1:0] pr; logic st; integer k;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m1_mul = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[38:1] == 0 && !na[0]) || (spb == 2'd0 && nb[38:1] == 0 && !nb[0]))
        m1_mul = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m1_mul = m1_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[38:1] * nb[38:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[37:0] != 0);
      m1_mul = m1_mkx(2'd0, s, na[38+8:38+1] + nb[38+8:38+1] + 38, pr[2*38-1:38], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*38+1:0] m1_udiv(input [37:0] a, input [37:0] dv);
    logic [38+1:0] r; logic [38:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 38; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[37:0], ge};
      if (i > 0) r = {r[38:0], 1'b0};
    end
    m1_udiv = {q, r[38:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*38+8+2:0] m1_mulx(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*38-1:0] pr;
    na = m1_norm(a); nb = m1_norm(b);
    pr = na[38:1] * nb[38:1];
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[38:1] == 0) || (spb == 2'd0 && nb[38:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m1_mulx = {sp, s, na[38+8:38+1] + nb[38+8:38+1], pr};
  endfunction
  function automatic [49:0] m1_div(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38+1:0] qr; logic [38:0] q, r;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_div = m1_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m1_div = m1_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[38:1] == 0 && !nb[0]) begin
      if (na[38:1] == 0 && !na[0]) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m1_div = m1_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[38:1] == 0 && !na[0]) m1_div = m1_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m1_udiv(na[38:1], nb[38:1]);     // both normalized: nonzero finite
      q = qr[2*38+1:38+1]; r = qr[38:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[38]) m1_div = m1_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38 + 1, q[38:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m1_div = m1_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38, q[37:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [49:0] m1_sqrt(input [49:0] a);
    logic [49:0] na; logic [1:0] spa; logic signed [7:0] e; logic [38:0] m; logic [2*38+3:0] rad;
    logic [38+2:0] rem, trial; logic [38:0] root; logic ge; integer i;
    na = m1_norm(a); spa = na[49:49-1];
    if (spa == 2'd1) m1_sqrt = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_sqrt = na[49-2] ? m1_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[38:1] == 0 && !na[0]) m1_sqrt = na;
    else if (na[49-2]) m1_sqrt = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[38+8:38+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[38:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[38:1]};
      rad = {{(38+3){1'b0}}, m} << 38;
      rem = 0; root = 0;
      for (i = 38; i >= 0; i = i - 1) begin
        rem = {rem[38:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[37:0], ge};
      end
      m1_sqrt = m1_mkx(2'd0, 1'b0, (e >>> 1) - 19 + 1, root[38:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m1_lt(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [7:0] ea, eb;
    na = m1_norm(a); nb = m1_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    sa = na[49-2] && !za; sb = nb[49-2] && !zb;
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m1_lt = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2) begin
      if (na[49:49-1] == 2'd2 && nb[49:49-1] == 2'd2) m1_lt = na[49-2] && !nb[49-2];
      else if (na[49:49-1] == 2'd2) m1_lt = na[49-2];
      else m1_lt = !nb[49-2];
    end else if (za && zb) m1_lt = 1'b0;
    else if (sa != sb) m1_lt = sa;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[38:1] < nb[38:1] || (na[38:1] == nb[38:1] && !na[0] && nb[0])));
      m1_lt = sa ? !mag_lt && !(za && zb) && !m1_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m1_eq(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb;
    na = m1_norm(a); nb = m1_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m1_eq = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2)
      m1_eq = (na[49:49-1] == nb[49:49-1]) && (na[49-2] == nb[49-2]);
    else if (za || zb) m1_eq = za && zb;
    else m1_eq = (na[49-2] == nb[49-2]) && (na[38+8:38+1] == nb[38+8:38+1]) && (na[38:1] == nb[38:1]) && (na[0] == nb[0]);
  endfunction

  function automatic [28:0] m1_unpack_s(input [15:0] b, input daz);
    logic s; logic [15:0] mag; integer i;
    s = 1'b0; mag = b;
    m1_unpack_s = {1'b0, m1_mkv(2'd0, s && (mag != 0), -0, {{(17-16){1'b0}}, mag})};
  endfunction

  function automatic [15:0] m1_enc(input signed [34:0] v); m1_enc = v[15:0]; endfunction
  function automatic [15:0] m1_wrap(input signed [34:0] v); m1_wrap = v[15:0]; endfunction
  function automatic [15:0] m1_sat(input signed [34:0] v);
    m1_sat = (v > 35'sd65535) ? {16{1'b1}} : (v < 0) ? 16'd0 : v[15:0];
  endfunction

  // round v / 2^f under rnd (the SR word applies to the fraction bits)
  function automatic signed [34:0] m1_rshift(input signed [34:0] v, input integer f, input [2:0] rnd, input [7:0] word);
    logic s; logic [34:0] mag, keep, rest, halfv; logic [43:0] fint; logic up, inexact;
    s = v < 0; mag = s ? -v : v;
    if (f <= 0) m1_rshift = v;
    else begin
      keep = mag >> f; rest = mag & (((35'd1) << f) - 1); halfv = (35'd1) << (f - 1);
      inexact = rest != 0;
      fint = (f >= 8) ? (rest >> (f - 8)) : (rest << (8 - f));
      case (rnd)
        3'd0: up = (rest > halfv) || (rest == halfv && keep[0]);
        3'd1: up = 1'b0;
        3'd2: up = inexact && s;
        3'd3: up = inexact && !s;
        3'd4: up = inexact && (0 ? (fint >= word) : (fint > word));
        default: up = inexact;
      endcase
      keep = keep + up;
      m1_rshift = s ? -$signed(keep) : $signed(keep);
    end
  endfunction
  // the SR word of a division: floor(|r| * 2^sb / |b|)
  function automatic [7:0] m1_divfrac(input [34:0] r, input [34:0] b);
    logic [43:0] t;
    t = ({{9{1'b0}}, r} << 8) / {{9{1'b0}}, b};
    m1_divfrac = t[7:0];
  endfunction
endpackage

// alu_core_m2_pkg: the exact-arithmetic functions of mode 2 (2xint8_twos_complement)
package alu_core_m2_pkg;

  // ---- m2: V = {special[1:0], sign, exp[8] (signed), sig[9]}
  //           X = {special[1:0], sign, exp[8] (signed), sig[22], sticky}
  localparam int m2_SW = 9, m2_EW = 8, m2_XW = 22;
  localparam int m2_VW = 20, m2_XT = 34;
  function automatic [19:0] m2_mkv(input [1:0] sp, input s, input signed [7:0] e, input [8:0] sig);
    m2_mkv = {sp, s, e, sig};
  endfunction
  function automatic [33:0] m2_mkx(input [1:0] sp, input s, input signed [7:0] e, input [21:0] sig, input st);
    m2_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [33:0] m2_x(input [19:0] v);   // widen V to X
    m2_x = {v[19:19-1], v[19-2], v[19-3 -: 8], {{(22-9){1'b0}}, v[8:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [33:0] m2_norm(input [33:0] x);
    logic [21:0] s; logic signed [7:0] e; integer k;
    s = x[22:1]; e = x[22+8:22+1];
    if (s != 0) begin
      for (k = 16; k >= 1; k = k / 2) begin
        if (k < 22) begin
          if (s[21 -: 1] == 1'b0 && (s >> (22 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m2_norm = {x[33:33-1], x[33-2], e, s, x[0]};
  endfunction

  function automatic m2_rup(input [2:0] rnd, input s, input inexact, input [22:0] rest, input [22:0] halfv,
                             input st, input lsb, input [22+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m2_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m2_rup = 1'b0;
      3'd2: m2_rup = inexact && s;
      3'd3: m2_rup = inexact && !s;
      3'd4: m2_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m2_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [33:0] m2_add(input [33:0] a, input [33:0] b, input sub);
    logic [33:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [7:0] ea, eb, d; logic [22:0] ms, mb, r; logic st, stb; integer sh;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[33:33-1]; spb = nb[33:33-1];
    sa = na[33-2]; sb = nb[33-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m2_add = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m2_add = (sa == sb) ? m2_mkx(2'd2, sa, 0, 0, 1'b0) : m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_add = m2_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m2_add = m2_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[22:1] == 0 && !na[0]) m2_add = {nb[33:33-1], sb, nb[33-3:0]};
    else if (nb[22:1] == 0 && !nb[0]) m2_add = na;
    else begin
      ea = na[22+8:22+1]; eb = nb[22+8:22+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[22:1] >= nb[22:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[22+8:22+1] - sml[22+8:22+1];
      ms = {1'b0, sml[22:1]}; stb = sml[0];
      if (d > 22 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 22 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[22:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[22]) begin st = st | r[0]; r = r >> 1; m2_add = m2_mkx(2'd0, sr, big[22+8:22+1] + 1, r[21:0], st); end
      else m2_add = m2_mkx(2'd0, sr, big[22+8:22+1], r[21:0], st);
    end
  endfunction
  function automatic [33:0] m2_mul(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*22-1:0] pr; logic st; integer k;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[33:33-1]; spb = nb[33:33-1]; s = na[33-2] ^ nb[33-2];
    if (spa == 2'd1 || spb == 2'd1) m2_mul = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[22:1] == 0 && !na[0]) || (spb == 2'd0 && nb[22:1] == 0 && !nb[0]))
        m2_mul = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m2_mul = m2_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[22:1] * nb[22:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[21:0] != 0);
      m2_mul = m2_mkx(2'd0, s, na[22+8:22+1] + nb[22+8:22+1] + 22, pr[2*22-1:22], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*22+1:0] m2_udiv(input [21:0] a, input [21:0] dv);
    logic [22+1:0] r; logic [22:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 22; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[21:0], ge};
      if (i > 0) r = {r[22:0], 1'b0};
    end
    m2_udiv = {q, r[22:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*22+8+2:0] m2_mulx(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*22-1:0] pr;
    na = m2_norm(a); nb = m2_norm(b);
    pr = na[22:1] * nb[22:1];
    spa = na[33:33-1]; spb = nb[33:33-1]; s = na[33-2] ^ nb[33-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[22:1] == 0) || (spb == 2'd0 && nb[22:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m2_mulx = {sp, s, na[22+8:22+1] + nb[22+8:22+1], pr};
  endfunction
  function automatic [33:0] m2_div(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*22+1:0] qr; logic [22:0] q, r;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[33:33-1]; spb = nb[33:33-1]; s = na[33-2] ^ nb[33-2];
    if (spa == 2'd1 || spb == 2'd1) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_div = m2_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m2_div = m2_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[22:1] == 0 && !nb[0]) begin
      if (na[22:1] == 0 && !na[0]) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m2_div = m2_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[22:1] == 0 && !na[0]) m2_div = m2_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m2_udiv(na[22:1], nb[22:1]);     // both normalized: nonzero finite
      q = qr[2*22+1:22+1]; r = qr[22:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[22]) m2_div = m2_mkx(2'd0, s, na[22+8:22+1] - nb[22+8:22+1] - 22 + 1, q[22:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m2_div = m2_mkx(2'd0, s, na[22+8:22+1] - nb[22+8:22+1] - 22, q[21:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [33:0] m2_sqrt(input [33:0] a);
    logic [33:0] na; logic [1:0] spa; logic signed [7:0] e; logic [22:0] m; logic [2*22+3:0] rad;
    logic [22+2:0] rem, trial; logic [22:0] root; logic ge; integer i;
    na = m2_norm(a); spa = na[33:33-1];
    if (spa == 2'd1) m2_sqrt = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_sqrt = na[33-2] ? m2_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[22:1] == 0 && !na[0]) m2_sqrt = na;
    else if (na[33-2]) m2_sqrt = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[22+8:22+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[22:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[22:1]};
      rad = {{(22+3){1'b0}}, m} << 22;
      rem = 0; root = 0;
      for (i = 22; i >= 0; i = i - 1) begin
        rem = {rem[22:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[21:0], ge};
      end
      m2_sqrt = m2_mkx(2'd0, 1'b0, (e >>> 1) - 11 + 1, root[22:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m2_lt(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [7:0] ea, eb;
    na = m2_norm(a); nb = m2_norm(b);
    za = (na[22:1] == 0) && !na[0]; zb = (nb[22:1] == 0) && !nb[0];
    sa = na[33-2] && !za; sb = nb[33-2] && !zb;
    if (na[33:33-1] == 2'd1 || nb[33:33-1] == 2'd1) m2_lt = 1'b0;
    else if (na[33:33-1] == 2'd2 || nb[33:33-1] == 2'd2) begin
      if (na[33:33-1] == 2'd2 && nb[33:33-1] == 2'd2) m2_lt = na[33-2] && !nb[33-2];
      else if (na[33:33-1] == 2'd2) m2_lt = na[33-2];
      else m2_lt = !nb[33-2];
    end else if (za && zb) m2_lt = 1'b0;
    else if (sa != sb) m2_lt = sa;
    else begin
      ea = na[22+8:22+1]; eb = nb[22+8:22+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[22:1] < nb[22:1] || (na[22:1] == nb[22:1] && !na[0] && nb[0])));
      m2_lt = sa ? !mag_lt && !(za && zb) && !m2_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m2_eq(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic za, zb;
    na = m2_norm(a); nb = m2_norm(b);
    za = (na[22:1] == 0) && !na[0]; zb = (nb[22:1] == 0) && !nb[0];
    if (na[33:33-1] == 2'd1 || nb[33:33-1] == 2'd1) m2_eq = 1'b0;
    else if (na[33:33-1] == 2'd2 || nb[33:33-1] == 2'd2)
      m2_eq = (na[33:33-1] == nb[33:33-1]) && (na[33-2] == nb[33-2]);
    else if (za || zb) m2_eq = za && zb;
    else m2_eq = (na[33-2] == nb[33-2]) && (na[22+8:22+1] == nb[22+8:22+1]) && (na[22:1] == nb[22:1]) && (na[0] == nb[0]);
  endfunction

  function automatic [20:0] m2_unpack_s(input [7:0] b, input daz);
    logic s; logic [7:0] mag; integer i;
    s = b[7]; mag = s ? (~b + 1'b1) : b;
    m2_unpack_s = {1'b0, m2_mkv(2'd0, s && (mag != 0), -0, {{(9-8){1'b0}}, mag})};
  endfunction

  function automatic [7:0] m2_enc(input signed [18:0] v); m2_enc = v[7:0]; endfunction
  function automatic [7:0] m2_wrap(input signed [18:0] v); m2_wrap = v[7:0]; endfunction
  function automatic [7:0] m2_sat(input signed [18:0] v);
    m2_sat = (v > 19'sd127) ? {1'b0, {7{1'b1}}} : (v < -19'sd128) ? {1'b1, {7{1'b0}}} : v[7:0];
  endfunction

  // round v / 2^f under rnd (the SR word applies to the fraction bits)
  function automatic signed [18:0] m2_rshift(input signed [18:0] v, input integer f, input [2:0] rnd, input [7:0] word);
    logic s; logic [18:0] mag, keep, rest, halfv; logic [27:0] fint; logic up, inexact;
    s = v < 0; mag = s ? -v : v;
    if (f <= 0) m2_rshift = v;
    else begin
      keep = mag >> f; rest = mag & (((19'd1) << f) - 1); halfv = (19'd1) << (f - 1);
      inexact = rest != 0;
      fint = (f >= 8) ? (rest >> (f - 8)) : (rest << (8 - f));
      case (rnd)
        3'd0: up = (rest > halfv) || (rest == halfv && keep[0]);
        3'd1: up = 1'b0;
        3'd2: up = inexact && s;
        3'd3: up = inexact && !s;
        3'd4: up = inexact && (0 ? (fint >= word) : (fint > word));
        default: up = inexact;
      endcase
      keep = keep + up;
      m2_rshift = s ? -$signed(keep) : $signed(keep);
    end
  endfunction
  // the SR word of a division: floor(|r| * 2^sb / |b|)
  function automatic [7:0] m2_divfrac(input [18:0] r, input [18:0] b);
    logic [27:0] t;
    t = ({{9{1'b0}}, r} << 8) / {{9{1'b0}}, b};
    m2_divfrac = t[7:0];
  endfunction
endpackage
// ADIR-MEMBER top
// EVOLVE-BLOCK-START
// ADIR-DECL v1
// VAR core.multiplier.m2.family=twin_precision_subword
// VAR core.logic.m0.family=wide_gate_row
// VAR core.logic.m1.family=wide_gate_row
// VAR core.logic.m2.family=wide_gate_row
// VAR core.adder.m0.family=compound_flagged_prefix
// VAR core.adder.m0.outputs=sum_sum1_summinus1
// VAR core.adder.m0.implementation=flag_row
// VAR core.adder.m1.family=parallel_prefix
// VAR core.adder.m1.topology=han_carlson
// VAR core.adder.m2.family=carry_skip
// VAR core.adder.m2.block_width=5
// VAR core.adder.m2.block_adder.full_adder_logic=two_half_adders_or
// VAR core.multiplier.m0.family=segmented_grid
// VAR core.multiplier.m0.recursion_depth=3
// VAR core.multiplier.m0.num_seg=4
// VAR core.multiplier.m0.segment.group_bits=2
// VAR core.multiplier.m0.segment.signed_scheme=sign_extension
// VAR core.multiplier.m0.segment.reduction.geometry=balanced_delay
// VAR core.multiplier.m0.segment.reduction.counter_kind=5_2
// VAR core.multiplier.m0.segment.reduction.cpa.adder.family=prefix_synthesis_nonuniform_arrival
// VAR core.multiplier.m0.segment.reduction.cpa.adder.arrival_profile=lsb_late
// VAR core.multiplier.m0.segment.hard_multiple_adder.family=parallel_prefix
// VAR core.multiplier.m0.segment.hard_multiple_adder.topology=han_carlson
// VAR core.multiplier.m0.merge_adder.family=sparse_prefix_hybrid
// VAR core.multiplier.m0.merge_adder.log2_sparsity=1
// VAR core.multiplier.m0.merge_adder.tree_topology=knowles_mixed
// VAR core.multiplier.m0.merge_adder.sum_block_style=conditional_sum
// VAR core.multiplier.m0.merge_tree.geometry=tdm_arrival_driven
// VAR core.multiplier.m0.merge_tree.counter_kind=4_2
// VAR core.multiplier.m0.merge_tree.cpa.adder.family=carry_skip
// VAR core.multiplier.m0.merge_tree.cpa.adder.skip_gate=and_or_bypass
// VAR core.multiplier.m0.merge_tree.cpa.adder.block_adder.family=parallel_prefix
// VAR core.multiplier.m0.merge_tree.cpa.adder.block_adder.valency=3
// VAR core.multiplier.m1.family=squarer
// VAR core.multiplier.m1.folding_scheme=divide_and_conquer
// VAR core.multiplier.m1.reduction.family=tiled_cpa_reduction_tree
// VAR core.multiplier.m1.reduction.adder_width=4
// VAR core.multiplier.m1.reduction.carry_assimilation=staggered_tiling
// VAR core.multiplier.m1.reduction.cpa.adder.family=sparse_prefix_hybrid
// VAR core.multiplier.m1.reduction.cpa.adder.log2_sparsity=1
// VAR core.multiplier.m1.reduction.cpa.adder.tree_topology=kogge_stone
// VAR core.multiplier.m1.reduction.cpa.adder.sum_block_style=ripple_precompute
// VAR core.multiplier.m1.reduction.cpa.adder.sum_block.family=parallel_prefix
// VAR core.multiplier.m1.reduction.cpa.adder.sum_block.topology=knowles_mixed
// VAR core.multiplier.m1.reduction.tile_adder.family=prefix_synthesis_nonuniform_arrival
// VAR core.multiplier.m1.reduction.tile_adder.arrival_profile=lsb_late
// VAR core.multiplier.m1.cross.family=booth_recoded_parallel
// VAR core.multiplier.m1.cross.booth_radix=8
// VAR core.multiplier.m1.cross.hard_multiple_gen=specialized_3m_cpa
// VAR core.multiplier.m1.cross.sign_extension=roorda_compact
// VAR core.multiplier.m1.cross.negative_pp_encoding=twos_complement_row
// VAR core.multiplier.m1.cross.reduction.family=tiled_cpa_reduction_tree
// VAR core.multiplier.m1.cross.reduction.adder_width=4
// VAR core.multiplier.m1.cross.reduction.cpa.family=hybrid_arrival_driven
// VAR core.multiplier.m1.cross.reduction.cpa.region_count=4
// VAR core.multiplier.m1.cross.reduction.cpa.arrival_model=measured_tree_profile
// VAR core.multiplier.m1.cross.reduction.cpa.boundary_search=delay_bound_boundary_enumeration
// VAR core.multiplier.m1.cross.reduction.tile_adder.family=compound_flagged_prefix
// VAR core.multiplier.m1.cross.reduction.tile_adder.topology=han_carlson
// VAR core.multiplier.m1.cross.reduction.tile_adder.late_carry_in=true
// VAR core.multiplier.m1.cross.hard_multiple_adder.family=ling_prefix
// VAR core.multiplier.m1.cross.hard_multiple_adder.topology=knowles_mixed
// VAR core.multiplier.m1.cross.hard_multiple_adder.sum_recovery=xor_correction
// VAR core.multiplier.m1.pre_adder.family=manchester_carry_chain
// VAR core.multiplier.m1.pre_adder.variable_skip=true
// VAR core.shifter.m0.stage_radix=4
// VAR core.shifter.m0.stage_order=large_shift_first
// VAR core.shifter.m0.direction_handling=data_reversal
// VAR core.shifter.m0.sticky_collect=true
// VAR core.shifter.m1.stage_radix=full_width_single_stage
// VAR core.shifter.m2.family=masked_merged
// VAR core.shifter.m2.mask_generator=lut
// VAR core.shifter.m2.merge_style=per_bit_mux
// VAR core.shifter.m2.rotator.stage_radix=8
// VAR core.shifter.m2.rotator.stage_order=large_shift_first
// VAR core.bitcount.m0.family=lzd_cell_tree
// VAR core.bitcount.m0.block_primitive=nibble_cell
// VAR core.bitcount.m0.valid_flag_propagation=true
// VAR core.bitcount.m1.family=lzd_cell_tree
// VAR core.bitcount.m1.valid_flag_propagation=true
// VAR core.bitcount.m2.family=priority_encoder
// VAR core.bitcount.m2.output_form=direct_binary
// VAR core.bitcount.m2.lookahead_group=16
// VAR core.bitcount.m2.levels=2
// VAR core.comparator.m0.family=subtractor_comparator
// VAR core.comparator.m0.subtractor.family=parallel_prefix
// VAR core.comparator.m0.subtractor.topology=kogge_stone
// VAR core.comparator.m1.family=subtractor_comparator
// VAR core.comparator.m1.subtractor.family=prefix_synthesis_nonuniform_arrival
// VAR core.comparator.m2.family=subtractor_comparator
// VAR core.comparator.m2.subtractor.family=end_around_carry
// VAR core.comparator.m2.subtractor.modulus=generic_p_correction
// VAR core.comparator.m2.subtractor.topology=ladner_fischer
// VAR core.comparator.m2.subtractor.modulus_value=165
// VAR core.subword.family=replicated_lanes
// STRUCTURE m0.l0.adder kind=adder slot=adder mode=0 lane=0 width=16 format=int16_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m0_l0_adder
// STRUCTURE m0.l0.multiplier kind=multiplier slot=multiplier mode=0 lane=0 width=16 format=int16_twos_complement ops=mul,mul_high sv=alu_core_u_m0_l0_multiplier
// STRUCTURE m0.l0.comparator kind=comparator slot=comparator mode=0 lane=0 width=16 format=int16_twos_complement ops=min,max,cmp sv=alu_core_u_m0_l0_comparator
// STRUCTURE m0.l0.shifter kind=shifter slot=shifter mode=0 lane=0 width=16 format=int16_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m0_l0_shifter
// STRUCTURE m0.l0.logic kind=logic slot=logic mode=0 lane=0 width=16 format=int16_twos_complement ops=and,or,xor,not sv=alu_core_u_gate_rows_0 group=gate_rows_0
// STRUCTURE m0.l0.bitcount kind=bitcount slot=bitcount mode=0 lane=0 width=16 format=int16_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m0_l0_bitcount
// STRUCTURE m1.l0.adder kind=adder slot=adder mode=1 lane=0 width=16 format=int16_unsigned ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m1_l0_adder
// STRUCTURE m1.l0.multiplier kind=multiplier slot=multiplier mode=1 lane=0 width=16 format=int16_unsigned ops=mul,mul_high sv=alu_core_u_m1_l0_multiplier
// STRUCTURE m1.l0.comparator kind=comparator slot=comparator mode=1 lane=0 width=16 format=int16_unsigned ops=min,max,cmp sv=alu_core_u_m1_l0_comparator
// STRUCTURE m1.l0.shifter kind=shifter slot=shifter mode=1 lane=0 width=16 format=int16_unsigned ops=shl,shr_arith,rol sv=alu_core_u_m1_l0_shifter
// STRUCTURE m1.l0.logic kind=logic slot=logic mode=1 lane=0 width=16 format=int16_unsigned ops=and,or,xor,not sv=alu_core_u_gate_rows_0 group=gate_rows_0
// STRUCTURE m1.l0.bitcount kind=bitcount slot=bitcount mode=1 lane=0 width=16 format=int16_unsigned ops=popcount,clz,ctz sv=alu_core_u_m1_l0_bitcount
// STRUCTURE m2.l0.adder kind=adder slot=adder mode=2 lane=0 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m2_l0_adder
// STRUCTURE m2.l1.adder kind=adder slot=adder mode=2 lane=1 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m2_l1_adder
// STRUCTURE m2.l0.multiplier kind=multiplier slot=multiplier mode=2 lane=0 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_multipliers_0 group=multipliers_0
// STRUCTURE m2.l1.multiplier kind=multiplier slot=multiplier mode=2 lane=1 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_multipliers_0 group=multipliers_0
// STRUCTURE m2.l0.comparator kind=comparator slot=comparator mode=2 lane=0 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_m2_l0_comparator
// STRUCTURE m2.l1.comparator kind=comparator slot=comparator mode=2 lane=1 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_m2_l1_comparator
// STRUCTURE m2.l0.shifter kind=shifter slot=shifter mode=2 lane=0 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l0_shifter
// STRUCTURE m2.l1.shifter kind=shifter slot=shifter mode=2 lane=1 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l1_shifter
// STRUCTURE m2.l0.logic kind=logic slot=logic mode=2 lane=0 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_gate_rows_0 group=gate_rows_0
// STRUCTURE m2.l1.logic kind=logic slot=logic mode=2 lane=1 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_gate_rows_0 group=gate_rows_0
// STRUCTURE m2.l0.bitcount kind=bitcount slot=bitcount mode=2 lane=0 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l0_bitcount
// STRUCTURE m2.l1.bitcount kind=bitcount slot=bitcount mode=2 lane=1 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l1_bitcount
// ADIR-END
module alu_core (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  output logic [15:0] y,
  output logic [3:0] flags
);
  // alu_core: behavioral reference derived from the instance (modes 1xint16_twos_complement, 1xint16_unsigned, 2xint8_twos_complement; ops add, sub, adc, neg, abs, add_sat, mul, mul_high, min, max, cmp, shl, shr_arith, rol, and, or, xor, not, popcount, clz, ctz). Every (mode, op) pair computes the verify layer's exact semantics.
  // HIERARCHY: 20 physical structure modules instantiated by alu_core, built from 15 lane modules (one per mode and kind, parameter LANE) and 3 packages of engine functions (one per mode); a float mode's datapath is split into an unpacker (the xa/xb/den buses), the arithmetic and converter structures (unrounded results on the x bus) and a rounder (y and the flags); 0 misc lane modules and 0 block-conversion group modules
  // UNIT multipliers_0 module=alu_core_u_multipliers_0 kind=multiplier members=m2.l0.multiplier,m2.l1.multiplier
  // UNIT gate_rows_0 module=alu_core_u_gate_rows_0 kind=logic members=m0.l0.logic,m1.l0.logic,m2.l0.logic,m2.l1.logic
  // UNIT m0.l0.adder module=alu_core_u_m0_l0_adder kind=adder members=m0.l0.adder
  // UNIT m0.l0.multiplier module=alu_core_u_m0_l0_multiplier kind=multiplier members=m0.l0.multiplier
  // UNIT m0.l0.comparator module=alu_core_u_m0_l0_comparator kind=comparator members=m0.l0.comparator
  // UNIT m0.l0.shifter module=alu_core_u_m0_l0_shifter kind=shifter members=m0.l0.shifter
  // UNIT m0.l0.bitcount module=alu_core_u_m0_l0_bitcount kind=bitcount members=m0.l0.bitcount
  // UNIT m1.l0.adder module=alu_core_u_m1_l0_adder kind=adder members=m1.l0.adder
  // UNIT m1.l0.multiplier module=alu_core_u_m1_l0_multiplier kind=multiplier members=m1.l0.multiplier
  // UNIT m1.l0.comparator module=alu_core_u_m1_l0_comparator kind=comparator members=m1.l0.comparator
  // UNIT m1.l0.shifter module=alu_core_u_m1_l0_shifter kind=shifter members=m1.l0.shifter
  // UNIT m1.l0.bitcount module=alu_core_u_m1_l0_bitcount kind=bitcount members=m1.l0.bitcount
  // UNIT m2.l0.adder module=alu_core_u_m2_l0_adder kind=adder members=m2.l0.adder
  // UNIT m2.l1.adder module=alu_core_u_m2_l1_adder kind=adder members=m2.l1.adder
  // UNIT m2.l0.comparator module=alu_core_u_m2_l0_comparator kind=comparator members=m2.l0.comparator
  // UNIT m2.l1.comparator module=alu_core_u_m2_l1_comparator kind=comparator members=m2.l1.comparator
  // UNIT m2.l0.shifter module=alu_core_u_m2_l0_shifter kind=shifter members=m2.l0.shifter
  // UNIT m2.l1.shifter module=alu_core_u_m2_l1_shifter kind=shifter members=m2.l1.shifter
  // UNIT m2.l0.bitcount module=alu_core_u_m2_l0_bitcount kind=bitcount members=m2.l0.bitcount
  // UNIT m2.l1.bitcount module=alu_core_u_m2_l1_bitcount kind=bitcount members=m2.l1.bitcount
  // // STRUCTURE m0.l0.adder kind=adder slot=adder mode=0 lane=0 width=16 format=int16_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m0_l0_adder
  // // STRUCTURE m0.l0.multiplier kind=multiplier slot=multiplier mode=0 lane=0 width=16 format=int16_twos_complement ops=mul,mul_high sv=alu_core_u_m0_l0_multiplier
  // // STRUCTURE m0.l0.comparator kind=comparator slot=comparator mode=0 lane=0 width=16 format=int16_twos_complement ops=min,max,cmp sv=alu_core_u_m0_l0_comparator
  // // STRUCTURE m0.l0.shifter kind=shifter slot=shifter mode=0 lane=0 width=16 format=int16_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m0_l0_shifter
  // // STRUCTURE m0.l0.logic kind=logic slot=logic mode=0 lane=0 width=16 format=int16_twos_complement ops=and,or,xor,not sv=alu_core_u_gate_rows_0
  // // STRUCTURE m0.l0.bitcount kind=bitcount slot=bitcount mode=0 lane=0 width=16 format=int16_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m0_l0_bitcount
  // // STRUCTURE m1.l0.adder kind=adder slot=adder mode=1 lane=0 width=16 format=int16_unsigned ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m1_l0_adder
  // // STRUCTURE m1.l0.multiplier kind=multiplier slot=multiplier mode=1 lane=0 width=16 format=int16_unsigned ops=mul,mul_high sv=alu_core_u_m1_l0_multiplier
  // // STRUCTURE m1.l0.comparator kind=comparator slot=comparator mode=1 lane=0 width=16 format=int16_unsigned ops=min,max,cmp sv=alu_core_u_m1_l0_comparator
  // // STRUCTURE m1.l0.shifter kind=shifter slot=shifter mode=1 lane=0 width=16 format=int16_unsigned ops=shl,shr_arith,rol sv=alu_core_u_m1_l0_shifter
  // // STRUCTURE m1.l0.logic kind=logic slot=logic mode=1 lane=0 width=16 format=int16_unsigned ops=and,or,xor,not sv=alu_core_u_gate_rows_0
  // // STRUCTURE m1.l0.bitcount kind=bitcount slot=bitcount mode=1 lane=0 width=16 format=int16_unsigned ops=popcount,clz,ctz sv=alu_core_u_m1_l0_bitcount
  // // STRUCTURE m2.l0.adder kind=adder slot=adder mode=2 lane=0 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m2_l0_adder
  // // STRUCTURE m2.l1.adder kind=adder slot=adder mode=2 lane=1 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m2_l1_adder
  // // STRUCTURE m2.l0.multiplier kind=multiplier slot=multiplier mode=2 lane=0 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_multipliers_0
  // // STRUCTURE m2.l1.multiplier kind=multiplier slot=multiplier mode=2 lane=1 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_multipliers_0
  // // STRUCTURE m2.l0.comparator kind=comparator slot=comparator mode=2 lane=0 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_m2_l0_comparator
  // // STRUCTURE m2.l1.comparator kind=comparator slot=comparator mode=2 lane=1 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_m2_l1_comparator
  // // STRUCTURE m2.l0.shifter kind=shifter slot=shifter mode=2 lane=0 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l0_shifter
  // // STRUCTURE m2.l1.shifter kind=shifter slot=shifter mode=2 lane=1 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l1_shifter
  // // STRUCTURE m2.l0.logic kind=logic slot=logic mode=2 lane=0 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_gate_rows_0
  // // STRUCTURE m2.l1.logic kind=logic slot=logic mode=2 lane=1 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_gate_rows_0
  // // STRUCTURE m2.l0.bitcount kind=bitcount slot=bitcount mode=2 lane=0 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l0_bitcount
  // // STRUCTURE m2.l1.bitcount kind=bitcount slot=bitcount mode=2 lane=1 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l1_bitcount
  // LIBRARY: fam_adder_carry_select_w5, fam_adder_carry_select_w5_component_block_adder_adder_w1, fam_adder_carry_select_w5_component_block_adder_adder_w4, fam_adder_carry_skip_pa39c40615e8121c47344c8e7421357ece0ee9686d31fd75f7bfde2405c0d679e_w8, fam_adder_carry_skip_pa39c40615e8121c47344c8e7421357ece0ee9686d31fd75f7bfde2405c0d679e_w8_component_block_adder_adder_w3, fam_adder_carry_skip_pa39c40615e8121c47344c8e7421357ece0ee9686d31fd75f7bfde2405c0d679e_w8_component_block_adder_adder_w5, fam_adder_conditional_sum, fam_adder_eac_cyclic_prefix_level_p49961f094ec9edb5039f1a4ebe8b25f3a7b6da85cb8155779bdd360605f439ba_w8, fam_adder_manchester_carry_chain, fam_adder_ripple_carry, fam_adder_ripple_chunk, fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10, fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14, fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w34, fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36, fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2, fam_binary_decode_fam_adder_eac_cyclic_prefix_level_p49961f094ec9edb5039f1a4ebe8b25f3a7b6da85cb8155779bdd360605f439ba_w8, fam_cmp_subtractor_end_around_carry_p49961f094ec9edb5039f1a4ebe8b25f3a7b6da85cb8155779bdd360605f439ba_sum_or_tree_s_w8, fam_cmp_subtractor_parallel_prefix_p342d4c3a5c869c66271da18b33b3b0a025b39f54fb5f2f6451ab982e08120d27_sum_or_tree_s_w16, fam_cmp_subtractor_prefix_synthesis_nonuniform_arrival_p91919e29d8984fc7b1564e16baf52afcd8459b99d9f7793d8c56df316dce0a37_sum_or_tree_u_w16, fam_count_lzd_nibble_cell_binary_count_vprop_w16, fam_count_lzd_pair_cell_binary_count_vprop_w16, fam_count_priority_encoder_g16_l2_direct_binary_w8, fam_incr_prefix_and, fam_logic_gate_row, fam_mul_booth8_dadda_3_2_w10_s_p284dba6b, fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2, fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2, fam_mul_segmented_grid_w16_s_p507511d0, fam_mul_segmented_grid_w16_s_p507511d0_g00, fam_mul_segmented_grid_w16_s_p507511d0_g01, fam_mul_segmented_grid_w16_s_p507511d0_g02, fam_mul_segmented_grid_w16_s_p507511d0_g03, fam_mul_segmented_grid_w16_s_p507511d0_g10, fam_mul_segmented_grid_w16_s_p507511d0_g11, fam_mul_segmented_grid_w16_s_p507511d0_g12, fam_mul_segmented_grid_w16_s_p507511d0_g13, fam_mul_segmented_grid_w16_s_p507511d0_g20, fam_mul_segmented_grid_w16_s_p507511d0_g21, fam_mul_segmented_grid_w16_s_p507511d0_g22, fam_mul_segmented_grid_w16_s_p507511d0_g23, fam_mul_segmented_grid_w16_s_p507511d0_g30, fam_mul_segmented_grid_w16_s_p507511d0_g31, fam_mul_segmented_grid_w16_s_p507511d0_g32, fam_mul_segmented_grid_w16_s_p507511d0_g33, fam_mul_squarer_w16_u_pef720af1, fam_mul_squarer_w16_u_pef720af1_sq, fam_mul_twin_precision_w16_8s_mag_d363602d01e8, fam_mul_twin_precision_w16_8s_mag_d363602d01e8_u, fam_prefix_arrival_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_w16, fam_prefix_arrival_1_0_w2, fam_prefix_arrival_2_1_1_0_w4, fam_prefix_arrival_3_2_2_1_1_0_w6, fam_prefix_han_carlson_w16, fam_prefix_han_carlson_w4_flag_dual_late, fam_prefix_han_carlson_w5, fam_prefix_knowles_mixed_w2, fam_prefix_kogge_stone_w16, fam_prefix_ladner_fischer_w8, fam_prefix_ladner_fischer_w9, fam_prefix_net_knowles_mixed_w17, fam_prefix_net_knowles_mixed_w5, fam_prefix_net_knowles_mixed_w7, fam_prefix_net_kogge_stone_w18, fam_prefix_sklansky_w16_flagm, fam_shift_barrel_mux_tree, fam_shift_keep_mask, fam_shift_masked_merged, fam_shift_stage (chialu.targets.rtl.families: the modules of the declared families the lane modules instantiate; their text follows the generated modules)
  logic [2:0] rnd_sel;
  logic [2:0] rnd;
  logic daz;
  logic ftz;
  logic dual;
  logic [15:0] y_m0_gate_rows_0;
  logic [19:0] fl_m0_gate_rows_0;
  logic [15:0] y_m0_m0_l0_adder;
  logic [19:0] fl_m0_m0_l0_adder;
  logic [15:0] y_m0_m0_l0_multiplier;
  logic [19:0] fl_m0_m0_l0_multiplier;
  logic [15:0] y_m0_m0_l0_comparator;
  logic [19:0] fl_m0_m0_l0_comparator;
  logic [15:0] y_m0_m0_l0_shifter;
  logic [19:0] fl_m0_m0_l0_shifter;
  logic [15:0] y_m0_m0_l0_bitcount;
  logic [19:0] fl_m0_m0_l0_bitcount;
  logic [15:0] y_m0;
  logic [19:0] fl_m0;
  logic [15:0] y_m1_gate_rows_0;
  logic [19:0] fl_m1_gate_rows_0;
  logic [15:0] y_m1_m1_l0_adder;
  logic [19:0] fl_m1_m1_l0_adder;
  logic [15:0] y_m1_m1_l0_multiplier;
  logic [19:0] fl_m1_m1_l0_multiplier;
  logic [15:0] y_m1_m1_l0_comparator;
  logic [19:0] fl_m1_m1_l0_comparator;
  logic [15:0] y_m1_m1_l0_shifter;
  logic [19:0] fl_m1_m1_l0_shifter;
  logic [15:0] y_m1_m1_l0_bitcount;
  logic [19:0] fl_m1_m1_l0_bitcount;
  logic [15:0] y_m1;
  logic [19:0] fl_m1;
  logic [15:0] y_m2_multipliers_0;
  logic [19:0] fl_m2_multipliers_0;
  logic [15:0] y_m2_gate_rows_0;
  logic [19:0] fl_m2_gate_rows_0;
  logic [15:0] y_m2_m2_l0_adder;
  logic [19:0] fl_m2_m2_l0_adder;
  logic [15:0] y_m2_m2_l1_adder;
  logic [19:0] fl_m2_m2_l1_adder;
  logic [15:0] y_m2_m2_l0_comparator;
  logic [19:0] fl_m2_m2_l0_comparator;
  logic [15:0] y_m2_m2_l1_comparator;
  logic [19:0] fl_m2_m2_l1_comparator;
  logic [15:0] y_m2_m2_l0_shifter;
  logic [19:0] fl_m2_m2_l0_shifter;
  logic [15:0] y_m2_m2_l1_shifter;
  logic [19:0] fl_m2_m2_l1_shifter;
  logic [15:0] y_m2_m2_l0_bitcount;
  logic [19:0] fl_m2_m2_l0_bitcount;
  logic [15:0] y_m2_m2_l1_bitcount;
  logic [19:0] fl_m2_m2_l1_bitcount;
  logic [15:0] y_m2;
  logic [19:0] fl_m2;
  logic [19:0] fl_all;
  assign rnd_sel = 3'd0;
  assign rnd = rnd_sel;
  assign daz = 1'b0;
  assign ftz = 1'b0;
  assign dual = 1'b0;
  assign y_m0 = y_m0_gate_rows_0 | y_m0_m0_l0_adder | y_m0_m0_l0_multiplier | y_m0_m0_l0_comparator | y_m0_m0_l0_shifter | y_m0_m0_l0_bitcount;
  assign fl_m0 = fl_m0_gate_rows_0 | fl_m0_m0_l0_adder | fl_m0_m0_l0_multiplier | fl_m0_m0_l0_comparator | fl_m0_m0_l0_shifter | fl_m0_m0_l0_bitcount;
  assign y_m1 = y_m1_gate_rows_0 | y_m1_m1_l0_adder | y_m1_m1_l0_multiplier | y_m1_m1_l0_comparator | y_m1_m1_l0_shifter | y_m1_m1_l0_bitcount;
  assign fl_m1 = fl_m1_gate_rows_0 | fl_m1_m1_l0_adder | fl_m1_m1_l0_multiplier | fl_m1_m1_l0_comparator | fl_m1_m1_l0_shifter | fl_m1_m1_l0_bitcount;
  assign y_m2 = y_m2_multipliers_0 | y_m2_gate_rows_0 | y_m2_m2_l0_adder | y_m2_m2_l1_adder | y_m2_m2_l0_comparator | y_m2_m2_l1_comparator | y_m2_m2_l0_shifter | y_m2_m2_l1_shifter | y_m2_m2_l0_bitcount | y_m2_m2_l1_bitcount;
  assign fl_m2 = fl_m2_multipliers_0 | fl_m2_gate_rows_0 | fl_m2_m2_l0_adder | fl_m2_m2_l1_adder | fl_m2_m2_l0_comparator | fl_m2_m2_l1_comparator | fl_m2_m2_l0_shifter | fl_m2_m2_l1_shifter | fl_m2_m2_l0_bitcount | fl_m2_m2_l1_bitcount;
  alu_core_u_multipliers_0 u_multipliers_0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_multipliers_0), .fl_m2(fl_m2_multipliers_0));
  alu_core_u_gate_rows_0 u_gate_rows_0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_gate_rows_0), .fl_m0(fl_m0_gate_rows_0), .y_m1(y_m1_gate_rows_0), .fl_m1(fl_m1_gate_rows_0), .y_m2(y_m2_gate_rows_0), .fl_m2(fl_m2_gate_rows_0));
  alu_core_u_m0_l0_adder u_m0_l0_adder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_adder), .fl_m0(fl_m0_m0_l0_adder));
  alu_core_u_m0_l0_multiplier u_m0_l0_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_multiplier), .fl_m0(fl_m0_m0_l0_multiplier));
  alu_core_u_m0_l0_comparator u_m0_l0_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_comparator), .fl_m0(fl_m0_m0_l0_comparator));
  alu_core_u_m0_l0_shifter u_m0_l0_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_shifter), .fl_m0(fl_m0_m0_l0_shifter));
  alu_core_u_m0_l0_bitcount u_m0_l0_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_bitcount), .fl_m0(fl_m0_m0_l0_bitcount));
  alu_core_u_m1_l0_adder u_m1_l0_adder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_adder), .fl_m1(fl_m1_m1_l0_adder));
  alu_core_u_m1_l0_multiplier u_m1_l0_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_multiplier), .fl_m1(fl_m1_m1_l0_multiplier));
  alu_core_u_m1_l0_comparator u_m1_l0_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_comparator), .fl_m1(fl_m1_m1_l0_comparator));
  alu_core_u_m1_l0_shifter u_m1_l0_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_shifter), .fl_m1(fl_m1_m1_l0_shifter));
  alu_core_u_m1_l0_bitcount u_m1_l0_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_bitcount), .fl_m1(fl_m1_m1_l0_bitcount));
  alu_core_u_m2_l0_adder u_m2_l0_adder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_adder), .fl_m2(fl_m2_m2_l0_adder));
  alu_core_u_m2_l1_adder u_m2_l1_adder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_adder), .fl_m2(fl_m2_m2_l1_adder));
  alu_core_u_m2_l0_comparator u_m2_l0_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_comparator), .fl_m2(fl_m2_m2_l0_comparator));
  alu_core_u_m2_l1_comparator u_m2_l1_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_comparator), .fl_m2(fl_m2_m2_l1_comparator));
  alu_core_u_m2_l0_shifter u_m2_l0_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_shifter), .fl_m2(fl_m2_m2_l0_shifter));
  alu_core_u_m2_l1_shifter u_m2_l1_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_shifter), .fl_m2(fl_m2_m2_l1_shifter));
  alu_core_u_m2_l0_bitcount u_m2_l0_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_bitcount), .fl_m2(fl_m2_m2_l0_bitcount));
  alu_core_u_m2_l1_bitcount u_m2_l1_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_bitcount), .fl_m2(fl_m2_m2_l1_bitcount));
  always_comb begin
    case (mode)
      2'd0: begin y = y_m0; fl_all = fl_m0; end
      2'd1: begin y = y_m1; fl_all = fl_m1; end
      2'd2: begin y = y_m2; fl_all = fl_m2; end
      default: begin y = '0; fl_all = '0; end
    endcase
  end
  assign flags[0] = fl_all[7];
  assign flags[1] = fl_all[8];
  assign flags[2] = fl_all[17];
  assign flags[3] = fl_all[18];
endmodule
// EVOLVE-BLOCK-END

module alu_core_m0_adder #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_adder: lane LANE of mode 0 (int16_twos_complement) for the adder ops add, sub, adc, neg, abs, add_sat; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_add_aLANE;
  logic [15:0] m0_add_bLANE;
  logic m0_add_cinLANE;
  logic [15:0] m0_add_sLANE;
  logic m0_add_coutLANE;
  logic signed [34:0] m0_o0ex0_LANE;
  logic signed [34:0] m0_o1ex0_LANE;
  logic signed [34:0] m0_o2ex0_LANE;
  logic signed [34:0] m0_o3ex0_LANE;
  logic signed [34:0] m0_o4ex0_LANE;
  logic signed [34:0] m0_o5ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.adder.m0: family compound_flagged_prefix realized by the library module fam_prefix_sklansky_w16_flagm
  fam_prefix_sklansky_w16_flagm u_m0_adderLANE (.a(m0_add_aLANE), .b(m0_add_bLANE), .cin(m0_add_cinLANE), .s(m0_add_sLANE), .cout(m0_add_coutLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_add_aLANE = 'x; m0_add_bLANE = 'x; m0_add_cinLANE = 'x; m0_o0ex0_LANE = 'x; m0_o1ex0_LANE = 'x; m0_o2ex0_LANE = 'x;
    m0_o3ex0_LANE = 'x; m0_o4ex0_LANE = 'x; m0_o5ex0_LANE = 'x;
    case (op)
      5'd0: begin
        m0_add_aLANE = m0_aLANE; m0_add_bLANE = m0_bLANE; m0_add_cinLANE = 1'b0;
        m0_o0ex0_LANE = $signed({(m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o0ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (m0_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd1: begin
        m0_add_aLANE = m0_aLANE; m0_add_bLANE = ~m0_bLANE; m0_add_cinLANE = 1'b1;
        m0_o1ex0_LANE = $signed({(m0_aLANE[15] ^ ~m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o1ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ ~m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ ~m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (~m0_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd2: begin
        m0_add_aLANE = m0_aLANE; m0_add_bLANE = m0_bLANE; m0_add_cinLANE = 1'b1;
        m0_o2ex0_LANE = $signed({(m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o2ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (m0_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd3: begin
        m0_add_aLANE = 16'd0; m0_add_bLANE = ~m0_aLANE; m0_add_cinLANE = 1'b1;
        m0_o3ex0_LANE = $signed({(1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o3ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (m0_aLANE != 0 ? (10'd1 << 7) : 10'd0);
      end
      5'd4: begin
        m0_add_aLANE = 16'd0; m0_add_bLANE = ~m0_aLANE; m0_add_cinLANE = 1'b1;
        m0_o4ex0_LANE = (m0_aLANE[15] ? $signed({(1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE), m0_add_sLANE}) : $signed({1'b0, m0_aLANE}));
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o4ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = ((m0_aLANE[15] & ((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15])) ? (10'd1 << 8) : 10'd0) | ((m0_aLANE[15] & ((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15])) ? (10'd1 << 2) : 10'd0);
      end
      5'd5: begin
        m0_add_aLANE = m0_aLANE; m0_add_bLANE = m0_bLANE; m0_add_cinLANE = 1'b0;
        m0_o5ex0_LANE = $signed({(m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_sat(m0_o5ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_bitcount #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_bitcount: lane LANE of mode 0 (int16_twos_complement) for the bitcount ops popcount, clz, ctz; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_clz_aLANE;
  logic [4:0] m0_clz_nLANE;
  logic signed [34:0] m0_o18ex0_LANE;
  logic signed [34:0] m0_o19ex0_LANE;
  logic signed [34:0] m0_o20ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.bitcount.m0: family lzd_cell_tree realized by the library module fam_count_lzd_nibble_cell_binary_count_vprop_w16 (clz)
  fam_count_lzd_nibble_cell_binary_count_vprop_w16 u_m0_clzLANE (.a(m0_clz_aLANE), .n(m0_clz_nLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_clz_aLANE = 'x; m0_o18ex0_LANE = 'x; m0_o19ex0_LANE = 'x; m0_o20ex0_LANE = 'x;
    case (op)
      5'd18: begin
        y_m0[((LANE*16)+0) +: 16] = m0_aLANE[0] + m0_aLANE[1] + m0_aLANE[2] + m0_aLANE[3] + m0_aLANE[4] + m0_aLANE[5] + m0_aLANE[6] + m0_aLANE[7] + m0_aLANE[8] + m0_aLANE[9] + m0_aLANE[10] + m0_aLANE[11] + m0_aLANE[12] + m0_aLANE[13] + m0_aLANE[14] + m0_aLANE[15];
      end
      5'd19: begin
        m0_clz_aLANE = m0_aLANE;
        y_m0[((LANE*16)+0) +: 16] = {{11{1'b0}}, m0_clz_nLANE};
      end
      5'd20: begin
        y_m0[((LANE*16)+0) +: 16] = m0_aLANE[0] ? 16'd0 : m0_aLANE[1] ? 16'd1 : m0_aLANE[2] ? 16'd2 : m0_aLANE[3] ? 16'd3 : m0_aLANE[4] ? 16'd4 : m0_aLANE[5] ? 16'd5 : m0_aLANE[6] ? 16'd6 : m0_aLANE[7] ? 16'd7 : m0_aLANE[8] ? 16'd8 : m0_aLANE[9] ? 16'd9 : m0_aLANE[10] ? 16'd10 : m0_aLANE[11] ? 16'd11 : m0_aLANE[12] ? 16'd12 : m0_aLANE[13] ? 16'd13 : m0_aLANE[14] ? 16'd14 : m0_aLANE[15] ? 16'd15 : 16'd16;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_comparator #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_comparator: lane LANE of mode 0 (int16_twos_complement) for the comparator ops min, max, cmp; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_cmp_aLANE;
  logic [15:0] m0_cmp_bLANE;
  logic m0_cmp_ltLANE;
  logic m0_cmp_eqLANE;
  logic signed [34:0] m0_o8ex0_LANE;
  logic signed [34:0] m0_o9ex0_LANE;
  logic signed [34:0] m0_o10ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.comparator.m0: family subtractor_comparator realized by the library module fam_cmp_subtractor_parallel_prefix_p342d4c3a5c869c66271da18b33b3b0a025b39f54fb5f2f6451ab982e08120d27_sum_or_tree_s_w16
  fam_cmp_subtractor_parallel_prefix_p342d4c3a5c869c66271da18b33b3b0a025b39f54fb5f2f6451ab982e08120d27_sum_or_tree_s_w16 u_m0_cmpLANE (.a(m0_cmp_aLANE), .b(m0_cmp_bLANE), .lt(m0_cmp_ltLANE), .eq(m0_cmp_eqLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_cmp_aLANE = 'x; m0_cmp_bLANE = 'x; m0_o8ex0_LANE = 'x; m0_o9ex0_LANE = 'x; m0_o10ex0_LANE = 'x;
    case (op)
      5'd8: begin
        m0_cmp_aLANE = m0_aLANE; m0_cmp_bLANE = m0_bLANE;
        y_m0[((LANE*16)+0) +: 16] = (m0_cmp_ltLANE | m0_cmp_eqLANE) ? m0_aLANE : m0_bLANE;
      end
      5'd9: begin
        m0_cmp_aLANE = m0_aLANE; m0_cmp_bLANE = m0_bLANE;
        y_m0[((LANE*16)+0) +: 16] = (~m0_cmp_ltLANE) ? m0_aLANE : m0_bLANE;
      end
      5'd10: begin
        m0_cmp_aLANE = m0_aLANE; m0_cmp_bLANE = m0_bLANE;
        y_m0[((LANE*16)+0) +: 16] = {{13{1'b0}}, (~m0_cmp_ltLANE & ~m0_cmp_eqLANE), m0_cmp_eqLANE, m0_cmp_ltLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_multiplier #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_multiplier: lane LANE of mode 0 (int16_twos_complement) for the multiplier ops mul, mul_high; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_mul_aLANE;
  logic [15:0] m0_mul_bLANE;
  logic [31:0] m0_mul_pLANE;
  logic signed [34:0] m0_o6ex0_LANE;
  logic signed [34:0] m0_o7ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.multiplier.m0: family segmented_grid realized by the library module fam_mul_segmented_grid_w16_s_p507511d0
  fam_mul_segmented_grid_w16_s_p507511d0 u_m0_mulLANE (.a(m0_mul_aLANE), .b(m0_mul_bLANE), .p(m0_mul_pLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_mul_aLANE = 'x; m0_mul_bLANE = 'x; m0_o6ex0_LANE = 'x; m0_o7ex0_LANE = 'x;
    case (op)
      5'd6: begin
        m0_mul_aLANE = m0_aLANE; m0_mul_bLANE = m0_bLANE;
        m0_o6ex0_LANE = $signed({{3{m0_mul_pLANE[31]}}, m0_mul_pLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o6ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (m0_o6ex0_LANE > 35'sd32767 || m0_o6ex0_LANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m0_o6ex0_LANE > 35'sd32767 || m0_o6ex0_LANE < -35'sd32768 ? (10'd1 << 2) : 10'd0);
      end
      5'd7: begin
        m0_mul_aLANE = m0_aLANE; m0_mul_bLANE = m0_bLANE;
        m0_o7ex0_LANE = $signed({{3{m0_mul_pLANE[31]}}, m0_mul_pLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o7ex0_LANE >>> 16);
        fl_m0[(0+LANE)*10 +: 10] = (m0_o7ex0_LANE > 35'sd32767 || m0_o7ex0_LANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m0_o7ex0_LANE > 35'sd32767 || m0_o7ex0_LANE < -35'sd32768 ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_shifter #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_shifter: lane LANE of mode 0 (int16_twos_complement) for the shifter ops shl, shr_arith, rol; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_sh_aLANE;
  logic [3:0] m0_sh_amtLANE;
  logic [2:0] m0_sh_opLANE;
  logic [15:0] m0_sh_yLANE;
  logic signed [34:0] m0_o11ex0_LANE;
  logic signed [34:0] m0_o12ex0_LANE;
  logic signed [34:0] m0_o13ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.shifter.m0: family barrel_mux_tree realized by the library module fam_shift_barrel_mux_tree
  fam_shift_barrel_mux_tree #(.W(16), .RADIX_LOG2(2), .ONE_HOT(0), .DIR(1), .ORDER(1), .STICKY(1)) u_m0_shifterLANE (.a(m0_sh_aLANE), .amt(m0_sh_amtLANE), .op(m0_sh_opLANE), .y(m0_sh_yLANE), .sticky());
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_sh_aLANE = 'x; m0_sh_amtLANE = 'x; m0_sh_opLANE = 'x; m0_o11ex0_LANE = 'x; m0_o12ex0_LANE = 'x; m0_o13ex0_LANE = 'x;
    case (op)
      5'd11: begin
        m0_sh_aLANE = m0_aLANE; m0_sh_amtLANE = 4'(m0_bLANE % 16'd16); m0_sh_opLANE = 3'd0;
        y_m0[((LANE*16)+0) +: 16] = m0_sh_yLANE;
      end
      5'd12: begin
        m0_sh_aLANE = m0_aLANE; m0_sh_amtLANE = 4'(m0_bLANE % 16'd16); m0_sh_opLANE = 3'd2;
        y_m0[((LANE*16)+0) +: 16] = m0_sh_yLANE;
      end
      5'd13: begin
        m0_sh_aLANE = m0_aLANE; m0_sh_amtLANE = 4'(m0_bLANE % 16'd16); m0_sh_opLANE = 3'd3;
        y_m0[((LANE*16)+0) +: 16] = m0_sh_yLANE;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_adder #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_adder: lane LANE of mode 1 (int16_unsigned) for the adder ops add, sub, adc, neg, abs, add_sat; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_add_aLANE;
  logic [15:0] m1_add_bLANE;
  logic m1_add_cinLANE;
  logic [15:0] m1_add_sLANE;
  logic m1_add_coutLANE;
  logic signed [34:0] m1_o0ex0_LANE;
  logic signed [34:0] m1_o1ex0_LANE;
  logic signed [34:0] m1_o2ex0_LANE;
  logic signed [34:0] m1_o3ex0_LANE;
  logic signed [34:0] m1_o4ex0_LANE;
  logic signed [34:0] m1_o4sx0_LANE;
  logic signed [34:0] m1_o5ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.adder.m1: family parallel_prefix realized by the library module fam_prefix_han_carlson_w16
  fam_prefix_han_carlson_w16 u_m1_adderLANE (.a(m1_add_aLANE), .b(m1_add_bLANE), .cin(m1_add_cinLANE), .s(m1_add_sLANE), .cout(m1_add_coutLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_add_aLANE = 'x; m1_add_bLANE = 'x; m1_add_cinLANE = 'x; m1_o0ex0_LANE = 'x; m1_o1ex0_LANE = 'x; m1_o2ex0_LANE = 'x;
    m1_o3ex0_LANE = 'x; m1_o4ex0_LANE = 'x; m1_o4sx0_LANE = 'x; m1_o5ex0_LANE = 'x;
    case (op)
      5'd0: begin
        m1_add_aLANE = m1_aLANE; m1_add_bLANE = m1_bLANE; m1_add_cinLANE = 1'b0;
        m1_o0ex0_LANE = $signed({1'b0, m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o0ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (m1_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd1: begin
        m1_add_aLANE = m1_aLANE; m1_add_bLANE = ~m1_bLANE; m1_add_cinLANE = 1'b1;
        m1_o1ex0_LANE = $signed({~m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o1ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (~m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ ~m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (~m1_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd2: begin
        m1_add_aLANE = m1_aLANE; m1_add_bLANE = m1_bLANE; m1_add_cinLANE = 1'b1;
        m1_o2ex0_LANE = $signed({1'b0, m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o2ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (m1_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd3: begin
        m1_add_aLANE = 16'd0; m1_add_bLANE = ~m1_aLANE; m1_add_cinLANE = 1'b1;
        m1_o3ex0_LANE = $signed({~m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o3ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (~m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((1'b0 ^ ~m1_aLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (m1_aLANE != 0 ? (10'd1 << 7) : 10'd0);
      end
      5'd4: begin
        m1_o4ex0_LANE = (m1_vaLANE < 0) ? -m1_vaLANE : m1_vaLANE;
        m1_o4sx0_LANE = (($signed({m1_aLANE[15], m1_aLANE}) < 0) ? -$signed({m1_aLANE[15], m1_aLANE}) : $signed({m1_aLANE[15], m1_aLANE}));
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o4ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_o4sx0_LANE > 35'sd32767 || m1_o4sx0_LANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m1_o4ex0_LANE > 35'sd65535 || m1_o4ex0_LANE < 0 ? (10'd1 << 2) : 10'd0);
      end
      5'd5: begin
        m1_add_aLANE = m1_aLANE; m1_add_bLANE = m1_bLANE; m1_add_cinLANE = 1'b0;
        m1_o5ex0_LANE = $signed({1'b0, m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_sat(m1_o5ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_bitcount #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_bitcount: lane LANE of mode 1 (int16_unsigned) for the bitcount ops popcount, clz, ctz; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_clz_aLANE;
  logic [4:0] m1_clz_nLANE;
  logic signed [34:0] m1_o18ex0_LANE;
  logic signed [34:0] m1_o19ex0_LANE;
  logic signed [34:0] m1_o20ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.bitcount.m1: family lzd_cell_tree realized by the library module fam_count_lzd_pair_cell_binary_count_vprop_w16 (clz)
  fam_count_lzd_pair_cell_binary_count_vprop_w16 u_m1_clzLANE (.a(m1_clz_aLANE), .n(m1_clz_nLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_clz_aLANE = 'x; m1_o18ex0_LANE = 'x; m1_o19ex0_LANE = 'x; m1_o20ex0_LANE = 'x;
    case (op)
      5'd18: begin
        y_m1[((LANE*16)+0) +: 16] = m1_aLANE[0] + m1_aLANE[1] + m1_aLANE[2] + m1_aLANE[3] + m1_aLANE[4] + m1_aLANE[5] + m1_aLANE[6] + m1_aLANE[7] + m1_aLANE[8] + m1_aLANE[9] + m1_aLANE[10] + m1_aLANE[11] + m1_aLANE[12] + m1_aLANE[13] + m1_aLANE[14] + m1_aLANE[15];
      end
      5'd19: begin
        m1_clz_aLANE = m1_aLANE;
        y_m1[((LANE*16)+0) +: 16] = {{11{1'b0}}, m1_clz_nLANE};
      end
      5'd20: begin
        y_m1[((LANE*16)+0) +: 16] = m1_aLANE[0] ? 16'd0 : m1_aLANE[1] ? 16'd1 : m1_aLANE[2] ? 16'd2 : m1_aLANE[3] ? 16'd3 : m1_aLANE[4] ? 16'd4 : m1_aLANE[5] ? 16'd5 : m1_aLANE[6] ? 16'd6 : m1_aLANE[7] ? 16'd7 : m1_aLANE[8] ? 16'd8 : m1_aLANE[9] ? 16'd9 : m1_aLANE[10] ? 16'd10 : m1_aLANE[11] ? 16'd11 : m1_aLANE[12] ? 16'd12 : m1_aLANE[13] ? 16'd13 : m1_aLANE[14] ? 16'd14 : m1_aLANE[15] ? 16'd15 : 16'd16;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_comparator #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_comparator: lane LANE of mode 1 (int16_unsigned) for the comparator ops min, max, cmp; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_cmp_aLANE;
  logic [15:0] m1_cmp_bLANE;
  logic m1_cmp_ltLANE;
  logic m1_cmp_eqLANE;
  logic signed [34:0] m1_o8ex0_LANE;
  logic signed [34:0] m1_o9ex0_LANE;
  logic signed [34:0] m1_o10ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.comparator.m1: family subtractor_comparator realized by the library module fam_cmp_subtractor_prefix_synthesis_nonuniform_arrival_p91919e29d8984fc7b1564e16baf52afcd8459b99d9f7793d8c56df316dce0a37_sum_or_tree_u_w16
  fam_cmp_subtractor_prefix_synthesis_nonuniform_arrival_p91919e29d8984fc7b1564e16baf52afcd8459b99d9f7793d8c56df316dce0a37_sum_or_tree_u_w16 u_m1_cmpLANE (.a(m1_cmp_aLANE), .b(m1_cmp_bLANE), .lt(m1_cmp_ltLANE), .eq(m1_cmp_eqLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_cmp_aLANE = 'x; m1_cmp_bLANE = 'x; m1_o8ex0_LANE = 'x; m1_o9ex0_LANE = 'x; m1_o10ex0_LANE = 'x;
    case (op)
      5'd8: begin
        m1_cmp_aLANE = m1_aLANE; m1_cmp_bLANE = m1_bLANE;
        y_m1[((LANE*16)+0) +: 16] = (m1_cmp_ltLANE | m1_cmp_eqLANE) ? m1_aLANE : m1_bLANE;
      end
      5'd9: begin
        m1_cmp_aLANE = m1_aLANE; m1_cmp_bLANE = m1_bLANE;
        y_m1[((LANE*16)+0) +: 16] = (~m1_cmp_ltLANE) ? m1_aLANE : m1_bLANE;
      end
      5'd10: begin
        m1_cmp_aLANE = m1_aLANE; m1_cmp_bLANE = m1_bLANE;
        y_m1[((LANE*16)+0) +: 16] = {{13{1'b0}}, (~m1_cmp_ltLANE & ~m1_cmp_eqLANE), m1_cmp_eqLANE, m1_cmp_ltLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_multiplier #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_multiplier: lane LANE of mode 1 (int16_unsigned) for the multiplier ops mul, mul_high; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_mul_aLANE;
  logic [15:0] m1_mul_bLANE;
  logic [31:0] m1_mul_pLANE;
  logic signed [34:0] m1_o6ex0_LANE;
  logic signed [34:0] m1_o6sx0_ANE;
  logic signed [34:0] m1_o7ex0_LANE;
  logic signed [34:0] m1_o7sx0_ANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.multiplier.m1: family squarer realized by the library module fam_mul_squarer_w16_u_pef720af1
  fam_mul_squarer_w16_u_pef720af1 u_m1_mulLANE (.a(m1_mul_aLANE), .b(m1_mul_bLANE), .p(m1_mul_pLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_mul_aLANE = 'x; m1_mul_bLANE = 'x; m1_o6ex0_LANE = 'x; m1_o6sx0_ANE = 'x; m1_o7ex0_LANE = 'x; m1_o7sx0_ANE = 'x;
    case (op)
      5'd6: begin
        m1_mul_aLANE = m1_aLANE; m1_mul_bLANE = m1_bLANE;
        m1_o6ex0_LANE = $signed({{3{1'b0}}, m1_mul_pLANE});
        m1_o6sx0_ANE = m1_o6ex0_LANE - (m1_aLANE[15] ? ($signed(m1_vbLANE) <<< 16) : 35'sd0) - (m1_bLANE[15] ? ($signed(m1_vaLANE) <<< 16) : 35'sd0) + ((m1_aLANE[15] & m1_bLANE[15]) ? 35'sd4294967296 : 35'sd0);
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o6ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_o6sx0_ANE > 35'sd32767 || m1_o6sx0_ANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m1_o6ex0_LANE > 35'sd65535 || m1_o6ex0_LANE < 0 ? (10'd1 << 2) : 10'd0);
      end
      5'd7: begin
        m1_mul_aLANE = m1_aLANE; m1_mul_bLANE = m1_bLANE;
        m1_o7ex0_LANE = $signed({{3{1'b0}}, m1_mul_pLANE});
        m1_o7sx0_ANE = m1_o7ex0_LANE - (m1_aLANE[15] ? ($signed(m1_vbLANE) <<< 16) : 35'sd0) - (m1_bLANE[15] ? ($signed(m1_vaLANE) <<< 16) : 35'sd0) + ((m1_aLANE[15] & m1_bLANE[15]) ? 35'sd4294967296 : 35'sd0);
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o7ex0_LANE >>> 16);
        fl_m1[(0+LANE)*10 +: 10] = (m1_o7sx0_ANE > 35'sd32767 || m1_o7sx0_ANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m1_o7ex0_LANE > 35'sd65535 || m1_o7ex0_LANE < 0 ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_shifter #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_shifter: lane LANE of mode 1 (int16_unsigned) for the shifter ops shl, shr_arith, rol; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_sh_aLANE;
  logic [3:0] m1_sh_amtLANE;
  logic [2:0] m1_sh_opLANE;
  logic [15:0] m1_sh_yLANE;
  logic signed [34:0] m1_o11ex0_LANE;
  logic signed [34:0] m1_o12ex0_LANE;
  logic signed [34:0] m1_o13ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.shifter.m1: family barrel_mux_tree realized by the library module fam_shift_barrel_mux_tree
  fam_shift_barrel_mux_tree #(.W(16), .RADIX_LOG2(0), .ONE_HOT(0), .DIR(0), .ORDER(0), .STICKY(0)) u_m1_shifterLANE (.a(m1_sh_aLANE), .amt(m1_sh_amtLANE), .op(m1_sh_opLANE), .y(m1_sh_yLANE), .sticky());
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_sh_aLANE = 'x; m1_sh_amtLANE = 'x; m1_sh_opLANE = 'x; m1_o11ex0_LANE = 'x; m1_o12ex0_LANE = 'x; m1_o13ex0_LANE = 'x;
    case (op)
      5'd11: begin
        m1_sh_aLANE = m1_aLANE; m1_sh_amtLANE = 4'(m1_bLANE % 16'd16); m1_sh_opLANE = 3'd0;
        y_m1[((LANE*16)+0) +: 16] = m1_sh_yLANE;
      end
      5'd12: begin
        m1_sh_aLANE = m1_aLANE; m1_sh_amtLANE = 4'(m1_bLANE % 16'd16); m1_sh_opLANE = 3'd2;
        y_m1[((LANE*16)+0) +: 16] = m1_sh_yLANE;
      end
      5'd13: begin
        m1_sh_aLANE = m1_aLANE; m1_sh_amtLANE = 4'(m1_bLANE % 16'd16); m1_sh_opLANE = 3'd3;
        y_m1[((LANE*16)+0) +: 16] = m1_sh_yLANE;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_adder #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_adder: lane LANE of mode 2 (int8_twos_complement) for the adder ops add, sub, adc, neg, abs, add_sat; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_add_aLANE;
  logic [7:0] m2_add_bLANE;
  logic m2_add_cinLANE;
  logic [7:0] m2_add_sLANE;
  logic m2_add_coutLANE;
  logic signed [18:0] m2_o0ex0_LANE;
  logic signed [18:0] m2_o1ex0_LANE;
  logic signed [18:0] m2_o2ex0_LANE;
  logic signed [18:0] m2_o3ex0_LANE;
  logic signed [18:0] m2_o4ex0_LANE;
  logic signed [18:0] m2_o5ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.adder.m2: family carry_skip realized by the library module fam_adder_carry_skip_pa39c40615e8121c47344c8e7421357ece0ee9686d31fd75f7bfde2405c0d679e_w8
  fam_adder_carry_skip_pa39c40615e8121c47344c8e7421357ece0ee9686d31fd75f7bfde2405c0d679e_w8 u_m2_adderLANE (.a(m2_add_aLANE), .b(m2_add_bLANE), .cin(m2_add_cinLANE), .s(m2_add_sLANE), .cout(m2_add_coutLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_add_aLANE = 'x; m2_add_bLANE = 'x; m2_add_cinLANE = 'x; m2_o0ex0_LANE = 'x; m2_o1ex0_LANE = 'x; m2_o2ex0_LANE = 'x;
    m2_o3ex0_LANE = 'x; m2_o4ex0_LANE = 'x; m2_o5ex0_LANE = 'x;
    case (op)
      5'd0: begin
        m2_add_aLANE = m2_aLANE; m2_add_bLANE = m2_bLANE; m2_add_cinLANE = 1'b0;
        m2_o0ex0_LANE = $signed({(m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o0ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (m2_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd1: begin
        m2_add_aLANE = m2_aLANE; m2_add_bLANE = ~m2_bLANE; m2_add_cinLANE = 1'b1;
        m2_o1ex0_LANE = $signed({(m2_aLANE[7] ^ ~m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o1ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ ~m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ ~m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (~m2_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd2: begin
        m2_add_aLANE = m2_aLANE; m2_add_bLANE = m2_bLANE; m2_add_cinLANE = 1'b1;
        m2_o2ex0_LANE = $signed({(m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o2ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (m2_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd3: begin
        m2_add_aLANE = 8'd0; m2_add_bLANE = ~m2_aLANE; m2_add_cinLANE = 1'b1;
        m2_o3ex0_LANE = $signed({(1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o3ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (m2_aLANE != 0 ? (10'd1 << 7) : 10'd0);
      end
      5'd4: begin
        m2_add_aLANE = 8'd0; m2_add_bLANE = ~m2_aLANE; m2_add_cinLANE = 1'b1;
        m2_o4ex0_LANE = (m2_aLANE[7] ? $signed({(1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE), m2_add_sLANE}) : $signed({1'b0, m2_aLANE}));
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o4ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = ((m2_aLANE[7] & ((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7])) ? (10'd1 << 8) : 10'd0) | ((m2_aLANE[7] & ((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7])) ? (10'd1 << 2) : 10'd0);
      end
      5'd5: begin
        m2_add_aLANE = m2_aLANE; m2_add_bLANE = m2_bLANE; m2_add_cinLANE = 1'b0;
        m2_o5ex0_LANE = $signed({(m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_sat(m2_o5ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_bitcount #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_bitcount: lane LANE of mode 2 (int8_twos_complement) for the bitcount ops popcount, clz, ctz; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_clz_aLANE;
  logic [3:0] m2_clz_nLANE;
  logic signed [18:0] m2_o18ex0_LANE;
  logic signed [18:0] m2_o19ex0_LANE;
  logic signed [18:0] m2_o20ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.bitcount.m2: family priority_encoder realized by the library module fam_count_priority_encoder_g16_l2_direct_binary_w8 (clz)
  fam_count_priority_encoder_g16_l2_direct_binary_w8 u_m2_clzLANE (.a(m2_clz_aLANE), .n(m2_clz_nLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_clz_aLANE = 'x; m2_o18ex0_LANE = 'x; m2_o19ex0_LANE = 'x; m2_o20ex0_LANE = 'x;
    case (op)
      5'd18: begin
        y_m2[((LANE*8)+0) +: 8] = m2_aLANE[0] + m2_aLANE[1] + m2_aLANE[2] + m2_aLANE[3] + m2_aLANE[4] + m2_aLANE[5] + m2_aLANE[6] + m2_aLANE[7];
      end
      5'd19: begin
        m2_clz_aLANE = m2_aLANE;
        y_m2[((LANE*8)+0) +: 8] = {{4{1'b0}}, m2_clz_nLANE};
      end
      5'd20: begin
        y_m2[((LANE*8)+0) +: 8] = m2_aLANE[0] ? 8'd0 : m2_aLANE[1] ? 8'd1 : m2_aLANE[2] ? 8'd2 : m2_aLANE[3] ? 8'd3 : m2_aLANE[4] ? 8'd4 : m2_aLANE[5] ? 8'd5 : m2_aLANE[6] ? 8'd6 : m2_aLANE[7] ? 8'd7 : 8'd8;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_comparator #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_comparator: lane LANE of mode 2 (int8_twos_complement) for the comparator ops min, max, cmp; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_cmp_aLANE;
  logic [7:0] m2_cmp_bLANE;
  logic m2_cmp_ltLANE;
  logic m2_cmp_eqLANE;
  logic signed [18:0] m2_o8ex0_LANE;
  logic signed [18:0] m2_o9ex0_LANE;
  logic signed [18:0] m2_o10ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.comparator.m2: family subtractor_comparator realized by the library module fam_cmp_subtractor_end_around_carry_p49961f094ec9edb5039f1a4ebe8b25f3a7b6da85cb8155779bdd360605f439ba_sum_or_tree_s_w8
  fam_cmp_subtractor_end_around_carry_p49961f094ec9edb5039f1a4ebe8b25f3a7b6da85cb8155779bdd360605f439ba_sum_or_tree_s_w8 u_m2_cmpLANE (.a(m2_cmp_aLANE), .b(m2_cmp_bLANE), .lt(m2_cmp_ltLANE), .eq(m2_cmp_eqLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_cmp_aLANE = 'x; m2_cmp_bLANE = 'x; m2_o8ex0_LANE = 'x; m2_o9ex0_LANE = 'x; m2_o10ex0_LANE = 'x;
    case (op)
      5'd8: begin
        m2_cmp_aLANE = m2_aLANE; m2_cmp_bLANE = m2_bLANE;
        y_m2[((LANE*8)+0) +: 8] = (m2_cmp_ltLANE | m2_cmp_eqLANE) ? m2_aLANE : m2_bLANE;
      end
      5'd9: begin
        m2_cmp_aLANE = m2_aLANE; m2_cmp_bLANE = m2_bLANE;
        y_m2[((LANE*8)+0) +: 8] = (~m2_cmp_ltLANE) ? m2_aLANE : m2_bLANE;
      end
      5'd10: begin
        m2_cmp_aLANE = m2_aLANE; m2_cmp_bLANE = m2_bLANE;
        y_m2[((LANE*8)+0) +: 8] = {{5{1'b0}}, (~m2_cmp_ltLANE & ~m2_cmp_eqLANE), m2_cmp_eqLANE, m2_cmp_ltLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_multiplier_sh #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2,
  input  logic [31:0] tp_p_m2
);
  // alu_core_m2_multiplier_sh: lane LANE of mode 2 (int8_twos_complement) for the multiplier ops mul, mul_high; the result buses are the mode's, with only this lane's bits written; the unit's shared multiplier serve this lane through the pc_/tp_ buses
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_mul_aLANE;
  logic [7:0] m2_mul_bLANE;
  logic [15:0] m2_mul_pLANE;
  logic signed [18:0] m2_o6ex0_LANE;
  logic signed [18:0] m2_o7ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.multiplier.m2: family twin_precision_subword realized by the unit's shared twin-precision multiplier 
  assign m2_mul_pLANE = tp_p_m2[(LANE)*16 +: 16];
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_mul_aLANE = 'x; m2_mul_bLANE = 'x; m2_o6ex0_LANE = 'x; m2_o7ex0_LANE = 'x;
    case (op)
      5'd6: begin
        m2_mul_aLANE = m2_aLANE; m2_mul_bLANE = m2_bLANE;
        m2_o6ex0_LANE = $signed({{3{m2_mul_pLANE[15]}}, m2_mul_pLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o6ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (m2_o6ex0_LANE > 19'sd127 || m2_o6ex0_LANE < -19'sd128 ? (10'd1 << 8) : 10'd0) | (m2_o6ex0_LANE > 19'sd127 || m2_o6ex0_LANE < -19'sd128 ? (10'd1 << 2) : 10'd0);
      end
      5'd7: begin
        m2_mul_aLANE = m2_aLANE; m2_mul_bLANE = m2_bLANE;
        m2_o7ex0_LANE = $signed({{3{m2_mul_pLANE[15]}}, m2_mul_pLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o7ex0_LANE >>> 8);
        fl_m2[(0+LANE)*10 +: 10] = (m2_o7ex0_LANE > 19'sd127 || m2_o7ex0_LANE < -19'sd128 ? (10'd1 << 8) : 10'd0) | (m2_o7ex0_LANE > 19'sd127 || m2_o7ex0_LANE < -19'sd128 ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_shifter #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_shifter: lane LANE of mode 2 (int8_twos_complement) for the shifter ops shl, shr_arith, rol; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_sh_aLANE;
  logic [2:0] m2_sh_amtLANE;
  logic [2:0] m2_sh_opLANE;
  logic [7:0] m2_sh_yLANE;
  logic signed [18:0] m2_o11ex0_LANE;
  logic signed [18:0] m2_o12ex0_LANE;
  logic signed [18:0] m2_o13ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.shifter.m2: family masked_merged realized by the library module fam_shift_masked_merged
  fam_shift_masked_merged #(.W(8), .MASKGEN(2), .MERGE(1), .R_RADIX_LOG2(3), .R_ONE_HOT(0), .R_ORDER(1), .STICKY(0)) u_m2_shifterLANE (.a(m2_sh_aLANE), .amt(m2_sh_amtLANE), .op(m2_sh_opLANE), .y(m2_sh_yLANE), .sticky());
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_sh_aLANE = 'x; m2_sh_amtLANE = 'x; m2_sh_opLANE = 'x; m2_o11ex0_LANE = 'x; m2_o12ex0_LANE = 'x; m2_o13ex0_LANE = 'x;
    case (op)
      5'd11: begin
        m2_sh_aLANE = m2_aLANE; m2_sh_amtLANE = 3'(m2_bLANE % 8'd8); m2_sh_opLANE = 3'd0;
        y_m2[((LANE*8)+0) +: 8] = m2_sh_yLANE;
      end
      5'd12: begin
        m2_sh_aLANE = m2_aLANE; m2_sh_amtLANE = 3'(m2_bLANE % 8'd8); m2_sh_opLANE = 3'd2;
        y_m2[((LANE*8)+0) +: 8] = m2_sh_yLANE;
      end
      5'd13: begin
        m2_sh_aLANE = m2_aLANE; m2_sh_amtLANE = 3'(m2_bLANE % 8'd8); m2_sh_opLANE = 3'd3;
        y_m2[((LANE*8)+0) +: 8] = m2_sh_yLANE;
      end
      default: ;
    endcase
  end
endmodule
// ADIR-MEMBER m0_l0_adder
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_adder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_adder: physical structure `m0.l0.adder` (kind adder, slot adder); realizes m0.l0.adder: adder, mode 0 lane 0, int16_twos_complement, ops add, sub, adc, neg, abs, add_sat
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_adder #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_multiplier: physical structure `m0.l0.multiplier` (kind multiplier, slot multiplier); realizes m0.l0.multiplier: multiplier, mode 0 lane 0, int16_twos_complement, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_multiplier #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_comparator: physical structure `m0.l0.comparator` (kind comparator, slot comparator); realizes m0.l0.comparator: comparator, mode 0 lane 0, int16_twos_complement, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_comparator #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_shifter: physical structure `m0.l0.shifter` (kind shifter, slot shifter); realizes m0.l0.shifter: shifter, mode 0 lane 0, int16_twos_complement, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_shifter #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_logic
// EVOLVE-BLOCK-START
module alu_core_u_gate_rows_0 (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_gate_rows_0: physical structure `gate_rows_0` (kind logic, slot logic); realizes m0.l0.logic: logic, mode 0 lane 0, int16_twos_complement, ops and, or, xor, not, m1.l0.logic: logic, mode 1 lane 0, int16_unsigned, ops and, or, xor, not, m2.l0.logic: logic, mode 2 lane 0, int8_twos_complement, ops and, or, xor, not, m2.l1.logic: logic, mode 2 lane 1, int8_twos_complement, ops and, or, xor, not
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [1:0] lg_op;
  logic lg_en;
  logic [15:0] lg_y;
  assign lg_op = (op == 5'd14) ? 2'd0 : (op == 5'd15) ? 2'd1 : (op == 5'd16) ? 2'd2 : (op == 5'd17) ? 2'd3 : 2'd0;
  assign lg_en = (op == 5'd14) | (op == 5'd15) | (op == 5'd16) | (op == 5'd17);
  // structure core.logic: family wide_gate_row realized by one library gate row over the whole word (the packings 1 x int16_twos_complement, 1 x int16_unsigned, 2 x int8_twos_complement)
  fam_logic_gate_row #(.W(16), .NOT_VIA_XOR(0)) u_wide_row (.a(a), .b(b), .op(lg_op), .y(lg_y));
  assign y_m0 = lg_en ? lg_y[15:0] : '0;
  assign fl_m0 = '0;
  assign y_m1 = lg_en ? lg_y[15:0] : '0;
  assign fl_m1 = '0;
  assign y_m2 = lg_en ? lg_y[15:0] : '0;
  assign fl_m2 = '0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_bitcount: physical structure `m0.l0.bitcount` (kind bitcount, slot bitcount); realizes m0.l0.bitcount: bitcount, mode 0 lane 0, int16_twos_complement, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_bitcount #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_adder
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_adder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_adder: physical structure `m1.l0.adder` (kind adder, slot adder); realizes m1.l0.adder: adder, mode 1 lane 0, int16_unsigned, ops add, sub, adc, neg, abs, add_sat
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_adder #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_multiplier: physical structure `m1.l0.multiplier` (kind multiplier, slot multiplier); realizes m1.l0.multiplier: multiplier, mode 1 lane 0, int16_unsigned, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_multiplier #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_comparator: physical structure `m1.l0.comparator` (kind comparator, slot comparator); realizes m1.l0.comparator: comparator, mode 1 lane 0, int16_unsigned, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_comparator #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_shifter: physical structure `m1.l0.shifter` (kind shifter, slot shifter); realizes m1.l0.shifter: shifter, mode 1 lane 0, int16_unsigned, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_shifter #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_logic
// m1.l0.logic: realized by the unit module in member m0_l0_logic
// ADIR-MEMBER m1_l0_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_bitcount: physical structure `m1.l0.bitcount` (kind bitcount, slot bitcount); realizes m1.l0.bitcount: bitcount, mode 1 lane 0, int16_unsigned, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_bitcount #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_adder
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_adder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_adder: physical structure `m2.l0.adder` (kind adder, slot adder); realizes m2.l0.adder: adder, mode 2 lane 0, int8_twos_complement, ops add, sub, adc, neg, abs, add_sat
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_adder #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_adder
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_adder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_adder: physical structure `m2.l1.adder` (kind adder, slot adder); realizes m2.l1.adder: adder, mode 2 lane 1, int8_twos_complement, ops add, sub, adc, neg, abs, add_sat
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_adder #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_multipliers_0 (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_multipliers_0: physical structure `multipliers_0` (kind multiplier, slot multiplier); realizes m2.l0.multiplier: multiplier, mode 2 lane 0, int8_twos_complement, ops mul, mul_high, m2.l1.multiplier: multiplier, mode 2 lane 1, int8_twos_complement, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [31:0] tp_p_m2;
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  logic tp_sel;
  logic [31:0] tp_p;
  alu_core_m2_multiplier_sh #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0), .tp_p_m2(tp_p_m2));
  alu_core_m2_multiplier_sh #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1), .tp_p_m2(tp_p_m2));
  assign y_m2 = y_m2_l0 | y_m2_l1;
  assign fl_m2 = fl_m2_l0 | fl_m2_l1;
  assign tp_sel = (mode == 2'd2) ? 1'd0 : '0;
  // structure core.multiplier: family twin_precision_subword realized by one library matrix over the packings 2 x int8_twos_complement
  fam_mul_twin_precision_w16_8s_mag_d363602d01e8 u_twin (.a(a), .b(b), .sel(tp_sel), .p(tp_p));
  assign tp_p_m2 = tp_p;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_multiplier
// m2.l1.multiplier: realized by the unit module in member m2_l0_multiplier
// ADIR-MEMBER m2_l0_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_comparator: physical structure `m2.l0.comparator` (kind comparator, slot comparator); realizes m2.l0.comparator: comparator, mode 2 lane 0, int8_twos_complement, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_comparator #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_comparator: physical structure `m2.l1.comparator` (kind comparator, slot comparator); realizes m2.l1.comparator: comparator, mode 2 lane 1, int8_twos_complement, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_comparator #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_shifter: physical structure `m2.l0.shifter` (kind shifter, slot shifter); realizes m2.l0.shifter: shifter, mode 2 lane 0, int8_twos_complement, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_shifter #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_shifter: physical structure `m2.l1.shifter` (kind shifter, slot shifter); realizes m2.l1.shifter: shifter, mode 2 lane 1, int8_twos_complement, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_shifter #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_logic
// m2.l0.logic: realized by the unit module in member m0_l0_logic
// ADIR-MEMBER m2_l1_logic
// m2.l1.logic: realized by the unit module in member m0_l0_logic
// ADIR-MEMBER m2_l0_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_bitcount: physical structure `m2.l0.bitcount` (kind bitcount, slot bitcount); realizes m2.l0.bitcount: bitcount, mode 2 lane 0, int8_twos_complement, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_bitcount #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_bitcount: physical structure `m2.l1.bitcount` (kind bitcount, slot bitcount); realizes m2.l1.bitcount: bitcount, mode 2 lane 1, int8_twos_complement, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_bitcount #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER library
// ---- the family library modules the lane modules instantiate (chialu/targets/rtl/families; fixed text, replaced by editing the instances)


















// carry_select: blocks [4, 1] (uniform), full_duplicate, selects rippled_block_carries
module fam_adder_carry_select_w5 (input logic [4:0] a, input logic [4:0] b, input logic cin, output logic [4:0] s, output logic cout);
  logic [3:0] s0_0;
  logic [3:0] s0_1;
  logic co0_0;
  logic co0_1;
  // block 0 (4 bits), carry-in 0
  fam_adder_carry_select_w5_component_block_adder_adder_w4 u1 (.a(a[3:0]), .b(b[3:0]), .cin(1'b0), .s(s0_0), .cout(co0_0));
  // block 0, carry-in 1
  fam_adder_carry_select_w5_component_block_adder_adder_w4 u2 (.a(a[3:0]), .b(b[3:0]), .cin(1'b1), .s(s0_1), .cout(co0_1));
  logic bp0; assign bp0 = co0_1 & ~co0_0;
  logic s1_0;
  logic s1_1;
  logic co1_0;
  logic co1_1;
  // block 1 (1 bits), carry-in 0
  fam_adder_carry_select_w5_component_block_adder_adder_w1 u3 (.a(a[4:4]), .b(b[4:4]), .cin(1'b0), .s(s1_0), .cout(co1_0));
  // block 1, carry-in 1
  fam_adder_carry_select_w5_component_block_adder_adder_w1 u4 (.a(a[4:4]), .b(b[4:4]), .cin(1'b1), .s(s1_1), .cout(co1_1));
  logic bp1; assign bp1 = co1_1 & ~co1_0;
  logic c1; assign c1 = cin ? co0_1 : co0_0;
  logic c2; assign c2 = c1 ? co1_1 : co1_0;
  assign s[3:0] = cin ? s0_1 : s0_0;
  assign s[4:4] = c1 ? s1_1 : s1_0;
  assign cout = c2;
endmodule




module fam_adder_carry_select_w5_component_block_adder_adder_w1(input wire [0:0] a, input wire [0:0] b, input wire [0:0] cin, output wire [0:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(1), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_carry_select_w5_component_block_adder_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule

// carry_skip: blocks [5, 3] (uniform), 1 skip level, mux
module fam_adder_carry_skip_pa39c40615e8121c47344c8e7421357ece0ee9686d31fd75f7bfde2405c0d679e_w8 (input logic [7:0] a, input logic [7:0] b, input logic cin, output logic [7:0] s, output logic cout);
  logic P0; assign P0 = &(a[4:0] ^ b[4:0]);
  logic P1; assign P1 = &(a[7:5] ^ b[7:5]);
  logic [4:0] s0;
  logic co0;
  // block 0 (5 bits)
  fam_adder_carry_skip_pa39c40615e8121c47344c8e7421357ece0ee9686d31fd75f7bfde2405c0d679e_w8_component_block_adder_adder_w5 u1 (.a(a[4:0]), .b(b[4:0]), .cin(cin), .s(s0), .cout(co0));
  assign s[4:0] = s0;
  logic bc0;
  assign bc0 = P0 ? cin : co0;
  logic [2:0] s1;
  logic co1;
  // block 1 (3 bits)
  fam_adder_carry_skip_pa39c40615e8121c47344c8e7421357ece0ee9686d31fd75f7bfde2405c0d679e_w8_component_block_adder_adder_w3 u2 (.a(a[7:5]), .b(b[7:5]), .cin(bc0), .s(s1), .cout(co1));
  assign s[7:5] = s1;
  logic bc1;
  assign bc1 = P1 ? bc0 : co1;
  assign cout = bc1;
endmodule




module fam_adder_carry_skip_pa39c40615e8121c47344c8e7421357ece0ee9686d31fd75f7bfde2405c0d679e_w8_component_block_adder_adder_w3(input wire [2:0] a, input wire [2:0] b, input wire [0:0] cin, output wire [2:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(3), .CHUNK(1), .FORM(1)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule





module fam_adder_carry_skip_pa39c40615e8121c47344c8e7421357ece0ee9686d31fd75f7bfde2405c0d679e_w8_component_block_adder_adder_w5(input wire [4:0] a, input wire [4:0] b, input wire [0:0] cin, output wire [4:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(5), .CHUNK(1), .FORM(1)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule



// ------------------------------------------------------------- conditional_sum
// base blocks of BASE bits ripple their sum and carry for both carry-ins; a
// level merges RADIX consecutive blocks (2 or 4: the selection radix) by
// selecting each upper block's pair by the carry out of the blocks below it
// within the merged group, until one block spans the word
module fam_adder_conditional_sum #(parameter int W = 16, parameter int BASE = 1, parameter int RADIX = 2)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  localparam int R = (RADIX == 4) ? 4 : 2;
  localparam int BS = (BASE < 1) ? 1 : BASE;
  localparam int NB0 = (W + BS - 1) / BS;                 // the base blocks
  localparam int L = (NB0 <= 1) ? 0 : ((R == 4) ? ($clog2(NB0) + 1) / 2 : $clog2(NB0));
  localparam int NBP = 1;                                 // (unused: the padded count follows below)
  // the padded block count: R^L base blocks
  function automatic int powi(input int base_, input int e);
    int r_, i_;
    r_ = 1;
    for (i_ = 0; i_ < e; i_ = i_ + 1) r_ = r_ * base_;
    return r_;
  endfunction
  localparam int NBL = powi(R, L);                        // base blocks after padding
  localparam int WP = NBL * BS;                           // the padded width
  logic [WP-1:0] ap, bp;
  assign ap = {{(WP-W){1'b0}}, a};
  assign bp = {{(WP-W){1'b0}}, b};
  // per level: the sums under carry-in 0 and 1, and the carry out of the block a bit ends
  logic [WP-1:0] s0 [0:L];
  logic [WP-1:0] s1 [0:L];
  logic [WP-1:0] c0 [0:L];
  logic [WP-1:0] c1 [0:L];
  genvar l, i, m;
  generate
    // level 0: the base blocks rippled for both carry-ins
    for (i = 0; i < NBL; i = i + 1) begin : base
      localparam int LO = i * BS;
      logic [BS:0] r0, r1;
      assign r0[0] = 1'b0;
      assign r1[0] = 1'b1;
      for (m = 0; m < BS; m = m + 1) begin : bit_
        assign s0[0][LO+m] = ap[LO+m] ^ bp[LO+m] ^ r0[m];
        assign r0[m+1] = (ap[LO+m] & bp[LO+m]) | ((ap[LO+m] ^ bp[LO+m]) & r0[m]);
        assign s1[0][LO+m] = ap[LO+m] ^ bp[LO+m] ^ r1[m];
        assign r1[m+1] = (ap[LO+m] & bp[LO+m]) | ((ap[LO+m] ^ bp[LO+m]) & r1[m]);
        // the carry out of bit LO+m under the block's carry-in (the block's carry-out at its top bit)
        assign c0[0][LO+m] = r0[m+1];
        assign c1[0][LO+m] = r1[m+1];
      end
    end
    for (l = 0; l < L; l = l + 1) begin : lvl
      localparam int BW = BS * powi(R, l);                // the block width at this level
      for (i = 0; i < WP; i = i + 1) begin : bit_
        localparam int GRP = i / (BW * R);                // the merged group
        localparam int POS = (i / BW) % R;                // the block's position in the group
        localparam int GLO = GRP * BW * R;                // the group's first bit
        if (POS == 0) begin : lower
          assign s0[l+1][i] = s0[l][i];
          assign s1[l+1][i] = s1[l][i];
          assign c0[l+1][i] = c0[l][i];
          assign c1[l+1][i] = c1[l][i];
        end else begin : upper
          // the carry into this block under the group's carry-in 0 / 1: the chain of the blocks below
          logic [POS:0] k0, k1;
          assign k0[0] = 1'b0;
          assign k1[0] = 1'b1;
          genvar q;
          for (q = 0; q < POS; q = q + 1) begin : chain
            localparam int E = GLO + q * BW + BW - 1;     // the last bit of block q
            assign k0[q+1] = k0[q] ? c1[l][E] : c0[l][E];
            assign k1[q+1] = k1[q] ? c1[l][E] : c0[l][E];
          end
          assign s0[l+1][i] = k0[POS] ? s1[l][i] : s0[l][i];
          assign c0[l+1][i] = k0[POS] ? c1[l][i] : c0[l][i];
          assign s1[l+1][i] = k1[POS] ? s1[l][i] : s0[l][i];
          assign c1[l+1][i] = k1[POS] ? c1[l][i] : c0[l][i];
        end
      end
    end
  endgenerate
  assign s = cin ? s1[L][W-1:0] : s0[L][W-1:0];
  assign cout = cin ? c1[L][W-1] : c0[L][W-1];
endmodule


// end_around_carry (generic_p_correction, cyclic_prefix_level, ladner_fischer, the incrementer prefix_and_incrementer): the carry-out re-enters as the carry-in
module fam_adder_eac_cyclic_prefix_level_p49961f094ec9edb5039f1a4ebe8b25f3a7b6da85cb8155779bdd360605f439ba_w8 (input logic [7:0] a, input logic [7:0] b, input logic cin, output logic [7:0] s, output logic cout);
  logic [8:0] t;
  // the sum
  fam_prefix_ladner_fischer_w8 u1 (.a(a), .b(b), .cin(cin), .s(t[7:0]), .cout(t[8]));
  localparam [8:0] MODULUS = 9'd165;
  localparam integer REDUCTION_STAGES = 2;
  logic [8:0] difference1;
  logic nonnegative1;
  // complete generic-p reduction, shifted modulus 1
  fam_prefix_ladner_fischer_w9 u2 (.a(t), .b(9'd181), .cin(1'b1), .s(difference1), .cout(nonnegative1));
  logic [8:0] remainder1; assign remainder1 = nonnegative1 ? difference1 : t;
  logic [8:0] difference0;
  logic nonnegative0;
  // complete generic-p reduction, shifted modulus 0
  fam_prefix_ladner_fischer_w9 u3 (.a(remainder1), .b(9'd346), .cin(1'b1), .s(difference0), .cout(nonnegative0));
  logic [8:0] remainder0; assign remainder0 = nonnegative0 ? difference0 : remainder1;
  assign s = remainder0[7:0];
  assign cout = t[8];
endmodule



// -------------------------------------------------------- manchester_carry_chain
// the pass-device carry chain in its synthesizable form: per bit a kill, a
// propagate and a generate, the carry passing through the chain in segments of
// SEG bits (chain_segment_length). VARSKIP = 1 (variable_skip) bypasses a
// segment whose bits all propagate: the segment's carry-out is its carry-in.
module fam_adder_manchester_carry_chain #(parameter int W = 16, parameter int SEG = 4, parameter int VARSKIP = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  localparam int NS = (W + SEG - 1) / SEG;
  logic [W-1:0] g, p, k, pass;
  assign g = a & b;
  assign p = a ^ b;
  assign k = ~(a | b);
  assign pass = ~g & ~k;              // the carry passes when neither killed nor generated
  logic [NS:0] sc;                    // the carry into each segment
  assign sc[0] = cin;
  genvar j, i;
  generate
    for (j = 0; j < NS; j = j + 1) begin : seg
      localparam int LO = j * SEG;
      localparam int HI = (LO + SEG > W) ? W : LO + SEG;
      logic [HI-LO:0] c;
      assign c[0] = sc[j];
      for (i = 0; i < HI - LO; i = i + 1) begin : bit_
        assign c[i+1] = (pass[LO+i] & c[i]) | g[LO+i];
        assign s[LO+i] = p[LO+i] ^ c[i];
      end
      if (VARSKIP) begin : skip
        wire allpass = &pass[HI-1:LO];
        assign sc[j+1] = allpass ? sc[j] : c[HI-LO];
      end else begin : chain
        assign sc[j+1] = c[HI-LO];
      end
    end
  endgenerate
  assign cout = sc[NS];
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).
module fam_adder_ripple_carry #(parameter int W = 16, parameter int CHUNK = 1, parameter int FORM = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  localparam int BLOCKS = (W + CHUNK - 1) / CHUNK;
  logic [BLOCKS:0] block_carry;
  assign block_carry[0] = cin;
  for (genvar block_index = 0; block_index < BLOCKS; block_index = block_index + 1) begin : chunk
    localparam int LO = block_index * CHUNK;
    localparam int BW = LO + CHUNK > W ? W - LO : CHUNK;
    (* keep_hierarchy = "yes" *) fam_adder_ripple_chunk #(.W(BW), .FORM(FORM)) u_chunk(
      .a(a[LO +: BW]), .b(b[LO +: BW]), .cin(block_carry[block_index]),
      .s(s[LO +: BW]), .cout(block_carry[block_index+1]));
  end
  assign cout = block_carry[BLOCKS];
endmodule







module fam_adder_ripple_chunk #(parameter int W = 1, parameter int FORM = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  logic [W:0] c;
  assign c[0] = cin;
  genvar i;
  generate
    for (i = 0; i < W; i = i + 1) begin : fa
      if (FORM == 1) begin : two_ha
        wire s1 = a[i] ^ b[i];
        wire c1 = a[i] & b[i];
        wire c2 = s1 & c[i];
        assign s[i] = s1 ^ c[i];
        assign c[i+1] = c1 | c2;
      end else if (FORM == 2) begin : maj
        assign s[i] = a[i] ^ b[i] ^ c[i];
        assign c[i+1] = (a[i] & b[i]) | (a[i] & c[i]) | (b[i] & c[i]);
      end else if (FORM == 3) begin : muxc
        wire p = a[i] ^ b[i];
        assign s[i] = p ^ c[i];
        assign c[i+1] = p ? c[i] : a[i];
      end else begin : gp
        wire g = a[i] & b[i];
        wire p = a[i] ^ b[i];
        assign s[i] = p ^ c[i];
        assign c[i+1] = g | (p & c[i]);
      end
    end
  endgenerate
  assign cout = c[W];
endmodule















// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum
module fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 (input logic [9:0] a, input logic [9:0] b, input logic cin, output logic [9:0] s, output logic cout);
  logic [9:0] g; assign g = a & b;
  logic [9:0] p; assign p = a ^ b;
  logic BG0; assign BG0 = (g[1] | (p[1] & g[0]));
  logic BP0; assign BP0 = (p[1] & p[0]);
  logic BG1; assign BG1 = (g[3] | (p[3] & g[2]));
  logic BP1; assign BP1 = (p[3] & p[2]);
  logic BG2; assign BG2 = (g[5] | (p[5] & g[4]));
  logic BP2; assign BP2 = (p[5] & p[4]);
  logic BG3; assign BG3 = (g[7] | (p[7] & g[6]));
  logic BP3; assign BP3 = (p[7] & p[6]);
  logic BG4; assign BG4 = (g[9] | (p[9] & g[8]));
  logic BP4; assign BP4 = (p[9] & p[8]);
  logic [4:0] net_g; assign net_g = {BG4, BG3, BG2, BG1, BG0};
  logic [4:0] net_p; assign net_p = {BP4, BP3, BP2, BP1, BP0};
  logic [4:0] net_c;
  logic net_co;
  // the prefix network over the blocks (knowles_mixed)
  fam_prefix_net_knowles_mixed_w5 u1 (.g(net_g), .p(net_p), .cin(cin), .c(net_c), .cout(net_co));
  logic [1:0] s0;
  logic x0;
  // block 0: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u2 (.a(a[1:0]), .b(b[1:0]), .cin(net_c[0]), .s(s0), .cout(x0));
  assign s[1:0] = s0;
  logic [1:0] s1;
  logic x1;
  // block 1: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u3 (.a(a[3:2]), .b(b[3:2]), .cin(net_c[1]), .s(s1), .cout(x1));
  assign s[3:2] = s1;
  logic [1:0] s2;
  logic x2;
  // block 2: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u4 (.a(a[5:4]), .b(b[5:4]), .cin(net_c[2]), .s(s2), .cout(x2));
  assign s[5:4] = s2;
  logic [1:0] s3;
  logic x3;
  // block 3: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u5 (.a(a[7:6]), .b(b[7:6]), .cin(net_c[3]), .s(s3), .cout(x3));
  assign s[7:6] = s3;
  logic [1:0] s4;
  logic x4;
  // block 4: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u6 (.a(a[9:8]), .b(b[9:8]), .cin(net_c[4]), .s(s4), .cout(x4));
  assign s[9:8] = s4;
  assign cout = net_co;
endmodule



























// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum
module fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 (input logic [13:0] a, input logic [13:0] b, input logic cin, output logic [13:0] s, output logic cout);
  logic [13:0] g; assign g = a & b;
  logic [13:0] p; assign p = a ^ b;
  logic BG0; assign BG0 = (g[1] | (p[1] & g[0]));
  logic BP0; assign BP0 = (p[1] & p[0]);
  logic BG1; assign BG1 = (g[3] | (p[3] & g[2]));
  logic BP1; assign BP1 = (p[3] & p[2]);
  logic BG2; assign BG2 = (g[5] | (p[5] & g[4]));
  logic BP2; assign BP2 = (p[5] & p[4]);
  logic BG3; assign BG3 = (g[7] | (p[7] & g[6]));
  logic BP3; assign BP3 = (p[7] & p[6]);
  logic BG4; assign BG4 = (g[9] | (p[9] & g[8]));
  logic BP4; assign BP4 = (p[9] & p[8]);
  logic BG5; assign BG5 = (g[11] | (p[11] & g[10]));
  logic BP5; assign BP5 = (p[11] & p[10]);
  logic BG6; assign BG6 = (g[13] | (p[13] & g[12]));
  logic BP6; assign BP6 = (p[13] & p[12]);
  logic [6:0] net_g; assign net_g = {BG6, BG5, BG4, BG3, BG2, BG1, BG0};
  logic [6:0] net_p; assign net_p = {BP6, BP5, BP4, BP3, BP2, BP1, BP0};
  logic [6:0] net_c;
  logic net_co;
  // the prefix network over the blocks (knowles_mixed)
  fam_prefix_net_knowles_mixed_w7 u1 (.g(net_g), .p(net_p), .cin(cin), .c(net_c), .cout(net_co));
  logic [1:0] s0;
  logic x0;
  // block 0: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u2 (.a(a[1:0]), .b(b[1:0]), .cin(net_c[0]), .s(s0), .cout(x0));
  assign s[1:0] = s0;
  logic [1:0] s1;
  logic x1;
  // block 1: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u3 (.a(a[3:2]), .b(b[3:2]), .cin(net_c[1]), .s(s1), .cout(x1));
  assign s[3:2] = s1;
  logic [1:0] s2;
  logic x2;
  // block 2: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u4 (.a(a[5:4]), .b(b[5:4]), .cin(net_c[2]), .s(s2), .cout(x2));
  assign s[5:4] = s2;
  logic [1:0] s3;
  logic x3;
  // block 3: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u5 (.a(a[7:6]), .b(b[7:6]), .cin(net_c[3]), .s(s3), .cout(x3));
  assign s[7:6] = s3;
  logic [1:0] s4;
  logic x4;
  // block 4: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u6 (.a(a[9:8]), .b(b[9:8]), .cin(net_c[4]), .s(s4), .cout(x4));
  assign s[9:8] = s4;
  logic [1:0] s5;
  logic x5;
  // block 5: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u7 (.a(a[11:10]), .b(b[11:10]), .cin(net_c[5]), .s(s5), .cout(x5));
  assign s[11:10] = s5;
  logic [1:0] s6;
  logic x6;
  // block 6: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u8 (.a(a[13:12]), .b(b[13:12]), .cin(net_c[6]), .s(s6), .cout(x6));
  assign s[13:12] = s6;
  assign cout = net_co;
endmodule






































// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum
module fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w34 (input logic [33:0] a, input logic [33:0] b, input logic cin, output logic [33:0] s, output logic cout);
  logic [33:0] g; assign g = a & b;
  logic [33:0] p; assign p = a ^ b;
  logic BG0; assign BG0 = (g[1] | (p[1] & g[0]));
  logic BP0; assign BP0 = (p[1] & p[0]);
  logic BG1; assign BG1 = (g[3] | (p[3] & g[2]));
  logic BP1; assign BP1 = (p[3] & p[2]);
  logic BG2; assign BG2 = (g[5] | (p[5] & g[4]));
  logic BP2; assign BP2 = (p[5] & p[4]);
  logic BG3; assign BG3 = (g[7] | (p[7] & g[6]));
  logic BP3; assign BP3 = (p[7] & p[6]);
  logic BG4; assign BG4 = (g[9] | (p[9] & g[8]));
  logic BP4; assign BP4 = (p[9] & p[8]);
  logic BG5; assign BG5 = (g[11] | (p[11] & g[10]));
  logic BP5; assign BP5 = (p[11] & p[10]);
  logic BG6; assign BG6 = (g[13] | (p[13] & g[12]));
  logic BP6; assign BP6 = (p[13] & p[12]);
  logic BG7; assign BG7 = (g[15] | (p[15] & g[14]));
  logic BP7; assign BP7 = (p[15] & p[14]);
  logic BG8; assign BG8 = (g[17] | (p[17] & g[16]));
  logic BP8; assign BP8 = (p[17] & p[16]);
  logic BG9; assign BG9 = (g[19] | (p[19] & g[18]));
  logic BP9; assign BP9 = (p[19] & p[18]);
  logic BG10; assign BG10 = (g[21] | (p[21] & g[20]));
  logic BP10; assign BP10 = (p[21] & p[20]);
  logic BG11; assign BG11 = (g[23] | (p[23] & g[22]));
  logic BP11; assign BP11 = (p[23] & p[22]);
  logic BG12; assign BG12 = (g[25] | (p[25] & g[24]));
  logic BP12; assign BP12 = (p[25] & p[24]);
  logic BG13; assign BG13 = (g[27] | (p[27] & g[26]));
  logic BP13; assign BP13 = (p[27] & p[26]);
  logic BG14; assign BG14 = (g[29] | (p[29] & g[28]));
  logic BP14; assign BP14 = (p[29] & p[28]);
  logic BG15; assign BG15 = (g[31] | (p[31] & g[30]));
  logic BP15; assign BP15 = (p[31] & p[30]);
  logic BG16; assign BG16 = (g[33] | (p[33] & g[32]));
  logic BP16; assign BP16 = (p[33] & p[32]);
  logic [16:0] net_g; assign net_g = {BG16, BG15, BG14, BG13, BG12, BG11, BG10, BG9, BG8, BG7, BG6, BG5, BG4, BG3, BG2, BG1, BG0};
  logic [16:0] net_p; assign net_p = {BP16, BP15, BP14, BP13, BP12, BP11, BP10, BP9, BP8, BP7, BP6, BP5, BP4, BP3, BP2, BP1, BP0};
  logic [16:0] net_c;
  logic net_co;
  // the prefix network over the blocks (knowles_mixed)
  fam_prefix_net_knowles_mixed_w17 u1 (.g(net_g), .p(net_p), .cin(cin), .c(net_c), .cout(net_co));
  logic [1:0] s0;
  logic x0;
  // block 0: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u2 (.a(a[1:0]), .b(b[1:0]), .cin(net_c[0]), .s(s0), .cout(x0));
  assign s[1:0] = s0;
  logic [1:0] s1;
  logic x1;
  // block 1: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u3 (.a(a[3:2]), .b(b[3:2]), .cin(net_c[1]), .s(s1), .cout(x1));
  assign s[3:2] = s1;
  logic [1:0] s2;
  logic x2;
  // block 2: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u4 (.a(a[5:4]), .b(b[5:4]), .cin(net_c[2]), .s(s2), .cout(x2));
  assign s[5:4] = s2;
  logic [1:0] s3;
  logic x3;
  // block 3: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u5 (.a(a[7:6]), .b(b[7:6]), .cin(net_c[3]), .s(s3), .cout(x3));
  assign s[7:6] = s3;
  logic [1:0] s4;
  logic x4;
  // block 4: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u6 (.a(a[9:8]), .b(b[9:8]), .cin(net_c[4]), .s(s4), .cout(x4));
  assign s[9:8] = s4;
  logic [1:0] s5;
  logic x5;
  // block 5: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u7 (.a(a[11:10]), .b(b[11:10]), .cin(net_c[5]), .s(s5), .cout(x5));
  assign s[11:10] = s5;
  logic [1:0] s6;
  logic x6;
  // block 6: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u8 (.a(a[13:12]), .b(b[13:12]), .cin(net_c[6]), .s(s6), .cout(x6));
  assign s[13:12] = s6;
  logic [1:0] s7;
  logic x7;
  // block 7: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u9 (.a(a[15:14]), .b(b[15:14]), .cin(net_c[7]), .s(s7), .cout(x7));
  assign s[15:14] = s7;
  logic [1:0] s8;
  logic x8;
  // block 8: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u10 (.a(a[17:16]), .b(b[17:16]), .cin(net_c[8]), .s(s8), .cout(x8));
  assign s[17:16] = s8;
  logic [1:0] s9;
  logic x9;
  // block 9: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u11 (.a(a[19:18]), .b(b[19:18]), .cin(net_c[9]), .s(s9), .cout(x9));
  assign s[19:18] = s9;
  logic [1:0] s10;
  logic x10;
  // block 10: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u12 (.a(a[21:20]), .b(b[21:20]), .cin(net_c[10]), .s(s10), .cout(x10));
  assign s[21:20] = s10;
  logic [1:0] s11;
  logic x11;
  // block 11: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u13 (.a(a[23:22]), .b(b[23:22]), .cin(net_c[11]), .s(s11), .cout(x11));
  assign s[23:22] = s11;
  logic [1:0] s12;
  logic x12;
  // block 12: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u14 (.a(a[25:24]), .b(b[25:24]), .cin(net_c[12]), .s(s12), .cout(x12));
  assign s[25:24] = s12;
  logic [1:0] s13;
  logic x13;
  // block 13: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u15 (.a(a[27:26]), .b(b[27:26]), .cin(net_c[13]), .s(s13), .cout(x13));
  assign s[27:26] = s13;
  logic [1:0] s14;
  logic x14;
  // block 14: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u16 (.a(a[29:28]), .b(b[29:28]), .cin(net_c[14]), .s(s14), .cout(x14));
  assign s[29:28] = s14;
  logic [1:0] s15;
  logic x15;
  // block 15: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u17 (.a(a[31:30]), .b(b[31:30]), .cin(net_c[15]), .s(s15), .cout(x15));
  assign s[31:30] = s15;
  logic [1:0] s16;
  logic x16;
  // block 16: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(2), .BASE(1), .RADIX(2)) u18 (.a(a[33:32]), .b(b[33:32]), .cin(net_c[16]), .s(s16), .cout(x16));
  assign s[33:32] = s16;
  assign cout = net_co;
endmodule





































































































































// sparse_prefix_hybrid: a kogge_stone prefix network over blocks of 2 bits, the sums by ripple_precompute
module fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36 (input logic [35:0] a, input logic [35:0] b, input logic cin, output logic [35:0] s, output logic cout);
  logic [35:0] g; assign g = a & b;
  logic [35:0] p; assign p = a ^ b;
  logic BG0; assign BG0 = (g[1] | (p[1] & g[0]));
  logic BP0; assign BP0 = (p[1] & p[0]);
  logic BG1; assign BG1 = (g[3] | (p[3] & g[2]));
  logic BP1; assign BP1 = (p[3] & p[2]);
  logic BG2; assign BG2 = (g[5] | (p[5] & g[4]));
  logic BP2; assign BP2 = (p[5] & p[4]);
  logic BG3; assign BG3 = (g[7] | (p[7] & g[6]));
  logic BP3; assign BP3 = (p[7] & p[6]);
  logic BG4; assign BG4 = (g[9] | (p[9] & g[8]));
  logic BP4; assign BP4 = (p[9] & p[8]);
  logic BG5; assign BG5 = (g[11] | (p[11] & g[10]));
  logic BP5; assign BP5 = (p[11] & p[10]);
  logic BG6; assign BG6 = (g[13] | (p[13] & g[12]));
  logic BP6; assign BP6 = (p[13] & p[12]);
  logic BG7; assign BG7 = (g[15] | (p[15] & g[14]));
  logic BP7; assign BP7 = (p[15] & p[14]);
  logic BG8; assign BG8 = (g[17] | (p[17] & g[16]));
  logic BP8; assign BP8 = (p[17] & p[16]);
  logic BG9; assign BG9 = (g[19] | (p[19] & g[18]));
  logic BP9; assign BP9 = (p[19] & p[18]);
  logic BG10; assign BG10 = (g[21] | (p[21] & g[20]));
  logic BP10; assign BP10 = (p[21] & p[20]);
  logic BG11; assign BG11 = (g[23] | (p[23] & g[22]));
  logic BP11; assign BP11 = (p[23] & p[22]);
  logic BG12; assign BG12 = (g[25] | (p[25] & g[24]));
  logic BP12; assign BP12 = (p[25] & p[24]);
  logic BG13; assign BG13 = (g[27] | (p[27] & g[26]));
  logic BP13; assign BP13 = (p[27] & p[26]);
  logic BG14; assign BG14 = (g[29] | (p[29] & g[28]));
  logic BP14; assign BP14 = (p[29] & p[28]);
  logic BG15; assign BG15 = (g[31] | (p[31] & g[30]));
  logic BP15; assign BP15 = (p[31] & p[30]);
  logic BG16; assign BG16 = (g[33] | (p[33] & g[32]));
  logic BP16; assign BP16 = (p[33] & p[32]);
  logic BG17; assign BG17 = (g[35] | (p[35] & g[34]));
  logic BP17; assign BP17 = (p[35] & p[34]);
  logic [17:0] net_g; assign net_g = {BG17, BG16, BG15, BG14, BG13, BG12, BG11, BG10, BG9, BG8, BG7, BG6, BG5, BG4, BG3, BG2, BG1, BG0};
  logic [17:0] net_p; assign net_p = {BP17, BP16, BP15, BP14, BP13, BP12, BP11, BP10, BP9, BP8, BP7, BP6, BP5, BP4, BP3, BP2, BP1, BP0};
  logic [17:0] net_c;
  logic net_co;
  // the prefix network over the blocks (kogge_stone)
  fam_prefix_net_kogge_stone_w18 u1 (.g(net_g), .p(net_p), .cin(cin), .c(net_c), .cout(net_co));
  logic [1:0] s0;
  logic x0;
  // block 0: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u2 (.a(a[1:0]), .b(b[1:0]), .cin(net_c[0]), .s(s0), .cout(x0));
  assign s[1:0] = s0;
  logic [1:0] s1;
  logic x1;
  // block 1: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u3 (.a(a[3:2]), .b(b[3:2]), .cin(net_c[1]), .s(s1), .cout(x1));
  assign s[3:2] = s1;
  logic [1:0] s2;
  logic x2;
  // block 2: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u4 (.a(a[5:4]), .b(b[5:4]), .cin(net_c[2]), .s(s2), .cout(x2));
  assign s[5:4] = s2;
  logic [1:0] s3;
  logic x3;
  // block 3: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u5 (.a(a[7:6]), .b(b[7:6]), .cin(net_c[3]), .s(s3), .cout(x3));
  assign s[7:6] = s3;
  logic [1:0] s4;
  logic x4;
  // block 4: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u6 (.a(a[9:8]), .b(b[9:8]), .cin(net_c[4]), .s(s4), .cout(x4));
  assign s[9:8] = s4;
  logic [1:0] s5;
  logic x5;
  // block 5: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u7 (.a(a[11:10]), .b(b[11:10]), .cin(net_c[5]), .s(s5), .cout(x5));
  assign s[11:10] = s5;
  logic [1:0] s6;
  logic x6;
  // block 6: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u8 (.a(a[13:12]), .b(b[13:12]), .cin(net_c[6]), .s(s6), .cout(x6));
  assign s[13:12] = s6;
  logic [1:0] s7;
  logic x7;
  // block 7: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u9 (.a(a[15:14]), .b(b[15:14]), .cin(net_c[7]), .s(s7), .cout(x7));
  assign s[15:14] = s7;
  logic [1:0] s8;
  logic x8;
  // block 8: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u10 (.a(a[17:16]), .b(b[17:16]), .cin(net_c[8]), .s(s8), .cout(x8));
  assign s[17:16] = s8;
  logic [1:0] s9;
  logic x9;
  // block 9: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u11 (.a(a[19:18]), .b(b[19:18]), .cin(net_c[9]), .s(s9), .cout(x9));
  assign s[19:18] = s9;
  logic [1:0] s10;
  logic x10;
  // block 10: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u12 (.a(a[21:20]), .b(b[21:20]), .cin(net_c[10]), .s(s10), .cout(x10));
  assign s[21:20] = s10;
  logic [1:0] s11;
  logic x11;
  // block 11: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u13 (.a(a[23:22]), .b(b[23:22]), .cin(net_c[11]), .s(s11), .cout(x11));
  assign s[23:22] = s11;
  logic [1:0] s12;
  logic x12;
  // block 12: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u14 (.a(a[25:24]), .b(b[25:24]), .cin(net_c[12]), .s(s12), .cout(x12));
  assign s[25:24] = s12;
  logic [1:0] s13;
  logic x13;
  // block 13: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u15 (.a(a[27:26]), .b(b[27:26]), .cin(net_c[13]), .s(s13), .cout(x13));
  assign s[27:26] = s13;
  logic [1:0] s14;
  logic x14;
  // block 14: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u16 (.a(a[29:28]), .b(b[29:28]), .cin(net_c[14]), .s(s14), .cout(x14));
  assign s[29:28] = s14;
  logic [1:0] s15;
  logic x15;
  // block 15: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u17 (.a(a[31:30]), .b(b[31:30]), .cin(net_c[15]), .s(s15), .cout(x15));
  assign s[31:30] = s15;
  logic [1:0] s16;
  logic x16;
  // block 16: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u18 (.a(a[33:32]), .b(b[33:32]), .cin(net_c[16]), .s(s16), .cout(x16));
  assign s[33:32] = s16;
  logic [1:0] s17;
  logic x17;
  // block 17: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2 u19 (.a(a[35:34]), .b(b[35:34]), .cin(net_c[17]), .s(s17), .cout(x17));
  assign s[35:34] = s17;
  assign cout = net_co;
endmodule




module fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36_component_sum_block_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_prefix_knowles_mixed_w2 implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule


// selected EAC followed by an ordinary binary sum/carry decoder
module fam_binary_decode_fam_adder_eac_cyclic_prefix_level_p49961f094ec9edb5039f1a4ebe8b25f3a7b6da85cb8155779bdd360605f439ba_w8 (input logic [7:0] a,b, input logic cin, output logic [7:0] s, output logic cout);
  logic [7:0] rns_eac1_a; assign rns_eac1_a = a;
  logic [7:0] rns_eac1_b; assign rns_eac1_b = b;
  logic rns_eac1_cin; assign rns_eac1_cin = cin;
  logic [7:0] rns_eac1_encoded_sum;
  logic rns_eac1_encoded_carry;
  // : selected EAC followed by binary encoding decode
  fam_adder_eac_cyclic_prefix_level_p49961f094ec9edb5039f1a4ebe8b25f3a7b6da85cb8155779bdd360605f439ba_w8 u1 (.a(rns_eac1_a), .b(rns_eac1_b), .cin(rns_eac1_cin), .s(rns_eac1_encoded_sum), .cout(rns_eac1_encoded_carry));
  logic rns_eac1_qa; assign rns_eac1_qa = rns_eac1_a / 8'd165;
  logic rns_eac1_qb; assign rns_eac1_qb = rns_eac1_b / 8'd165;
  logic [7:0] rns_eac1_ra; assign rns_eac1_ra = rns_eac1_a % 8'd165;
  logic [7:0] rns_eac1_rb; assign rns_eac1_rb = rns_eac1_b % 8'd165;
  logic [8:0] rns_eac1_partial; assign rns_eac1_partial = rns_eac1_ra + rns_eac1_rb + rns_eac1_cin;
  logic rns_eac1_quotient_carry; assign rns_eac1_quotient_carry = rns_eac1_partial >= 9'd165;
  logic [1:0] rns_eac1_quotient; assign rns_eac1_quotient = rns_eac1_qa + rns_eac1_qb + rns_eac1_quotient_carry;
  logic [8:0] rns_eac1_coarse; assign rns_eac1_coarse = rns_eac1_quotient * 9'd165;
  logic [8:0] rns_eac1_decoded_sum; assign rns_eac1_decoded_sum = rns_eac1_coarse + rns_eac1_encoded_sum;
  logic rns_eac1_raw_carry; assign rns_eac1_raw_carry = rns_eac1_encoded_carry;
  assign s = rns_eac1_decoded_sum[7:0];
  assign cout = rns_eac1_raw_carry;
endmodule

// subtractor_comparator (end_around_carry, sum_or_tree, signed): a - b through the adder's carry-out, the sum path unused
module fam_cmp_subtractor_end_around_carry_p49961f094ec9edb5039f1a4ebe8b25f3a7b6da85cb8155779bdd360605f439ba_sum_or_tree_s_w8 (input logic [7:0] a, input logic [7:0] b, output logic lt, output logic eq);
  logic [7:0] ax, bx, nb, s;
  logic co;
  assign ax = {a[7] ^ 1'b1, a[6:0]};
  assign bx = {b[7] ^ 1'b1, b[6:0]};
  assign nb = ~bx;
  // the subtractor: the adder (end_around_carry) on a and ~b with a carry in; no carry out means a < b
  fam_binary_decode_fam_adder_eac_cyclic_prefix_level_p49961f094ec9edb5039f1a4ebe8b25f3a7b6da85cb8155779bdd360605f439ba_w8 u_sub (.a(ax), .b(nb), .cin(1'b1), .s(s), .cout(co));
  assign lt = ~co;
  assign eq = (s == '0);       // the difference is zero
endmodule

// subtractor_comparator (parallel_prefix, sum_or_tree, signed): a - b through the adder's carry-out, the sum path unused
module fam_cmp_subtractor_parallel_prefix_p342d4c3a5c869c66271da18b33b3b0a025b39f54fb5f2f6451ab982e08120d27_sum_or_tree_s_w16 (input logic [15:0] a, input logic [15:0] b, output logic lt, output logic eq);
  logic [15:0] ax, bx, nb, s;
  logic co;
  assign ax = {a[15] ^ 1'b1, a[14:0]};
  assign bx = {b[15] ^ 1'b1, b[14:0]};
  assign nb = ~bx;
  // the subtractor: the adder (parallel_prefix) on a and ~b with a carry in; no carry out means a < b
  fam_prefix_kogge_stone_w16 u_sub (.a(ax), .b(nb), .cin(1'b1), .s(s), .cout(co));
  assign lt = ~co;
  assign eq = (s == '0);       // the difference is zero
endmodule

// subtractor_comparator (prefix_synthesis_nonuniform_arrival, sum_or_tree, unsigned): a - b through the adder's carry-out, the sum path unused
module fam_cmp_subtractor_prefix_synthesis_nonuniform_arrival_p91919e29d8984fc7b1564e16baf52afcd8459b99d9f7793d8c56df316dce0a37_sum_or_tree_u_w16 (input logic [15:0] a, input logic [15:0] b, output logic lt, output logic eq);
  logic [15:0] ax, bx, nb, s;
  logic co;
  assign ax = {a[15] ^ 1'b0, a[14:0]};
  assign bx = {b[15] ^ 1'b0, b[14:0]};
  assign nb = ~bx;
  // the subtractor: the adder (prefix_synthesis_nonuniform_arrival) on a and ~b with a carry in; no carry out means a < b
  fam_prefix_arrival_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_w16 u_sub (.a(ax), .b(nb), .cin(1'b1), .s(s), .cout(co));
  assign lt = ~co;
  assign eq = (s == '0);       // the difference is zero
endmodule

// lzd_cell_tree (nibble_cell, binary_count, valid flags propagated): the leading zeros of a 16-bit word
module fam_count_lzd_nibble_cell_binary_count_vprop_w16 (input logic [15:0] a, output logic [4:0] n);
  logic v0_0; assign v0_0 = a[15] | a[14] | a[13] | a[12];
  logic [1:0] p0_0; assign p0_0 = a[15] ? 2'd0 : a[14] ? 2'd1 : a[13] ? 2'd2 : 2'd3;
  logic v0_1; assign v0_1 = a[11] | a[10] | a[9] | a[8];
  logic [1:0] p0_1; assign p0_1 = a[11] ? 2'd0 : a[10] ? 2'd1 : a[9] ? 2'd2 : 2'd3;
  logic v0_2; assign v0_2 = a[7] | a[6] | a[5] | a[4];
  logic [1:0] p0_2; assign p0_2 = a[7] ? 2'd0 : a[6] ? 2'd1 : a[5] ? 2'd2 : 2'd3;
  logic v0_3; assign v0_3 = a[3] | a[2] | a[1] | a[0];
  logic [1:0] p0_3; assign p0_3 = a[3] ? 2'd0 : a[2] ? 2'd1 : a[1] ? 2'd2 : 2'd3;
  logic v1_0; assign v1_0 = v0_0 | v0_1;
  logic [2:0] p1_0; assign p1_0 = v0_0 ? {1'b0, p0_0} : {1'b1, p0_1};
  logic v1_1; assign v1_1 = v0_2 | v0_3;
  logic [2:0] p1_1; assign p1_1 = v0_2 ? {1'b0, p0_2} : {1'b1, p0_3};
  logic v2_0; assign v2_0 = v1_0 | v1_1;
  logic [3:0] p2_0; assign p2_0 = v1_0 ? {1'b0, p1_0} : {1'b1, p1_1};
  assign n = v2_0 ? {1'd0, p2_0} : 5'd16;
endmodule


// lzd_cell_tree (pair_cell, binary_count, valid flags propagated): the leading zeros of a 16-bit word
module fam_count_lzd_pair_cell_binary_count_vprop_w16 (input logic [15:0] a, output logic [4:0] n);
  logic v0_0; assign v0_0 = a[15] | a[14];
  logic p0_0; assign p0_0 = ~a[15];
  logic v0_1; assign v0_1 = a[13] | a[12];
  logic p0_1; assign p0_1 = ~a[13];
  logic v0_2; assign v0_2 = a[11] | a[10];
  logic p0_2; assign p0_2 = ~a[11];
  logic v0_3; assign v0_3 = a[9] | a[8];
  logic p0_3; assign p0_3 = ~a[9];
  logic v0_4; assign v0_4 = a[7] | a[6];
  logic p0_4; assign p0_4 = ~a[7];
  logic v0_5; assign v0_5 = a[5] | a[4];
  logic p0_5; assign p0_5 = ~a[5];
  logic v0_6; assign v0_6 = a[3] | a[2];
  logic p0_6; assign p0_6 = ~a[3];
  logic v0_7; assign v0_7 = a[1] | a[0];
  logic p0_7; assign p0_7 = ~a[1];
  logic v1_0; assign v1_0 = v0_0 | v0_1;
  logic [1:0] p1_0; assign p1_0 = v0_0 ? {1'b0, p0_0} : {1'b1, p0_1};
  logic v1_1; assign v1_1 = v0_2 | v0_3;
  logic [1:0] p1_1; assign p1_1 = v0_2 ? {1'b0, p0_2} : {1'b1, p0_3};
  logic v1_2; assign v1_2 = v0_4 | v0_5;
  logic [1:0] p1_2; assign p1_2 = v0_4 ? {1'b0, p0_4} : {1'b1, p0_5};
  logic v1_3; assign v1_3 = v0_6 | v0_7;
  logic [1:0] p1_3; assign p1_3 = v0_6 ? {1'b0, p0_6} : {1'b1, p0_7};
  logic v2_0; assign v2_0 = v1_0 | v1_1;
  logic [2:0] p2_0; assign p2_0 = v1_0 ? {1'b0, p1_0} : {1'b1, p1_1};
  logic v2_1; assign v2_1 = v1_2 | v1_3;
  logic [2:0] p2_1; assign p2_1 = v1_2 ? {1'b0, p1_2} : {1'b1, p1_3};
  logic v3_0; assign v3_0 = v2_0 | v2_1;
  logic [3:0] p3_0; assign p3_0 = v2_0 ? {1'b0, p2_0} : {1'b1, p2_1};
  assign n = v3_0 ? {1'd0, p3_0} : 5'd16;
endmodule


// priority_encoder (groups of 16, 2 lookahead levels, direct_binary): the leading zeros of a 8-bit word
module fam_count_priority_encoder_g16_l2_direct_binary_w8 (input logic [7:0] a, output logic [3:0] n);
  logic any0; assign any0 = a[7] | a[6] | a[5] | a[4] | a[3] | a[2] | a[1] | a[0];
  logic any2_0; assign any2_0 = any0;
  logic kg0; assign kg0 = 1'b0;
  logic fg0; assign fg0 = any0 & ~kg0;
  logic kb0; assign kb0 = 1'b0;
  logic oh0; assign oh0 = a[7] & ~kb0 & fg0;
  logic kc0; assign kc0 = kb0 | a[7];
  logic kb1; assign kb1 = kc0;
  logic oh1; assign oh1 = a[6] & ~kb1 & fg0;
  logic kc1; assign kc1 = kb1 | a[6];
  logic kb2; assign kb2 = kc1;
  logic oh2; assign oh2 = a[5] & ~kb2 & fg0;
  logic kc2; assign kc2 = kb2 | a[5];
  logic kb3; assign kb3 = kc2;
  logic oh3; assign oh3 = a[4] & ~kb3 & fg0;
  logic kc3; assign kc3 = kb3 | a[4];
  logic kb4; assign kb4 = kc3;
  logic oh4; assign oh4 = a[3] & ~kb4 & fg0;
  logic kc4; assign kc4 = kb4 | a[3];
  logic kb5; assign kb5 = kc4;
  logic oh5; assign oh5 = a[2] & ~kb5 & fg0;
  logic kc5; assign kc5 = kb5 | a[2];
  logic kb6; assign kb6 = kc5;
  logic oh6; assign oh6 = a[1] & ~kb6 & fg0;
  logic kc6; assign kc6 = kb6 | a[1];
  logic kb7; assign kb7 = kc6;
  logic oh7; assign oh7 = a[0] & ~kb7 & fg0;
  logic kc7; assign kc7 = kb7 | a[0];
  logic v; assign v = any0;
  logic [3:0] loc0; assign loc0 = (a[7] ? 4'd0 : (a[6] ? 4'd1 : (a[5] ? 4'd2 : (a[4] ? 4'd3 : (a[3] ? 4'd4 : (a[2] ? 4'd5 : (a[1] ? 4'd6 : 4'd7)))))));
  assign n = (fg0 ? (4'd0 + loc0) : 4'd8);
endmodule




// ------------------------------------------------------------ prefix_and_incrementer
// s = a + cin: the carry into bit i is cin AND every lower bit, a prefix AND
// (STRUCTURE 0 a ripple AND chain, 1 a prefix AND tree of topology TOPO, 2
// select blocks of B bits whose block carry is the AND of the block)
module fam_incr_prefix_and #(parameter int W = 16, parameter int STRUCTURE = 1, parameter int B = 4, parameter int TOPO = 0)
  (input logic [W-1:0] a, input logic cin, output logic [W-1:0] s, output logic cout);
  // STRUCTURE: 0 ripple_and_chain, 1 prefix_and_tree (TOPO: 0 sklansky, 1 brent_kung, 2 kogge_stone),
  // 2 select_blocks of B bits
  logic [W:0] c;
  assign c[0] = cin;
  genvar i, l;
  generate
    if (STRUCTURE == 0) begin : ripple
      for (i = 0; i < W; i = i + 1) begin : ch
        assign c[i+1] = c[i] & a[i];
      end
    end else if (STRUCTURE == 1) begin : tree
      localparam int L = (W <= 1) ? 1 : $clog2(W);
      if (TOPO == 2) begin : kogge_stone
        // p[l][i]: AND of a[i] down to a[i - 2^l + 1]
        logic [W-1:0] p [0:L];
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : lvl
          for (i = 0; i < W; i = i + 1) begin : pos
            if (i >= (1 << l)) begin : comb
              assign p[l+1][i] = p[l][i] & p[l][i - (1 << l)];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[L][i];
        end
      end else if (TOPO == 1) begin : brent_kung
        // an up-sweep over the odd positions of each level, then a down-sweep filling the rest
        logic [W-1:0] p [0:2*L];
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : up
          for (i = 0; i < W; i = i + 1) begin : pos
            if (((i + 1) % (2 << l)) == 0) begin : comb
              assign p[l+1][i] = p[l][i] & p[l][i - (1 << l)];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (l = 0; l < L; l = l + 1) begin : down
          localparam int D = 1 << (L - 1 - l);
          for (i = 0; i < W; i = i + 1) begin : pos
            if (((i + 1) % (2 * D)) == D && (i + 1) > D) begin : comb
              assign p[L+l+1][i] = p[L+l][i] & p[L+l][i - D];
            end else begin : keep
              assign p[L+l+1][i] = p[L+l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[2*L][i];
        end
      end else begin : sklansky
        logic [W-1:0] p [0:L];           // p[l][i]: AND of a[i] down to a[i - 2^l + 1]
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : lvl
          for (i = 0; i < W; i = i + 1) begin : pos
            if ((i / (1 << l)) % 2 == 1) begin : comb   // the upper half of every block takes the lower half's end
              assign p[l+1][i] = p[l][i] & p[l][(i / (1 << l)) * (1 << l) - 1];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[L][i];
        end
      end
    end else begin : blocks
      localparam int NB = (W + B - 1) / B;
      logic [NB:0] bc;                  // the carry into each block
      assign bc[0] = cin;
      for (i = 0; i < NB; i = i + 1) begin : blk
        localparam int LO = i * B;
        localparam int HI = (LO + B - 1 < W - 1) ? LO + B - 1 : W - 1;
        logic all1;
        assign all1 = &a[HI:LO];
        assign bc[i+1] = bc[i] & all1;
        genvar j;
        for (j = LO; j <= HI; j = j + 1) begin : bit_
          if (j == LO) begin : first
            assign c[j+1] = bc[i] & a[j];
          end else begin : rest
            assign c[j+1] = c[j] & a[j];
          end
        end
      end
    end
  endgenerate
  assign s = a ^ c[W-1:0];
  assign cout = c[W];
endmodule


// The logic family library: the bitwise gate row of lane_replicated_gates and wide_gate_row.
//   fam_logic_gate_row #(W, NOT_VIA_XOR) (input [W-1:0] a, b, input [1:0] op, output [W-1:0] y)
//   op: 0 and, 1 or, 2 xor, 3 not (of a)
// NOT_VIA_XOR = 1 forms the not as a xor with ones, so the row is three gate types and a
// two-way operand select instead of four gate types under a four-way result mux.
module fam_logic_gate_row #(parameter int W = 16, parameter int NOT_VIA_XOR = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic [1:0] op, output logic [W-1:0] y);
  generate
    if (NOT_VIA_XOR) begin : via_xor
      logic [W-1:0] bx;
      assign bx = (op == 2'd3) ? {W{1'b1}} : b;
      assign y = (op == 2'd0) ? (a & b) : (op == 2'd1) ? (a | b) : (a ^ bx);
    end else begin : plain
      assign y = (op == 2'd0) ? (a & b) : (op == 2'd1) ? (a | b) : (op == 2'd2) ? (a ^ b) : ~a;
    end
  endgenerate
endmodule



module fam_mul_booth8_dadda_3_2_w10_s_p284dba6b (input logic [9:0] a, input logic [9:0] b, output logic [19:0] p);
  // booth_recoded_parallel: {'pp_bits': 56, 'full_adders': 0, 'half_adders': 6, 'cells': 0, 'tree_depth': 4}
  logic neg1, sel3, sel4, sel5, sel6, hg7, hg8, hg9, hg10, hg11, hg12, hg13, hg14, hg15, hg16, hg17, hg18, hg19, hp20, hp21, hp22, hp23, hp24, hp25, hp26, hp27, hp28, hp29, hp30, hp31, hp32, hc33, hc34, hc35, hc36, hc37, hc38, hc39, hc40, hc41, hc42, hc43, hc44, hc45, hs46, hs47, hs48, hs49, hs50, hs51, hs52, hs53, hs54, hs55, hs56, hs57, hs58, pp59, pp60, pp61, pp62, pp63, pp64, pp65, pp66, pp67, pp68, pp69, pp70, pp71, pp72, pp73, pp74, pp75, pp76, pp77, pp78, pp79, pp80, pp81, pp82, pp83, pp84, pp85, pp86, pp87, pp88, pp89, pp90, pp91, pp92, pp93, pp94, pp95, pp96, pp97, neg99, sel101, sel102, sel103, sel104, pp105, pp106, pp107, pp108, pp109, pp110, pp111, pp112, pp113, pp114, pp115, pp116, pp117, pp118, pp119, pp120, pp121, pp122, pp123, pp124, pp125, pp126, pp127, pp128, pp129, pp130, pp131, pp132, pp133, pp134, pp135, pp136, pp137, pp138, pp139, pp140, pp141, pp142, pp143, neg145, sel147, sel148, sel149, sel150, pp151, pp152, pp153, pp154, pp155, pp156, pp157, pp158, pp159, pp160, pp161, pp162, pp163, pp164, pp165, pp166, pp167, pp168, pp169, pp170, pp171, pp172, pp173, pp174, pp175, pp176, pp177, pp178, pp179, pp180, pp181, pp182, pp183, pp184, pp185, pp186, pp187, pp188, pp189, neg191, sel193, sel194, sel195, sel196, pp197, pp198, pp199, pp200, pp201, pp202, pp203, pp204, pp205, pp206, pp207, pp208, pp209, pp210, pp211, pp212, pp213, pp214, pp215, pp216, pp217, pp218, pp219, pp220, pp221, pp222, pp223, pp224, pp225, pp226, pp227, pp228, pp229, pp230, pp231, pp232, pp233, pp234, pp235, ns236, ns237, ns238, t239, t240, t241, t242, t243, t244, t245, t246, t247, t248, t249, t250;
  logic [12:0] a_ext;
  logic [2:0] lo0;
  logic [2:0] mg2;
  logic [12:0] m2;
  logic [12:0] m3;
  logic [12:0] m4;
  logic [12:0] nm1_i;
  logic [12:0] nm2_i;
  logic [12:0] nm3_i;
  logic [12:0] nm4_i;
  logic [2:0] lo98;
  logic [2:0] mg100;
  logic [2:0] lo144;
  logic [2:0] mg146;
  logic [2:0] lo190;
  logic [2:0] mg192;
  logic [12:0] nm1; logic nm1_co;
  // -1a = ~(1a) + 1 through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(13), .STRUCTURE(0), .B(4), .TOPO(0)) u_i1 (.a(nm1_i), .cin(1'b1), .s(nm1), .cout(nm1_co));
  logic [12:0] nm2; logic nm2_co;
  // -2a = ~(2a) + 1 through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(13), .STRUCTURE(0), .B(4), .TOPO(0)) u_i2 (.a(nm2_i), .cin(1'b1), .s(nm2), .cout(nm2_co));
  logic [12:0] nm3; logic nm3_co;
  // -3a = ~(3a) + 1 through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(13), .STRUCTURE(0), .B(4), .TOPO(0)) u_i3 (.a(nm3_i), .cin(1'b1), .s(nm3), .cout(nm3_co));
  logic [12:0] nm4; logic nm4_co;
  // -4a = ~(4a) + 1 through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(13), .STRUCTURE(0), .B(4), .TOPO(0)) u_i4 (.a(nm4_i), .cin(1'b1), .s(nm4), .cout(nm4_co));
  logic [3:0] ts1; logic tc1;
  // tile 1 (compound_flagged_prefix, 4 bits) at level 0
  fam_prefix_han_carlson_w4_flag_dual_late u_i5 (.a({pp70, pp67, pp64, pp61}), .b({pp107, 1'b0, 1'b0, 1'b0}), .cin(1'b0), .s(ts1), .cout(tc1));
  logic [3:0] ts2; logic tc2;
  // tile 2 (compound_flagged_prefix, 4 bits) at level 0
  fam_prefix_han_carlson_w4_flag_dual_late u_i6 (.a({pp82, pp79, pp76, pp73}), .b({pp119, pp116, pp113, pp110}), .cin(1'b0), .s(ts2), .cout(tc2));
  logic [3:0] ts3; logic tc3;
  // tile 3 (compound_flagged_prefix, 4 bits) at level 0
  fam_prefix_han_carlson_w4_flag_dual_late u_i7 (.a({pp94, pp91, pp88, pp85}), .b({pp131, pp128, pp125, pp122}), .cin(1'b0), .s(ts3), .cout(tc3));
  logic [3:0] ts4; logic tc4;
  // tile 4 (compound_flagged_prefix, 4 bits) at level 0
  fam_prefix_han_carlson_w4_flag_dual_late u_i8 (.a({ns236, pp97, pp97, pp97}), .b({ns237, pp140, pp137, pp134}), .cin(1'b0), .s(ts4), .cout(tc4));
  logic [3:0] ts5; logic tc5;
  // tile 5 (compound_flagged_prefix, 4 bits) at level 0
  fam_prefix_han_carlson_w4_flag_dual_late u_i9 (.a({1'b1, ns238, 1'b1, 1'b1}), .b({pp229, pp226, pp186, pp183}), .cin(1'b0), .s(ts5), .cout(tc5));
  logic [3:0] ts6; logic tc6;
  // tile 6 (compound_flagged_prefix, 4 bits) at level 0
  fam_prefix_han_carlson_w4_flag_dual_late u_i10 (.a({pp168, pp165, pp162, pp159}), .b({pp205, pp202, pp199, 1'b0}), .cin(1'b0), .s(ts6), .cout(tc6));
  logic [3:0] ts7; logic tc7;
  // tile 7 (compound_flagged_prefix, 4 bits) at level 0
  fam_prefix_han_carlson_w4_flag_dual_late u_i11 (.a({pp180, pp177, pp174, pp171}), .b({pp217, pp214, pp211, pp208}), .cin(1'b0), .s(ts7), .cout(tc7));
  logic [3:0] ts8; logic tc8;
  // tile 8 (compound_flagged_prefix, 4 bits) at level 1
  fam_prefix_han_carlson_w4_flag_dual_late u_i12 (.a({ts2[3], ts2[2], ts2[1], ts2[0]}), .b({pp156, pp153, 1'b0, 1'b0}), .cin(1'b0), .s(ts8), .cout(tc8));
  logic [3:0] ts9; logic tc9;
  // tile 9 (compound_flagged_prefix, 4 bits) at level 1
  fam_prefix_han_carlson_w4_flag_dual_late u_i13 (.a({ts3[3], ts3[2], ts3[1], ts3[0]}), .b({ts6[3], ts6[2], ts6[1], ts6[0]}), .cin(1'b0), .s(ts9), .cout(tc9));
  logic [3:0] ts10; logic tc10;
  // tile 10 (compound_flagged_prefix, 4 bits) at level 1
  fam_prefix_han_carlson_w4_flag_dual_late u_i14 (.a({ts4[3], ts4[2], ts4[1], ts4[0]}), .b({ts7[3], ts7[2], ts7[1], ts7[0]}), .cin(1'b0), .s(ts10), .cout(tc10));
  logic [3:0] ts11; logic tc11;
  // tile 11 (compound_flagged_prefix, 4 bits) at level 1
  fam_prefix_han_carlson_w4_flag_dual_late u_i15 (.a({ts5[3], ts5[2], ts5[1], ts5[0]}), .b({1'b0, 1'b0, pp223, pp220}), .cin(1'b0), .s(ts11), .cout(tc11));
  logic [3:0] ts12; logic tc12;
  // tile 12 (compound_flagged_prefix, 4 bits) at level 1
  fam_prefix_han_carlson_w4_flag_dual_late u_i16 (.a({1'b0, 1'b0, 1'b0, tc3}), .b({1'b0, 1'b0, 1'b0, tc6}), .cin(1'b0), .s(ts12), .cout(tc12));
  logic [3:0] ts13; logic tc13;
  // tile 13 (compound_flagged_prefix, 4 bits) at level 1
  fam_prefix_han_carlson_w4_flag_dual_late u_i17 (.a({1'b0, 1'b0, 1'b0, tc4}), .b({1'b0, 1'b0, 1'b0, tc7}), .cin(1'b0), .s(ts13), .cout(tc13));
  logic [3:0] ts14; logic tc14;
  // tile 14 (compound_flagged_prefix, 4 bits) at level 2
  fam_prefix_han_carlson_w4_flag_dual_late u_i18 (.a({ts8[3], ts8[2], ts8[1], ts8[0]}), .b({1'b0, 1'b0, 1'b0, tc1}), .cin(1'b0), .s(ts14), .cout(tc14));
  logic [3:0] ts15; logic tc15;
  // tile 15 (compound_flagged_prefix, 4 bits) at level 2
  fam_prefix_han_carlson_w4_flag_dual_late u_i19 (.a({ts9[3], ts9[2], ts9[1], ts9[0]}), .b({1'b0, 1'b0, 1'b0, tc2}), .cin(1'b0), .s(ts15), .cout(tc15));
  logic [3:0] ts16; logic tc16;
  // tile 16 (compound_flagged_prefix, 4 bits) at level 2
  fam_prefix_han_carlson_w4_flag_dual_late u_i20 (.a({ts10[3], ts10[2], ts10[1], ts10[0]}), .b({ts12[3], ts12[2], ts12[1], ts12[0]}), .cin(1'b0), .s(ts16), .cout(tc16));
  logic [3:0] ts17; logic tc17;
  // tile 17 (compound_flagged_prefix, 4 bits) at level 2
  fam_prefix_han_carlson_w4_flag_dual_late u_i21 (.a({ts11[3], ts11[2], ts11[1], ts11[0]}), .b({ts13[3], ts13[2], ts13[1], ts13[0]}), .cin(1'b0), .s(ts17), .cout(tc17));
  logic [3:0] ts18; logic tc18;
  // tile 18 (compound_flagged_prefix, 4 bits) at level 2
  fam_prefix_han_carlson_w4_flag_dual_late u_i22 (.a({1'b0, 1'b0, 1'b0, tc10}), .b({1'b0, 1'b0, 1'b0, tc12}), .cin(1'b0), .s(ts18), .cout(tc18));
  assign a_ext = {{3{a[9]}}, a};
  assign lo0 = {1'b0, {b[1], b[0]}} + {{2{1'b0}}, 1'b0};
  assign neg1 = b[2] & ~(1'b0 & b[0] & b[1]);
  assign mg2 = b[2] ? (3'd4 - lo0) : lo0;
  assign sel3 = (mg2 == 3'd1);
  assign sel4 = (mg2 == 3'd2);
  assign sel5 = (mg2 == 3'd3);
  assign sel6 = (mg2 == 3'd4);
  assign m2 = {a_ext[11:0], 1'd0};
  assign hg7 = m2[0] & a_ext[0];
  assign hg8 = m2[1] & a_ext[1];
  assign hg9 = m2[2] & a_ext[2];
  assign hg10 = m2[3] & a_ext[3];
  assign hg11 = m2[4] & a_ext[4];
  assign hg12 = m2[5] & a_ext[5];
  assign hg13 = m2[6] & a_ext[6];
  assign hg14 = m2[7] & a_ext[7];
  assign hg15 = m2[8] & a_ext[8];
  assign hg16 = m2[9] & a_ext[9];
  assign hg17 = m2[10] & a_ext[10];
  assign hg18 = m2[11] & a_ext[11];
  assign hg19 = m2[12] & a_ext[12];
  assign hp20 = m2[0] ^ a_ext[0];
  assign hp21 = m2[1] ^ a_ext[1];
  assign hp22 = m2[2] ^ a_ext[2];
  assign hp23 = m2[3] ^ a_ext[3];
  assign hp24 = m2[4] ^ a_ext[4];
  assign hp25 = m2[5] ^ a_ext[5];
  assign hp26 = m2[6] ^ a_ext[6];
  assign hp27 = m2[7] ^ a_ext[7];
  assign hp28 = m2[8] ^ a_ext[8];
  assign hp29 = m2[9] ^ a_ext[9];
  assign hp30 = m2[10] ^ a_ext[10];
  assign hp31 = m2[11] ^ a_ext[11];
  assign hp32 = m2[12] ^ a_ext[12];
  assign hc33 = hg7 | (hp20 & 1'b0);
  assign hc34 = hg8 | (hg7 & hp21) | (hp20 & hp21 & 1'b0);
  assign hc35 = hg9 | (hg8 & hp22) | (hg7 & hp21 & hp22) | (hp20 & hp21 & hp22 & 1'b0);
  assign hc36 = hg10 | (hg9 & hp23) | (hg8 & hp22 & hp23) | (hg7 & hp21 & hp22 & hp23) | (hp20 & hp21 & hp22 & hp23 & 1'b0);
  assign hc37 = hg11 | (hp24 & hc36);
  assign hc38 = hg12 | (hg11 & hp25) | (hp24 & hp25 & hc36);
  assign hc39 = hg13 | (hg12 & hp26) | (hg11 & hp25 & hp26) | (hp24 & hp25 & hp26 & hc36);
  assign hc40 = hg14 | (hg13 & hp27) | (hg12 & hp26 & hp27) | (hg11 & hp25 & hp26 & hp27) | (hp24 & hp25 & hp26 & hp27 & hc36);
  assign hc41 = hg15 | (hp28 & hc40);
  assign hc42 = hg16 | (hg15 & hp29) | (hp28 & hp29 & hc40);
  assign hc43 = hg17 | (hg16 & hp30) | (hg15 & hp29 & hp30) | (hp28 & hp29 & hp30 & hc40);
  assign hc44 = hg18 | (hg17 & hp31) | (hg16 & hp30 & hp31) | (hg15 & hp29 & hp30 & hp31) | (hp28 & hp29 & hp30 & hp31 & hc40);
  assign hc45 = hg19 | (hp32 & hc44);
  assign hs46 = hp20 ^ 1'b0;
  assign hs47 = hp21 ^ hc33;
  assign hs48 = hp22 ^ hc34;
  assign hs49 = hp23 ^ hc35;
  assign hs50 = hp24 ^ hc36;
  assign hs51 = hp25 ^ hc37;
  assign hs52 = hp26 ^ hc38;
  assign hs53 = hp27 ^ hc39;
  assign hs54 = hp28 ^ hc40;
  assign hs55 = hp29 ^ hc41;
  assign hs56 = hp30 ^ hc42;
  assign hs57 = hp31 ^ hc43;
  assign hs58 = hp32 ^ hc44;
  assign m3 = {hs58, hs57, hs56, hs55, hs54, hs53, hs52, hs51, hs50, hs49, hs48, hs47, hs46};
  assign m4 = {a_ext[10:0], 2'd0};
  assign pp59 = (sel3 & a_ext[0]) | (sel4 & m2[0]) | (sel5 & m3[0]) | (sel6 & m4[0]);
  assign nm1_i = ~a_ext;
  assign nm2_i = ~m2;
  assign nm3_i = ~m3;
  assign nm4_i = ~m4;
  assign pp60 = (sel3 & nm1[0]) | (sel4 & nm2[0]) | (sel5 & nm3[0]) | (sel6 & nm4[0]);
  assign pp61 = neg1 ? pp60 : pp59;
  assign pp62 = (sel3 & a_ext[1]) | (sel4 & m2[1]) | (sel5 & m3[1]) | (sel6 & m4[1]);
  assign pp63 = (sel3 & nm1[1]) | (sel4 & nm2[1]) | (sel5 & nm3[1]) | (sel6 & nm4[1]);
  assign pp64 = neg1 ? pp63 : pp62;
  assign pp65 = (sel3 & a_ext[2]) | (sel4 & m2[2]) | (sel5 & m3[2]) | (sel6 & m4[2]);
  assign pp66 = (sel3 & nm1[2]) | (sel4 & nm2[2]) | (sel5 & nm3[2]) | (sel6 & nm4[2]);
  assign pp67 = neg1 ? pp66 : pp65;
  assign pp68 = (sel3 & a_ext[3]) | (sel4 & m2[3]) | (sel5 & m3[3]) | (sel6 & m4[3]);
  assign pp69 = (sel3 & nm1[3]) | (sel4 & nm2[3]) | (sel5 & nm3[3]) | (sel6 & nm4[3]);
  assign pp70 = neg1 ? pp69 : pp68;
  assign pp71 = (sel3 & a_ext[4]) | (sel4 & m2[4]) | (sel5 & m3[4]) | (sel6 & m4[4]);
  assign pp72 = (sel3 & nm1[4]) | (sel4 & nm2[4]) | (sel5 & nm3[4]) | (sel6 & nm4[4]);
  assign pp73 = neg1 ? pp72 : pp71;
  assign pp74 = (sel3 & a_ext[5]) | (sel4 & m2[5]) | (sel5 & m3[5]) | (sel6 & m4[5]);
  assign pp75 = (sel3 & nm1[5]) | (sel4 & nm2[5]) | (sel5 & nm3[5]) | (sel6 & nm4[5]);
  assign pp76 = neg1 ? pp75 : pp74;
  assign pp77 = (sel3 & a_ext[6]) | (sel4 & m2[6]) | (sel5 & m3[6]) | (sel6 & m4[6]);
  assign pp78 = (sel3 & nm1[6]) | (sel4 & nm2[6]) | (sel5 & nm3[6]) | (sel6 & nm4[6]);
  assign pp79 = neg1 ? pp78 : pp77;
  assign pp80 = (sel3 & a_ext[7]) | (sel4 & m2[7]) | (sel5 & m3[7]) | (sel6 & m4[7]);
  assign pp81 = (sel3 & nm1[7]) | (sel4 & nm2[7]) | (sel5 & nm3[7]) | (sel6 & nm4[7]);
  assign pp82 = neg1 ? pp81 : pp80;
  assign pp83 = (sel3 & a_ext[8]) | (sel4 & m2[8]) | (sel5 & m3[8]) | (sel6 & m4[8]);
  assign pp84 = (sel3 & nm1[8]) | (sel4 & nm2[8]) | (sel5 & nm3[8]) | (sel6 & nm4[8]);
  assign pp85 = neg1 ? pp84 : pp83;
  assign pp86 = (sel3 & a_ext[9]) | (sel4 & m2[9]) | (sel5 & m3[9]) | (sel6 & m4[9]);
  assign pp87 = (sel3 & nm1[9]) | (sel4 & nm2[9]) | (sel5 & nm3[9]) | (sel6 & nm4[9]);
  assign pp88 = neg1 ? pp87 : pp86;
  assign pp89 = (sel3 & a_ext[10]) | (sel4 & m2[10]) | (sel5 & m3[10]) | (sel6 & m4[10]);
  assign pp90 = (sel3 & nm1[10]) | (sel4 & nm2[10]) | (sel5 & nm3[10]) | (sel6 & nm4[10]);
  assign pp91 = neg1 ? pp90 : pp89;
  assign pp92 = (sel3 & a_ext[11]) | (sel4 & m2[11]) | (sel5 & m3[11]) | (sel6 & m4[11]);
  assign pp93 = (sel3 & nm1[11]) | (sel4 & nm2[11]) | (sel5 & nm3[11]) | (sel6 & nm4[11]);
  assign pp94 = neg1 ? pp93 : pp92;
  assign pp95 = (sel3 & a_ext[12]) | (sel4 & m2[12]) | (sel5 & m3[12]) | (sel6 & m4[12]);
  assign pp96 = (sel3 & nm1[12]) | (sel4 & nm2[12]) | (sel5 & nm3[12]) | (sel6 & nm4[12]);
  assign pp97 = neg1 ? pp96 : pp95;
  assign lo98 = {1'b0, {b[4], b[3]}} + {{2{1'b0}}, b[2]};
  assign neg99 = b[5] & ~(b[2] & b[3] & b[4]);
  assign mg100 = b[5] ? (3'd4 - lo98) : lo98;
  assign sel101 = (mg100 == 3'd1);
  assign sel102 = (mg100 == 3'd2);
  assign sel103 = (mg100 == 3'd3);
  assign sel104 = (mg100 == 3'd4);
  assign pp105 = (sel101 & a_ext[0]) | (sel102 & m2[0]) | (sel103 & m3[0]) | (sel104 & m4[0]);
  assign pp106 = (sel101 & nm1[0]) | (sel102 & nm2[0]) | (sel103 & nm3[0]) | (sel104 & nm4[0]);
  assign pp107 = neg99 ? pp106 : pp105;
  assign pp108 = (sel101 & a_ext[1]) | (sel102 & m2[1]) | (sel103 & m3[1]) | (sel104 & m4[1]);
  assign pp109 = (sel101 & nm1[1]) | (sel102 & nm2[1]) | (sel103 & nm3[1]) | (sel104 & nm4[1]);
  assign pp110 = neg99 ? pp109 : pp108;
  assign pp111 = (sel101 & a_ext[2]) | (sel102 & m2[2]) | (sel103 & m3[2]) | (sel104 & m4[2]);
  assign pp112 = (sel101 & nm1[2]) | (sel102 & nm2[2]) | (sel103 & nm3[2]) | (sel104 & nm4[2]);
  assign pp113 = neg99 ? pp112 : pp111;
  assign pp114 = (sel101 & a_ext[3]) | (sel102 & m2[3]) | (sel103 & m3[3]) | (sel104 & m4[3]);
  assign pp115 = (sel101 & nm1[3]) | (sel102 & nm2[3]) | (sel103 & nm3[3]) | (sel104 & nm4[3]);
  assign pp116 = neg99 ? pp115 : pp114;
  assign pp117 = (sel101 & a_ext[4]) | (sel102 & m2[4]) | (sel103 & m3[4]) | (sel104 & m4[4]);
  assign pp118 = (sel101 & nm1[4]) | (sel102 & nm2[4]) | (sel103 & nm3[4]) | (sel104 & nm4[4]);
  assign pp119 = neg99 ? pp118 : pp117;
  assign pp120 = (sel101 & a_ext[5]) | (sel102 & m2[5]) | (sel103 & m3[5]) | (sel104 & m4[5]);
  assign pp121 = (sel101 & nm1[5]) | (sel102 & nm2[5]) | (sel103 & nm3[5]) | (sel104 & nm4[5]);
  assign pp122 = neg99 ? pp121 : pp120;
  assign pp123 = (sel101 & a_ext[6]) | (sel102 & m2[6]) | (sel103 & m3[6]) | (sel104 & m4[6]);
  assign pp124 = (sel101 & nm1[6]) | (sel102 & nm2[6]) | (sel103 & nm3[6]) | (sel104 & nm4[6]);
  assign pp125 = neg99 ? pp124 : pp123;
  assign pp126 = (sel101 & a_ext[7]) | (sel102 & m2[7]) | (sel103 & m3[7]) | (sel104 & m4[7]);
  assign pp127 = (sel101 & nm1[7]) | (sel102 & nm2[7]) | (sel103 & nm3[7]) | (sel104 & nm4[7]);
  assign pp128 = neg99 ? pp127 : pp126;
  assign pp129 = (sel101 & a_ext[8]) | (sel102 & m2[8]) | (sel103 & m3[8]) | (sel104 & m4[8]);
  assign pp130 = (sel101 & nm1[8]) | (sel102 & nm2[8]) | (sel103 & nm3[8]) | (sel104 & nm4[8]);
  assign pp131 = neg99 ? pp130 : pp129;
  assign pp132 = (sel101 & a_ext[9]) | (sel102 & m2[9]) | (sel103 & m3[9]) | (sel104 & m4[9]);
  assign pp133 = (sel101 & nm1[9]) | (sel102 & nm2[9]) | (sel103 & nm3[9]) | (sel104 & nm4[9]);
  assign pp134 = neg99 ? pp133 : pp132;
  assign pp135 = (sel101 & a_ext[10]) | (sel102 & m2[10]) | (sel103 & m3[10]) | (sel104 & m4[10]);
  assign pp136 = (sel101 & nm1[10]) | (sel102 & nm2[10]) | (sel103 & nm3[10]) | (sel104 & nm4[10]);
  assign pp137 = neg99 ? pp136 : pp135;
  assign pp138 = (sel101 & a_ext[11]) | (sel102 & m2[11]) | (sel103 & m3[11]) | (sel104 & m4[11]);
  assign pp139 = (sel101 & nm1[11]) | (sel102 & nm2[11]) | (sel103 & nm3[11]) | (sel104 & nm4[11]);
  assign pp140 = neg99 ? pp139 : pp138;
  assign pp141 = (sel101 & a_ext[12]) | (sel102 & m2[12]) | (sel103 & m3[12]) | (sel104 & m4[12]);
  assign pp142 = (sel101 & nm1[12]) | (sel102 & nm2[12]) | (sel103 & nm3[12]) | (sel104 & nm4[12]);
  assign pp143 = neg99 ? pp142 : pp141;
  assign lo144 = {1'b0, {b[7], b[6]}} + {{2{1'b0}}, b[5]};
  assign neg145 = b[8] & ~(b[5] & b[6] & b[7]);
  assign mg146 = b[8] ? (3'd4 - lo144) : lo144;
  assign sel147 = (mg146 == 3'd1);
  assign sel148 = (mg146 == 3'd2);
  assign sel149 = (mg146 == 3'd3);
  assign sel150 = (mg146 == 3'd4);
  assign pp151 = (sel147 & a_ext[0]) | (sel148 & m2[0]) | (sel149 & m3[0]) | (sel150 & m4[0]);
  assign pp152 = (sel147 & nm1[0]) | (sel148 & nm2[0]) | (sel149 & nm3[0]) | (sel150 & nm4[0]);
  assign pp153 = neg145 ? pp152 : pp151;
  assign pp154 = (sel147 & a_ext[1]) | (sel148 & m2[1]) | (sel149 & m3[1]) | (sel150 & m4[1]);
  assign pp155 = (sel147 & nm1[1]) | (sel148 & nm2[1]) | (sel149 & nm3[1]) | (sel150 & nm4[1]);
  assign pp156 = neg145 ? pp155 : pp154;
  assign pp157 = (sel147 & a_ext[2]) | (sel148 & m2[2]) | (sel149 & m3[2]) | (sel150 & m4[2]);
  assign pp158 = (sel147 & nm1[2]) | (sel148 & nm2[2]) | (sel149 & nm3[2]) | (sel150 & nm4[2]);
  assign pp159 = neg145 ? pp158 : pp157;
  assign pp160 = (sel147 & a_ext[3]) | (sel148 & m2[3]) | (sel149 & m3[3]) | (sel150 & m4[3]);
  assign pp161 = (sel147 & nm1[3]) | (sel148 & nm2[3]) | (sel149 & nm3[3]) | (sel150 & nm4[3]);
  assign pp162 = neg145 ? pp161 : pp160;
  assign pp163 = (sel147 & a_ext[4]) | (sel148 & m2[4]) | (sel149 & m3[4]) | (sel150 & m4[4]);
  assign pp164 = (sel147 & nm1[4]) | (sel148 & nm2[4]) | (sel149 & nm3[4]) | (sel150 & nm4[4]);
  assign pp165 = neg145 ? pp164 : pp163;
  assign pp166 = (sel147 & a_ext[5]) | (sel148 & m2[5]) | (sel149 & m3[5]) | (sel150 & m4[5]);
  assign pp167 = (sel147 & nm1[5]) | (sel148 & nm2[5]) | (sel149 & nm3[5]) | (sel150 & nm4[5]);
  assign pp168 = neg145 ? pp167 : pp166;
  assign pp169 = (sel147 & a_ext[6]) | (sel148 & m2[6]) | (sel149 & m3[6]) | (sel150 & m4[6]);
  assign pp170 = (sel147 & nm1[6]) | (sel148 & nm2[6]) | (sel149 & nm3[6]) | (sel150 & nm4[6]);
  assign pp171 = neg145 ? pp170 : pp169;
  assign pp172 = (sel147 & a_ext[7]) | (sel148 & m2[7]) | (sel149 & m3[7]) | (sel150 & m4[7]);
  assign pp173 = (sel147 & nm1[7]) | (sel148 & nm2[7]) | (sel149 & nm3[7]) | (sel150 & nm4[7]);
  assign pp174 = neg145 ? pp173 : pp172;
  assign pp175 = (sel147 & a_ext[8]) | (sel148 & m2[8]) | (sel149 & m3[8]) | (sel150 & m4[8]);
  assign pp176 = (sel147 & nm1[8]) | (sel148 & nm2[8]) | (sel149 & nm3[8]) | (sel150 & nm4[8]);
  assign pp177 = neg145 ? pp176 : pp175;
  assign pp178 = (sel147 & a_ext[9]) | (sel148 & m2[9]) | (sel149 & m3[9]) | (sel150 & m4[9]);
  assign pp179 = (sel147 & nm1[9]) | (sel148 & nm2[9]) | (sel149 & nm3[9]) | (sel150 & nm4[9]);
  assign pp180 = neg145 ? pp179 : pp178;
  assign pp181 = (sel147 & a_ext[10]) | (sel148 & m2[10]) | (sel149 & m3[10]) | (sel150 & m4[10]);
  assign pp182 = (sel147 & nm1[10]) | (sel148 & nm2[10]) | (sel149 & nm3[10]) | (sel150 & nm4[10]);
  assign pp183 = neg145 ? pp182 : pp181;
  assign pp184 = (sel147 & a_ext[11]) | (sel148 & m2[11]) | (sel149 & m3[11]) | (sel150 & m4[11]);
  assign pp185 = (sel147 & nm1[11]) | (sel148 & nm2[11]) | (sel149 & nm3[11]) | (sel150 & nm4[11]);
  assign pp186 = neg145 ? pp185 : pp184;
  assign pp187 = (sel147 & a_ext[12]) | (sel148 & m2[12]) | (sel149 & m3[12]) | (sel150 & m4[12]);
  assign pp188 = (sel147 & nm1[12]) | (sel148 & nm2[12]) | (sel149 & nm3[12]) | (sel150 & nm4[12]);
  assign pp189 = neg145 ? pp188 : pp187;
  assign lo190 = {1'b0, {b[9], b[9]}} + {{2{1'b0}}, b[8]};
  assign neg191 = b[9] & ~(b[8] & b[9] & b[9]);
  assign mg192 = b[9] ? (3'd4 - lo190) : lo190;
  assign sel193 = (mg192 == 3'd1);
  assign sel194 = (mg192 == 3'd2);
  assign sel195 = (mg192 == 3'd3);
  assign sel196 = (mg192 == 3'd4);
  assign pp197 = (sel193 & a_ext[0]) | (sel194 & m2[0]) | (sel195 & m3[0]) | (sel196 & m4[0]);
  assign pp198 = (sel193 & nm1[0]) | (sel194 & nm2[0]) | (sel195 & nm3[0]) | (sel196 & nm4[0]);
  assign pp199 = neg191 ? pp198 : pp197;
  assign pp200 = (sel193 & a_ext[1]) | (sel194 & m2[1]) | (sel195 & m3[1]) | (sel196 & m4[1]);
  assign pp201 = (sel193 & nm1[1]) | (sel194 & nm2[1]) | (sel195 & nm3[1]) | (sel196 & nm4[1]);
  assign pp202 = neg191 ? pp201 : pp200;
  assign pp203 = (sel193 & a_ext[2]) | (sel194 & m2[2]) | (sel195 & m3[2]) | (sel196 & m4[2]);
  assign pp204 = (sel193 & nm1[2]) | (sel194 & nm2[2]) | (sel195 & nm3[2]) | (sel196 & nm4[2]);
  assign pp205 = neg191 ? pp204 : pp203;
  assign pp206 = (sel193 & a_ext[3]) | (sel194 & m2[3]) | (sel195 & m3[3]) | (sel196 & m4[3]);
  assign pp207 = (sel193 & nm1[3]) | (sel194 & nm2[3]) | (sel195 & nm3[3]) | (sel196 & nm4[3]);
  assign pp208 = neg191 ? pp207 : pp206;
  assign pp209 = (sel193 & a_ext[4]) | (sel194 & m2[4]) | (sel195 & m3[4]) | (sel196 & m4[4]);
  assign pp210 = (sel193 & nm1[4]) | (sel194 & nm2[4]) | (sel195 & nm3[4]) | (sel196 & nm4[4]);
  assign pp211 = neg191 ? pp210 : pp209;
  assign pp212 = (sel193 & a_ext[5]) | (sel194 & m2[5]) | (sel195 & m3[5]) | (sel196 & m4[5]);
  assign pp213 = (sel193 & nm1[5]) | (sel194 & nm2[5]) | (sel195 & nm3[5]) | (sel196 & nm4[5]);
  assign pp214 = neg191 ? pp213 : pp212;
  assign pp215 = (sel193 & a_ext[6]) | (sel194 & m2[6]) | (sel195 & m3[6]) | (sel196 & m4[6]);
  assign pp216 = (sel193 & nm1[6]) | (sel194 & nm2[6]) | (sel195 & nm3[6]) | (sel196 & nm4[6]);
  assign pp217 = neg191 ? pp216 : pp215;
  assign pp218 = (sel193 & a_ext[7]) | (sel194 & m2[7]) | (sel195 & m3[7]) | (sel196 & m4[7]);
  assign pp219 = (sel193 & nm1[7]) | (sel194 & nm2[7]) | (sel195 & nm3[7]) | (sel196 & nm4[7]);
  assign pp220 = neg191 ? pp219 : pp218;
  assign pp221 = (sel193 & a_ext[8]) | (sel194 & m2[8]) | (sel195 & m3[8]) | (sel196 & m4[8]);
  assign pp222 = (sel193 & nm1[8]) | (sel194 & nm2[8]) | (sel195 & nm3[8]) | (sel196 & nm4[8]);
  assign pp223 = neg191 ? pp222 : pp221;
  assign pp224 = (sel193 & a_ext[9]) | (sel194 & m2[9]) | (sel195 & m3[9]) | (sel196 & m4[9]);
  assign pp225 = (sel193 & nm1[9]) | (sel194 & nm2[9]) | (sel195 & nm3[9]) | (sel196 & nm4[9]);
  assign pp226 = neg191 ? pp225 : pp224;
  assign pp227 = (sel193 & a_ext[10]) | (sel194 & m2[10]) | (sel195 & m3[10]) | (sel196 & m4[10]);
  assign pp228 = (sel193 & nm1[10]) | (sel194 & nm2[10]) | (sel195 & nm3[10]) | (sel196 & nm4[10]);
  assign pp229 = neg191 ? pp228 : pp227;
  assign pp230 = (sel193 & a_ext[11]) | (sel194 & m2[11]) | (sel195 & m3[11]) | (sel196 & m4[11]);
  assign pp231 = (sel193 & nm1[11]) | (sel194 & nm2[11]) | (sel195 & nm3[11]) | (sel196 & nm4[11]);
  assign pp232 = neg191 ? pp231 : pp230;
  assign pp233 = (sel193 & a_ext[12]) | (sel194 & m2[12]) | (sel195 & m3[12]) | (sel196 & m4[12]);
  assign pp234 = (sel193 & nm1[12]) | (sel194 & nm2[12]) | (sel195 & nm3[12]) | (sel196 & nm4[12]);
  assign pp235 = neg191 ? pp234 : pp233;
  assign ns236 = ~pp97;
  assign ns237 = ~pp143;
  assign ns238 = ~pp189;
  assign t239 = ts15[0] ^ tc8;
  assign t240 = ts15[0] & tc8;
  assign t241 = ts16[0] ^ tc9;
  assign t242 = ts16[0] & tc9;
  assign t243 = ts17[0] ^ ts18[0];
  assign t244 = ts17[0] & ts18[0];
  assign t245 = ts17[1] ^ ts18[1];
  assign t246 = ts17[1] & ts18[1];
  assign t247 = ts17[2] ^ ts18[2];
  assign t248 = ts17[2] & ts18[2];
  assign t249 = ts17[3] ^ ts18[3];
  assign t250 = ts17[3] & ts18[3];
  logic [19:0] row_s, row_c;
  assign row_s = {t248, t246, t244, tc16, ts16[3], ts16[2], ts16[1], tc15, ts15[3], ts15[2], ts15[1], tc14, ts14[3], ts14[2], ts14[1], ts14[0], ts1[3], ts1[2], ts1[1], ts1[0]};
  assign row_c = {t249, t247, t245, t243, 1'b0, 1'b0, t242, t241, 1'b0, 1'b0, t240, t239, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
  // hybrid final adder: regions [0, 5, 10, 15, 20] of kinds ['ripple', 'select', 'select', 'select'] on the measured_tree_profile profile (delay_bound_boundary_enumeration)
  logic rg0_co;
  fam_adder_ripple_carry #(.W(5), .CHUNK(1), .FORM(0)) u_rg0 (.a(row_s[4:0]), .b(row_c[4:0]), .cin(1'b0), .s(p[4:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_select_w5 u_rg1 (.a(row_s[9:5]), .b(row_c[9:5]), .cin(rg0_co), .s(p[9:5]), .cout(rg1_co));
  logic rg2_co;
  fam_adder_carry_select_w5 u_rg2 (.a(row_s[14:10]), .b(row_c[14:10]), .cin(rg1_co), .s(p[14:10]), .cout(rg2_co));
  logic rg3_co;
  fam_adder_carry_select_w5 u_rg3 (.a(row_s[19:15]), .b(row_c[19:15]), .cin(rg2_co), .s(p[19:15]), .cout(rg3_co));
endmodule


module fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 (input logic [1:0] a, input logic [1:0] b, output logic [3:0] p);
  // direct_pp_parallel: {'pp_bits': 6, 'full_adders': 0, 'half_adders': 0, 'cells': 0, 'tree_depth': 0}
  logic sel0, sel1, sel2, pp3, pp4, pp5, pp6, pp7, sel8, sel9, sel10, pp11, pp12, pp13, pp14, pp15;
  logic [4:0] a_ext;
  logic [4:0] m2;
  logic [4:0] m3; logic m3_co;
  // the hard multiple 3a = 2a + a through the adder (parallel_prefix)
  fam_prefix_han_carlson_w5 u_i1 (.a(m2), .b(a_ext), .cin(1'b0), .s(m3), .cout(m3_co));
  assign a_ext = {{3{1'b0}}, a};
  assign sel0 = b[0] & ~b[1];
  assign sel1 = ~b[0] & b[1];
  assign sel2 = b[0] & b[1];
  assign m2 = {a_ext[3:0], 1'd0};
  assign pp3 = (sel0 & a_ext[0]) | (sel1 & m2[0]) | (sel2 & m3[0]);
  assign pp4 = (sel0 & a_ext[1]) | (sel1 & m2[1]) | (sel2 & m3[1]);
  assign pp5 = (sel0 & a_ext[2]) | (sel1 & m2[2]) | (sel2 & m3[2]);
  assign pp6 = (sel0 & a_ext[3]) | (sel1 & m2[3]) | (sel2 & m3[3]);
  assign pp7 = (sel0 & a_ext[4]) | (sel1 & m2[4]) | (sel2 & m3[4]);
  assign sel8 = 1'b0 & ~1'b0;
  assign sel9 = ~1'b0 & 1'b0;
  assign sel10 = 1'b0 & 1'b0;
  assign pp11 = (sel8 & a_ext[0]) | (sel9 & m2[0]) | (sel10 & m3[0]);
  assign pp12 = (sel8 & a_ext[1]) | (sel9 & m2[1]) | (sel10 & m3[1]);
  assign pp13 = (sel8 & a_ext[2]) | (sel9 & m2[2]) | (sel10 & m3[2]);
  assign pp14 = (sel8 & a_ext[3]) | (sel9 & m2[3]) | (sel10 & m3[3]);
  assign pp15 = (sel8 & a_ext[4]) | (sel9 & m2[4]) | (sel10 & m3[4]);
  logic [3:0] row_s, row_c;
  assign row_s = {pp6, pp5, pp4, pp3};
  assign row_c = {pp12, pp11, 1'b0, 1'b0};
  fam_prefix_arrival_2_1_1_0_w4 u_cpa (.a(row_s), .b(row_c), .cin(1'b0), .s(p), .cout());
endmodule










module fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 (input logic [2:0] a, input logic [2:0] b, output logic [5:0] p);
  // direct_pp_parallel: {'pp_bits': 11, 'full_adders': 0, 'half_adders': 2, 'cells': 0, 'tree_depth': 1}
  logic sel0, sel1, sel2, pp3, pp4, pp5, pp6, pp7, sel8, sel9, sel10, pp11, pp12, pp13, pp14, pp15, ns16, t17, t18, t19, t20;
  logic [4:0] a_ext;
  logic [4:0] m2;
  logic [4:0] m3; logic m3_co;
  // the hard multiple 3a = 2a + a through the adder (parallel_prefix)
  fam_prefix_han_carlson_w5 u_i1 (.a(m2), .b(a_ext), .cin(1'b0), .s(m3), .cout(m3_co));
  assign a_ext = {{2{a[2]}}, a};
  assign sel0 = b[0] & ~b[1];
  assign sel1 = ~b[0] & b[1];
  assign sel2 = b[0] & b[1];
  assign m2 = {a_ext[3:0], 1'd0};
  assign pp3 = (sel0 & a_ext[0]) | (sel1 & m2[0]) | (sel2 & m3[0]);
  assign pp4 = (sel0 & a_ext[1]) | (sel1 & m2[1]) | (sel2 & m3[1]);
  assign pp5 = (sel0 & a_ext[2]) | (sel1 & m2[2]) | (sel2 & m3[2]);
  assign pp6 = (sel0 & a_ext[3]) | (sel1 & m2[3]) | (sel2 & m3[3]);
  assign pp7 = (sel0 & a_ext[4]) | (sel1 & m2[4]) | (sel2 & m3[4]);
  assign sel8 = b[2] & ~b[2];
  assign sel9 = ~b[2] & b[2];
  assign sel10 = b[2] & b[2];
  assign pp11 = (sel8 & a_ext[0]) | (sel9 & m2[0]) | (sel10 & m3[0]);
  assign pp12 = (sel8 & a_ext[1]) | (sel9 & m2[1]) | (sel10 & m3[1]);
  assign pp13 = (sel8 & a_ext[2]) | (sel9 & m2[2]) | (sel10 & m3[2]);
  assign pp14 = (sel8 & a_ext[3]) | (sel9 & m2[3]) | (sel10 & m3[3]);
  assign pp15 = (sel8 & a_ext[4]) | (sel9 & m2[4]) | (sel10 & m3[4]);
  assign ns16 = ~pp7;
  assign t17 = ns16 ^ pp13;
  assign t18 = ns16 & pp13;
  assign t19 = pp14 ^ 1'b1;
  assign t20 = pp14 & 1'b1;
  logic [5:0] row_s, row_c;
  assign row_s = {t18, 1'b1, pp6, pp5, pp4, pp3};
  assign row_c = {t19, t17, pp12, pp11, 1'b0, 1'b0};
  fam_prefix_arrival_3_2_2_1_1_0_w6 u_cpa (.a(row_s), .b(row_c), .cin(1'b0), .s(p), .cout());
endmodule

// segmented_grid (square, depth 3): 4 x 4 segment products of 4 x 4 bits (direct_pp_parallel) merged by cpa (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p507511d0 (input logic [15:0] a, input logic [15:0] b, output logic [31:0] p);
  logic [15:0] ae; assign ae = a;
  logic [15:0] be; assign be = b;
  logic [3:0] sa00; assign sa00 = ae[3:0];
  logic [3:0] sb00; assign sb00 = be[3:0];
  logic [7:0] sp00;
  // segment product (0, 0): a segmented grid of depth 2
  fam_mul_segmented_grid_w16_s_p507511d0_g00 u_g00 (.a(sa00), .b(sb00), .p(sp00));
  logic [3:0] sa01; assign sa01 = ae[3:0];
  logic [3:0] sb01; assign sb01 = be[7:4];
  logic [7:0] sp01;
  // segment product (0, 1): a segmented grid of depth 2
  fam_mul_segmented_grid_w16_s_p507511d0_g01 u_g01 (.a(sa01), .b(sb01), .p(sp01));
  logic [3:0] sa02; assign sa02 = ae[3:0];
  logic [3:0] sb02; assign sb02 = be[11:8];
  logic [7:0] sp02;
  // segment product (0, 2): a segmented grid of depth 2
  fam_mul_segmented_grid_w16_s_p507511d0_g02 u_g02 (.a(sa02), .b(sb02), .p(sp02));
  logic [4:0] sa03; assign sa03 = {{1{1'b0}}, ae[3:0]};
  logic [4:0] sb03; assign sb03 = {{1{be[15]}}, be[15:12]};
  logic [9:0] sp03;
  // segment product (0, 3): a segmented grid of depth 2
  fam_mul_segmented_grid_w16_s_p507511d0_g03 u_g03 (.a(sa03), .b(sb03), .p(sp03));
  logic [3:0] sa10; assign sa10 = ae[7:4];
  logic [3:0] sb10; assign sb10 = be[3:0];
  logic [7:0] sp10;
  // segment product (1, 0): a segmented grid of depth 2
  fam_mul_segmented_grid_w16_s_p507511d0_g10 u_g10 (.a(sa10), .b(sb10), .p(sp10));
  logic [3:0] sa11; assign sa11 = ae[7:4];
  logic [3:0] sb11; assign sb11 = be[7:4];
  logic [7:0] sp11;
  // segment product (1, 1): a segmented grid of depth 2
  fam_mul_segmented_grid_w16_s_p507511d0_g11 u_g11 (.a(sa11), .b(sb11), .p(sp11));
  logic [3:0] sa12; assign sa12 = ae[7:4];
  logic [3:0] sb12; assign sb12 = be[11:8];
  logic [7:0] sp12;
  // segment product (1, 2): a segmented grid of depth 2
  fam_mul_segmented_grid_w16_s_p507511d0_g12 u_g12 (.a(sa12), .b(sb12), .p(sp12));
  logic [4:0] sa13; assign sa13 = {{1{1'b0}}, ae[7:4]};
  logic [4:0] sb13; assign sb13 = {{1{be[15]}}, be[15:12]};
  logic [9:0] sp13;
  // segment product (1, 3): a segmented grid of depth 2
  fam_mul_segmented_grid_w16_s_p507511d0_g13 u_g13 (.a(sa13), .b(sb13), .p(sp13));
  logic [3:0] sa20; assign sa20 = ae[11:8];
  logic [3:0] sb20; assign sb20 = be[3:0];
  logic [7:0] sp20;
  // segment product (2, 0): a segmented grid of depth 2
  fam_mul_segmented_grid_w16_s_p507511d0_g20 u_g20 (.a(sa20), .b(sb20), .p(sp20));
  logic [3:0] sa21; assign sa21 = ae[11:8];
  logic [3:0] sb21; assign sb21 = be[7:4];
  logic [7:0] sp21;
  // segment product (2, 1): a segmented grid of depth 2
  fam_mul_segmented_grid_w16_s_p507511d0_g21 u_g21 (.a(sa21), .b(sb21), .p(sp21));
  logic [3:0] sa22; assign sa22 = ae[11:8];
  logic [3:0] sb22; assign sb22 = be[11:8];
  logic [7:0] sp22;
  // segment product (2, 2): a segmented grid of depth 2
  fam_mul_segmented_grid_w16_s_p507511d0_g22 u_g22 (.a(sa22), .b(sb22), .p(sp22));
  logic [4:0] sa23; assign sa23 = {{1{1'b0}}, ae[11:8]};
  logic [4:0] sb23; assign sb23 = {{1{be[15]}}, be[15:12]};
  logic [9:0] sp23;
  // segment product (2, 3): a segmented grid of depth 2
  fam_mul_segmented_grid_w16_s_p507511d0_g23 u_g23 (.a(sa23), .b(sb23), .p(sp23));
  logic [4:0] sa30; assign sa30 = {{1{ae[15]}}, ae[15:12]};
  logic [4:0] sb30; assign sb30 = {{1{1'b0}}, be[3:0]};
  logic [9:0] sp30;
  // segment product (3, 0): a segmented grid of depth 2
  fam_mul_segmented_grid_w16_s_p507511d0_g30 u_g30 (.a(sa30), .b(sb30), .p(sp30));
  logic [4:0] sa31; assign sa31 = {{1{ae[15]}}, ae[15:12]};
  logic [4:0] sb31; assign sb31 = {{1{1'b0}}, be[7:4]};
  logic [9:0] sp31;
  // segment product (3, 1): a segmented grid of depth 2
  fam_mul_segmented_grid_w16_s_p507511d0_g31 u_g31 (.a(sa31), .b(sb31), .p(sp31));
  logic [4:0] sa32; assign sa32 = {{1{ae[15]}}, ae[15:12]};
  logic [4:0] sb32; assign sb32 = {{1{1'b0}}, be[11:8]};
  logic [9:0] sp32;
  // segment product (3, 2): a segmented grid of depth 2
  fam_mul_segmented_grid_w16_s_p507511d0_g32 u_g32 (.a(sa32), .b(sb32), .p(sp32));
  logic [4:0] sa33; assign sa33 = {{1{ae[15]}}, ae[15:12]};
  logic [4:0] sb33; assign sb33 = {{1{be[15]}}, be[15:12]};
  logic [9:0] sp33;
  // segment product (3, 3): a segmented grid of depth 2
  fam_mul_segmented_grid_w16_s_p507511d0_g33 u_g33 (.a(sa33), .b(sb33), .p(sp33));
  logic [33:0] t_sp00; assign t_sp00 = {{(34-8){1'b0}}, sp00} << 0;
  logic [33:0] t_sp01; assign t_sp01 = {{(34-8){1'b0}}, sp01} << 4;
  logic [33:0] t_sp02; assign t_sp02 = {{(34-8){1'b0}}, sp02} << 8;
  logic [33:0] t_sp03; assign t_sp03 = $signed({{(34-10){sp03[9]}}, sp03}) <<< 12;
  logic [33:0] t_sp10; assign t_sp10 = {{(34-8){1'b0}}, sp10} << 4;
  logic [33:0] t_sp11; assign t_sp11 = {{(34-8){1'b0}}, sp11} << 8;
  logic [33:0] t_sp12; assign t_sp12 = {{(34-8){1'b0}}, sp12} << 12;
  logic [33:0] t_sp13; assign t_sp13 = $signed({{(34-10){sp13[9]}}, sp13}) <<< 16;
  logic [33:0] t_sp20; assign t_sp20 = {{(34-8){1'b0}}, sp20} << 8;
  logic [33:0] t_sp21; assign t_sp21 = {{(34-8){1'b0}}, sp21} << 12;
  logic [33:0] t_sp22; assign t_sp22 = {{(34-8){1'b0}}, sp22} << 16;
  logic [33:0] t_sp23; assign t_sp23 = $signed({{(34-10){sp23[9]}}, sp23}) <<< 20;
  logic [33:0] t_sp30; assign t_sp30 = $signed({{(34-10){sp30[9]}}, sp30}) <<< 12;
  logic [33:0] t_sp31; assign t_sp31 = $signed({{(34-10){sp31[9]}}, sp31}) <<< 16;
  logic [33:0] t_sp32; assign t_sp32 = $signed({{(34-10){sp32[9]}}, sp32}) <<< 20;
  logic [33:0] t_sp33; assign t_sp33 = $signed({{(34-10){sp33[9]}}, sp33}) <<< 24;
  logic [34:0] acc1;
  // merge adder 1
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w34 u1 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(acc1[33:0]), .cout(acc1[34]));
  logic [34:0] acc2;
  // merge adder 2
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w34 u2 (.a(acc1[33:0]), .b(t_sp02), .cin(1'b0), .s(acc2[33:0]), .cout(acc2[34]));
  logic [34:0] acc3;
  // merge adder 3
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w34 u3 (.a(acc2[33:0]), .b(t_sp03), .cin(1'b0), .s(acc3[33:0]), .cout(acc3[34]));
  logic [34:0] acc4;
  // merge adder 4
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w34 u4 (.a(acc3[33:0]), .b(t_sp10), .cin(1'b0), .s(acc4[33:0]), .cout(acc4[34]));
  logic [34:0] acc5;
  // merge adder 5
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w34 u5 (.a(acc4[33:0]), .b(t_sp11), .cin(1'b0), .s(acc5[33:0]), .cout(acc5[34]));
  logic [34:0] acc6;
  // merge adder 6
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w34 u6 (.a(acc5[33:0]), .b(t_sp12), .cin(1'b0), .s(acc6[33:0]), .cout(acc6[34]));
  logic [34:0] acc7;
  // merge adder 7
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w34 u7 (.a(acc6[33:0]), .b(t_sp13), .cin(1'b0), .s(acc7[33:0]), .cout(acc7[34]));
  logic [34:0] acc8;
  // merge adder 8
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w34 u8 (.a(acc7[33:0]), .b(t_sp20), .cin(1'b0), .s(acc8[33:0]), .cout(acc8[34]));
  logic [34:0] acc9;
  // merge adder 9
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w34 u9 (.a(acc8[33:0]), .b(t_sp21), .cin(1'b0), .s(acc9[33:0]), .cout(acc9[34]));
  logic [34:0] acc10;
  // merge adder 10
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w34 u10 (.a(acc9[33:0]), .b(t_sp22), .cin(1'b0), .s(acc10[33:0]), .cout(acc10[34]));
  logic [34:0] acc11;
  // merge adder 11
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w34 u11 (.a(acc10[33:0]), .b(t_sp23), .cin(1'b0), .s(acc11[33:0]), .cout(acc11[34]));
  logic [34:0] acc12;
  // merge adder 12
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w34 u12 (.a(acc11[33:0]), .b(t_sp30), .cin(1'b0), .s(acc12[33:0]), .cout(acc12[34]));
  logic [34:0] acc13;
  // merge adder 13
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w34 u13 (.a(acc12[33:0]), .b(t_sp31), .cin(1'b0), .s(acc13[33:0]), .cout(acc13[34]));
  logic [34:0] acc14;
  // merge adder 14
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w34 u14 (.a(acc13[33:0]), .b(t_sp32), .cin(1'b0), .s(acc14[33:0]), .cout(acc14[34]));
  logic [34:0] acc15;
  // merge adder 15
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w34 u15 (.a(acc14[33:0]), .b(t_sp33), .cin(1'b0), .s(acc15[33:0]), .cout(acc15[34]));
  logic [33:0] full; assign full = acc15[33:0];
  assign p = full[31:0];
endmodule


// segmented_grid (square, depth 2): 2 x 2 segment products of 2 x 2 bits (direct_pp_parallel) merged by cpa (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p507511d0_g00 (input logic [3:0] a, input logic [3:0] b, output logic [7:0] p);
  logic [3:0] ae; assign ae = a;
  logic [3:0] be; assign be = b;
  logic [1:0] sa00; assign sa00 = ae[1:0];
  logic [1:0] sb00; assign sb00 = be[1:0];
  logic [3:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [1:0] sa01; assign sa01 = ae[1:0];
  logic [1:0] sb01; assign sb01 = be[3:2];
  logic [3:0] sp01;
  // segment product (0, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [1:0] sa10; assign sa10 = ae[3:2];
  logic [1:0] sb10; assign sb10 = be[1:0];
  logic [3:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u3 (.a(sa10), .b(sb10), .p(sp10));
  logic [1:0] sa11; assign sa11 = ae[3:2];
  logic [1:0] sb11; assign sb11 = be[3:2];
  logic [3:0] sp11;
  // segment product (1, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u4 (.a(sa11), .b(sb11), .p(sp11));
  logic [9:0] t_sp00; assign t_sp00 = {{(10-4){1'b0}}, sp00} << 0;
  logic [9:0] t_sp01; assign t_sp01 = {{(10-4){1'b0}}, sp01} << 2;
  logic [9:0] t_sp10; assign t_sp10 = {{(10-4){1'b0}}, sp10} << 2;
  logic [9:0] t_sp11; assign t_sp11 = {{(10-4){1'b0}}, sp11} << 4;
  logic [10:0] acc1;
  // merge adder 1
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u5 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(acc1[9:0]), .cout(acc1[10]));
  logic [10:0] acc2;
  // merge adder 2
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u6 (.a(acc1[9:0]), .b(t_sp10), .cin(1'b0), .s(acc2[9:0]), .cout(acc2[10]));
  logic [10:0] acc3;
  // merge adder 3
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u7 (.a(acc2[9:0]), .b(t_sp11), .cin(1'b0), .s(acc3[9:0]), .cout(acc3[10]));
  logic [9:0] full; assign full = acc3[9:0];
  assign p = full[7:0];
endmodule



// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// segmented_grid (square, depth 2): 2 x 2 segment products of 2 x 2 bits (direct_pp_parallel) merged by cpa (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p507511d0_g01 (input logic [3:0] a, input logic [3:0] b, output logic [7:0] p);
  logic [3:0] ae; assign ae = a;
  logic [3:0] be; assign be = b;
  logic [1:0] sa00; assign sa00 = ae[1:0];
  logic [1:0] sb00; assign sb00 = be[1:0];
  logic [3:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [1:0] sa01; assign sa01 = ae[1:0];
  logic [1:0] sb01; assign sb01 = be[3:2];
  logic [3:0] sp01;
  // segment product (0, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [1:0] sa10; assign sa10 = ae[3:2];
  logic [1:0] sb10; assign sb10 = be[1:0];
  logic [3:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u3 (.a(sa10), .b(sb10), .p(sp10));
  logic [1:0] sa11; assign sa11 = ae[3:2];
  logic [1:0] sb11; assign sb11 = be[3:2];
  logic [3:0] sp11;
  // segment product (1, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u4 (.a(sa11), .b(sb11), .p(sp11));
  logic [9:0] t_sp00; assign t_sp00 = {{(10-4){1'b0}}, sp00} << 0;
  logic [9:0] t_sp01; assign t_sp01 = {{(10-4){1'b0}}, sp01} << 2;
  logic [9:0] t_sp10; assign t_sp10 = {{(10-4){1'b0}}, sp10} << 2;
  logic [9:0] t_sp11; assign t_sp11 = {{(10-4){1'b0}}, sp11} << 4;
  logic [10:0] acc1;
  // merge adder 1
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u5 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(acc1[9:0]), .cout(acc1[10]));
  logic [10:0] acc2;
  // merge adder 2
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u6 (.a(acc1[9:0]), .b(t_sp10), .cin(1'b0), .s(acc2[9:0]), .cout(acc2[10]));
  logic [10:0] acc3;
  // merge adder 3
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u7 (.a(acc2[9:0]), .b(t_sp11), .cin(1'b0), .s(acc3[9:0]), .cout(acc3[10]));
  logic [9:0] full; assign full = acc3[9:0];
  assign p = full[7:0];
endmodule


















// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// segmented_grid (square, depth 2): 2 x 2 segment products of 2 x 2 bits (direct_pp_parallel) merged by cpa (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p507511d0_g02 (input logic [3:0] a, input logic [3:0] b, output logic [7:0] p);
  logic [3:0] ae; assign ae = a;
  logic [3:0] be; assign be = b;
  logic [1:0] sa00; assign sa00 = ae[1:0];
  logic [1:0] sb00; assign sb00 = be[1:0];
  logic [3:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [1:0] sa01; assign sa01 = ae[1:0];
  logic [1:0] sb01; assign sb01 = be[3:2];
  logic [3:0] sp01;
  // segment product (0, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [1:0] sa10; assign sa10 = ae[3:2];
  logic [1:0] sb10; assign sb10 = be[1:0];
  logic [3:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u3 (.a(sa10), .b(sb10), .p(sp10));
  logic [1:0] sa11; assign sa11 = ae[3:2];
  logic [1:0] sb11; assign sb11 = be[3:2];
  logic [3:0] sp11;
  // segment product (1, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u4 (.a(sa11), .b(sb11), .p(sp11));
  logic [9:0] t_sp00; assign t_sp00 = {{(10-4){1'b0}}, sp00} << 0;
  logic [9:0] t_sp01; assign t_sp01 = {{(10-4){1'b0}}, sp01} << 2;
  logic [9:0] t_sp10; assign t_sp10 = {{(10-4){1'b0}}, sp10} << 2;
  logic [9:0] t_sp11; assign t_sp11 = {{(10-4){1'b0}}, sp11} << 4;
  logic [10:0] acc1;
  // merge adder 1
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u5 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(acc1[9:0]), .cout(acc1[10]));
  logic [10:0] acc2;
  // merge adder 2
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u6 (.a(acc1[9:0]), .b(t_sp10), .cin(1'b0), .s(acc2[9:0]), .cout(acc2[10]));
  logic [10:0] acc3;
  // merge adder 3
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u7 (.a(acc2[9:0]), .b(t_sp11), .cin(1'b0), .s(acc3[9:0]), .cout(acc3[10]));
  logic [9:0] full; assign full = acc3[9:0];
  assign p = full[7:0];
endmodule


















// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// segmented_grid (square, depth 2): 3 x 3 segment products of 2 x 2 bits (direct_pp_parallel) merged by cpa (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p507511d0_g03 (input logic [4:0] a, input logic [4:0] b, output logic [9:0] p);
  logic [5:0] ae; assign ae = {{(6-5){a[4]}}, a};
  logic [5:0] be; assign be = {{(6-5){b[4]}}, b};
  logic [1:0] sa00; assign sa00 = ae[1:0];
  logic [1:0] sb00; assign sb00 = be[1:0];
  logic [3:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [1:0] sa01; assign sa01 = ae[1:0];
  logic [1:0] sb01; assign sb01 = be[3:2];
  logic [3:0] sp01;
  // segment product (0, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [2:0] sa02; assign sa02 = {{1{1'b0}}, ae[1:0]};
  logic [2:0] sb02; assign sb02 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp02;
  // segment product (0, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u3 (.a(sa02), .b(sb02), .p(sp02));
  logic [1:0] sa10; assign sa10 = ae[3:2];
  logic [1:0] sb10; assign sb10 = be[1:0];
  logic [3:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u4 (.a(sa10), .b(sb10), .p(sp10));
  logic [1:0] sa11; assign sa11 = ae[3:2];
  logic [1:0] sb11; assign sb11 = be[3:2];
  logic [3:0] sp11;
  // segment product (1, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u5 (.a(sa11), .b(sb11), .p(sp11));
  logic [2:0] sa12; assign sa12 = {{1{1'b0}}, ae[3:2]};
  logic [2:0] sb12; assign sb12 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp12;
  // segment product (1, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u6 (.a(sa12), .b(sb12), .p(sp12));
  logic [2:0] sa20; assign sa20 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb20; assign sb20 = {{1{1'b0}}, be[1:0]};
  logic [5:0] sp20;
  // segment product (2, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u7 (.a(sa20), .b(sb20), .p(sp20));
  logic [2:0] sa21; assign sa21 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb21; assign sb21 = {{1{1'b0}}, be[3:2]};
  logic [5:0] sp21;
  // segment product (2, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u8 (.a(sa21), .b(sb21), .p(sp21));
  logic [2:0] sa22; assign sa22 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb22; assign sb22 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp22;
  // segment product (2, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u9 (.a(sa22), .b(sb22), .p(sp22));
  logic [13:0] t_sp00; assign t_sp00 = {{(14-4){1'b0}}, sp00} << 0;
  logic [13:0] t_sp01; assign t_sp01 = {{(14-4){1'b0}}, sp01} << 2;
  logic [13:0] t_sp02; assign t_sp02 = $signed({{(14-6){sp02[5]}}, sp02}) <<< 4;
  logic [13:0] t_sp10; assign t_sp10 = {{(14-4){1'b0}}, sp10} << 2;
  logic [13:0] t_sp11; assign t_sp11 = {{(14-4){1'b0}}, sp11} << 4;
  logic [13:0] t_sp12; assign t_sp12 = $signed({{(14-6){sp12[5]}}, sp12}) <<< 6;
  logic [13:0] t_sp20; assign t_sp20 = $signed({{(14-6){sp20[5]}}, sp20}) <<< 4;
  logic [13:0] t_sp21; assign t_sp21 = $signed({{(14-6){sp21[5]}}, sp21}) <<< 6;
  logic [13:0] t_sp22; assign t_sp22 = $signed({{(14-6){sp22[5]}}, sp22}) <<< 8;
  logic [14:0] acc1;
  // merge adder 1
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u10 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(acc1[13:0]), .cout(acc1[14]));
  logic [14:0] acc2;
  // merge adder 2
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u11 (.a(acc1[13:0]), .b(t_sp02), .cin(1'b0), .s(acc2[13:0]), .cout(acc2[14]));
  logic [14:0] acc3;
  // merge adder 3
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u12 (.a(acc2[13:0]), .b(t_sp10), .cin(1'b0), .s(acc3[13:0]), .cout(acc3[14]));
  logic [14:0] acc4;
  // merge adder 4
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u13 (.a(acc3[13:0]), .b(t_sp11), .cin(1'b0), .s(acc4[13:0]), .cout(acc4[14]));
  logic [14:0] acc5;
  // merge adder 5
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u14 (.a(acc4[13:0]), .b(t_sp12), .cin(1'b0), .s(acc5[13:0]), .cout(acc5[14]));
  logic [14:0] acc6;
  // merge adder 6
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u15 (.a(acc5[13:0]), .b(t_sp20), .cin(1'b0), .s(acc6[13:0]), .cout(acc6[14]));
  logic [14:0] acc7;
  // merge adder 7
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u16 (.a(acc6[13:0]), .b(t_sp21), .cin(1'b0), .s(acc7[13:0]), .cout(acc7[14]));
  logic [14:0] acc8;
  // merge adder 8
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u17 (.a(acc7[13:0]), .b(t_sp22), .cin(1'b0), .s(acc8[13:0]), .cout(acc8[14]));
  logic [13:0] full; assign full = acc8[13:0];
  assign p = full[9:0];
endmodule



// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// segmented_grid (square, depth 2): 2 x 2 segment products of 2 x 2 bits (direct_pp_parallel) merged by cpa (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p507511d0_g10 (input logic [3:0] a, input logic [3:0] b, output logic [7:0] p);
  logic [3:0] ae; assign ae = a;
  logic [3:0] be; assign be = b;
  logic [1:0] sa00; assign sa00 = ae[1:0];
  logic [1:0] sb00; assign sb00 = be[1:0];
  logic [3:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [1:0] sa01; assign sa01 = ae[1:0];
  logic [1:0] sb01; assign sb01 = be[3:2];
  logic [3:0] sp01;
  // segment product (0, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [1:0] sa10; assign sa10 = ae[3:2];
  logic [1:0] sb10; assign sb10 = be[1:0];
  logic [3:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u3 (.a(sa10), .b(sb10), .p(sp10));
  logic [1:0] sa11; assign sa11 = ae[3:2];
  logic [1:0] sb11; assign sb11 = be[3:2];
  logic [3:0] sp11;
  // segment product (1, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u4 (.a(sa11), .b(sb11), .p(sp11));
  logic [9:0] t_sp00; assign t_sp00 = {{(10-4){1'b0}}, sp00} << 0;
  logic [9:0] t_sp01; assign t_sp01 = {{(10-4){1'b0}}, sp01} << 2;
  logic [9:0] t_sp10; assign t_sp10 = {{(10-4){1'b0}}, sp10} << 2;
  logic [9:0] t_sp11; assign t_sp11 = {{(10-4){1'b0}}, sp11} << 4;
  logic [10:0] acc1;
  // merge adder 1
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u5 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(acc1[9:0]), .cout(acc1[10]));
  logic [10:0] acc2;
  // merge adder 2
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u6 (.a(acc1[9:0]), .b(t_sp10), .cin(1'b0), .s(acc2[9:0]), .cout(acc2[10]));
  logic [10:0] acc3;
  // merge adder 3
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u7 (.a(acc2[9:0]), .b(t_sp11), .cin(1'b0), .s(acc3[9:0]), .cout(acc3[10]));
  logic [9:0] full; assign full = acc3[9:0];
  assign p = full[7:0];
endmodule


















// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// segmented_grid (square, depth 2): 2 x 2 segment products of 2 x 2 bits (direct_pp_parallel) merged by cpa (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p507511d0_g11 (input logic [3:0] a, input logic [3:0] b, output logic [7:0] p);
  logic [3:0] ae; assign ae = a;
  logic [3:0] be; assign be = b;
  logic [1:0] sa00; assign sa00 = ae[1:0];
  logic [1:0] sb00; assign sb00 = be[1:0];
  logic [3:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [1:0] sa01; assign sa01 = ae[1:0];
  logic [1:0] sb01; assign sb01 = be[3:2];
  logic [3:0] sp01;
  // segment product (0, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [1:0] sa10; assign sa10 = ae[3:2];
  logic [1:0] sb10; assign sb10 = be[1:0];
  logic [3:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u3 (.a(sa10), .b(sb10), .p(sp10));
  logic [1:0] sa11; assign sa11 = ae[3:2];
  logic [1:0] sb11; assign sb11 = be[3:2];
  logic [3:0] sp11;
  // segment product (1, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u4 (.a(sa11), .b(sb11), .p(sp11));
  logic [9:0] t_sp00; assign t_sp00 = {{(10-4){1'b0}}, sp00} << 0;
  logic [9:0] t_sp01; assign t_sp01 = {{(10-4){1'b0}}, sp01} << 2;
  logic [9:0] t_sp10; assign t_sp10 = {{(10-4){1'b0}}, sp10} << 2;
  logic [9:0] t_sp11; assign t_sp11 = {{(10-4){1'b0}}, sp11} << 4;
  logic [10:0] acc1;
  // merge adder 1
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u5 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(acc1[9:0]), .cout(acc1[10]));
  logic [10:0] acc2;
  // merge adder 2
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u6 (.a(acc1[9:0]), .b(t_sp10), .cin(1'b0), .s(acc2[9:0]), .cout(acc2[10]));
  logic [10:0] acc3;
  // merge adder 3
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u7 (.a(acc2[9:0]), .b(t_sp11), .cin(1'b0), .s(acc3[9:0]), .cout(acc3[10]));
  logic [9:0] full; assign full = acc3[9:0];
  assign p = full[7:0];
endmodule


















// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// segmented_grid (square, depth 2): 2 x 2 segment products of 2 x 2 bits (direct_pp_parallel) merged by cpa (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p507511d0_g12 (input logic [3:0] a, input logic [3:0] b, output logic [7:0] p);
  logic [3:0] ae; assign ae = a;
  logic [3:0] be; assign be = b;
  logic [1:0] sa00; assign sa00 = ae[1:0];
  logic [1:0] sb00; assign sb00 = be[1:0];
  logic [3:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [1:0] sa01; assign sa01 = ae[1:0];
  logic [1:0] sb01; assign sb01 = be[3:2];
  logic [3:0] sp01;
  // segment product (0, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [1:0] sa10; assign sa10 = ae[3:2];
  logic [1:0] sb10; assign sb10 = be[1:0];
  logic [3:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u3 (.a(sa10), .b(sb10), .p(sp10));
  logic [1:0] sa11; assign sa11 = ae[3:2];
  logic [1:0] sb11; assign sb11 = be[3:2];
  logic [3:0] sp11;
  // segment product (1, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u4 (.a(sa11), .b(sb11), .p(sp11));
  logic [9:0] t_sp00; assign t_sp00 = {{(10-4){1'b0}}, sp00} << 0;
  logic [9:0] t_sp01; assign t_sp01 = {{(10-4){1'b0}}, sp01} << 2;
  logic [9:0] t_sp10; assign t_sp10 = {{(10-4){1'b0}}, sp10} << 2;
  logic [9:0] t_sp11; assign t_sp11 = {{(10-4){1'b0}}, sp11} << 4;
  logic [10:0] acc1;
  // merge adder 1
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u5 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(acc1[9:0]), .cout(acc1[10]));
  logic [10:0] acc2;
  // merge adder 2
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u6 (.a(acc1[9:0]), .b(t_sp10), .cin(1'b0), .s(acc2[9:0]), .cout(acc2[10]));
  logic [10:0] acc3;
  // merge adder 3
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u7 (.a(acc2[9:0]), .b(t_sp11), .cin(1'b0), .s(acc3[9:0]), .cout(acc3[10]));
  logic [9:0] full; assign full = acc3[9:0];
  assign p = full[7:0];
endmodule


















// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// segmented_grid (square, depth 2): 3 x 3 segment products of 2 x 2 bits (direct_pp_parallel) merged by cpa (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p507511d0_g13 (input logic [4:0] a, input logic [4:0] b, output logic [9:0] p);
  logic [5:0] ae; assign ae = {{(6-5){a[4]}}, a};
  logic [5:0] be; assign be = {{(6-5){b[4]}}, b};
  logic [1:0] sa00; assign sa00 = ae[1:0];
  logic [1:0] sb00; assign sb00 = be[1:0];
  logic [3:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [1:0] sa01; assign sa01 = ae[1:0];
  logic [1:0] sb01; assign sb01 = be[3:2];
  logic [3:0] sp01;
  // segment product (0, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [2:0] sa02; assign sa02 = {{1{1'b0}}, ae[1:0]};
  logic [2:0] sb02; assign sb02 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp02;
  // segment product (0, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u3 (.a(sa02), .b(sb02), .p(sp02));
  logic [1:0] sa10; assign sa10 = ae[3:2];
  logic [1:0] sb10; assign sb10 = be[1:0];
  logic [3:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u4 (.a(sa10), .b(sb10), .p(sp10));
  logic [1:0] sa11; assign sa11 = ae[3:2];
  logic [1:0] sb11; assign sb11 = be[3:2];
  logic [3:0] sp11;
  // segment product (1, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u5 (.a(sa11), .b(sb11), .p(sp11));
  logic [2:0] sa12; assign sa12 = {{1{1'b0}}, ae[3:2]};
  logic [2:0] sb12; assign sb12 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp12;
  // segment product (1, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u6 (.a(sa12), .b(sb12), .p(sp12));
  logic [2:0] sa20; assign sa20 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb20; assign sb20 = {{1{1'b0}}, be[1:0]};
  logic [5:0] sp20;
  // segment product (2, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u7 (.a(sa20), .b(sb20), .p(sp20));
  logic [2:0] sa21; assign sa21 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb21; assign sb21 = {{1{1'b0}}, be[3:2]};
  logic [5:0] sp21;
  // segment product (2, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u8 (.a(sa21), .b(sb21), .p(sp21));
  logic [2:0] sa22; assign sa22 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb22; assign sb22 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp22;
  // segment product (2, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u9 (.a(sa22), .b(sb22), .p(sp22));
  logic [13:0] t_sp00; assign t_sp00 = {{(14-4){1'b0}}, sp00} << 0;
  logic [13:0] t_sp01; assign t_sp01 = {{(14-4){1'b0}}, sp01} << 2;
  logic [13:0] t_sp02; assign t_sp02 = $signed({{(14-6){sp02[5]}}, sp02}) <<< 4;
  logic [13:0] t_sp10; assign t_sp10 = {{(14-4){1'b0}}, sp10} << 2;
  logic [13:0] t_sp11; assign t_sp11 = {{(14-4){1'b0}}, sp11} << 4;
  logic [13:0] t_sp12; assign t_sp12 = $signed({{(14-6){sp12[5]}}, sp12}) <<< 6;
  logic [13:0] t_sp20; assign t_sp20 = $signed({{(14-6){sp20[5]}}, sp20}) <<< 4;
  logic [13:0] t_sp21; assign t_sp21 = $signed({{(14-6){sp21[5]}}, sp21}) <<< 6;
  logic [13:0] t_sp22; assign t_sp22 = $signed({{(14-6){sp22[5]}}, sp22}) <<< 8;
  logic [14:0] acc1;
  // merge adder 1
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u10 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(acc1[13:0]), .cout(acc1[14]));
  logic [14:0] acc2;
  // merge adder 2
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u11 (.a(acc1[13:0]), .b(t_sp02), .cin(1'b0), .s(acc2[13:0]), .cout(acc2[14]));
  logic [14:0] acc3;
  // merge adder 3
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u12 (.a(acc2[13:0]), .b(t_sp10), .cin(1'b0), .s(acc3[13:0]), .cout(acc3[14]));
  logic [14:0] acc4;
  // merge adder 4
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u13 (.a(acc3[13:0]), .b(t_sp11), .cin(1'b0), .s(acc4[13:0]), .cout(acc4[14]));
  logic [14:0] acc5;
  // merge adder 5
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u14 (.a(acc4[13:0]), .b(t_sp12), .cin(1'b0), .s(acc5[13:0]), .cout(acc5[14]));
  logic [14:0] acc6;
  // merge adder 6
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u15 (.a(acc5[13:0]), .b(t_sp20), .cin(1'b0), .s(acc6[13:0]), .cout(acc6[14]));
  logic [14:0] acc7;
  // merge adder 7
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u16 (.a(acc6[13:0]), .b(t_sp21), .cin(1'b0), .s(acc7[13:0]), .cout(acc7[14]));
  logic [14:0] acc8;
  // merge adder 8
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u17 (.a(acc7[13:0]), .b(t_sp22), .cin(1'b0), .s(acc8[13:0]), .cout(acc8[14]));
  logic [13:0] full; assign full = acc8[13:0];
  assign p = full[9:0];
endmodule






































// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// segmented_grid (square, depth 2): 2 x 2 segment products of 2 x 2 bits (direct_pp_parallel) merged by cpa (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p507511d0_g20 (input logic [3:0] a, input logic [3:0] b, output logic [7:0] p);
  logic [3:0] ae; assign ae = a;
  logic [3:0] be; assign be = b;
  logic [1:0] sa00; assign sa00 = ae[1:0];
  logic [1:0] sb00; assign sb00 = be[1:0];
  logic [3:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [1:0] sa01; assign sa01 = ae[1:0];
  logic [1:0] sb01; assign sb01 = be[3:2];
  logic [3:0] sp01;
  // segment product (0, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [1:0] sa10; assign sa10 = ae[3:2];
  logic [1:0] sb10; assign sb10 = be[1:0];
  logic [3:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u3 (.a(sa10), .b(sb10), .p(sp10));
  logic [1:0] sa11; assign sa11 = ae[3:2];
  logic [1:0] sb11; assign sb11 = be[3:2];
  logic [3:0] sp11;
  // segment product (1, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u4 (.a(sa11), .b(sb11), .p(sp11));
  logic [9:0] t_sp00; assign t_sp00 = {{(10-4){1'b0}}, sp00} << 0;
  logic [9:0] t_sp01; assign t_sp01 = {{(10-4){1'b0}}, sp01} << 2;
  logic [9:0] t_sp10; assign t_sp10 = {{(10-4){1'b0}}, sp10} << 2;
  logic [9:0] t_sp11; assign t_sp11 = {{(10-4){1'b0}}, sp11} << 4;
  logic [10:0] acc1;
  // merge adder 1
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u5 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(acc1[9:0]), .cout(acc1[10]));
  logic [10:0] acc2;
  // merge adder 2
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u6 (.a(acc1[9:0]), .b(t_sp10), .cin(1'b0), .s(acc2[9:0]), .cout(acc2[10]));
  logic [10:0] acc3;
  // merge adder 3
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u7 (.a(acc2[9:0]), .b(t_sp11), .cin(1'b0), .s(acc3[9:0]), .cout(acc3[10]));
  logic [9:0] full; assign full = acc3[9:0];
  assign p = full[7:0];
endmodule


















// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// segmented_grid (square, depth 2): 2 x 2 segment products of 2 x 2 bits (direct_pp_parallel) merged by cpa (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p507511d0_g21 (input logic [3:0] a, input logic [3:0] b, output logic [7:0] p);
  logic [3:0] ae; assign ae = a;
  logic [3:0] be; assign be = b;
  logic [1:0] sa00; assign sa00 = ae[1:0];
  logic [1:0] sb00; assign sb00 = be[1:0];
  logic [3:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [1:0] sa01; assign sa01 = ae[1:0];
  logic [1:0] sb01; assign sb01 = be[3:2];
  logic [3:0] sp01;
  // segment product (0, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [1:0] sa10; assign sa10 = ae[3:2];
  logic [1:0] sb10; assign sb10 = be[1:0];
  logic [3:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u3 (.a(sa10), .b(sb10), .p(sp10));
  logic [1:0] sa11; assign sa11 = ae[3:2];
  logic [1:0] sb11; assign sb11 = be[3:2];
  logic [3:0] sp11;
  // segment product (1, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u4 (.a(sa11), .b(sb11), .p(sp11));
  logic [9:0] t_sp00; assign t_sp00 = {{(10-4){1'b0}}, sp00} << 0;
  logic [9:0] t_sp01; assign t_sp01 = {{(10-4){1'b0}}, sp01} << 2;
  logic [9:0] t_sp10; assign t_sp10 = {{(10-4){1'b0}}, sp10} << 2;
  logic [9:0] t_sp11; assign t_sp11 = {{(10-4){1'b0}}, sp11} << 4;
  logic [10:0] acc1;
  // merge adder 1
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u5 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(acc1[9:0]), .cout(acc1[10]));
  logic [10:0] acc2;
  // merge adder 2
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u6 (.a(acc1[9:0]), .b(t_sp10), .cin(1'b0), .s(acc2[9:0]), .cout(acc2[10]));
  logic [10:0] acc3;
  // merge adder 3
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u7 (.a(acc2[9:0]), .b(t_sp11), .cin(1'b0), .s(acc3[9:0]), .cout(acc3[10]));
  logic [9:0] full; assign full = acc3[9:0];
  assign p = full[7:0];
endmodule


















// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// segmented_grid (square, depth 2): 2 x 2 segment products of 2 x 2 bits (direct_pp_parallel) merged by cpa (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p507511d0_g22 (input logic [3:0] a, input logic [3:0] b, output logic [7:0] p);
  logic [3:0] ae; assign ae = a;
  logic [3:0] be; assign be = b;
  logic [1:0] sa00; assign sa00 = ae[1:0];
  logic [1:0] sb00; assign sb00 = be[1:0];
  logic [3:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [1:0] sa01; assign sa01 = ae[1:0];
  logic [1:0] sb01; assign sb01 = be[3:2];
  logic [3:0] sp01;
  // segment product (0, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [1:0] sa10; assign sa10 = ae[3:2];
  logic [1:0] sb10; assign sb10 = be[1:0];
  logic [3:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u3 (.a(sa10), .b(sb10), .p(sp10));
  logic [1:0] sa11; assign sa11 = ae[3:2];
  logic [1:0] sb11; assign sb11 = be[3:2];
  logic [3:0] sp11;
  // segment product (1, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u4 (.a(sa11), .b(sb11), .p(sp11));
  logic [9:0] t_sp00; assign t_sp00 = {{(10-4){1'b0}}, sp00} << 0;
  logic [9:0] t_sp01; assign t_sp01 = {{(10-4){1'b0}}, sp01} << 2;
  logic [9:0] t_sp10; assign t_sp10 = {{(10-4){1'b0}}, sp10} << 2;
  logic [9:0] t_sp11; assign t_sp11 = {{(10-4){1'b0}}, sp11} << 4;
  logic [10:0] acc1;
  // merge adder 1
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u5 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(acc1[9:0]), .cout(acc1[10]));
  logic [10:0] acc2;
  // merge adder 2
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u6 (.a(acc1[9:0]), .b(t_sp10), .cin(1'b0), .s(acc2[9:0]), .cout(acc2[10]));
  logic [10:0] acc3;
  // merge adder 3
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w10 u7 (.a(acc2[9:0]), .b(t_sp11), .cin(1'b0), .s(acc3[9:0]), .cout(acc3[10]));
  logic [9:0] full; assign full = acc3[9:0];
  assign p = full[7:0];
endmodule


















// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// segmented_grid (square, depth 2): 3 x 3 segment products of 2 x 2 bits (direct_pp_parallel) merged by cpa (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p507511d0_g23 (input logic [4:0] a, input logic [4:0] b, output logic [9:0] p);
  logic [5:0] ae; assign ae = {{(6-5){a[4]}}, a};
  logic [5:0] be; assign be = {{(6-5){b[4]}}, b};
  logic [1:0] sa00; assign sa00 = ae[1:0];
  logic [1:0] sb00; assign sb00 = be[1:0];
  logic [3:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [1:0] sa01; assign sa01 = ae[1:0];
  logic [1:0] sb01; assign sb01 = be[3:2];
  logic [3:0] sp01;
  // segment product (0, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [2:0] sa02; assign sa02 = {{1{1'b0}}, ae[1:0]};
  logic [2:0] sb02; assign sb02 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp02;
  // segment product (0, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u3 (.a(sa02), .b(sb02), .p(sp02));
  logic [1:0] sa10; assign sa10 = ae[3:2];
  logic [1:0] sb10; assign sb10 = be[1:0];
  logic [3:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u4 (.a(sa10), .b(sb10), .p(sp10));
  logic [1:0] sa11; assign sa11 = ae[3:2];
  logic [1:0] sb11; assign sb11 = be[3:2];
  logic [3:0] sp11;
  // segment product (1, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u5 (.a(sa11), .b(sb11), .p(sp11));
  logic [2:0] sa12; assign sa12 = {{1{1'b0}}, ae[3:2]};
  logic [2:0] sb12; assign sb12 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp12;
  // segment product (1, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u6 (.a(sa12), .b(sb12), .p(sp12));
  logic [2:0] sa20; assign sa20 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb20; assign sb20 = {{1{1'b0}}, be[1:0]};
  logic [5:0] sp20;
  // segment product (2, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u7 (.a(sa20), .b(sb20), .p(sp20));
  logic [2:0] sa21; assign sa21 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb21; assign sb21 = {{1{1'b0}}, be[3:2]};
  logic [5:0] sp21;
  // segment product (2, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u8 (.a(sa21), .b(sb21), .p(sp21));
  logic [2:0] sa22; assign sa22 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb22; assign sb22 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp22;
  // segment product (2, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u9 (.a(sa22), .b(sb22), .p(sp22));
  logic [13:0] t_sp00; assign t_sp00 = {{(14-4){1'b0}}, sp00} << 0;
  logic [13:0] t_sp01; assign t_sp01 = {{(14-4){1'b0}}, sp01} << 2;
  logic [13:0] t_sp02; assign t_sp02 = $signed({{(14-6){sp02[5]}}, sp02}) <<< 4;
  logic [13:0] t_sp10; assign t_sp10 = {{(14-4){1'b0}}, sp10} << 2;
  logic [13:0] t_sp11; assign t_sp11 = {{(14-4){1'b0}}, sp11} << 4;
  logic [13:0] t_sp12; assign t_sp12 = $signed({{(14-6){sp12[5]}}, sp12}) <<< 6;
  logic [13:0] t_sp20; assign t_sp20 = $signed({{(14-6){sp20[5]}}, sp20}) <<< 4;
  logic [13:0] t_sp21; assign t_sp21 = $signed({{(14-6){sp21[5]}}, sp21}) <<< 6;
  logic [13:0] t_sp22; assign t_sp22 = $signed({{(14-6){sp22[5]}}, sp22}) <<< 8;
  logic [14:0] acc1;
  // merge adder 1
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u10 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(acc1[13:0]), .cout(acc1[14]));
  logic [14:0] acc2;
  // merge adder 2
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u11 (.a(acc1[13:0]), .b(t_sp02), .cin(1'b0), .s(acc2[13:0]), .cout(acc2[14]));
  logic [14:0] acc3;
  // merge adder 3
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u12 (.a(acc2[13:0]), .b(t_sp10), .cin(1'b0), .s(acc3[13:0]), .cout(acc3[14]));
  logic [14:0] acc4;
  // merge adder 4
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u13 (.a(acc3[13:0]), .b(t_sp11), .cin(1'b0), .s(acc4[13:0]), .cout(acc4[14]));
  logic [14:0] acc5;
  // merge adder 5
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u14 (.a(acc4[13:0]), .b(t_sp12), .cin(1'b0), .s(acc5[13:0]), .cout(acc5[14]));
  logic [14:0] acc6;
  // merge adder 6
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u15 (.a(acc5[13:0]), .b(t_sp20), .cin(1'b0), .s(acc6[13:0]), .cout(acc6[14]));
  logic [14:0] acc7;
  // merge adder 7
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u16 (.a(acc6[13:0]), .b(t_sp21), .cin(1'b0), .s(acc7[13:0]), .cout(acc7[14]));
  logic [14:0] acc8;
  // merge adder 8
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u17 (.a(acc7[13:0]), .b(t_sp22), .cin(1'b0), .s(acc8[13:0]), .cout(acc8[14]));
  logic [13:0] full; assign full = acc8[13:0];
  assign p = full[9:0];
endmodule






































// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// segmented_grid (square, depth 2): 3 x 3 segment products of 2 x 2 bits (direct_pp_parallel) merged by cpa (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p507511d0_g30 (input logic [4:0] a, input logic [4:0] b, output logic [9:0] p);
  logic [5:0] ae; assign ae = {{(6-5){a[4]}}, a};
  logic [5:0] be; assign be = {{(6-5){b[4]}}, b};
  logic [1:0] sa00; assign sa00 = ae[1:0];
  logic [1:0] sb00; assign sb00 = be[1:0];
  logic [3:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [1:0] sa01; assign sa01 = ae[1:0];
  logic [1:0] sb01; assign sb01 = be[3:2];
  logic [3:0] sp01;
  // segment product (0, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [2:0] sa02; assign sa02 = {{1{1'b0}}, ae[1:0]};
  logic [2:0] sb02; assign sb02 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp02;
  // segment product (0, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u3 (.a(sa02), .b(sb02), .p(sp02));
  logic [1:0] sa10; assign sa10 = ae[3:2];
  logic [1:0] sb10; assign sb10 = be[1:0];
  logic [3:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u4 (.a(sa10), .b(sb10), .p(sp10));
  logic [1:0] sa11; assign sa11 = ae[3:2];
  logic [1:0] sb11; assign sb11 = be[3:2];
  logic [3:0] sp11;
  // segment product (1, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u5 (.a(sa11), .b(sb11), .p(sp11));
  logic [2:0] sa12; assign sa12 = {{1{1'b0}}, ae[3:2]};
  logic [2:0] sb12; assign sb12 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp12;
  // segment product (1, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u6 (.a(sa12), .b(sb12), .p(sp12));
  logic [2:0] sa20; assign sa20 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb20; assign sb20 = {{1{1'b0}}, be[1:0]};
  logic [5:0] sp20;
  // segment product (2, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u7 (.a(sa20), .b(sb20), .p(sp20));
  logic [2:0] sa21; assign sa21 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb21; assign sb21 = {{1{1'b0}}, be[3:2]};
  logic [5:0] sp21;
  // segment product (2, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u8 (.a(sa21), .b(sb21), .p(sp21));
  logic [2:0] sa22; assign sa22 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb22; assign sb22 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp22;
  // segment product (2, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u9 (.a(sa22), .b(sb22), .p(sp22));
  logic [13:0] t_sp00; assign t_sp00 = {{(14-4){1'b0}}, sp00} << 0;
  logic [13:0] t_sp01; assign t_sp01 = {{(14-4){1'b0}}, sp01} << 2;
  logic [13:0] t_sp02; assign t_sp02 = $signed({{(14-6){sp02[5]}}, sp02}) <<< 4;
  logic [13:0] t_sp10; assign t_sp10 = {{(14-4){1'b0}}, sp10} << 2;
  logic [13:0] t_sp11; assign t_sp11 = {{(14-4){1'b0}}, sp11} << 4;
  logic [13:0] t_sp12; assign t_sp12 = $signed({{(14-6){sp12[5]}}, sp12}) <<< 6;
  logic [13:0] t_sp20; assign t_sp20 = $signed({{(14-6){sp20[5]}}, sp20}) <<< 4;
  logic [13:0] t_sp21; assign t_sp21 = $signed({{(14-6){sp21[5]}}, sp21}) <<< 6;
  logic [13:0] t_sp22; assign t_sp22 = $signed({{(14-6){sp22[5]}}, sp22}) <<< 8;
  logic [14:0] acc1;
  // merge adder 1
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u10 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(acc1[13:0]), .cout(acc1[14]));
  logic [14:0] acc2;
  // merge adder 2
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u11 (.a(acc1[13:0]), .b(t_sp02), .cin(1'b0), .s(acc2[13:0]), .cout(acc2[14]));
  logic [14:0] acc3;
  // merge adder 3
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u12 (.a(acc2[13:0]), .b(t_sp10), .cin(1'b0), .s(acc3[13:0]), .cout(acc3[14]));
  logic [14:0] acc4;
  // merge adder 4
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u13 (.a(acc3[13:0]), .b(t_sp11), .cin(1'b0), .s(acc4[13:0]), .cout(acc4[14]));
  logic [14:0] acc5;
  // merge adder 5
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u14 (.a(acc4[13:0]), .b(t_sp12), .cin(1'b0), .s(acc5[13:0]), .cout(acc5[14]));
  logic [14:0] acc6;
  // merge adder 6
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u15 (.a(acc5[13:0]), .b(t_sp20), .cin(1'b0), .s(acc6[13:0]), .cout(acc6[14]));
  logic [14:0] acc7;
  // merge adder 7
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u16 (.a(acc6[13:0]), .b(t_sp21), .cin(1'b0), .s(acc7[13:0]), .cout(acc7[14]));
  logic [14:0] acc8;
  // merge adder 8
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u17 (.a(acc7[13:0]), .b(t_sp22), .cin(1'b0), .s(acc8[13:0]), .cout(acc8[14]));
  logic [13:0] full; assign full = acc8[13:0];
  assign p = full[9:0];
endmodule






































// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// segmented_grid (square, depth 2): 3 x 3 segment products of 2 x 2 bits (direct_pp_parallel) merged by cpa (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p507511d0_g31 (input logic [4:0] a, input logic [4:0] b, output logic [9:0] p);
  logic [5:0] ae; assign ae = {{(6-5){a[4]}}, a};
  logic [5:0] be; assign be = {{(6-5){b[4]}}, b};
  logic [1:0] sa00; assign sa00 = ae[1:0];
  logic [1:0] sb00; assign sb00 = be[1:0];
  logic [3:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [1:0] sa01; assign sa01 = ae[1:0];
  logic [1:0] sb01; assign sb01 = be[3:2];
  logic [3:0] sp01;
  // segment product (0, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [2:0] sa02; assign sa02 = {{1{1'b0}}, ae[1:0]};
  logic [2:0] sb02; assign sb02 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp02;
  // segment product (0, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u3 (.a(sa02), .b(sb02), .p(sp02));
  logic [1:0] sa10; assign sa10 = ae[3:2];
  logic [1:0] sb10; assign sb10 = be[1:0];
  logic [3:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u4 (.a(sa10), .b(sb10), .p(sp10));
  logic [1:0] sa11; assign sa11 = ae[3:2];
  logic [1:0] sb11; assign sb11 = be[3:2];
  logic [3:0] sp11;
  // segment product (1, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u5 (.a(sa11), .b(sb11), .p(sp11));
  logic [2:0] sa12; assign sa12 = {{1{1'b0}}, ae[3:2]};
  logic [2:0] sb12; assign sb12 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp12;
  // segment product (1, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u6 (.a(sa12), .b(sb12), .p(sp12));
  logic [2:0] sa20; assign sa20 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb20; assign sb20 = {{1{1'b0}}, be[1:0]};
  logic [5:0] sp20;
  // segment product (2, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u7 (.a(sa20), .b(sb20), .p(sp20));
  logic [2:0] sa21; assign sa21 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb21; assign sb21 = {{1{1'b0}}, be[3:2]};
  logic [5:0] sp21;
  // segment product (2, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u8 (.a(sa21), .b(sb21), .p(sp21));
  logic [2:0] sa22; assign sa22 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb22; assign sb22 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp22;
  // segment product (2, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u9 (.a(sa22), .b(sb22), .p(sp22));
  logic [13:0] t_sp00; assign t_sp00 = {{(14-4){1'b0}}, sp00} << 0;
  logic [13:0] t_sp01; assign t_sp01 = {{(14-4){1'b0}}, sp01} << 2;
  logic [13:0] t_sp02; assign t_sp02 = $signed({{(14-6){sp02[5]}}, sp02}) <<< 4;
  logic [13:0] t_sp10; assign t_sp10 = {{(14-4){1'b0}}, sp10} << 2;
  logic [13:0] t_sp11; assign t_sp11 = {{(14-4){1'b0}}, sp11} << 4;
  logic [13:0] t_sp12; assign t_sp12 = $signed({{(14-6){sp12[5]}}, sp12}) <<< 6;
  logic [13:0] t_sp20; assign t_sp20 = $signed({{(14-6){sp20[5]}}, sp20}) <<< 4;
  logic [13:0] t_sp21; assign t_sp21 = $signed({{(14-6){sp21[5]}}, sp21}) <<< 6;
  logic [13:0] t_sp22; assign t_sp22 = $signed({{(14-6){sp22[5]}}, sp22}) <<< 8;
  logic [14:0] acc1;
  // merge adder 1
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u10 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(acc1[13:0]), .cout(acc1[14]));
  logic [14:0] acc2;
  // merge adder 2
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u11 (.a(acc1[13:0]), .b(t_sp02), .cin(1'b0), .s(acc2[13:0]), .cout(acc2[14]));
  logic [14:0] acc3;
  // merge adder 3
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u12 (.a(acc2[13:0]), .b(t_sp10), .cin(1'b0), .s(acc3[13:0]), .cout(acc3[14]));
  logic [14:0] acc4;
  // merge adder 4
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u13 (.a(acc3[13:0]), .b(t_sp11), .cin(1'b0), .s(acc4[13:0]), .cout(acc4[14]));
  logic [14:0] acc5;
  // merge adder 5
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u14 (.a(acc4[13:0]), .b(t_sp12), .cin(1'b0), .s(acc5[13:0]), .cout(acc5[14]));
  logic [14:0] acc6;
  // merge adder 6
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u15 (.a(acc5[13:0]), .b(t_sp20), .cin(1'b0), .s(acc6[13:0]), .cout(acc6[14]));
  logic [14:0] acc7;
  // merge adder 7
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u16 (.a(acc6[13:0]), .b(t_sp21), .cin(1'b0), .s(acc7[13:0]), .cout(acc7[14]));
  logic [14:0] acc8;
  // merge adder 8
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u17 (.a(acc7[13:0]), .b(t_sp22), .cin(1'b0), .s(acc8[13:0]), .cout(acc8[14]));
  logic [13:0] full; assign full = acc8[13:0];
  assign p = full[9:0];
endmodule






































// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// segmented_grid (square, depth 2): 3 x 3 segment products of 2 x 2 bits (direct_pp_parallel) merged by cpa (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p507511d0_g32 (input logic [4:0] a, input logic [4:0] b, output logic [9:0] p);
  logic [5:0] ae; assign ae = {{(6-5){a[4]}}, a};
  logic [5:0] be; assign be = {{(6-5){b[4]}}, b};
  logic [1:0] sa00; assign sa00 = ae[1:0];
  logic [1:0] sb00; assign sb00 = be[1:0];
  logic [3:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [1:0] sa01; assign sa01 = ae[1:0];
  logic [1:0] sb01; assign sb01 = be[3:2];
  logic [3:0] sp01;
  // segment product (0, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [2:0] sa02; assign sa02 = {{1{1'b0}}, ae[1:0]};
  logic [2:0] sb02; assign sb02 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp02;
  // segment product (0, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u3 (.a(sa02), .b(sb02), .p(sp02));
  logic [1:0] sa10; assign sa10 = ae[3:2];
  logic [1:0] sb10; assign sb10 = be[1:0];
  logic [3:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u4 (.a(sa10), .b(sb10), .p(sp10));
  logic [1:0] sa11; assign sa11 = ae[3:2];
  logic [1:0] sb11; assign sb11 = be[3:2];
  logic [3:0] sp11;
  // segment product (1, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u5 (.a(sa11), .b(sb11), .p(sp11));
  logic [2:0] sa12; assign sa12 = {{1{1'b0}}, ae[3:2]};
  logic [2:0] sb12; assign sb12 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp12;
  // segment product (1, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u6 (.a(sa12), .b(sb12), .p(sp12));
  logic [2:0] sa20; assign sa20 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb20; assign sb20 = {{1{1'b0}}, be[1:0]};
  logic [5:0] sp20;
  // segment product (2, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u7 (.a(sa20), .b(sb20), .p(sp20));
  logic [2:0] sa21; assign sa21 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb21; assign sb21 = {{1{1'b0}}, be[3:2]};
  logic [5:0] sp21;
  // segment product (2, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u8 (.a(sa21), .b(sb21), .p(sp21));
  logic [2:0] sa22; assign sa22 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb22; assign sb22 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp22;
  // segment product (2, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u9 (.a(sa22), .b(sb22), .p(sp22));
  logic [13:0] t_sp00; assign t_sp00 = {{(14-4){1'b0}}, sp00} << 0;
  logic [13:0] t_sp01; assign t_sp01 = {{(14-4){1'b0}}, sp01} << 2;
  logic [13:0] t_sp02; assign t_sp02 = $signed({{(14-6){sp02[5]}}, sp02}) <<< 4;
  logic [13:0] t_sp10; assign t_sp10 = {{(14-4){1'b0}}, sp10} << 2;
  logic [13:0] t_sp11; assign t_sp11 = {{(14-4){1'b0}}, sp11} << 4;
  logic [13:0] t_sp12; assign t_sp12 = $signed({{(14-6){sp12[5]}}, sp12}) <<< 6;
  logic [13:0] t_sp20; assign t_sp20 = $signed({{(14-6){sp20[5]}}, sp20}) <<< 4;
  logic [13:0] t_sp21; assign t_sp21 = $signed({{(14-6){sp21[5]}}, sp21}) <<< 6;
  logic [13:0] t_sp22; assign t_sp22 = $signed({{(14-6){sp22[5]}}, sp22}) <<< 8;
  logic [14:0] acc1;
  // merge adder 1
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u10 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(acc1[13:0]), .cout(acc1[14]));
  logic [14:0] acc2;
  // merge adder 2
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u11 (.a(acc1[13:0]), .b(t_sp02), .cin(1'b0), .s(acc2[13:0]), .cout(acc2[14]));
  logic [14:0] acc3;
  // merge adder 3
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u12 (.a(acc2[13:0]), .b(t_sp10), .cin(1'b0), .s(acc3[13:0]), .cout(acc3[14]));
  logic [14:0] acc4;
  // merge adder 4
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u13 (.a(acc3[13:0]), .b(t_sp11), .cin(1'b0), .s(acc4[13:0]), .cout(acc4[14]));
  logic [14:0] acc5;
  // merge adder 5
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u14 (.a(acc4[13:0]), .b(t_sp12), .cin(1'b0), .s(acc5[13:0]), .cout(acc5[14]));
  logic [14:0] acc6;
  // merge adder 6
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u15 (.a(acc5[13:0]), .b(t_sp20), .cin(1'b0), .s(acc6[13:0]), .cout(acc6[14]));
  logic [14:0] acc7;
  // merge adder 7
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u16 (.a(acc6[13:0]), .b(t_sp21), .cin(1'b0), .s(acc7[13:0]), .cout(acc7[14]));
  logic [14:0] acc8;
  // merge adder 8
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u17 (.a(acc7[13:0]), .b(t_sp22), .cin(1'b0), .s(acc8[13:0]), .cout(acc8[14]));
  logic [13:0] full; assign full = acc8[13:0];
  assign p = full[9:0];
endmodule






































// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// segmented_grid (square, depth 2): 3 x 3 segment products of 2 x 2 bits (direct_pp_parallel) merged by cpa (merge adder sparse_prefix_hybrid)
module fam_mul_segmented_grid_w16_s_p507511d0_g33 (input logic [4:0] a, input logic [4:0] b, output logic [9:0] p);
  logic [5:0] ae; assign ae = {{(6-5){a[4]}}, a};
  logic [5:0] be; assign be = {{(6-5){b[4]}}, b};
  logic [1:0] sa00; assign sa00 = ae[1:0];
  logic [1:0] sb00; assign sb00 = be[1:0];
  logic [3:0] sp00;
  // segment product (0, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [1:0] sa01; assign sa01 = ae[1:0];
  logic [1:0] sb01; assign sb01 = be[3:2];
  logic [3:0] sp01;
  // segment product (0, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u2 (.a(sa01), .b(sb01), .p(sp01));
  logic [2:0] sa02; assign sa02 = {{1{1'b0}}, ae[1:0]};
  logic [2:0] sb02; assign sb02 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp02;
  // segment product (0, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u3 (.a(sa02), .b(sb02), .p(sp02));
  logic [1:0] sa10; assign sa10 = ae[3:2];
  logic [1:0] sb10; assign sb10 = be[1:0];
  logic [3:0] sp10;
  // segment product (1, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u4 (.a(sa10), .b(sb10), .p(sp10));
  logic [1:0] sa11; assign sa11 = ae[3:2];
  logic [1:0] sb11; assign sb11 = be[3:2];
  logic [3:0] sp11;
  // segment product (1, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w2_u_p8ed37fd2 u5 (.a(sa11), .b(sb11), .p(sp11));
  logic [2:0] sa12; assign sa12 = {{1{1'b0}}, ae[3:2]};
  logic [2:0] sb12; assign sb12 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp12;
  // segment product (1, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u6 (.a(sa12), .b(sb12), .p(sp12));
  logic [2:0] sa20; assign sa20 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb20; assign sb20 = {{1{1'b0}}, be[1:0]};
  logic [5:0] sp20;
  // segment product (2, 0) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u7 (.a(sa20), .b(sb20), .p(sp20));
  logic [2:0] sa21; assign sa21 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb21; assign sb21 = {{1{1'b0}}, be[3:2]};
  logic [5:0] sp21;
  // segment product (2, 1) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u8 (.a(sa21), .b(sb21), .p(sp21));
  logic [2:0] sa22; assign sa22 = {{1{ae[5]}}, ae[5:4]};
  logic [2:0] sb22; assign sb22 = {{1{be[5]}}, be[5:4]};
  logic [5:0] sp22;
  // segment product (2, 2) (direct_pp_parallel)
  fam_mul_direct_balanced_delay_5_2_w3_s_p8ed37fd2 u9 (.a(sa22), .b(sb22), .p(sp22));
  logic [13:0] t_sp00; assign t_sp00 = {{(14-4){1'b0}}, sp00} << 0;
  logic [13:0] t_sp01; assign t_sp01 = {{(14-4){1'b0}}, sp01} << 2;
  logic [13:0] t_sp02; assign t_sp02 = $signed({{(14-6){sp02[5]}}, sp02}) <<< 4;
  logic [13:0] t_sp10; assign t_sp10 = {{(14-4){1'b0}}, sp10} << 2;
  logic [13:0] t_sp11; assign t_sp11 = {{(14-4){1'b0}}, sp11} << 4;
  logic [13:0] t_sp12; assign t_sp12 = $signed({{(14-6){sp12[5]}}, sp12}) <<< 6;
  logic [13:0] t_sp20; assign t_sp20 = $signed({{(14-6){sp20[5]}}, sp20}) <<< 4;
  logic [13:0] t_sp21; assign t_sp21 = $signed({{(14-6){sp21[5]}}, sp21}) <<< 6;
  logic [13:0] t_sp22; assign t_sp22 = $signed({{(14-6){sp22[5]}}, sp22}) <<< 8;
  logic [14:0] acc1;
  // merge adder 1
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u10 (.a(t_sp00), .b(t_sp01), .cin(1'b0), .s(acc1[13:0]), .cout(acc1[14]));
  logic [14:0] acc2;
  // merge adder 2
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u11 (.a(acc1[13:0]), .b(t_sp02), .cin(1'b0), .s(acc2[13:0]), .cout(acc2[14]));
  logic [14:0] acc3;
  // merge adder 3
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u12 (.a(acc2[13:0]), .b(t_sp10), .cin(1'b0), .s(acc3[13:0]), .cout(acc3[14]));
  logic [14:0] acc4;
  // merge adder 4
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u13 (.a(acc3[13:0]), .b(t_sp11), .cin(1'b0), .s(acc4[13:0]), .cout(acc4[14]));
  logic [14:0] acc5;
  // merge adder 5
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u14 (.a(acc4[13:0]), .b(t_sp12), .cin(1'b0), .s(acc5[13:0]), .cout(acc5[14]));
  logic [14:0] acc6;
  // merge adder 6
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u15 (.a(acc5[13:0]), .b(t_sp20), .cin(1'b0), .s(acc6[13:0]), .cout(acc6[14]));
  logic [14:0] acc7;
  // merge adder 7
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u16 (.a(acc6[13:0]), .b(t_sp21), .cin(1'b0), .s(acc7[13:0]), .cout(acc7[14]));
  logic [14:0] acc8;
  // merge adder 8
  fam_adder_sparse_prefix_hybrid_p491cd7846ddf8a744c405d1237a341cc707f59cb11ee2d4278ddd7b6978a3f7c_w14 u17 (.a(acc7[13:0]), .b(t_sp22), .cin(1'b0), .s(acc8[13:0]), .cout(acc8[14]));
  logic [13:0] full; assign full = acc8[13:0];
  assign p = full[9:0];
endmodule

// squarer (divide_and_conquer): the product from two folded squarers by the quarter-square identity 4ab = (a+b)^2 - (a-b)^2 (a squarer alone serves x^2); the sum, the difference and the final subtraction through the pre_adder slot (manchester_carry_chain)
module fam_mul_squarer_w16_u_pef720af1 (input logic [15:0] a, input logic [15:0] b, output logic [31:0] p);
  logic [17:0] ae; assign ae = {2'b0, a};
  logic [17:0] be; assign be = {2'b0, b};
  logic [18:0] sa;
  // a + b (the sign bit's carry unused)
  fam_adder_manchester_carry_chain #(.W(18), .SEG(2), .VARSKIP(1)) u1 (.a(ae), .b(be), .cin(1'b0), .s(sa[17:0]), .cout(sa[18]));
  logic [18:0] da;
  logic [17:0] da_nb; assign da_nb = ~be;
  // a - b
  fam_adder_manchester_carry_chain #(.W(18), .SEG(2), .VARSKIP(1)) u2 (.a(ae), .b(da_nb), .cin(1'b1), .s(da[17:0]), .cout(da[18]));
  logic [35:0] s2;
  logic [35:0] d2;
  fam_mul_squarer_w16_u_pef720af1_sq u_s (.x(sa[17:0]), .p(s2));
  fam_mul_squarer_w16_u_pef720af1_sq u_d (.x(da[17:0]), .p(d2));
  logic [36:0] diff;
  logic [35:0] diff_nb; assign diff_nb = ~d2;
  // (a+b)^2 - (a-b)^2
  fam_adder_manchester_carry_chain #(.W(36), .SEG(2), .VARSKIP(1)) u3 (.a(s2), .b(diff_nb), .cin(1'b1), .s(diff[35:0]), .cout(diff[36]));
  assign p = diff[33:2];
endmodule


module fam_mul_squarer_w16_u_pef720af1_sq (input logic [17:0] x, output logic [35:0] p);
  // squarer (divide_and_conquer, two's complement x): 0 full adders, 1 half adders, depth 17
  logic sq0, sq1, sq2, sq3, sq4, sq5, sq6, sq7, sq8, sq9, sq10, sq11, sq12, sq13, sq14, sq15, sq16, sq17, sq18, sq19, sq20, sq21, sq22, sq23, sq24, sq25, sq26, sq27, sq28, sq29, sq30, sq31, sq32, sq33, sq34, sq35, sq36, sq37, sq38, sq39, sq40, sq41, sq42, sq43, sq44, sq45, sq46, sq47, sq48, sq49, sq50, sq51, sq52, sq53, sq54, sq55, sq56, sq57, sq58, sq59, sq60, sq61, sq62, sq63, sq64, sq65, sq66, sq67, sq68, sq69, sq70, sq71, sq72, t73, t74;
  logic [8:0] xl_x;
  logic [8:0] xh_x;
  logic [19:0] xp_x;
  // the cross product of the halves (booth_recoded_parallel)
  fam_mul_booth8_dadda_3_2_w10_s_p284dba6b u_cross_x (.a({{1{1'b0}}, xl_x}), .b({{1{xh_x[8]}}, xh_x}), .p(xp_x));
  logic [3:0] ts1; logic tc1;
  // tile 1 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i1 (.a({sq1, sq0, 1'b0, xl_x[0]}), .b({1'b0, xl_x[1], 1'b0, 1'b0}), .cin(1'b0), .s(ts1), .cout(tc1));
  logic [3:0] ts2; logic tc2;
  // tile 2 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i2 (.a({sq5, sq4, sq3, sq2}), .b({sq11, sq10, sq9, sq8}), .cin(1'b0), .s(ts2), .cout(tc2));
  logic [3:0] ts3; logic tc3;
  // tile 3 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i3 (.a({sq20, sq14, sq7, sq6}), .b({sq24, sq19, sq13, sq12}), .cin(1'b0), .s(ts3), .cout(tc3));
  logic [3:0] ts4; logic tc4;
  // tile 4 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i4 (.a({sq34, sq32, sq29, sq25}), .b({xp_x[5], sq33, sq31, sq28}), .cin(1'b0), .s(ts4), .cout(tc4));
  logic [3:0] ts5; logic tc5;
  // tile 5 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i5 (.a({xp_x[9], xh_x[0], xp_x[7], sq35}), .b({1'b0, xp_x[8], 1'b0, xl_x[8]}), .cin(1'b0), .s(ts5), .cout(tc5));
  logic [3:0] ts6; logic tc6;
  // tile 6 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i6 (.a({sq39, sq38, sq37, sq36}), .b({sq45, sq44, xp_x[11], xh_x[1]}), .cin(1'b0), .s(ts6), .cout(tc6));
  logic [3:0] ts7; logic tc7;
  // tile 7 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i7 (.a({sq43, sq42, sq41, sq40}), .b({sq49, sq48, sq47, sq46}), .cin(1'b0), .s(ts7), .cout(tc7));
  logic [3:0] ts8; logic tc8;
  // tile 8 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i8 (.a({sq65, sq61, sq56, sq50}), .b({sq67, sq64, sq60, sq55}), .cin(1'b0), .s(ts8), .cout(tc8));
  logic [3:0] ts9; logic tc9;
  // tile 9 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i9 (.a({1'b1, sq71, sq70, sq68}), .b({1'b1, xh_x[8], 1'b1, sq69}), .cin(1'b0), .s(ts9), .cout(tc9));
  logic [3:0] ts10; logic tc10;
  // tile 10 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i10 (.a({sq16, sq15, 1'b0, xl_x[2]}), .b({1'b0, xl_x[3], 1'b0, 1'b0}), .cin(1'b0), .s(ts10), .cout(tc10));
  logic [3:0] ts11; logic tc11;
  // tile 11 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i11 (.a({sq27, sq23, sq18, sq17}), .b({xp_x[1], sq26, sq22, sq21}), .cin(1'b0), .s(ts11), .cout(tc11));
  logic [3:0] ts12; logic tc12;
  // tile 12 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i12 (.a({1'b0, xl_x[7], xp_x[3], sq30}), .b({1'b0, xp_x[4], 1'b0, xl_x[6]}), .cin(1'b0), .s(ts12), .cout(tc12));
  logic [3:0] ts13; logic tc13;
  // tile 13 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i13 (.a({xp_x[13], xh_x[2], 1'b0, xp_x[10]}), .b({1'b0, xp_x[12], 1'b0, 1'b0}), .cin(1'b0), .s(ts13), .cout(tc13));
  logic [3:0] ts14; logic tc14;
  // tile 14 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i14 (.a({sq54, sq53, sq52, sq51}), .b({sq58, sq57, xp_x[15], xh_x[3]}), .cin(1'b0), .s(ts14), .cout(tc14));
  logic [3:0] ts15; logic tc15;
  // tile 15 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i15 (.a({1'b1, sq66, sq63, sq59}), .b({1'b0, xh_x[6], sq72, sq62}), .cin(1'b0), .s(ts15), .cout(tc15));
  logic [3:0] ts16; logic tc16;
  // tile 16 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i16 (.a({1'b0, 1'b1, 1'b0, xh_x[7]}), .b({1'b0, 1'b0, 1'b0, 1'b1}), .cin(1'b0), .s(ts16), .cout(tc16));
  logic [3:0] ts17; logic tc17;
  // tile 17 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i17 (.a({1'b0, xl_x[5], 1'b0, xl_x[4]}), .b({1'b0, xp_x[0], 1'b0, 1'b0}), .cin(1'b0), .s(ts17), .cout(tc17));
  logic [3:0] ts18; logic tc18;
  // tile 18 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i18 (.a({1'b1, xh_x[4], 1'b0, xp_x[14]}), .b({xp_x[17], xp_x[16], 1'b0, 1'b0}), .cin(1'b0), .s(ts18), .cout(tc18));
  logic [3:0] ts19; logic tc19;
  // tile 19 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_2_1_1_0_w4 u_i19 (.a({1'b0, 1'b1, 1'b1, xh_x[5]}), .b({1'b0, 1'b0, 1'b0, xp_x[18]}), .cin(1'b0), .s(ts19), .cout(tc19));
  logic [3:0] ts20; logic tc20;
  // tile 20 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 1
  fam_prefix_arrival_2_1_1_0_w4 u_i20 (.a({ts2[1], ts2[0], ts1[3], ts1[2]}), .b({ts10[1], ts10[0], 1'b0, 1'b0}), .cin(1'b0), .s(ts20), .cout(tc20));
  logic [3:0] ts21; logic tc21;
  // tile 21 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 1
  fam_prefix_arrival_2_1_1_0_w4 u_i21 (.a({ts3[1], ts3[0], ts2[3], ts2[2]}), .b({ts11[1], ts11[0], ts10[3], ts10[2]}), .cin(1'b0), .s(ts21), .cout(tc21));
  logic [3:0] ts22; logic tc22;
  // tile 22 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 1
  fam_prefix_arrival_2_1_1_0_w4 u_i22 (.a({ts4[1], ts4[0], ts3[3], ts3[2]}), .b({ts12[1], ts12[0], ts11[3], ts11[2]}), .cin(1'b0), .s(ts22), .cout(tc22));
  logic [3:0] ts23; logic tc23;
  // tile 23 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 1
  fam_prefix_arrival_2_1_1_0_w4 u_i23 (.a({ts5[1], ts5[0], ts4[3], ts4[2]}), .b({1'b0, xp_x[6], ts12[3], ts12[2]}), .cin(1'b0), .s(ts23), .cout(tc23));
  logic [3:0] ts24; logic tc24;
  // tile 24 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 1
  fam_prefix_arrival_2_1_1_0_w4 u_i24 (.a({ts6[1], ts6[0], ts5[3], ts5[2]}), .b({ts13[1], ts13[0], 1'b0, 1'b0}), .cin(1'b0), .s(ts24), .cout(tc24));
  logic [3:0] ts25; logic tc25;
  // tile 25 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 1
  fam_prefix_arrival_2_1_1_0_w4 u_i25 (.a({ts7[1], ts7[0], ts6[3], ts6[2]}), .b({ts14[1], ts14[0], ts13[3], ts13[2]}), .cin(1'b0), .s(ts25), .cout(tc25));
  logic [3:0] ts26; logic tc26;
  // tile 26 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 1
  fam_prefix_arrival_2_1_1_0_w4 u_i26 (.a({ts8[1], ts8[0], ts7[3], ts7[2]}), .b({ts15[1], ts15[0], ts14[3], ts14[2]}), .cin(1'b0), .s(ts26), .cout(tc26));
  logic [3:0] ts27; logic tc27;
  // tile 27 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 1
  fam_prefix_arrival_2_1_1_0_w4 u_i27 (.a({ts9[1], ts9[0], ts8[3], ts8[2]}), .b({ts16[1], ts16[0], ts15[3], ts15[2]}), .cin(1'b0), .s(ts27), .cout(tc27));
  logic [1:0] ts28; logic tc28;
  // tile 28 (prefix_synthesis_nonuniform_arrival, 2 bits) at level 1
  fam_prefix_arrival_1_0_w2 u_i28 (.a({ts9[3], ts9[2]}), .b({ts16[3], ts16[2]}), .cin(1'b0), .s(ts28), .cout(tc28));
  logic [3:0] ts29; logic tc29;
  // tile 29 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 1
  fam_prefix_arrival_2_1_1_0_w4 u_i29 (.a({ts17[1], ts17[0], 1'b0, 1'b0}), .b({1'b0, tc2, 1'b0, 1'b0}), .cin(1'b0), .s(ts29), .cout(tc29));
  logic [3:0] ts30; logic tc30;
  // tile 30 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 1
  fam_prefix_arrival_2_1_1_0_w4 u_i30 (.a({1'b0, xp_x[2], ts17[3], ts17[2]}), .b({1'b0, tc3, 1'b0, 1'b0}), .cin(1'b0), .s(ts30), .cout(tc30));
  logic [3:0] ts31; logic tc31;
  // tile 31 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 1
  fam_prefix_arrival_2_1_1_0_w4 u_i31 (.a({ts18[1], ts18[0], 1'b0, 1'b0}), .b({1'b0, tc6, 1'b0, 1'b0}), .cin(1'b0), .s(ts31), .cout(tc31));
  logic [3:0] ts32; logic tc32;
  // tile 32 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 1
  fam_prefix_arrival_2_1_1_0_w4 u_i32 (.a({ts19[1], ts19[0], ts18[3], ts18[2]}), .b({1'b0, tc7, 1'b0, 1'b0}), .cin(1'b0), .s(ts32), .cout(tc32));
  logic [3:0] ts33; logic tc33;
  // tile 33 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 1
  fam_prefix_arrival_2_1_1_0_w4 u_i33 (.a({1'b0, 1'b0, ts19[3], ts19[2]}), .b({1'b0, tc8, 1'b0, 1'b0}), .cin(1'b0), .s(ts33), .cout(tc33));
  logic [3:0] ts34; logic tc34;
  // tile 34 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 1
  fam_prefix_arrival_2_1_1_0_w4 u_i34 (.a({1'b0, tc11, 1'b0, 1'b0}), .b({1'b0, tc17, 1'b0, 1'b0}), .cin(1'b0), .s(ts34), .cout(tc34));
  logic [3:0] ts35; logic tc35;
  // tile 35 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 1
  fam_prefix_arrival_2_1_1_0_w4 u_i35 (.a({1'b0, tc14, 1'b0, 1'b0}), .b({1'b0, tc18, 1'b0, 1'b0}), .cin(1'b0), .s(ts35), .cout(tc35));
  logic [3:0] ts36; logic tc36;
  // tile 36 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 1
  fam_prefix_arrival_2_1_1_0_w4 u_i36 (.a({1'b0, tc15, 1'b0, 1'b0}), .b({1'b0, tc19, 1'b0, 1'b0}), .cin(1'b0), .s(ts36), .cout(tc36));
  logic [3:0] ts37; logic tc37;
  // tile 37 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_2_1_1_0_w4 u_i37 (.a({ts21[1], ts21[0], ts20[3], ts20[2]}), .b({ts29[1], ts29[0], 1'b0, tc1}), .cin(1'b0), .s(ts37), .cout(tc37));
  logic [3:0] ts38; logic tc38;
  // tile 38 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_2_1_1_0_w4 u_i38 (.a({ts22[1], ts22[0], ts21[3], ts21[2]}), .b({ts30[1], ts30[0], ts29[3], ts29[2]}), .cin(1'b0), .s(ts38), .cout(tc38));
  logic [3:0] ts39; logic tc39;
  // tile 39 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_2_1_1_0_w4 u_i39 (.a({ts23[1], ts23[0], ts22[3], ts22[2]}), .b({1'b0, 1'b0, ts30[3], ts30[2]}), .cin(1'b0), .s(ts39), .cout(tc39));
  logic [3:0] ts40; logic tc40;
  // tile 40 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_2_1_1_0_w4 u_i40 (.a({ts24[1], ts24[0], ts23[3], ts23[2]}), .b({1'b0, 1'b0, 1'b0, tc4}), .cin(1'b0), .s(ts40), .cout(tc40));
  logic [3:0] ts41; logic tc41;
  // tile 41 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_2_1_1_0_w4 u_i41 (.a({ts25[1], ts25[0], ts24[3], ts24[2]}), .b({ts31[1], ts31[0], 1'b0, tc5}), .cin(1'b0), .s(ts41), .cout(tc41));
  logic [3:0] ts42; logic tc42;
  // tile 42 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_2_1_1_0_w4 u_i42 (.a({ts26[1], ts26[0], ts25[3], ts25[2]}), .b({ts32[1], ts32[0], ts31[3], ts31[2]}), .cin(1'b0), .s(ts42), .cout(tc42));
  logic [3:0] ts43; logic tc43;
  // tile 43 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_2_1_1_0_w4 u_i43 (.a({ts27[1], ts27[0], ts26[3], ts26[2]}), .b({ts33[1], ts33[0], ts32[3], ts32[2]}), .cin(1'b0), .s(ts43), .cout(tc43));
  logic [3:0] ts44; logic tc44;
  // tile 44 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_2_1_1_0_w4 u_i44 (.a({ts28[1], ts28[0], ts27[3], ts27[2]}), .b({1'b0, 1'b0, ts33[3], ts33[2]}), .cin(1'b0), .s(ts44), .cout(tc44));
  logic [3:0] ts45; logic tc45;
  // tile 45 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_2_1_1_0_w4 u_i45 (.a({ts34[1], ts34[0], 1'b0, tc10}), .b({1'b0, tc21, 1'b0, 1'b0}), .cin(1'b0), .s(ts45), .cout(tc45));
  logic [3:0] ts46; logic tc46;
  // tile 46 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_2_1_1_0_w4 u_i46 (.a({1'b0, 1'b0, ts34[3], ts34[2]}), .b({1'b0, tc22, 1'b0, 1'b0}), .cin(1'b0), .s(ts46), .cout(tc46));
  logic [3:0] ts47; logic tc47;
  // tile 47 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_2_1_1_0_w4 u_i47 (.a({1'b0, 1'b0, 1'b0, tc12}), .b({1'b0, tc23, 1'b0, 1'b0}), .cin(1'b0), .s(ts47), .cout(tc47));
  logic [3:0] ts48; logic tc48;
  // tile 48 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_2_1_1_0_w4 u_i48 (.a({ts35[1], ts35[0], 1'b0, tc13}), .b({1'b0, tc25, 1'b0, 1'b0}), .cin(1'b0), .s(ts48), .cout(tc48));
  logic [3:0] ts49; logic tc49;
  // tile 49 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_2_1_1_0_w4 u_i49 (.a({ts36[1], ts36[0], ts35[3], ts35[2]}), .b({1'b0, tc26, 1'b0, 1'b0}), .cin(1'b0), .s(ts49), .cout(tc49));
  logic [3:0] ts50; logic tc50;
  // tile 50 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_2_1_1_0_w4 u_i50 (.a({1'b0, 1'b0, ts36[3], ts36[2]}), .b({1'b0, tc27, 1'b0, 1'b0}), .cin(1'b0), .s(ts50), .cout(tc50));
  logic [3:0] ts51; logic tc51;
  // tile 51 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_2_1_1_0_w4 u_i51 (.a({1'b0, tc30, 1'b0, 1'b0}), .b({1'b0, tc34, 1'b0, 1'b0}), .cin(1'b0), .s(ts51), .cout(tc51));
  logic [3:0] ts52; logic tc52;
  // tile 52 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_2_1_1_0_w4 u_i52 (.a({1'b0, tc32, 1'b0, 1'b0}), .b({1'b0, tc35, 1'b0, 1'b0}), .cin(1'b0), .s(ts52), .cout(tc52));
  logic [3:0] ts53; logic tc53;
  // tile 53 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_2_1_1_0_w4 u_i53 (.a({1'b0, tc33, 1'b0, 1'b0}), .b({1'b0, tc36, 1'b0, 1'b0}), .cin(1'b0), .s(ts53), .cout(tc53));
  logic [3:0] ts54; logic tc54;
  // tile 54 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 3
  fam_prefix_arrival_2_1_1_0_w4 u_i54 (.a({ts38[1], ts38[0], ts37[3], ts37[2]}), .b({ts45[1], ts45[0], 1'b0, tc20}), .cin(1'b0), .s(ts54), .cout(tc54));
  logic [3:0] ts55; logic tc55;
  // tile 55 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 3
  fam_prefix_arrival_2_1_1_0_w4 u_i55 (.a({ts39[1], ts39[0], ts38[3], ts38[2]}), .b({ts46[1], ts46[0], ts45[3], ts45[2]}), .cin(1'b0), .s(ts55), .cout(tc55));
  logic [3:0] ts56; logic tc56;
  // tile 56 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 3
  fam_prefix_arrival_2_1_1_0_w4 u_i56 (.a({ts40[1], ts40[0], ts39[3], ts39[2]}), .b({ts47[1], ts47[0], ts46[3], ts46[2]}), .cin(1'b0), .s(ts56), .cout(tc56));
  logic [3:0] ts57; logic tc57;
  // tile 57 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 3
  fam_prefix_arrival_2_1_1_0_w4 u_i57 (.a({ts41[1], ts41[0], ts40[3], ts40[2]}), .b({1'b0, 1'b0, ts47[3], ts47[2]}), .cin(1'b0), .s(ts57), .cout(tc57));
  logic [3:0] ts58; logic tc58;
  // tile 58 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 3
  fam_prefix_arrival_2_1_1_0_w4 u_i58 (.a({ts42[1], ts42[0], ts41[3], ts41[2]}), .b({ts48[1], ts48[0], 1'b0, tc24}), .cin(1'b0), .s(ts58), .cout(tc58));
  logic [3:0] ts59; logic tc59;
  // tile 59 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 3
  fam_prefix_arrival_2_1_1_0_w4 u_i59 (.a({ts43[1], ts43[0], ts42[3], ts42[2]}), .b({ts49[1], ts49[0], ts48[3], ts48[2]}), .cin(1'b0), .s(ts59), .cout(tc59));
  logic [3:0] ts60; logic tc60;
  // tile 60 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 3
  fam_prefix_arrival_2_1_1_0_w4 u_i60 (.a({ts44[1], ts44[0], ts43[3], ts43[2]}), .b({ts50[1], ts50[0], ts49[3], ts49[2]}), .cin(1'b0), .s(ts60), .cout(tc60));
  logic [1:0] ts61; logic tc61;
  // tile 61 (prefix_synthesis_nonuniform_arrival, 2 bits) at level 3
  fam_prefix_arrival_1_0_w2 u_i61 (.a({ts44[3], ts44[2]}), .b({ts50[3], ts50[2]}), .cin(1'b0), .s(ts61), .cout(tc61));
  logic [3:0] ts62; logic tc62;
  // tile 62 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 3
  fam_prefix_arrival_2_1_1_0_w4 u_i62 (.a({ts51[1], ts51[0], 1'b0, tc29}), .b({1'b0, tc38, 1'b0, 1'b0}), .cin(1'b0), .s(ts62), .cout(tc62));
  logic [3:0] ts63; logic tc63;
  // tile 63 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 3
  fam_prefix_arrival_2_1_1_0_w4 u_i63 (.a({1'b0, 1'b0, ts51[3], ts51[2]}), .b({1'b0, tc39, 1'b0, 1'b0}), .cin(1'b0), .s(ts63), .cout(tc63));
  logic [3:0] ts64; logic tc64;
  // tile 64 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 3
  fam_prefix_arrival_2_1_1_0_w4 u_i64 (.a({ts52[1], ts52[0], 1'b0, tc31}), .b({1'b0, tc42, 1'b0, 1'b0}), .cin(1'b0), .s(ts64), .cout(tc64));
  logic [3:0] ts65; logic tc65;
  // tile 65 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 3
  fam_prefix_arrival_2_1_1_0_w4 u_i65 (.a({ts53[1], ts53[0], ts52[3], ts52[2]}), .b({1'b0, tc43, 1'b0, 1'b0}), .cin(1'b0), .s(ts65), .cout(tc65));
  logic [3:0] ts66; logic tc66;
  // tile 66 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 3
  fam_prefix_arrival_2_1_1_0_w4 u_i66 (.a({1'b0, tc46, 1'b0, 1'b0}), .b({1'b0, tc51, 1'b0, 1'b0}), .cin(1'b0), .s(ts66), .cout(tc66));
  logic [3:0] ts67; logic tc67;
  // tile 67 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 3
  fam_prefix_arrival_2_1_1_0_w4 u_i67 (.a({1'b0, tc49, 1'b0, 1'b0}), .b({1'b0, tc52, 1'b0, 1'b0}), .cin(1'b0), .s(ts67), .cout(tc67));
  logic [3:0] ts68; logic tc68;
  // tile 68 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 4
  fam_prefix_arrival_2_1_1_0_w4 u_i68 (.a({ts55[1], ts55[0], ts54[3], ts54[2]}), .b({ts62[1], ts62[0], 1'b0, tc37}), .cin(1'b0), .s(ts68), .cout(tc68));
  logic [3:0] ts69; logic tc69;
  // tile 69 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 4
  fam_prefix_arrival_2_1_1_0_w4 u_i69 (.a({ts56[1], ts56[0], ts55[3], ts55[2]}), .b({ts63[1], ts63[0], ts62[3], ts62[2]}), .cin(1'b0), .s(ts69), .cout(tc69));
  logic [3:0] ts70; logic tc70;
  // tile 70 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 4
  fam_prefix_arrival_2_1_1_0_w4 u_i70 (.a({ts57[1], ts57[0], ts56[3], ts56[2]}), .b({1'b0, 1'b0, ts63[3], ts63[2]}), .cin(1'b0), .s(ts70), .cout(tc70));
  logic [3:0] ts71; logic tc71;
  // tile 71 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 4
  fam_prefix_arrival_2_1_1_0_w4 u_i71 (.a({ts58[1], ts58[0], ts57[3], ts57[2]}), .b({1'b0, 1'b0, 1'b0, tc40}), .cin(1'b0), .s(ts71), .cout(tc71));
  logic [3:0] ts72; logic tc72;
  // tile 72 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 4
  fam_prefix_arrival_2_1_1_0_w4 u_i72 (.a({ts59[1], ts59[0], ts58[3], ts58[2]}), .b({ts64[1], ts64[0], 1'b0, tc41}), .cin(1'b0), .s(ts72), .cout(tc72));
  logic [3:0] ts73; logic tc73;
  // tile 73 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 4
  fam_prefix_arrival_2_1_1_0_w4 u_i73 (.a({ts60[1], ts60[0], ts59[3], ts59[2]}), .b({ts65[1], ts65[0], ts64[3], ts64[2]}), .cin(1'b0), .s(ts73), .cout(tc73));
  logic [3:0] ts74; logic tc74;
  // tile 74 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 4
  fam_prefix_arrival_2_1_1_0_w4 u_i74 (.a({ts61[1], ts61[0], ts60[3], ts60[2]}), .b({ts53[3], ts53[2], ts65[3], ts65[2]}), .cin(1'b0), .s(ts74), .cout(tc74));
  logic [3:0] ts75; logic tc75;
  // tile 75 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 4
  fam_prefix_arrival_2_1_1_0_w4 u_i75 (.a({ts66[1], ts66[0], 1'b0, tc45}), .b({1'b0, tc55, 1'b0, 1'b0}), .cin(1'b0), .s(ts75), .cout(tc75));
  logic [3:0] ts76; logic tc76;
  // tile 76 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 4
  fam_prefix_arrival_2_1_1_0_w4 u_i76 (.a({1'b0, 1'b0, ts66[3], ts66[2]}), .b({1'b0, tc56, 1'b0, 1'b0}), .cin(1'b0), .s(ts76), .cout(tc76));
  logic [3:0] ts77; logic tc77;
  // tile 77 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 4
  fam_prefix_arrival_2_1_1_0_w4 u_i77 (.a({1'b0, 1'b0, 1'b0, tc47}), .b({1'b0, tc57, 1'b0, 1'b0}), .cin(1'b0), .s(ts77), .cout(tc77));
  logic [3:0] ts78; logic tc78;
  // tile 78 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 4
  fam_prefix_arrival_2_1_1_0_w4 u_i78 (.a({ts67[1], ts67[0], 1'b0, tc48}), .b({1'b0, tc59, 1'b0, 1'b0}), .cin(1'b0), .s(ts78), .cout(tc78));
  logic [3:0] ts79; logic tc79;
  // tile 79 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 4
  fam_prefix_arrival_2_1_1_0_w4 u_i79 (.a({1'b0, 1'b0, ts67[3], ts67[2]}), .b({1'b0, tc60, 1'b0, 1'b0}), .cin(1'b0), .s(ts79), .cout(tc79));
  logic [3:0] ts80; logic tc80;
  // tile 80 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 4
  fam_prefix_arrival_2_1_1_0_w4 u_i80 (.a({1'b0, tc63, 1'b0, 1'b0}), .b({1'b0, tc66, 1'b0, 1'b0}), .cin(1'b0), .s(ts80), .cout(tc80));
  logic [3:0] ts81; logic tc81;
  // tile 81 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 4
  fam_prefix_arrival_2_1_1_0_w4 u_i81 (.a({1'b0, tc65, 1'b0, 1'b0}), .b({1'b0, tc67, 1'b0, 1'b0}), .cin(1'b0), .s(ts81), .cout(tc81));
  logic [3:0] ts82; logic tc82;
  // tile 82 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 5
  fam_prefix_arrival_2_1_1_0_w4 u_i82 (.a({ts69[1], ts69[0], ts68[3], ts68[2]}), .b({ts75[1], ts75[0], 1'b0, tc54}), .cin(1'b0), .s(ts82), .cout(tc82));
  logic [3:0] ts83; logic tc83;
  // tile 83 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 5
  fam_prefix_arrival_2_1_1_0_w4 u_i83 (.a({ts70[1], ts70[0], ts69[3], ts69[2]}), .b({ts76[1], ts76[0], ts75[3], ts75[2]}), .cin(1'b0), .s(ts83), .cout(tc83));
  logic [3:0] ts84; logic tc84;
  // tile 84 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 5
  fam_prefix_arrival_2_1_1_0_w4 u_i84 (.a({ts71[1], ts71[0], ts70[3], ts70[2]}), .b({ts77[1], ts77[0], ts76[3], ts76[2]}), .cin(1'b0), .s(ts84), .cout(tc84));
  logic [3:0] ts85; logic tc85;
  // tile 85 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 5
  fam_prefix_arrival_2_1_1_0_w4 u_i85 (.a({ts72[1], ts72[0], ts71[3], ts71[2]}), .b({1'b0, 1'b0, ts77[3], ts77[2]}), .cin(1'b0), .s(ts85), .cout(tc85));
  logic [3:0] ts86; logic tc86;
  // tile 86 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 5
  fam_prefix_arrival_2_1_1_0_w4 u_i86 (.a({ts73[1], ts73[0], ts72[3], ts72[2]}), .b({ts78[1], ts78[0], 1'b0, tc58}), .cin(1'b0), .s(ts86), .cout(tc86));
  logic [3:0] ts87; logic tc87;
  // tile 87 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 5
  fam_prefix_arrival_2_1_1_0_w4 u_i87 (.a({ts74[1], ts74[0], ts73[3], ts73[2]}), .b({ts79[1], ts79[0], ts78[3], ts78[2]}), .cin(1'b0), .s(ts87), .cout(tc87));
  logic [1:0] ts88; logic tc88;
  // tile 88 (prefix_synthesis_nonuniform_arrival, 2 bits) at level 5
  fam_prefix_arrival_1_0_w2 u_i88 (.a({ts74[3], ts74[2]}), .b({ts79[3], ts79[2]}), .cin(1'b0), .s(ts88), .cout(tc88));
  logic [3:0] ts89; logic tc89;
  // tile 89 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 5
  fam_prefix_arrival_2_1_1_0_w4 u_i89 (.a({ts80[1], ts80[0], 1'b0, tc62}), .b({1'b0, tc69, 1'b0, 1'b0}), .cin(1'b0), .s(ts89), .cout(tc89));
  logic [3:0] ts90; logic tc90;
  // tile 90 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 5
  fam_prefix_arrival_2_1_1_0_w4 u_i90 (.a({1'b0, 1'b0, ts80[3], ts80[2]}), .b({1'b0, tc70, 1'b0, 1'b0}), .cin(1'b0), .s(ts90), .cout(tc90));
  logic [3:0] ts91; logic tc91;
  // tile 91 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 5
  fam_prefix_arrival_2_1_1_0_w4 u_i91 (.a({ts81[1], ts81[0], 1'b0, tc64}), .b({1'b0, tc73, 1'b0, 1'b0}), .cin(1'b0), .s(ts91), .cout(tc91));
  logic [3:0] ts92; logic tc92;
  // tile 92 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 5
  fam_prefix_arrival_2_1_1_0_w4 u_i92 (.a({1'b0, tc76, 1'b0, 1'b0}), .b({1'b0, tc80, 1'b0, 1'b0}), .cin(1'b0), .s(ts92), .cout(tc92));
  logic [3:0] ts93; logic tc93;
  // tile 93 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 6
  fam_prefix_arrival_2_1_1_0_w4 u_i93 (.a({ts83[1], ts83[0], ts82[3], ts82[2]}), .b({ts89[1], ts89[0], 1'b0, tc68}), .cin(1'b0), .s(ts93), .cout(tc93));
  logic [3:0] ts94; logic tc94;
  // tile 94 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 6
  fam_prefix_arrival_2_1_1_0_w4 u_i94 (.a({ts84[1], ts84[0], ts83[3], ts83[2]}), .b({ts90[1], ts90[0], ts89[3], ts89[2]}), .cin(1'b0), .s(ts94), .cout(tc94));
  logic [3:0] ts95; logic tc95;
  // tile 95 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 6
  fam_prefix_arrival_2_1_1_0_w4 u_i95 (.a({ts85[1], ts85[0], ts84[3], ts84[2]}), .b({1'b0, 1'b0, ts90[3], ts90[2]}), .cin(1'b0), .s(ts95), .cout(tc95));
  logic [3:0] ts96; logic tc96;
  // tile 96 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 6
  fam_prefix_arrival_2_1_1_0_w4 u_i96 (.a({ts86[1], ts86[0], ts85[3], ts85[2]}), .b({1'b0, 1'b0, 1'b0, tc71}), .cin(1'b0), .s(ts96), .cout(tc96));
  logic [3:0] ts97; logic tc97;
  // tile 97 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 6
  fam_prefix_arrival_2_1_1_0_w4 u_i97 (.a({ts87[1], ts87[0], ts86[3], ts86[2]}), .b({ts91[1], ts91[0], 1'b0, tc72}), .cin(1'b0), .s(ts97), .cout(tc97));
  logic [3:0] ts98; logic tc98;
  // tile 98 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 6
  fam_prefix_arrival_2_1_1_0_w4 u_i98 (.a({ts88[1], ts88[0], ts87[3], ts87[2]}), .b({ts81[3], ts81[2], ts91[3], ts91[2]}), .cin(1'b0), .s(ts98), .cout(tc98));
  logic [3:0] ts99; logic tc99;
  // tile 99 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 6
  fam_prefix_arrival_2_1_1_0_w4 u_i99 (.a({ts92[1], ts92[0], 1'b0, tc75}), .b({1'b0, tc83, 1'b0, 1'b0}), .cin(1'b0), .s(ts99), .cout(tc99));
  logic [3:0] ts100; logic tc100;
  // tile 100 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 6
  fam_prefix_arrival_2_1_1_0_w4 u_i100 (.a({1'b0, 1'b0, ts92[3], ts92[2]}), .b({1'b0, tc84, 1'b0, 1'b0}), .cin(1'b0), .s(ts100), .cout(tc100));
  logic [3:0] ts101; logic tc101;
  // tile 101 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 6
  fam_prefix_arrival_2_1_1_0_w4 u_i101 (.a({1'b0, 1'b0, 1'b0, tc77}), .b({1'b0, tc85, 1'b0, 1'b0}), .cin(1'b0), .s(ts101), .cout(tc101));
  logic [3:0] ts102; logic tc102;
  // tile 102 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 6
  fam_prefix_arrival_2_1_1_0_w4 u_i102 (.a({1'b0, 1'b0, 1'b0, tc78}), .b({1'b0, tc87, 1'b0, 1'b0}), .cin(1'b0), .s(ts102), .cout(tc102));
  logic [3:0] ts103; logic tc103;
  // tile 103 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 6
  fam_prefix_arrival_2_1_1_0_w4 u_i103 (.a({1'b0, tc90, 1'b0, 1'b0}), .b({1'b0, tc92, 1'b0, 1'b0}), .cin(1'b0), .s(ts103), .cout(tc103));
  logic [3:0] ts104; logic tc104;
  // tile 104 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 7
  fam_prefix_arrival_2_1_1_0_w4 u_i104 (.a({ts94[1], ts94[0], ts93[3], ts93[2]}), .b({ts99[1], ts99[0], 1'b0, tc82}), .cin(1'b0), .s(ts104), .cout(tc104));
  logic [3:0] ts105; logic tc105;
  // tile 105 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 7
  fam_prefix_arrival_2_1_1_0_w4 u_i105 (.a({ts95[1], ts95[0], ts94[3], ts94[2]}), .b({ts100[1], ts100[0], ts99[3], ts99[2]}), .cin(1'b0), .s(ts105), .cout(tc105));
  logic [3:0] ts106; logic tc106;
  // tile 106 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 7
  fam_prefix_arrival_2_1_1_0_w4 u_i106 (.a({ts96[1], ts96[0], ts95[3], ts95[2]}), .b({ts101[1], ts101[0], ts100[3], ts100[2]}), .cin(1'b0), .s(ts106), .cout(tc106));
  logic [3:0] ts107; logic tc107;
  // tile 107 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 7
  fam_prefix_arrival_2_1_1_0_w4 u_i107 (.a({ts97[1], ts97[0], ts96[3], ts96[2]}), .b({1'b0, 1'b0, ts101[3], ts101[2]}), .cin(1'b0), .s(ts107), .cout(tc107));
  logic [3:0] ts108; logic tc108;
  // tile 108 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 7
  fam_prefix_arrival_2_1_1_0_w4 u_i108 (.a({ts98[1], ts98[0], ts97[3], ts97[2]}), .b({ts102[1], ts102[0], 1'b0, tc86}), .cin(1'b0), .s(ts108), .cout(tc108));
  logic [1:0] ts109; logic tc109;
  // tile 109 (prefix_synthesis_nonuniform_arrival, 2 bits) at level 7
  fam_prefix_arrival_1_0_w2 u_i109 (.a({ts98[3], ts98[2]}), .b({ts102[3], ts102[2]}), .cin(1'b0), .s(ts109), .cout(tc109));
  logic [3:0] ts110; logic tc110;
  // tile 110 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 7
  fam_prefix_arrival_2_1_1_0_w4 u_i110 (.a({ts103[1], ts103[0], 1'b0, tc89}), .b({1'b0, tc94, 1'b0, 1'b0}), .cin(1'b0), .s(ts110), .cout(tc110));
  logic [3:0] ts111; logic tc111;
  // tile 111 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 7
  fam_prefix_arrival_2_1_1_0_w4 u_i111 (.a({1'b0, 1'b0, ts103[3], ts103[2]}), .b({1'b0, tc95, 1'b0, 1'b0}), .cin(1'b0), .s(ts111), .cout(tc111));
  logic [3:0] ts112; logic tc112;
  // tile 112 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 7
  fam_prefix_arrival_2_1_1_0_w4 u_i112 (.a({1'b0, tc100, 1'b0, 1'b0}), .b({1'b0, tc103, 1'b0, 1'b0}), .cin(1'b0), .s(ts112), .cout(tc112));
  logic [3:0] ts113; logic tc113;
  // tile 113 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 8
  fam_prefix_arrival_2_1_1_0_w4 u_i113 (.a({ts105[1], ts105[0], ts104[3], ts104[2]}), .b({ts110[1], ts110[0], 1'b0, tc93}), .cin(1'b0), .s(ts113), .cout(tc113));
  logic [3:0] ts114; logic tc114;
  // tile 114 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 8
  fam_prefix_arrival_2_1_1_0_w4 u_i114 (.a({ts106[1], ts106[0], ts105[3], ts105[2]}), .b({ts111[1], ts111[0], ts110[3], ts110[2]}), .cin(1'b0), .s(ts114), .cout(tc114));
  logic [3:0] ts115; logic tc115;
  // tile 115 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 8
  fam_prefix_arrival_2_1_1_0_w4 u_i115 (.a({ts107[1], ts107[0], ts106[3], ts106[2]}), .b({1'b0, 1'b0, ts111[3], ts111[2]}), .cin(1'b0), .s(ts115), .cout(tc115));
  logic [3:0] ts116; logic tc116;
  // tile 116 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 8
  fam_prefix_arrival_2_1_1_0_w4 u_i116 (.a({ts108[1], ts108[0], ts107[3], ts107[2]}), .b({1'b0, 1'b0, 1'b0, tc96}), .cin(1'b0), .s(ts116), .cout(tc116));
  logic [3:0] ts117; logic tc117;
  // tile 117 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 8
  fam_prefix_arrival_2_1_1_0_w4 u_i117 (.a({ts109[1], ts109[0], ts108[3], ts108[2]}), .b({1'b0, tc91, 1'b0, tc97}), .cin(1'b0), .s(ts117), .cout(tc117));
  logic [3:0] ts118; logic tc118;
  // tile 118 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 8
  fam_prefix_arrival_2_1_1_0_w4 u_i118 (.a({ts112[1], ts112[0], 1'b0, tc99}), .b({1'b0, tc105, 1'b0, 1'b0}), .cin(1'b0), .s(ts118), .cout(tc118));
  logic [3:0] ts119; logic tc119;
  // tile 119 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 8
  fam_prefix_arrival_2_1_1_0_w4 u_i119 (.a({1'b0, 1'b0, ts112[3], ts112[2]}), .b({1'b0, tc106, 1'b0, 1'b0}), .cin(1'b0), .s(ts119), .cout(tc119));
  logic [3:0] ts120; logic tc120;
  // tile 120 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 8
  fam_prefix_arrival_2_1_1_0_w4 u_i120 (.a({1'b0, 1'b0, 1'b0, tc101}), .b({1'b0, tc107, 1'b0, 1'b0}), .cin(1'b0), .s(ts120), .cout(tc120));
  logic [3:0] ts121; logic tc121;
  // tile 121 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 8
  fam_prefix_arrival_2_1_1_0_w4 u_i121 (.a({1'b0, tc111, 1'b0, 1'b0}), .b({1'b0, tc112, 1'b0, 1'b0}), .cin(1'b0), .s(ts121), .cout(tc121));
  logic [3:0] ts122; logic tc122;
  // tile 122 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 9
  fam_prefix_arrival_2_1_1_0_w4 u_i122 (.a({ts114[1], ts114[0], ts113[3], ts113[2]}), .b({ts118[1], ts118[0], 1'b0, tc104}), .cin(1'b0), .s(ts122), .cout(tc122));
  logic [3:0] ts123; logic tc123;
  // tile 123 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 9
  fam_prefix_arrival_2_1_1_0_w4 u_i123 (.a({ts115[1], ts115[0], ts114[3], ts114[2]}), .b({ts119[1], ts119[0], ts118[3], ts118[2]}), .cin(1'b0), .s(ts123), .cout(tc123));
  logic [3:0] ts124; logic tc124;
  // tile 124 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 9
  fam_prefix_arrival_2_1_1_0_w4 u_i124 (.a({ts116[1], ts116[0], ts115[3], ts115[2]}), .b({ts120[1], ts120[0], ts119[3], ts119[2]}), .cin(1'b0), .s(ts124), .cout(tc124));
  logic [3:0] ts125; logic tc125;
  // tile 125 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 9
  fam_prefix_arrival_2_1_1_0_w4 u_i125 (.a({ts117[1], ts117[0], ts116[3], ts116[2]}), .b({1'b0, 1'b0, ts120[3], ts120[2]}), .cin(1'b0), .s(ts125), .cout(tc125));
  logic [1:0] ts126; logic tc126;
  // tile 126 (prefix_synthesis_nonuniform_arrival, 2 bits) at level 9
  fam_prefix_arrival_1_0_w2 u_i126 (.a({ts117[3], ts117[2]}), .b({1'b0, tc108}), .cin(1'b0), .s(ts126), .cout(tc126));
  logic [3:0] ts127; logic tc127;
  // tile 127 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 9
  fam_prefix_arrival_2_1_1_0_w4 u_i127 (.a({ts121[1], ts121[0], 1'b0, tc110}), .b({1'b0, tc114, 1'b0, 1'b0}), .cin(1'b0), .s(ts127), .cout(tc127));
  logic [3:0] ts128; logic tc128;
  // tile 128 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 9
  fam_prefix_arrival_2_1_1_0_w4 u_i128 (.a({1'b0, 1'b0, ts121[3], ts121[2]}), .b({1'b0, tc115, 1'b0, 1'b0}), .cin(1'b0), .s(ts128), .cout(tc128));
  logic [3:0] ts129; logic tc129;
  // tile 129 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 9
  fam_prefix_arrival_2_1_1_0_w4 u_i129 (.a({1'b0, tc119, 1'b0, 1'b0}), .b({1'b0, tc121, 1'b0, 1'b0}), .cin(1'b0), .s(ts129), .cout(tc129));
  logic [3:0] ts130; logic tc130;
  // tile 130 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 10
  fam_prefix_arrival_2_1_1_0_w4 u_i130 (.a({ts123[1], ts123[0], ts122[3], ts122[2]}), .b({ts127[1], ts127[0], 1'b0, tc113}), .cin(1'b0), .s(ts130), .cout(tc130));
  logic [3:0] ts131; logic tc131;
  // tile 131 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 10
  fam_prefix_arrival_2_1_1_0_w4 u_i131 (.a({ts124[1], ts124[0], ts123[3], ts123[2]}), .b({ts128[1], ts128[0], ts127[3], ts127[2]}), .cin(1'b0), .s(ts131), .cout(tc131));
  logic [3:0] ts132; logic tc132;
  // tile 132 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 10
  fam_prefix_arrival_2_1_1_0_w4 u_i132 (.a({ts125[1], ts125[0], ts124[3], ts124[2]}), .b({1'b0, 1'b0, ts128[3], ts128[2]}), .cin(1'b0), .s(ts132), .cout(tc132));
  logic [3:0] ts133; logic tc133;
  // tile 133 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 10
  fam_prefix_arrival_2_1_1_0_w4 u_i133 (.a({ts126[1], ts126[0], ts125[3], ts125[2]}), .b({1'b0, 1'b0, 1'b0, tc116}), .cin(1'b0), .s(ts133), .cout(tc133));
  logic [3:0] ts134; logic tc134;
  // tile 134 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 10
  fam_prefix_arrival_2_1_1_0_w4 u_i134 (.a({ts129[1], ts129[0], 1'b0, tc118}), .b({1'b0, tc123, 1'b0, 1'b0}), .cin(1'b0), .s(ts134), .cout(tc134));
  logic [3:0] ts135; logic tc135;
  // tile 135 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 10
  fam_prefix_arrival_2_1_1_0_w4 u_i135 (.a({1'b0, 1'b0, ts129[3], ts129[2]}), .b({1'b0, tc124, 1'b0, 1'b0}), .cin(1'b0), .s(ts135), .cout(tc135));
  logic [3:0] ts136; logic tc136;
  // tile 136 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 10
  fam_prefix_arrival_2_1_1_0_w4 u_i136 (.a({1'b0, 1'b0, 1'b0, tc120}), .b({1'b0, tc125, 1'b0, 1'b0}), .cin(1'b0), .s(ts136), .cout(tc136));
  logic [3:0] ts137; logic tc137;
  // tile 137 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 10
  fam_prefix_arrival_2_1_1_0_w4 u_i137 (.a({1'b0, tc128, 1'b0, 1'b0}), .b({1'b0, tc129, 1'b0, 1'b0}), .cin(1'b0), .s(ts137), .cout(tc137));
  logic [3:0] ts138; logic tc138;
  // tile 138 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 11
  fam_prefix_arrival_2_1_1_0_w4 u_i138 (.a({ts131[1], ts131[0], ts130[3], ts130[2]}), .b({ts134[1], ts134[0], 1'b0, tc122}), .cin(1'b0), .s(ts138), .cout(tc138));
  logic [3:0] ts139; logic tc139;
  // tile 139 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 11
  fam_prefix_arrival_2_1_1_0_w4 u_i139 (.a({ts132[1], ts132[0], ts131[3], ts131[2]}), .b({ts135[1], ts135[0], ts134[3], ts134[2]}), .cin(1'b0), .s(ts139), .cout(tc139));
  logic [3:0] ts140; logic tc140;
  // tile 140 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 11
  fam_prefix_arrival_2_1_1_0_w4 u_i140 (.a({ts133[1], ts133[0], ts132[3], ts132[2]}), .b({ts136[1], ts136[0], ts135[3], ts135[2]}), .cin(1'b0), .s(ts140), .cout(tc140));
  logic [1:0] ts141; logic tc141;
  // tile 141 (prefix_synthesis_nonuniform_arrival, 2 bits) at level 11
  fam_prefix_arrival_1_0_w2 u_i141 (.a({ts133[3], ts133[2]}), .b({ts136[3], ts136[2]}), .cin(1'b0), .s(ts141), .cout(tc141));
  logic [3:0] ts142; logic tc142;
  // tile 142 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 11
  fam_prefix_arrival_2_1_1_0_w4 u_i142 (.a({ts137[1], ts137[0], 1'b0, tc127}), .b({1'b0, tc131, 1'b0, 1'b0}), .cin(1'b0), .s(ts142), .cout(tc142));
  logic [3:0] ts143; logic tc143;
  // tile 143 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 11
  fam_prefix_arrival_2_1_1_0_w4 u_i143 (.a({1'b0, 1'b0, ts137[3], ts137[2]}), .b({1'b0, tc132, 1'b0, 1'b0}), .cin(1'b0), .s(ts143), .cout(tc143));
  logic [3:0] ts144; logic tc144;
  // tile 144 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 11
  fam_prefix_arrival_2_1_1_0_w4 u_i144 (.a({1'b0, tc135, 1'b0, 1'b0}), .b({1'b0, tc137, 1'b0, 1'b0}), .cin(1'b0), .s(ts144), .cout(tc144));
  logic [3:0] ts145; logic tc145;
  // tile 145 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 12
  fam_prefix_arrival_2_1_1_0_w4 u_i145 (.a({ts139[1], ts139[0], ts138[3], ts138[2]}), .b({ts142[1], ts142[0], 1'b0, tc130}), .cin(1'b0), .s(ts145), .cout(tc145));
  logic [3:0] ts146; logic tc146;
  // tile 146 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 12
  fam_prefix_arrival_2_1_1_0_w4 u_i146 (.a({ts140[1], ts140[0], ts139[3], ts139[2]}), .b({ts143[1], ts143[0], ts142[3], ts142[2]}), .cin(1'b0), .s(ts146), .cout(tc146));
  logic [3:0] ts147; logic tc147;
  // tile 147 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 12
  fam_prefix_arrival_2_1_1_0_w4 u_i147 (.a({ts141[1], ts141[0], ts140[3], ts140[2]}), .b({1'b0, 1'b0, ts143[3], ts143[2]}), .cin(1'b0), .s(ts147), .cout(tc147));
  logic [3:0] ts148; logic tc148;
  // tile 148 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 12
  fam_prefix_arrival_2_1_1_0_w4 u_i148 (.a({ts144[1], ts144[0], 1'b0, tc134}), .b({1'b0, tc139, 1'b0, 1'b0}), .cin(1'b0), .s(ts148), .cout(tc148));
  logic [3:0] ts149; logic tc149;
  // tile 149 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 12
  fam_prefix_arrival_2_1_1_0_w4 u_i149 (.a({1'b0, 1'b0, ts144[3], ts144[2]}), .b({1'b0, tc140, 1'b0, 1'b0}), .cin(1'b0), .s(ts149), .cout(tc149));
  logic [3:0] ts150; logic tc150;
  // tile 150 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 12
  fam_prefix_arrival_2_1_1_0_w4 u_i150 (.a({1'b0, tc143, 1'b0, 1'b0}), .b({1'b0, tc144, 1'b0, 1'b0}), .cin(1'b0), .s(ts150), .cout(tc150));
  logic [3:0] ts151; logic tc151;
  // tile 151 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 13
  fam_prefix_arrival_2_1_1_0_w4 u_i151 (.a({ts146[1], ts146[0], ts145[3], ts145[2]}), .b({ts148[1], ts148[0], 1'b0, tc138}), .cin(1'b0), .s(ts151), .cout(tc151));
  logic [3:0] ts152; logic tc152;
  // tile 152 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 13
  fam_prefix_arrival_2_1_1_0_w4 u_i152 (.a({ts147[1], ts147[0], ts146[3], ts146[2]}), .b({ts149[1], ts149[0], ts148[3], ts148[2]}), .cin(1'b0), .s(ts152), .cout(tc152));
  logic [1:0] ts153; logic tc153;
  // tile 153 (prefix_synthesis_nonuniform_arrival, 2 bits) at level 13
  fam_prefix_arrival_1_0_w2 u_i153 (.a({ts147[3], ts147[2]}), .b({ts149[3], ts149[2]}), .cin(1'b0), .s(ts153), .cout(tc153));
  logic [3:0] ts154; logic tc154;
  // tile 154 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 13
  fam_prefix_arrival_2_1_1_0_w4 u_i154 (.a({ts150[1], ts150[0], 1'b0, tc142}), .b({1'b0, tc146, 1'b0, 1'b0}), .cin(1'b0), .s(ts154), .cout(tc154));
  logic [3:0] ts155; logic tc155;
  // tile 155 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 14
  fam_prefix_arrival_2_1_1_0_w4 u_i155 (.a({ts152[1], ts152[0], ts151[3], ts151[2]}), .b({ts154[1], ts154[0], 1'b0, tc145}), .cin(1'b0), .s(ts155), .cout(tc155));
  logic [3:0] ts156; logic tc156;
  // tile 156 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 14
  fam_prefix_arrival_2_1_1_0_w4 u_i156 (.a({ts153[1], ts153[0], ts152[3], ts152[2]}), .b({ts150[3], ts150[2], ts154[3], ts154[2]}), .cin(1'b0), .s(ts156), .cout(tc156));
  logic [3:0] ts157; logic tc157;
  // tile 157 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 14
  fam_prefix_arrival_2_1_1_0_w4 u_i157 (.a({1'b0, 1'b0, 1'b0, tc148}), .b({1'b0, tc152, 1'b0, 1'b0}), .cin(1'b0), .s(ts157), .cout(tc157));
  logic [3:0] ts158; logic tc158;
  // tile 158 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 15
  fam_prefix_arrival_2_1_1_0_w4 u_i158 (.a({ts156[1], ts156[0], ts155[3], ts155[2]}), .b({ts157[1], ts157[0], 1'b0, tc151}), .cin(1'b0), .s(ts158), .cout(tc158));
  logic [1:0] ts159; logic tc159;
  // tile 159 (prefix_synthesis_nonuniform_arrival, 2 bits) at level 15
  fam_prefix_arrival_1_0_w2 u_i159 (.a({ts156[3], ts156[2]}), .b({ts157[3], ts157[2]}), .cin(1'b0), .s(ts159), .cout(tc159));
  assign xl_x = x[8:0];
  assign xh_x = x[17:9];
  assign sq0 = xl_x[0] & xl_x[1];
  assign sq1 = xl_x[0] & xl_x[2];
  assign sq2 = xl_x[0] & xl_x[3];
  assign sq3 = xl_x[0] & xl_x[4];
  assign sq4 = xl_x[0] & xl_x[5];
  assign sq5 = xl_x[0] & xl_x[6];
  assign sq6 = xl_x[0] & xl_x[7];
  assign sq7 = xl_x[0] & xl_x[8];
  assign sq8 = xl_x[1] & xl_x[2];
  assign sq9 = xl_x[1] & xl_x[3];
  assign sq10 = xl_x[1] & xl_x[4];
  assign sq11 = xl_x[1] & xl_x[5];
  assign sq12 = xl_x[1] & xl_x[6];
  assign sq13 = xl_x[1] & xl_x[7];
  assign sq14 = xl_x[1] & xl_x[8];
  assign sq15 = xl_x[2] & xl_x[3];
  assign sq16 = xl_x[2] & xl_x[4];
  assign sq17 = xl_x[2] & xl_x[5];
  assign sq18 = xl_x[2] & xl_x[6];
  assign sq19 = xl_x[2] & xl_x[7];
  assign sq20 = xl_x[2] & xl_x[8];
  assign sq21 = xl_x[3] & xl_x[4];
  assign sq22 = xl_x[3] & xl_x[5];
  assign sq23 = xl_x[3] & xl_x[6];
  assign sq24 = xl_x[3] & xl_x[7];
  assign sq25 = xl_x[3] & xl_x[8];
  assign sq26 = xl_x[4] & xl_x[5];
  assign sq27 = xl_x[4] & xl_x[6];
  assign sq28 = xl_x[4] & xl_x[7];
  assign sq29 = xl_x[4] & xl_x[8];
  assign sq30 = xl_x[5] & xl_x[6];
  assign sq31 = xl_x[5] & xl_x[7];
  assign sq32 = xl_x[5] & xl_x[8];
  assign sq33 = xl_x[6] & xl_x[7];
  assign sq34 = xl_x[6] & xl_x[8];
  assign sq35 = xl_x[7] & xl_x[8];
  assign sq36 = xh_x[0] & xh_x[1];
  assign sq37 = xh_x[0] & xh_x[2];
  assign sq38 = xh_x[0] & xh_x[3];
  assign sq39 = xh_x[0] & xh_x[4];
  assign sq40 = xh_x[0] & xh_x[5];
  assign sq41 = xh_x[0] & xh_x[6];
  assign sq42 = xh_x[0] & xh_x[7];
  assign sq43 = ~(xh_x[0] & xh_x[8]);
  assign sq44 = xh_x[1] & xh_x[2];
  assign sq45 = xh_x[1] & xh_x[3];
  assign sq46 = xh_x[1] & xh_x[4];
  assign sq47 = xh_x[1] & xh_x[5];
  assign sq48 = xh_x[1] & xh_x[6];
  assign sq49 = xh_x[1] & xh_x[7];
  assign sq50 = ~(xh_x[1] & xh_x[8]);
  assign sq51 = xh_x[2] & xh_x[3];
  assign sq52 = xh_x[2] & xh_x[4];
  assign sq53 = xh_x[2] & xh_x[5];
  assign sq54 = xh_x[2] & xh_x[6];
  assign sq55 = xh_x[2] & xh_x[7];
  assign sq56 = ~(xh_x[2] & xh_x[8]);
  assign sq57 = xh_x[3] & xh_x[4];
  assign sq58 = xh_x[3] & xh_x[5];
  assign sq59 = xh_x[3] & xh_x[6];
  assign sq60 = xh_x[3] & xh_x[7];
  assign sq61 = ~(xh_x[3] & xh_x[8]);
  assign sq62 = xh_x[4] & xh_x[5];
  assign sq63 = xh_x[4] & xh_x[6];
  assign sq64 = xh_x[4] & xh_x[7];
  assign sq65 = ~(xh_x[4] & xh_x[8]);
  assign sq66 = xh_x[5] & xh_x[6];
  assign sq67 = xh_x[5] & xh_x[7];
  assign sq68 = ~(xh_x[5] & xh_x[8]);
  assign sq69 = xh_x[6] & xh_x[7];
  assign sq70 = ~(xh_x[6] & xh_x[8]);
  assign sq71 = ~(xh_x[7] & xh_x[8]);
  assign sq72 = ~xp_x[19];
  assign t73 = ts159[0] ^ tc154;
  assign t74 = ts159[0] & tc154;
  logic [35:0] row_s, row_c;
  assign row_s = {ts159[1], tc158, ts158[3], ts158[2], ts158[1], ts158[0], ts155[1], ts155[0], ts151[1], ts151[0], ts145[1], ts145[0], ts138[1], ts138[0], ts130[1], ts130[0], ts122[1], ts122[0], ts113[1], ts113[0], ts104[1], ts104[0], ts93[1], ts93[0], ts82[1], ts82[0], ts68[1], ts68[0], ts54[1], ts54[0], ts37[1], ts37[0], ts20[1], ts20[0], ts1[1], ts1[0]};
  assign row_c = {t74, t73, 1'b0, tc155, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
  fam_adder_sparse_prefix_hybrid_pffcb72a1e2dde901eb12285a94d60bf7eedb50952359c8f19d7c7cbf86a1c3ec_w36 u_cpa (.a(row_s), .b(row_c), .cin(1'b0), .s(p), .cout());
endmodule

// twin_precision_subword (baugh_wooley, signs outside the matrix): the lanes' magnitudes through an unsigned gated matrix, each lane's product negated back by the operand signs
module fam_mul_twin_precision_w16_8s_mag_d363602d01e8 (input logic [15:0] a, input logic [15:0] b, input logic [0:0] sel, output logic [31:0] p);
  logic [15:0] am, bm; logic [31:0] pu, pn;
  logic [15:0] am0, bm0; logic [31:0] pn0;
  assign am0 = {(a[15] ? -a[15:8] : a[15:8]), (a[7] ? -a[7:0] : a[7:0])}; assign bm0 = {(b[15] ? -b[15:8] : b[15:8]), (b[7] ? -b[7:0] : b[7:0])}; assign pn0 = {((a[15] ^ b[15]) ? -pu[31:16] : pu[31:16]), ((a[7] ^ b[7]) ? -pu[15:0] : pu[15:0])};
  assign am = (sel == 1'd0) ? am0 : a;
  assign bm = (sel == 1'd0) ? bm0 : b;
  fam_mul_twin_precision_w16_8s_mag_d363602d01e8_u u_mat (.a(am), .b(bm), .sel(sel), .p(pu));
  assign p = (sel == 1'd0) ? pn0 : pu;
endmodule


// twin_precision_subword (baugh_wooley, per-lane signed): one partial-product matrix gated by the mode (2 x 8), carries killed at the lane boundaries, the packed products on one bus
module fam_mul_twin_precision_w16_8s_mag_d363602d01e8_u (input logic [15:0] a, input logic [15:0] b, input logic [0:0] sel, output logic [31:0] p);
  logic [0:0] sel_u; assign sel_u = sel;
  logic ms0, pp1, pp2, pp3, pp4, pp5, pp6, pp7, pp8, pp9, pp10, pp11, pp12, pp13, pp14, pp15, pp16, pp17, pp18, pp19, pp20, pp21, pp22, pp23, pp24, pp25, pp26, pp27, pp28, pp29, pp30, pp31, pp32, pp33, pp34, pp35, pp36, pp37, pp38, pp39, pp40, pp41, pp42, pp43, pp44, pp45, pp46, pp47, pp48, pp49, pp50, pp51, pp52, pp53, pp54, pp55, pp56, pp57, pp58, pp59, pp60, pp61, pp62, pp63, pp64, pp65, pp66, pp67, pp68, pp69, pp70, pp71, pp72, pp73, pp74, pp75, pp76, pp77, pp78, pp79, pp80, pp81, pp82, pp83, pp84, pp85, pp86, pp87, pp88, pp89, pp90, pp91, pp92, pp93, pp94, pp95, pp96, pp97, pp98, pp99, pp100, pp101, pp102, pp103, pp104, pp105, pp106, pp107, pp108, pp109, pp110, pp111, pp112, pp113, pp114, pp115, pp116, pp117, pp118, pp119, pp120, pp121, pp122, pp123, pp124, pp125, pp126, pp127, pp128, t129, t130, t131, t132, t133, t134, t135, t136, t137, t138, t139, t140, t141, t142, t143, t144, t145, t146, t147, t148, t149, t150, t151, t152, t153, t154, t155, t156, t157, t158, t159, t160, t161, t162, t163, t164, t165, t166, t167, t168, t169, t170, t171, t172, t173, t174, t175, t176, t177, t178, t179, t180, t181, t182, t183, t184, t185, t186, t187, t188, t189, t190, t191, t192, t193, t194, t195, t196, t197, t198, t199, t200, t201, t202, t203, t204, t205, t206, t207, t208, t209, t210, t211, t212, t213, t214, t215, t216, t217, t218, t219, t220, t221, t222, t223, t224, t225, t226, t227, t228, t229, t230, t231, t232, t233, t234, t235, t236, t237, t238, t239, t240, t241, t242, t243, t244, t245, t246, t247, t248, t249, t250, t251, t252, t253, t254, t255, t256, t257, t258, t259, t260, t261, t262, t263, t264, t265, t266, t267, t268, t269, t270, t271, t272, t273, t274, t275, t276, t277, t278, t279, t280, t281, t282, t283, t284, t285, t286, t287, t288, t289, t290, t291, t292, t293, t294, t295, t296;
  assign ms0 = sel == 1'd0;
  assign pp1 = a[0] & b[0];
  assign pp2 = a[0] & b[1];
  assign pp3 = a[0] & b[2];
  assign pp4 = a[0] & b[3];
  assign pp5 = a[0] & b[4];
  assign pp6 = a[0] & b[5];
  assign pp7 = a[0] & b[6];
  assign pp8 = a[0] & b[7];
  assign pp9 = a[1] & b[0];
  assign pp10 = a[1] & b[1];
  assign pp11 = a[1] & b[2];
  assign pp12 = a[1] & b[3];
  assign pp13 = a[1] & b[4];
  assign pp14 = a[1] & b[5];
  assign pp15 = a[1] & b[6];
  assign pp16 = a[1] & b[7];
  assign pp17 = a[2] & b[0];
  assign pp18 = a[2] & b[1];
  assign pp19 = a[2] & b[2];
  assign pp20 = a[2] & b[3];
  assign pp21 = a[2] & b[4];
  assign pp22 = a[2] & b[5];
  assign pp23 = a[2] & b[6];
  assign pp24 = a[2] & b[7];
  assign pp25 = a[3] & b[0];
  assign pp26 = a[3] & b[1];
  assign pp27 = a[3] & b[2];
  assign pp28 = a[3] & b[3];
  assign pp29 = a[3] & b[4];
  assign pp30 = a[3] & b[5];
  assign pp31 = a[3] & b[6];
  assign pp32 = a[3] & b[7];
  assign pp33 = a[4] & b[0];
  assign pp34 = a[4] & b[1];
  assign pp35 = a[4] & b[2];
  assign pp36 = a[4] & b[3];
  assign pp37 = a[4] & b[4];
  assign pp38 = a[4] & b[5];
  assign pp39 = a[4] & b[6];
  assign pp40 = a[4] & b[7];
  assign pp41 = a[5] & b[0];
  assign pp42 = a[5] & b[1];
  assign pp43 = a[5] & b[2];
  assign pp44 = a[5] & b[3];
  assign pp45 = a[5] & b[4];
  assign pp46 = a[5] & b[5];
  assign pp47 = a[5] & b[6];
  assign pp48 = a[5] & b[7];
  assign pp49 = a[6] & b[0];
  assign pp50 = a[6] & b[1];
  assign pp51 = a[6] & b[2];
  assign pp52 = a[6] & b[3];
  assign pp53 = a[6] & b[4];
  assign pp54 = a[6] & b[5];
  assign pp55 = a[6] & b[6];
  assign pp56 = a[6] & b[7];
  assign pp57 = a[7] & b[0];
  assign pp58 = a[7] & b[1];
  assign pp59 = a[7] & b[2];
  assign pp60 = a[7] & b[3];
  assign pp61 = a[7] & b[4];
  assign pp62 = a[7] & b[5];
  assign pp63 = a[7] & b[6];
  assign pp64 = a[7] & b[7];
  assign pp65 = a[8] & b[8];
  assign pp66 = a[8] & b[9];
  assign pp67 = a[8] & b[10];
  assign pp68 = a[8] & b[11];
  assign pp69 = a[8] & b[12];
  assign pp70 = a[8] & b[13];
  assign pp71 = a[8] & b[14];
  assign pp72 = a[8] & b[15];
  assign pp73 = a[9] & b[8];
  assign pp74 = a[9] & b[9];
  assign pp75 = a[9] & b[10];
  assign pp76 = a[9] & b[11];
  assign pp77 = a[9] & b[12];
  assign pp78 = a[9] & b[13];
  assign pp79 = a[9] & b[14];
  assign pp80 = a[9] & b[15];
  assign pp81 = a[10] & b[8];
  assign pp82 = a[10] & b[9];
  assign pp83 = a[10] & b[10];
  assign pp84 = a[10] & b[11];
  assign pp85 = a[10] & b[12];
  assign pp86 = a[10] & b[13];
  assign pp87 = a[10] & b[14];
  assign pp88 = a[10] & b[15];
  assign pp89 = a[11] & b[8];
  assign pp90 = a[11] & b[9];
  assign pp91 = a[11] & b[10];
  assign pp92 = a[11] & b[11];
  assign pp93 = a[11] & b[12];
  assign pp94 = a[11] & b[13];
  assign pp95 = a[11] & b[14];
  assign pp96 = a[11] & b[15];
  assign pp97 = a[12] & b[8];
  assign pp98 = a[12] & b[9];
  assign pp99 = a[12] & b[10];
  assign pp100 = a[12] & b[11];
  assign pp101 = a[12] & b[12];
  assign pp102 = a[12] & b[13];
  assign pp103 = a[12] & b[14];
  assign pp104 = a[12] & b[15];
  assign pp105 = a[13] & b[8];
  assign pp106 = a[13] & b[9];
  assign pp107 = a[13] & b[10];
  assign pp108 = a[13] & b[11];
  assign pp109 = a[13] & b[12];
  assign pp110 = a[13] & b[13];
  assign pp111 = a[13] & b[14];
  assign pp112 = a[13] & b[15];
  assign pp113 = a[14] & b[8];
  assign pp114 = a[14] & b[9];
  assign pp115 = a[14] & b[10];
  assign pp116 = a[14] & b[11];
  assign pp117 = a[14] & b[12];
  assign pp118 = a[14] & b[13];
  assign pp119 = a[14] & b[14];
  assign pp120 = a[14] & b[15];
  assign pp121 = a[15] & b[8];
  assign pp122 = a[15] & b[9];
  assign pp123 = a[15] & b[10];
  assign pp124 = a[15] & b[11];
  assign pp125 = a[15] & b[12];
  assign pp126 = a[15] & b[13];
  assign pp127 = a[15] & b[14];
  assign pp128 = a[15] & b[15];
  assign t129 = pp7 ^ pp14;
  assign t130 = pp7 & pp14;
  assign t131 = pp8 ^ pp15 ^ pp22;
  assign t132 = (pp8 & pp15) | (pp8 & pp22) | (pp15 & pp22);
  assign t133 = pp29 ^ pp36;
  assign t134 = pp29 & pp36;
  assign t135 = pp16 ^ pp23 ^ pp30;
  assign t136 = (pp16 & pp23) | (pp16 & pp30) | (pp23 & pp30);
  assign t137 = pp37 ^ pp44;
  assign t138 = pp37 & pp44;
  assign t139 = pp24 ^ pp31 ^ pp38;
  assign t140 = (pp24 & pp31) | (pp24 & pp38) | (pp31 & pp38);
  assign t141 = pp71 ^ pp78;
  assign t142 = pp71 & pp78;
  assign t143 = pp72 ^ pp79 ^ pp86;
  assign t144 = (pp72 & pp79) | (pp72 & pp86) | (pp79 & pp86);
  assign t145 = pp93 ^ pp100;
  assign t146 = pp93 & pp100;
  assign t147 = pp80 ^ pp87 ^ pp94;
  assign t148 = (pp80 & pp87) | (pp80 & pp94) | (pp87 & pp94);
  assign t149 = pp101 ^ pp108;
  assign t150 = pp101 & pp108;
  assign t151 = pp88 ^ pp95 ^ pp102;
  assign t152 = (pp88 & pp95) | (pp88 & pp102) | (pp95 & pp102);
  assign t153 = pp5 ^ pp12;
  assign t154 = pp5 & pp12;
  assign t155 = pp6 ^ pp13 ^ pp20;
  assign t156 = (pp6 & pp13) | (pp6 & pp20) | (pp13 & pp20);
  assign t157 = pp27 ^ pp34;
  assign t158 = pp27 & pp34;
  assign t159 = t129 ^ pp21 ^ pp28;
  assign t160 = (t129 & pp21) | (t129 & pp28) | (pp21 & pp28);
  assign t161 = pp35 ^ pp42 ^ pp49;
  assign t162 = (pp35 & pp42) | (pp35 & pp49) | (pp42 & pp49);
  assign t163 = t130 ^ t131 ^ t133;
  assign t164 = (t130 & t131) | (t130 & t133) | (t131 & t133);
  assign t165 = pp43 ^ pp50 ^ pp57;
  assign t166 = (pp43 & pp50) | (pp43 & pp57) | (pp50 & pp57);
  assign t167 = t132 ^ t134 ^ t135;
  assign t168 = (t132 & t134) | (t132 & t135) | (t134 & t135);
  assign t169 = t137 ^ pp51 ^ pp58;
  assign t170 = (t137 & pp51) | (t137 & pp58) | (pp51 & pp58);
  assign t171 = t136 ^ t138 ^ t139;
  assign t172 = (t136 & t138) | (t136 & t139) | (t138 & t139);
  assign t173 = pp45 ^ pp52 ^ pp59;
  assign t174 = (pp45 & pp52) | (pp45 & pp59) | (pp52 & pp59);
  assign t175 = t140 ^ pp32 ^ pp39;
  assign t176 = (t140 & pp32) | (t140 & pp39) | (pp32 & pp39);
  assign t177 = pp46 ^ pp53 ^ pp60;
  assign t178 = (pp46 & pp53) | (pp46 & pp60) | (pp53 & pp60);
  assign t179 = pp40 ^ pp47 ^ pp54;
  assign t180 = (pp40 & pp47) | (pp40 & pp54) | (pp47 & pp54);
  assign t181 = pp69 ^ pp76;
  assign t182 = pp69 & pp76;
  assign t183 = pp70 ^ pp77 ^ pp84;
  assign t184 = (pp70 & pp77) | (pp70 & pp84) | (pp77 & pp84);
  assign t185 = pp91 ^ pp98;
  assign t186 = pp91 & pp98;
  assign t187 = t141 ^ pp85 ^ pp92;
  assign t188 = (t141 & pp85) | (t141 & pp92) | (pp85 & pp92);
  assign t189 = pp99 ^ pp106 ^ pp113;
  assign t190 = (pp99 & pp106) | (pp99 & pp113) | (pp106 & pp113);
  assign t191 = t142 ^ t143 ^ t145;
  assign t192 = (t142 & t143) | (t142 & t145) | (t143 & t145);
  assign t193 = pp107 ^ pp114 ^ pp121;
  assign t194 = (pp107 & pp114) | (pp107 & pp121) | (pp114 & pp121);
  assign t195 = t144 ^ t146 ^ t147;
  assign t196 = (t144 & t146) | (t144 & t147) | (t146 & t147);
  assign t197 = t149 ^ pp115 ^ pp122;
  assign t198 = (t149 & pp115) | (t149 & pp122) | (pp115 & pp122);
  assign t199 = t148 ^ t150 ^ t151;
  assign t200 = (t148 & t150) | (t148 & t151) | (t150 & t151);
  assign t201 = pp109 ^ pp116 ^ pp123;
  assign t202 = (pp109 & pp116) | (pp109 & pp123) | (pp116 & pp123);
  assign t203 = t152 ^ pp96 ^ pp103;
  assign t204 = (t152 & pp96) | (t152 & pp103) | (pp96 & pp103);
  assign t205 = pp110 ^ pp117 ^ pp124;
  assign t206 = (pp110 & pp117) | (pp110 & pp124) | (pp117 & pp124);
  assign t207 = pp104 ^ pp111 ^ pp118;
  assign t208 = (pp104 & pp111) | (pp104 & pp118) | (pp111 & pp118);
  assign t209 = pp4 ^ pp11;
  assign t210 = pp4 & pp11;
  assign t211 = t153 ^ pp19 ^ pp26;
  assign t212 = (t153 & pp19) | (t153 & pp26) | (pp19 & pp26);
  assign t213 = t154 ^ t155 ^ t157;
  assign t214 = (t154 & t155) | (t154 & t157) | (t155 & t157);
  assign t215 = t156 ^ t158 ^ t159;
  assign t216 = (t156 & t158) | (t156 & t159) | (t158 & t159);
  assign t217 = t160 ^ t162 ^ t163;
  assign t218 = (t160 & t162) | (t160 & t163) | (t162 & t163);
  assign t219 = t164 ^ t166 ^ t167;
  assign t220 = (t164 & t166) | (t164 & t167) | (t166 & t167);
  assign t221 = t168 ^ t170 ^ t171;
  assign t222 = (t168 & t170) | (t168 & t171) | (t170 & t171);
  assign t223 = t172 ^ t174 ^ t175;
  assign t224 = (t172 & t174) | (t172 & t175) | (t174 & t175);
  assign t225 = t176 ^ t178 ^ t179;
  assign t226 = (t176 & t178) | (t176 & t179) | (t178 & t179);
  assign t227 = t180 ^ pp48 ^ pp55;
  assign t228 = (t180 & pp48) | (t180 & pp55) | (pp48 & pp55);
  assign t229 = pp68 ^ pp75;
  assign t230 = pp68 & pp75;
  assign t231 = t181 ^ pp83 ^ pp90;
  assign t232 = (t181 & pp83) | (t181 & pp90) | (pp83 & pp90);
  assign t233 = t182 ^ t183 ^ t185;
  assign t234 = (t182 & t183) | (t182 & t185) | (t183 & t185);
  assign t235 = t184 ^ t186 ^ t187;
  assign t236 = (t184 & t186) | (t184 & t187) | (t186 & t187);
  assign t237 = t188 ^ t190 ^ t191;
  assign t238 = (t188 & t190) | (t188 & t191) | (t190 & t191);
  assign t239 = t192 ^ t194 ^ t195;
  assign t240 = (t192 & t194) | (t192 & t195) | (t194 & t195);
  assign t241 = t196 ^ t198 ^ t199;
  assign t242 = (t196 & t198) | (t196 & t199) | (t198 & t199);
  assign t243 = t200 ^ t202 ^ t203;
  assign t244 = (t200 & t202) | (t200 & t203) | (t202 & t203);
  assign t245 = t204 ^ t206 ^ t207;
  assign t246 = (t204 & t206) | (t204 & t207) | (t206 & t207);
  assign t247 = t208 ^ pp112 ^ pp119;
  assign t248 = (t208 & pp112) | (t208 & pp119) | (pp112 & pp119);
  assign t249 = pp3 ^ pp10;
  assign t250 = pp3 & pp10;
  assign t251 = t209 ^ pp18 ^ pp25;
  assign t252 = (t209 & pp18) | (t209 & pp25) | (pp18 & pp25);
  assign t253 = t210 ^ t211 ^ pp33;
  assign t254 = (t210 & t211) | (t210 & pp33) | (t211 & pp33);
  assign t255 = t212 ^ t213 ^ pp41;
  assign t256 = (t212 & t213) | (t212 & pp41) | (t213 & pp41);
  assign t257 = t214 ^ t215 ^ t161;
  assign t258 = (t214 & t215) | (t214 & t161) | (t215 & t161);
  assign t259 = t216 ^ t217 ^ t165;
  assign t260 = (t216 & t217) | (t216 & t165) | (t217 & t165);
  assign t261 = t218 ^ t219 ^ t169;
  assign t262 = (t218 & t219) | (t218 & t169) | (t219 & t169);
  assign t263 = t220 ^ t221 ^ t173;
  assign t264 = (t220 & t221) | (t220 & t173) | (t221 & t173);
  assign t265 = t222 ^ t223 ^ t177;
  assign t266 = (t222 & t223) | (t222 & t177) | (t223 & t177);
  assign t267 = t224 ^ t225 ^ pp61;
  assign t268 = (t224 & t225) | (t224 & pp61) | (t225 & pp61);
  assign t269 = t226 ^ t227 ^ pp62;
  assign t270 = (t226 & t227) | (t226 & pp62) | (t227 & pp62);
  assign t271 = t228 ^ pp56 ^ pp63;
  assign t272 = (t228 & pp56) | (t228 & pp63) | (pp56 & pp63);
  assign t273 = pp67 ^ pp74;
  assign t274 = pp67 & pp74;
  assign t275 = t229 ^ pp82 ^ pp89;
  assign t276 = (t229 & pp82) | (t229 & pp89) | (pp82 & pp89);
  assign t277 = t230 ^ t231 ^ pp97;
  assign t278 = (t230 & t231) | (t230 & pp97) | (t231 & pp97);
  assign t279 = t232 ^ t233 ^ pp105;
  assign t280 = (t232 & t233) | (t232 & pp105) | (t233 & pp105);
  assign t281 = t234 ^ t235 ^ t189;
  assign t282 = (t234 & t235) | (t234 & t189) | (t235 & t189);
  assign t283 = t236 ^ t237 ^ t193;
  assign t284 = (t236 & t237) | (t236 & t193) | (t237 & t193);
  assign t285 = t238 ^ t239 ^ t197;
  assign t286 = (t238 & t239) | (t238 & t197) | (t239 & t197);
  assign t287 = t240 ^ t241 ^ t201;
  assign t288 = (t240 & t241) | (t240 & t201) | (t241 & t201);
  assign t289 = t242 ^ t243 ^ t205;
  assign t290 = (t242 & t243) | (t242 & t205) | (t243 & t205);
  assign t291 = t244 ^ t245 ^ pp125;
  assign t292 = (t244 & t245) | (t244 & pp125) | (t245 & pp125);
  assign t293 = t246 ^ t247 ^ pp126;
  assign t294 = (t246 & t247) | (t246 & pp126) | (t247 & pp126);
  assign t295 = t248 ^ pp120 ^ pp127;
  assign t296 = (t248 & pp120) | (t248 & pp127) | (pp120 & pp127);
  logic [31:0] row_s, row_c;
  assign row_s = {1'b0, t296, t294, t292, t290, t288, t286, t284, t282, t280, t278, t276, t274, t273, pp66, pp65, 1'b0, t272, t270, t268, t266, t264, t262, t260, t258, t256, t254, t252, t250, t249, pp2, pp1};
  assign row_c = {1'b0, pp128, t295, t293, t291, t289, t287, t285, t283, t281, t279, t277, t275, pp81, pp73, 1'b0, 1'b0, pp64, t271, t269, t267, t265, t263, t261, t259, t257, t255, t253, t251, pp17, pp9, 1'b0};
  logic [2:0] cc; assign cc[0] = 1'b0;
  logic ci0; assign ci0 = cc[0] & ~(1'b1);
  fam_adder_ripple_carry #(.W(16), .CHUNK(1), .FORM(0)) u_cpa0 (.a(row_s[15:0]), .b(row_c[15:0]), .cin(ci0), .s(p[15:0]), .cout(cc[1]));
  logic ci1; assign ci1 = cc[1] & ~(1'b1);
  fam_adder_ripple_carry #(.W(16), .CHUNK(1), .FORM(0)) u_cpa1 (.a(row_s[31:16]), .b(row_c[31:16]), .cin(ci1), .s(p[31:16]), .cout(cc[2]));
endmodule



module fam_prefix_arrival_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_w16 (input logic [15:0] a, input logic [15:0] b, input logic cin,
  output logic [15:0] s, output logic cout);
  // prefix graph: {'n': 16, 'levels': 4, 'size': 49, 'fanout': 4, 'tracks': 8, 'exact_split': True, 'valency': 2}
  logic [15:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [15:0] g0, p0;
  assign g0 = {gi[15:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_1_2, P_1_2, G_2_3, P_2_3, G_3_4, P_3_4, G_4_5, P_4_5, G_5_6, P_5_6, G_6_7, P_6_7, G_7_8, P_7_8, G_8_9, P_8_9, G_9_10, P_9_10, G_10_11, P_10_11, G_11_12, P_11_12, G_12_13, P_12_13, G_13_14, P_13_14, G_14_15, P_14_15, G_0_2, G_0_3, G_1_4, P_1_4, G_2_5, P_2_5, G_3_6, P_3_6, G_4_7, P_4_7, G_5_8, P_5_8, G_6_9, P_6_9, G_7_10, P_7_10, G_8_11, P_8_11, G_9_12, P_9_12, G_10_13, P_10_13, G_11_14, P_11_14, G_12_15, P_12_15, G_0_4, G_0_5, G_0_6, G_0_7, G_1_8, P_1_8, G_2_9, P_2_9, G_3_10, P_3_10, G_4_11, P_4_11, G_5_12, P_5_12, G_6_13, P_6_13, G_7_14, P_7_14, G_8_15, P_8_15, G_0_8, G_0_9, G_0_10, G_0_11, G_0_12, G_0_13, G_0_14, G_0_15;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_5_6 = g0[6] | (p0[6] & g0[5]);
  assign P_5_6 = p0[6] & p0[5];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_7_8 = g0[8] | (p0[8] & g0[7]);
  assign P_7_8 = p0[8] & p0[7];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_9_10 = g0[10] | (p0[10] & g0[9]);
  assign P_9_10 = p0[10] & p0[9];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_11_12 = g0[12] | (p0[12] & g0[11]);
  assign P_11_12 = p0[12] & p0[11];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_13_14 = g0[14] | (p0[14] & g0[13]);
  assign P_13_14 = p0[14] & p0[13];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_1_4 = G_3_4 | (P_3_4 & G_1_2);
  assign P_1_4 = P_3_4 & P_1_2;
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_3_6 = G_5_6 | (P_5_6 & G_3_4);
  assign P_3_6 = P_5_6 & P_3_4;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_5_8 = G_7_8 | (P_7_8 & G_5_6);
  assign P_5_8 = P_7_8 & P_5_6;
  assign G_6_9 = G_8_9 | (P_8_9 & G_6_7);
  assign P_6_9 = P_8_9 & P_6_7;
  assign G_7_10 = G_9_10 | (P_9_10 & G_7_8);
  assign P_7_10 = P_9_10 & P_7_8;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_9_12 = G_11_12 | (P_11_12 & G_9_10);
  assign P_9_12 = P_11_12 & P_9_10;
  assign G_10_13 = G_12_13 | (P_12_13 & G_10_11);
  assign P_10_13 = P_12_13 & P_10_11;
  assign G_11_14 = G_13_14 | (P_13_14 & G_11_12);
  assign P_11_14 = P_13_14 & P_11_12;
  assign G_12_15 = G_14_15 | (P_14_15 & G_12_13);
  assign P_12_15 = P_14_15 & P_12_13;
  assign G_0_4 = G_1_4 | (P_1_4 & g0[0]);
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  assign G_0_6 = G_3_6 | (P_3_6 & G_0_2);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_1_8 = G_5_8 | (P_5_8 & G_1_4);
  assign P_1_8 = P_5_8 & P_1_4;
  assign G_2_9 = G_6_9 | (P_6_9 & G_2_5);
  assign P_2_9 = P_6_9 & P_2_5;
  assign G_3_10 = G_7_10 | (P_7_10 & G_3_6);
  assign P_3_10 = P_7_10 & P_3_6;
  assign G_4_11 = G_8_11 | (P_8_11 & G_4_7);
  assign P_4_11 = P_8_11 & P_4_7;
  assign G_5_12 = G_9_12 | (P_9_12 & G_5_8);
  assign P_5_12 = P_9_12 & P_5_8;
  assign G_6_13 = G_10_13 | (P_10_13 & G_6_9);
  assign P_6_13 = P_10_13 & P_6_9;
  assign G_7_14 = G_11_14 | (P_11_14 & G_7_10);
  assign P_7_14 = P_11_14 & P_7_10;
  assign G_8_15 = G_12_15 | (P_12_15 & G_8_11);
  assign P_8_15 = P_12_15 & P_8_11;
  assign G_0_8 = G_1_8 | (P_1_8 & g0[0]);
  assign G_0_9 = G_2_9 | (P_2_9 & G_0_1);
  assign G_0_10 = G_3_10 | (P_3_10 & G_0_2);
  assign G_0_11 = G_4_11 | (P_4_11 & G_0_3);
  assign G_0_12 = G_5_12 | (P_5_12 & G_0_4);
  assign G_0_13 = G_6_13 | (P_6_13 & G_0_5);
  assign G_0_14 = G_7_14 | (P_7_14 & G_0_6);
  assign G_0_15 = G_8_15 | (P_8_15 & G_0_7);
  logic [16:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign c[15] = G_0_14;
  assign c[16] = G_0_15;
  assign s = pi_ ^ c[15:0];
  assign cout = c[16];
endmodule





























module fam_prefix_arrival_1_0_w2 (input logic [1:0] a, input logic [1:0] b, input logic cin,
  output logic [1:0] s, output logic cout);
  // prefix graph: {'n': 2, 'levels': 1, 'size': 1, 'fanout': 1, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [1:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [1:0] g0, p0;
  assign g0 = {gi[1:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  logic [2:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign s = pi_ ^ c[1:0];
  assign cout = c[2];
endmodule


module fam_prefix_arrival_2_1_1_0_w4 (input logic [3:0] a, input logic [3:0] b, input logic cin,
  output logic [3:0] s, output logic cout);
  // prefix graph: {'n': 4, 'levels': 3, 'size': 6, 'fanout': 3, 'tracks': 2, 'exact_split': True, 'valency': 2}
  logic [3:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [3:0] g0, p0;
  assign g0 = {gi[3:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_1_2, P_1_2, G_2_3, P_2_3, G_0_2, G_1_3, P_1_3, G_0_3;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_1_3 = G_2_3 | (P_2_3 & g0[1]);
  assign P_1_3 = P_2_3 & p0[1];
  assign G_0_3 = G_1_3 | (P_1_3 & g0[0]);
  logic [4:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign s = pi_ ^ c[3:0];
  assign cout = c[4];
endmodule



module fam_prefix_arrival_3_2_2_1_1_0_w6 (input logic [5:0] a, input logic [5:0] b, input logic cin,
  output logic [5:0] s, output logic cout);
  // prefix graph: {'n': 6, 'levels': 4, 'size': 14, 'fanout': 5, 'tracks': 3, 'exact_split': True, 'valency': 2}
  logic [5:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [5:0] g0, p0;
  assign g0 = {gi[5:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_1_2, P_1_2, G_2_3, P_2_3, G_3_4, P_3_4, G_4_5, P_4_5, G_0_2, G_1_3, P_1_3, G_2_4, P_2_4, G_3_5, P_3_5, G_0_3, G_1_4, P_1_4, G_1_5, P_1_5, G_0_4, G_0_5;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_1_3 = G_2_3 | (P_2_3 & g0[1]);
  assign P_1_3 = P_2_3 & p0[1];
  assign G_2_4 = G_3_4 | (P_3_4 & g0[2]);
  assign P_2_4 = P_3_4 & p0[2];
  assign G_3_5 = G_4_5 | (P_4_5 & g0[3]);
  assign P_3_5 = P_4_5 & p0[3];
  assign G_0_3 = G_1_3 | (P_1_3 & g0[0]);
  assign G_1_4 = G_2_4 | (P_2_4 & g0[1]);
  assign P_1_4 = P_2_4 & p0[1];
  assign G_1_5 = G_3_5 | (P_3_5 & G_1_2);
  assign P_1_5 = P_3_5 & P_1_2;
  assign G_0_4 = G_1_4 | (P_1_4 & g0[0]);
  assign G_0_5 = G_1_5 | (P_1_5 & g0[0]);
  logic [6:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign s = pi_ ^ c[5:0];
  assign cout = c[6];
endmodule

module fam_prefix_han_carlson_w16 (input logic [15:0] a, input logic [15:0] b, input logic cin,
  output logic [15:0] s, output logic cout);
  // prefix graph: {'n': 16, 'levels': 5, 'size': 32, 'fanout': 4, 'tracks': 4, 'exact_split': True, 'valency': 2}
  logic [15:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [15:0] g0, p0;
  assign g0 = {gi[15:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_8_9, P_8_9, G_10_11, P_10_11, G_12_13, P_12_13, G_14_15, P_14_15, G_0_2, G_0_3, G_2_5, P_2_5, G_4_7, P_4_7, G_6_9, P_6_9, G_8_11, P_8_11, G_10_13, P_10_13, G_12_15, P_12_15, G_0_4, G_0_5, G_0_7, G_2_9, P_2_9, G_4_11, P_4_11, G_6_13, P_6_13, G_8_15, P_8_15, G_0_6, G_0_8, G_0_9, G_0_11, G_0_13, G_0_15, G_0_10, G_0_12, G_0_14;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_6_9 = G_8_9 | (P_8_9 & G_6_7);
  assign P_6_9 = P_8_9 & P_6_7;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_10_13 = G_12_13 | (P_12_13 & G_10_11);
  assign P_10_13 = P_12_13 & P_10_11;
  assign G_12_15 = G_14_15 | (P_14_15 & G_12_13);
  assign P_12_15 = P_14_15 & P_12_13;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_2_9 = G_6_9 | (P_6_9 & G_2_5);
  assign P_2_9 = P_6_9 & P_2_5;
  assign G_4_11 = G_8_11 | (P_8_11 & G_4_7);
  assign P_4_11 = P_8_11 & P_4_7;
  assign G_6_13 = G_10_13 | (P_10_13 & G_6_9);
  assign P_6_13 = P_10_13 & P_6_9;
  assign G_8_15 = G_12_15 | (P_12_15 & G_8_11);
  assign P_8_15 = P_12_15 & P_8_11;
  assign G_0_6 = g0[6] | (p0[6] & G_0_5);
  assign G_0_8 = g0[8] | (p0[8] & G_0_7);
  assign G_0_9 = G_2_9 | (P_2_9 & G_0_1);
  assign G_0_11 = G_4_11 | (P_4_11 & G_0_3);
  assign G_0_13 = G_6_13 | (P_6_13 & G_0_5);
  assign G_0_15 = G_8_15 | (P_8_15 & G_0_7);
  assign G_0_10 = g0[10] | (p0[10] & G_0_9);
  assign G_0_12 = g0[12] | (p0[12] & G_0_11);
  assign G_0_14 = g0[14] | (p0[14] & G_0_13);
  logic [16:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign c[15] = G_0_14;
  assign c[16] = G_0_15;
  assign s = pi_ ^ c[15:0];
  assign cout = c[16];
endmodule



module fam_prefix_han_carlson_w4_flag_dual_late (input logic [3:0] a, input logic [3:0] b, input logic cin,
  output logic [3:0] s, output logic cout, output logic [3:0] s1);
  // prefix graph: {'n': 4, 'levels': 2, 'size': 4, 'fanout': 2, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [3:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [3:0] g0, p0;
  assign g0 = gi;
  assign p0 = pi_;
  logic G_0_1, P_0_1, G_2_3, P_2_3, G_0_2, P_0_2, G_0_3, P_0_3;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign P_0_1 = p0[1] & p0[0];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign P_0_2 = p0[2] & P_0_1;
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign P_0_3 = P_2_3 & P_0_1;
  logic [4:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0] | (p0[0] & cin);
  assign c[2] = G_0_1 | (P_0_1 & cin);
  assign c[3] = G_0_2 | (P_0_2 & cin);
  assign c[4] = G_0_3 | (P_0_3 & cin);
  assign s = pi_ ^ c[3:0];
  assign cout = c[4];
  logic [4:0] c1;
  assign c1[0] = 1'b1;
  assign c1[1] = g0[0] | p0[0];
  assign c1[2] = G_0_1 | P_0_1;
  assign c1[3] = G_0_2 | P_0_2;
  assign c1[4] = G_0_3 | P_0_3;
  assign s1 = pi_ ^ c1[3:0];
endmodule


module fam_prefix_han_carlson_w5 (input logic [4:0] a, input logic [4:0] b, input logic cin,
  output logic [4:0] s, output logic cout);
  // prefix graph: {'n': 5, 'levels': 3, 'size': 5, 'fanout': 2, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [4:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [4:0] g0, p0;
  assign g0 = {gi[4:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_2_3, P_2_3, G_0_2, G_0_3, G_0_4;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  logic [5:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign s = pi_ ^ c[4:0];
  assign cout = c[5];
endmodule




module fam_prefix_knowles_mixed_w2 (input logic [1:0] a, input logic [1:0] b, input logic cin,
  output logic [1:0] s, output logic cout);
  // prefix graph: {'n': 2, 'levels': 1, 'size': 1, 'fanout': 1, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [1:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [1:0] g0, p0;
  assign g0 = {gi[1:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  logic [2:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign s = pi_ ^ c[1:0];
  assign cout = c[2];
endmodule





module fam_prefix_kogge_stone_w16 (input logic [15:0] a, input logic [15:0] b, input logic cin,
  output logic [15:0] s, output logic cout);
  // prefix graph: {'n': 16, 'levels': 4, 'size': 49, 'fanout': 4, 'tracks': 8, 'exact_split': True, 'valency': 2}
  logic [15:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [15:0] g0, p0;
  assign g0 = {gi[15:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_1_2, P_1_2, G_2_3, P_2_3, G_3_4, P_3_4, G_4_5, P_4_5, G_5_6, P_5_6, G_6_7, P_6_7, G_7_8, P_7_8, G_8_9, P_8_9, G_9_10, P_9_10, G_10_11, P_10_11, G_11_12, P_11_12, G_12_13, P_12_13, G_13_14, P_13_14, G_14_15, P_14_15, G_0_2, G_0_3, G_1_4, P_1_4, G_2_5, P_2_5, G_3_6, P_3_6, G_4_7, P_4_7, G_5_8, P_5_8, G_6_9, P_6_9, G_7_10, P_7_10, G_8_11, P_8_11, G_9_12, P_9_12, G_10_13, P_10_13, G_11_14, P_11_14, G_12_15, P_12_15, G_0_4, G_0_5, G_0_6, G_0_7, G_1_8, P_1_8, G_2_9, P_2_9, G_3_10, P_3_10, G_4_11, P_4_11, G_5_12, P_5_12, G_6_13, P_6_13, G_7_14, P_7_14, G_8_15, P_8_15, G_0_8, G_0_9, G_0_10, G_0_11, G_0_12, G_0_13, G_0_14, G_0_15;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_5_6 = g0[6] | (p0[6] & g0[5]);
  assign P_5_6 = p0[6] & p0[5];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_7_8 = g0[8] | (p0[8] & g0[7]);
  assign P_7_8 = p0[8] & p0[7];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_9_10 = g0[10] | (p0[10] & g0[9]);
  assign P_9_10 = p0[10] & p0[9];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_11_12 = g0[12] | (p0[12] & g0[11]);
  assign P_11_12 = p0[12] & p0[11];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_13_14 = g0[14] | (p0[14] & g0[13]);
  assign P_13_14 = p0[14] & p0[13];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_1_4 = G_3_4 | (P_3_4 & G_1_2);
  assign P_1_4 = P_3_4 & P_1_2;
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_3_6 = G_5_6 | (P_5_6 & G_3_4);
  assign P_3_6 = P_5_6 & P_3_4;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_5_8 = G_7_8 | (P_7_8 & G_5_6);
  assign P_5_8 = P_7_8 & P_5_6;
  assign G_6_9 = G_8_9 | (P_8_9 & G_6_7);
  assign P_6_9 = P_8_9 & P_6_7;
  assign G_7_10 = G_9_10 | (P_9_10 & G_7_8);
  assign P_7_10 = P_9_10 & P_7_8;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_9_12 = G_11_12 | (P_11_12 & G_9_10);
  assign P_9_12 = P_11_12 & P_9_10;
  assign G_10_13 = G_12_13 | (P_12_13 & G_10_11);
  assign P_10_13 = P_12_13 & P_10_11;
  assign G_11_14 = G_13_14 | (P_13_14 & G_11_12);
  assign P_11_14 = P_13_14 & P_11_12;
  assign G_12_15 = G_14_15 | (P_14_15 & G_12_13);
  assign P_12_15 = P_14_15 & P_12_13;
  assign G_0_4 = G_1_4 | (P_1_4 & g0[0]);
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  assign G_0_6 = G_3_6 | (P_3_6 & G_0_2);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_1_8 = G_5_8 | (P_5_8 & G_1_4);
  assign P_1_8 = P_5_8 & P_1_4;
  assign G_2_9 = G_6_9 | (P_6_9 & G_2_5);
  assign P_2_9 = P_6_9 & P_2_5;
  assign G_3_10 = G_7_10 | (P_7_10 & G_3_6);
  assign P_3_10 = P_7_10 & P_3_6;
  assign G_4_11 = G_8_11 | (P_8_11 & G_4_7);
  assign P_4_11 = P_8_11 & P_4_7;
  assign G_5_12 = G_9_12 | (P_9_12 & G_5_8);
  assign P_5_12 = P_9_12 & P_5_8;
  assign G_6_13 = G_10_13 | (P_10_13 & G_6_9);
  assign P_6_13 = P_10_13 & P_6_9;
  assign G_7_14 = G_11_14 | (P_11_14 & G_7_10);
  assign P_7_14 = P_11_14 & P_7_10;
  assign G_8_15 = G_12_15 | (P_12_15 & G_8_11);
  assign P_8_15 = P_12_15 & P_8_11;
  assign G_0_8 = G_1_8 | (P_1_8 & g0[0]);
  assign G_0_9 = G_2_9 | (P_2_9 & G_0_1);
  assign G_0_10 = G_3_10 | (P_3_10 & G_0_2);
  assign G_0_11 = G_4_11 | (P_4_11 & G_0_3);
  assign G_0_12 = G_5_12 | (P_5_12 & G_0_4);
  assign G_0_13 = G_6_13 | (P_6_13 & G_0_5);
  assign G_0_14 = G_7_14 | (P_7_14 & G_0_6);
  assign G_0_15 = G_8_15 | (P_8_15 & G_0_7);
  logic [16:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign c[15] = G_0_14;
  assign c[16] = G_0_15;
  assign s = pi_ ^ c[15:0];
  assign cout = c[16];
endmodule



module fam_prefix_ladner_fischer_w8 (input logic [7:0] a, input logic [7:0] b, input logic cin,
  output logic [7:0] s, output logic cout);
  // prefix graph: {'n': 8, 'levels': 4, 'size': 11, 'fanout': 3, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [7:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [7:0] g0, p0;
  assign g0 = {gi[7:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_0_2, G_0_3, G_4_7, P_4_7, G_0_4, G_0_5, G_0_7, G_0_6;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign G_0_5 = G_4_5 | (P_4_5 & G_0_3);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_0_6 = g0[6] | (p0[6] & G_0_5);
  logic [8:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign s = pi_ ^ c[7:0];
  assign cout = c[8];
endmodule


module fam_prefix_ladner_fischer_w9 (input logic [8:0] a, input logic [8:0] b, input logic cin,
  output logic [8:0] s, output logic cout);
  // prefix graph: {'n': 9, 'levels': 4, 'size': 12, 'fanout': 3, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [8:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [8:0] g0, p0;
  assign g0 = {gi[8:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_0_2, G_0_3, G_4_7, P_4_7, G_0_4, G_0_5, G_0_7, G_0_6, G_0_8;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign G_0_5 = G_4_5 | (P_4_5 & G_0_3);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_0_6 = g0[6] | (p0[6] & G_0_5);
  assign G_0_8 = g0[8] | (p0[8] & G_0_7);
  logic [9:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign s = pi_ ^ c[8:0];
  assign cout = c[9];
endmodule






module fam_prefix_net_knowles_mixed_w17 (input logic [16:0] g, input logic [16:0] p, input logic cin,
  output logic [16:0] c, output logic cout);
  // prefix graph: {'n': 17, 'levels': 5, 'size': 54, 'fanout': 4, 'tracks': 4, 'exact_split': False, 'valency': 2}
  logic [16:0] g0, p0;
  assign g0 = {g[16:1], g[0] | (p[0] & cin)};
  assign p0 = p;
  logic G_0_1, G_1_2, P_1_2, G_2_3, P_2_3, G_3_4, P_3_4, G_4_5, P_4_5, G_5_6, P_5_6, G_6_7, P_6_7, G_7_8, P_7_8, G_8_9, P_8_9, G_9_10, P_9_10, G_10_11, P_10_11, G_11_12, P_11_12, G_12_13, P_12_13, G_13_14, P_13_14, G_14_15, P_14_15, G_15_16, P_15_16, G_0_2, G_0_3, G_1_4, P_1_4, G_2_5, P_2_5, G_3_6, P_3_6, G_4_7, P_4_7, G_5_8, P_5_8, G_6_9, P_6_9, G_7_10, P_7_10, G_8_11, P_8_11, G_9_12, P_9_12, G_10_13, P_10_13, G_11_14, P_11_14, G_12_15, P_12_15, G_13_16, P_13_16, G_0_4, G_0_5, G_0_6, G_0_7, G_1_8, P_1_8, G_2_9, P_2_9, G_3_10, P_3_10, G_4_11, P_4_11, G_5_12, P_5_12, G_6_13, P_6_13, G_7_14, P_7_14, G_8_15, P_8_15, G_9_16, P_9_16, G_0_8, G_0_9, G_0_10, G_0_11, G_0_12, G_0_13, G_0_14, G_0_15, G_2_16, P_2_16, G_0_16;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_5_6 = g0[6] | (p0[6] & g0[5]);
  assign P_5_6 = p0[6] & p0[5];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_7_8 = g0[8] | (p0[8] & g0[7]);
  assign P_7_8 = p0[8] & p0[7];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_9_10 = g0[10] | (p0[10] & g0[9]);
  assign P_9_10 = p0[10] & p0[9];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_11_12 = g0[12] | (p0[12] & g0[11]);
  assign P_11_12 = p0[12] & p0[11];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_13_14 = g0[14] | (p0[14] & g0[13]);
  assign P_13_14 = p0[14] & p0[13];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_15_16 = g0[16] | (p0[16] & g0[15]);
  assign P_15_16 = p0[16] & p0[15];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_1_4 = G_3_4 | (P_3_4 & G_1_2);
  assign P_1_4 = P_3_4 & P_1_2;
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_3_6 = G_5_6 | (P_5_6 & G_3_4);
  assign P_3_6 = P_5_6 & P_3_4;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_5_8 = G_7_8 | (P_7_8 & G_5_6);
  assign P_5_8 = P_7_8 & P_5_6;
  assign G_6_9 = G_8_9 | (P_8_9 & G_6_7);
  assign P_6_9 = P_8_9 & P_6_7;
  assign G_7_10 = G_9_10 | (P_9_10 & G_7_8);
  assign P_7_10 = P_9_10 & P_7_8;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_9_12 = G_11_12 | (P_11_12 & G_9_10);
  assign P_9_12 = P_11_12 & P_9_10;
  assign G_10_13 = G_12_13 | (P_12_13 & G_10_11);
  assign P_10_13 = P_12_13 & P_10_11;
  assign G_11_14 = G_13_14 | (P_13_14 & G_11_12);
  assign P_11_14 = P_13_14 & P_11_12;
  assign G_12_15 = G_14_15 | (P_14_15 & G_12_13);
  assign P_12_15 = P_14_15 & P_12_13;
  assign G_13_16 = G_15_16 | (P_15_16 & G_13_14);
  assign P_13_16 = P_15_16 & P_13_14;
  assign G_0_4 = G_1_4 | (P_1_4 & g0[0]);
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  assign G_0_6 = G_3_6 | (P_3_6 & G_0_2);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_1_8 = G_5_8 | (P_5_8 & G_1_4);
  assign P_1_8 = P_5_8 & P_1_4;
  assign G_2_9 = G_6_9 | (P_6_9 & G_2_5);
  assign P_2_9 = P_6_9 & P_2_5;
  assign G_3_10 = G_7_10 | (P_7_10 & G_3_6);
  assign P_3_10 = P_7_10 & P_3_6;
  assign G_4_11 = G_8_11 | (P_8_11 & G_4_7);
  assign P_4_11 = P_8_11 & P_4_7;
  assign G_5_12 = G_9_12 | (P_9_12 & G_5_8);
  assign P_5_12 = P_9_12 & P_5_8;
  assign G_6_13 = G_10_13 | (P_10_13 & G_6_9);
  assign P_6_13 = P_10_13 & P_6_9;
  assign G_7_14 = G_11_14 | (P_11_14 & G_7_10);
  assign P_7_14 = P_11_14 & P_7_10;
  assign G_8_15 = G_12_15 | (P_12_15 & G_8_11);
  assign P_8_15 = P_12_15 & P_8_11;
  assign G_9_16 = G_13_16 | (P_13_16 & G_9_12);
  assign P_9_16 = P_13_16 & P_9_12;
  assign G_0_8 = G_1_8 | (P_1_8 & G_0_1);
  assign G_0_9 = G_2_9 | (P_2_9 & G_0_1);
  assign G_0_10 = G_3_10 | (P_3_10 & G_0_3);
  assign G_0_11 = G_4_11 | (P_4_11 & G_0_3);
  assign G_0_12 = G_5_12 | (P_5_12 & G_0_5);
  assign G_0_13 = G_6_13 | (P_6_13 & G_0_5);
  assign G_0_14 = G_7_14 | (P_7_14 & G_0_7);
  assign G_0_15 = G_8_15 | (P_8_15 & G_0_7);
  assign G_2_16 = G_9_16 | (P_9_16 & G_2_9);
  assign P_2_16 = P_9_16 & P_2_9;
  assign G_0_16 = G_2_16 | (P_2_16 & G_0_3);
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign c[15] = G_0_14;
  assign c[16] = G_0_15;
  assign cout = G_0_16;
endmodule

// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum





// sparse_prefix_hybrid: a knowles_mixed prefix network over blocks of 2 bits, the sums by conditional_sum










module fam_prefix_net_knowles_mixed_w5 (input logic [4:0] g, input logic [4:0] p, input logic cin,
  output logic [4:0] c, output logic cout);
  // prefix graph: {'n': 5, 'levels': 3, 'size': 8, 'fanout': 2, 'tracks': 2, 'exact_split': False, 'valency': 2}
  logic [4:0] g0, p0;
  assign g0 = {g[4:1], g[0] | (p[0] & cin)};
  assign p0 = p;
  logic G_0_1, G_1_2, P_1_2, G_2_3, P_2_3, G_3_4, P_3_4, G_0_2, G_0_3, G_1_4, P_1_4, G_0_4;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_1_4 = G_3_4 | (P_3_4 & G_1_2);
  assign P_1_4 = P_3_4 & P_1_2;
  assign G_0_4 = G_1_4 | (P_1_4 & G_0_1);
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign cout = G_0_4;
endmodule




module fam_prefix_net_knowles_mixed_w7 (input logic [6:0] g, input logic [6:0] p, input logic cin,
  output logic [6:0] c, output logic cout);
  // prefix graph: {'n': 7, 'levels': 3, 'size': 14, 'fanout': 3, 'tracks': 2, 'exact_split': False, 'valency': 2}
  logic [6:0] g0, p0;
  assign g0 = {g[6:1], g[0] | (p[0] & cin)};
  assign p0 = p;
  logic G_0_1, G_1_2, P_1_2, G_2_3, P_2_3, G_3_4, P_3_4, G_4_5, P_4_5, G_5_6, P_5_6, G_0_2, G_0_3, G_1_4, P_1_4, G_2_5, P_2_5, G_3_6, P_3_6, G_0_4, G_0_5, G_0_6;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_5_6 = g0[6] | (p0[6] & g0[5]);
  assign P_5_6 = p0[6] & p0[5];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_1_4 = G_3_4 | (P_3_4 & G_1_2);
  assign P_1_4 = P_3_4 & P_1_2;
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_3_6 = G_5_6 | (P_5_6 & G_3_4);
  assign P_3_6 = P_5_6 & P_3_4;
  assign G_0_4 = G_1_4 | (P_1_4 & G_0_1);
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  assign G_0_6 = G_3_6 | (P_3_6 & G_0_3);
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign cout = G_0_6;
endmodule




module fam_prefix_net_kogge_stone_w18 (input logic [17:0] g, input logic [17:0] p, input logic cin,
  output logic [17:0] c, output logic cout);
  // prefix graph: {'n': 18, 'levels': 5, 'size': 59, 'fanout': 5, 'tracks': 8, 'exact_split': True, 'valency': 2}
  logic [17:0] g0, p0;
  assign g0 = {g[17:1], g[0] | (p[0] & cin)};
  assign p0 = p;
  logic G_0_1, G_1_2, P_1_2, G_2_3, P_2_3, G_3_4, P_3_4, G_4_5, P_4_5, G_5_6, P_5_6, G_6_7, P_6_7, G_7_8, P_7_8, G_8_9, P_8_9, G_9_10, P_9_10, G_10_11, P_10_11, G_11_12, P_11_12, G_12_13, P_12_13, G_13_14, P_13_14, G_14_15, P_14_15, G_15_16, P_15_16, G_16_17, P_16_17, G_0_2, G_0_3, G_1_4, P_1_4, G_2_5, P_2_5, G_3_6, P_3_6, G_4_7, P_4_7, G_5_8, P_5_8, G_6_9, P_6_9, G_7_10, P_7_10, G_8_11, P_8_11, G_9_12, P_9_12, G_10_13, P_10_13, G_11_14, P_11_14, G_12_15, P_12_15, G_13_16, P_13_16, G_14_17, P_14_17, G_0_4, G_0_5, G_0_6, G_0_7, G_1_8, P_1_8, G_2_9, P_2_9, G_3_10, P_3_10, G_4_11, P_4_11, G_5_12, P_5_12, G_6_13, P_6_13, G_7_14, P_7_14, G_8_15, P_8_15, G_9_16, P_9_16, G_10_17, P_10_17, G_0_8, G_0_9, G_0_10, G_0_11, G_0_12, G_0_13, G_0_14, G_0_15, G_1_16, P_1_16, G_2_17, P_2_17, G_0_16, G_0_17;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_5_6 = g0[6] | (p0[6] & g0[5]);
  assign P_5_6 = p0[6] & p0[5];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_7_8 = g0[8] | (p0[8] & g0[7]);
  assign P_7_8 = p0[8] & p0[7];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_9_10 = g0[10] | (p0[10] & g0[9]);
  assign P_9_10 = p0[10] & p0[9];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_11_12 = g0[12] | (p0[12] & g0[11]);
  assign P_11_12 = p0[12] & p0[11];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_13_14 = g0[14] | (p0[14] & g0[13]);
  assign P_13_14 = p0[14] & p0[13];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_15_16 = g0[16] | (p0[16] & g0[15]);
  assign P_15_16 = p0[16] & p0[15];
  assign G_16_17 = g0[17] | (p0[17] & g0[16]);
  assign P_16_17 = p0[17] & p0[16];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_1_4 = G_3_4 | (P_3_4 & G_1_2);
  assign P_1_4 = P_3_4 & P_1_2;
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_3_6 = G_5_6 | (P_5_6 & G_3_4);
  assign P_3_6 = P_5_6 & P_3_4;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_5_8 = G_7_8 | (P_7_8 & G_5_6);
  assign P_5_8 = P_7_8 & P_5_6;
  assign G_6_9 = G_8_9 | (P_8_9 & G_6_7);
  assign P_6_9 = P_8_9 & P_6_7;
  assign G_7_10 = G_9_10 | (P_9_10 & G_7_8);
  assign P_7_10 = P_9_10 & P_7_8;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_9_12 = G_11_12 | (P_11_12 & G_9_10);
  assign P_9_12 = P_11_12 & P_9_10;
  assign G_10_13 = G_12_13 | (P_12_13 & G_10_11);
  assign P_10_13 = P_12_13 & P_10_11;
  assign G_11_14 = G_13_14 | (P_13_14 & G_11_12);
  assign P_11_14 = P_13_14 & P_11_12;
  assign G_12_15 = G_14_15 | (P_14_15 & G_12_13);
  assign P_12_15 = P_14_15 & P_12_13;
  assign G_13_16 = G_15_16 | (P_15_16 & G_13_14);
  assign P_13_16 = P_15_16 & P_13_14;
  assign G_14_17 = G_16_17 | (P_16_17 & G_14_15);
  assign P_14_17 = P_16_17 & P_14_15;
  assign G_0_4 = G_1_4 | (P_1_4 & g0[0]);
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  assign G_0_6 = G_3_6 | (P_3_6 & G_0_2);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_1_8 = G_5_8 | (P_5_8 & G_1_4);
  assign P_1_8 = P_5_8 & P_1_4;
  assign G_2_9 = G_6_9 | (P_6_9 & G_2_5);
  assign P_2_9 = P_6_9 & P_2_5;
  assign G_3_10 = G_7_10 | (P_7_10 & G_3_6);
  assign P_3_10 = P_7_10 & P_3_6;
  assign G_4_11 = G_8_11 | (P_8_11 & G_4_7);
  assign P_4_11 = P_8_11 & P_4_7;
  assign G_5_12 = G_9_12 | (P_9_12 & G_5_8);
  assign P_5_12 = P_9_12 & P_5_8;
  assign G_6_13 = G_10_13 | (P_10_13 & G_6_9);
  assign P_6_13 = P_10_13 & P_6_9;
  assign G_7_14 = G_11_14 | (P_11_14 & G_7_10);
  assign P_7_14 = P_11_14 & P_7_10;
  assign G_8_15 = G_12_15 | (P_12_15 & G_8_11);
  assign P_8_15 = P_12_15 & P_8_11;
  assign G_9_16 = G_13_16 | (P_13_16 & G_9_12);
  assign P_9_16 = P_13_16 & P_9_12;
  assign G_10_17 = G_14_17 | (P_14_17 & G_10_13);
  assign P_10_17 = P_14_17 & P_10_13;
  assign G_0_8 = G_1_8 | (P_1_8 & g0[0]);
  assign G_0_9 = G_2_9 | (P_2_9 & G_0_1);
  assign G_0_10 = G_3_10 | (P_3_10 & G_0_2);
  assign G_0_11 = G_4_11 | (P_4_11 & G_0_3);
  assign G_0_12 = G_5_12 | (P_5_12 & G_0_4);
  assign G_0_13 = G_6_13 | (P_6_13 & G_0_5);
  assign G_0_14 = G_7_14 | (P_7_14 & G_0_6);
  assign G_0_15 = G_8_15 | (P_8_15 & G_0_7);
  assign G_1_16 = G_9_16 | (P_9_16 & G_1_8);
  assign P_1_16 = P_9_16 & P_1_8;
  assign G_2_17 = G_10_17 | (P_10_17 & G_2_9);
  assign P_2_17 = P_10_17 & P_2_9;
  assign G_0_16 = G_1_16 | (P_1_16 & g0[0]);
  assign G_0_17 = G_2_17 | (P_2_17 & G_0_1);
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign c[15] = G_0_14;
  assign c[16] = G_0_15;
  assign c[17] = G_0_16;
  assign cout = G_0_17;
endmodule

module fam_prefix_sklansky_w16_flagm (input logic [15:0] a, input logic [15:0] b, input logic cin,
  output logic [15:0] s, output logic cout, output logic [15:0] s1, output logic [15:0] sm1);
  // prefix graph: {'n': 16, 'levels': 4, 'size': 32, 'fanout': 8, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [15:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [15:0] g0, p0;
  assign g0 = {gi[15:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, P_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_8_9, P_8_9, G_10_11, P_10_11, G_12_13, P_12_13, G_14_15, P_14_15, G_0_2, P_0_2, G_0_3, P_0_3, G_4_6, P_4_6, G_4_7, P_4_7, G_8_10, P_8_10, G_8_11, P_8_11, G_12_14, P_12_14, G_12_15, P_12_15, G_0_4, P_0_4, G_0_5, P_0_5, G_0_6, P_0_6, G_0_7, P_0_7, G_8_12, P_8_12, G_8_13, P_8_13, G_8_14, P_8_14, G_8_15, P_8_15, G_0_8, P_0_8, G_0_9, P_0_9, G_0_10, P_0_10, G_0_11, P_0_11, G_0_12, P_0_12, G_0_13, P_0_13, G_0_14, P_0_14, G_0_15, P_0_15;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign P_0_1 = p0[1] & p0[0];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign P_0_2 = p0[2] & P_0_1;
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign P_0_3 = P_2_3 & P_0_1;
  assign G_4_6 = g0[6] | (p0[6] & G_4_5);
  assign P_4_6 = p0[6] & P_4_5;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_8_10 = g0[10] | (p0[10] & G_8_9);
  assign P_8_10 = p0[10] & P_8_9;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_12_14 = g0[14] | (p0[14] & G_12_13);
  assign P_12_14 = p0[14] & P_12_13;
  assign G_12_15 = G_14_15 | (P_14_15 & G_12_13);
  assign P_12_15 = P_14_15 & P_12_13;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign P_0_4 = p0[4] & P_0_3;
  assign G_0_5 = G_4_5 | (P_4_5 & G_0_3);
  assign P_0_5 = P_4_5 & P_0_3;
  assign G_0_6 = G_4_6 | (P_4_6 & G_0_3);
  assign P_0_6 = P_4_6 & P_0_3;
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign P_0_7 = P_4_7 & P_0_3;
  assign G_8_12 = g0[12] | (p0[12] & G_8_11);
  assign P_8_12 = p0[12] & P_8_11;
  assign G_8_13 = G_12_13 | (P_12_13 & G_8_11);
  assign P_8_13 = P_12_13 & P_8_11;
  assign G_8_14 = G_12_14 | (P_12_14 & G_8_11);
  assign P_8_14 = P_12_14 & P_8_11;
  assign G_8_15 = G_12_15 | (P_12_15 & G_8_11);
  assign P_8_15 = P_12_15 & P_8_11;
  assign G_0_8 = g0[8] | (p0[8] & G_0_7);
  assign P_0_8 = p0[8] & P_0_7;
  assign G_0_9 = G_8_9 | (P_8_9 & G_0_7);
  assign P_0_9 = P_8_9 & P_0_7;
  assign G_0_10 = G_8_10 | (P_8_10 & G_0_7);
  assign P_0_10 = P_8_10 & P_0_7;
  assign G_0_11 = G_8_11 | (P_8_11 & G_0_7);
  assign P_0_11 = P_8_11 & P_0_7;
  assign G_0_12 = G_8_12 | (P_8_12 & G_0_7);
  assign P_0_12 = P_8_12 & P_0_7;
  assign G_0_13 = G_8_13 | (P_8_13 & G_0_7);
  assign P_0_13 = P_8_13 & P_0_7;
  assign G_0_14 = G_8_14 | (P_8_14 & G_0_7);
  assign P_0_14 = P_8_14 & P_0_7;
  assign G_0_15 = G_8_15 | (P_8_15 & G_0_7);
  assign P_0_15 = P_8_15 & P_0_7;
  logic [16:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign c[15] = G_0_14;
  assign c[16] = G_0_15;
  assign s = pi_ ^ c[15:0];
  assign cout = c[16];
  logic [15:0] f;
  assign f[0] = 1'b1;
  assign f[1] = pi_[0];
  assign f[2] = P_0_1;
  assign f[3] = P_0_2;
  assign f[4] = P_0_3;
  assign f[5] = P_0_4;
  assign f[6] = P_0_5;
  assign f[7] = P_0_6;
  assign f[8] = P_0_7;
  assign f[9] = P_0_8;
  assign f[10] = P_0_9;
  assign f[11] = P_0_10;
  assign f[12] = P_0_11;
  assign f[13] = P_0_12;
  assign f[14] = P_0_13;
  assign f[15] = P_0_14;
  assign s1 = s ^ f;
  logic [15:0] fm;
  assign fm[0] = 1'b1;
  assign fm[1] = fm[0] & ~s[0];
  assign fm[2] = fm[1] & ~s[1];
  assign fm[3] = fm[2] & ~s[2];
  assign fm[4] = fm[3] & ~s[3];
  assign fm[5] = fm[4] & ~s[4];
  assign fm[6] = fm[5] & ~s[5];
  assign fm[7] = fm[6] & ~s[6];
  assign fm[8] = fm[7] & ~s[7];
  assign fm[9] = fm[8] & ~s[8];
  assign fm[10] = fm[9] & ~s[9];
  assign fm[11] = fm[10] & ~s[10];
  assign fm[12] = fm[11] & ~s[11];
  assign fm[13] = fm[12] & ~s[12];
  assign fm[14] = fm[13] & ~s[13];
  assign fm[15] = fm[14] & ~s[14];
  assign sm1 = s ^ fm;
endmodule




// -------------------------------------------------------------- barrel_mux_tree
// ceil(AW / K) stages of 2^K:1 muxes (RADIX_LOG2 = K; 0 selects one full-width
// stage of W:1 muxes). DIR: 0 mirrored_datapath (a left and a right datapath,
// the result selected by the direction), 1 data_reversal (a right operation is
// a left one on the reversed word), 2 amount_negation (one left rotator; a right
// operation rotates by W - amt, a shift merges the fill through the keep mask).
// ORDER: 0 small_shift_first, 1 large_shift_first. ONE_HOT: the stages' select
// encoding.
module fam_shift_barrel_mux_tree #(parameter int W = 16, parameter int RADIX_LOG2 = 1, parameter int ONE_HOT = 0,
                                   parameter int DIR = 1, parameter int ORDER = 0, parameter int STICKY = 0)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic [2:0] op, output logic [W-1:0] y, output logic sticky);
  localparam int AW = $clog2(W);
  localparam int K = (RADIX_LOG2 == 0 || RADIX_LOG2 > AW) ? AW : RADIX_LOG2;
  localparam int NS = (AW + K - 1) / K;
  wire right = (op == 3'd1) || (op == 3'd2) || (op == 3'd4);
  wire rot = (op == 3'd3) || (op == 3'd4);
  wire arith = (op == 3'd2);
  wire fill = arith & a[W-1];
  logic [W-1:0] mask;
  fam_shift_keep_mask #(.W(W), .STICKY(STICKY)) u_mask (.a(a), .amt(amt), .right(right), .rot(rot), .mask(mask), .sticky(sticky));
  genvar s, i;
  generate
    if (DIR == 1) begin : reversed
      logic [W-1:0] rev_in, x, back;
      for (i = 0; i < W; i = i + 1) begin : rv
        assign rev_in[i] = a[W-1-i];
      end
      assign x = right ? rev_in : a;
      logic [W-1:0] st [0:NS];
      assign st[0] = x;
      for (s = 0; s < NS; s = s + 1) begin : stage
        localparam int G = ORDER ? (NS - 1 - s) : s;          // the digit this stage consumes
        localparam int KB = (G * K + K <= AW) ? K : AW - G * K;
        fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(0), .ONE_HOT(ONE_HOT))
          u (.x(st[s]), .digit(amt[G*K +: KB]), .rot(rot), .fill(fill), .y(st[s+1]));
      end
      for (i = 0; i < W; i = i + 1) begin : rb
        assign back[i] = st[NS][W-1-i];
      end
      assign y = right ? back : st[NS];
    end else if (DIR == 0) begin : mirrored
      logic [W-1:0] lft [0:NS];
      logic [W-1:0] rgt [0:NS];
      assign lft[0] = a;
      assign rgt[0] = a;
      for (s = 0; s < NS; s = s + 1) begin : stage
        localparam int G = ORDER ? (NS - 1 - s) : s;
        localparam int KB = (G * K + K <= AW) ? K : AW - G * K;
        fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(0), .ONE_HOT(ONE_HOT))
          ul (.x(lft[s]), .digit(amt[G*K +: KB]), .rot(rot), .fill(1'b0), .y(lft[s+1]));
        fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(1), .ONE_HOT(ONE_HOT))
          ur (.x(rgt[s]), .digit(amt[G*K +: KB]), .rot(rot), .fill(fill), .y(rgt[s+1]));
      end
      assign y = right ? rgt[NS] : lft[NS];
    end else begin : negated
      // one left rotator; a right operation is a left rotation by W - amt, and a shift takes
      // its fill through the keep mask (zero and overflow flags fall out of the mask)
      logic [AW-1:0] lamt;
      assign lamt = right ? (W - amt) : amt;
      logic [W-1:0] st [0:NS];
      assign st[0] = a;
      for (s = 0; s < NS; s = s + 1) begin : stage
        localparam int G = ORDER ? (NS - 1 - s) : s;
        localparam int KB = (G * K + K <= AW) ? K : AW - G * K;
        fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(0), .ONE_HOT(ONE_HOT))
          u (.x(st[s]), .digit(lamt[G*K +: KB]), .rot(1'b1), .fill(1'b0), .y(st[s+1]));
      end
      assign y = (st[NS] & mask) | ({W{fill}} & ~mask);
    end
  endgenerate
endmodule



// ----------------------------------------------------------- the keep mask
// mask[i] = 1 where a shift keeps the input bit that lands at i (a rotate keeps
// every bit): the thermometer of the amount for the direction. sticky is the OR
// of the input bits a shift moves out (the low amt bits of a right shift, the
// top amt bits of a left one; none for a rotate), read through the mask of the
// opposite direction, in parallel with the datapath.
module fam_shift_keep_mask #(parameter int W = 16, parameter int STICKY = 1)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic right, input logic rot,
   output logic [W-1:0] mask, output logic sticky);
  logic [W-1:0] kept_in;
  genvar i;
  generate
    for (i = 0; i < W; i = i + 1) begin : mk
      assign mask[i] = rot | (right ? (i < W - amt) : (i >= amt));
      assign kept_in[i] = rot | (right ? (i >= amt) : (i < W - amt));
    end
  endgenerate
  assign sticky = STICKY ? |(a & ~kept_in) : 1'b0;
endmodule




// ------------------------------------------------------------------ masked_merged
// a left rotator (the `rotator` slot's barrel: R_RADIX_LOG2, R_ONE_HOT, R_ORDER)
// plus a mask that turns the rotation into a shift by merging in the fill bits.
// MASKGEN: 0 thermometer_decode (one thermometer per direction, selected), 1
// two_thermometer_and (a low and a high bound thermometer ANDed), 2 lut (a table
// over the direction and the amount). MERGE: 0 and_or_merge, 1 per_bit_mux.
module fam_shift_masked_merged #(parameter int W = 16, parameter int MASKGEN = 0, parameter int MERGE = 0,
                                 parameter int R_RADIX_LOG2 = 1, parameter int R_ONE_HOT = 0, parameter int R_ORDER = 0, parameter int STICKY = 0)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic [2:0] op, output logic [W-1:0] y, output logic sticky);
  localparam int AW = $clog2(W);
  localparam int K = (R_RADIX_LOG2 == 0 || R_RADIX_LOG2 > AW) ? AW : R_RADIX_LOG2;
  localparam int NS = (AW + K - 1) / K;
  wire right = (op == 3'd1) || (op == 3'd2) || (op == 3'd4);
  wire rot = (op == 3'd3) || (op == 3'd4);
  wire arith = (op == 3'd2);
  wire fill = arith & a[W-1];
  // rotate left by amt (a right operation by k is a left rotation by W - k)
  logic [AW-1:0] lamt;
  assign lamt = right ? (W - amt) : amt;
  logic [W-1:0] st [0:NS];
  assign st[0] = a;
  genvar s, i;
  logic [W-1:0] mask;                 // 1 where the rotated bit is kept
  generate
    for (s = 0; s < NS; s = s + 1) begin : stage
      localparam int G = R_ORDER ? (NS - 1 - s) : s;
      localparam int KB = (G * K + K <= AW) ? K : AW - G * K;
      fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(0), .ONE_HOT(R_ONE_HOT))
        u (.x(st[s]), .digit(lamt[G*K +: KB]), .rot(1'b1), .fill(1'b0), .y(st[s+1]));
    end
    if (MASKGEN == 0) begin : thermo
      for (i = 0; i < W; i = i + 1) begin : mk
        assign mask[i] = right ? (i < W - amt) : (i >= amt);
      end
    end else if (MASKGEN == 1) begin : two_thermo
      // the field kept lies between a low and a high bound: [amt, W-1] for a left shift,
      // [0, W-1-amt] for a right one; each bound is a thermometer, the mask their AND. The
      // high bound is signed: a right amount at or past W (an amount code W leaves the whole
      // word when W is below a power of two) puts it below zero, and no bit is kept
      logic [AW:0] lo;
      logic signed [AW+1:0] hi;
      assign lo = right ? {(AW+1){1'b0}} : {1'b0, amt};
      assign hi = right ? ($signed(W - 1) - $signed({2'b00, amt})) : $signed(W - 1);
      logic [W-1:0] ge_lo, le_hi;
      for (i = 0; i < W; i = i + 1) begin : mk
        assign ge_lo[i] = (i >= lo);
        assign le_hi[i] = (hi >= 0) && (i <= hi);
      end
      assign mask = ge_lo & le_hi;
    end else begin : lut
      // the mask read from a table over the direction and the amount
      logic [AW:0] idx;
      assign idx = {right, amt};
      logic [W-1:0] tab [0:2*(1<<AW)-1];
      for (i = 0; i < 2 * (1 << AW); i = i + 1) begin : t
        localparam int RT = i >> AW;
        localparam int AM = i & ((1 << AW) - 1);
        genvar j;
        for (j = 0; j < W; j = j + 1) begin : bt
          assign tab[i][j] = RT ? (j < W - AM) : (j >= AM);
        end
      end
      assign mask = tab[idx];
    end
  endgenerate
  logic [W-1:0] mask_unused;
  fam_shift_keep_mask #(.W(W), .STICKY(STICKY)) u_sticky (.a(a), .amt(amt), .right(right), .rot(rot), .mask(mask_unused), .sticky(sticky));
  generate
    if (MERGE == 0) begin : and_or
      assign y = rot ? st[NS] : ((st[NS] & mask) | ({W{fill}} & ~mask));
    end else begin : per_bit
      for (i = 0; i < W; i = i + 1) begin : mx
        assign y[i] = (rot | mask[i]) ? st[NS][i] : fill;
      end
    end
  endgenerate
endmodule

// The shifter families of chiALU. One interface:
//   #(parameter int W) (input [W-1:0] a, input [AW-1:0] amt, input [2:0] op, output [W-1:0] y)
// op: 0 shl, 1 shr_logical, 2 shr_arith, 3 rol, 4 ror; amt is below W.
// Every family has `output sticky`, the OR of the bits a shift moves out (0 for a rotate), built
// when STICKY = 1 (the sticky_collect choice; an alignment shifter asks for it) and tied to 0
// otherwise; a consumer that does not collect it leaves the port unconnected.

// ------------------------------------------------------------------ one mux stage
// One stage of a shifter: the K-bit digit of the amount selects among R = 2^K
// candidates, candidate d being the input displaced by d * 2^SH to the left
// (RIGHT = 0) or to the right (RIGHT = 1), the vacated bits taken from the
// other end under `rot` or from `fill`. ONE_HOT = 1 decodes the digit to R
// select lines and forms the mux as an AND-OR (the select_encoding choice);
// ONE_HOT = 0 indexes the candidates by the binary digit.
module fam_shift_stage #(parameter int W = 16, parameter int K = 1, parameter int SH = 0,
                         parameter int RIGHT = 0, parameter int ONE_HOT = 0)
  (input logic [W-1:0] x, input logic [K-1:0] digit, input logic rot, input logic fill, output logic [W-1:0] y);
  localparam int R = 1 << K;
  localparam int D = 1 << SH;
  logic [W*R-1:0] cand;                       // candidate d at [d*W +: W]
  genvar d, i;
  generate
    for (d = 0; d < R; d = d + 1) begin : c
      for (i = 0; i < W; i = i + 1) begin : b
        localparam int S = d * D;             // the displacement of this candidate
        if (S >= W) begin : far
          // a displacement past the word: a rotate wraps it (mod W), a shift clears the word
          localparam int IDX = ((RIGHT ? (i + S) : (i - S)) % W + W) % W;
          assign cand[d*W + i] = rot ? x[IDX] : fill;
        end else if (RIGHT) begin : r
          if (i + S < W) begin : in_
            assign cand[d*W + i] = x[i + S];
          end else begin : out_
            assign cand[d*W + i] = rot ? x[i + S - W] : fill;
          end
        end else begin : l
          if (i >= S) begin : in_
            assign cand[d*W + i] = x[i - S];
          end else begin : out_
            assign cand[d*W + i] = rot ? x[W - S + i] : fill;
          end
        end
      end
    end
    if (ONE_HOT) begin : onehot
      logic [R-1:0] sel;
      for (d = 0; d < R; d = d + 1) begin : dec
        assign sel[d] = (digit == d);
      end
      for (i = 0; i < W; i = i + 1) begin : orb
        logic [R-1:0] t;
        for (d = 0; d < R; d = d + 1) begin : and_
          assign t[d] = sel[d] & cand[d*W + i];
        end
        assign y[i] = |t;
      end
    end else begin : binary
      assign y = cand[digit*W +: W];
    end
  endgenerate
endmodule
