// ADIR-MEMBER packages
// alu_core_m0_pkg: the exact-arithmetic functions of mode 0 (1xint16_twos_complement)
package alu_core_m0_pkg;

  // ---- m0: V = {special[1:0], sign, exp[8] (signed), sig[17]}
  //           X = {special[1:0], sign, exp[8] (signed), sig[38], sticky}
  localparam int m0_SW = 17, m0_EW = 8, m0_XW = 38;
  localparam int m0_VW = 28, m0_XT = 50;
  function automatic [27:0] m0_mkv(input [1:0] sp, input s, input signed [7:0] e, input [16:0] sig);
    m0_mkv = {sp, s, e, sig};
  endfunction
  function automatic [49:0] m0_mkx(input [1:0] sp, input s, input signed [7:0] e, input [37:0] sig, input st);
    m0_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [49:0] m0_x(input [27:0] v);   // widen V to X
    m0_x = {v[27:27-1], v[27-2], v[27-3 -: 8], {{(38-17){1'b0}}, v[16:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [49:0] m0_norm(input [49:0] x);
    logic [37:0] s; logic signed [7:0] e; integer k;
    s = x[38:1]; e = x[38+8:38+1];
    if (s != 0) begin
      for (k = 32; k >= 1; k = k / 2) begin
        if (k < 38) begin
          if (s[37 -: 1] == 1'b0 && (s >> (38 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m0_norm = {x[49:49-1], x[49-2], e, s, x[0]};
  endfunction

  function automatic m0_rup(input [2:0] rnd, input s, input inexact, input [38:0] rest, input [38:0] halfv,
                             input st, input lsb, input [38+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m0_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m0_rup = 1'b0;
      3'd2: m0_rup = inexact && s;
      3'd3: m0_rup = inexact && !s;
      3'd4: m0_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m0_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [49:0] m0_add(input [49:0] a, input [49:0] b, input sub);
    logic [49:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [7:0] ea, eb, d; logic [38:0] ms, mb, r; logic st, stb; integer sh;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1];
    sa = na[49-2]; sb = nb[49-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m0_add = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m0_add = (sa == sb) ? m0_mkx(2'd2, sa, 0, 0, 1'b0) : m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_add = m0_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m0_add = m0_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[38:1] == 0 && !na[0]) m0_add = {nb[49:49-1], sb, nb[49-3:0]};
    else if (nb[38:1] == 0 && !nb[0]) m0_add = na;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[38:1] >= nb[38:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[38+8:38+1] - sml[38+8:38+1];
      ms = {1'b0, sml[38:1]}; stb = sml[0];
      if (d > 38 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 38 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[38:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[38]) begin st = st | r[0]; r = r >> 1; m0_add = m0_mkx(2'd0, sr, big[38+8:38+1] + 1, r[37:0], st); end
      else m0_add = m0_mkx(2'd0, sr, big[38+8:38+1], r[37:0], st);
    end
  endfunction
  function automatic [49:0] m0_mul(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38-1:0] pr; logic st; integer k;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m0_mul = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[38:1] == 0 && !na[0]) || (spb == 2'd0 && nb[38:1] == 0 && !nb[0]))
        m0_mul = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m0_mul = m0_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[38:1] * nb[38:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[37:0] != 0);
      m0_mul = m0_mkx(2'd0, s, na[38+8:38+1] + nb[38+8:38+1] + 38, pr[2*38-1:38], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*38+1:0] m0_udiv(input [37:0] a, input [37:0] dv);
    logic [38+1:0] r; logic [38:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 38; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[37:0], ge};
      if (i > 0) r = {r[38:0], 1'b0};
    end
    m0_udiv = {q, r[38:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*38+8+2:0] m0_mulx(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*38-1:0] pr;
    na = m0_norm(a); nb = m0_norm(b);
    pr = na[38:1] * nb[38:1];
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[38:1] == 0) || (spb == 2'd0 && nb[38:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m0_mulx = {sp, s, na[38+8:38+1] + nb[38+8:38+1], pr};
  endfunction
  function automatic [49:0] m0_div(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38+1:0] qr; logic [38:0] q, r;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_div = m0_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m0_div = m0_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[38:1] == 0 && !nb[0]) begin
      if (na[38:1] == 0 && !na[0]) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m0_div = m0_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[38:1] == 0 && !na[0]) m0_div = m0_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m0_udiv(na[38:1], nb[38:1]);     // both normalized: nonzero finite
      q = qr[2*38+1:38+1]; r = qr[38:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[38]) m0_div = m0_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38 + 1, q[38:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m0_div = m0_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38, q[37:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [49:0] m0_sqrt(input [49:0] a);
    logic [49:0] na; logic [1:0] spa; logic signed [7:0] e; logic [38:0] m; logic [2*38+3:0] rad;
    logic [38+2:0] rem, trial; logic [38:0] root; logic ge; integer i;
    na = m0_norm(a); spa = na[49:49-1];
    if (spa == 2'd1) m0_sqrt = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_sqrt = na[49-2] ? m0_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[38:1] == 0 && !na[0]) m0_sqrt = na;
    else if (na[49-2]) m0_sqrt = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[38+8:38+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[38:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[38:1]};
      rad = {{(38+3){1'b0}}, m} << 38;
      rem = 0; root = 0;
      for (i = 38; i >= 0; i = i - 1) begin
        rem = {rem[38:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[37:0], ge};
      end
      m0_sqrt = m0_mkx(2'd0, 1'b0, (e >>> 1) - 19 + 1, root[38:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m0_lt(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [7:0] ea, eb;
    na = m0_norm(a); nb = m0_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    sa = na[49-2] && !za; sb = nb[49-2] && !zb;
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m0_lt = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2) begin
      if (na[49:49-1] == 2'd2 && nb[49:49-1] == 2'd2) m0_lt = na[49-2] && !nb[49-2];
      else if (na[49:49-1] == 2'd2) m0_lt = na[49-2];
      else m0_lt = !nb[49-2];
    end else if (za && zb) m0_lt = 1'b0;
    else if (sa != sb) m0_lt = sa;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[38:1] < nb[38:1] || (na[38:1] == nb[38:1] && !na[0] && nb[0])));
      m0_lt = sa ? !mag_lt && !(za && zb) && !m0_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m0_eq(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb;
    na = m0_norm(a); nb = m0_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m0_eq = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2)
      m0_eq = (na[49:49-1] == nb[49:49-1]) && (na[49-2] == nb[49-2]);
    else if (za || zb) m0_eq = za && zb;
    else m0_eq = (na[49-2] == nb[49-2]) && (na[38+8:38+1] == nb[38+8:38+1]) && (na[38:1] == nb[38:1]) && (na[0] == nb[0]);
  endfunction

  function automatic [28:0] m0_unpack_s(input [15:0] b, input daz);
    logic s; logic [15:0] mag; integer i;
    s = b[15]; mag = s ? (~b + 1'b1) : b;
    m0_unpack_s = {1'b0, m0_mkv(2'd0, s && (mag != 0), -0, {{(17-16){1'b0}}, mag})};
  endfunction

  function automatic [15:0] m0_enc(input signed [34:0] v); m0_enc = v[15:0]; endfunction
  function automatic [15:0] m0_wrap(input signed [34:0] v); m0_wrap = v[15:0]; endfunction
  function automatic [15:0] m0_sat(input signed [34:0] v);
    m0_sat = (v > 35'sd32767) ? {1'b0, {15{1'b1}}} : (v < -35'sd32768) ? {1'b1, {15{1'b0}}} : v[15:0];
  endfunction

  // round v / 2^f under rnd (the SR word applies to the fraction bits)
  function automatic signed [34:0] m0_rshift(input signed [34:0] v, input integer f, input [2:0] rnd, input [7:0] word);
    logic s; logic [34:0] mag, keep, rest, halfv; logic [43:0] fint; logic up, inexact;
    s = v < 0; mag = s ? -v : v;
    if (f <= 0) m0_rshift = v;
    else begin
      keep = mag >> f; rest = mag & (((35'd1) << f) - 1); halfv = (35'd1) << (f - 1);
      inexact = rest != 0;
      fint = (f >= 8) ? (rest >> (f - 8)) : (rest << (8 - f));
      case (rnd)
        3'd0: up = (rest > halfv) || (rest == halfv && keep[0]);
        3'd1: up = 1'b0;
        3'd2: up = inexact && s;
        3'd3: up = inexact && !s;
        3'd4: up = inexact && (0 ? (fint >= word) : (fint > word));
        default: up = inexact;
      endcase
      keep = keep + up;
      m0_rshift = s ? -$signed(keep) : $signed(keep);
    end
  endfunction
  // the SR word of a division: floor(|r| * 2^sb / |b|)
  function automatic [7:0] m0_divfrac(input [34:0] r, input [34:0] b);
    logic [43:0] t;
    t = ({{9{1'b0}}, r} << 8) / {{9{1'b0}}, b};
    m0_divfrac = t[7:0];
  endfunction
endpackage

// alu_core_m1_pkg: the exact-arithmetic functions of mode 1 (1xint16_unsigned)
package alu_core_m1_pkg;

  // ---- m1: V = {special[1:0], sign, exp[8] (signed), sig[17]}
  //           X = {special[1:0], sign, exp[8] (signed), sig[38], sticky}
  localparam int m1_SW = 17, m1_EW = 8, m1_XW = 38;
  localparam int m1_VW = 28, m1_XT = 50;
  function automatic [27:0] m1_mkv(input [1:0] sp, input s, input signed [7:0] e, input [16:0] sig);
    m1_mkv = {sp, s, e, sig};
  endfunction
  function automatic [49:0] m1_mkx(input [1:0] sp, input s, input signed [7:0] e, input [37:0] sig, input st);
    m1_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [49:0] m1_x(input [27:0] v);   // widen V to X
    m1_x = {v[27:27-1], v[27-2], v[27-3 -: 8], {{(38-17){1'b0}}, v[16:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [49:0] m1_norm(input [49:0] x);
    logic [37:0] s; logic signed [7:0] e; integer k;
    s = x[38:1]; e = x[38+8:38+1];
    if (s != 0) begin
      for (k = 32; k >= 1; k = k / 2) begin
        if (k < 38) begin
          if (s[37 -: 1] == 1'b0 && (s >> (38 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m1_norm = {x[49:49-1], x[49-2], e, s, x[0]};
  endfunction

  function automatic m1_rup(input [2:0] rnd, input s, input inexact, input [38:0] rest, input [38:0] halfv,
                             input st, input lsb, input [38+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m1_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m1_rup = 1'b0;
      3'd2: m1_rup = inexact && s;
      3'd3: m1_rup = inexact && !s;
      3'd4: m1_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m1_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [49:0] m1_add(input [49:0] a, input [49:0] b, input sub);
    logic [49:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [7:0] ea, eb, d; logic [38:0] ms, mb, r; logic st, stb; integer sh;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1];
    sa = na[49-2]; sb = nb[49-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m1_add = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m1_add = (sa == sb) ? m1_mkx(2'd2, sa, 0, 0, 1'b0) : m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_add = m1_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m1_add = m1_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[38:1] == 0 && !na[0]) m1_add = {nb[49:49-1], sb, nb[49-3:0]};
    else if (nb[38:1] == 0 && !nb[0]) m1_add = na;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[38:1] >= nb[38:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[38+8:38+1] - sml[38+8:38+1];
      ms = {1'b0, sml[38:1]}; stb = sml[0];
      if (d > 38 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 38 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[38:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[38]) begin st = st | r[0]; r = r >> 1; m1_add = m1_mkx(2'd0, sr, big[38+8:38+1] + 1, r[37:0], st); end
      else m1_add = m1_mkx(2'd0, sr, big[38+8:38+1], r[37:0], st);
    end
  endfunction
  function automatic [49:0] m1_mul(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38-1:0] pr; logic st; integer k;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m1_mul = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[38:1] == 0 && !na[0]) || (spb == 2'd0 && nb[38:1] == 0 && !nb[0]))
        m1_mul = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m1_mul = m1_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[38:1] * nb[38:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[37:0] != 0);
      m1_mul = m1_mkx(2'd0, s, na[38+8:38+1] + nb[38+8:38+1] + 38, pr[2*38-1:38], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*38+1:0] m1_udiv(input [37:0] a, input [37:0] dv);
    logic [38+1:0] r; logic [38:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 38; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[37:0], ge};
      if (i > 0) r = {r[38:0], 1'b0};
    end
    m1_udiv = {q, r[38:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*38+8+2:0] m1_mulx(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*38-1:0] pr;
    na = m1_norm(a); nb = m1_norm(b);
    pr = na[38:1] * nb[38:1];
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[38:1] == 0) || (spb == 2'd0 && nb[38:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m1_mulx = {sp, s, na[38+8:38+1] + nb[38+8:38+1], pr};
  endfunction
  function automatic [49:0] m1_div(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*38+1:0] qr; logic [38:0] q, r;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[49:49-1]; spb = nb[49:49-1]; s = na[49-2] ^ nb[49-2];
    if (spa == 2'd1 || spb == 2'd1) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_div = m1_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m1_div = m1_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[38:1] == 0 && !nb[0]) begin
      if (na[38:1] == 0 && !na[0]) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m1_div = m1_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[38:1] == 0 && !na[0]) m1_div = m1_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m1_udiv(na[38:1], nb[38:1]);     // both normalized: nonzero finite
      q = qr[2*38+1:38+1]; r = qr[38:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[38]) m1_div = m1_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38 + 1, q[38:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m1_div = m1_mkx(2'd0, s, na[38+8:38+1] - nb[38+8:38+1] - 38, q[37:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [49:0] m1_sqrt(input [49:0] a);
    logic [49:0] na; logic [1:0] spa; logic signed [7:0] e; logic [38:0] m; logic [2*38+3:0] rad;
    logic [38+2:0] rem, trial; logic [38:0] root; logic ge; integer i;
    na = m1_norm(a); spa = na[49:49-1];
    if (spa == 2'd1) m1_sqrt = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_sqrt = na[49-2] ? m1_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[38:1] == 0 && !na[0]) m1_sqrt = na;
    else if (na[49-2]) m1_sqrt = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[38+8:38+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[38:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[38:1]};
      rad = {{(38+3){1'b0}}, m} << 38;
      rem = 0; root = 0;
      for (i = 38; i >= 0; i = i - 1) begin
        rem = {rem[38:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[37:0], ge};
      end
      m1_sqrt = m1_mkx(2'd0, 1'b0, (e >>> 1) - 19 + 1, root[38:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m1_lt(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [7:0] ea, eb;
    na = m1_norm(a); nb = m1_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    sa = na[49-2] && !za; sb = nb[49-2] && !zb;
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m1_lt = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2) begin
      if (na[49:49-1] == 2'd2 && nb[49:49-1] == 2'd2) m1_lt = na[49-2] && !nb[49-2];
      else if (na[49:49-1] == 2'd2) m1_lt = na[49-2];
      else m1_lt = !nb[49-2];
    end else if (za && zb) m1_lt = 1'b0;
    else if (sa != sb) m1_lt = sa;
    else begin
      ea = na[38+8:38+1]; eb = nb[38+8:38+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[38:1] < nb[38:1] || (na[38:1] == nb[38:1] && !na[0] && nb[0])));
      m1_lt = sa ? !mag_lt && !(za && zb) && !m1_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m1_eq(input [49:0] a, input [49:0] b);
    logic [49:0] na, nb; logic za, zb;
    na = m1_norm(a); nb = m1_norm(b);
    za = (na[38:1] == 0) && !na[0]; zb = (nb[38:1] == 0) && !nb[0];
    if (na[49:49-1] == 2'd1 || nb[49:49-1] == 2'd1) m1_eq = 1'b0;
    else if (na[49:49-1] == 2'd2 || nb[49:49-1] == 2'd2)
      m1_eq = (na[49:49-1] == nb[49:49-1]) && (na[49-2] == nb[49-2]);
    else if (za || zb) m1_eq = za && zb;
    else m1_eq = (na[49-2] == nb[49-2]) && (na[38+8:38+1] == nb[38+8:38+1]) && (na[38:1] == nb[38:1]) && (na[0] == nb[0]);
  endfunction

  function automatic [28:0] m1_unpack_s(input [15:0] b, input daz);
    logic s; logic [15:0] mag; integer i;
    s = 1'b0; mag = b;
    m1_unpack_s = {1'b0, m1_mkv(2'd0, s && (mag != 0), -0, {{(17-16){1'b0}}, mag})};
  endfunction

  function automatic [15:0] m1_enc(input signed [34:0] v); m1_enc = v[15:0]; endfunction
  function automatic [15:0] m1_wrap(input signed [34:0] v); m1_wrap = v[15:0]; endfunction
  function automatic [15:0] m1_sat(input signed [34:0] v);
    m1_sat = (v > 35'sd65535) ? {16{1'b1}} : (v < 0) ? 16'd0 : v[15:0];
  endfunction

  // round v / 2^f under rnd (the SR word applies to the fraction bits)
  function automatic signed [34:0] m1_rshift(input signed [34:0] v, input integer f, input [2:0] rnd, input [7:0] word);
    logic s; logic [34:0] mag, keep, rest, halfv; logic [43:0] fint; logic up, inexact;
    s = v < 0; mag = s ? -v : v;
    if (f <= 0) m1_rshift = v;
    else begin
      keep = mag >> f; rest = mag & (((35'd1) << f) - 1); halfv = (35'd1) << (f - 1);
      inexact = rest != 0;
      fint = (f >= 8) ? (rest >> (f - 8)) : (rest << (8 - f));
      case (rnd)
        3'd0: up = (rest > halfv) || (rest == halfv && keep[0]);
        3'd1: up = 1'b0;
        3'd2: up = inexact && s;
        3'd3: up = inexact && !s;
        3'd4: up = inexact && (0 ? (fint >= word) : (fint > word));
        default: up = inexact;
      endcase
      keep = keep + up;
      m1_rshift = s ? -$signed(keep) : $signed(keep);
    end
  endfunction
  // the SR word of a division: floor(|r| * 2^sb / |b|)
  function automatic [7:0] m1_divfrac(input [34:0] r, input [34:0] b);
    logic [43:0] t;
    t = ({{9{1'b0}}, r} << 8) / {{9{1'b0}}, b};
    m1_divfrac = t[7:0];
  endfunction
endpackage

// alu_core_m2_pkg: the exact-arithmetic functions of mode 2 (2xint8_twos_complement)
package alu_core_m2_pkg;

  // ---- m2: V = {special[1:0], sign, exp[8] (signed), sig[9]}
  //           X = {special[1:0], sign, exp[8] (signed), sig[22], sticky}
  localparam int m2_SW = 9, m2_EW = 8, m2_XW = 22;
  localparam int m2_VW = 20, m2_XT = 34;
  function automatic [19:0] m2_mkv(input [1:0] sp, input s, input signed [7:0] e, input [8:0] sig);
    m2_mkv = {sp, s, e, sig};
  endfunction
  function automatic [33:0] m2_mkx(input [1:0] sp, input s, input signed [7:0] e, input [21:0] sig, input st);
    m2_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [33:0] m2_x(input [19:0] v);   // widen V to X
    m2_x = {v[19:19-1], v[19-2], v[19-3 -: 8], {{(22-9){1'b0}}, v[8:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [33:0] m2_norm(input [33:0] x);
    logic [21:0] s; logic signed [7:0] e; integer k;
    s = x[22:1]; e = x[22+8:22+1];
    if (s != 0) begin
      for (k = 16; k >= 1; k = k / 2) begin
        if (k < 22) begin
          if (s[21 -: 1] == 1'b0 && (s >> (22 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m2_norm = {x[33:33-1], x[33-2], e, s, x[0]};
  endfunction

  function automatic m2_rup(input [2:0] rnd, input s, input inexact, input [22:0] rest, input [22:0] halfv,
                             input st, input lsb, input [22+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m2_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m2_rup = 1'b0;
      3'd2: m2_rup = inexact && s;
      3'd3: m2_rup = inexact && !s;
      3'd4: m2_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m2_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [33:0] m2_add(input [33:0] a, input [33:0] b, input sub);
    logic [33:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [7:0] ea, eb, d; logic [22:0] ms, mb, r; logic st, stb; integer sh;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[33:33-1]; spb = nb[33:33-1];
    sa = na[33-2]; sb = nb[33-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m2_add = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m2_add = (sa == sb) ? m2_mkx(2'd2, sa, 0, 0, 1'b0) : m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_add = m2_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m2_add = m2_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[22:1] == 0 && !na[0]) m2_add = {nb[33:33-1], sb, nb[33-3:0]};
    else if (nb[22:1] == 0 && !nb[0]) m2_add = na;
    else begin
      ea = na[22+8:22+1]; eb = nb[22+8:22+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[22:1] >= nb[22:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[22+8:22+1] - sml[22+8:22+1];
      ms = {1'b0, sml[22:1]}; stb = sml[0];
      if (d > 22 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 22 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[22:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[22]) begin st = st | r[0]; r = r >> 1; m2_add = m2_mkx(2'd0, sr, big[22+8:22+1] + 1, r[21:0], st); end
      else m2_add = m2_mkx(2'd0, sr, big[22+8:22+1], r[21:0], st);
    end
  endfunction
  function automatic [33:0] m2_mul(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*22-1:0] pr; logic st; integer k;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[33:33-1]; spb = nb[33:33-1]; s = na[33-2] ^ nb[33-2];
    if (spa == 2'd1 || spb == 2'd1) m2_mul = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[22:1] == 0 && !na[0]) || (spb == 2'd0 && nb[22:1] == 0 && !nb[0]))
        m2_mul = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m2_mul = m2_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[22:1] * nb[22:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[21:0] != 0);
      m2_mul = m2_mkx(2'd0, s, na[22+8:22+1] + nb[22+8:22+1] + 22, pr[2*22-1:22], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*22+1:0] m2_udiv(input [21:0] a, input [21:0] dv);
    logic [22+1:0] r; logic [22:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 22; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[21:0], ge};
      if (i > 0) r = {r[22:0], 1'b0};
    end
    m2_udiv = {q, r[22:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*22+8+2:0] m2_mulx(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*22-1:0] pr;
    na = m2_norm(a); nb = m2_norm(b);
    pr = na[22:1] * nb[22:1];
    spa = na[33:33-1]; spb = nb[33:33-1]; s = na[33-2] ^ nb[33-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[22:1] == 0) || (spb == 2'd0 && nb[22:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m2_mulx = {sp, s, na[22+8:22+1] + nb[22+8:22+1], pr};
  endfunction
  function automatic [33:0] m2_div(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*22+1:0] qr; logic [22:0] q, r;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[33:33-1]; spb = nb[33:33-1]; s = na[33-2] ^ nb[33-2];
    if (spa == 2'd1 || spb == 2'd1) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_div = m2_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m2_div = m2_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[22:1] == 0 && !nb[0]) begin
      if (na[22:1] == 0 && !na[0]) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m2_div = m2_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[22:1] == 0 && !na[0]) m2_div = m2_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m2_udiv(na[22:1], nb[22:1]);     // both normalized: nonzero finite
      q = qr[2*22+1:22+1]; r = qr[22:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[22]) m2_div = m2_mkx(2'd0, s, na[22+8:22+1] - nb[22+8:22+1] - 22 + 1, q[22:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m2_div = m2_mkx(2'd0, s, na[22+8:22+1] - nb[22+8:22+1] - 22, q[21:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [33:0] m2_sqrt(input [33:0] a);
    logic [33:0] na; logic [1:0] spa; logic signed [7:0] e; logic [22:0] m; logic [2*22+3:0] rad;
    logic [22+2:0] rem, trial; logic [22:0] root; logic ge; integer i;
    na = m2_norm(a); spa = na[33:33-1];
    if (spa == 2'd1) m2_sqrt = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_sqrt = na[33-2] ? m2_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[22:1] == 0 && !na[0]) m2_sqrt = na;
    else if (na[33-2]) m2_sqrt = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[22+8:22+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[22:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[22:1]};
      rad = {{(22+3){1'b0}}, m} << 22;
      rem = 0; root = 0;
      for (i = 22; i >= 0; i = i - 1) begin
        rem = {rem[22:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[21:0], ge};
      end
      m2_sqrt = m2_mkx(2'd0, 1'b0, (e >>> 1) - 11 + 1, root[22:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m2_lt(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [7:0] ea, eb;
    na = m2_norm(a); nb = m2_norm(b);
    za = (na[22:1] == 0) && !na[0]; zb = (nb[22:1] == 0) && !nb[0];
    sa = na[33-2] && !za; sb = nb[33-2] && !zb;
    if (na[33:33-1] == 2'd1 || nb[33:33-1] == 2'd1) m2_lt = 1'b0;
    else if (na[33:33-1] == 2'd2 || nb[33:33-1] == 2'd2) begin
      if (na[33:33-1] == 2'd2 && nb[33:33-1] == 2'd2) m2_lt = na[33-2] && !nb[33-2];
      else if (na[33:33-1] == 2'd2) m2_lt = na[33-2];
      else m2_lt = !nb[33-2];
    end else if (za && zb) m2_lt = 1'b0;
    else if (sa != sb) m2_lt = sa;
    else begin
      ea = na[22+8:22+1]; eb = nb[22+8:22+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[22:1] < nb[22:1] || (na[22:1] == nb[22:1] && !na[0] && nb[0])));
      m2_lt = sa ? !mag_lt && !(za && zb) && !m2_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m2_eq(input [33:0] a, input [33:0] b);
    logic [33:0] na, nb; logic za, zb;
    na = m2_norm(a); nb = m2_norm(b);
    za = (na[22:1] == 0) && !na[0]; zb = (nb[22:1] == 0) && !nb[0];
    if (na[33:33-1] == 2'd1 || nb[33:33-1] == 2'd1) m2_eq = 1'b0;
    else if (na[33:33-1] == 2'd2 || nb[33:33-1] == 2'd2)
      m2_eq = (na[33:33-1] == nb[33:33-1]) && (na[33-2] == nb[33-2]);
    else if (za || zb) m2_eq = za && zb;
    else m2_eq = (na[33-2] == nb[33-2]) && (na[22+8:22+1] == nb[22+8:22+1]) && (na[22:1] == nb[22:1]) && (na[0] == nb[0]);
  endfunction

  function automatic [20:0] m2_unpack_s(input [7:0] b, input daz);
    logic s; logic [7:0] mag; integer i;
    s = b[7]; mag = s ? (~b + 1'b1) : b;
    m2_unpack_s = {1'b0, m2_mkv(2'd0, s && (mag != 0), -0, {{(9-8){1'b0}}, mag})};
  endfunction

  function automatic [7:0] m2_enc(input signed [18:0] v); m2_enc = v[7:0]; endfunction
  function automatic [7:0] m2_wrap(input signed [18:0] v); m2_wrap = v[7:0]; endfunction
  function automatic [7:0] m2_sat(input signed [18:0] v);
    m2_sat = (v > 19'sd127) ? {1'b0, {7{1'b1}}} : (v < -19'sd128) ? {1'b1, {7{1'b0}}} : v[7:0];
  endfunction

  // round v / 2^f under rnd (the SR word applies to the fraction bits)
  function automatic signed [18:0] m2_rshift(input signed [18:0] v, input integer f, input [2:0] rnd, input [7:0] word);
    logic s; logic [18:0] mag, keep, rest, halfv; logic [27:0] fint; logic up, inexact;
    s = v < 0; mag = s ? -v : v;
    if (f <= 0) m2_rshift = v;
    else begin
      keep = mag >> f; rest = mag & (((19'd1) << f) - 1); halfv = (19'd1) << (f - 1);
      inexact = rest != 0;
      fint = (f >= 8) ? (rest >> (f - 8)) : (rest << (8 - f));
      case (rnd)
        3'd0: up = (rest > halfv) || (rest == halfv && keep[0]);
        3'd1: up = 1'b0;
        3'd2: up = inexact && s;
        3'd3: up = inexact && !s;
        3'd4: up = inexact && (0 ? (fint >= word) : (fint > word));
        default: up = inexact;
      endcase
      keep = keep + up;
      m2_rshift = s ? -$signed(keep) : $signed(keep);
    end
  endfunction
  // the SR word of a division: floor(|r| * 2^sb / |b|)
  function automatic [7:0] m2_divfrac(input [18:0] r, input [18:0] b);
    logic [27:0] t;
    t = ({{9{1'b0}}, r} << 8) / {{9{1'b0}}, b};
    m2_divfrac = t[7:0];
  endfunction
endpackage
// ADIR-MEMBER top
// EVOLVE-BLOCK-START
// ADIR-DECL v1
// VAR core.adder.m0.family=carry_lookahead
// VAR core.adder.m0.group_size=7
// VAR core.adder.m0.intergroup_carry=lookahead
// VAR core.adder.m1.family=sparse_prefix_hybrid
// VAR core.adder.m1.log2_sparsity=2
// VAR core.adder.m1.tree_topology=kogge_stone
// VAR core.adder.m1.sum_block_style=conditional_sum
// VAR core.adder.m2.family=sparse_prefix_hybrid
// VAR core.adder.m2.log2_sparsity=1
// VAR core.adder.m2.sum_block_style=ripple_precompute
// VAR core.adder.m2.sum_block.full_adder_logic=two_half_adders_or
// VAR core.multiplier.m0.family=direct_pp_parallel
// VAR core.multiplier.m0.reduction.geometry=wallace
// VAR core.multiplier.m0.reduction.counter_kind=7_3
// VAR core.multiplier.m0.reduction.cpa.adder.family=carry_increment
// VAR core.multiplier.m0.reduction.cpa.adder.intergroup_carry=rippled
// VAR core.multiplier.m0.reduction.cpa.adder.block_adder.family=parallel_prefix
// VAR core.multiplier.m0.reduction.cpa.adder.block_adder.topology=han_carlson
// VAR core.multiplier.m0.reduction.cpa.adder.increment_stage.structure=select_blocks
// VAR core.multiplier.m0.hard_multiple_adder.full_adder_logic=two_half_adders_or
// VAR core.multiplier.m1.family=squarer
// VAR core.multiplier.m1.folding_scheme=divide_and_conquer
// VAR core.multiplier.m1.reduction.family=compressor_4_2_tree
// VAR core.multiplier.m1.reduction.compressor_kind=stacking_6_3
// VAR core.multiplier.m1.reduction.cpa.family=hybrid_arrival_driven
// VAR core.multiplier.m1.reduction.cpa.region_count=3
// VAR core.multiplier.m1.reduction.cpa.region_adder_mix=ripple_cla_select
// VAR core.multiplier.m1.reduction.cpa.boundary_search=delay_bound_boundary_enumeration
// VAR core.multiplier.m1.cross.group_bits=2
// VAR core.multiplier.m1.cross.reduction.family=tiled_cpa_reduction_tree
// VAR core.multiplier.m1.cross.reduction.adder_width=8
// VAR core.multiplier.m1.cross.reduction.carry_assimilation=staggered_tiling
// VAR core.multiplier.m1.cross.reduction.terminal_reduction=compressor_4_2
// VAR core.multiplier.m1.cross.reduction.cpa.family=hybrid_arrival_driven
// VAR core.multiplier.m1.cross.reduction.cpa.region_count=4
// VAR core.multiplier.m1.cross.reduction.cpa.region_adder_mix=vba_select_cla_select_vba
// VAR core.multiplier.m1.cross.reduction.tile_adder.family=prefix_synthesis_nonuniform_arrival
// VAR core.multiplier.m1.cross.reduction.tile_adder.arrival_profile=msb_late
// VAR core.multiplier.m1.cross.hard_multiple_adder.family=prefix_synthesis_nonuniform_arrival
// VAR core.multiplier.m1.cross.hard_multiple_adder.arrival_profile=msb_late
// VAR core.multiplier.m1.pre_adder.family=compound_flagged_prefix
// VAR core.multiplier.m1.pre_adder.topology=harris
// VAR core.multiplier.m1.pre_adder.log2_sparsity=1
// VAR core.multiplier.m1.pre_adder.fanout_cap=4
// VAR core.multiplier.m1.pre_adder.implementation=flag_row
// VAR core.multiplier.m1.pre_adder.late_carry_in=true
// VAR core.multiplier.m2.family=recursive_karatsuba
// VAR core.multiplier.m2.recursion_depth=3
// VAR core.multiplier.m2.reduction.geometry=balanced_delay
// VAR core.multiplier.m2.reduction.counter_kind=7_3
// VAR core.multiplier.m2.reduction.cpa.adder.family=carry_select
// VAR core.multiplier.m2.reduction.cpa.adder.select_source=lookahead_tree
// VAR core.multiplier.m2.reduction.cpa.adder.block_adder.full_adder_logic=half_sum_mux_carry
// VAR core.multiplier.m2.adder.family=sparse_prefix_hybrid
// VAR core.multiplier.m2.adder.log2_sparsity=1
// VAR core.multiplier.m2.adder.sum_block_style=ripple_precompute
// VAR core.multiplier.m2.adder.sum_block.family=parallel_prefix
// VAR core.multiplier.m2.adder.sum_block.valency=4
// VAR core.shifter.m0.family=butterfly_network
// VAR core.shifter.m1.family=masked_merged
// VAR core.shifter.m1.merge_style=per_bit_mux
// VAR core.shifter.m1.rotator.stage_radix=8
// VAR core.shifter.m1.rotator.select_encoding=one_hot_decoded
// VAR core.shifter.m2.direction_handling=amount_negation
// VAR core.shifter.m2.sticky_collect=true
// VAR core.bitcount.m0.family=trailing_zero
// VAR core.bitcount.m0.isolate_circuit=ripple_kill_chain
// VAR core.bitcount.m0.lzd.family=prefix_lzc
// VAR core.bitcount.m0.lzd.prefix_topology=sklansky
// VAR core.bitcount.m0.lzd.count_form=lookahead_flags
// VAR core.bitcount.m0.lzd.counter.tree_shape=linear_chain
// VAR core.bitcount.m0.lzd.counter.final_adder.family=end_around_carry
// VAR core.bitcount.m0.lzd.counter.final_adder.recirculation=cyclic_prefix_level
// VAR core.bitcount.m0.lzd.counter.final_adder.incrementer.structure=prefix_and_tree
// VAR core.bitcount.m0.negation_incrementer.structure=prefix_and_tree
// VAR core.bitcount.m0.negation_incrementer.topology=kogge_stone
// VAR core.bitcount.m1.family=lzd_cell_tree
// VAR core.bitcount.m1.block_primitive=nibble_cell
// VAR core.bitcount.m1.valid_flag_propagation=true
// VAR core.bitcount.m2.family=trailing_zero
// VAR core.bitcount.m2.strategy=isolate_then_encode
// VAR core.bitcount.m2.lzd.family=prefix_lzc
// VAR core.bitcount.m2.lzd.counter.final_adder.family=conditional_sum
// VAR core.bitcount.m2.negation_incrementer.structure=prefix_and_tree
// VAR core.bitcount.m2.negation_incrementer.topology=kogge_stone
// VAR core.logic.m0.family=wide_gate_row
// VAR core.logic.m1.family=wide_gate_row
// VAR core.logic.m2.family=wide_gate_row
// VAR core.logic.m2.not_via_xor=true
// VAR core.comparator.m0.radix=3
// VAR core.subword.family=replicated_lanes
// STRUCTURE m0.l0.adder kind=adder slot=adder mode=0 lane=0 width=16 format=int16_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m0_l0_adder
// STRUCTURE m0.l0.multiplier kind=multiplier slot=multiplier mode=0 lane=0 width=16 format=int16_twos_complement ops=mul,mul_high sv=alu_core_u_m0_l0_multiplier
// STRUCTURE m0.l0.comparator kind=comparator slot=comparator mode=0 lane=0 width=16 format=int16_twos_complement ops=min,max,cmp sv=alu_core_u_m0_l0_comparator
// STRUCTURE m0.l0.shifter kind=shifter slot=shifter mode=0 lane=0 width=16 format=int16_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m0_l0_shifter
// STRUCTURE m0.l0.logic kind=logic slot=logic mode=0 lane=0 width=16 format=int16_twos_complement ops=and,or,xor,not sv=alu_core_u_m0_l0_logic
// STRUCTURE m0.l0.bitcount kind=bitcount slot=bitcount mode=0 lane=0 width=16 format=int16_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m0_l0_bitcount
// STRUCTURE m1.l0.adder kind=adder slot=adder mode=1 lane=0 width=16 format=int16_unsigned ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m1_l0_adder
// STRUCTURE m1.l0.multiplier kind=multiplier slot=multiplier mode=1 lane=0 width=16 format=int16_unsigned ops=mul,mul_high sv=alu_core_u_m1_l0_multiplier
// STRUCTURE m1.l0.comparator kind=comparator slot=comparator mode=1 lane=0 width=16 format=int16_unsigned ops=min,max,cmp sv=alu_core_u_m1_l0_comparator
// STRUCTURE m1.l0.shifter kind=shifter slot=shifter mode=1 lane=0 width=16 format=int16_unsigned ops=shl,shr_arith,rol sv=alu_core_u_m1_l0_shifter
// STRUCTURE m1.l0.logic kind=logic slot=logic mode=1 lane=0 width=16 format=int16_unsigned ops=and,or,xor,not sv=alu_core_u_m1_l0_logic
// STRUCTURE m1.l0.bitcount kind=bitcount slot=bitcount mode=1 lane=0 width=16 format=int16_unsigned ops=popcount,clz,ctz sv=alu_core_u_m1_l0_bitcount
// STRUCTURE m2.l0.adder kind=adder slot=adder mode=2 lane=0 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m2_l0_adder
// STRUCTURE m2.l1.adder kind=adder slot=adder mode=2 lane=1 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m2_l1_adder
// STRUCTURE m2.l0.multiplier kind=multiplier slot=multiplier mode=2 lane=0 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_m2_l0_multiplier
// STRUCTURE m2.l1.multiplier kind=multiplier slot=multiplier mode=2 lane=1 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_m2_l1_multiplier
// STRUCTURE m2.l0.comparator kind=comparator slot=comparator mode=2 lane=0 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_m2_l0_comparator
// STRUCTURE m2.l1.comparator kind=comparator slot=comparator mode=2 lane=1 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_m2_l1_comparator
// STRUCTURE m2.l0.shifter kind=shifter slot=shifter mode=2 lane=0 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l0_shifter
// STRUCTURE m2.l1.shifter kind=shifter slot=shifter mode=2 lane=1 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l1_shifter
// STRUCTURE m2.l0.logic kind=logic slot=logic mode=2 lane=0 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_m2_l0_logic
// STRUCTURE m2.l1.logic kind=logic slot=logic mode=2 lane=1 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_m2_l1_logic
// STRUCTURE m2.l0.bitcount kind=bitcount slot=bitcount mode=2 lane=0 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l0_bitcount
// STRUCTURE m2.l1.bitcount kind=bitcount slot=bitcount mode=2 lane=1 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l1_bitcount
// ADIR-END
module alu_core (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  output logic [15:0] y,
  output logic [3:0] flags
);
  // alu_core: behavioral reference derived from the instance (modes 1xint16_twos_complement, 1xint16_unsigned, 2xint8_twos_complement; ops add, sub, adc, neg, abs, add_sat, mul, mul_high, min, max, cmp, shl, shr_arith, rol, and, or, xor, not, popcount, clz, ctz). Every (mode, op) pair computes the verify layer's exact semantics.
  // HIERARCHY: 24 physical structure modules instantiated by alu_core, built from 15 lane modules (one per mode and kind, parameter LANE) and 3 packages of engine functions (one per mode); a float mode's datapath is split into an unpacker (the xa/xb/den buses), the arithmetic and converter structures (unrounded results on the x bus) and a rounder (y and the flags); 0 misc lane modules and 0 block-conversion group modules
  // UNIT m0.l0.adder module=alu_core_u_m0_l0_adder kind=adder members=m0.l0.adder
  // UNIT m0.l0.multiplier module=alu_core_u_m0_l0_multiplier kind=multiplier members=m0.l0.multiplier
  // UNIT m0.l0.comparator module=alu_core_u_m0_l0_comparator kind=comparator members=m0.l0.comparator
  // UNIT m0.l0.shifter module=alu_core_u_m0_l0_shifter kind=shifter members=m0.l0.shifter
  // UNIT m0.l0.logic module=alu_core_u_m0_l0_logic kind=logic members=m0.l0.logic
  // UNIT m0.l0.bitcount module=alu_core_u_m0_l0_bitcount kind=bitcount members=m0.l0.bitcount
  // UNIT m1.l0.adder module=alu_core_u_m1_l0_adder kind=adder members=m1.l0.adder
  // UNIT m1.l0.multiplier module=alu_core_u_m1_l0_multiplier kind=multiplier members=m1.l0.multiplier
  // UNIT m1.l0.comparator module=alu_core_u_m1_l0_comparator kind=comparator members=m1.l0.comparator
  // UNIT m1.l0.shifter module=alu_core_u_m1_l0_shifter kind=shifter members=m1.l0.shifter
  // UNIT m1.l0.logic module=alu_core_u_m1_l0_logic kind=logic members=m1.l0.logic
  // UNIT m1.l0.bitcount module=alu_core_u_m1_l0_bitcount kind=bitcount members=m1.l0.bitcount
  // UNIT m2.l0.adder module=alu_core_u_m2_l0_adder kind=adder members=m2.l0.adder
  // UNIT m2.l1.adder module=alu_core_u_m2_l1_adder kind=adder members=m2.l1.adder
  // UNIT m2.l0.multiplier module=alu_core_u_m2_l0_multiplier kind=multiplier members=m2.l0.multiplier
  // UNIT m2.l1.multiplier module=alu_core_u_m2_l1_multiplier kind=multiplier members=m2.l1.multiplier
  // UNIT m2.l0.comparator module=alu_core_u_m2_l0_comparator kind=comparator members=m2.l0.comparator
  // UNIT m2.l1.comparator module=alu_core_u_m2_l1_comparator kind=comparator members=m2.l1.comparator
  // UNIT m2.l0.shifter module=alu_core_u_m2_l0_shifter kind=shifter members=m2.l0.shifter
  // UNIT m2.l1.shifter module=alu_core_u_m2_l1_shifter kind=shifter members=m2.l1.shifter
  // UNIT m2.l0.logic module=alu_core_u_m2_l0_logic kind=logic members=m2.l0.logic
  // UNIT m2.l1.logic module=alu_core_u_m2_l1_logic kind=logic members=m2.l1.logic
  // UNIT m2.l0.bitcount module=alu_core_u_m2_l0_bitcount kind=bitcount members=m2.l0.bitcount
  // UNIT m2.l1.bitcount module=alu_core_u_m2_l1_bitcount kind=bitcount members=m2.l1.bitcount
  // // STRUCTURE m0.l0.adder kind=adder slot=adder mode=0 lane=0 width=16 format=int16_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m0_l0_adder
  // // STRUCTURE m0.l0.multiplier kind=multiplier slot=multiplier mode=0 lane=0 width=16 format=int16_twos_complement ops=mul,mul_high sv=alu_core_u_m0_l0_multiplier
  // // STRUCTURE m0.l0.comparator kind=comparator slot=comparator mode=0 lane=0 width=16 format=int16_twos_complement ops=min,max,cmp sv=alu_core_u_m0_l0_comparator
  // // STRUCTURE m0.l0.shifter kind=shifter slot=shifter mode=0 lane=0 width=16 format=int16_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m0_l0_shifter
  // // STRUCTURE m0.l0.logic kind=logic slot=logic mode=0 lane=0 width=16 format=int16_twos_complement ops=and,or,xor,not sv=alu_core_u_m0_l0_logic
  // // STRUCTURE m0.l0.bitcount kind=bitcount slot=bitcount mode=0 lane=0 width=16 format=int16_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m0_l0_bitcount
  // // STRUCTURE m1.l0.adder kind=adder slot=adder mode=1 lane=0 width=16 format=int16_unsigned ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m1_l0_adder
  // // STRUCTURE m1.l0.multiplier kind=multiplier slot=multiplier mode=1 lane=0 width=16 format=int16_unsigned ops=mul,mul_high sv=alu_core_u_m1_l0_multiplier
  // // STRUCTURE m1.l0.comparator kind=comparator slot=comparator mode=1 lane=0 width=16 format=int16_unsigned ops=min,max,cmp sv=alu_core_u_m1_l0_comparator
  // // STRUCTURE m1.l0.shifter kind=shifter slot=shifter mode=1 lane=0 width=16 format=int16_unsigned ops=shl,shr_arith,rol sv=alu_core_u_m1_l0_shifter
  // // STRUCTURE m1.l0.logic kind=logic slot=logic mode=1 lane=0 width=16 format=int16_unsigned ops=and,or,xor,not sv=alu_core_u_m1_l0_logic
  // // STRUCTURE m1.l0.bitcount kind=bitcount slot=bitcount mode=1 lane=0 width=16 format=int16_unsigned ops=popcount,clz,ctz sv=alu_core_u_m1_l0_bitcount
  // // STRUCTURE m2.l0.adder kind=adder slot=adder mode=2 lane=0 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m2_l0_adder
  // // STRUCTURE m2.l1.adder kind=adder slot=adder mode=2 lane=1 width=8 format=int8_twos_complement ops=add,sub,adc,neg,abs,add_sat sv=alu_core_u_m2_l1_adder
  // // STRUCTURE m2.l0.multiplier kind=multiplier slot=multiplier mode=2 lane=0 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_m2_l0_multiplier
  // // STRUCTURE m2.l1.multiplier kind=multiplier slot=multiplier mode=2 lane=1 width=8 format=int8_twos_complement ops=mul,mul_high sv=alu_core_u_m2_l1_multiplier
  // // STRUCTURE m2.l0.comparator kind=comparator slot=comparator mode=2 lane=0 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_m2_l0_comparator
  // // STRUCTURE m2.l1.comparator kind=comparator slot=comparator mode=2 lane=1 width=8 format=int8_twos_complement ops=min,max,cmp sv=alu_core_u_m2_l1_comparator
  // // STRUCTURE m2.l0.shifter kind=shifter slot=shifter mode=2 lane=0 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l0_shifter
  // // STRUCTURE m2.l1.shifter kind=shifter slot=shifter mode=2 lane=1 width=8 format=int8_twos_complement ops=shl,shr_arith,rol sv=alu_core_u_m2_l1_shifter
  // // STRUCTURE m2.l0.logic kind=logic slot=logic mode=2 lane=0 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_m2_l0_logic
  // // STRUCTURE m2.l1.logic kind=logic slot=logic mode=2 lane=1 width=8 format=int8_twos_complement ops=and,or,xor,not sv=alu_core_u_m2_l1_logic
  // // STRUCTURE m2.l0.bitcount kind=bitcount slot=bitcount mode=2 lane=0 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l0_bitcount
  // // STRUCTURE m2.l1.bitcount kind=bitcount slot=bitcount mode=2 lane=1 width=8 format=int8_twos_complement ops=popcount,clz,ctz sv=alu_core_u_m2_l1_bitcount
  // LIBRARY: fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32, fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2, fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2, fam_adder_carry_lookahead, fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w12, fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w12_component_block_adder_adder_w2, fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w8, fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w8_component_block_adder_adder_w2, fam_adder_carry_select_w12, fam_adder_carry_select_w12_component_block_adder_adder_w4, fam_adder_carry_select_w5, fam_adder_carry_select_w5_component_block_adder_adder_w1, fam_adder_carry_select_w5_component_block_adder_adder_w4, fam_adder_carry_skip_p035b672f454741e836110d2b293e320d2adf30f103464a83f97bd3dfd9837ae4_w5, fam_adder_carry_skip_p035b672f454741e836110d2b293e320d2adf30f103464a83f97bd3dfd9837ae4_w5_component_block_adder_adder_w1, fam_adder_carry_skip_p035b672f454741e836110d2b293e320d2adf30f103464a83f97bd3dfd9837ae4_w5_component_block_adder_adder_w2, fam_adder_cla_level, fam_adder_conditional_sum, fam_adder_ripple_carry, fam_adder_ripple_chunk, fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w16, fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w16_component_sum_block_adder_w2, fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w6, fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w6_component_sum_block_adder_w2, fam_adder_sparse_prefix_hybrid_p36fd82ab953ccb4995a8e1923d6edef046b1089c32e5aac0b4643aeefde6bf91_w8, fam_adder_sparse_prefix_hybrid_p36fd82ab953ccb4995a8e1923d6edef046b1089c32e5aac0b4643aeefde6bf91_w8_component_sum_block_adder_w2, fam_adder_sparse_prefix_hybrid_p80a4980a643e7f96abce420e7211cfd6176603e909f321d18db0975395a28f34_w16, fam_cmp_prefix_comparator, fam_count_lzd_nibble_cell_binary_count_vprop_w16, fam_count_prefix_lzc_sklansky_flags_w16, fam_count_tzc_isolate_then_encode_twos_complement_and_pb78b9_w8, fam_count_tzc_reverse_prefix_lzc_p1c2a0_w16, fam_incr_prefix_and, fam_logic_gate_row, fam_mul_direct_dadda_3_2_w10_s_p586fca89, fam_mul_direct_wallace_7_3_w16_s_p573b4b25, fam_mul_karatsuba_d3_w8_s_pa2efba30, fam_mul_karatsuba_d3_w8_s_pa2efba30_hh_b4s, fam_mul_karatsuba_d3_w8_s_pa2efba30_ll_b4u, fam_mul_karatsuba_d3_w8_s_pa2efba30_mm_b6s, fam_mul_squarer_w16_u_p17507a8b, fam_mul_squarer_w16_u_p17507a8b_sq, fam_prefix_arrival_0_0_1_1_1_2_2_3_3_3_4_4_w12, fam_prefix_arrival_0_0_1_1_2_2_3_3_w8, fam_prefix_arrival_0_1_1_2_w4, fam_prefix_han_carlson_w2, fam_prefix_harris_l1f1_w18_flag_late, fam_prefix_harris_l1f1_w36_flag_late, fam_prefix_net_kogge_stone_w4, fam_prefix_net_sklansky_w3, fam_prefix_net_sklansky_w4, fam_prefix_net_sklansky_w8, fam_prefix_sklansky_w2_v4, fam_shift_barrel_mux_tree, fam_shift_butterfly_network, fam_shift_keep_mask, fam_shift_masked_merged, fam_shift_stage (chialu.targets.rtl.families: the modules of the declared families the lane modules instantiate; their text follows the generated modules)
  logic [2:0] rnd_sel;
  logic [2:0] rnd;
  logic daz;
  logic ftz;
  logic dual;
  logic [15:0] y_m0_m0_l0_adder;
  logic [19:0] fl_m0_m0_l0_adder;
  logic [15:0] y_m0_m0_l0_multiplier;
  logic [19:0] fl_m0_m0_l0_multiplier;
  logic [15:0] y_m0_m0_l0_comparator;
  logic [19:0] fl_m0_m0_l0_comparator;
  logic [15:0] y_m0_m0_l0_shifter;
  logic [19:0] fl_m0_m0_l0_shifter;
  logic [15:0] y_m0_m0_l0_logic;
  logic [19:0] fl_m0_m0_l0_logic;
  logic [15:0] y_m0_m0_l0_bitcount;
  logic [19:0] fl_m0_m0_l0_bitcount;
  logic [15:0] y_m0;
  logic [19:0] fl_m0;
  logic [15:0] y_m1_m1_l0_adder;
  logic [19:0] fl_m1_m1_l0_adder;
  logic [15:0] y_m1_m1_l0_multiplier;
  logic [19:0] fl_m1_m1_l0_multiplier;
  logic [15:0] y_m1_m1_l0_comparator;
  logic [19:0] fl_m1_m1_l0_comparator;
  logic [15:0] y_m1_m1_l0_shifter;
  logic [19:0] fl_m1_m1_l0_shifter;
  logic [15:0] y_m1_m1_l0_logic;
  logic [19:0] fl_m1_m1_l0_logic;
  logic [15:0] y_m1_m1_l0_bitcount;
  logic [19:0] fl_m1_m1_l0_bitcount;
  logic [15:0] y_m1;
  logic [19:0] fl_m1;
  logic [15:0] y_m2_m2_l0_adder;
  logic [19:0] fl_m2_m2_l0_adder;
  logic [15:0] y_m2_m2_l1_adder;
  logic [19:0] fl_m2_m2_l1_adder;
  logic [15:0] y_m2_m2_l0_multiplier;
  logic [19:0] fl_m2_m2_l0_multiplier;
  logic [15:0] y_m2_m2_l1_multiplier;
  logic [19:0] fl_m2_m2_l1_multiplier;
  logic [15:0] y_m2_m2_l0_comparator;
  logic [19:0] fl_m2_m2_l0_comparator;
  logic [15:0] y_m2_m2_l1_comparator;
  logic [19:0] fl_m2_m2_l1_comparator;
  logic [15:0] y_m2_m2_l0_shifter;
  logic [19:0] fl_m2_m2_l0_shifter;
  logic [15:0] y_m2_m2_l1_shifter;
  logic [19:0] fl_m2_m2_l1_shifter;
  logic [15:0] y_m2_m2_l0_logic;
  logic [19:0] fl_m2_m2_l0_logic;
  logic [15:0] y_m2_m2_l1_logic;
  logic [19:0] fl_m2_m2_l1_logic;
  logic [15:0] y_m2_m2_l0_bitcount;
  logic [19:0] fl_m2_m2_l0_bitcount;
  logic [15:0] y_m2_m2_l1_bitcount;
  logic [19:0] fl_m2_m2_l1_bitcount;
  logic [15:0] y_m2;
  logic [19:0] fl_m2;
  logic [19:0] fl_all;
  assign rnd_sel = 3'd0;
  assign rnd = rnd_sel;
  assign daz = 1'b0;
  assign ftz = 1'b0;
  assign dual = 1'b0;
  assign y_m0 = y_m0_m0_l0_adder | y_m0_m0_l0_multiplier | y_m0_m0_l0_comparator | y_m0_m0_l0_shifter | y_m0_m0_l0_logic | y_m0_m0_l0_bitcount;
  assign fl_m0 = fl_m0_m0_l0_adder | fl_m0_m0_l0_multiplier | fl_m0_m0_l0_comparator | fl_m0_m0_l0_shifter | fl_m0_m0_l0_logic | fl_m0_m0_l0_bitcount;
  assign y_m1 = y_m1_m1_l0_adder | y_m1_m1_l0_multiplier | y_m1_m1_l0_comparator | y_m1_m1_l0_shifter | y_m1_m1_l0_logic | y_m1_m1_l0_bitcount;
  assign fl_m1 = fl_m1_m1_l0_adder | fl_m1_m1_l0_multiplier | fl_m1_m1_l0_comparator | fl_m1_m1_l0_shifter | fl_m1_m1_l0_logic | fl_m1_m1_l0_bitcount;
  assign y_m2 = y_m2_m2_l0_adder | y_m2_m2_l1_adder | y_m2_m2_l0_multiplier | y_m2_m2_l1_multiplier | y_m2_m2_l0_comparator | y_m2_m2_l1_comparator | y_m2_m2_l0_shifter | y_m2_m2_l1_shifter | y_m2_m2_l0_logic | y_m2_m2_l1_logic | y_m2_m2_l0_bitcount | y_m2_m2_l1_bitcount;
  assign fl_m2 = fl_m2_m2_l0_adder | fl_m2_m2_l1_adder | fl_m2_m2_l0_multiplier | fl_m2_m2_l1_multiplier | fl_m2_m2_l0_comparator | fl_m2_m2_l1_comparator | fl_m2_m2_l0_shifter | fl_m2_m2_l1_shifter | fl_m2_m2_l0_logic | fl_m2_m2_l1_logic | fl_m2_m2_l0_bitcount | fl_m2_m2_l1_bitcount;
  alu_core_u_m0_l0_adder u_m0_l0_adder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_adder), .fl_m0(fl_m0_m0_l0_adder));
  alu_core_u_m0_l0_multiplier u_m0_l0_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_multiplier), .fl_m0(fl_m0_m0_l0_multiplier));
  alu_core_u_m0_l0_comparator u_m0_l0_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_comparator), .fl_m0(fl_m0_m0_l0_comparator));
  alu_core_u_m0_l0_shifter u_m0_l0_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_shifter), .fl_m0(fl_m0_m0_l0_shifter));
  alu_core_u_m0_l0_logic u_m0_l0_logic (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_logic), .fl_m0(fl_m0_m0_l0_logic));
  alu_core_u_m0_l0_bitcount u_m0_l0_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_bitcount), .fl_m0(fl_m0_m0_l0_bitcount));
  alu_core_u_m1_l0_adder u_m1_l0_adder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_adder), .fl_m1(fl_m1_m1_l0_adder));
  alu_core_u_m1_l0_multiplier u_m1_l0_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_multiplier), .fl_m1(fl_m1_m1_l0_multiplier));
  alu_core_u_m1_l0_comparator u_m1_l0_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_comparator), .fl_m1(fl_m1_m1_l0_comparator));
  alu_core_u_m1_l0_shifter u_m1_l0_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_shifter), .fl_m1(fl_m1_m1_l0_shifter));
  alu_core_u_m1_l0_logic u_m1_l0_logic (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_logic), .fl_m1(fl_m1_m1_l0_logic));
  alu_core_u_m1_l0_bitcount u_m1_l0_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_bitcount), .fl_m1(fl_m1_m1_l0_bitcount));
  alu_core_u_m2_l0_adder u_m2_l0_adder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_adder), .fl_m2(fl_m2_m2_l0_adder));
  alu_core_u_m2_l1_adder u_m2_l1_adder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_adder), .fl_m2(fl_m2_m2_l1_adder));
  alu_core_u_m2_l0_multiplier u_m2_l0_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_multiplier), .fl_m2(fl_m2_m2_l0_multiplier));
  alu_core_u_m2_l1_multiplier u_m2_l1_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_multiplier), .fl_m2(fl_m2_m2_l1_multiplier));
  alu_core_u_m2_l0_comparator u_m2_l0_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_comparator), .fl_m2(fl_m2_m2_l0_comparator));
  alu_core_u_m2_l1_comparator u_m2_l1_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_comparator), .fl_m2(fl_m2_m2_l1_comparator));
  alu_core_u_m2_l0_shifter u_m2_l0_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_shifter), .fl_m2(fl_m2_m2_l0_shifter));
  alu_core_u_m2_l1_shifter u_m2_l1_shifter (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_shifter), .fl_m2(fl_m2_m2_l1_shifter));
  alu_core_u_m2_l0_logic u_m2_l0_logic (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_logic), .fl_m2(fl_m2_m2_l0_logic));
  alu_core_u_m2_l1_logic u_m2_l1_logic (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_logic), .fl_m2(fl_m2_m2_l1_logic));
  alu_core_u_m2_l0_bitcount u_m2_l0_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_bitcount), .fl_m2(fl_m2_m2_l0_bitcount));
  alu_core_u_m2_l1_bitcount u_m2_l1_bitcount (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_bitcount), .fl_m2(fl_m2_m2_l1_bitcount));
  always_comb begin
    case (mode)
      2'd0: begin y = y_m0; fl_all = fl_m0; end
      2'd1: begin y = y_m1; fl_all = fl_m1; end
      2'd2: begin y = y_m2; fl_all = fl_m2; end
      default: begin y = '0; fl_all = '0; end
    endcase
  end
  assign flags[0] = fl_all[7];
  assign flags[1] = fl_all[8];
  assign flags[2] = fl_all[17];
  assign flags[3] = fl_all[18];
endmodule
// EVOLVE-BLOCK-END

module alu_core_m0_adder #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_adder: lane LANE of mode 0 (int16_twos_complement) for the adder ops add, sub, adc, neg, abs, add_sat; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_add_aLANE;
  logic [15:0] m0_add_bLANE;
  logic m0_add_cinLANE;
  logic [15:0] m0_add_sLANE;
  logic m0_add_coutLANE;
  logic signed [34:0] m0_o0ex0_LANE;
  logic signed [34:0] m0_o1ex0_LANE;
  logic signed [34:0] m0_o2ex0_LANE;
  logic signed [34:0] m0_o3ex0_LANE;
  logic signed [34:0] m0_o4ex0_LANE;
  logic signed [34:0] m0_o5ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.adder.m0: family carry_lookahead realized by the library module fam_adder_carry_lookahead
  fam_adder_carry_lookahead #(.W(16), .G(7), .INTER(1), .LEVELS(1)) u_m0_adderLANE (.a(m0_add_aLANE), .b(m0_add_bLANE), .cin(m0_add_cinLANE), .s(m0_add_sLANE), .cout(m0_add_coutLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_add_aLANE = 'x; m0_add_bLANE = 'x; m0_add_cinLANE = 'x; m0_o0ex0_LANE = 'x; m0_o1ex0_LANE = 'x; m0_o2ex0_LANE = 'x;
    m0_o3ex0_LANE = 'x; m0_o4ex0_LANE = 'x; m0_o5ex0_LANE = 'x;
    case (op)
      5'd0: begin
        m0_add_aLANE = m0_aLANE; m0_add_bLANE = m0_bLANE; m0_add_cinLANE = 1'b0;
        m0_o0ex0_LANE = $signed({(m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o0ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (m0_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd1: begin
        m0_add_aLANE = m0_aLANE; m0_add_bLANE = ~m0_bLANE; m0_add_cinLANE = 1'b1;
        m0_o1ex0_LANE = $signed({(m0_aLANE[15] ^ ~m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o1ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ ~m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ ~m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (~m0_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd2: begin
        m0_add_aLANE = m0_aLANE; m0_add_bLANE = m0_bLANE; m0_add_cinLANE = 1'b1;
        m0_o2ex0_LANE = $signed({(m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o2ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (m0_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd3: begin
        m0_add_aLANE = 16'd0; m0_add_bLANE = ~m0_aLANE; m0_add_cinLANE = 1'b1;
        m0_o3ex0_LANE = $signed({(1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o3ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0) | (m0_aLANE != 0 ? (10'd1 << 7) : 10'd0);
      end
      5'd4: begin
        m0_add_aLANE = 16'd0; m0_add_bLANE = ~m0_aLANE; m0_add_cinLANE = 1'b1;
        m0_o4ex0_LANE = (m0_aLANE[15] ? $signed({(1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE), m0_add_sLANE}) : $signed({1'b0, m0_aLANE}));
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o4ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = ((m0_aLANE[15] & ((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15])) ? (10'd1 << 8) : 10'd0) | ((m0_aLANE[15] & ((1'b0 ^ ~m0_aLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15])) ? (10'd1 << 2) : 10'd0);
      end
      5'd5: begin
        m0_add_aLANE = m0_aLANE; m0_add_bLANE = m0_bLANE; m0_add_cinLANE = 1'b0;
        m0_o5ex0_LANE = $signed({(m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE), m0_add_sLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_sat(m0_o5ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (((m0_aLANE[15] ^ m0_bLANE[15] ^ m0_add_coutLANE) ^ m0_add_sLANE[15]) ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_bitcount #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_bitcount: lane LANE of mode 0 (int16_twos_complement) for the bitcount ops popcount, clz, ctz; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_ctz_aLANE;
  logic [4:0] m0_ctz_nLANE;
  logic signed [34:0] m0_o18ex0_LANE;
  logic signed [34:0] m0_o19ex0_LANE;
  logic signed [34:0] m0_o20ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.bitcount.m0: family trailing_zero realized by the library module fam_count_tzc_reverse_prefix_lzc_p1c2a0_w16 (ctz)
  fam_count_tzc_reverse_prefix_lzc_p1c2a0_w16 u_m0_ctzLANE (.a(m0_ctz_aLANE), .n(m0_ctz_nLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_ctz_aLANE = 'x; m0_o18ex0_LANE = 'x; m0_o19ex0_LANE = 'x; m0_o20ex0_LANE = 'x;
    case (op)
      5'd18: begin
        y_m0[((LANE*16)+0) +: 16] = m0_aLANE[0] + m0_aLANE[1] + m0_aLANE[2] + m0_aLANE[3] + m0_aLANE[4] + m0_aLANE[5] + m0_aLANE[6] + m0_aLANE[7] + m0_aLANE[8] + m0_aLANE[9] + m0_aLANE[10] + m0_aLANE[11] + m0_aLANE[12] + m0_aLANE[13] + m0_aLANE[14] + m0_aLANE[15];
      end
      5'd19: begin
        y_m0[((LANE*16)+0) +: 16] = m0_aLANE[15] ? 16'd0 : m0_aLANE[14] ? 16'd1 : m0_aLANE[13] ? 16'd2 : m0_aLANE[12] ? 16'd3 : m0_aLANE[11] ? 16'd4 : m0_aLANE[10] ? 16'd5 : m0_aLANE[9] ? 16'd6 : m0_aLANE[8] ? 16'd7 : m0_aLANE[7] ? 16'd8 : m0_aLANE[6] ? 16'd9 : m0_aLANE[5] ? 16'd10 : m0_aLANE[4] ? 16'd11 : m0_aLANE[3] ? 16'd12 : m0_aLANE[2] ? 16'd13 : m0_aLANE[1] ? 16'd14 : m0_aLANE[0] ? 16'd15 : 16'd16;
      end
      5'd20: begin
        m0_ctz_aLANE = m0_aLANE;
        y_m0[((LANE*16)+0) +: 16] = {{11{1'b0}}, m0_ctz_nLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_comparator #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_comparator: lane LANE of mode 0 (int16_twos_complement) for the comparator ops min, max, cmp; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_cmp_aLANE;
  logic [15:0] m0_cmp_bLANE;
  logic m0_cmp_ltLANE;
  logic m0_cmp_eqLANE;
  logic signed [34:0] m0_o8ex0_LANE;
  logic signed [34:0] m0_o9ex0_LANE;
  logic signed [34:0] m0_o10ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.comparator.m0: family prefix_comparator realized by the library module fam_cmp_prefix_comparator
  fam_cmp_prefix_comparator #(.W(16), .SIGNED(1), .STRUCTURE(0), .RADIX(3)) u_m0_cmpLANE (.a(m0_cmp_aLANE), .b(m0_cmp_bLANE), .lt(m0_cmp_ltLANE), .eq(m0_cmp_eqLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_cmp_aLANE = 'x; m0_cmp_bLANE = 'x; m0_o8ex0_LANE = 'x; m0_o9ex0_LANE = 'x; m0_o10ex0_LANE = 'x;
    case (op)
      5'd8: begin
        m0_cmp_aLANE = m0_aLANE; m0_cmp_bLANE = m0_bLANE;
        y_m0[((LANE*16)+0) +: 16] = (m0_cmp_ltLANE | m0_cmp_eqLANE) ? m0_aLANE : m0_bLANE;
      end
      5'd9: begin
        m0_cmp_aLANE = m0_aLANE; m0_cmp_bLANE = m0_bLANE;
        y_m0[((LANE*16)+0) +: 16] = (~m0_cmp_ltLANE) ? m0_aLANE : m0_bLANE;
      end
      5'd10: begin
        m0_cmp_aLANE = m0_aLANE; m0_cmp_bLANE = m0_bLANE;
        y_m0[((LANE*16)+0) +: 16] = {{13{1'b0}}, (~m0_cmp_ltLANE & ~m0_cmp_eqLANE), m0_cmp_eqLANE, m0_cmp_ltLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_multiplier #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_multiplier: lane LANE of mode 0 (int16_twos_complement) for the multiplier ops mul, mul_high; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_mul_aLANE;
  logic [15:0] m0_mul_bLANE;
  logic [31:0] m0_mul_pLANE;
  logic signed [34:0] m0_o6ex0_LANE;
  logic signed [34:0] m0_o7ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.multiplier.m0: family direct_pp_parallel realized by the library module fam_mul_direct_wallace_7_3_w16_s_p573b4b25
  fam_mul_direct_wallace_7_3_w16_s_p573b4b25 u_m0_mulLANE (.a(m0_mul_aLANE), .b(m0_mul_bLANE), .p(m0_mul_pLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_mul_aLANE = 'x; m0_mul_bLANE = 'x; m0_o6ex0_LANE = 'x; m0_o7ex0_LANE = 'x;
    case (op)
      5'd6: begin
        m0_mul_aLANE = m0_aLANE; m0_mul_bLANE = m0_bLANE;
        m0_o6ex0_LANE = $signed({{3{m0_mul_pLANE[31]}}, m0_mul_pLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o6ex0_LANE);
        fl_m0[(0+LANE)*10 +: 10] = (m0_o6ex0_LANE > 35'sd32767 || m0_o6ex0_LANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m0_o6ex0_LANE > 35'sd32767 || m0_o6ex0_LANE < -35'sd32768 ? (10'd1 << 2) : 10'd0);
      end
      5'd7: begin
        m0_mul_aLANE = m0_aLANE; m0_mul_bLANE = m0_bLANE;
        m0_o7ex0_LANE = $signed({{3{m0_mul_pLANE[31]}}, m0_mul_pLANE});
        y_m0[((LANE*16)+0) +: 16] = m0_wrap(m0_o7ex0_LANE >>> 16);
        fl_m0[(0+LANE)*10 +: 10] = (m0_o7ex0_LANE > 35'sd32767 || m0_o7ex0_LANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m0_o7ex0_LANE > 35'sd32767 || m0_o7ex0_LANE < -35'sd32768 ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_shifter #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_m0_shifter: lane LANE of mode 0 (int16_twos_complement) for the shifter ops shl, shr_arith, rol; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [49:0] m0_xa [0:0];
  logic [49:0] m0_xb [0:0];
  logic signed [16:0] m0_vaLANE;
  logic signed [16:0] m0_vbLANE;
  logic [15:0] m0_sh_aLANE;
  logic [3:0] m0_sh_amtLANE;
  logic [2:0] m0_sh_opLANE;
  logic [15:0] m0_sh_yLANE;
  logic signed [34:0] m0_o11ex0_LANE;
  logic signed [34:0] m0_o12ex0_LANE;
  logic signed [34:0] m0_o13ex0_LANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_xa[LANE] = m0_x(m0_unpack_s(m0_aLANE, 1'b0));
  assign m0_xb[LANE] = m0_x(m0_unpack_s(m0_bLANE, 1'b0));
  assign m0_vaLANE = {m0_aLANE[15], m0_aLANE};
  assign m0_vbLANE = {m0_bLANE[15], m0_bLANE};
  // structure core.shifter.m0: family butterfly_network realized by the library module fam_shift_butterfly_network
  fam_shift_butterfly_network #(.W(16), .NETWORK(0), .STICKY(0)) u_m0_shifterLANE (.a(m0_sh_aLANE), .amt(m0_sh_amtLANE), .op(m0_sh_opLANE), .y(m0_sh_yLANE), .sticky());
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_sh_aLANE = 'x; m0_sh_amtLANE = 'x; m0_sh_opLANE = 'x; m0_o11ex0_LANE = 'x; m0_o12ex0_LANE = 'x; m0_o13ex0_LANE = 'x;
    case (op)
      5'd11: begin
        m0_sh_aLANE = m0_aLANE; m0_sh_amtLANE = 4'(m0_bLANE % 16'd16); m0_sh_opLANE = 3'd0;
        y_m0[((LANE*16)+0) +: 16] = m0_sh_yLANE;
      end
      5'd12: begin
        m0_sh_aLANE = m0_aLANE; m0_sh_amtLANE = 4'(m0_bLANE % 16'd16); m0_sh_opLANE = 3'd2;
        y_m0[((LANE*16)+0) +: 16] = m0_sh_yLANE;
      end
      5'd13: begin
        m0_sh_aLANE = m0_aLANE; m0_sh_amtLANE = 4'(m0_bLANE % 16'd16); m0_sh_opLANE = 3'd3;
        y_m0[((LANE*16)+0) +: 16] = m0_sh_yLANE;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_adder #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_adder: lane LANE of mode 1 (int16_unsigned) for the adder ops add, sub, adc, neg, abs, add_sat; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_add_aLANE;
  logic [15:0] m1_add_bLANE;
  logic m1_add_cinLANE;
  logic [15:0] m1_add_sLANE;
  logic m1_add_coutLANE;
  logic signed [34:0] m1_o0ex0_LANE;
  logic signed [34:0] m1_o1ex0_LANE;
  logic signed [34:0] m1_o2ex0_LANE;
  logic signed [34:0] m1_o3ex0_LANE;
  logic signed [34:0] m1_o4ex0_LANE;
  logic signed [34:0] m1_o4sx0_LANE;
  logic signed [34:0] m1_o5ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.adder.m1: family sparse_prefix_hybrid realized by the library module fam_adder_sparse_prefix_hybrid_p80a4980a643e7f96abce420e7211cfd6176603e909f321d18db0975395a28f34_w16
  fam_adder_sparse_prefix_hybrid_p80a4980a643e7f96abce420e7211cfd6176603e909f321d18db0975395a28f34_w16 u_m1_adderLANE (.a(m1_add_aLANE), .b(m1_add_bLANE), .cin(m1_add_cinLANE), .s(m1_add_sLANE), .cout(m1_add_coutLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_add_aLANE = 'x; m1_add_bLANE = 'x; m1_add_cinLANE = 'x; m1_o0ex0_LANE = 'x; m1_o1ex0_LANE = 'x; m1_o2ex0_LANE = 'x;
    m1_o3ex0_LANE = 'x; m1_o4ex0_LANE = 'x; m1_o4sx0_LANE = 'x; m1_o5ex0_LANE = 'x;
    case (op)
      5'd0: begin
        m1_add_aLANE = m1_aLANE; m1_add_bLANE = m1_bLANE; m1_add_cinLANE = 1'b0;
        m1_o0ex0_LANE = $signed({1'b0, m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o0ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (m1_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd1: begin
        m1_add_aLANE = m1_aLANE; m1_add_bLANE = ~m1_bLANE; m1_add_cinLANE = 1'b1;
        m1_o1ex0_LANE = $signed({~m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o1ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (~m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ ~m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (~m1_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd2: begin
        m1_add_aLANE = m1_aLANE; m1_add_bLANE = m1_bLANE; m1_add_cinLANE = 1'b1;
        m1_o2ex0_LANE = $signed({1'b0, m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o2ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (m1_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd3: begin
        m1_add_aLANE = 16'd0; m1_add_bLANE = ~m1_aLANE; m1_add_cinLANE = 1'b1;
        m1_o3ex0_LANE = $signed({~m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o3ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (~m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((1'b0 ^ ~m1_aLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0) | (m1_aLANE != 0 ? (10'd1 << 7) : 10'd0);
      end
      5'd4: begin
        m1_o4ex0_LANE = (m1_vaLANE < 0) ? -m1_vaLANE : m1_vaLANE;
        m1_o4sx0_LANE = (($signed({m1_aLANE[15], m1_aLANE}) < 0) ? -$signed({m1_aLANE[15], m1_aLANE}) : $signed({m1_aLANE[15], m1_aLANE}));
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o4ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_o4sx0_LANE > 35'sd32767 || m1_o4sx0_LANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m1_o4ex0_LANE > 35'sd65535 || m1_o4ex0_LANE < 0 ? (10'd1 << 2) : 10'd0);
      end
      5'd5: begin
        m1_add_aLANE = m1_aLANE; m1_add_bLANE = m1_bLANE; m1_add_cinLANE = 1'b0;
        m1_o5ex0_LANE = $signed({1'b0, m1_add_coutLANE, m1_add_sLANE});
        y_m1[((LANE*16)+0) +: 16] = m1_sat(m1_o5ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_add_coutLANE ? (10'd1 << 2) : 10'd0) | (((m1_aLANE[15] ^ m1_bLANE[15] ^ m1_add_coutLANE) ^ m1_add_sLANE[15]) ? (10'd1 << 8) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_bitcount #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_bitcount: lane LANE of mode 1 (int16_unsigned) for the bitcount ops popcount, clz, ctz; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_clz_aLANE;
  logic [4:0] m1_clz_nLANE;
  logic signed [34:0] m1_o18ex0_LANE;
  logic signed [34:0] m1_o19ex0_LANE;
  logic signed [34:0] m1_o20ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.bitcount.m1: family lzd_cell_tree realized by the library module fam_count_lzd_nibble_cell_binary_count_vprop_w16 (clz)
  fam_count_lzd_nibble_cell_binary_count_vprop_w16 u_m1_clzLANE (.a(m1_clz_aLANE), .n(m1_clz_nLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_clz_aLANE = 'x; m1_o18ex0_LANE = 'x; m1_o19ex0_LANE = 'x; m1_o20ex0_LANE = 'x;
    case (op)
      5'd18: begin
        y_m1[((LANE*16)+0) +: 16] = m1_aLANE[0] + m1_aLANE[1] + m1_aLANE[2] + m1_aLANE[3] + m1_aLANE[4] + m1_aLANE[5] + m1_aLANE[6] + m1_aLANE[7] + m1_aLANE[8] + m1_aLANE[9] + m1_aLANE[10] + m1_aLANE[11] + m1_aLANE[12] + m1_aLANE[13] + m1_aLANE[14] + m1_aLANE[15];
      end
      5'd19: begin
        m1_clz_aLANE = m1_aLANE;
        y_m1[((LANE*16)+0) +: 16] = {{11{1'b0}}, m1_clz_nLANE};
      end
      5'd20: begin
        y_m1[((LANE*16)+0) +: 16] = m1_aLANE[0] ? 16'd0 : m1_aLANE[1] ? 16'd1 : m1_aLANE[2] ? 16'd2 : m1_aLANE[3] ? 16'd3 : m1_aLANE[4] ? 16'd4 : m1_aLANE[5] ? 16'd5 : m1_aLANE[6] ? 16'd6 : m1_aLANE[7] ? 16'd7 : m1_aLANE[8] ? 16'd8 : m1_aLANE[9] ? 16'd9 : m1_aLANE[10] ? 16'd10 : m1_aLANE[11] ? 16'd11 : m1_aLANE[12] ? 16'd12 : m1_aLANE[13] ? 16'd13 : m1_aLANE[14] ? 16'd14 : m1_aLANE[15] ? 16'd15 : 16'd16;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_comparator #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_comparator: lane LANE of mode 1 (int16_unsigned) for the comparator ops min, max, cmp; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_cmp_aLANE;
  logic [15:0] m1_cmp_bLANE;
  logic m1_cmp_ltLANE;
  logic m1_cmp_eqLANE;
  logic signed [34:0] m1_o8ex0_LANE;
  logic signed [34:0] m1_o9ex0_LANE;
  logic signed [34:0] m1_o10ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.comparator.m1: family prefix_comparator realized by the library module fam_cmp_prefix_comparator
  fam_cmp_prefix_comparator #(.W(16), .SIGNED(0), .STRUCTURE(0), .RADIX(2)) u_m1_cmpLANE (.a(m1_cmp_aLANE), .b(m1_cmp_bLANE), .lt(m1_cmp_ltLANE), .eq(m1_cmp_eqLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_cmp_aLANE = 'x; m1_cmp_bLANE = 'x; m1_o8ex0_LANE = 'x; m1_o9ex0_LANE = 'x; m1_o10ex0_LANE = 'x;
    case (op)
      5'd8: begin
        m1_cmp_aLANE = m1_aLANE; m1_cmp_bLANE = m1_bLANE;
        y_m1[((LANE*16)+0) +: 16] = (m1_cmp_ltLANE | m1_cmp_eqLANE) ? m1_aLANE : m1_bLANE;
      end
      5'd9: begin
        m1_cmp_aLANE = m1_aLANE; m1_cmp_bLANE = m1_bLANE;
        y_m1[((LANE*16)+0) +: 16] = (~m1_cmp_ltLANE) ? m1_aLANE : m1_bLANE;
      end
      5'd10: begin
        m1_cmp_aLANE = m1_aLANE; m1_cmp_bLANE = m1_bLANE;
        y_m1[((LANE*16)+0) +: 16] = {{13{1'b0}}, (~m1_cmp_ltLANE & ~m1_cmp_eqLANE), m1_cmp_eqLANE, m1_cmp_ltLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_multiplier #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_multiplier: lane LANE of mode 1 (int16_unsigned) for the multiplier ops mul, mul_high; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_mul_aLANE;
  logic [15:0] m1_mul_bLANE;
  logic [31:0] m1_mul_pLANE;
  logic signed [34:0] m1_o6ex0_LANE;
  logic signed [34:0] m1_o6sx0_ANE;
  logic signed [34:0] m1_o7ex0_LANE;
  logic signed [34:0] m1_o7sx0_ANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.multiplier.m1: family squarer realized by the library module fam_mul_squarer_w16_u_p17507a8b
  fam_mul_squarer_w16_u_p17507a8b u_m1_mulLANE (.a(m1_mul_aLANE), .b(m1_mul_bLANE), .p(m1_mul_pLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_mul_aLANE = 'x; m1_mul_bLANE = 'x; m1_o6ex0_LANE = 'x; m1_o6sx0_ANE = 'x; m1_o7ex0_LANE = 'x; m1_o7sx0_ANE = 'x;
    case (op)
      5'd6: begin
        m1_mul_aLANE = m1_aLANE; m1_mul_bLANE = m1_bLANE;
        m1_o6ex0_LANE = $signed({{3{1'b0}}, m1_mul_pLANE});
        m1_o6sx0_ANE = m1_o6ex0_LANE - (m1_aLANE[15] ? ($signed(m1_vbLANE) <<< 16) : 35'sd0) - (m1_bLANE[15] ? ($signed(m1_vaLANE) <<< 16) : 35'sd0) + ((m1_aLANE[15] & m1_bLANE[15]) ? 35'sd4294967296 : 35'sd0);
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o6ex0_LANE);
        fl_m1[(0+LANE)*10 +: 10] = (m1_o6sx0_ANE > 35'sd32767 || m1_o6sx0_ANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m1_o6ex0_LANE > 35'sd65535 || m1_o6ex0_LANE < 0 ? (10'd1 << 2) : 10'd0);
      end
      5'd7: begin
        m1_mul_aLANE = m1_aLANE; m1_mul_bLANE = m1_bLANE;
        m1_o7ex0_LANE = $signed({{3{1'b0}}, m1_mul_pLANE});
        m1_o7sx0_ANE = m1_o7ex0_LANE - (m1_aLANE[15] ? ($signed(m1_vbLANE) <<< 16) : 35'sd0) - (m1_bLANE[15] ? ($signed(m1_vaLANE) <<< 16) : 35'sd0) + ((m1_aLANE[15] & m1_bLANE[15]) ? 35'sd4294967296 : 35'sd0);
        y_m1[((LANE*16)+0) +: 16] = m1_wrap(m1_o7ex0_LANE >>> 16);
        fl_m1[(0+LANE)*10 +: 10] = (m1_o7sx0_ANE > 35'sd32767 || m1_o7sx0_ANE < -35'sd32768 ? (10'd1 << 8) : 10'd0) | (m1_o7ex0_LANE > 35'sd65535 || m1_o7ex0_LANE < 0 ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_shifter #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_m1_shifter: lane LANE of mode 1 (int16_unsigned) for the shifter ops shl, shr_arith, rol; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [49:0] m1_xa [0:0];
  logic [49:0] m1_xb [0:0];
  logic signed [16:0] m1_vaLANE;
  logic signed [16:0] m1_vbLANE;
  logic [15:0] m1_sh_aLANE;
  logic [3:0] m1_sh_amtLANE;
  logic [2:0] m1_sh_opLANE;
  logic [15:0] m1_sh_yLANE;
  logic signed [34:0] m1_o11ex0_LANE;
  logic signed [34:0] m1_o12ex0_LANE;
  logic signed [34:0] m1_o13ex0_LANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_xa[LANE] = m1_x(m1_unpack_s(m1_aLANE, 1'b0));
  assign m1_xb[LANE] = m1_x(m1_unpack_s(m1_bLANE, 1'b0));
  assign m1_vaLANE = {1'b0, m1_aLANE};
  assign m1_vbLANE = {1'b0, m1_bLANE};
  // structure core.shifter.m1: family masked_merged realized by the library module fam_shift_masked_merged
  fam_shift_masked_merged #(.W(16), .MASKGEN(0), .MERGE(1), .R_RADIX_LOG2(3), .R_ONE_HOT(1), .R_ORDER(0), .STICKY(0)) u_m1_shifterLANE (.a(m1_sh_aLANE), .amt(m1_sh_amtLANE), .op(m1_sh_opLANE), .y(m1_sh_yLANE), .sticky());
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_sh_aLANE = 'x; m1_sh_amtLANE = 'x; m1_sh_opLANE = 'x; m1_o11ex0_LANE = 'x; m1_o12ex0_LANE = 'x; m1_o13ex0_LANE = 'x;
    case (op)
      5'd11: begin
        m1_sh_aLANE = m1_aLANE; m1_sh_amtLANE = 4'(m1_bLANE % 16'd16); m1_sh_opLANE = 3'd0;
        y_m1[((LANE*16)+0) +: 16] = m1_sh_yLANE;
      end
      5'd12: begin
        m1_sh_aLANE = m1_aLANE; m1_sh_amtLANE = 4'(m1_bLANE % 16'd16); m1_sh_opLANE = 3'd2;
        y_m1[((LANE*16)+0) +: 16] = m1_sh_yLANE;
      end
      5'd13: begin
        m1_sh_aLANE = m1_aLANE; m1_sh_amtLANE = 4'(m1_bLANE % 16'd16); m1_sh_opLANE = 3'd3;
        y_m1[((LANE*16)+0) +: 16] = m1_sh_yLANE;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_adder #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_adder: lane LANE of mode 2 (int8_twos_complement) for the adder ops add, sub, adc, neg, abs, add_sat; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_add_aLANE;
  logic [7:0] m2_add_bLANE;
  logic m2_add_cinLANE;
  logic [7:0] m2_add_sLANE;
  logic m2_add_coutLANE;
  logic signed [18:0] m2_o0ex0_LANE;
  logic signed [18:0] m2_o1ex0_LANE;
  logic signed [18:0] m2_o2ex0_LANE;
  logic signed [18:0] m2_o3ex0_LANE;
  logic signed [18:0] m2_o4ex0_LANE;
  logic signed [18:0] m2_o5ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.adder.m2: family sparse_prefix_hybrid realized by the library module fam_adder_sparse_prefix_hybrid_p36fd82ab953ccb4995a8e1923d6edef046b1089c32e5aac0b4643aeefde6bf91_w8
  fam_adder_sparse_prefix_hybrid_p36fd82ab953ccb4995a8e1923d6edef046b1089c32e5aac0b4643aeefde6bf91_w8 u_m2_adderLANE (.a(m2_add_aLANE), .b(m2_add_bLANE), .cin(m2_add_cinLANE), .s(m2_add_sLANE), .cout(m2_add_coutLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_add_aLANE = 'x; m2_add_bLANE = 'x; m2_add_cinLANE = 'x; m2_o0ex0_LANE = 'x; m2_o1ex0_LANE = 'x; m2_o2ex0_LANE = 'x;
    m2_o3ex0_LANE = 'x; m2_o4ex0_LANE = 'x; m2_o5ex0_LANE = 'x;
    case (op)
      5'd0: begin
        m2_add_aLANE = m2_aLANE; m2_add_bLANE = m2_bLANE; m2_add_cinLANE = 1'b0;
        m2_o0ex0_LANE = $signed({(m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o0ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (m2_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd1: begin
        m2_add_aLANE = m2_aLANE; m2_add_bLANE = ~m2_bLANE; m2_add_cinLANE = 1'b1;
        m2_o1ex0_LANE = $signed({(m2_aLANE[7] ^ ~m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o1ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ ~m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ ~m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (~m2_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd2: begin
        m2_add_aLANE = m2_aLANE; m2_add_bLANE = m2_bLANE; m2_add_cinLANE = 1'b1;
        m2_o2ex0_LANE = $signed({(m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o2ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (m2_add_coutLANE ? (10'd1 << 7) : 10'd0);
      end
      5'd3: begin
        m2_add_aLANE = 8'd0; m2_add_bLANE = ~m2_aLANE; m2_add_cinLANE = 1'b1;
        m2_o3ex0_LANE = $signed({(1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o3ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0) | (m2_aLANE != 0 ? (10'd1 << 7) : 10'd0);
      end
      5'd4: begin
        m2_add_aLANE = 8'd0; m2_add_bLANE = ~m2_aLANE; m2_add_cinLANE = 1'b1;
        m2_o4ex0_LANE = (m2_aLANE[7] ? $signed({(1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE), m2_add_sLANE}) : $signed({1'b0, m2_aLANE}));
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o4ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = ((m2_aLANE[7] & ((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7])) ? (10'd1 << 8) : 10'd0) | ((m2_aLANE[7] & ((1'b0 ^ ~m2_aLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7])) ? (10'd1 << 2) : 10'd0);
      end
      5'd5: begin
        m2_add_aLANE = m2_aLANE; m2_add_bLANE = m2_bLANE; m2_add_cinLANE = 1'b0;
        m2_o5ex0_LANE = $signed({(m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE), m2_add_sLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_sat(m2_o5ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 8) : 10'd0) | (((m2_aLANE[7] ^ m2_bLANE[7] ^ m2_add_coutLANE) ^ m2_add_sLANE[7]) ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_bitcount #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_bitcount: lane LANE of mode 2 (int8_twos_complement) for the bitcount ops popcount, clz, ctz; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_ctz_aLANE;
  logic [3:0] m2_ctz_nLANE;
  logic signed [18:0] m2_o18ex0_LANE;
  logic signed [18:0] m2_o19ex0_LANE;
  logic signed [18:0] m2_o20ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.bitcount.m2: family trailing_zero realized by the library module fam_count_tzc_isolate_then_encode_twos_complement_and_pb78b9_w8 (ctz)
  fam_count_tzc_isolate_then_encode_twos_complement_and_pb78b9_w8 u_m2_ctzLANE (.a(m2_ctz_aLANE), .n(m2_ctz_nLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_ctz_aLANE = 'x; m2_o18ex0_LANE = 'x; m2_o19ex0_LANE = 'x; m2_o20ex0_LANE = 'x;
    case (op)
      5'd18: begin
        y_m2[((LANE*8)+0) +: 8] = m2_aLANE[0] + m2_aLANE[1] + m2_aLANE[2] + m2_aLANE[3] + m2_aLANE[4] + m2_aLANE[5] + m2_aLANE[6] + m2_aLANE[7];
      end
      5'd19: begin
        y_m2[((LANE*8)+0) +: 8] = m2_aLANE[7] ? 8'd0 : m2_aLANE[6] ? 8'd1 : m2_aLANE[5] ? 8'd2 : m2_aLANE[4] ? 8'd3 : m2_aLANE[3] ? 8'd4 : m2_aLANE[2] ? 8'd5 : m2_aLANE[1] ? 8'd6 : m2_aLANE[0] ? 8'd7 : 8'd8;
      end
      5'd20: begin
        m2_ctz_aLANE = m2_aLANE;
        y_m2[((LANE*8)+0) +: 8] = {{4{1'b0}}, m2_ctz_nLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_comparator #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_comparator: lane LANE of mode 2 (int8_twos_complement) for the comparator ops min, max, cmp; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_cmp_aLANE;
  logic [7:0] m2_cmp_bLANE;
  logic m2_cmp_ltLANE;
  logic m2_cmp_eqLANE;
  logic signed [18:0] m2_o8ex0_LANE;
  logic signed [18:0] m2_o9ex0_LANE;
  logic signed [18:0] m2_o10ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.comparator.m2: family prefix_comparator realized by the library module fam_cmp_prefix_comparator
  fam_cmp_prefix_comparator #(.W(8), .SIGNED(1), .STRUCTURE(0), .RADIX(2)) u_m2_cmpLANE (.a(m2_cmp_aLANE), .b(m2_cmp_bLANE), .lt(m2_cmp_ltLANE), .eq(m2_cmp_eqLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_cmp_aLANE = 'x; m2_cmp_bLANE = 'x; m2_o8ex0_LANE = 'x; m2_o9ex0_LANE = 'x; m2_o10ex0_LANE = 'x;
    case (op)
      5'd8: begin
        m2_cmp_aLANE = m2_aLANE; m2_cmp_bLANE = m2_bLANE;
        y_m2[((LANE*8)+0) +: 8] = (m2_cmp_ltLANE | m2_cmp_eqLANE) ? m2_aLANE : m2_bLANE;
      end
      5'd9: begin
        m2_cmp_aLANE = m2_aLANE; m2_cmp_bLANE = m2_bLANE;
        y_m2[((LANE*8)+0) +: 8] = (~m2_cmp_ltLANE) ? m2_aLANE : m2_bLANE;
      end
      5'd10: begin
        m2_cmp_aLANE = m2_aLANE; m2_cmp_bLANE = m2_bLANE;
        y_m2[((LANE*8)+0) +: 8] = {{5{1'b0}}, (~m2_cmp_ltLANE & ~m2_cmp_eqLANE), m2_cmp_eqLANE, m2_cmp_ltLANE};
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_multiplier #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_multiplier: lane LANE of mode 2 (int8_twos_complement) for the multiplier ops mul, mul_high; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_mul_aLANE;
  logic [7:0] m2_mul_bLANE;
  logic [15:0] m2_mul_pLANE;
  logic signed [18:0] m2_o6ex0_LANE;
  logic signed [18:0] m2_o7ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.multiplier.m2: family recursive_karatsuba realized by the library module fam_mul_karatsuba_d3_w8_s_pa2efba30
  fam_mul_karatsuba_d3_w8_s_pa2efba30 u_m2_mulLANE (.a(m2_mul_aLANE), .b(m2_mul_bLANE), .p(m2_mul_pLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_mul_aLANE = 'x; m2_mul_bLANE = 'x; m2_o6ex0_LANE = 'x; m2_o7ex0_LANE = 'x;
    case (op)
      5'd6: begin
        m2_mul_aLANE = m2_aLANE; m2_mul_bLANE = m2_bLANE;
        m2_o6ex0_LANE = $signed({{3{m2_mul_pLANE[15]}}, m2_mul_pLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o6ex0_LANE);
        fl_m2[(0+LANE)*10 +: 10] = (m2_o6ex0_LANE > 19'sd127 || m2_o6ex0_LANE < -19'sd128 ? (10'd1 << 8) : 10'd0) | (m2_o6ex0_LANE > 19'sd127 || m2_o6ex0_LANE < -19'sd128 ? (10'd1 << 2) : 10'd0);
      end
      5'd7: begin
        m2_mul_aLANE = m2_aLANE; m2_mul_bLANE = m2_bLANE;
        m2_o7ex0_LANE = $signed({{3{m2_mul_pLANE[15]}}, m2_mul_pLANE});
        y_m2[((LANE*8)+0) +: 8] = m2_wrap(m2_o7ex0_LANE >>> 8);
        fl_m2[(0+LANE)*10 +: 10] = (m2_o7ex0_LANE > 19'sd127 || m2_o7ex0_LANE < -19'sd128 ? (10'd1 << 8) : 10'd0) | (m2_o7ex0_LANE > 19'sd127 || m2_o7ex0_LANE < -19'sd128 ? (10'd1 << 2) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_shifter #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_m2_shifter: lane LANE of mode 2 (int8_twos_complement) for the shifter ops shl, shr_arith, rol; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [33:0] m2_xa [0:1];
  logic [33:0] m2_xb [0:1];
  logic signed [8:0] m2_vaLANE;
  logic signed [8:0] m2_vbLANE;
  logic [7:0] m2_sh_aLANE;
  logic [2:0] m2_sh_amtLANE;
  logic [2:0] m2_sh_opLANE;
  logic [7:0] m2_sh_yLANE;
  logic signed [18:0] m2_o11ex0_LANE;
  logic signed [18:0] m2_o12ex0_LANE;
  logic signed [18:0] m2_o13ex0_LANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  assign m2_xa[LANE] = m2_x(m2_unpack_s(m2_aLANE, 1'b0));
  assign m2_xb[LANE] = m2_x(m2_unpack_s(m2_bLANE, 1'b0));
  assign m2_vaLANE = {m2_aLANE[7], m2_aLANE};
  assign m2_vbLANE = {m2_bLANE[7], m2_bLANE};
  // structure core.shifter.m2: family barrel_mux_tree realized by the library module fam_shift_barrel_mux_tree
  fam_shift_barrel_mux_tree #(.W(8), .RADIX_LOG2(1), .ONE_HOT(0), .DIR(2), .ORDER(0), .STICKY(1)) u_m2_shifterLANE (.a(m2_sh_aLANE), .amt(m2_sh_amtLANE), .op(m2_sh_opLANE), .y(m2_sh_yLANE), .sticky());
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_sh_aLANE = 'x; m2_sh_amtLANE = 'x; m2_sh_opLANE = 'x; m2_o11ex0_LANE = 'x; m2_o12ex0_LANE = 'x; m2_o13ex0_LANE = 'x;
    case (op)
      5'd11: begin
        m2_sh_aLANE = m2_aLANE; m2_sh_amtLANE = 3'(m2_bLANE % 8'd8); m2_sh_opLANE = 3'd0;
        y_m2[((LANE*8)+0) +: 8] = m2_sh_yLANE;
      end
      5'd12: begin
        m2_sh_aLANE = m2_aLANE; m2_sh_amtLANE = 3'(m2_bLANE % 8'd8); m2_sh_opLANE = 3'd2;
        y_m2[((LANE*8)+0) +: 8] = m2_sh_yLANE;
      end
      5'd13: begin
        m2_sh_aLANE = m2_aLANE; m2_sh_amtLANE = 3'(m2_bLANE % 8'd8); m2_sh_opLANE = 3'd3;
        y_m2[((LANE*8)+0) +: 8] = m2_sh_yLANE;
      end
      default: ;
    endcase
  end
endmodule
// ADIR-MEMBER m0_l0_adder
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_adder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_adder: physical structure `m0.l0.adder` (kind adder, slot adder); realizes m0.l0.adder: adder, mode 0 lane 0, int16_twos_complement, ops add, sub, adc, neg, abs, add_sat
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_adder #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_multiplier: physical structure `m0.l0.multiplier` (kind multiplier, slot multiplier); realizes m0.l0.multiplier: multiplier, mode 0 lane 0, int16_twos_complement, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_multiplier #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_comparator: physical structure `m0.l0.comparator` (kind comparator, slot comparator); realizes m0.l0.comparator: comparator, mode 0 lane 0, int16_twos_complement, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_comparator #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_shifter: physical structure `m0.l0.shifter` (kind shifter, slot shifter); realizes m0.l0.shifter: shifter, mode 0 lane 0, int16_twos_complement, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_shifter #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_logic
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_logic (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_logic: physical structure `m0.l0.logic` (kind logic, slot logic); realizes m0.l0.logic: logic, mode 0 lane 0, int16_twos_complement, ops and, or, xor, not
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [1:0] lg_op;
  logic lg_en;
  logic [15:0] lg_y;
  assign lg_op = (op == 5'd14) ? 2'd0 : (op == 5'd15) ? 2'd1 : (op == 5'd16) ? 2'd2 : (op == 5'd17) ? 2'd3 : 2'd0;
  assign lg_en = (op == 5'd14) | (op == 5'd15) | (op == 5'd16) | (op == 5'd17);
  // structure core.logic: family wide_gate_row realized by one library gate row over the whole word (the packings 1 x int16_twos_complement)
  fam_logic_gate_row #(.W(16), .NOT_VIA_XOR(0)) u_wide_row (.a(a), .b(b), .op(lg_op), .y(lg_y));
  assign y_m0 = lg_en ? lg_y[15:0] : '0;
  assign fl_m0 = '0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0
);
  // alu_core_u_m0_l0_bitcount: physical structure `m0.l0.bitcount` (kind bitcount, slot bitcount); realizes m0.l0.bitcount: bitcount, mode 0 lane 0, int16_twos_complement, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_bitcount #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_adder
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_adder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_adder: physical structure `m1.l0.adder` (kind adder, slot adder); realizes m1.l0.adder: adder, mode 1 lane 0, int16_unsigned, ops add, sub, adc, neg, abs, add_sat
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_adder #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_multiplier: physical structure `m1.l0.multiplier` (kind multiplier, slot multiplier); realizes m1.l0.multiplier: multiplier, mode 1 lane 0, int16_unsigned, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_multiplier #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_comparator: physical structure `m1.l0.comparator` (kind comparator, slot comparator); realizes m1.l0.comparator: comparator, mode 1 lane 0, int16_unsigned, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_comparator #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_shifter: physical structure `m1.l0.shifter` (kind shifter, slot shifter); realizes m1.l0.shifter: shifter, mode 1 lane 0, int16_unsigned, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_shifter #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_logic
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_logic (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_logic: physical structure `m1.l0.logic` (kind logic, slot logic); realizes m1.l0.logic: logic, mode 1 lane 0, int16_unsigned, ops and, or, xor, not
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [1:0] lg_op;
  logic lg_en;
  logic [15:0] lg_y;
  assign lg_op = (op == 5'd14) ? 2'd0 : (op == 5'd15) ? 2'd1 : (op == 5'd16) ? 2'd2 : (op == 5'd17) ? 2'd3 : 2'd0;
  assign lg_en = (op == 5'd14) | (op == 5'd15) | (op == 5'd16) | (op == 5'd17);
  // structure core.logic: family wide_gate_row realized by one library gate row over the whole word (the packings 1 x int16_unsigned)
  fam_logic_gate_row #(.W(16), .NOT_VIA_XOR(0)) u_wide_row (.a(a), .b(b), .op(lg_op), .y(lg_y));
  assign y_m1 = lg_en ? lg_y[15:0] : '0;
  assign fl_m1 = '0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1
);
  // alu_core_u_m1_l0_bitcount: physical structure `m1.l0.bitcount` (kind bitcount, slot bitcount); realizes m1.l0.bitcount: bitcount, mode 1 lane 0, int16_unsigned, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_bitcount #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_adder
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_adder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_adder: physical structure `m2.l0.adder` (kind adder, slot adder); realizes m2.l0.adder: adder, mode 2 lane 0, int8_twos_complement, ops add, sub, adc, neg, abs, add_sat
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_adder #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_adder
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_adder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_adder: physical structure `m2.l1.adder` (kind adder, slot adder); realizes m2.l1.adder: adder, mode 2 lane 1, int8_twos_complement, ops add, sub, adc, neg, abs, add_sat
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_adder #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_multiplier: physical structure `m2.l0.multiplier` (kind multiplier, slot multiplier); realizes m2.l0.multiplier: multiplier, mode 2 lane 0, int8_twos_complement, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_multiplier #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_multiplier: physical structure `m2.l1.multiplier` (kind multiplier, slot multiplier); realizes m2.l1.multiplier: multiplier, mode 2 lane 1, int8_twos_complement, ops mul, mul_high
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_multiplier #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_comparator: physical structure `m2.l0.comparator` (kind comparator, slot comparator); realizes m2.l0.comparator: comparator, mode 2 lane 0, int8_twos_complement, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_comparator #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_comparator: physical structure `m2.l1.comparator` (kind comparator, slot comparator); realizes m2.l1.comparator: comparator, mode 2 lane 1, int8_twos_complement, ops min, max, cmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_comparator #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_shifter: physical structure `m2.l0.shifter` (kind shifter, slot shifter); realizes m2.l0.shifter: shifter, mode 2 lane 0, int8_twos_complement, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_shifter #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_shifter
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_shifter (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_shifter: physical structure `m2.l1.shifter` (kind shifter, slot shifter); realizes m2.l1.shifter: shifter, mode 2 lane 1, int8_twos_complement, ops shl, shr_arith, rol
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_shifter #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_logic
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_logic (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_logic: physical structure `m2.l0.logic` (kind logic, slot logic); realizes m2.l0.logic: logic, mode 2 lane 0, int8_twos_complement, ops and, or, xor, not
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [1:0] lg_op;
  logic lg_en;
  logic [15:0] lg_y;
  assign lg_op = (op == 5'd14) ? 2'd0 : (op == 5'd15) ? 2'd1 : (op == 5'd16) ? 2'd2 : (op == 5'd17) ? 2'd3 : 2'd0;
  assign lg_en = (op == 5'd14) | (op == 5'd15) | (op == 5'd16) | (op == 5'd17);
  // structure core.logic: family wide_gate_row realized by one library gate row over the whole word (the packings 2 x int8_twos_complement)
  fam_logic_gate_row #(.W(16), .NOT_VIA_XOR(1)) u_wide_row (.a(a), .b(b), .op(lg_op), .y(lg_y));
  assign y_m2 = lg_en ? lg_y[15:0] : '0;
  assign fl_m2 = '0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_logic
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_logic (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_logic: physical structure `m2.l1.logic` (kind logic, slot logic); realizes m2.l1.logic: logic, mode 2 lane 1, int8_twos_complement, ops and, or, xor, not
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [1:0] lg_op;
  logic lg_en;
  logic [15:0] lg_y;
  assign lg_op = (op == 5'd14) ? 2'd0 : (op == 5'd15) ? 2'd1 : (op == 5'd16) ? 2'd2 : (op == 5'd17) ? 2'd3 : 2'd0;
  assign lg_en = (op == 5'd14) | (op == 5'd15) | (op == 5'd16) | (op == 5'd17);
  // structure core.logic: family wide_gate_row realized by one library gate row over the whole word (the packings 2 x int8_twos_complement)
  fam_logic_gate_row #(.W(16), .NOT_VIA_XOR(1)) u_wide_row (.a(a), .b(b), .op(lg_op), .y(lg_y));
  assign y_m2 = lg_en ? lg_y[15:0] : '0;
  assign fl_m2 = '0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l0_bitcount: physical structure `m2.l0.bitcount` (kind bitcount, slot bitcount); realizes m2.l0.bitcount: bitcount, mode 2 lane 0, int8_twos_complement, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_bitcount #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_bitcount
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_bitcount (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [4:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2
);
  // alu_core_u_m2_l1_bitcount: physical structure `m2.l1.bitcount` (kind bitcount, slot bitcount); realizes m2.l1.bitcount: bitcount, mode 2 lane 1, int8_twos_complement, ops popcount, clz, ctz
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_bitcount #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER library
// ---- the family library modules the lane modules instantiate (chialu/targets/rtl/families; fixed text, replaced by editing the instances)

// carry_increment: blocks [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2] (uniform), group carries rippled, 1 increment level
module fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32 (input logic [31:0] a, input logic [31:0] b, input logic cin, output logic [31:0] s, output logic cout);
  logic [1:0] s0;
  logic co0;
  // block 0 (2 bits), carry-in 0
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2 u1 (.a(a[1:0]), .b(b[1:0]), .cin(1'b0), .s(s0), .cout(co0));
  logic bp0; assign bp0 = &(a[1:0] ^ b[1:0]);
  logic [1:0] s1;
  logic co1;
  // block 1 (2 bits), carry-in 0
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2 u2 (.a(a[3:2]), .b(b[3:2]), .cin(1'b0), .s(s1), .cout(co1));
  logic bp1; assign bp1 = &(a[3:2] ^ b[3:2]);
  logic [1:0] s2;
  logic co2;
  // block 2 (2 bits), carry-in 0
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2 u3 (.a(a[5:4]), .b(b[5:4]), .cin(1'b0), .s(s2), .cout(co2));
  logic bp2; assign bp2 = &(a[5:4] ^ b[5:4]);
  logic [1:0] s3;
  logic co3;
  // block 3 (2 bits), carry-in 0
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2 u4 (.a(a[7:6]), .b(b[7:6]), .cin(1'b0), .s(s3), .cout(co3));
  logic bp3; assign bp3 = &(a[7:6] ^ b[7:6]);
  logic [1:0] s4;
  logic co4;
  // block 4 (2 bits), carry-in 0
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2 u5 (.a(a[9:8]), .b(b[9:8]), .cin(1'b0), .s(s4), .cout(co4));
  logic bp4; assign bp4 = &(a[9:8] ^ b[9:8]);
  logic [1:0] s5;
  logic co5;
  // block 5 (2 bits), carry-in 0
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2 u6 (.a(a[11:10]), .b(b[11:10]), .cin(1'b0), .s(s5), .cout(co5));
  logic bp5; assign bp5 = &(a[11:10] ^ b[11:10]);
  logic [1:0] s6;
  logic co6;
  // block 6 (2 bits), carry-in 0
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2 u7 (.a(a[13:12]), .b(b[13:12]), .cin(1'b0), .s(s6), .cout(co6));
  logic bp6; assign bp6 = &(a[13:12] ^ b[13:12]);
  logic [1:0] s7;
  logic co7;
  // block 7 (2 bits), carry-in 0
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2 u8 (.a(a[15:14]), .b(b[15:14]), .cin(1'b0), .s(s7), .cout(co7));
  logic bp7; assign bp7 = &(a[15:14] ^ b[15:14]);
  logic [1:0] s8;
  logic co8;
  // block 8 (2 bits), carry-in 0
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2 u9 (.a(a[17:16]), .b(b[17:16]), .cin(1'b0), .s(s8), .cout(co8));
  logic bp8; assign bp8 = &(a[17:16] ^ b[17:16]);
  logic [1:0] s9;
  logic co9;
  // block 9 (2 bits), carry-in 0
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2 u10 (.a(a[19:18]), .b(b[19:18]), .cin(1'b0), .s(s9), .cout(co9));
  logic bp9; assign bp9 = &(a[19:18] ^ b[19:18]);
  logic [1:0] s10;
  logic co10;
  // block 10 (2 bits), carry-in 0
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2 u11 (.a(a[21:20]), .b(b[21:20]), .cin(1'b0), .s(s10), .cout(co10));
  logic bp10; assign bp10 = &(a[21:20] ^ b[21:20]);
  logic [1:0] s11;
  logic co11;
  // block 11 (2 bits), carry-in 0
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2 u12 (.a(a[23:22]), .b(b[23:22]), .cin(1'b0), .s(s11), .cout(co11));
  logic bp11; assign bp11 = &(a[23:22] ^ b[23:22]);
  logic [1:0] s12;
  logic co12;
  // block 12 (2 bits), carry-in 0
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2 u13 (.a(a[25:24]), .b(b[25:24]), .cin(1'b0), .s(s12), .cout(co12));
  logic bp12; assign bp12 = &(a[25:24] ^ b[25:24]);
  logic [1:0] s13;
  logic co13;
  // block 13 (2 bits), carry-in 0
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2 u14 (.a(a[27:26]), .b(b[27:26]), .cin(1'b0), .s(s13), .cout(co13));
  logic bp13; assign bp13 = &(a[27:26] ^ b[27:26]);
  logic [1:0] s14;
  logic co14;
  // block 14 (2 bits), carry-in 0
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2 u15 (.a(a[29:28]), .b(b[29:28]), .cin(1'b0), .s(s14), .cout(co14));
  logic bp14; assign bp14 = &(a[29:28] ^ b[29:28]);
  logic [1:0] s15;
  logic co15;
  // block 15 (2 bits), carry-in 0
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2 u16 (.a(a[31:30]), .b(b[31:30]), .cin(1'b0), .s(s15), .cout(co15));
  logic bp15; assign bp15 = &(a[31:30] ^ b[31:30]);
  logic c1; assign c1 = co0 | (bp0 & cin);
  logic c2; assign c2 = co1 | (bp1 & c1);
  logic c3; assign c3 = co2 | (bp2 & c2);
  logic c4; assign c4 = co3 | (bp3 & c3);
  logic c5; assign c5 = co4 | (bp4 & c4);
  logic c6; assign c6 = co5 | (bp5 & c5);
  logic c7; assign c7 = co6 | (bp6 & c6);
  logic c8; assign c8 = co7 | (bp7 & c7);
  logic c9; assign c9 = co8 | (bp8 & c8);
  logic c10; assign c10 = co9 | (bp9 & c9);
  logic c11; assign c11 = co10 | (bp10 & c10);
  logic c12; assign c12 = co11 | (bp11 & c11);
  logic c13; assign c13 = co12 | (bp12 & c12);
  logic c14; assign c14 = co13 | (bp13 & c13);
  logic c15; assign c15 = co14 | (bp14 & c14);
  logic c16; assign c16 = co15 | (bp15 & c15);
  logic [1:0] si0;
  logic ico0;
  // block 0: the carry-in through the increment stage
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2 u17 (.a(s0), .cin(cin), .s(si0), .cout(ico0));
  assign s[1:0] = si0;
  logic [1:0] si1;
  logic ico1;
  // block 1: the carry-in through the increment stage
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2 u18 (.a(s1), .cin(c1), .s(si1), .cout(ico1));
  assign s[3:2] = si1;
  logic [1:0] si2;
  logic ico2;
  // block 2: the carry-in through the increment stage
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2 u19 (.a(s2), .cin(c2), .s(si2), .cout(ico2));
  assign s[5:4] = si2;
  logic [1:0] si3;
  logic ico3;
  // block 3: the carry-in through the increment stage
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2 u20 (.a(s3), .cin(c3), .s(si3), .cout(ico3));
  assign s[7:6] = si3;
  logic [1:0] si4;
  logic ico4;
  // block 4: the carry-in through the increment stage
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2 u21 (.a(s4), .cin(c4), .s(si4), .cout(ico4));
  assign s[9:8] = si4;
  logic [1:0] si5;
  logic ico5;
  // block 5: the carry-in through the increment stage
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2 u22 (.a(s5), .cin(c5), .s(si5), .cout(ico5));
  assign s[11:10] = si5;
  logic [1:0] si6;
  logic ico6;
  // block 6: the carry-in through the increment stage
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2 u23 (.a(s6), .cin(c6), .s(si6), .cout(ico6));
  assign s[13:12] = si6;
  logic [1:0] si7;
  logic ico7;
  // block 7: the carry-in through the increment stage
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2 u24 (.a(s7), .cin(c7), .s(si7), .cout(ico7));
  assign s[15:14] = si7;
  logic [1:0] si8;
  logic ico8;
  // block 8: the carry-in through the increment stage
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2 u25 (.a(s8), .cin(c8), .s(si8), .cout(ico8));
  assign s[17:16] = si8;
  logic [1:0] si9;
  logic ico9;
  // block 9: the carry-in through the increment stage
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2 u26 (.a(s9), .cin(c9), .s(si9), .cout(ico9));
  assign s[19:18] = si9;
  logic [1:0] si10;
  logic ico10;
  // block 10: the carry-in through the increment stage
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2 u27 (.a(s10), .cin(c10), .s(si10), .cout(ico10));
  assign s[21:20] = si10;
  logic [1:0] si11;
  logic ico11;
  // block 11: the carry-in through the increment stage
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2 u28 (.a(s11), .cin(c11), .s(si11), .cout(ico11));
  assign s[23:22] = si11;
  logic [1:0] si12;
  logic ico12;
  // block 12: the carry-in through the increment stage
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2 u29 (.a(s12), .cin(c12), .s(si12), .cout(ico12));
  assign s[25:24] = si12;
  logic [1:0] si13;
  logic ico13;
  // block 13: the carry-in through the increment stage
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2 u30 (.a(s13), .cin(c13), .s(si13), .cout(ico13));
  assign s[27:26] = si13;
  logic [1:0] si14;
  logic ico14;
  // block 14: the carry-in through the increment stage
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2 u31 (.a(s14), .cin(c14), .s(si14), .cout(ico14));
  assign s[29:28] = si14;
  logic [1:0] si15;
  logic ico15;
  // block 15: the carry-in through the increment stage
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2 u32 (.a(s15), .cin(c15), .s(si15), .cout(ico15));
  assign s[31:30] = si15;
  assign cout = c16;
endmodule




module fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_block_adder_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_prefix_han_carlson_w2 implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule





module fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32_component_increment_stage_incrementer_w2(input wire [1:0] a, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_incr_prefix_and #(.W(2), .STRUCTURE(2), .B(4), .TOPO(0)) implementation(.a(a), .cin(cin), .s(s), .cout(cout));
endmodule



// -------------------------------------------------------------- carry_lookahead
// groups of G bits with a one-level lookahead inside the group (the carries of
// the group from its bit generates and propagates and the group carry-in); the
// group carries come from LEVELS levels of lookahead over the group generates
// and propagates (fam_adder_cla_level): rippled (INTER = 0), looked ahead
// (INTER = 1), or selected (INTER = 2: every group's sum is formed for both
// carry-ins and the rippled group carry selects it, the carry-select stage
// above lookahead blocks).
module fam_adder_carry_lookahead #(parameter int W = 16, parameter int G = 4, parameter int INTER = 0, parameter int LEVELS = 1)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  localparam int NG = (W + G - 1) / G;
  logic [W-1:0] g, p;
  assign g = a & b;
  assign p = a ^ b;
  logic [NG-1:0] gc;                  // the carry into each group
  logic [NG-1:0] GG, GP;              // group generate and propagate
  genvar k, i;
  generate
    for (k = 0; k < NG; k = k + 1) begin : grp
      localparam int LO = k * G;
      localparam int HI = (LO + G > W) ? W : LO + G;
      localparam int NB = HI - LO;
      // the group's generate and propagate from its bits
      logic [NB:0] lg, lp;
      assign lg[0] = 1'b0;
      assign lp[0] = 1'b1;
      for (i = 0; i < NB; i = i + 1) begin : acc
        assign lg[i+1] = g[LO+i] | (p[LO+i] & lg[i]);
        assign lp[i+1] = p[LO+i] & lp[i];
      end
      assign GG[k] = lg[NB];
      assign GP[k] = lp[NB];
      if (INTER == 2) begin : select
        // both sums of the group, selected by the group carry
        logic [NB-1:0] c0, c1;
        for (i = 0; i < NB; i = i + 1) begin : cc
          assign c0[i] = lg[i];
          assign c1[i] = lg[i] | lp[i];
          assign s[LO+i] = p[LO+i] ^ (gc[k] ? c1[i] : c0[i]);
        end
      end else begin : direct
        for (i = 0; i < NB; i = i + 1) begin : cc
          assign s[LO+i] = p[LO+i] ^ (lg[i] | (lp[i] & gc[k]));
        end
      end
    end
    begin : levels
      fam_adder_cla_level #(.N(NG), .G(G), .LEVELS(LEVELS), .INTER(INTER))
        u_lvl (.gg(GG), .gp(GP), .cin(cin), .c(gc), .cout(cout));
    end
  endgenerate
endmodule


// carry_select: blocks [2, 2, 2, 2, 2, 2] (uniform), full_duplicate, selects lookahead_tree
module fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w12 (input logic [11:0] a, input logic [11:0] b, input logic cin, output logic [11:0] s, output logic cout);
  logic [1:0] s0_0;
  logic [1:0] s0_1;
  logic co0_0;
  logic co0_1;
  // block 0 (2 bits), carry-in 0
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w12_component_block_adder_adder_w2 u1 (.a(a[1:0]), .b(b[1:0]), .cin(1'b0), .s(s0_0), .cout(co0_0));
  // block 0, carry-in 1
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w12_component_block_adder_adder_w2 u2 (.a(a[1:0]), .b(b[1:0]), .cin(1'b1), .s(s0_1), .cout(co0_1));
  logic bp0; assign bp0 = co0_1 & ~co0_0;
  logic [1:0] s1_0;
  logic [1:0] s1_1;
  logic co1_0;
  logic co1_1;
  // block 1 (2 bits), carry-in 0
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w12_component_block_adder_adder_w2 u3 (.a(a[3:2]), .b(b[3:2]), .cin(1'b0), .s(s1_0), .cout(co1_0));
  // block 1, carry-in 1
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w12_component_block_adder_adder_w2 u4 (.a(a[3:2]), .b(b[3:2]), .cin(1'b1), .s(s1_1), .cout(co1_1));
  logic bp1; assign bp1 = co1_1 & ~co1_0;
  logic [1:0] s2_0;
  logic [1:0] s2_1;
  logic co2_0;
  logic co2_1;
  // block 2 (2 bits), carry-in 0
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w12_component_block_adder_adder_w2 u5 (.a(a[5:4]), .b(b[5:4]), .cin(1'b0), .s(s2_0), .cout(co2_0));
  // block 2, carry-in 1
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w12_component_block_adder_adder_w2 u6 (.a(a[5:4]), .b(b[5:4]), .cin(1'b1), .s(s2_1), .cout(co2_1));
  logic bp2; assign bp2 = co2_1 & ~co2_0;
  logic [1:0] s3_0;
  logic [1:0] s3_1;
  logic co3_0;
  logic co3_1;
  // block 3 (2 bits), carry-in 0
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w12_component_block_adder_adder_w2 u7 (.a(a[7:6]), .b(b[7:6]), .cin(1'b0), .s(s3_0), .cout(co3_0));
  // block 3, carry-in 1
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w12_component_block_adder_adder_w2 u8 (.a(a[7:6]), .b(b[7:6]), .cin(1'b1), .s(s3_1), .cout(co3_1));
  logic bp3; assign bp3 = co3_1 & ~co3_0;
  logic [1:0] s4_0;
  logic [1:0] s4_1;
  logic co4_0;
  logic co4_1;
  // block 4 (2 bits), carry-in 0
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w12_component_block_adder_adder_w2 u9 (.a(a[9:8]), .b(b[9:8]), .cin(1'b0), .s(s4_0), .cout(co4_0));
  // block 4, carry-in 1
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w12_component_block_adder_adder_w2 u10 (.a(a[9:8]), .b(b[9:8]), .cin(1'b1), .s(s4_1), .cout(co4_1));
  logic bp4; assign bp4 = co4_1 & ~co4_0;
  logic [1:0] s5_0;
  logic [1:0] s5_1;
  logic co5_0;
  logic co5_1;
  // block 5 (2 bits), carry-in 0
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w12_component_block_adder_adder_w2 u11 (.a(a[11:10]), .b(b[11:10]), .cin(1'b0), .s(s5_0), .cout(co5_0));
  // block 5, carry-in 1
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w12_component_block_adder_adder_w2 u12 (.a(a[11:10]), .b(b[11:10]), .cin(1'b1), .s(s5_1), .cout(co5_1));
  logic bp5; assign bp5 = co5_1 & ~co5_0;
  logic la_t0_0; assign la_t0_0 = co0_0 | (bp0 & cin);
  logic la_t1_0; assign la_t1_0 = co0_0 | (bp0 & cin);
  logic la_t1_1; assign la_t1_1 = co1_0 | (bp1 & la_t1_0);
  logic la_t2_0; assign la_t2_0 = co0_0 | (bp0 & cin);
  logic la_t2_1; assign la_t2_1 = co1_0 | (bp1 & la_t2_0);
  logic la_t2_2; assign la_t2_2 = co2_0 | (bp2 & la_t2_1);
  logic la_t3_0; assign la_t3_0 = co0_0 | (bp0 & cin);
  logic la_t3_1; assign la_t3_1 = co1_0 | (bp1 & la_t3_0);
  logic la_t3_2; assign la_t3_2 = co2_0 | (bp2 & la_t3_1);
  logic la_t3_3; assign la_t3_3 = co3_0 | (bp3 & la_t3_2);
  logic la_t4_0; assign la_t4_0 = co0_0 | (bp0 & cin);
  logic la_t4_1; assign la_t4_1 = co1_0 | (bp1 & la_t4_0);
  logic la_t4_2; assign la_t4_2 = co2_0 | (bp2 & la_t4_1);
  logic la_t4_3; assign la_t4_3 = co3_0 | (bp3 & la_t4_2);
  logic la_t4_4; assign la_t4_4 = co4_0 | (bp4 & la_t4_3);
  logic la_t5_0; assign la_t5_0 = co0_0 | (bp0 & cin);
  logic la_t5_1; assign la_t5_1 = co1_0 | (bp1 & la_t5_0);
  logic la_t5_2; assign la_t5_2 = co2_0 | (bp2 & la_t5_1);
  logic la_t5_3; assign la_t5_3 = co3_0 | (bp3 & la_t5_2);
  logic la_t5_4; assign la_t5_4 = co4_0 | (bp4 & la_t5_3);
  logic la_t5_5; assign la_t5_5 = co5_0 | (bp5 & la_t5_4);
  assign s[1:0] = cin ? s0_1 : s0_0;
  assign s[3:2] = la_t0_0 ? s1_1 : s1_0;
  assign s[5:4] = la_t1_1 ? s2_1 : s2_0;
  assign s[7:6] = la_t2_2 ? s3_1 : s3_0;
  assign s[9:8] = la_t3_3 ? s4_1 : s4_0;
  assign s[11:10] = la_t4_4 ? s5_1 : s5_0;
  assign cout = la_t5_5;
endmodule




module fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w12_component_block_adder_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(3)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule


// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).












// carry_select: blocks [2, 2, 2, 2] (uniform), full_duplicate, selects lookahead_tree
module fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w8 (input logic [7:0] a, input logic [7:0] b, input logic cin, output logic [7:0] s, output logic cout);
  logic [1:0] s0_0;
  logic [1:0] s0_1;
  logic co0_0;
  logic co0_1;
  // block 0 (2 bits), carry-in 0
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w8_component_block_adder_adder_w2 u1 (.a(a[1:0]), .b(b[1:0]), .cin(1'b0), .s(s0_0), .cout(co0_0));
  // block 0, carry-in 1
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w8_component_block_adder_adder_w2 u2 (.a(a[1:0]), .b(b[1:0]), .cin(1'b1), .s(s0_1), .cout(co0_1));
  logic bp0; assign bp0 = co0_1 & ~co0_0;
  logic [1:0] s1_0;
  logic [1:0] s1_1;
  logic co1_0;
  logic co1_1;
  // block 1 (2 bits), carry-in 0
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w8_component_block_adder_adder_w2 u3 (.a(a[3:2]), .b(b[3:2]), .cin(1'b0), .s(s1_0), .cout(co1_0));
  // block 1, carry-in 1
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w8_component_block_adder_adder_w2 u4 (.a(a[3:2]), .b(b[3:2]), .cin(1'b1), .s(s1_1), .cout(co1_1));
  logic bp1; assign bp1 = co1_1 & ~co1_0;
  logic [1:0] s2_0;
  logic [1:0] s2_1;
  logic co2_0;
  logic co2_1;
  // block 2 (2 bits), carry-in 0
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w8_component_block_adder_adder_w2 u5 (.a(a[5:4]), .b(b[5:4]), .cin(1'b0), .s(s2_0), .cout(co2_0));
  // block 2, carry-in 1
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w8_component_block_adder_adder_w2 u6 (.a(a[5:4]), .b(b[5:4]), .cin(1'b1), .s(s2_1), .cout(co2_1));
  logic bp2; assign bp2 = co2_1 & ~co2_0;
  logic [1:0] s3_0;
  logic [1:0] s3_1;
  logic co3_0;
  logic co3_1;
  // block 3 (2 bits), carry-in 0
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w8_component_block_adder_adder_w2 u7 (.a(a[7:6]), .b(b[7:6]), .cin(1'b0), .s(s3_0), .cout(co3_0));
  // block 3, carry-in 1
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w8_component_block_adder_adder_w2 u8 (.a(a[7:6]), .b(b[7:6]), .cin(1'b1), .s(s3_1), .cout(co3_1));
  logic bp3; assign bp3 = co3_1 & ~co3_0;
  logic la_t0_0; assign la_t0_0 = co0_0 | (bp0 & cin);
  logic la_t1_0; assign la_t1_0 = co0_0 | (bp0 & cin);
  logic la_t1_1; assign la_t1_1 = co1_0 | (bp1 & la_t1_0);
  logic la_t2_0; assign la_t2_0 = co0_0 | (bp0 & cin);
  logic la_t2_1; assign la_t2_1 = co1_0 | (bp1 & la_t2_0);
  logic la_t2_2; assign la_t2_2 = co2_0 | (bp2 & la_t2_1);
  logic la_t3_0; assign la_t3_0 = co0_0 | (bp0 & cin);
  logic la_t3_1; assign la_t3_1 = co1_0 | (bp1 & la_t3_0);
  logic la_t3_2; assign la_t3_2 = co2_0 | (bp2 & la_t3_1);
  logic la_t3_3; assign la_t3_3 = co3_0 | (bp3 & la_t3_2);
  assign s[1:0] = cin ? s0_1 : s0_0;
  assign s[3:2] = la_t0_0 ? s1_1 : s1_0;
  assign s[5:4] = la_t1_1 ? s2_1 : s2_0;
  assign s[7:6] = la_t2_2 ? s3_1 : s3_0;
  assign cout = la_t3_3;
endmodule




module fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w8_component_block_adder_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(3)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule


// carry_select: blocks [4, 1] (uniform), full_duplicate, selects rippled_block_carries






// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).











// carry_select: blocks [4, 4, 4] (uniform), full_duplicate, selects rippled_block_carries
module fam_adder_carry_select_w12 (input logic [11:0] a, input logic [11:0] b, input logic cin, output logic [11:0] s, output logic cout);
  logic [3:0] s0_0;
  logic [3:0] s0_1;
  logic co0_0;
  logic co0_1;
  // block 0 (4 bits), carry-in 0
  fam_adder_carry_select_w12_component_block_adder_adder_w4 u1 (.a(a[3:0]), .b(b[3:0]), .cin(1'b0), .s(s0_0), .cout(co0_0));
  // block 0, carry-in 1
  fam_adder_carry_select_w12_component_block_adder_adder_w4 u2 (.a(a[3:0]), .b(b[3:0]), .cin(1'b1), .s(s0_1), .cout(co0_1));
  logic bp0; assign bp0 = co0_1 & ~co0_0;
  logic [3:0] s1_0;
  logic [3:0] s1_1;
  logic co1_0;
  logic co1_1;
  // block 1 (4 bits), carry-in 0
  fam_adder_carry_select_w12_component_block_adder_adder_w4 u3 (.a(a[7:4]), .b(b[7:4]), .cin(1'b0), .s(s1_0), .cout(co1_0));
  // block 1, carry-in 1
  fam_adder_carry_select_w12_component_block_adder_adder_w4 u4 (.a(a[7:4]), .b(b[7:4]), .cin(1'b1), .s(s1_1), .cout(co1_1));
  logic bp1; assign bp1 = co1_1 & ~co1_0;
  logic [3:0] s2_0;
  logic [3:0] s2_1;
  logic co2_0;
  logic co2_1;
  // block 2 (4 bits), carry-in 0
  fam_adder_carry_select_w12_component_block_adder_adder_w4 u5 (.a(a[11:8]), .b(b[11:8]), .cin(1'b0), .s(s2_0), .cout(co2_0));
  // block 2, carry-in 1
  fam_adder_carry_select_w12_component_block_adder_adder_w4 u6 (.a(a[11:8]), .b(b[11:8]), .cin(1'b1), .s(s2_1), .cout(co2_1));
  logic bp2; assign bp2 = co2_1 & ~co2_0;
  logic c1; assign c1 = cin ? co0_1 : co0_0;
  logic c2; assign c2 = c1 ? co1_1 : co1_0;
  logic c3; assign c3 = c2 ? co2_1 : co2_0;
  assign s[3:0] = cin ? s0_1 : s0_0;
  assign s[7:4] = c1 ? s1_1 : s1_0;
  assign s[11:8] = c2 ? s2_1 : s2_0;
  assign cout = c3;
endmodule




module fam_adder_carry_select_w12_component_block_adder_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule


// carry_select: blocks [4, 1] (uniform), full_duplicate, selects rippled_block_carries
module fam_adder_carry_select_w5 (input logic [4:0] a, input logic [4:0] b, input logic cin, output logic [4:0] s, output logic cout);
  logic [3:0] s0_0;
  logic [3:0] s0_1;
  logic co0_0;
  logic co0_1;
  // block 0 (4 bits), carry-in 0
  fam_adder_carry_select_w5_component_block_adder_adder_w4 u1 (.a(a[3:0]), .b(b[3:0]), .cin(1'b0), .s(s0_0), .cout(co0_0));
  // block 0, carry-in 1
  fam_adder_carry_select_w5_component_block_adder_adder_w4 u2 (.a(a[3:0]), .b(b[3:0]), .cin(1'b1), .s(s0_1), .cout(co0_1));
  logic bp0; assign bp0 = co0_1 & ~co0_0;
  logic s1_0;
  logic s1_1;
  logic co1_0;
  logic co1_1;
  // block 1 (1 bits), carry-in 0
  fam_adder_carry_select_w5_component_block_adder_adder_w1 u3 (.a(a[4:4]), .b(b[4:4]), .cin(1'b0), .s(s1_0), .cout(co1_0));
  // block 1, carry-in 1
  fam_adder_carry_select_w5_component_block_adder_adder_w1 u4 (.a(a[4:4]), .b(b[4:4]), .cin(1'b1), .s(s1_1), .cout(co1_1));
  logic bp1; assign bp1 = co1_1 & ~co1_0;
  logic c1; assign c1 = cin ? co0_1 : co0_0;
  logic c2; assign c2 = c1 ? co1_1 : co1_0;
  assign s[3:0] = cin ? s0_1 : s0_0;
  assign s[4:4] = c1 ? s1_1 : s1_0;
  assign cout = c2;
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).









module fam_adder_carry_select_w5_component_block_adder_adder_w1(input wire [0:0] a, input wire [0:0] b, input wire [0:0] cin, output wire [0:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(1), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_carry_select_w5_component_block_adder_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




















// carry_skip: blocks [2, 1, 2] (trapezoidal_variable), 1 skip level, mux
module fam_adder_carry_skip_p035b672f454741e836110d2b293e320d2adf30f103464a83f97bd3dfd9837ae4_w5 (input logic [4:0] a, input logic [4:0] b, input logic cin, output logic [4:0] s, output logic cout);
  logic P0; assign P0 = &(a[1:0] ^ b[1:0]);
  logic P1; assign P1 = &(a[2:2] ^ b[2:2]);
  logic P2; assign P2 = &(a[4:3] ^ b[4:3]);
  logic [1:0] s0;
  logic co0;
  // block 0 (2 bits)
  fam_adder_carry_skip_p035b672f454741e836110d2b293e320d2adf30f103464a83f97bd3dfd9837ae4_w5_component_block_adder_adder_w2 u1 (.a(a[1:0]), .b(b[1:0]), .cin(cin), .s(s0), .cout(co0));
  assign s[1:0] = s0;
  logic bc0;
  assign bc0 = P0 ? cin : co0;
  logic s1;
  logic co1;
  // block 1 (1 bits)
  fam_adder_carry_skip_p035b672f454741e836110d2b293e320d2adf30f103464a83f97bd3dfd9837ae4_w5_component_block_adder_adder_w1 u2 (.a(a[2:2]), .b(b[2:2]), .cin(bc0), .s(s1), .cout(co1));
  assign s[2:2] = s1;
  logic bc1;
  assign bc1 = P1 ? bc0 : co1;
  logic [1:0] s2;
  logic co2;
  // block 2 (2 bits)
  fam_adder_carry_skip_p035b672f454741e836110d2b293e320d2adf30f103464a83f97bd3dfd9837ae4_w5_component_block_adder_adder_w2 u3 (.a(a[4:3]), .b(b[4:3]), .cin(bc1), .s(s2), .cout(co2));
  assign s[4:3] = s2;
  logic bc2;
  assign bc2 = P2 ? bc1 : co2;
  assign cout = bc2;
endmodule




module fam_adder_carry_skip_p035b672f454741e836110d2b293e320d2adf30f103464a83f97bd3dfd9837ae4_w5_component_block_adder_adder_w1(input wire [0:0] a, input wire [0:0] b, input wire [0:0] cin, output wire [0:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(1), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_carry_skip_p035b672f454741e836110d2b293e320d2adf30f103464a83f97bd3dfd9837ae4_w5_component_block_adder_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule



// ------------------------------------------------------------ the lookahead levels
// The carries into N elements from their generate and propagate pairs and a
// carry-in: LEVELS = 1 resolves the N elements flat, the element carries
// rippled (INTER = 0) or looked ahead (INTER = 1); LEVELS > 1 groups G
// elements into super-groups, resolves the super-group carries with the same
// structure one level up, and looks ahead inside every super-group.
module fam_adder_cla_level #(parameter int N = 4, parameter int G = 4, parameter int LEVELS = 1, parameter int INTER = 0)
  (input logic [N-1:0] gg, input logic [N-1:0] gp, input logic cin, output logic [N-1:0] c, output logic cout);
  genvar k, i;
  generate
    if (LEVELS <= 1 || N <= G) begin : flat
      if (INTER == 1) begin : lookahead
        for (k = 0; k < N; k = k + 1) begin : lg
          logic [k+1:0] t;
          assign t[0] = cin;
          for (i = 0; i <= k; i = i + 1) begin : tt
            assign t[i+1] = gg[i] | (gp[i] & t[i]);
          end
          assign c[k] = t[k];
          if (k == N - 1) begin : last
            assign cout = t[k+1];
          end
        end
      end else if (INTER == 2) begin : select
        logic [N:0] r;
        assign r[0] = cin;
        for (k = 0; k < N; k = k + 1) begin : rg
          assign r[k+1] = r[k] ? (gg[k] | gp[k]) : gg[k];
          assign c[k] = r[k];
        end
        assign cout = r[N];
      end else begin : ripple
        logic [N:0] r;
        assign r[0] = cin;
        for (k = 0; k < N; k = k + 1) begin : rg
          assign r[k+1] = gg[k] | (gp[k] & r[k]);
          assign c[k] = r[k];
        end
        assign cout = r[N];
      end
    end else begin : hier
      localparam int NS = (N + G - 1) / G;
      logic [NS-1:0] sgg, sgp, sc;
      for (k = 0; k < NS; k = k + 1) begin : sg
        localparam int LO = k * G;
        localparam int HI = (LO + G > N) ? N : LO + G;
        // the super-group's generate and propagate from its elements
        logic [HI-LO:0] lg, lp;
        assign lg[0] = 1'b0;
        assign lp[0] = 1'b1;
        for (i = 0; i < HI - LO; i = i + 1) begin : acc
          assign lg[i+1] = gg[LO+i] | (gp[LO+i] & lg[i]);
          assign lp[i+1] = gp[LO+i] & lp[i];
          // the lookahead carry into element LO+i from the super-group carry-in
          if (INTER == 2) begin : select
            assign c[LO+i] = sc[k] ? (lg[i] | lp[i]) : lg[i];
          end else begin : lookahead
            assign c[LO+i] = lg[i] | (lp[i] & sc[k]);
          end
        end
        assign sgg[k] = lg[HI-LO];
        assign sgp[k] = lp[HI-LO];
      end
      fam_adder_cla_level #(.N(NS), .G(G), .LEVELS(LEVELS - 1), .INTER(INTER))
        u_up (.gg(sgg), .gp(sgp), .cin(cin), .c(sc), .cout(cout));
    end
  endgenerate
endmodule



// ------------------------------------------------------------- conditional_sum
// base blocks of BASE bits ripple their sum and carry for both carry-ins; a
// level merges RADIX consecutive blocks (2 or 4: the selection radix) by
// selecting each upper block's pair by the carry out of the blocks below it
// within the merged group, until one block spans the word
module fam_adder_conditional_sum #(parameter int W = 16, parameter int BASE = 1, parameter int RADIX = 2)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  localparam int R = (RADIX == 4) ? 4 : 2;
  localparam int BS = (BASE < 1) ? 1 : BASE;
  localparam int NB0 = (W + BS - 1) / BS;                 // the base blocks
  localparam int L = (NB0 <= 1) ? 0 : ((R == 4) ? ($clog2(NB0) + 1) / 2 : $clog2(NB0));
  localparam int NBP = 1;                                 // (unused: the padded count follows below)
  // the padded block count: R^L base blocks
  function automatic int powi(input int base_, input int e);
    int r_, i_;
    r_ = 1;
    for (i_ = 0; i_ < e; i_ = i_ + 1) r_ = r_ * base_;
    return r_;
  endfunction
  localparam int NBL = powi(R, L);                        // base blocks after padding
  localparam int WP = NBL * BS;                           // the padded width
  logic [WP-1:0] ap, bp;
  assign ap = {{(WP-W){1'b0}}, a};
  assign bp = {{(WP-W){1'b0}}, b};
  // per level: the sums under carry-in 0 and 1, and the carry out of the block a bit ends
  logic [WP-1:0] s0 [0:L];
  logic [WP-1:0] s1 [0:L];
  logic [WP-1:0] c0 [0:L];
  logic [WP-1:0] c1 [0:L];
  genvar l, i, m;
  generate
    // level 0: the base blocks rippled for both carry-ins
    for (i = 0; i < NBL; i = i + 1) begin : base
      localparam int LO = i * BS;
      logic [BS:0] r0, r1;
      assign r0[0] = 1'b0;
      assign r1[0] = 1'b1;
      for (m = 0; m < BS; m = m + 1) begin : bit_
        assign s0[0][LO+m] = ap[LO+m] ^ bp[LO+m] ^ r0[m];
        assign r0[m+1] = (ap[LO+m] & bp[LO+m]) | ((ap[LO+m] ^ bp[LO+m]) & r0[m]);
        assign s1[0][LO+m] = ap[LO+m] ^ bp[LO+m] ^ r1[m];
        assign r1[m+1] = (ap[LO+m] & bp[LO+m]) | ((ap[LO+m] ^ bp[LO+m]) & r1[m]);
        // the carry out of bit LO+m under the block's carry-in (the block's carry-out at its top bit)
        assign c0[0][LO+m] = r0[m+1];
        assign c1[0][LO+m] = r1[m+1];
      end
    end
    for (l = 0; l < L; l = l + 1) begin : lvl
      localparam int BW = BS * powi(R, l);                // the block width at this level
      for (i = 0; i < WP; i = i + 1) begin : bit_
        localparam int GRP = i / (BW * R);                // the merged group
        localparam int POS = (i / BW) % R;                // the block's position in the group
        localparam int GLO = GRP * BW * R;                // the group's first bit
        if (POS == 0) begin : lower
          assign s0[l+1][i] = s0[l][i];
          assign s1[l+1][i] = s1[l][i];
          assign c0[l+1][i] = c0[l][i];
          assign c1[l+1][i] = c1[l][i];
        end else begin : upper
          // the carry into this block under the group's carry-in 0 / 1: the chain of the blocks below
          logic [POS:0] k0, k1;
          assign k0[0] = 1'b0;
          assign k1[0] = 1'b1;
          genvar q;
          for (q = 0; q < POS; q = q + 1) begin : chain
            localparam int E = GLO + q * BW + BW - 1;     // the last bit of block q
            assign k0[q+1] = k0[q] ? c1[l][E] : c0[l][E];
            assign k1[q+1] = k1[q] ? c1[l][E] : c0[l][E];
          end
          assign s0[l+1][i] = k0[POS] ? s1[l][i] : s0[l][i];
          assign c0[l+1][i] = k0[POS] ? c1[l][i] : c0[l][i];
          assign s1[l+1][i] = k1[POS] ? s1[l][i] : s0[l][i];
          assign c1[l+1][i] = k1[POS] ? c1[l][i] : c0[l][i];
        end
      end
    end
  endgenerate
  assign s = cin ? s1[L][W-1:0] : s0[L][W-1:0];
  assign cout = cin ? c1[L][W-1] : c0[L][W-1];
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).
module fam_adder_ripple_carry #(parameter int W = 16, parameter int CHUNK = 1, parameter int FORM = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  localparam int BLOCKS = (W + CHUNK - 1) / CHUNK;
  logic [BLOCKS:0] block_carry;
  assign block_carry[0] = cin;
  for (genvar block_index = 0; block_index < BLOCKS; block_index = block_index + 1) begin : chunk
    localparam int LO = block_index * CHUNK;
    localparam int BW = LO + CHUNK > W ? W - LO : CHUNK;
    (* keep_hierarchy = "yes" *) fam_adder_ripple_chunk #(.W(BW), .FORM(FORM)) u_chunk(
      .a(a[LO +: BW]), .b(b[LO +: BW]), .cin(block_carry[block_index]),
      .s(s[LO +: BW]), .cout(block_carry[block_index+1]));
  end
  assign cout = block_carry[BLOCKS];
endmodule







module fam_adder_ripple_chunk #(parameter int W = 1, parameter int FORM = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  logic [W:0] c;
  assign c[0] = cin;
  genvar i;
  generate
    for (i = 0; i < W; i = i + 1) begin : fa
      if (FORM == 1) begin : two_ha
        wire s1 = a[i] ^ b[i];
        wire c1 = a[i] & b[i];
        wire c2 = s1 & c[i];
        assign s[i] = s1 ^ c[i];
        assign c[i+1] = c1 | c2;
      end else if (FORM == 2) begin : maj
        assign s[i] = a[i] ^ b[i] ^ c[i];
        assign c[i+1] = (a[i] & b[i]) | (a[i] & c[i]) | (b[i] & c[i]);
      end else if (FORM == 3) begin : muxc
        wire p = a[i] ^ b[i];
        assign s[i] = p ^ c[i];
        assign c[i+1] = p ? c[i] : a[i];
      end else begin : gp
        wire g = a[i] & b[i];
        wire p = a[i] ^ b[i];
        assign s[i] = p ^ c[i];
        assign c[i+1] = g | (p & c[i]);
      end
    end
  endgenerate
  assign cout = c[W];
endmodule




// sparse_prefix_hybrid: a sklansky prefix network over blocks of 2 bits, the sums by ripple_precompute












// sparse_prefix_hybrid: a sklansky prefix network over blocks of 2 bits, the sums by ripple_precompute
module fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w16 (input logic [15:0] a, input logic [15:0] b, input logic cin, output logic [15:0] s, output logic cout);
  logic [15:0] g; assign g = a & b;
  logic [15:0] p; assign p = a ^ b;
  logic BG0; assign BG0 = (g[1] | (p[1] & g[0]));
  logic BP0; assign BP0 = (p[1] & p[0]);
  logic BG1; assign BG1 = (g[3] | (p[3] & g[2]));
  logic BP1; assign BP1 = (p[3] & p[2]);
  logic BG2; assign BG2 = (g[5] | (p[5] & g[4]));
  logic BP2; assign BP2 = (p[5] & p[4]);
  logic BG3; assign BG3 = (g[7] | (p[7] & g[6]));
  logic BP3; assign BP3 = (p[7] & p[6]);
  logic BG4; assign BG4 = (g[9] | (p[9] & g[8]));
  logic BP4; assign BP4 = (p[9] & p[8]);
  logic BG5; assign BG5 = (g[11] | (p[11] & g[10]));
  logic BP5; assign BP5 = (p[11] & p[10]);
  logic BG6; assign BG6 = (g[13] | (p[13] & g[12]));
  logic BP6; assign BP6 = (p[13] & p[12]);
  logic BG7; assign BG7 = (g[15] | (p[15] & g[14]));
  logic BP7; assign BP7 = (p[15] & p[14]);
  logic [7:0] net_g; assign net_g = {BG7, BG6, BG5, BG4, BG3, BG2, BG1, BG0};
  logic [7:0] net_p; assign net_p = {BP7, BP6, BP5, BP4, BP3, BP2, BP1, BP0};
  logic [7:0] net_c;
  logic net_co;
  // the prefix network over the blocks (sklansky)
  fam_prefix_net_sklansky_w8 u1 (.g(net_g), .p(net_p), .cin(cin), .c(net_c), .cout(net_co));
  logic [1:0] s0;
  logic x0;
  // block 0: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w16_component_sum_block_adder_w2 u2 (.a(a[1:0]), .b(b[1:0]), .cin(net_c[0]), .s(s0), .cout(x0));
  assign s[1:0] = s0;
  logic [1:0] s1;
  logic x1;
  // block 1: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w16_component_sum_block_adder_w2 u3 (.a(a[3:2]), .b(b[3:2]), .cin(net_c[1]), .s(s1), .cout(x1));
  assign s[3:2] = s1;
  logic [1:0] s2;
  logic x2;
  // block 2: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w16_component_sum_block_adder_w2 u4 (.a(a[5:4]), .b(b[5:4]), .cin(net_c[2]), .s(s2), .cout(x2));
  assign s[5:4] = s2;
  logic [1:0] s3;
  logic x3;
  // block 3: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w16_component_sum_block_adder_w2 u5 (.a(a[7:6]), .b(b[7:6]), .cin(net_c[3]), .s(s3), .cout(x3));
  assign s[7:6] = s3;
  logic [1:0] s4;
  logic x4;
  // block 4: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w16_component_sum_block_adder_w2 u6 (.a(a[9:8]), .b(b[9:8]), .cin(net_c[4]), .s(s4), .cout(x4));
  assign s[9:8] = s4;
  logic [1:0] s5;
  logic x5;
  // block 5: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w16_component_sum_block_adder_w2 u7 (.a(a[11:10]), .b(b[11:10]), .cin(net_c[5]), .s(s5), .cout(x5));
  assign s[11:10] = s5;
  logic [1:0] s6;
  logic x6;
  // block 6: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w16_component_sum_block_adder_w2 u8 (.a(a[13:12]), .b(b[13:12]), .cin(net_c[6]), .s(s6), .cout(x6));
  assign s[13:12] = s6;
  logic [1:0] s7;
  logic x7;
  // block 7: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w16_component_sum_block_adder_w2 u9 (.a(a[15:14]), .b(b[15:14]), .cin(net_c[7]), .s(s7), .cout(x7));
  assign s[15:14] = s7;
  assign cout = net_co;
endmodule




module fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w16_component_sum_block_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_prefix_sklansky_w2_v4 implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule


// sparse_prefix_hybrid: a sklansky prefix network over blocks of 2 bits, the sums by ripple_precompute
module fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w6 (input logic [5:0] a, input logic [5:0] b, input logic cin, output logic [5:0] s, output logic cout);
  logic [5:0] g; assign g = a & b;
  logic [5:0] p; assign p = a ^ b;
  logic BG0; assign BG0 = (g[1] | (p[1] & g[0]));
  logic BP0; assign BP0 = (p[1] & p[0]);
  logic BG1; assign BG1 = (g[3] | (p[3] & g[2]));
  logic BP1; assign BP1 = (p[3] & p[2]);
  logic BG2; assign BG2 = (g[5] | (p[5] & g[4]));
  logic BP2; assign BP2 = (p[5] & p[4]);
  logic [2:0] net_g; assign net_g = {BG2, BG1, BG0};
  logic [2:0] net_p; assign net_p = {BP2, BP1, BP0};
  logic [2:0] net_c;
  logic net_co;
  // the prefix network over the blocks (sklansky)
  fam_prefix_net_sklansky_w3 u1 (.g(net_g), .p(net_p), .cin(cin), .c(net_c), .cout(net_co));
  logic [1:0] s0;
  logic x0;
  // block 0: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w6_component_sum_block_adder_w2 u2 (.a(a[1:0]), .b(b[1:0]), .cin(net_c[0]), .s(s0), .cout(x0));
  assign s[1:0] = s0;
  logic [1:0] s1;
  logic x1;
  // block 1: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w6_component_sum_block_adder_w2 u3 (.a(a[3:2]), .b(b[3:2]), .cin(net_c[1]), .s(s1), .cout(x1));
  assign s[3:2] = s1;
  logic [1:0] s2;
  logic x2;
  // block 2: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w6_component_sum_block_adder_w2 u4 (.a(a[5:4]), .b(b[5:4]), .cin(net_c[2]), .s(s2), .cout(x2));
  assign s[5:4] = s2;
  assign cout = net_co;
endmodule




module fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w6_component_sum_block_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_prefix_sklansky_w2_v4 implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule

// sparse_prefix_hybrid: a sklansky prefix network over blocks of 2 bits, the sums by ripple_precompute
module fam_adder_sparse_prefix_hybrid_p36fd82ab953ccb4995a8e1923d6edef046b1089c32e5aac0b4643aeefde6bf91_w8 (input logic [7:0] a, input logic [7:0] b, input logic cin, output logic [7:0] s, output logic cout);
  logic [7:0] g; assign g = a & b;
  logic [7:0] p; assign p = a ^ b;
  logic BG0; assign BG0 = (g[1] | (p[1] & g[0]));
  logic BP0; assign BP0 = (p[1] & p[0]);
  logic BG1; assign BG1 = (g[3] | (p[3] & g[2]));
  logic BP1; assign BP1 = (p[3] & p[2]);
  logic BG2; assign BG2 = (g[5] | (p[5] & g[4]));
  logic BP2; assign BP2 = (p[5] & p[4]);
  logic BG3; assign BG3 = (g[7] | (p[7] & g[6]));
  logic BP3; assign BP3 = (p[7] & p[6]);
  logic [3:0] net_g; assign net_g = {BG3, BG2, BG1, BG0};
  logic [3:0] net_p; assign net_p = {BP3, BP2, BP1, BP0};
  logic [3:0] net_c;
  logic net_co;
  // the prefix network over the blocks (sklansky)
  fam_prefix_net_sklansky_w4 u1 (.g(net_g), .p(net_p), .cin(cin), .c(net_c), .cout(net_co));
  logic [1:0] s0;
  logic x0;
  // block 0: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p36fd82ab953ccb4995a8e1923d6edef046b1089c32e5aac0b4643aeefde6bf91_w8_component_sum_block_adder_w2 u2 (.a(a[1:0]), .b(b[1:0]), .cin(net_c[0]), .s(s0), .cout(x0));
  assign s[1:0] = s0;
  logic [1:0] s1;
  logic x1;
  // block 1: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p36fd82ab953ccb4995a8e1923d6edef046b1089c32e5aac0b4643aeefde6bf91_w8_component_sum_block_adder_w2 u3 (.a(a[3:2]), .b(b[3:2]), .cin(net_c[1]), .s(s1), .cout(x1));
  assign s[3:2] = s1;
  logic [1:0] s2;
  logic x2;
  // block 2: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p36fd82ab953ccb4995a8e1923d6edef046b1089c32e5aac0b4643aeefde6bf91_w8_component_sum_block_adder_w2 u4 (.a(a[5:4]), .b(b[5:4]), .cin(net_c[2]), .s(s2), .cout(x2));
  assign s[5:4] = s2;
  logic [1:0] s3;
  logic x3;
  // block 3: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p36fd82ab953ccb4995a8e1923d6edef046b1089c32e5aac0b4643aeefde6bf91_w8_component_sum_block_adder_w2 u5 (.a(a[7:6]), .b(b[7:6]), .cin(net_c[3]), .s(s3), .cout(x3));
  assign s[7:6] = s3;
  assign cout = net_co;
endmodule




module fam_adder_sparse_prefix_hybrid_p36fd82ab953ccb4995a8e1923d6edef046b1089c32e5aac0b4643aeefde6bf91_w8_component_sum_block_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(1)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule

// sparse_prefix_hybrid: a kogge_stone prefix network over blocks of 4 bits, the sums by conditional_sum
module fam_adder_sparse_prefix_hybrid_p80a4980a643e7f96abce420e7211cfd6176603e909f321d18db0975395a28f34_w16 (input logic [15:0] a, input logic [15:0] b, input logic cin, output logic [15:0] s, output logic cout);
  logic [15:0] g; assign g = a & b;
  logic [15:0] p; assign p = a ^ b;
  logic BG0; assign BG0 = (g[3] | (p[3] & (g[2] | (p[2] & (g[1] | (p[1] & g[0]))))));
  logic BP0; assign BP0 = (p[3] & (p[2] & (p[1] & p[0])));
  logic BG1; assign BG1 = (g[7] | (p[7] & (g[6] | (p[6] & (g[5] | (p[5] & g[4]))))));
  logic BP1; assign BP1 = (p[7] & (p[6] & (p[5] & p[4])));
  logic BG2; assign BG2 = (g[11] | (p[11] & (g[10] | (p[10] & (g[9] | (p[9] & g[8]))))));
  logic BP2; assign BP2 = (p[11] & (p[10] & (p[9] & p[8])));
  logic BG3; assign BG3 = (g[15] | (p[15] & (g[14] | (p[14] & (g[13] | (p[13] & g[12]))))));
  logic BP3; assign BP3 = (p[15] & (p[14] & (p[13] & p[12])));
  logic [3:0] net_g; assign net_g = {BG3, BG2, BG1, BG0};
  logic [3:0] net_p; assign net_p = {BP3, BP2, BP1, BP0};
  logic [3:0] net_c;
  logic net_co;
  // the prefix network over the blocks (kogge_stone)
  fam_prefix_net_kogge_stone_w4 u1 (.g(net_g), .p(net_p), .cin(cin), .c(net_c), .cout(net_co));
  logic [3:0] s0;
  logic x0;
  // block 0: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(4), .BASE(1), .RADIX(2)) u2 (.a(a[3:0]), .b(b[3:0]), .cin(net_c[0]), .s(s0), .cout(x0));
  assign s[3:0] = s0;
  logic [3:0] s1;
  logic x1;
  // block 1: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(4), .BASE(1), .RADIX(2)) u3 (.a(a[7:4]), .b(b[7:4]), .cin(net_c[1]), .s(s1), .cout(x1));
  assign s[7:4] = s1;
  logic [3:0] s2;
  logic x2;
  // block 2: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(4), .BASE(1), .RADIX(2)) u4 (.a(a[11:8]), .b(b[11:8]), .cin(net_c[2]), .s(s2), .cout(x2));
  assign s[11:8] = s2;
  logic [3:0] s3;
  logic x3;
  // block 3: a conditional-sum block under the tree's carry
  fam_adder_conditional_sum #(.W(4), .BASE(1), .RADIX(2)) u5 (.a(a[15:12]), .b(b[15:12]), .cin(net_c[3]), .s(s3), .cout(x3));
  assign s[15:12] = s3;
  assign cout = net_co;
endmodule

// The comparator family of chiALU realized in parametric SystemVerilog:
//   fam_cmp_prefix_comparator #(W, SIGNED, STRUCTURE, RADIX) (input [W-1:0] a, b, output lt, eq)
// The subtractor form (subtractor_comparator) is generated by families/comparator.py around
// the adder of its `subtractor` slot.

// ------------------------------------------------------------ prefix_comparator
// STRUCTURE: 0 msb_first_prefix (a scan from the msb over groups of RADIX bits:
// each group gives (equal, less) flat, the groups are chained msb first), 1
// tree_reduction (a balanced tree of RADIX-ary nodes over the (equal, less)
// pairs). SIGNED flips the sign bits. RADIX is the bits a scan step groups, or
// the arity of a tree node.
module fam_cmp_prefix_comparator #(parameter int W = 16, parameter int SIGNED = 1, parameter int STRUCTURE = 0, parameter int RADIX = 2)
  (input logic [W-1:0] a, input logic [W-1:0] b, output logic lt, output logic eq);
  localparam int R = (RADIX < 2) ? 2 : RADIX;
  localparam int NG = (W + R - 1) / R;                 // the groups of R bits, group g at [g*R +: R] from the lsb
  // ceil(log_r n): the levels of an r-ary tree over n entries
  function automatic int clogr(input int n, input int r);
    int l, p;
    l = 0; p = 1;
    while (p < n) begin p = p * r; l = l + 1; end
    return l;
  endfunction
  // ceil(n / r^l): the entries of level l
  function automatic int entries(input int n, input int r, input int l);
    int m, i;
    m = n;
    for (i = 0; i < l; i = i + 1) m = (m + r - 1) / r;
    return m;
  endfunction
  logic [W-1:0] ax, bx;
  // a signed compare is an unsigned one with the sign bits inverted
  assign ax = {a[W-1] ^ (SIGNED != 0), a[W-2:0]};
  assign bx = {b[W-1] ^ (SIGNED != 0), b[W-2:0]};
  // per bit: equal, less
  logic [W-1:0] e0, l0;
  genvar i, g, l, k;
  generate
    for (i = 0; i < W; i = i + 1) begin : bit_
      assign e0[i] = (ax[i] == bx[i]);
      assign l0[i] = ~ax[i] & bx[i];
    end
    // per group of R bits (flat): equal = every bit equal; less = the first unequal bit from the top is less
    logic [NG-1:0] eg, lg;
    for (g = 0; g < NG; g = g + 1) begin : grp
      localparam int LO = g * R;
      localparam int HI = (LO + R - 1 < W - 1) ? LO + R - 1 : W - 1;
      localparam int N = HI - LO + 1;
      logic [N-1:0] ge, gl;
      assign ge = e0[HI:LO];
      assign gl = l0[HI:LO];
      assign eg[g] = &ge;
      logic [N-1:0] t;
      for (k = 0; k < N; k = k + 1) begin : tk
        // bit LO+k decides when the bits above it in the group are equal
        if (k == N - 1) begin : top
          assign t[k] = gl[k];
        end else begin : low
          assign t[k] = gl[k] & (&ge[N-1:k+1]);
        end
      end
      assign lg[g] = |t;
    end
    if (STRUCTURE == 0) begin : msb_first
      // the scan from the msb group down: e[g]: groups NG-1..g equal; ls[g]: a < b decided within them
      logic [NG:0] e, ls;
      assign e[NG] = 1'b1;
      assign ls[NG] = 1'b0;
      for (g = NG - 1; g >= 0; g = g - 1) begin : scan
        assign e[g] = e[g+1] & eg[g];
        assign ls[g] = ls[g+1] | (e[g+1] & lg[g]);
      end
      assign lt = ls[0];
      assign eq = e[0];
    end else begin : tree
      // a balanced R-ary tree over the group pairs: a node's (equal, less) from its children
      // (child c is more significant than child c-1): equal = AND of the children's equal, less =
      // OR over c of (less_c AND the children above c equal); level l holds ceil(NG / R^l) entries
      localparam int LV = (NG <= 1) ? 1 : clogr(NG, R);
      logic [NG-1:0] E [0:LV];
      logic [NG-1:0] LT [0:LV];
      assign E[0] = eg;
      assign LT[0] = lg;
      for (l = 0; l < LV; l = l + 1) begin : lvl
        localparam int MIN = entries(NG, R, l);       // the entries of the level below
        for (g = 0; g < NG; g = g + 1) begin : node
          if (g * R < MIN) begin : real_
            logic [R-1:0] ce, cl;
            for (k = 0; k < R; k = k + 1) begin : ck
              if (g * R + k < MIN) begin : in_
                assign ce[k] = E[l][g*R + k];
                assign cl[k] = LT[l][g*R + k];
              end else begin : pad
                assign ce[k] = 1'b1;
                assign cl[k] = 1'b0;
              end
            end
            assign E[l+1][g] = &ce;
            logic [R-1:0] t;
            for (k = 0; k < R; k = k + 1) begin : tk
              if (k == R - 1) begin : top
                assign t[k] = cl[k];
              end else begin : low
                assign t[k] = cl[k] & (&ce[R-1:k+1]);
              end
            end
            assign LT[l+1][g] = |t;
          end else begin : pad
            assign E[l+1][g] = 1'b1;
            assign LT[l+1][g] = 1'b0;
          end
        end
      end
      assign lt = LT[LV][0];
      assign eq = E[LV][0];
    end
  endgenerate
endmodule


// lzd_cell_tree (nibble_cell, binary_count, valid flags propagated): the leading zeros of a 16-bit word
module fam_count_lzd_nibble_cell_binary_count_vprop_w16 (input logic [15:0] a, output logic [4:0] n);
  logic v0_0; assign v0_0 = a[15] | a[14] | a[13] | a[12];
  logic [1:0] p0_0; assign p0_0 = a[15] ? 2'd0 : a[14] ? 2'd1 : a[13] ? 2'd2 : 2'd3;
  logic v0_1; assign v0_1 = a[11] | a[10] | a[9] | a[8];
  logic [1:0] p0_1; assign p0_1 = a[11] ? 2'd0 : a[10] ? 2'd1 : a[9] ? 2'd2 : 2'd3;
  logic v0_2; assign v0_2 = a[7] | a[6] | a[5] | a[4];
  logic [1:0] p0_2; assign p0_2 = a[7] ? 2'd0 : a[6] ? 2'd1 : a[5] ? 2'd2 : 2'd3;
  logic v0_3; assign v0_3 = a[3] | a[2] | a[1] | a[0];
  logic [1:0] p0_3; assign p0_3 = a[3] ? 2'd0 : a[2] ? 2'd1 : a[1] ? 2'd2 : 2'd3;
  logic v1_0; assign v1_0 = v0_0 | v0_1;
  logic [2:0] p1_0; assign p1_0 = v0_0 ? {1'b0, p0_0} : {1'b1, p0_1};
  logic v1_1; assign v1_1 = v0_2 | v0_3;
  logic [2:0] p1_1; assign p1_1 = v0_2 ? {1'b0, p0_2} : {1'b1, p0_3};
  logic v2_0; assign v2_0 = v1_0 | v1_1;
  logic [3:0] p2_0; assign p2_0 = v1_0 ? {1'b0, p1_0} : {1'b1, p1_1};
  assign n = v2_0 ? {1'd0, p2_0} : 5'd16;
endmodule



// prefix_lzc (sklansky prefix OR, lookahead_flags): the leading zeros of a 16-bit word
module fam_count_prefix_lzc_sklansky_flags_w16 (input logic [15:0] a, output logic [4:0] n);
  logic x0; assign x0 = a[15];
  logic x1; assign x1 = a[14];
  logic x2; assign x2 = a[13];
  logic x3; assign x3 = a[12];
  logic x4; assign x4 = a[11];
  logic x5; assign x5 = a[10];
  logic x6; assign x6 = a[9];
  logic x7; assign x7 = a[8];
  logic x8; assign x8 = a[7];
  logic x9; assign x9 = a[6];
  logic x10; assign x10 = a[5];
  logic x11; assign x11 = a[4];
  logic x12; assign x12 = a[3];
  logic x13; assign x13 = a[2];
  logic x14; assign x14 = a[1];
  logic x15; assign x15 = a[0];
  logic p_sk0_1; assign p_sk0_1 = x1 | x0;
  logic p_sk0_3; assign p_sk0_3 = x3 | x2;
  logic p_sk0_5; assign p_sk0_5 = x5 | x4;
  logic p_sk0_7; assign p_sk0_7 = x7 | x6;
  logic p_sk0_9; assign p_sk0_9 = x9 | x8;
  logic p_sk0_11; assign p_sk0_11 = x11 | x10;
  logic p_sk0_13; assign p_sk0_13 = x13 | x12;
  logic p_sk0_15; assign p_sk0_15 = x15 | x14;
  logic p_sk1_2; assign p_sk1_2 = x2 | p_sk0_1;
  logic p_sk1_3; assign p_sk1_3 = p_sk0_3 | p_sk0_1;
  logic p_sk1_6; assign p_sk1_6 = x6 | p_sk0_5;
  logic p_sk1_7; assign p_sk1_7 = p_sk0_7 | p_sk0_5;
  logic p_sk1_10; assign p_sk1_10 = x10 | p_sk0_9;
  logic p_sk1_11; assign p_sk1_11 = p_sk0_11 | p_sk0_9;
  logic p_sk1_14; assign p_sk1_14 = x14 | p_sk0_13;
  logic p_sk1_15; assign p_sk1_15 = p_sk0_15 | p_sk0_13;
  logic p_sk2_4; assign p_sk2_4 = x4 | p_sk1_3;
  logic p_sk2_5; assign p_sk2_5 = p_sk0_5 | p_sk1_3;
  logic p_sk2_6; assign p_sk2_6 = p_sk1_6 | p_sk1_3;
  logic p_sk2_7; assign p_sk2_7 = p_sk1_7 | p_sk1_3;
  logic p_sk2_12; assign p_sk2_12 = x12 | p_sk1_11;
  logic p_sk2_13; assign p_sk2_13 = p_sk0_13 | p_sk1_11;
  logic p_sk2_14; assign p_sk2_14 = p_sk1_14 | p_sk1_11;
  logic p_sk2_15; assign p_sk2_15 = p_sk1_15 | p_sk1_11;
  logic p_sk3_8; assign p_sk3_8 = x8 | p_sk2_7;
  logic p_sk3_9; assign p_sk3_9 = p_sk0_9 | p_sk2_7;
  logic p_sk3_10; assign p_sk3_10 = p_sk1_10 | p_sk2_7;
  logic p_sk3_11; assign p_sk3_11 = p_sk1_11 | p_sk2_7;
  logic p_sk3_12; assign p_sk3_12 = p_sk2_12 | p_sk2_7;
  logic p_sk3_13; assign p_sk3_13 = p_sk2_13 | p_sk2_7;
  logic p_sk3_14; assign p_sk3_14 = p_sk2_14 | p_sk2_7;
  logic p_sk3_15; assign p_sk3_15 = p_sk2_15 | p_sk2_7;
  logic f0; assign f0 = x0;
  logic f1; assign f1 = p_sk0_1 & ~x0;
  logic f2; assign f2 = p_sk1_2 & ~p_sk0_1;
  logic f3; assign f3 = p_sk1_3 & ~p_sk1_2;
  logic f4; assign f4 = p_sk2_4 & ~p_sk1_3;
  logic f5; assign f5 = p_sk2_5 & ~p_sk2_4;
  logic f6; assign f6 = p_sk2_6 & ~p_sk2_5;
  logic f7; assign f7 = p_sk2_7 & ~p_sk2_6;
  logic f8; assign f8 = p_sk3_8 & ~p_sk2_7;
  logic f9; assign f9 = p_sk3_9 & ~p_sk3_8;
  logic f10; assign f10 = p_sk3_10 & ~p_sk3_9;
  logic f11; assign f11 = p_sk3_11 & ~p_sk3_10;
  logic f12; assign f12 = p_sk3_12 & ~p_sk3_11;
  logic f13; assign f13 = p_sk3_13 & ~p_sk3_12;
  logic f14; assign f14 = p_sk3_14 & ~p_sk3_13;
  logic f15; assign f15 = p_sk3_15 & ~p_sk3_14;
  logic [4:0] enc;
  // the leading-one flags encoded by one OR tree per count bit
  assign enc[0] = f1 | f3 | f5 | f7 | f9 | f11 | f13 | f15;
  assign enc[1] = f2 | f3 | f6 | f7 | f10 | f11 | f14 | f15;
  assign enc[2] = f4 | f5 | f6 | f7 | f12 | f13 | f14 | f15;
  assign enc[3] = f8 | f9 | f10 | f11 | f12 | f13 | f14 | f15;
  assign enc[4] = 1'b0;
  assign n = p_sk3_15 ? enc : 5'd16;
endmodule


// trailing_zero (isolate_then_encode, twos_complement_and): the lowest one isolated and encoded
module fam_count_tzc_isolate_then_encode_twos_complement_and_pb78b9_w8 (input logic [7:0] a, output logic [3:0] n);
  logic [7:0] low;
  logic [7:0] na; assign na = ~a;
  logic [7:0] neg;
  // -a = ~a + 1 through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(2)) u1 (.a(na), .cin(1'b1), .s(neg), .cout());
  assign low = a & neg;
  logic [3:0] enc;
  // the isolated one encoded to its index
  assign enc[0] = low[1] | low[3] | low[5] | low[7];
  assign enc[1] = low[2] | low[3] | low[6] | low[7];
  assign enc[2] = low[4] | low[5] | low[6] | low[7];
  assign enc[3] = 1'b0;
  assign n = (low == 8'd0) ? 4'd8 : enc;
endmodule


// trailing_zero (reverse_then_lzd over prefix_lzc): the word reversed into the leading-zero detector
module fam_count_tzc_reverse_prefix_lzc_p1c2a0_w16 (input logic [15:0] a, output logic [4:0] n);
  logic [15:0] r; assign r = {a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12], a[13], a[14], a[15]};
  // the leading-zero detector (prefix_lzc) on the reversed word
  fam_count_prefix_lzc_sklansky_flags_w16 u1 (.a(r), .n(n));
endmodule






// ------------------------------------------------------------ prefix_and_incrementer
// s = a + cin: the carry into bit i is cin AND every lower bit, a prefix AND
// (STRUCTURE 0 a ripple AND chain, 1 a prefix AND tree of topology TOPO, 2
// select blocks of B bits whose block carry is the AND of the block)
module fam_incr_prefix_and #(parameter int W = 16, parameter int STRUCTURE = 1, parameter int B = 4, parameter int TOPO = 0)
  (input logic [W-1:0] a, input logic cin, output logic [W-1:0] s, output logic cout);
  // STRUCTURE: 0 ripple_and_chain, 1 prefix_and_tree (TOPO: 0 sklansky, 1 brent_kung, 2 kogge_stone),
  // 2 select_blocks of B bits
  logic [W:0] c;
  assign c[0] = cin;
  genvar i, l;
  generate
    if (STRUCTURE == 0) begin : ripple
      for (i = 0; i < W; i = i + 1) begin : ch
        assign c[i+1] = c[i] & a[i];
      end
    end else if (STRUCTURE == 1) begin : tree
      localparam int L = (W <= 1) ? 1 : $clog2(W);
      if (TOPO == 2) begin : kogge_stone
        // p[l][i]: AND of a[i] down to a[i - 2^l + 1]
        logic [W-1:0] p [0:L];
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : lvl
          for (i = 0; i < W; i = i + 1) begin : pos
            if (i >= (1 << l)) begin : comb
              assign p[l+1][i] = p[l][i] & p[l][i - (1 << l)];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[L][i];
        end
      end else if (TOPO == 1) begin : brent_kung
        // an up-sweep over the odd positions of each level, then a down-sweep filling the rest
        logic [W-1:0] p [0:2*L];
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : up
          for (i = 0; i < W; i = i + 1) begin : pos
            if (((i + 1) % (2 << l)) == 0) begin : comb
              assign p[l+1][i] = p[l][i] & p[l][i - (1 << l)];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (l = 0; l < L; l = l + 1) begin : down
          localparam int D = 1 << (L - 1 - l);
          for (i = 0; i < W; i = i + 1) begin : pos
            if (((i + 1) % (2 * D)) == D && (i + 1) > D) begin : comb
              assign p[L+l+1][i] = p[L+l][i] & p[L+l][i - D];
            end else begin : keep
              assign p[L+l+1][i] = p[L+l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[2*L][i];
        end
      end else begin : sklansky
        logic [W-1:0] p [0:L];           // p[l][i]: AND of a[i] down to a[i - 2^l + 1]
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : lvl
          for (i = 0; i < W; i = i + 1) begin : pos
            if ((i / (1 << l)) % 2 == 1) begin : comb   // the upper half of every block takes the lower half's end
              assign p[l+1][i] = p[l][i] & p[l][(i / (1 << l)) * (1 << l) - 1];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[L][i];
        end
      end
    end else begin : blocks
      localparam int NB = (W + B - 1) / B;
      logic [NB:0] bc;                  // the carry into each block
      assign bc[0] = cin;
      for (i = 0; i < NB; i = i + 1) begin : blk
        localparam int LO = i * B;
        localparam int HI = (LO + B - 1 < W - 1) ? LO + B - 1 : W - 1;
        logic all1;
        assign all1 = &a[HI:LO];
        assign bc[i+1] = bc[i] & all1;
        genvar j;
        for (j = LO; j <= HI; j = j + 1) begin : bit_
          if (j == LO) begin : first
            assign c[j+1] = bc[i] & a[j];
          end else begin : rest
            assign c[j+1] = c[j] & a[j];
          end
        end
      end
    end
  endgenerate
  assign s = a ^ c[W-1:0];
  assign cout = c[W];
endmodule





// The logic family library: the bitwise gate row of lane_replicated_gates and wide_gate_row.
//   fam_logic_gate_row #(W, NOT_VIA_XOR) (input [W-1:0] a, b, input [1:0] op, output [W-1:0] y)
//   op: 0 and, 1 or, 2 xor, 3 not (of a)
// NOT_VIA_XOR = 1 forms the not as a xor with ones, so the row is three gate types and a
// two-way operand select instead of four gate types under a four-way result mux.
module fam_logic_gate_row #(parameter int W = 16, parameter int NOT_VIA_XOR = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic [1:0] op, output logic [W-1:0] y);
  generate
    if (NOT_VIA_XOR) begin : via_xor
      logic [W-1:0] bx;
      assign bx = (op == 2'd3) ? {W{1'b1}} : b;
      assign y = (op == 2'd0) ? (a & b) : (op == 2'd1) ? (a | b) : (a ^ bx);
    end else begin : plain
      assign y = (op == 2'd0) ? (a & b) : (op == 2'd1) ? (a | b) : (op == 2'd2) ? (a ^ b) : ~a;
    end
  endgenerate
endmodule



module fam_mul_direct_dadda_3_2_w10_s_p586fca89 (input logic [9:0] a, input logic [9:0] b, output logic [19:0] p);
  // direct_pp_parallel: {'pp_bits': 66, 'full_adders': 0, 'half_adders': 1, 'cells': 0, 'tree_depth': 6}
  logic sel0, sel1, sel2, pp3, pp4, pp5, pp6, pp7, pp8, pp9, pp10, pp11, pp12, pp13, pp14, sel15, sel16, sel17, pp18, pp19, pp20, pp21, pp22, pp23, pp24, pp25, pp26, pp27, pp28, pp29, sel30, sel31, sel32, pp33, pp34, pp35, pp36, pp37, pp38, pp39, pp40, pp41, pp42, pp43, pp44, sel45, sel46, sel47, pp48, pp49, pp50, pp51, pp52, pp53, pp54, pp55, pp56, pp57, pp58, pp59, neg60, neg61, neg62, sel63, sel64, pp65, pp66, pp67, pp68, pp69, pp70, pp71, pp72, pp73, pp74, pp75, pp76, pp77, pp78, pp79, pp80, pp81, pp82, pp83, pp84, pp85, pp86, pp87, pp88, ns89, ns90, ns91, ns92, ns93, t94, t95;
  logic [11:0] a_ext;
  logic [11:0] m2;
  logic [11:0] m3; logic m3_co;
  // the hard multiple 3a = 2a + a through the adder (prefix_synthesis_nonuniform_arrival)
  fam_prefix_arrival_0_0_1_1_1_2_2_3_3_3_4_4_w12 u_i1 (.a(m2), .b(a_ext), .cin(1'b0), .s(m3), .cout(m3_co));
  logic [7:0] ts1; logic tc1;
  // tile 1 (prefix_synthesis_nonuniform_arrival, 8 bits) at level 0
  fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 u_i2 (.a({pp10, pp9, pp8, pp7, pp6, pp5, pp4, pp3}), .b({pp23, pp22, pp21, pp20, pp19, pp18, 1'b0, 1'b0}), .cin(1'b0), .s(ts1), .cout(tc1));
  logic [7:0] ts2; logic tc2;
  // tile 2 (prefix_synthesis_nonuniform_arrival, 8 bits) at level 0
  fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 u_i3 (.a({ns91, pp43, ns90, pp28, ns89, pp13, pp12, pp11}), .b({pp57, pp56, pp42, pp41, pp27, pp26, pp25, pp24}), .cin(1'b0), .s(ts2), .cout(tc2));
  logic [3:0] ts3; logic tc3;
  // tile 3 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 0
  fam_prefix_arrival_0_1_1_2_w4 u_i4 (.a({ns93, pp86, ns92, pp58}), .b({1'b0, 1'b1, pp84, pp82}), .cin(1'b0), .s(ts3), .cout(tc3));
  logic [7:0] ts4; logic tc4;
  // tile 4 (prefix_synthesis_nonuniform_arrival, 8 bits) at level 0
  fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 u_i5 (.a({pp36, pp35, pp34, pp33, 1'b0, 1'b0, 1'b0, 1'b0}), .b({pp49, pp48, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0}), .cin(1'b0), .s(ts4), .cout(tc4));
  logic [7:0] ts5; logic tc5;
  // tile 5 (prefix_synthesis_nonuniform_arrival, 8 bits) at level 0
  fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 u_i6 (.a({pp80, pp78, pp55, pp54, pp40, pp39, pp38, pp37}), .b({1'b0, 1'b1, pp76, pp74, pp53, pp52, pp51, pp50}), .cin(1'b0), .s(ts5), .cout(tc5));
  logic [7:0] ts6; logic tc6;
  // tile 6 (prefix_synthesis_nonuniform_arrival, 8 bits) at level 0
  fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 u_i7 (.a({1'b0, 1'b0, 1'b0, 1'b1, pp72, pp70, pp68, pp66}), .b({1'b0, 1'b0, 1'b0, 1'b0, 1'b1, 1'b0, 1'b0, neg62}), .cin(1'b0), .s(ts6), .cout(tc6));
  logic [3:0] ts7; logic tc7;
  // tile 7 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 1
  fam_prefix_arrival_0_1_1_2_w4 u_i8 (.a({ts1[3], ts1[2], ts1[1], ts1[0]}), .b({ts4[3], ts4[2], ts4[1], ts4[0]}), .cin(1'b0), .s(ts7), .cout(tc7));
  logic [7:0] ts8; logic tc8;
  // tile 8 (prefix_synthesis_nonuniform_arrival, 8 bits) at level 1
  fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 u_i9 (.a({ts2[3], ts2[2], ts2[1], ts2[0], ts1[7], ts1[6], ts1[5], ts1[4]}), .b({ts5[3], ts5[2], ts5[1], ts5[0], ts4[7], ts4[6], ts4[5], ts4[4]}), .cin(1'b0), .s(ts8), .cout(tc8));
  logic [7:0] ts9; logic tc9;
  // tile 9 (prefix_synthesis_nonuniform_arrival, 8 bits) at level 1
  fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 u_i10 (.a({ts3[3], ts3[2], ts3[1], ts3[0], ts2[7], ts2[6], ts2[5], ts2[4]}), .b({1'b0, 1'b0, 1'b0, 1'b1, ts5[7], ts5[6], ts5[5], ts5[4]}), .cin(1'b0), .s(ts9), .cout(tc9));
  logic [7:0] ts10; logic tc10;
  // tile 10 (prefix_synthesis_nonuniform_arrival, 8 bits) at level 1
  fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 u_i11 (.a({ts6[3], ts6[2], ts6[1], ts6[0], 1'b0, 1'b0, 1'b0, 1'b0}), .b({1'b0, 1'b0, 1'b0, tc1, 1'b0, 1'b0, 1'b0, 1'b0}), .cin(1'b0), .s(ts10), .cout(tc10));
  logic [7:0] ts11; logic tc11;
  // tile 11 (prefix_synthesis_nonuniform_arrival, 8 bits) at level 1
  fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 u_i12 (.a({1'b0, 1'b0, 1'b0, 1'b0, ts6[7], ts6[6], ts6[5], ts6[4]}), .b({1'b0, 1'b0, 1'b0, tc2, 1'b0, 1'b0, 1'b0, 1'b0}), .cin(1'b0), .s(ts11), .cout(tc11));
  logic [7:0] ts12; logic tc12;
  // tile 12 (prefix_synthesis_nonuniform_arrival, 8 bits) at level 1
  fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 u_i13 (.a({1'b0, 1'b0, 1'b0, tc5, 1'b0, 1'b0, 1'b0, 1'b0}), .b({1'b0, 1'b0, 1'b0, tc6, 1'b0, 1'b0, 1'b0, 1'b0}), .cin(1'b0), .s(ts12), .cout(tc12));
  logic [7:0] ts13; logic tc13;
  // tile 13 (prefix_synthesis_nonuniform_arrival, 8 bits) at level 2
  fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 u_i14 (.a({ts8[3], ts8[2], ts8[1], ts8[0], ts7[3], ts7[2], ts7[1], ts7[0]}), .b({ts10[3], ts10[2], ts10[1], ts10[0], 1'b0, 1'b0, 1'b0, 1'b0}), .cin(1'b0), .s(ts13), .cout(tc13));
  logic [7:0] ts14; logic tc14;
  // tile 14 (prefix_synthesis_nonuniform_arrival, 8 bits) at level 2
  fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 u_i15 (.a({ts9[3], ts9[2], ts9[1], ts9[0], ts8[7], ts8[6], ts8[5], ts8[4]}), .b({ts11[3], ts11[2], ts11[1], ts11[0], ts10[7], ts10[6], ts10[5], ts10[4]}), .cin(1'b0), .s(ts14), .cout(tc14));
  logic [3:0] ts15; logic tc15;
  // tile 15 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 2
  fam_prefix_arrival_0_1_1_2_w4 u_i16 (.a({ts9[7], ts9[6], ts9[5], ts9[4]}), .b({ts11[7], ts11[6], ts11[5], ts11[4]}), .cin(1'b0), .s(ts15), .cout(tc15));
  logic [7:0] ts16; logic tc16;
  // tile 16 (prefix_synthesis_nonuniform_arrival, 8 bits) at level 2
  fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 u_i17 (.a({ts12[3], ts12[2], ts12[1], ts12[0], 1'b0, 1'b0, 1'b0, tc4}), .b({1'b0, 1'b0, 1'b0, tc8, 1'b0, 1'b0, 1'b0, 1'b0}), .cin(1'b0), .s(ts16), .cout(tc16));
  logic [7:0] ts17; logic tc17;
  // tile 17 (prefix_synthesis_nonuniform_arrival, 8 bits) at level 3
  fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 u_i18 (.a({ts14[3], ts14[2], ts14[1], ts14[0], ts13[7], ts13[6], ts13[5], ts13[4]}), .b({ts16[3], ts16[2], ts16[1], ts16[0], 1'b0, 1'b0, 1'b0, tc7}), .cin(1'b0), .s(ts17), .cout(tc17));
  logic [7:0] ts18; logic tc18;
  // tile 18 (prefix_synthesis_nonuniform_arrival, 8 bits) at level 3
  fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 u_i19 (.a({ts15[3], ts15[2], ts15[1], ts15[0], ts14[7], ts14[6], ts14[5], ts14[4]}), .b({ts12[7], ts12[6], ts12[5], ts12[4], ts16[7], ts16[6], ts16[5], ts16[4]}), .cin(1'b0), .s(ts18), .cout(tc18));
  logic [7:0] ts19; logic tc19;
  // tile 19 (prefix_synthesis_nonuniform_arrival, 8 bits) at level 3
  fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 u_i20 (.a({1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, tc10}), .b({1'b0, 1'b0, 1'b0, tc14, 1'b0, 1'b0, 1'b0, 1'b0}), .cin(1'b0), .s(ts19), .cout(tc19));
  logic [7:0] ts20; logic tc20;
  // tile 20 (prefix_synthesis_nonuniform_arrival, 8 bits) at level 4
  fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 u_i21 (.a({ts18[3], ts18[2], ts18[1], ts18[0], ts17[7], ts17[6], ts17[5], ts17[4]}), .b({ts19[3], ts19[2], ts19[1], ts19[0], 1'b0, 1'b0, 1'b0, tc13}), .cin(1'b0), .s(ts20), .cout(tc20));
  logic [3:0] ts21; logic tc21;
  // tile 21 (prefix_synthesis_nonuniform_arrival, 4 bits) at level 4
  fam_prefix_arrival_0_1_1_2_w4 u_i22 (.a({ts18[7], ts18[6], ts18[5], ts18[4]}), .b({ts19[7], ts19[6], ts19[5], ts19[4]}), .cin(1'b0), .s(ts21), .cout(tc21));
  assign a_ext = {{2{a[9]}}, a};
  assign sel0 = b[0] & ~b[1];
  assign sel1 = ~b[0] & b[1];
  assign sel2 = b[0] & b[1];
  assign m2 = {a_ext[10:0], 1'd0};
  assign pp3 = (sel0 & a_ext[0]) | (sel1 & m2[0]) | (sel2 & m3[0]);
  assign pp4 = (sel0 & a_ext[1]) | (sel1 & m2[1]) | (sel2 & m3[1]);
  assign pp5 = (sel0 & a_ext[2]) | (sel1 & m2[2]) | (sel2 & m3[2]);
  assign pp6 = (sel0 & a_ext[3]) | (sel1 & m2[3]) | (sel2 & m3[3]);
  assign pp7 = (sel0 & a_ext[4]) | (sel1 & m2[4]) | (sel2 & m3[4]);
  assign pp8 = (sel0 & a_ext[5]) | (sel1 & m2[5]) | (sel2 & m3[5]);
  assign pp9 = (sel0 & a_ext[6]) | (sel1 & m2[6]) | (sel2 & m3[6]);
  assign pp10 = (sel0 & a_ext[7]) | (sel1 & m2[7]) | (sel2 & m3[7]);
  assign pp11 = (sel0 & a_ext[8]) | (sel1 & m2[8]) | (sel2 & m3[8]);
  assign pp12 = (sel0 & a_ext[9]) | (sel1 & m2[9]) | (sel2 & m3[9]);
  assign pp13 = (sel0 & a_ext[10]) | (sel1 & m2[10]) | (sel2 & m3[10]);
  assign pp14 = (sel0 & a_ext[11]) | (sel1 & m2[11]) | (sel2 & m3[11]);
  assign sel15 = b[2] & ~b[3];
  assign sel16 = ~b[2] & b[3];
  assign sel17 = b[2] & b[3];
  assign pp18 = (sel15 & a_ext[0]) | (sel16 & m2[0]) | (sel17 & m3[0]);
  assign pp19 = (sel15 & a_ext[1]) | (sel16 & m2[1]) | (sel17 & m3[1]);
  assign pp20 = (sel15 & a_ext[2]) | (sel16 & m2[2]) | (sel17 & m3[2]);
  assign pp21 = (sel15 & a_ext[3]) | (sel16 & m2[3]) | (sel17 & m3[3]);
  assign pp22 = (sel15 & a_ext[4]) | (sel16 & m2[4]) | (sel17 & m3[4]);
  assign pp23 = (sel15 & a_ext[5]) | (sel16 & m2[5]) | (sel17 & m3[5]);
  assign pp24 = (sel15 & a_ext[6]) | (sel16 & m2[6]) | (sel17 & m3[6]);
  assign pp25 = (sel15 & a_ext[7]) | (sel16 & m2[7]) | (sel17 & m3[7]);
  assign pp26 = (sel15 & a_ext[8]) | (sel16 & m2[8]) | (sel17 & m3[8]);
  assign pp27 = (sel15 & a_ext[9]) | (sel16 & m2[9]) | (sel17 & m3[9]);
  assign pp28 = (sel15 & a_ext[10]) | (sel16 & m2[10]) | (sel17 & m3[10]);
  assign pp29 = (sel15 & a_ext[11]) | (sel16 & m2[11]) | (sel17 & m3[11]);
  assign sel30 = b[4] & ~b[5];
  assign sel31 = ~b[4] & b[5];
  assign sel32 = b[4] & b[5];
  assign pp33 = (sel30 & a_ext[0]) | (sel31 & m2[0]) | (sel32 & m3[0]);
  assign pp34 = (sel30 & a_ext[1]) | (sel31 & m2[1]) | (sel32 & m3[1]);
  assign pp35 = (sel30 & a_ext[2]) | (sel31 & m2[2]) | (sel32 & m3[2]);
  assign pp36 = (sel30 & a_ext[3]) | (sel31 & m2[3]) | (sel32 & m3[3]);
  assign pp37 = (sel30 & a_ext[4]) | (sel31 & m2[4]) | (sel32 & m3[4]);
  assign pp38 = (sel30 & a_ext[5]) | (sel31 & m2[5]) | (sel32 & m3[5]);
  assign pp39 = (sel30 & a_ext[6]) | (sel31 & m2[6]) | (sel32 & m3[6]);
  assign pp40 = (sel30 & a_ext[7]) | (sel31 & m2[7]) | (sel32 & m3[7]);
  assign pp41 = (sel30 & a_ext[8]) | (sel31 & m2[8]) | (sel32 & m3[8]);
  assign pp42 = (sel30 & a_ext[9]) | (sel31 & m2[9]) | (sel32 & m3[9]);
  assign pp43 = (sel30 & a_ext[10]) | (sel31 & m2[10]) | (sel32 & m3[10]);
  assign pp44 = (sel30 & a_ext[11]) | (sel31 & m2[11]) | (sel32 & m3[11]);
  assign sel45 = b[6] & ~b[7];
  assign sel46 = ~b[6] & b[7];
  assign sel47 = b[6] & b[7];
  assign pp48 = (sel45 & a_ext[0]) | (sel46 & m2[0]) | (sel47 & m3[0]);
  assign pp49 = (sel45 & a_ext[1]) | (sel46 & m2[1]) | (sel47 & m3[1]);
  assign pp50 = (sel45 & a_ext[2]) | (sel46 & m2[2]) | (sel47 & m3[2]);
  assign pp51 = (sel45 & a_ext[3]) | (sel46 & m2[3]) | (sel47 & m3[3]);
  assign pp52 = (sel45 & a_ext[4]) | (sel46 & m2[4]) | (sel47 & m3[4]);
  assign pp53 = (sel45 & a_ext[5]) | (sel46 & m2[5]) | (sel47 & m3[5]);
  assign pp54 = (sel45 & a_ext[6]) | (sel46 & m2[6]) | (sel47 & m3[6]);
  assign pp55 = (sel45 & a_ext[7]) | (sel46 & m2[7]) | (sel47 & m3[7]);
  assign pp56 = (sel45 & a_ext[8]) | (sel46 & m2[8]) | (sel47 & m3[8]);
  assign pp57 = (sel45 & a_ext[9]) | (sel46 & m2[9]) | (sel47 & m3[9]);
  assign pp58 = (sel45 & a_ext[10]) | (sel46 & m2[10]) | (sel47 & m3[10]);
  assign pp59 = (sel45 & a_ext[11]) | (sel46 & m2[11]) | (sel47 & m3[11]);
  assign neg60 = b[9] & ~b[8];
  assign neg61 = b[9] & b[8];
  assign neg62 = neg60 | neg61;
  assign sel63 = (b[8] & ~b[9]) | neg61;
  assign sel64 = neg60;
  assign pp65 = (sel63 & a_ext[0]) | (sel64 & m2[0]);
  assign pp66 = pp65 ^ neg62;
  assign pp67 = (sel63 & a_ext[1]) | (sel64 & m2[1]);
  assign pp68 = pp67 ^ neg62;
  assign pp69 = (sel63 & a_ext[2]) | (sel64 & m2[2]);
  assign pp70 = pp69 ^ neg62;
  assign pp71 = (sel63 & a_ext[3]) | (sel64 & m2[3]);
  assign pp72 = pp71 ^ neg62;
  assign pp73 = (sel63 & a_ext[4]) | (sel64 & m2[4]);
  assign pp74 = pp73 ^ neg62;
  assign pp75 = (sel63 & a_ext[5]) | (sel64 & m2[5]);
  assign pp76 = pp75 ^ neg62;
  assign pp77 = (sel63 & a_ext[6]) | (sel64 & m2[6]);
  assign pp78 = pp77 ^ neg62;
  assign pp79 = (sel63 & a_ext[7]) | (sel64 & m2[7]);
  assign pp80 = pp79 ^ neg62;
  assign pp81 = (sel63 & a_ext[8]) | (sel64 & m2[8]);
  assign pp82 = pp81 ^ neg62;
  assign pp83 = (sel63 & a_ext[9]) | (sel64 & m2[9]);
  assign pp84 = pp83 ^ neg62;
  assign pp85 = (sel63 & a_ext[10]) | (sel64 & m2[10]);
  assign pp86 = pp85 ^ neg62;
  assign pp87 = (sel63 & a_ext[11]) | (sel64 & m2[11]);
  assign pp88 = pp87 ^ neg62;
  assign ns89 = ~pp14;
  assign ns90 = ~pp29;
  assign ns91 = ~pp44;
  assign ns92 = ~pp59;
  assign ns93 = ~pp88;
  assign t94 = ts21[0] ^ tc16;
  assign t95 = ts21[0] & tc16;
  logic [19:0] row_s, row_c;
  assign row_s = {ts21[3], ts21[2], ts21[1], tc20, ts20[7], ts20[6], ts20[5], ts20[4], ts20[3], ts20[2], ts20[1], ts20[0], ts17[3], ts17[2], ts17[1], ts17[0], ts13[3], ts13[2], ts13[1], ts13[0]};
  assign row_c = {1'b0, 1'b0, t95, t94, 1'b0, 1'b0, 1'b0, tc17, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
  // hybrid final adder: regions [0, 5, 10, 15, 20] of kinds ['vba', 'select', 'cla', 'select'] on the uniform profile (arrival_profile_intersection)
  logic rg0_co;
  fam_adder_carry_skip_p035b672f454741e836110d2b293e320d2adf30f103464a83f97bd3dfd9837ae4_w5 u_rg0 (.a(row_s[4:0]), .b(row_c[4:0]), .cin(1'b0), .s(p[4:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_select_w5 u_rg1 (.a(row_s[9:5]), .b(row_c[9:5]), .cin(rg0_co), .s(p[9:5]), .cout(rg1_co));
  logic rg2_co;
  fam_adder_carry_lookahead #(.W(5), .G(4), .INTER(0), .LEVELS(1)) u_rg2 (.a(row_s[14:10]), .b(row_c[14:10]), .cin(rg1_co), .s(p[14:10]), .cout(rg2_co));
  logic rg3_co;
  fam_adder_carry_select_w5 u_rg3 (.a(row_s[19:15]), .b(row_c[19:15]), .cin(rg2_co), .s(p[19:15]), .cout(rg3_co));
endmodule

module fam_mul_direct_wallace_7_3_w16_s_p573b4b25 (input logic [15:0] a, input logic [15:0] b, output logic [31:0] p);
  // direct_pp_parallel: {'pp_bits': 258, 'full_adders': 196, 'half_adders': 14, 'cells': 17, 'tree_depth': 9}
  logic pp0, pp1, pp2, pp3, pp4, pp5, pp6, pp7, pp8, pp9, pp10, pp11, pp12, pp13, pp14, pp15, pp16, pp17, pp18, pp19, pp20, pp21, pp22, pp23, pp24, pp25, pp26, pp27, pp28, pp29, pp30, pp31, pp32, pp33, pp34, pp35, pp36, pp37, pp38, pp39, pp40, pp41, pp42, pp43, pp44, pp45, pp46, pp47, pp48, pp49, pp50, pp51, pp52, pp53, pp54, pp55, pp56, pp57, pp58, pp59, pp60, pp61, pp62, pp63, pp64, pp65, pp66, pp67, pp68, pp69, pp70, pp71, pp72, pp73, pp74, pp75, pp76, pp77, pp78, pp79, pp80, pp81, pp82, pp83, pp84, pp85, pp86, pp87, pp88, pp89, pp90, pp91, pp92, pp93, pp94, pp95, pp96, pp97, pp98, pp99, pp100, pp101, pp102, pp103, pp104, pp105, pp106, pp107, pp108, pp109, pp110, pp111, pp112, pp113, pp114, pp115, pp116, pp117, pp118, pp119, pp120, pp121, pp122, pp123, pp124, pp125, pp126, pp127, pp128, pp129, pp130, pp131, pp132, pp133, pp134, pp135, pp136, pp137, pp138, pp139, pp140, pp141, pp142, pp143, pp144, pp145, pp146, pp147, pp148, pp149, pp150, pp151, pp152, pp153, pp154, pp155, pp156, pp157, pp158, pp159, pp160, pp161, pp162, pp163, pp164, pp165, pp166, pp167, pp168, pp169, pp170, pp171, pp172, pp173, pp174, pp175, pp176, pp177, pp178, pp179, pp180, pp181, pp182, pp183, pp184, pp185, pp186, pp187, pp188, pp189, pp190, pp191, pp192, pp193, pp194, pp195, pp196, pp197, pp198, pp199, pp200, pp201, pp202, pp203, pp204, pp205, pp206, pp207, pp208, pp209, pp210, pp211, pp212, pp213, pp214, pp215, pp216, pp217, pp218, pp219, pp220, pp221, pp222, pp223, pp224, pp225, pp226, pp227, pp228, pp229, pp230, pp231, pp232, pp233, pp234, pp235, pp236, pp237, pp238, pp239, pp240, pp241, pp242, pp243, pp244, pp245, pp246, pp247, pp248, pp249, pp250, pp251, pp252, pp253, pp254, pp255, t256, t257, t258, t259, t260, t261, t262, t263, t264, t265, t266, t267, t268, t269, t270, t271, t272, t273, t274, t275, t276, t277, t278, t279, t280, t281, t282, t283, t284, t285, t286, t287, t288, t289, t290, t291, t292, t293, t294, t295, t296, t297, t298, t299, t300, t301, t302, t303, t304, t305, t306, t307, t308, t309, t310, t311, t312, t313, t314, t315, t316, t317, t318, t319, t320, t321, t322, t323, t324, t325, t326, t327, t328, t329, t330, t331, t332, t333, t334, t335, t336, t337, t338, t339, t340, t341, t342, t343, t344, t345, t346, t347, t348, t349, t350, t351, t352, t353, t354, t355, t356, t357, t358, t359, t360, t361, t362, t363, t364, t365, t366, t367, t368, t369, t370, t371, t372, t373, t374, t375, t376, t377, t378, t379, t380, t381, t382, t383, t384, t385, t386, t387, t388, t389, t390, t391, t392, t393, t394, t395, t396, t397, t398, t399, t400, t401, t402, t403, t404, t405, t406, t407, t408, t409, t410, t411, t412, t413, t414, t415, t416, t417, t418, t419, t420, t421, t422, t423, t424, t425, t426, t427, t428, t429, t430, t431, t432, t433, t434, t435, t436, t437, t438, t439, t440, t441, t442, t443, t444, t445, t446, t447, t448, t449, t450, t451, t452, t453, t454, t455, t456, t457, t458, t459, t460, t461, t462, t463, t464, t465, t466, t467, t468, t469, t470, t471, t472, t473, t474, t475, t476, t477, t478, t479, t480, t481, t482, t483, t484, t485, t486, t487, t488, t489, t490, t491, t492, t493, t494, t495, t496, t497, t498, t499, t500, t501, t502, t503, t504, t505, t506, t507, t508, t509, t510, t511, t512, t513, t514, t515, t516, t517, t518, t519, t520, t521, t522, t523, t524, t525, t526, t527, t528, t529, t530, t531, t532, t533, t534, t535, t536, t537, t538, t539, t540, t541, t542, t543, t544, t545, t546, t547, t548, t549, t550, t551, t552, t553, t554, t555, t556, t557, t558, t559, t560, t561, t562, t563, t564, t565, t566, t567, t568, t569, t570, t571, t572, t573, t574, t575, t576, t577, t578, t579, t580, t581, t582, t583, t584, t585, t586, t587, t588, t589, t590, t591, t592, t593, t594, t595, t596, t597, t598, t599, t600, t601, t602, t603, t604, t605, t606, t607, t608, t609, t610, t611, t612, t613, t614, t615, t616, t617, t618, t619, t620, t621, t622, t623, t624, t625, t626, t627, t628, t629, t630, t631, t632, t633, t634, t635, t636, t637, t638, t639, t640, t641, t642, t643, t644, t645, t646, t647, t648, t649, t650, t651, t652, t653, t654, t655, t656, t657, t658, t659, t660, t661, t662, t663, t664, t665, t666, t667, t668, t669, t670, t671, t672, t673, t674, t675;
  assign pp0 = (a[0] & b[0]);
  assign pp1 = (a[0] & b[1]);
  assign pp2 = (a[0] & b[2]);
  assign pp3 = (a[0] & b[3]);
  assign pp4 = (a[0] & b[4]);
  assign pp5 = (a[0] & b[5]);
  assign pp6 = (a[0] & b[6]);
  assign pp7 = (a[0] & b[7]);
  assign pp8 = (a[0] & b[8]);
  assign pp9 = (a[0] & b[9]);
  assign pp10 = (a[0] & b[10]);
  assign pp11 = (a[0] & b[11]);
  assign pp12 = (a[0] & b[12]);
  assign pp13 = (a[0] & b[13]);
  assign pp14 = (a[0] & b[14]);
  assign pp15 = ~(a[0] & b[15]);
  assign pp16 = (a[1] & b[0]);
  assign pp17 = (a[1] & b[1]);
  assign pp18 = (a[1] & b[2]);
  assign pp19 = (a[1] & b[3]);
  assign pp20 = (a[1] & b[4]);
  assign pp21 = (a[1] & b[5]);
  assign pp22 = (a[1] & b[6]);
  assign pp23 = (a[1] & b[7]);
  assign pp24 = (a[1] & b[8]);
  assign pp25 = (a[1] & b[9]);
  assign pp26 = (a[1] & b[10]);
  assign pp27 = (a[1] & b[11]);
  assign pp28 = (a[1] & b[12]);
  assign pp29 = (a[1] & b[13]);
  assign pp30 = (a[1] & b[14]);
  assign pp31 = ~(a[1] & b[15]);
  assign pp32 = (a[2] & b[0]);
  assign pp33 = (a[2] & b[1]);
  assign pp34 = (a[2] & b[2]);
  assign pp35 = (a[2] & b[3]);
  assign pp36 = (a[2] & b[4]);
  assign pp37 = (a[2] & b[5]);
  assign pp38 = (a[2] & b[6]);
  assign pp39 = (a[2] & b[7]);
  assign pp40 = (a[2] & b[8]);
  assign pp41 = (a[2] & b[9]);
  assign pp42 = (a[2] & b[10]);
  assign pp43 = (a[2] & b[11]);
  assign pp44 = (a[2] & b[12]);
  assign pp45 = (a[2] & b[13]);
  assign pp46 = (a[2] & b[14]);
  assign pp47 = ~(a[2] & b[15]);
  assign pp48 = (a[3] & b[0]);
  assign pp49 = (a[3] & b[1]);
  assign pp50 = (a[3] & b[2]);
  assign pp51 = (a[3] & b[3]);
  assign pp52 = (a[3] & b[4]);
  assign pp53 = (a[3] & b[5]);
  assign pp54 = (a[3] & b[6]);
  assign pp55 = (a[3] & b[7]);
  assign pp56 = (a[3] & b[8]);
  assign pp57 = (a[3] & b[9]);
  assign pp58 = (a[3] & b[10]);
  assign pp59 = (a[3] & b[11]);
  assign pp60 = (a[3] & b[12]);
  assign pp61 = (a[3] & b[13]);
  assign pp62 = (a[3] & b[14]);
  assign pp63 = ~(a[3] & b[15]);
  assign pp64 = (a[4] & b[0]);
  assign pp65 = (a[4] & b[1]);
  assign pp66 = (a[4] & b[2]);
  assign pp67 = (a[4] & b[3]);
  assign pp68 = (a[4] & b[4]);
  assign pp69 = (a[4] & b[5]);
  assign pp70 = (a[4] & b[6]);
  assign pp71 = (a[4] & b[7]);
  assign pp72 = (a[4] & b[8]);
  assign pp73 = (a[4] & b[9]);
  assign pp74 = (a[4] & b[10]);
  assign pp75 = (a[4] & b[11]);
  assign pp76 = (a[4] & b[12]);
  assign pp77 = (a[4] & b[13]);
  assign pp78 = (a[4] & b[14]);
  assign pp79 = ~(a[4] & b[15]);
  assign pp80 = (a[5] & b[0]);
  assign pp81 = (a[5] & b[1]);
  assign pp82 = (a[5] & b[2]);
  assign pp83 = (a[5] & b[3]);
  assign pp84 = (a[5] & b[4]);
  assign pp85 = (a[5] & b[5]);
  assign pp86 = (a[5] & b[6]);
  assign pp87 = (a[5] & b[7]);
  assign pp88 = (a[5] & b[8]);
  assign pp89 = (a[5] & b[9]);
  assign pp90 = (a[5] & b[10]);
  assign pp91 = (a[5] & b[11]);
  assign pp92 = (a[5] & b[12]);
  assign pp93 = (a[5] & b[13]);
  assign pp94 = (a[5] & b[14]);
  assign pp95 = ~(a[5] & b[15]);
  assign pp96 = (a[6] & b[0]);
  assign pp97 = (a[6] & b[1]);
  assign pp98 = (a[6] & b[2]);
  assign pp99 = (a[6] & b[3]);
  assign pp100 = (a[6] & b[4]);
  assign pp101 = (a[6] & b[5]);
  assign pp102 = (a[6] & b[6]);
  assign pp103 = (a[6] & b[7]);
  assign pp104 = (a[6] & b[8]);
  assign pp105 = (a[6] & b[9]);
  assign pp106 = (a[6] & b[10]);
  assign pp107 = (a[6] & b[11]);
  assign pp108 = (a[6] & b[12]);
  assign pp109 = (a[6] & b[13]);
  assign pp110 = (a[6] & b[14]);
  assign pp111 = ~(a[6] & b[15]);
  assign pp112 = (a[7] & b[0]);
  assign pp113 = (a[7] & b[1]);
  assign pp114 = (a[7] & b[2]);
  assign pp115 = (a[7] & b[3]);
  assign pp116 = (a[7] & b[4]);
  assign pp117 = (a[7] & b[5]);
  assign pp118 = (a[7] & b[6]);
  assign pp119 = (a[7] & b[7]);
  assign pp120 = (a[7] & b[8]);
  assign pp121 = (a[7] & b[9]);
  assign pp122 = (a[7] & b[10]);
  assign pp123 = (a[7] & b[11]);
  assign pp124 = (a[7] & b[12]);
  assign pp125 = (a[7] & b[13]);
  assign pp126 = (a[7] & b[14]);
  assign pp127 = ~(a[7] & b[15]);
  assign pp128 = (a[8] & b[0]);
  assign pp129 = (a[8] & b[1]);
  assign pp130 = (a[8] & b[2]);
  assign pp131 = (a[8] & b[3]);
  assign pp132 = (a[8] & b[4]);
  assign pp133 = (a[8] & b[5]);
  assign pp134 = (a[8] & b[6]);
  assign pp135 = (a[8] & b[7]);
  assign pp136 = (a[8] & b[8]);
  assign pp137 = (a[8] & b[9]);
  assign pp138 = (a[8] & b[10]);
  assign pp139 = (a[8] & b[11]);
  assign pp140 = (a[8] & b[12]);
  assign pp141 = (a[8] & b[13]);
  assign pp142 = (a[8] & b[14]);
  assign pp143 = ~(a[8] & b[15]);
  assign pp144 = (a[9] & b[0]);
  assign pp145 = (a[9] & b[1]);
  assign pp146 = (a[9] & b[2]);
  assign pp147 = (a[9] & b[3]);
  assign pp148 = (a[9] & b[4]);
  assign pp149 = (a[9] & b[5]);
  assign pp150 = (a[9] & b[6]);
  assign pp151 = (a[9] & b[7]);
  assign pp152 = (a[9] & b[8]);
  assign pp153 = (a[9] & b[9]);
  assign pp154 = (a[9] & b[10]);
  assign pp155 = (a[9] & b[11]);
  assign pp156 = (a[9] & b[12]);
  assign pp157 = (a[9] & b[13]);
  assign pp158 = (a[9] & b[14]);
  assign pp159 = ~(a[9] & b[15]);
  assign pp160 = (a[10] & b[0]);
  assign pp161 = (a[10] & b[1]);
  assign pp162 = (a[10] & b[2]);
  assign pp163 = (a[10] & b[3]);
  assign pp164 = (a[10] & b[4]);
  assign pp165 = (a[10] & b[5]);
  assign pp166 = (a[10] & b[6]);
  assign pp167 = (a[10] & b[7]);
  assign pp168 = (a[10] & b[8]);
  assign pp169 = (a[10] & b[9]);
  assign pp170 = (a[10] & b[10]);
  assign pp171 = (a[10] & b[11]);
  assign pp172 = (a[10] & b[12]);
  assign pp173 = (a[10] & b[13]);
  assign pp174 = (a[10] & b[14]);
  assign pp175 = ~(a[10] & b[15]);
  assign pp176 = (a[11] & b[0]);
  assign pp177 = (a[11] & b[1]);
  assign pp178 = (a[11] & b[2]);
  assign pp179 = (a[11] & b[3]);
  assign pp180 = (a[11] & b[4]);
  assign pp181 = (a[11] & b[5]);
  assign pp182 = (a[11] & b[6]);
  assign pp183 = (a[11] & b[7]);
  assign pp184 = (a[11] & b[8]);
  assign pp185 = (a[11] & b[9]);
  assign pp186 = (a[11] & b[10]);
  assign pp187 = (a[11] & b[11]);
  assign pp188 = (a[11] & b[12]);
  assign pp189 = (a[11] & b[13]);
  assign pp190 = (a[11] & b[14]);
  assign pp191 = ~(a[11] & b[15]);
  assign pp192 = (a[12] & b[0]);
  assign pp193 = (a[12] & b[1]);
  assign pp194 = (a[12] & b[2]);
  assign pp195 = (a[12] & b[3]);
  assign pp196 = (a[12] & b[4]);
  assign pp197 = (a[12] & b[5]);
  assign pp198 = (a[12] & b[6]);
  assign pp199 = (a[12] & b[7]);
  assign pp200 = (a[12] & b[8]);
  assign pp201 = (a[12] & b[9]);
  assign pp202 = (a[12] & b[10]);
  assign pp203 = (a[12] & b[11]);
  assign pp204 = (a[12] & b[12]);
  assign pp205 = (a[12] & b[13]);
  assign pp206 = (a[12] & b[14]);
  assign pp207 = ~(a[12] & b[15]);
  assign pp208 = (a[13] & b[0]);
  assign pp209 = (a[13] & b[1]);
  assign pp210 = (a[13] & b[2]);
  assign pp211 = (a[13] & b[3]);
  assign pp212 = (a[13] & b[4]);
  assign pp213 = (a[13] & b[5]);
  assign pp214 = (a[13] & b[6]);
  assign pp215 = (a[13] & b[7]);
  assign pp216 = (a[13] & b[8]);
  assign pp217 = (a[13] & b[9]);
  assign pp218 = (a[13] & b[10]);
  assign pp219 = (a[13] & b[11]);
  assign pp220 = (a[13] & b[12]);
  assign pp221 = (a[13] & b[13]);
  assign pp222 = (a[13] & b[14]);
  assign pp223 = ~(a[13] & b[15]);
  assign pp224 = (a[14] & b[0]);
  assign pp225 = (a[14] & b[1]);
  assign pp226 = (a[14] & b[2]);
  assign pp227 = (a[14] & b[3]);
  assign pp228 = (a[14] & b[4]);
  assign pp229 = (a[14] & b[5]);
  assign pp230 = (a[14] & b[6]);
  assign pp231 = (a[14] & b[7]);
  assign pp232 = (a[14] & b[8]);
  assign pp233 = (a[14] & b[9]);
  assign pp234 = (a[14] & b[10]);
  assign pp235 = (a[14] & b[11]);
  assign pp236 = (a[14] & b[12]);
  assign pp237 = (a[14] & b[13]);
  assign pp238 = (a[14] & b[14]);
  assign pp239 = ~(a[14] & b[15]);
  assign pp240 = ~(a[15] & b[0]);
  assign pp241 = ~(a[15] & b[1]);
  assign pp242 = ~(a[15] & b[2]);
  assign pp243 = ~(a[15] & b[3]);
  assign pp244 = ~(a[15] & b[4]);
  assign pp245 = ~(a[15] & b[5]);
  assign pp246 = ~(a[15] & b[6]);
  assign pp247 = ~(a[15] & b[7]);
  assign pp248 = ~(a[15] & b[8]);
  assign pp249 = ~(a[15] & b[9]);
  assign pp250 = ~(a[15] & b[10]);
  assign pp251 = ~(a[15] & b[11]);
  assign pp252 = ~(a[15] & b[12]);
  assign pp253 = ~(a[15] & b[13]);
  assign pp254 = ~(a[15] & b[14]);
  assign pp255 = (a[15] & b[15]);
  assign t256 = pp13 ^ pp28;
  assign t257 = pp13 & pp28;
  assign t258 = pp14 ^ pp29 ^ pp44;
  assign t259 = (pp14 & pp29) | (pp14 & pp44) | (pp29 & pp44);
  assign t260 = pp59 ^ pp74;
  assign t261 = pp59 & pp74;
  assign t262 = pp15 ^ pp30 ^ pp45;
  assign t263 = (pp15 & pp30) | (pp15 & pp45) | (pp30 & pp45);
  assign t264 = pp60 ^ pp75 ^ pp90;
  assign t265 = (pp60 & pp75) | (pp60 & pp90) | (pp75 & pp90);
  assign t266 = pp105 ^ pp120;
  assign t267 = pp105 & pp120;
  assign t268 = pp31 ^ pp46 ^ pp61;
  assign t269 = (pp31 & pp46) | (pp31 & pp61) | (pp46 & pp61);
  assign t270 = pp76 ^ pp91 ^ pp106;
  assign t271 = (pp76 & pp91) | (pp76 & pp106) | (pp91 & pp106);
  assign t272 = t268 ^ t270 ^ pp121;
  assign t273 = (t268 & t270) | (t268 & pp121) | (t270 & pp121);
  assign t274 = t269 ^ t271 ^ t273;
  assign t275 = (t269 & t271) | (t269 & t273) | (t271 & t273);
  assign t276 = pp47 ^ pp62 ^ pp77;
  assign t277 = (pp47 & pp62) | (pp47 & pp77) | (pp62 & pp77);
  assign t278 = pp63 ^ pp78 ^ pp93;
  assign t279 = (pp63 & pp78) | (pp63 & pp93) | (pp78 & pp93);
  assign t280 = pp9 ^ pp24;
  assign t281 = pp9 & pp24;
  assign t282 = pp10 ^ pp25 ^ pp40;
  assign t283 = (pp10 & pp25) | (pp10 & pp40) | (pp25 & pp40);
  assign t284 = pp55 ^ pp70;
  assign t285 = pp55 & pp70;
  assign t286 = pp11 ^ pp26 ^ pp41;
  assign t287 = (pp11 & pp26) | (pp11 & pp41) | (pp26 & pp41);
  assign t288 = pp56 ^ pp71 ^ pp86;
  assign t289 = (pp56 & pp71) | (pp56 & pp86) | (pp71 & pp86);
  assign t290 = pp101 ^ pp116;
  assign t291 = pp101 & pp116;
  assign t292 = pp12 ^ pp27 ^ pp42;
  assign t293 = (pp12 & pp27) | (pp12 & pp42) | (pp27 & pp42);
  assign t294 = pp57 ^ pp72 ^ pp87;
  assign t295 = (pp57 & pp72) | (pp57 & pp87) | (pp72 & pp87);
  assign t296 = t292 ^ t294 ^ pp102;
  assign t297 = (t292 & t294) | (t292 & pp102) | (t294 & pp102);
  assign t298 = t293 ^ t295 ^ t297;
  assign t299 = (t293 & t295) | (t293 & t297) | (t295 & t297);
  assign t300 = pp117 ^ pp132;
  assign t301 = pp117 & pp132;
  assign t302 = pp43 ^ pp58 ^ pp73;
  assign t303 = (pp43 & pp58) | (pp43 & pp73) | (pp58 & pp73);
  assign t304 = pp88 ^ pp103 ^ pp118;
  assign t305 = (pp88 & pp103) | (pp88 & pp118) | (pp103 & pp118);
  assign t306 = t302 ^ t304 ^ pp133;
  assign t307 = (t302 & t304) | (t302 & pp133) | (t304 & pp133);
  assign t308 = t303 ^ t305 ^ t307;
  assign t309 = (t303 & t305) | (t303 & t307) | (t305 & t307);
  assign t310 = pp89 ^ pp104 ^ pp119;
  assign t311 = (pp89 & pp104) | (pp89 & pp119) | (pp104 & pp119);
  assign t312 = pp134 ^ pp149 ^ pp164;
  assign t313 = (pp134 & pp149) | (pp134 & pp164) | (pp149 & pp164);
  assign t314 = t310 ^ t312 ^ pp179;
  assign t315 = (t310 & t312) | (t310 & pp179) | (t312 & pp179);
  assign t316 = t311 ^ t313 ^ t315;
  assign t317 = (t311 & t313) | (t311 & t315) | (t313 & t315);
  assign t318 = pp135 ^ pp150 ^ pp165;
  assign t319 = (pp135 & pp150) | (pp135 & pp165) | (pp150 & pp165);
  assign t320 = pp180 ^ pp195 ^ pp210;
  assign t321 = (pp180 & pp195) | (pp180 & pp210) | (pp195 & pp210);
  assign t322 = t318 ^ t320 ^ pp225;
  assign t323 = (t318 & t320) | (t318 & pp225) | (t320 & pp225);
  assign t324 = t319 ^ t321 ^ t323;
  assign t325 = (t319 & t321) | (t319 & t323) | (t321 & t323);
  assign t326 = pp136 ^ pp151 ^ pp166;
  assign t327 = (pp136 & pp151) | (pp136 & pp166) | (pp151 & pp166);
  assign t328 = pp181 ^ pp196 ^ pp211;
  assign t329 = (pp181 & pp196) | (pp181 & pp211) | (pp196 & pp211);
  assign t330 = t326 ^ t328 ^ pp226;
  assign t331 = (t326 & t328) | (t326 & pp226) | (t328 & pp226);
  assign t332 = t327 ^ t329 ^ t331;
  assign t333 = (t327 & t329) | (t327 & t331) | (t329 & t331);
  assign t334 = pp92 ^ pp107 ^ pp122;
  assign t335 = (pp92 & pp107) | (pp92 & pp122) | (pp107 & pp122);
  assign t336 = pp137 ^ pp152 ^ pp167;
  assign t337 = (pp137 & pp152) | (pp137 & pp167) | (pp152 & pp167);
  assign t338 = t334 ^ t336 ^ pp182;
  assign t339 = (t334 & t336) | (t334 & pp182) | (t336 & pp182);
  assign t340 = t335 ^ t337 ^ t339;
  assign t341 = (t335 & t337) | (t335 & t339) | (t337 & t339);
  assign t342 = pp108 ^ pp123 ^ pp138;
  assign t343 = (pp108 & pp123) | (pp108 & pp138) | (pp123 & pp138);
  assign t344 = pp153 ^ pp168 ^ pp183;
  assign t345 = (pp153 & pp168) | (pp153 & pp183) | (pp168 & pp183);
  assign t346 = t342 ^ t344 ^ pp198;
  assign t347 = (t342 & t344) | (t342 & pp198) | (t344 & pp198);
  assign t348 = t343 ^ t345 ^ t347;
  assign t349 = (t343 & t345) | (t343 & t347) | (t345 & t347);
  assign t350 = pp79 ^ pp94 ^ pp109;
  assign t351 = (pp79 & pp94) | (pp79 & pp109) | (pp94 & pp109);
  assign t352 = pp124 ^ pp139 ^ pp154;
  assign t353 = (pp124 & pp139) | (pp124 & pp154) | (pp139 & pp154);
  assign t354 = t350 ^ t352 ^ pp169;
  assign t355 = (t350 & t352) | (t350 & pp169) | (t352 & pp169);
  assign t356 = t351 ^ t353 ^ t355;
  assign t357 = (t351 & t353) | (t351 & t355) | (t353 & t355);
  assign t358 = pp95 ^ pp110 ^ pp125;
  assign t359 = (pp95 & pp110) | (pp95 & pp125) | (pp110 & pp125);
  assign t360 = pp140 ^ pp155 ^ pp170;
  assign t361 = (pp140 & pp155) | (pp140 & pp170) | (pp155 & pp170);
  assign t362 = pp111 ^ pp126 ^ pp141;
  assign t363 = (pp111 & pp126) | (pp111 & pp141) | (pp126 & pp141);
  assign t364 = pp156 ^ pp171 ^ pp186;
  assign t365 = (pp156 & pp171) | (pp156 & pp186) | (pp171 & pp186);
  assign t366 = pp127 ^ pp142 ^ pp157;
  assign t367 = (pp127 & pp142) | (pp127 & pp157) | (pp142 & pp157);
  assign t368 = pp6 ^ pp21;
  assign t369 = pp6 & pp21;
  assign t370 = pp7 ^ pp22 ^ pp37;
  assign t371 = (pp7 & pp22) | (pp7 & pp37) | (pp22 & pp37);
  assign t372 = pp52 ^ pp67;
  assign t373 = pp52 & pp67;
  assign t374 = pp8 ^ pp23 ^ pp38;
  assign t375 = (pp8 & pp23) | (pp8 & pp38) | (pp23 & pp38);
  assign t376 = pp53 ^ pp68 ^ pp83;
  assign t377 = (pp53 & pp68) | (pp53 & pp83) | (pp68 & pp83);
  assign t378 = pp98 ^ pp113;
  assign t379 = pp98 & pp113;
  assign t380 = pp39 ^ pp54 ^ pp69;
  assign t381 = (pp39 & pp54) | (pp39 & pp69) | (pp54 & pp69);
  assign t382 = pp84 ^ pp99 ^ pp114;
  assign t383 = (pp84 & pp99) | (pp84 & pp114) | (pp99 & pp114);
  assign t384 = t380 ^ t382 ^ pp129;
  assign t385 = (t380 & t382) | (t380 & pp129) | (t382 & pp129);
  assign t386 = t381 ^ t383 ^ t385;
  assign t387 = (t381 & t383) | (t381 & t385) | (t383 & t385);
  assign t388 = pp85 ^ pp100 ^ pp115;
  assign t389 = (pp85 & pp100) | (pp85 & pp115) | (pp100 & pp115);
  assign t390 = pp130 ^ pp145 ^ pp160;
  assign t391 = (pp130 & pp145) | (pp130 & pp160) | (pp145 & pp160);
  assign t392 = pp131 ^ pp146 ^ pp161;
  assign t393 = (pp131 & pp146) | (pp131 & pp161) | (pp146 & pp161);
  assign t394 = pp176 ^ t283 ^ t285;
  assign t395 = (pp176 & t283) | (pp176 & t285) | (t283 & t285);
  assign t396 = t392 ^ t394 ^ t286;
  assign t397 = (t392 & t394) | (t392 & t286) | (t394 & t286);
  assign t398 = t393 ^ t395 ^ t397;
  assign t399 = (t393 & t395) | (t393 & t397) | (t395 & t397);
  assign t400 = pp147 ^ pp162 ^ pp177;
  assign t401 = (pp147 & pp162) | (pp147 & pp177) | (pp162 & pp177);
  assign t402 = pp192 ^ t287 ^ t289;
  assign t403 = (pp192 & t287) | (pp192 & t289) | (t287 & t289);
  assign t404 = pp148 ^ pp163 ^ pp178;
  assign t405 = (pp148 & pp163) | (pp148 & pp178) | (pp163 & pp178);
  assign t406 = pp193 ^ pp208 ^ t256;
  assign t407 = (pp193 & pp208) | (pp193 & t256) | (pp208 & t256);
  assign t408 = t404 ^ t406 ^ t298;
  assign t409 = (t404 & t406) | (t404 & t298) | (t406 & t298);
  assign t410 = t405 ^ t407 ^ t409;
  assign t411 = (t405 & t407) | (t405 & t409) | (t407 & t409);
  assign t412 = pp194 ^ pp209 ^ pp224;
  assign t413 = (pp194 & pp209) | (pp194 & pp224) | (pp209 & pp224);
  assign t414 = t257 ^ t258 ^ t260;
  assign t415 = (t257 & t258) | (t257 & t260) | (t258 & t260);
  assign t416 = pp240 ^ t259 ^ t261;
  assign t417 = (pp240 & t259) | (pp240 & t261) | (t259 & t261);
  assign t418 = t262 ^ t264 ^ t266;
  assign t419 = (t262 & t264) | (t262 & t266) | (t264 & t266);
  assign t420 = t416 ^ t418 ^ t309;
  assign t421 = (t416 & t418) | (t416 & t309) | (t418 & t309);
  assign t422 = t417 ^ t419 ^ t421;
  assign t423 = (t417 & t419) | (t417 & t421) | (t419 & t421);
  assign t424 = pp241 ^ 1'b1 ^ t263;
  assign t425 = (pp241 & 1'b1) | (pp241 & t263) | (1'b1 & t263);
  assign t426 = t265 ^ t267 ^ t272;
  assign t427 = (t265 & t267) | (t265 & t272) | (t267 & t272);
  assign t428 = pp197 ^ pp212 ^ pp227;
  assign t429 = (pp197 & pp212) | (pp197 & pp227) | (pp212 & pp227);
  assign t430 = pp242 ^ t274 ^ t276;
  assign t431 = (pp242 & t274) | (pp242 & t276) | (t274 & t276);
  assign t432 = t428 ^ t430 ^ t325;
  assign t433 = (t428 & t430) | (t428 & t325) | (t430 & t325);
  assign t434 = t429 ^ t431 ^ t433;
  assign t435 = (t429 & t431) | (t429 & t433) | (t431 & t433);
  assign t436 = pp213 ^ pp228 ^ pp243;
  assign t437 = (pp213 & pp228) | (pp213 & pp243) | (pp228 & pp243);
  assign t438 = t275 ^ t277 ^ t278;
  assign t439 = (t275 & t277) | (t275 & t278) | (t277 & t278);
  assign t440 = pp184 ^ pp199 ^ pp214;
  assign t441 = (pp184 & pp199) | (pp184 & pp214) | (pp199 & pp214);
  assign t442 = pp229 ^ pp244 ^ t279;
  assign t443 = (pp229 & pp244) | (pp229 & t279) | (pp244 & t279);
  assign t444 = t440 ^ t442 ^ t341;
  assign t445 = (t440 & t442) | (t440 & t341) | (t442 & t341);
  assign t446 = t441 ^ t443 ^ t445;
  assign t447 = (t441 & t443) | (t441 & t445) | (t443 & t445);
  assign t448 = pp185 ^ pp200 ^ pp215;
  assign t449 = (pp185 & pp200) | (pp185 & pp215) | (pp200 & pp215);
  assign t450 = pp230 ^ pp245 ^ t349;
  assign t451 = (pp230 & pp245) | (pp230 & t349) | (pp245 & t349);
  assign t452 = pp201 ^ pp216 ^ pp231;
  assign t453 = (pp201 & pp216) | (pp201 & pp231) | (pp216 & pp231);
  assign t454 = pp246 ^ t357 ^ t359;
  assign t455 = (pp246 & t357) | (pp246 & t359) | (t357 & t359);
  assign t456 = t452 ^ t454 ^ t361;
  assign t457 = (t452 & t454) | (t452 & t361) | (t454 & t361);
  assign t458 = t453 ^ t455 ^ t457;
  assign t459 = (t453 & t455) | (t453 & t457) | (t455 & t457);
  assign t460 = pp172 ^ pp187 ^ pp202;
  assign t461 = (pp172 & pp187) | (pp172 & pp202) | (pp187 & pp202);
  assign t462 = pp217 ^ pp232 ^ pp247;
  assign t463 = (pp217 & pp232) | (pp217 & pp247) | (pp232 & pp247);
  assign t464 = pp143 ^ pp158 ^ pp173;
  assign t465 = (pp143 & pp158) | (pp143 & pp173) | (pp158 & pp173);
  assign t466 = pp188 ^ pp203 ^ pp218;
  assign t467 = (pp188 & pp203) | (pp188 & pp218) | (pp203 & pp218);
  assign t468 = t464 ^ t466 ^ pp233;
  assign t469 = (t464 & t466) | (t464 & pp233) | (t466 & pp233);
  assign t470 = t465 ^ t467 ^ t469;
  assign t471 = (t465 & t467) | (t465 & t469) | (t467 & t469);
  assign t472 = pp159 ^ pp174 ^ pp189;
  assign t473 = (pp159 & pp174) | (pp159 & pp189) | (pp174 & pp189);
  assign t474 = pp175 ^ pp190 ^ pp205;
  assign t475 = (pp175 & pp190) | (pp175 & pp205) | (pp190 & pp205);
  assign t476 = pp4 ^ pp19;
  assign t477 = pp4 & pp19;
  assign t478 = pp5 ^ pp20 ^ pp35;
  assign t479 = (pp5 & pp20) | (pp5 & pp35) | (pp20 & pp35);
  assign t480 = pp50 ^ pp65;
  assign t481 = pp50 & pp65;
  assign t482 = pp36 ^ pp51 ^ pp66;
  assign t483 = (pp36 & pp51) | (pp36 & pp66) | (pp51 & pp66);
  assign t484 = pp81 ^ pp96 ^ t368;
  assign t485 = (pp81 & pp96) | (pp81 & t368) | (pp96 & t368);
  assign t486 = pp82 ^ pp97 ^ pp112;
  assign t487 = (pp82 & pp97) | (pp82 & pp112) | (pp97 & pp112);
  assign t488 = t369 ^ t370 ^ t372;
  assign t489 = (t369 & t370) | (t369 & t372) | (t370 & t372);
  assign t490 = pp128 ^ t371 ^ t373;
  assign t491 = (pp128 & t371) | (pp128 & t373) | (t371 & t373);
  assign t492 = t374 ^ t376 ^ t378;
  assign t493 = (t374 & t376) | (t374 & t378) | (t376 & t378);
  assign t494 = pp144 ^ t280 ^ t375;
  assign t495 = (pp144 & t280) | (pp144 & t375) | (t280 & t375);
  assign t496 = t377 ^ t379 ^ t384;
  assign t497 = (t377 & t379) | (t377 & t384) | (t379 & t384);
  assign t498 = t281 ^ t282 ^ t284;
  assign t499 = (t281 & t282) | (t281 & t284) | (t282 & t284);
  assign t500 = t386 ^ t388 ^ t390;
  assign t501 = (t386 & t388) | (t386 & t390) | (t388 & t390);
  assign t502 = t288 ^ t290 ^ t387;
  assign t503 = (t288 & t290) | (t288 & t387) | (t290 & t387);
  assign t504 = t389 ^ t391 ^ t396;
  assign t505 = (t389 & t391) | (t389 & t396) | (t391 & t396);
  assign t506 = t291 ^ t296 ^ t300;
  assign t507 = (t291 & t296) | (t291 & t300) | (t296 & t300);
  assign t508 = t398 ^ t400 ^ t402;
  assign t509 = (t398 & t400) | (t398 & t402) | (t400 & t402);
  assign t510 = t301 ^ t306 ^ t399;
  assign t511 = (t301 & t306) | (t301 & t399) | (t306 & t399);
  assign t512 = t401 ^ t403 ^ t408;
  assign t513 = (t401 & t403) | (t401 & t408) | (t403 & t408);
  assign t514 = t299 ^ t308 ^ t314;
  assign t515 = (t299 & t308) | (t299 & t314) | (t308 & t314);
  assign t516 = t410 ^ t412 ^ t414;
  assign t517 = (t410 & t412) | (t410 & t414) | (t412 & t414);
  assign t518 = t316 ^ t322 ^ t411;
  assign t519 = (t316 & t322) | (t316 & t411) | (t322 & t411);
  assign t520 = t413 ^ t415 ^ t420;
  assign t521 = (t413 & t415) | (t413 & t420) | (t415 & t420);
  assign t522 = t317 ^ t324 ^ t330;
  assign t523 = (t317 & t324) | (t317 & t330) | (t324 & t330);
  assign t524 = t422 ^ t424 ^ t426;
  assign t525 = (t422 & t424) | (t422 & t426) | (t424 & t426);
  assign t526 = t332 ^ t338 ^ t423;
  assign t527 = (t332 & t338) | (t332 & t423) | (t338 & t423);
  assign t528 = t425 ^ t427 ^ t432;
  assign t529 = (t425 & t427) | (t425 & t432) | (t427 & t432);
  assign t530 = t333 ^ t340 ^ t346;
  assign t531 = (t333 & t340) | (t333 & t346) | (t340 & t346);
  assign t532 = t434 ^ t436 ^ t438;
  assign t533 = (t434 & t436) | (t434 & t438) | (t436 & t438);
  assign t534 = t348 ^ t354 ^ t435;
  assign t535 = (t348 & t354) | (t348 & t435) | (t354 & t435);
  assign t536 = t437 ^ t439 ^ t444;
  assign t537 = (t437 & t439) | (t437 & t444) | (t439 & t444);
  assign t538 = t356 ^ t358 ^ t360;
  assign t539 = (t356 & t358) | (t356 & t360) | (t358 & t360);
  assign t540 = t446 ^ t448 ^ t450;
  assign t541 = (t446 & t448) | (t446 & t450) | (t448 & t450);
  assign t542 = t362 ^ t364 ^ t447;
  assign t543 = (t362 & t364) | (t362 & t447) | (t364 & t447);
  assign t544 = t449 ^ t451 ^ t456;
  assign t545 = (t449 & t451) | (t449 & t456) | (t451 & t456);
  assign t546 = t363 ^ t365 ^ t366;
  assign t547 = (t363 & t365) | (t363 & t366) | (t365 & t366);
  assign t548 = t458 ^ t460 ^ t462;
  assign t549 = (t458 & t460) | (t458 & t462) | (t460 & t462);
  assign t550 = pp248 ^ t367 ^ t459;
  assign t551 = (pp248 & t367) | (pp248 & t459) | (t367 & t459);
  assign t552 = t461 ^ t463 ^ t468;
  assign t553 = (t461 & t463) | (t461 & t468) | (t463 & t468);
  assign t554 = pp204 ^ pp219 ^ pp234;
  assign t555 = (pp204 & pp219) | (pp204 & pp234) | (pp219 & pp234);
  assign t556 = pp249 ^ t470 ^ t472;
  assign t557 = (pp249 & t470) | (pp249 & t472) | (t470 & t472);
  assign t558 = pp220 ^ pp235 ^ pp250;
  assign t559 = (pp220 & pp235) | (pp220 & pp250) | (pp235 & pp250);
  assign t560 = t471 ^ t473 ^ t474;
  assign t561 = (t471 & t473) | (t471 & t474) | (t473 & t474);
  assign t562 = pp191 ^ pp206 ^ pp221;
  assign t563 = (pp191 & pp206) | (pp191 & pp221) | (pp206 & pp221);
  assign t564 = pp236 ^ pp251 ^ t475;
  assign t565 = (pp236 & pp251) | (pp236 & t475) | (pp251 & t475);
  assign t566 = pp207 ^ pp222 ^ pp237;
  assign t567 = (pp207 & pp222) | (pp207 & pp237) | (pp222 & pp237);
  assign t568 = pp3 ^ pp18;
  assign t569 = pp3 & pp18;
  assign t570 = pp34 ^ pp49 ^ pp64;
  assign t571 = (pp34 & pp49) | (pp34 & pp64) | (pp49 & pp64);
  assign t572 = pp80 ^ t477 ^ t478;
  assign t573 = (pp80 & t477) | (pp80 & t478) | (t477 & t478);
  assign t574 = t479 ^ t481 ^ t482;
  assign t575 = (t479 & t481) | (t479 & t482) | (t481 & t482);
  assign t576 = t483 ^ t485 ^ t486;
  assign t577 = (t483 & t485) | (t483 & t486) | (t485 & t486);
  assign t578 = t487 ^ t489 ^ t490;
  assign t579 = (t487 & t489) | (t487 & t490) | (t489 & t490);
  assign t580 = t491 ^ t493 ^ t494;
  assign t581 = (t491 & t493) | (t491 & t494) | (t493 & t494);
  assign t582 = t495 ^ t497 ^ t498;
  assign t583 = (t495 & t497) | (t495 & t498) | (t497 & t498);
  assign t584 = t499 ^ t501 ^ t502;
  assign t585 = (t499 & t501) | (t499 & t502) | (t501 & t502);
  assign t586 = t503 ^ t505 ^ t506;
  assign t587 = (t503 & t505) | (t503 & t506) | (t505 & t506);
  assign t588 = t507 ^ t509 ^ t510;
  assign t589 = (t507 & t509) | (t507 & t510) | (t509 & t510);
  assign t590 = t511 ^ t513 ^ t514;
  assign t591 = (t511 & t513) | (t511 & t514) | (t513 & t514);
  assign t592 = t515 ^ t517 ^ t518;
  assign t593 = (t515 & t517) | (t515 & t518) | (t517 & t518);
  assign t594 = t519 ^ t521 ^ t522;
  assign t595 = (t519 & t521) | (t519 & t522) | (t521 & t522);
  assign t596 = t523 ^ t525 ^ t526;
  assign t597 = (t523 & t525) | (t523 & t526) | (t525 & t526);
  assign t598 = t527 ^ t529 ^ t530;
  assign t599 = (t527 & t529) | (t527 & t530) | (t529 & t530);
  assign t600 = t531 ^ t533 ^ t534;
  assign t601 = (t531 & t533) | (t531 & t534) | (t533 & t534);
  assign t602 = t535 ^ t537 ^ t538;
  assign t603 = (t535 & t537) | (t535 & t538) | (t537 & t538);
  assign t604 = t539 ^ t541 ^ t542;
  assign t605 = (t539 & t541) | (t539 & t542) | (t541 & t542);
  assign t606 = t543 ^ t545 ^ t546;
  assign t607 = (t543 & t545) | (t543 & t546) | (t545 & t546);
  assign t608 = t547 ^ t549 ^ t550;
  assign t609 = (t547 & t549) | (t547 & t550) | (t549 & t550);
  assign t610 = t551 ^ t553 ^ t554;
  assign t611 = (t551 & t553) | (t551 & t554) | (t553 & t554);
  assign t612 = t555 ^ t557 ^ t558;
  assign t613 = (t555 & t557) | (t555 & t558) | (t557 & t558);
  assign t614 = t559 ^ t561 ^ t562;
  assign t615 = (t559 & t561) | (t559 & t562) | (t561 & t562);
  assign t616 = pp252 ^ t563 ^ t565;
  assign t617 = (pp252 & t563) | (pp252 & t565) | (t563 & t565);
  assign t618 = pp223 ^ pp238 ^ pp253;
  assign t619 = (pp223 & pp238) | (pp223 & pp253) | (pp238 & pp253);
  assign t620 = pp2 ^ pp17;
  assign t621 = pp2 & pp17;
  assign t622 = pp33 ^ pp48 ^ t568;
  assign t623 = (pp33 & pp48) | (pp33 & t568) | (pp48 & t568);
  assign t624 = t476 ^ t569 ^ t570;
  assign t625 = (t476 & t569) | (t476 & t570) | (t569 & t570);
  assign t626 = t480 ^ t571 ^ t572;
  assign t627 = (t480 & t571) | (t480 & t572) | (t571 & t572);
  assign t628 = t484 ^ t573 ^ t574;
  assign t629 = (t484 & t573) | (t484 & t574) | (t573 & t574);
  assign t630 = t488 ^ t575 ^ t576;
  assign t631 = (t488 & t575) | (t488 & t576) | (t575 & t576);
  assign t632 = t492 ^ t577 ^ t578;
  assign t633 = (t492 & t577) | (t492 & t578) | (t577 & t578);
  assign t634 = t496 ^ t579 ^ t580;
  assign t635 = (t496 & t579) | (t496 & t580) | (t579 & t580);
  assign t636 = t500 ^ t581 ^ t582;
  assign t637 = (t500 & t581) | (t500 & t582) | (t581 & t582);
  assign t638 = t504 ^ t583 ^ t584;
  assign t639 = (t504 & t583) | (t504 & t584) | (t583 & t584);
  assign t640 = t508 ^ t585 ^ t586;
  assign t641 = (t508 & t585) | (t508 & t586) | (t585 & t586);
  assign t642 = t512 ^ t587 ^ t588;
  assign t643 = (t512 & t587) | (t512 & t588) | (t587 & t588);
  assign t644 = t516 ^ t589 ^ t590;
  assign t645 = (t516 & t589) | (t516 & t590) | (t589 & t590);
  assign t646 = t520 ^ t591 ^ t592;
  assign t647 = (t520 & t591) | (t520 & t592) | (t591 & t592);
  assign t648 = t524 ^ t593 ^ t594;
  assign t649 = (t524 & t593) | (t524 & t594) | (t593 & t594);
  assign t650 = t528 ^ t595 ^ t596;
  assign t651 = (t528 & t595) | (t528 & t596) | (t595 & t596);
  assign t652 = t532 ^ t597 ^ t598;
  assign t653 = (t532 & t597) | (t532 & t598) | (t597 & t598);
  assign t654 = t536 ^ t599 ^ t600;
  assign t655 = (t536 & t599) | (t536 & t600) | (t599 & t600);
  assign t656 = t540 ^ t601 ^ t602;
  assign t657 = (t540 & t601) | (t540 & t602) | (t601 & t602);
  assign t658 = t544 ^ t603 ^ t604;
  assign t659 = (t544 & t603) | (t544 & t604) | (t603 & t604);
  assign t660 = t548 ^ t605 ^ t606;
  assign t661 = (t548 & t605) | (t548 & t606) | (t605 & t606);
  assign t662 = t552 ^ t607 ^ t608;
  assign t663 = (t552 & t607) | (t552 & t608) | (t607 & t608);
  assign t664 = t556 ^ t609 ^ t610;
  assign t665 = (t556 & t609) | (t556 & t610) | (t609 & t610);
  assign t666 = t560 ^ t611 ^ t612;
  assign t667 = (t560 & t611) | (t560 & t612) | (t611 & t612);
  assign t668 = t564 ^ t613 ^ t614;
  assign t669 = (t564 & t613) | (t564 & t614) | (t613 & t614);
  assign t670 = t566 ^ t615 ^ t616;
  assign t671 = (t566 & t615) | (t566 & t616) | (t615 & t616);
  assign t672 = t567 ^ t617 ^ t618;
  assign t673 = (t567 & t617) | (t567 & t618) | (t617 & t618);
  assign t674 = pp239 ^ pp254 ^ t619;
  assign t675 = (pp239 & pp254) | (pp239 & t619) | (pp254 & t619);
  logic [31:0] row_s, row_c;
  assign row_s = {1'b1, pp255, t673, t671, t669, t667, t665, t663, t661, t659, t657, t655, t653, t651, t649, t647, t645, t643, t641, t639, t637, t635, t633, t631, t629, t627, t625, t623, t621, pp32, pp1, pp0};
  assign row_c = {1'b0, t675, t674, t672, t670, t668, t666, t664, t662, t660, t658, t656, t654, t652, t650, t648, t646, t644, t642, t640, t638, t636, t634, t632, t630, t628, t626, t624, t622, t620, pp16, 1'b0};
  fam_adder_carry_increment_p659839ecca660b52c5f1754d416e7ec857891015ca284443d0eb4d7ee2ce61c4_w32 u_cpa (.a(row_s), .b(row_c), .cin(1'b0), .s(p), .cout());
endmodule

module fam_mul_karatsuba_d3_w8_s_pa2efba30 (input logic [7:0] a, input logic [7:0] b, output logic [15:0] p);
  // recursive_karatsuba (two_way): {'split': 4, 'depth': 3, 'products': 3, 'split_kind': 'two_way'}
  logic [3:0] al, bl; logic [3:0] ah, bh;
  logic [7:0] phh; logic [7:0] pll; logic [11:0] pmm;
  logic [15:0] wh, wm;
  logic [15:0] mida_ny;
  logic [15:0] mid_ny;
  logic [5:0] asum; logic asum_co;
  // a_h + a_l
  fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w6 u_i1 (.a({{2{1'b0}}, al}), .b({{2{ah[3]}}, ah}), .cin(1'b0), .s(asum), .cout(asum_co));
  logic [5:0] bsum; logic bsum_co;
  // b_h + b_l
  fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w6 u_i2 (.a({{2{1'b0}}, bl}), .b({{2{bh[3]}}, bh}), .cin(1'b0), .s(bsum), .cout(bsum_co));
  logic [15:0] mida; logic mida_co;
  // pmm - phh
  fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w16 u_i3 (.a({{4{pmm[11]}}, pmm}), .b(mida_ny), .cin(1'b1), .s(mida), .cout(mida_co));
  logic [15:0] mid; logic mid_co;
  // - pll
  fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w16 u_i4 (.a(mida), .b(mid_ny), .cin(1'b1), .s(mid), .cout(mid_co));
  logic [15:0] r1; logic r1_co;
  // pll + mid x
  fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w16 u_i5 (.a({{8{1'b0}}, pll}), .b(wm), .cin(1'b0), .s(r1), .cout(r1_co));
  logic [15:0] r2; logic r2_co;
  // + phh x^2
  fam_adder_sparse_prefix_hybrid_p1b6a021fa8bc128afe1aa6c66a36172faaba17d6805fa5a119519ec616900be7_w16 u_i6 (.a(r1), .b(wh), .cin(1'b0), .s(r2), .cout(r2_co));
  assign mida_ny = ~{{8{phh[7]}}, phh};
  assign mid_ny = ~{{8{1'b0}}, pll};
  assign al = a[3:0]; assign bl = b[3:0]; assign ah = a[7:4]; assign bh = b[7:4];
  fam_mul_karatsuba_d3_w8_s_pa2efba30_hh_b4s u_hh (.a(ah), .b(bh), .p(phh));
  fam_mul_karatsuba_d3_w8_s_pa2efba30_ll_b4u u_ll (.a(al), .b(bl), .p(pll));
  fam_mul_karatsuba_d3_w8_s_pa2efba30_mm_b6s u_mm (.a(asum), .b(bsum), .p(pmm));
  assign wh = {{8{phh[7]}}, phh} << 8; assign wm = mid << 4;
  assign p = r2;
endmodule







// sparse_prefix_hybrid: a sklansky prefix network over blocks of 2 bits, the sums by ripple_precompute












// sparse_prefix_hybrid: a sklansky prefix network over blocks of 2 bits, the sums by ripple_precompute












// sparse_prefix_hybrid: a sklansky prefix network over blocks of 2 bits, the sums by ripple_precompute












module fam_mul_karatsuba_d3_w8_s_pa2efba30_hh_b4s (input logic [3:0] a, input logic [3:0] b, output logic [7:0] p);
  // direct_pp_parallel: {'pp_bits': 18, 'full_adders': 4, 'half_adders': 2, 'cells': 0, 'tree_depth': 2}
  logic pp0, pp1, pp2, pp3, pp4, pp5, pp6, pp7, pp8, pp9, pp10, pp11, pp12, pp13, pp14, pp15, t16, t17, t18, t19, t20, t21, t22, t23, t24, t25, t26, t27;
  assign pp0 = (a[0] & b[0]);
  assign pp1 = (a[0] & b[1]);
  assign pp2 = (a[0] & b[2]);
  assign pp3 = ~(a[0] & b[3]);
  assign pp4 = (a[1] & b[0]);
  assign pp5 = (a[1] & b[1]);
  assign pp6 = (a[1] & b[2]);
  assign pp7 = ~(a[1] & b[3]);
  assign pp8 = (a[2] & b[0]);
  assign pp9 = (a[2] & b[1]);
  assign pp10 = (a[2] & b[2]);
  assign pp11 = ~(a[2] & b[3]);
  assign pp12 = ~(a[3] & b[0]);
  assign pp13 = ~(a[3] & b[1]);
  assign pp14 = ~(a[3] & b[2]);
  assign pp15 = (a[3] & b[3]);
  assign t16 = pp3 ^ pp6;
  assign t17 = pp3 & pp6;
  assign t18 = pp7 ^ pp10 ^ pp13;
  assign t19 = (pp7 & pp10) | (pp7 & pp13) | (pp10 & pp13);
  assign t20 = pp2 ^ pp5;
  assign t21 = pp2 & pp5;
  assign t22 = pp9 ^ pp12 ^ t16;
  assign t23 = (pp9 & pp12) | (pp9 & t16) | (pp12 & t16);
  assign t24 = 1'b1 ^ t17 ^ t18;
  assign t25 = (1'b1 & t17) | (1'b1 & t18) | (t17 & t18);
  assign t26 = pp11 ^ pp14 ^ t19;
  assign t27 = (pp11 & pp14) | (pp11 & t19) | (pp14 & t19);
  logic [7:0] row_s, row_c;
  assign row_s = {1'b1, pp15, t25, t23, t21, pp8, pp1, pp0};
  assign row_c = {1'b0, t27, t26, t24, t22, t20, pp4, 1'b0};
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w8 u_cpa (.a(row_s), .b(row_c), .cin(1'b0), .s(p), .cout());
endmodule





module fam_mul_karatsuba_d3_w8_s_pa2efba30_ll_b4u (input logic [3:0] a, input logic [3:0] b, output logic [7:0] p);
  // direct_pp_parallel: {'pp_bits': 16, 'full_adders': 3, 'half_adders': 3, 'cells': 0, 'tree_depth': 2}
  logic pp0, pp1, pp2, pp3, pp4, pp5, pp6, pp7, pp8, pp9, pp10, pp11, pp12, pp13, pp14, pp15, t16, t17, t18, t19, t20, t21, t22, t23, t24, t25, t26, t27;
  assign pp0 = (a[0] & b[0]);
  assign pp1 = (a[0] & b[1]);
  assign pp2 = (a[0] & b[2]);
  assign pp3 = (a[0] & b[3]);
  assign pp4 = (a[1] & b[0]);
  assign pp5 = (a[1] & b[1]);
  assign pp6 = (a[1] & b[2]);
  assign pp7 = (a[1] & b[3]);
  assign pp8 = (a[2] & b[0]);
  assign pp9 = (a[2] & b[1]);
  assign pp10 = (a[2] & b[2]);
  assign pp11 = (a[2] & b[3]);
  assign pp12 = (a[3] & b[0]);
  assign pp13 = (a[3] & b[1]);
  assign pp14 = (a[3] & b[2]);
  assign pp15 = (a[3] & b[3]);
  assign t16 = pp3 ^ pp6;
  assign t17 = pp3 & pp6;
  assign t18 = pp7 ^ pp10;
  assign t19 = pp7 & pp10;
  assign t20 = pp2 ^ pp5;
  assign t21 = pp2 & pp5;
  assign t22 = pp9 ^ pp12 ^ t16;
  assign t23 = (pp9 & pp12) | (pp9 & t16) | (pp12 & t16);
  assign t24 = pp13 ^ t17 ^ t18;
  assign t25 = (pp13 & t17) | (pp13 & t18) | (t17 & t18);
  assign t26 = pp11 ^ pp14 ^ t19;
  assign t27 = (pp11 & pp14) | (pp11 & t19) | (pp14 & t19);
  logic [7:0] row_s, row_c;
  assign row_s = {1'b0, pp15, t25, t23, t21, pp8, pp1, pp0};
  assign row_c = {1'b0, t27, t26, t24, t22, t20, pp4, 1'b0};
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w8 u_cpa (.a(row_s), .b(row_c), .cin(1'b0), .s(p), .cout());
endmodule


// carry_select: blocks [2, 2, 2, 2] (uniform), full_duplicate, selects lookahead_tree






// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).










module fam_mul_karatsuba_d3_w8_s_pa2efba30_mm_b6s (input logic [5:0] a, input logic [5:0] b, output logic [11:0] p);
  // direct_pp_parallel: {'pp_bits': 38, 'full_adders': 16, 'half_adders': 4, 'cells': 0, 'tree_depth': 3}
  logic pp0, pp1, pp2, pp3, pp4, pp5, pp6, pp7, pp8, pp9, pp10, pp11, pp12, pp13, pp14, pp15, pp16, pp17, pp18, pp19, pp20, pp21, pp22, pp23, pp24, pp25, pp26, pp27, pp28, pp29, pp30, pp31, pp32, pp33, pp34, pp35, t36, t37, t38, t39, t40, t41, t42, t43, t44, t45, t46, t47, t48, t49, t50, t51, t52, t53, t54, t55, t56, t57, t58, t59, t60, t61, t62, t63, t64, t65, t66, t67, t68, t69, t70, t71, t72, t73, t74, t75;
  assign pp0 = (a[0] & b[0]);
  assign pp1 = (a[0] & b[1]);
  assign pp2 = (a[0] & b[2]);
  assign pp3 = (a[0] & b[3]);
  assign pp4 = (a[0] & b[4]);
  assign pp5 = ~(a[0] & b[5]);
  assign pp6 = (a[1] & b[0]);
  assign pp7 = (a[1] & b[1]);
  assign pp8 = (a[1] & b[2]);
  assign pp9 = (a[1] & b[3]);
  assign pp10 = (a[1] & b[4]);
  assign pp11 = ~(a[1] & b[5]);
  assign pp12 = (a[2] & b[0]);
  assign pp13 = (a[2] & b[1]);
  assign pp14 = (a[2] & b[2]);
  assign pp15 = (a[2] & b[3]);
  assign pp16 = (a[2] & b[4]);
  assign pp17 = ~(a[2] & b[5]);
  assign pp18 = (a[3] & b[0]);
  assign pp19 = (a[3] & b[1]);
  assign pp20 = (a[3] & b[2]);
  assign pp21 = (a[3] & b[3]);
  assign pp22 = (a[3] & b[4]);
  assign pp23 = ~(a[3] & b[5]);
  assign pp24 = (a[4] & b[0]);
  assign pp25 = (a[4] & b[1]);
  assign pp26 = (a[4] & b[2]);
  assign pp27 = (a[4] & b[3]);
  assign pp28 = (a[4] & b[4]);
  assign pp29 = ~(a[4] & b[5]);
  assign pp30 = ~(a[5] & b[0]);
  assign pp31 = ~(a[5] & b[1]);
  assign pp32 = ~(a[5] & b[2]);
  assign pp33 = ~(a[5] & b[3]);
  assign pp34 = ~(a[5] & b[4]);
  assign pp35 = (a[5] & b[5]);
  assign t36 = pp4 ^ pp9;
  assign t37 = pp4 & pp9;
  assign t38 = pp5 ^ pp10 ^ pp15;
  assign t39 = (pp5 & pp10) | (pp5 & pp15) | (pp10 & pp15);
  assign t40 = pp20 ^ pp25;
  assign t41 = pp20 & pp25;
  assign t42 = pp11 ^ pp16 ^ pp21;
  assign t43 = (pp11 & pp16) | (pp11 & pp21) | (pp16 & pp21);
  assign t44 = pp26 ^ pp31 ^ 1'b1;
  assign t45 = (pp26 & pp31) | (pp26 & 1'b1) | (pp31 & 1'b1);
  assign t46 = pp17 ^ pp22 ^ pp27;
  assign t47 = (pp17 & pp22) | (pp17 & pp27) | (pp22 & pp27);
  assign t48 = pp3 ^ pp8;
  assign t49 = pp3 & pp8;
  assign t50 = pp14 ^ pp19 ^ pp24;
  assign t51 = (pp14 & pp19) | (pp14 & pp24) | (pp19 & pp24);
  assign t52 = pp30 ^ t37 ^ t38;
  assign t53 = (pp30 & t37) | (pp30 & t38) | (t37 & t38);
  assign t54 = t39 ^ t41 ^ t42;
  assign t55 = (t39 & t41) | (t39 & t42) | (t41 & t42);
  assign t56 = pp32 ^ t43 ^ t45;
  assign t57 = (pp32 & t43) | (pp32 & t45) | (t43 & t45);
  assign t58 = pp23 ^ pp28 ^ pp33;
  assign t59 = (pp23 & pp28) | (pp23 & pp33) | (pp28 & pp33);
  assign t60 = pp2 ^ pp7;
  assign t61 = pp2 & pp7;
  assign t62 = pp13 ^ pp18 ^ t48;
  assign t63 = (pp13 & pp18) | (pp13 & t48) | (pp18 & t48);
  assign t64 = t36 ^ t49 ^ t50;
  assign t65 = (t36 & t49) | (t36 & t50) | (t49 & t50);
  assign t66 = t40 ^ t51 ^ t52;
  assign t67 = (t40 & t51) | (t40 & t52) | (t51 & t52);
  assign t68 = t44 ^ t53 ^ t54;
  assign t69 = (t44 & t53) | (t44 & t54) | (t53 & t54);
  assign t70 = t46 ^ t55 ^ t56;
  assign t71 = (t46 & t55) | (t46 & t56) | (t55 & t56);
  assign t72 = t47 ^ t57 ^ t58;
  assign t73 = (t47 & t57) | (t47 & t58) | (t57 & t58);
  assign t74 = pp29 ^ pp34 ^ t59;
  assign t75 = (pp29 & pp34) | (pp29 & t59) | (pp34 & t59);
  logic [11:0] row_s, row_c;
  assign row_s = {1'b1, pp35, t73, t71, t69, t67, t65, t63, t61, pp12, pp1, pp0};
  assign row_c = {1'b0, t75, t74, t72, t70, t68, t66, t64, t62, t60, pp6, 1'b0};
  fam_adder_carry_select_pc37664859c46f5156115bc8e946f2980c8013fa6779cae73f05d7ddd116a1a1e_w12 u_cpa (.a(row_s), .b(row_c), .cin(1'b0), .s(p), .cout());
endmodule

// squarer (divide_and_conquer): the product from two folded squarers by the quarter-square identity 4ab = (a+b)^2 - (a-b)^2 (a squarer alone serves x^2); the sum, the difference and the final subtraction through the pre_adder slot (compound_flagged_prefix)
module fam_mul_squarer_w16_u_p17507a8b (input logic [15:0] a, input logic [15:0] b, output logic [31:0] p);
  logic [17:0] ae; assign ae = {2'b0, a};
  logic [17:0] be; assign be = {2'b0, b};
  logic [18:0] sa;
  // a + b (the sign bit's carry unused)
  fam_prefix_harris_l1f1_w18_flag_late u1 (.a(ae), .b(be), .cin(1'b0), .s(sa[17:0]), .cout(sa[18]));
  logic [18:0] da;
  logic [17:0] da_nb; assign da_nb = ~be;
  // a - b
  fam_prefix_harris_l1f1_w18_flag_late u2 (.a(ae), .b(da_nb), .cin(1'b1), .s(da[17:0]), .cout(da[18]));
  logic [35:0] s2;
  logic [35:0] d2;
  fam_mul_squarer_w16_u_p17507a8b_sq u_s (.x(sa[17:0]), .p(s2));
  fam_mul_squarer_w16_u_p17507a8b_sq u_d (.x(da[17:0]), .p(d2));
  logic [36:0] diff;
  logic [35:0] diff_nb; assign diff_nb = ~d2;
  // (a+b)^2 - (a-b)^2
  fam_prefix_harris_l1f1_w36_flag_late u3 (.a(s2), .b(diff_nb), .cin(1'b1), .s(diff[35:0]), .cout(diff[36]));
  assign p = diff[33:2];
endmodule


module fam_mul_squarer_w16_u_p17507a8b_sq (input logic [17:0] x, output logic [35:0] p);
  // squarer (divide_and_conquer, two's complement x): 51 full adders, 20 half adders, depth 3
  logic sq0, sq1, sq2, sq3, sq4, sq5, sq6, sq7, sq8, sq9, sq10, sq11, sq12, sq13, sq14, sq15, sq16, sq17, sq18, sq19, sq20, sq21, sq22, sq23, sq24, sq25, sq26, sq27, sq28, sq29, sq30, sq31, sq32, sq33, sq34, sq35, sq36, sq37, sq38, sq39, sq40, sq41, sq42, sq43, sq44, sq45, sq46, sq47, sq48, sq49, sq50, sq51, sq52, sq53, sq54, sq55, sq56, sq57, sq58, sq59, sq60, sq61, sq62, sq63, sq64, sq65, sq66, sq67, sq68, sq69, sq70, sq71, sq72, t73, t74, t75, t76, t77, t78, t79, t80, t81, t82, t83, t84, t85, t86, t87, t88, t89, t90, t91, t92, t93, t94, t95, t96, t97, t98, t99, t100, t101, t102, t103, t104, t105, t106, t107, t108, t109, t110, t111, t112, t113, t114, t115, t116, t117, t118, t119, t120, t121, t122, t123, t124, t125, t126, t127, t128, t129, t130, t131, t132, t133, t134, t135, t136, t137, t138, t139, t140, t141, t142, t143, t144, t145, t146, t147, t148, t149, t150, t151, t152, t153, t154, t155, t156, t157, t158, t159, t160, t161, t162, t163, t164, t165, t166, t167, t168, t169, t170, t171, t172, t173, t174, t175, t176, t177, t178, t179, t180, t181, t182, t183, t184, t185, t186, t187, t188, t189, t190, t191, t192, t193, t194, t195, t196, t197, t198, t199, t200, t201, t202, t203, t204, t205, t206, t207, t208, t209, t210, t211, t212, t213, t214;
  logic [8:0] xl_x;
  logic [8:0] xh_x;
  logic [19:0] xp_x;
  // the cross product of the halves (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w10_s_p586fca89 u_cross_x (.a({{1{1'b0}}, xl_x}), .b({{1{xh_x[8]}}, xh_x}), .p(xp_x));
  assign xl_x = x[8:0];
  assign xh_x = x[17:9];
  assign sq0 = xl_x[0] & xl_x[1];
  assign sq1 = xl_x[0] & xl_x[2];
  assign sq2 = xl_x[0] & xl_x[3];
  assign sq3 = xl_x[0] & xl_x[4];
  assign sq4 = xl_x[0] & xl_x[5];
  assign sq5 = xl_x[0] & xl_x[6];
  assign sq6 = xl_x[0] & xl_x[7];
  assign sq7 = xl_x[0] & xl_x[8];
  assign sq8 = xl_x[1] & xl_x[2];
  assign sq9 = xl_x[1] & xl_x[3];
  assign sq10 = xl_x[1] & xl_x[4];
  assign sq11 = xl_x[1] & xl_x[5];
  assign sq12 = xl_x[1] & xl_x[6];
  assign sq13 = xl_x[1] & xl_x[7];
  assign sq14 = xl_x[1] & xl_x[8];
  assign sq15 = xl_x[2] & xl_x[3];
  assign sq16 = xl_x[2] & xl_x[4];
  assign sq17 = xl_x[2] & xl_x[5];
  assign sq18 = xl_x[2] & xl_x[6];
  assign sq19 = xl_x[2] & xl_x[7];
  assign sq20 = xl_x[2] & xl_x[8];
  assign sq21 = xl_x[3] & xl_x[4];
  assign sq22 = xl_x[3] & xl_x[5];
  assign sq23 = xl_x[3] & xl_x[6];
  assign sq24 = xl_x[3] & xl_x[7];
  assign sq25 = xl_x[3] & xl_x[8];
  assign sq26 = xl_x[4] & xl_x[5];
  assign sq27 = xl_x[4] & xl_x[6];
  assign sq28 = xl_x[4] & xl_x[7];
  assign sq29 = xl_x[4] & xl_x[8];
  assign sq30 = xl_x[5] & xl_x[6];
  assign sq31 = xl_x[5] & xl_x[7];
  assign sq32 = xl_x[5] & xl_x[8];
  assign sq33 = xl_x[6] & xl_x[7];
  assign sq34 = xl_x[6] & xl_x[8];
  assign sq35 = xl_x[7] & xl_x[8];
  assign sq36 = xh_x[0] & xh_x[1];
  assign sq37 = xh_x[0] & xh_x[2];
  assign sq38 = xh_x[0] & xh_x[3];
  assign sq39 = xh_x[0] & xh_x[4];
  assign sq40 = xh_x[0] & xh_x[5];
  assign sq41 = xh_x[0] & xh_x[6];
  assign sq42 = xh_x[0] & xh_x[7];
  assign sq43 = ~(xh_x[0] & xh_x[8]);
  assign sq44 = xh_x[1] & xh_x[2];
  assign sq45 = xh_x[1] & xh_x[3];
  assign sq46 = xh_x[1] & xh_x[4];
  assign sq47 = xh_x[1] & xh_x[5];
  assign sq48 = xh_x[1] & xh_x[6];
  assign sq49 = xh_x[1] & xh_x[7];
  assign sq50 = ~(xh_x[1] & xh_x[8]);
  assign sq51 = xh_x[2] & xh_x[3];
  assign sq52 = xh_x[2] & xh_x[4];
  assign sq53 = xh_x[2] & xh_x[5];
  assign sq54 = xh_x[2] & xh_x[6];
  assign sq55 = xh_x[2] & xh_x[7];
  assign sq56 = ~(xh_x[2] & xh_x[8]);
  assign sq57 = xh_x[3] & xh_x[4];
  assign sq58 = xh_x[3] & xh_x[5];
  assign sq59 = xh_x[3] & xh_x[6];
  assign sq60 = xh_x[3] & xh_x[7];
  assign sq61 = ~(xh_x[3] & xh_x[8]);
  assign sq62 = xh_x[4] & xh_x[5];
  assign sq63 = xh_x[4] & xh_x[6];
  assign sq64 = xh_x[4] & xh_x[7];
  assign sq65 = ~(xh_x[4] & xh_x[8]);
  assign sq66 = xh_x[5] & xh_x[6];
  assign sq67 = xh_x[5] & xh_x[7];
  assign sq68 = ~(xh_x[5] & xh_x[8]);
  assign sq69 = xh_x[6] & xh_x[7];
  assign sq70 = ~(xh_x[6] & xh_x[8]);
  assign sq71 = ~(xh_x[7] & xh_x[8]);
  assign sq72 = ~xp_x[19];
  assign t73 = sq6 ^ sq12;
  assign t74 = sq6 & sq12;
  assign t75 = sq7 ^ sq13;
  assign t76 = sq7 & sq13;
  assign t77 = sq14 ^ sq19 ^ sq23;
  assign t78 = (sq14 & sq19) | (sq14 & sq23) | (sq19 & sq23);
  assign t79 = sq26 ^ xl_x[5];
  assign t80 = sq26 & xl_x[5];
  assign t81 = sq20 ^ sq24 ^ sq27;
  assign t82 = (sq20 & sq24) | (sq20 & sq27) | (sq24 & sq27);
  assign t83 = sq25 ^ sq28 ^ sq30;
  assign t84 = (sq25 & sq28) | (sq25 & sq30) | (sq28 & sq30);
  assign t85 = sq40 ^ sq46;
  assign t86 = sq40 & sq46;
  assign t87 = sq41 ^ sq47;
  assign t88 = sq41 & sq47;
  assign t89 = sq42 ^ sq48 ^ sq53;
  assign t90 = (sq42 & sq48) | (sq42 & sq53) | (sq48 & sq53);
  assign t91 = sq57 ^ xh_x[4];
  assign t92 = sq57 & xh_x[4];
  assign t93 = sq43 ^ sq49 ^ sq54;
  assign t94 = (sq43 & sq49) | (sq43 & sq54) | (sq49 & sq54);
  assign t95 = sq58 ^ 1'b1 ^ xp_x[17];
  assign t96 = (sq58 & 1'b1) | (sq58 & xp_x[17]) | (1'b1 & xp_x[17]);
  assign t97 = sq50 ^ sq55 ^ sq59;
  assign t98 = (sq50 & sq55) | (sq50 & sq59) | (sq55 & sq59);
  assign t99 = sq62 ^ xh_x[5] ^ xp_x[18];
  assign t100 = (sq62 & xh_x[5]) | (sq62 & xp_x[18]) | (xh_x[5] & xp_x[18]);
  assign t101 = sq56 ^ sq60 ^ sq63;
  assign t102 = (sq56 & sq60) | (sq56 & sq63) | (sq60 & sq63);
  assign t103 = sq72 ^ 1'b1;
  assign t104 = sq72 & 1'b1;
  assign t105 = sq61 ^ sq64 ^ sq66;
  assign t106 = (sq61 & sq64) | (sq61 & sq66) | (sq64 & sq66);
  assign t107 = xh_x[6] ^ 1'b1;
  assign t108 = xh_x[6] & 1'b1;
  assign t109 = sq65 ^ sq67;
  assign t110 = sq65 & sq67;
  assign t111 = sq68 ^ sq69;
  assign t112 = sq68 & sq69;
  assign t113 = sq4 ^ sq10;
  assign t114 = sq4 & sq10;
  assign t115 = sq5 ^ sq11;
  assign t116 = sq5 & sq11;
  assign t117 = sq17 ^ sq21 ^ xl_x[4];
  assign t118 = (sq17 & sq21) | (sq17 & xl_x[4]) | (sq21 & xl_x[4]);
  assign t119 = sq18 ^ sq22 ^ t74;
  assign t120 = (sq18 & sq22) | (sq18 & t74) | (sq22 & t74);
  assign t121 = xp_x[0] ^ t76 ^ t77;
  assign t122 = (xp_x[0] & t76) | (xp_x[0] & t77) | (t76 & t77);
  assign t123 = xp_x[1] ^ t78 ^ t80;
  assign t124 = (xp_x[1] & t78) | (xp_x[1] & t80) | (t78 & t80);
  assign t125 = xl_x[6] ^ xp_x[2] ^ t82;
  assign t126 = (xl_x[6] & xp_x[2]) | (xl_x[6] & t82) | (xp_x[2] & t82);
  assign t127 = sq29 ^ sq31 ^ xp_x[3];
  assign t128 = (sq29 & sq31) | (sq29 & xp_x[3]) | (sq31 & xp_x[3]);
  assign t129 = sq32 ^ sq33 ^ xl_x[7];
  assign t130 = (sq32 & sq33) | (sq32 & xl_x[7]) | (sq33 & xl_x[7]);
  assign t131 = sq38 ^ sq44;
  assign t132 = sq38 & sq44;
  assign t133 = sq39 ^ sq45;
  assign t134 = sq39 & sq45;
  assign t135 = sq51 ^ xh_x[3] ^ xp_x[14];
  assign t136 = (sq51 & xh_x[3]) | (sq51 & xp_x[14]) | (xh_x[3] & xp_x[14]);
  assign t137 = sq52 ^ xp_x[15] ^ t86;
  assign t138 = (sq52 & xp_x[15]) | (sq52 & t86) | (xp_x[15] & t86);
  assign t139 = xp_x[16] ^ t88 ^ t89;
  assign t140 = (xp_x[16] & t88) | (xp_x[16] & t89) | (t88 & t89);
  assign t141 = t90 ^ t92 ^ t93;
  assign t142 = (t90 & t92) | (t90 & t93) | (t92 & t93);
  assign t143 = t94 ^ t96 ^ t97;
  assign t144 = (t94 & t96) | (t94 & t97) | (t96 & t97);
  assign t145 = t98 ^ t100 ^ t101;
  assign t146 = (t98 & t100) | (t98 & t101) | (t100 & t101);
  assign t147 = t102 ^ t104 ^ t105;
  assign t148 = (t102 & t104) | (t102 & t105) | (t104 & t105);
  assign t149 = 1'b1 ^ t106 ^ t108;
  assign t150 = (1'b1 & t106) | (1'b1 & t108) | (t106 & t108);
  assign t151 = xh_x[7] ^ 1'b1 ^ t110;
  assign t152 = (xh_x[7] & 1'b1) | (xh_x[7] & t110) | (1'b1 & t110);
  assign t153 = sq70 ^ 1'b1;
  assign t154 = sq70 & 1'b1;
  assign t155 = sq71 ^ xh_x[8];
  assign t156 = sq71 & xh_x[8];
  assign t157 = sq2 ^ sq8;
  assign t158 = sq2 & sq8;
  assign t159 = sq3 ^ sq9;
  assign t160 = sq3 & sq9;
  assign t161 = sq15 ^ xl_x[3] ^ t113;
  assign t162 = (sq15 & xl_x[3]) | (sq15 & t113) | (xl_x[3] & t113);
  assign t163 = sq16 ^ t114 ^ t115;
  assign t164 = (sq16 & t114) | (sq16 & t115) | (t114 & t115);
  assign t165 = t73 ^ t116 ^ t117;
  assign t166 = (t73 & t116) | (t73 & t117) | (t116 & t117);
  assign t167 = t75 ^ t118 ^ t119;
  assign t168 = (t75 & t118) | (t75 & t119) | (t118 & t119);
  assign t169 = t79 ^ t120 ^ t121;
  assign t170 = (t79 & t120) | (t79 & t121) | (t120 & t121);
  assign t171 = t81 ^ t122 ^ t123;
  assign t172 = (t81 & t122) | (t81 & t123) | (t122 & t123);
  assign t173 = t83 ^ t124 ^ t125;
  assign t174 = (t83 & t124) | (t83 & t125) | (t124 & t125);
  assign t175 = t84 ^ t126 ^ t127;
  assign t176 = (t84 & t126) | (t84 & t127) | (t126 & t127);
  assign t177 = xp_x[4] ^ t128 ^ t129;
  assign t178 = (xp_x[4] & t128) | (xp_x[4] & t129) | (t128 & t129);
  assign t179 = sq34 ^ xp_x[5] ^ t130;
  assign t180 = (sq34 & xp_x[5]) | (sq34 & t130) | (xp_x[5] & t130);
  assign t181 = sq35 ^ xl_x[8] ^ xp_x[6];
  assign t182 = (sq35 & xl_x[8]) | (sq35 & xp_x[6]) | (xl_x[8] & xp_x[6]);
  assign t183 = sq36 ^ xh_x[1];
  assign t184 = sq36 & xh_x[1];
  assign t185 = sq37 ^ xp_x[11];
  assign t186 = sq37 & xp_x[11];
  assign t187 = xh_x[2] ^ xp_x[12] ^ t131;
  assign t188 = (xh_x[2] & xp_x[12]) | (xh_x[2] & t131) | (xp_x[12] & t131);
  assign t189 = xp_x[13] ^ t132 ^ t133;
  assign t190 = (xp_x[13] & t132) | (xp_x[13] & t133) | (t132 & t133);
  assign t191 = t85 ^ t134 ^ t135;
  assign t192 = (t85 & t134) | (t85 & t135) | (t134 & t135);
  assign t193 = t87 ^ t136 ^ t137;
  assign t194 = (t87 & t136) | (t87 & t137) | (t136 & t137);
  assign t195 = t91 ^ t138 ^ t139;
  assign t196 = (t91 & t138) | (t91 & t139) | (t138 & t139);
  assign t197 = t95 ^ t140 ^ t141;
  assign t198 = (t95 & t140) | (t95 & t141) | (t140 & t141);
  assign t199 = t99 ^ t142 ^ t143;
  assign t200 = (t99 & t142) | (t99 & t143) | (t142 & t143);
  assign t201 = t103 ^ t144 ^ t145;
  assign t202 = (t103 & t144) | (t103 & t145) | (t144 & t145);
  assign t203 = t107 ^ t146 ^ t147;
  assign t204 = (t107 & t146) | (t107 & t147) | (t146 & t147);
  assign t205 = t109 ^ t148 ^ t149;
  assign t206 = (t109 & t148) | (t109 & t149) | (t148 & t149);
  assign t207 = t111 ^ t150 ^ t151;
  assign t208 = (t111 & t150) | (t111 & t151) | (t150 & t151);
  assign t209 = t112 ^ t152 ^ t153;
  assign t210 = (t112 & t152) | (t112 & t153) | (t152 & t153);
  assign t211 = 1'b1 ^ t154 ^ t155;
  assign t212 = (1'b1 & t154) | (1'b1 & t155) | (t154 & t155);
  assign t213 = 1'b1 ^ 1'b1 ^ t156;
  assign t214 = (1'b1 & 1'b1) | (1'b1 & t156) | (1'b1 & t156);
  logic [35:0] row_s, row_c;
  assign row_s = {t212, t210, t208, t206, t204, t202, t200, t198, t196, t194, t192, t190, t188, t186, t184, xp_x[10], xp_x[9], xh_x[0], xp_x[7], t180, t178, t176, t174, t172, t170, t168, t166, t164, t162, t160, t158, xl_x[2], sq1, sq0, 1'b0, xl_x[0]};
  assign row_c = {t213, t211, t209, t207, t205, t203, t201, t199, t197, t195, t193, t191, t189, t187, t185, t183, 1'b0, xp_x[8], t182, t181, t179, t177, t175, t173, t171, t169, t167, t165, t163, t161, t159, t157, 1'b0, xl_x[1], 1'b0, 1'b0};
  // hybrid final adder: regions [0, 12, 24, 36] of kinds ['ripple', 'cla', 'select'] on the uniform profile (delay_bound_boundary_enumeration)
  logic rg0_co;
  fam_adder_ripple_carry #(.W(12), .CHUNK(1), .FORM(0)) u_rg0 (.a(row_s[11:0]), .b(row_c[11:0]), .cin(1'b0), .s(p[11:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_lookahead #(.W(12), .G(4), .INTER(0), .LEVELS(1)) u_rg1 (.a(row_s[23:12]), .b(row_c[23:12]), .cin(rg0_co), .s(p[23:12]), .cout(rg1_co));
  logic rg2_co;
  fam_adder_carry_select_w12 u_rg2 (.a(row_s[35:24]), .b(row_c[35:24]), .cin(rg1_co), .s(p[35:24]), .cout(rg2_co));
endmodule


module fam_prefix_arrival_0_0_1_1_1_2_2_3_3_3_4_4_w12 (input logic [11:0] a, input logic [11:0] b, input logic cin,
  output logic [11:0] s, output logic cout);
  // prefix graph: {'n': 12, 'levels': 5, 'size': 22, 'fanout': 4, 'tracks': 3, 'exact_split': True, 'valency': 2}
  logic [11:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [11:0] g0, p0;
  assign g0 = {gi[11:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_2_3, P_2_3, G_3_4, P_3_4, G_5_6, P_5_6, G_7_8, P_7_8, G_8_9, P_8_9, G_10_11, P_10_11, G_0_2, G_0_3, G_3_5, P_3_5, G_5_7, P_5_7, G_8_10, P_8_10, G_0_4, G_0_5, G_5_9, P_5_9, G_0_6, G_0_7, G_0_9, G_5_11, P_5_11, G_0_8, G_0_10, G_0_11;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_5_6 = g0[6] | (p0[6] & g0[5]);
  assign P_5_6 = p0[6] & p0[5];
  assign G_7_8 = g0[8] | (p0[8] & g0[7]);
  assign P_7_8 = p0[8] & p0[7];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_3_5 = g0[5] | (p0[5] & G_3_4);
  assign P_3_5 = p0[5] & P_3_4;
  assign G_5_7 = g0[7] | (p0[7] & G_5_6);
  assign P_5_7 = p0[7] & P_5_6;
  assign G_8_10 = g0[10] | (p0[10] & G_8_9);
  assign P_8_10 = p0[10] & P_8_9;
  assign G_0_4 = G_3_4 | (P_3_4 & G_0_2);
  assign G_0_5 = G_3_5 | (P_3_5 & G_0_2);
  assign G_5_9 = G_8_9 | (P_8_9 & G_5_7);
  assign P_5_9 = P_8_9 & P_5_7;
  assign G_0_6 = G_5_6 | (P_5_6 & G_0_4);
  assign G_0_7 = G_5_7 | (P_5_7 & G_0_4);
  assign G_0_9 = G_5_9 | (P_5_9 & G_0_4);
  assign G_5_11 = G_10_11 | (P_10_11 & G_5_9);
  assign P_5_11 = P_10_11 & P_5_9;
  assign G_0_8 = G_7_8 | (P_7_8 & G_0_6);
  assign G_0_10 = G_8_10 | (P_8_10 & G_0_7);
  assign G_0_11 = G_5_11 | (P_5_11 & G_0_4);
  logic [12:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign s = pi_ ^ c[11:0];
  assign cout = c[12];
endmodule


module fam_prefix_arrival_0_0_1_1_2_2_3_3_w8 (input logic [7:0] a, input logic [7:0] b, input logic cin,
  output logic [7:0] s, output logic cout);
  // prefix graph: {'n': 8, 'levels': 4, 'size': 12, 'fanout': 3, 'tracks': 2, 'exact_split': True, 'valency': 2}
  logic [7:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [7:0] g0, p0;
  assign g0 = {gi[7:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_0_2, G_0_3, G_2_4, P_2_4, G_4_6, P_4_6, G_0_4, G_0_5, G_0_6, G_0_7;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_2_4 = g0[4] | (p0[4] & G_2_3);
  assign P_2_4 = p0[4] & P_2_3;
  assign G_4_6 = g0[6] | (p0[6] & G_4_5);
  assign P_4_6 = p0[6] & P_4_5;
  assign G_0_4 = G_2_4 | (P_2_4 & G_0_1);
  assign G_0_5 = G_4_5 | (P_4_5 & G_0_3);
  assign G_0_6 = G_4_6 | (P_4_6 & G_0_3);
  assign G_0_7 = G_6_7 | (P_6_7 & G_0_5);
  logic [8:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign s = pi_ ^ c[7:0];
  assign cout = c[8];
endmodule



module fam_prefix_arrival_0_1_1_2_w4 (input logic [3:0] a, input logic [3:0] b, input logic cin,
  output logic [3:0] s, output logic cout);
  // prefix graph: {'n': 4, 'levels': 3, 'size': 5, 'fanout': 3, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [3:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [3:0] g0, p0;
  assign g0 = {gi[3:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_1_2, P_1_2, G_0_2, G_1_3, P_1_3, G_0_3;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_1_3 = g0[3] | (p0[3] & G_1_2);
  assign P_1_3 = p0[3] & P_1_2;
  assign G_0_3 = G_1_3 | (P_1_3 & g0[0]);
  logic [4:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign s = pi_ ^ c[3:0];
  assign cout = c[4];
endmodule




module fam_prefix_han_carlson_w2 (input logic [1:0] a, input logic [1:0] b, input logic cin,
  output logic [1:0] s, output logic cout);
  // prefix graph: {'n': 2, 'levels': 1, 'size': 1, 'fanout': 1, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [1:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [1:0] g0, p0;
  assign g0 = {gi[1:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  logic [2:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign s = pi_ ^ c[1:0];
  assign cout = c[2];
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).








module fam_prefix_harris_l1f1_w18_flag_late (input logic [17:0] a, input logic [17:0] b, input logic cin,
  output logic [17:0] s, output logic cout, output logic [17:0] s1);
  // prefix graph: {'n': 18, 'levels': 5, 'size': 38, 'fanout': 4, 'tracks': 4, 'exact_split': False, 'valency': 2}
  logic [17:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [17:0] g0, p0;
  assign g0 = gi;
  assign p0 = pi_;
  logic G_0_1, P_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_8_9, P_8_9, G_10_11, P_10_11, G_12_13, P_12_13, G_14_15, P_14_15, G_16_17, P_16_17, G_0_2, P_0_2, G_0_3, P_0_3, G_2_5, P_2_5, G_4_7, P_4_7, G_6_9, P_6_9, G_8_11, P_8_11, G_10_13, P_10_13, G_12_15, P_12_15, G_14_17, P_14_17, G_0_4, P_0_4, G_0_5, P_0_5, G_0_7, P_0_7, G_2_9, P_2_9, G_4_11, P_4_11, G_6_13, P_6_13, G_8_15, P_8_15, G_10_17, P_10_17, G_0_6, P_0_6, G_0_8, P_0_8, G_0_9, P_0_9, G_0_11, P_0_11, G_0_13, P_0_13, G_0_15, P_0_15, G_2_17, P_2_17, G_0_10, P_0_10, G_0_12, P_0_12, G_0_14, P_0_14, G_0_16, P_0_16, G_0_17, P_0_17;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign P_0_1 = p0[1] & p0[0];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_16_17 = g0[17] | (p0[17] & g0[16]);
  assign P_16_17 = p0[17] & p0[16];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign P_0_2 = p0[2] & P_0_1;
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign P_0_3 = P_2_3 & P_0_1;
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_6_9 = G_8_9 | (P_8_9 & G_6_7);
  assign P_6_9 = P_8_9 & P_6_7;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_10_13 = G_12_13 | (P_12_13 & G_10_11);
  assign P_10_13 = P_12_13 & P_10_11;
  assign G_12_15 = G_14_15 | (P_14_15 & G_12_13);
  assign P_12_15 = P_14_15 & P_12_13;
  assign G_14_17 = G_16_17 | (P_16_17 & G_14_15);
  assign P_14_17 = P_16_17 & P_14_15;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign P_0_4 = p0[4] & P_0_3;
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  assign P_0_5 = P_2_5 & P_0_1;
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign P_0_7 = P_4_7 & P_0_3;
  assign G_2_9 = G_6_9 | (P_6_9 & G_2_5);
  assign P_2_9 = P_6_9 & P_2_5;
  assign G_4_11 = G_8_11 | (P_8_11 & G_4_7);
  assign P_4_11 = P_8_11 & P_4_7;
  assign G_6_13 = G_10_13 | (P_10_13 & G_6_9);
  assign P_6_13 = P_10_13 & P_6_9;
  assign G_8_15 = G_12_15 | (P_12_15 & G_8_11);
  assign P_8_15 = P_12_15 & P_8_11;
  assign G_10_17 = G_14_17 | (P_14_17 & G_10_13);
  assign P_10_17 = P_14_17 & P_10_13;
  assign G_0_6 = g0[6] | (p0[6] & G_0_5);
  assign P_0_6 = p0[6] & P_0_5;
  assign G_0_8 = g0[8] | (p0[8] & G_0_7);
  assign P_0_8 = p0[8] & P_0_7;
  assign G_0_9 = G_2_9 | (P_2_9 & G_0_1);
  assign P_0_9 = P_2_9 & P_0_1;
  assign G_0_11 = G_4_11 | (P_4_11 & G_0_3);
  assign P_0_11 = P_4_11 & P_0_3;
  assign G_0_13 = G_6_13 | (P_6_13 & G_0_5);
  assign P_0_13 = P_6_13 & P_0_5;
  assign G_0_15 = G_8_15 | (P_8_15 & G_0_7);
  assign P_0_15 = P_8_15 & P_0_7;
  assign G_2_17 = G_10_17 | (P_10_17 & G_2_9);
  assign P_2_17 = P_10_17 & P_2_9;
  assign G_0_10 = g0[10] | (p0[10] & G_0_9);
  assign P_0_10 = p0[10] & P_0_9;
  assign G_0_12 = g0[12] | (p0[12] & G_0_11);
  assign P_0_12 = p0[12] & P_0_11;
  assign G_0_14 = g0[14] | (p0[14] & G_0_13);
  assign P_0_14 = p0[14] & P_0_13;
  assign G_0_16 = g0[16] | (p0[16] & G_0_15);
  assign P_0_16 = p0[16] & P_0_15;
  assign G_0_17 = G_2_17 | (P_2_17 & G_0_3);
  assign P_0_17 = P_2_17 & P_0_3;
  logic [18:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0] | (p0[0] & cin);
  assign c[2] = G_0_1 | (P_0_1 & cin);
  assign c[3] = G_0_2 | (P_0_2 & cin);
  assign c[4] = G_0_3 | (P_0_3 & cin);
  assign c[5] = G_0_4 | (P_0_4 & cin);
  assign c[6] = G_0_5 | (P_0_5 & cin);
  assign c[7] = G_0_6 | (P_0_6 & cin);
  assign c[8] = G_0_7 | (P_0_7 & cin);
  assign c[9] = G_0_8 | (P_0_8 & cin);
  assign c[10] = G_0_9 | (P_0_9 & cin);
  assign c[11] = G_0_10 | (P_0_10 & cin);
  assign c[12] = G_0_11 | (P_0_11 & cin);
  assign c[13] = G_0_12 | (P_0_12 & cin);
  assign c[14] = G_0_13 | (P_0_13 & cin);
  assign c[15] = G_0_14 | (P_0_14 & cin);
  assign c[16] = G_0_15 | (P_0_15 & cin);
  assign c[17] = G_0_16 | (P_0_16 & cin);
  assign c[18] = G_0_17 | (P_0_17 & cin);
  assign s = pi_ ^ c[17:0];
  assign cout = c[18];
  logic [17:0] f;
  assign f[0] = 1'b1;
  assign f[1] = pi_[0];
  assign f[2] = P_0_1;
  assign f[3] = P_0_2;
  assign f[4] = P_0_3;
  assign f[5] = P_0_4;
  assign f[6] = P_0_5;
  assign f[7] = P_0_6;
  assign f[8] = P_0_7;
  assign f[9] = P_0_8;
  assign f[10] = P_0_9;
  assign f[11] = P_0_10;
  assign f[12] = P_0_11;
  assign f[13] = P_0_12;
  assign f[14] = P_0_13;
  assign f[15] = P_0_14;
  assign f[16] = P_0_15;
  assign f[17] = P_0_16;
  assign s1 = s ^ f;
endmodule



module fam_prefix_harris_l1f1_w36_flag_late (input logic [35:0] a, input logic [35:0] b, input logic cin,
  output logic [35:0] s, output logic cout, output logic [35:0] s1);
  // prefix graph: {'n': 36, 'levels': 7, 'size': 94, 'fanout': 6, 'tracks': 8, 'exact_split': False, 'valency': 2}
  logic [35:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [35:0] g0, p0;
  assign g0 = gi;
  assign p0 = pi_;
  logic G_0_1, P_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_8_9, P_8_9, G_10_11, P_10_11, G_12_13, P_12_13, G_14_15, P_14_15, G_16_17, P_16_17, G_18_19, P_18_19, G_20_21, P_20_21, G_22_23, P_22_23, G_24_25, P_24_25, G_26_27, P_26_27, G_28_29, P_28_29, G_30_31, P_30_31, G_32_33, P_32_33, G_34_35, P_34_35, G_0_2, P_0_2, G_0_3, P_0_3, G_2_5, P_2_5, G_4_7, P_4_7, G_6_9, P_6_9, G_8_11, P_8_11, G_10_13, P_10_13, G_12_15, P_12_15, G_14_17, P_14_17, G_16_19, P_16_19, G_18_21, P_18_21, G_20_23, P_20_23, G_22_25, P_22_25, G_24_27, P_24_27, G_26_29, P_26_29, G_28_31, P_28_31, G_30_33, P_30_33, G_32_35, P_32_35, G_0_4, P_0_4, G_0_5, P_0_5, G_0_7, P_0_7, G_2_9, P_2_9, G_4_11, P_4_11, G_6_13, P_6_13, G_8_15, P_8_15, G_10_17, P_10_17, G_12_19, P_12_19, G_14_21, P_14_21, G_16_23, P_16_23, G_18_25, P_18_25, G_20_27, P_20_27, G_22_29, P_22_29, G_24_31, P_24_31, G_26_33, P_26_33, G_28_35, P_28_35, G_0_6, P_0_6, G_0_8, P_0_8, G_0_9, P_0_9, G_0_11, P_0_11, G_0_13, P_0_13, G_0_15, P_0_15, G_2_17, P_2_17, G_4_19, P_4_19, G_6_21, P_6_21, G_8_23, P_8_23, G_10_25, P_10_25, G_12_27, P_12_27, G_14_29, P_14_29, G_16_31, P_16_31, G_18_33, P_18_33, G_20_35, P_20_35, G_0_10, P_0_10, G_0_12, P_0_12, G_0_14, P_0_14, G_0_16, P_0_16, G_0_17, P_0_17, G_0_19, P_0_19, G_0_21, P_0_21, G_0_23, P_0_23, G_0_25, P_0_25, G_0_27, P_0_27, G_0_29, P_0_29, G_0_31, P_0_31, G_2_33, P_2_33, G_4_35, P_4_35, G_0_18, P_0_18, G_0_20, P_0_20, G_0_22, P_0_22, G_0_24, P_0_24, G_0_26, P_0_26, G_0_28, P_0_28, G_0_30, P_0_30, G_0_32, P_0_32, G_0_33, P_0_33, G_0_35, P_0_35, G_0_34, P_0_34;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign P_0_1 = p0[1] & p0[0];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_16_17 = g0[17] | (p0[17] & g0[16]);
  assign P_16_17 = p0[17] & p0[16];
  assign G_18_19 = g0[19] | (p0[19] & g0[18]);
  assign P_18_19 = p0[19] & p0[18];
  assign G_20_21 = g0[21] | (p0[21] & g0[20]);
  assign P_20_21 = p0[21] & p0[20];
  assign G_22_23 = g0[23] | (p0[23] & g0[22]);
  assign P_22_23 = p0[23] & p0[22];
  assign G_24_25 = g0[25] | (p0[25] & g0[24]);
  assign P_24_25 = p0[25] & p0[24];
  assign G_26_27 = g0[27] | (p0[27] & g0[26]);
  assign P_26_27 = p0[27] & p0[26];
  assign G_28_29 = g0[29] | (p0[29] & g0[28]);
  assign P_28_29 = p0[29] & p0[28];
  assign G_30_31 = g0[31] | (p0[31] & g0[30]);
  assign P_30_31 = p0[31] & p0[30];
  assign G_32_33 = g0[33] | (p0[33] & g0[32]);
  assign P_32_33 = p0[33] & p0[32];
  assign G_34_35 = g0[35] | (p0[35] & g0[34]);
  assign P_34_35 = p0[35] & p0[34];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign P_0_2 = p0[2] & P_0_1;
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign P_0_3 = P_2_3 & P_0_1;
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_6_9 = G_8_9 | (P_8_9 & G_6_7);
  assign P_6_9 = P_8_9 & P_6_7;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_10_13 = G_12_13 | (P_12_13 & G_10_11);
  assign P_10_13 = P_12_13 & P_10_11;
  assign G_12_15 = G_14_15 | (P_14_15 & G_12_13);
  assign P_12_15 = P_14_15 & P_12_13;
  assign G_14_17 = G_16_17 | (P_16_17 & G_14_15);
  assign P_14_17 = P_16_17 & P_14_15;
  assign G_16_19 = G_18_19 | (P_18_19 & G_16_17);
  assign P_16_19 = P_18_19 & P_16_17;
  assign G_18_21 = G_20_21 | (P_20_21 & G_18_19);
  assign P_18_21 = P_20_21 & P_18_19;
  assign G_20_23 = G_22_23 | (P_22_23 & G_20_21);
  assign P_20_23 = P_22_23 & P_20_21;
  assign G_22_25 = G_24_25 | (P_24_25 & G_22_23);
  assign P_22_25 = P_24_25 & P_22_23;
  assign G_24_27 = G_26_27 | (P_26_27 & G_24_25);
  assign P_24_27 = P_26_27 & P_24_25;
  assign G_26_29 = G_28_29 | (P_28_29 & G_26_27);
  assign P_26_29 = P_28_29 & P_26_27;
  assign G_28_31 = G_30_31 | (P_30_31 & G_28_29);
  assign P_28_31 = P_30_31 & P_28_29;
  assign G_30_33 = G_32_33 | (P_32_33 & G_30_31);
  assign P_30_33 = P_32_33 & P_30_31;
  assign G_32_35 = G_34_35 | (P_34_35 & G_32_33);
  assign P_32_35 = P_34_35 & P_32_33;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign P_0_4 = p0[4] & P_0_3;
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  assign P_0_5 = P_2_5 & P_0_1;
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign P_0_7 = P_4_7 & P_0_3;
  assign G_2_9 = G_6_9 | (P_6_9 & G_2_5);
  assign P_2_9 = P_6_9 & P_2_5;
  assign G_4_11 = G_8_11 | (P_8_11 & G_4_7);
  assign P_4_11 = P_8_11 & P_4_7;
  assign G_6_13 = G_10_13 | (P_10_13 & G_6_9);
  assign P_6_13 = P_10_13 & P_6_9;
  assign G_8_15 = G_12_15 | (P_12_15 & G_8_11);
  assign P_8_15 = P_12_15 & P_8_11;
  assign G_10_17 = G_14_17 | (P_14_17 & G_10_13);
  assign P_10_17 = P_14_17 & P_10_13;
  assign G_12_19 = G_16_19 | (P_16_19 & G_12_15);
  assign P_12_19 = P_16_19 & P_12_15;
  assign G_14_21 = G_18_21 | (P_18_21 & G_14_17);
  assign P_14_21 = P_18_21 & P_14_17;
  assign G_16_23 = G_20_23 | (P_20_23 & G_16_19);
  assign P_16_23 = P_20_23 & P_16_19;
  assign G_18_25 = G_22_25 | (P_22_25 & G_18_21);
  assign P_18_25 = P_22_25 & P_18_21;
  assign G_20_27 = G_24_27 | (P_24_27 & G_20_23);
  assign P_20_27 = P_24_27 & P_20_23;
  assign G_22_29 = G_26_29 | (P_26_29 & G_22_25);
  assign P_22_29 = P_26_29 & P_22_25;
  assign G_24_31 = G_28_31 | (P_28_31 & G_24_27);
  assign P_24_31 = P_28_31 & P_24_27;
  assign G_26_33 = G_30_33 | (P_30_33 & G_26_29);
  assign P_26_33 = P_30_33 & P_26_29;
  assign G_28_35 = G_32_35 | (P_32_35 & G_28_31);
  assign P_28_35 = P_32_35 & P_28_31;
  assign G_0_6 = g0[6] | (p0[6] & G_0_5);
  assign P_0_6 = p0[6] & P_0_5;
  assign G_0_8 = g0[8] | (p0[8] & G_0_7);
  assign P_0_8 = p0[8] & P_0_7;
  assign G_0_9 = G_2_9 | (P_2_9 & G_0_1);
  assign P_0_9 = P_2_9 & P_0_1;
  assign G_0_11 = G_4_11 | (P_4_11 & G_0_3);
  assign P_0_11 = P_4_11 & P_0_3;
  assign G_0_13 = G_6_13 | (P_6_13 & G_0_5);
  assign P_0_13 = P_6_13 & P_0_5;
  assign G_0_15 = G_8_15 | (P_8_15 & G_0_7);
  assign P_0_15 = P_8_15 & P_0_7;
  assign G_2_17 = G_10_17 | (P_10_17 & G_2_9);
  assign P_2_17 = P_10_17 & P_2_9;
  assign G_4_19 = G_12_19 | (P_12_19 & G_4_11);
  assign P_4_19 = P_12_19 & P_4_11;
  assign G_6_21 = G_14_21 | (P_14_21 & G_6_13);
  assign P_6_21 = P_14_21 & P_6_13;
  assign G_8_23 = G_16_23 | (P_16_23 & G_8_15);
  assign P_8_23 = P_16_23 & P_8_15;
  assign G_10_25 = G_18_25 | (P_18_25 & G_10_17);
  assign P_10_25 = P_18_25 & P_10_17;
  assign G_12_27 = G_20_27 | (P_20_27 & G_12_19);
  assign P_12_27 = P_20_27 & P_12_19;
  assign G_14_29 = G_22_29 | (P_22_29 & G_14_21);
  assign P_14_29 = P_22_29 & P_14_21;
  assign G_16_31 = G_24_31 | (P_24_31 & G_16_23);
  assign P_16_31 = P_24_31 & P_16_23;
  assign G_18_33 = G_26_33 | (P_26_33 & G_18_25);
  assign P_18_33 = P_26_33 & P_18_25;
  assign G_20_35 = G_28_35 | (P_28_35 & G_20_27);
  assign P_20_35 = P_28_35 & P_20_27;
  assign G_0_10 = g0[10] | (p0[10] & G_0_9);
  assign P_0_10 = p0[10] & P_0_9;
  assign G_0_12 = g0[12] | (p0[12] & G_0_11);
  assign P_0_12 = p0[12] & P_0_11;
  assign G_0_14 = g0[14] | (p0[14] & G_0_13);
  assign P_0_14 = p0[14] & P_0_13;
  assign G_0_16 = g0[16] | (p0[16] & G_0_15);
  assign P_0_16 = p0[16] & P_0_15;
  assign G_0_17 = G_2_17 | (P_2_17 & G_0_1);
  assign P_0_17 = P_2_17 & P_0_1;
  assign G_0_19 = G_4_19 | (P_4_19 & G_0_3);
  assign P_0_19 = P_4_19 & P_0_3;
  assign G_0_21 = G_6_21 | (P_6_21 & G_0_5);
  assign P_0_21 = P_6_21 & P_0_5;
  assign G_0_23 = G_8_23 | (P_8_23 & G_0_7);
  assign P_0_23 = P_8_23 & P_0_7;
  assign G_0_25 = G_10_25 | (P_10_25 & G_0_9);
  assign P_0_25 = P_10_25 & P_0_9;
  assign G_0_27 = G_12_27 | (P_12_27 & G_0_11);
  assign P_0_27 = P_12_27 & P_0_11;
  assign G_0_29 = G_14_29 | (P_14_29 & G_0_13);
  assign P_0_29 = P_14_29 & P_0_13;
  assign G_0_31 = G_16_31 | (P_16_31 & G_0_15);
  assign P_0_31 = P_16_31 & P_0_15;
  assign G_2_33 = G_18_33 | (P_18_33 & G_2_17);
  assign P_2_33 = P_18_33 & P_2_17;
  assign G_4_35 = G_20_35 | (P_20_35 & G_4_19);
  assign P_4_35 = P_20_35 & P_4_19;
  assign G_0_18 = g0[18] | (p0[18] & G_0_17);
  assign P_0_18 = p0[18] & P_0_17;
  assign G_0_20 = g0[20] | (p0[20] & G_0_19);
  assign P_0_20 = p0[20] & P_0_19;
  assign G_0_22 = g0[22] | (p0[22] & G_0_21);
  assign P_0_22 = p0[22] & P_0_21;
  assign G_0_24 = g0[24] | (p0[24] & G_0_23);
  assign P_0_24 = p0[24] & P_0_23;
  assign G_0_26 = g0[26] | (p0[26] & G_0_25);
  assign P_0_26 = p0[26] & P_0_25;
  assign G_0_28 = g0[28] | (p0[28] & G_0_27);
  assign P_0_28 = p0[28] & P_0_27;
  assign G_0_30 = g0[30] | (p0[30] & G_0_29);
  assign P_0_30 = p0[30] & P_0_29;
  assign G_0_32 = g0[32] | (p0[32] & G_0_31);
  assign P_0_32 = p0[32] & P_0_31;
  assign G_0_33 = G_2_33 | (P_2_33 & G_0_3);
  assign P_0_33 = P_2_33 & P_0_3;
  assign G_0_35 = G_4_35 | (P_4_35 & G_0_3);
  assign P_0_35 = P_4_35 & P_0_3;
  assign G_0_34 = g0[34] | (p0[34] & G_0_33);
  assign P_0_34 = p0[34] & P_0_33;
  logic [36:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0] | (p0[0] & cin);
  assign c[2] = G_0_1 | (P_0_1 & cin);
  assign c[3] = G_0_2 | (P_0_2 & cin);
  assign c[4] = G_0_3 | (P_0_3 & cin);
  assign c[5] = G_0_4 | (P_0_4 & cin);
  assign c[6] = G_0_5 | (P_0_5 & cin);
  assign c[7] = G_0_6 | (P_0_6 & cin);
  assign c[8] = G_0_7 | (P_0_7 & cin);
  assign c[9] = G_0_8 | (P_0_8 & cin);
  assign c[10] = G_0_9 | (P_0_9 & cin);
  assign c[11] = G_0_10 | (P_0_10 & cin);
  assign c[12] = G_0_11 | (P_0_11 & cin);
  assign c[13] = G_0_12 | (P_0_12 & cin);
  assign c[14] = G_0_13 | (P_0_13 & cin);
  assign c[15] = G_0_14 | (P_0_14 & cin);
  assign c[16] = G_0_15 | (P_0_15 & cin);
  assign c[17] = G_0_16 | (P_0_16 & cin);
  assign c[18] = G_0_17 | (P_0_17 & cin);
  assign c[19] = G_0_18 | (P_0_18 & cin);
  assign c[20] = G_0_19 | (P_0_19 & cin);
  assign c[21] = G_0_20 | (P_0_20 & cin);
  assign c[22] = G_0_21 | (P_0_21 & cin);
  assign c[23] = G_0_22 | (P_0_22 & cin);
  assign c[24] = G_0_23 | (P_0_23 & cin);
  assign c[25] = G_0_24 | (P_0_24 & cin);
  assign c[26] = G_0_25 | (P_0_25 & cin);
  assign c[27] = G_0_26 | (P_0_26 & cin);
  assign c[28] = G_0_27 | (P_0_27 & cin);
  assign c[29] = G_0_28 | (P_0_28 & cin);
  assign c[30] = G_0_29 | (P_0_29 & cin);
  assign c[31] = G_0_30 | (P_0_30 & cin);
  assign c[32] = G_0_31 | (P_0_31 & cin);
  assign c[33] = G_0_32 | (P_0_32 & cin);
  assign c[34] = G_0_33 | (P_0_33 & cin);
  assign c[35] = G_0_34 | (P_0_34 & cin);
  assign c[36] = G_0_35 | (P_0_35 & cin);
  assign s = pi_ ^ c[35:0];
  assign cout = c[36];
  logic [35:0] f;
  assign f[0] = 1'b1;
  assign f[1] = pi_[0];
  assign f[2] = P_0_1;
  assign f[3] = P_0_2;
  assign f[4] = P_0_3;
  assign f[5] = P_0_4;
  assign f[6] = P_0_5;
  assign f[7] = P_0_6;
  assign f[8] = P_0_7;
  assign f[9] = P_0_8;
  assign f[10] = P_0_9;
  assign f[11] = P_0_10;
  assign f[12] = P_0_11;
  assign f[13] = P_0_12;
  assign f[14] = P_0_13;
  assign f[15] = P_0_14;
  assign f[16] = P_0_15;
  assign f[17] = P_0_16;
  assign f[18] = P_0_17;
  assign f[19] = P_0_18;
  assign f[20] = P_0_19;
  assign f[21] = P_0_20;
  assign f[22] = P_0_21;
  assign f[23] = P_0_22;
  assign f[24] = P_0_23;
  assign f[25] = P_0_24;
  assign f[26] = P_0_25;
  assign f[27] = P_0_26;
  assign f[28] = P_0_27;
  assign f[29] = P_0_28;
  assign f[30] = P_0_29;
  assign f[31] = P_0_30;
  assign f[32] = P_0_31;
  assign f[33] = P_0_32;
  assign f[34] = P_0_33;
  assign f[35] = P_0_34;
  assign s1 = s ^ f;
endmodule





module fam_prefix_net_kogge_stone_w4 (input logic [3:0] g, input logic [3:0] p, input logic cin,
  output logic [3:0] c, output logic cout);
  // prefix graph: {'n': 4, 'levels': 2, 'size': 5, 'fanout': 2, 'tracks': 2, 'exact_split': True, 'valency': 2}
  logic [3:0] g0, p0;
  assign g0 = {g[3:1], g[0] | (p[0] & cin)};
  assign p0 = p;
  logic G_0_1, G_1_2, P_1_2, G_2_3, P_2_3, G_0_2, G_0_3;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign cout = G_0_3;
endmodule






module fam_prefix_net_sklansky_w3 (input logic [2:0] g, input logic [2:0] p, input logic cin,
  output logic [2:0] c, output logic cout);
  // prefix graph: {'n': 3, 'levels': 2, 'size': 2, 'fanout': 1, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [2:0] g0, p0;
  assign g0 = {g[2:1], g[0] | (p[0] & cin)};
  assign p0 = p;
  logic G_0_1, G_0_2;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign cout = G_0_2;
endmodule




module fam_prefix_net_sklansky_w4 (input logic [3:0] g, input logic [3:0] p, input logic cin,
  output logic [3:0] c, output logic cout);
  // prefix graph: {'n': 4, 'levels': 2, 'size': 4, 'fanout': 2, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [3:0] g0, p0;
  assign g0 = {g[3:1], g[0] | (p[0] & cin)};
  assign p0 = p;
  logic G_0_1, G_2_3, P_2_3, G_0_2, G_0_3;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign cout = G_0_3;
endmodule




module fam_prefix_net_sklansky_w8 (input logic [7:0] g, input logic [7:0] p, input logic cin,
  output logic [7:0] c, output logic cout);
  // prefix graph: {'n': 8, 'levels': 3, 'size': 12, 'fanout': 4, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [7:0] g0, p0;
  assign g0 = {g[7:1], g[0] | (p[0] & cin)};
  assign p0 = p;
  logic G_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_0_2, G_0_3, G_4_6, P_4_6, G_4_7, P_4_7, G_0_4, G_0_5, G_0_6, G_0_7;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_4_6 = g0[6] | (p0[6] & G_4_5);
  assign P_4_6 = p0[6] & P_4_5;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign G_0_5 = G_4_5 | (P_4_5 & G_0_3);
  assign G_0_6 = G_4_6 | (P_4_6 & G_0_3);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign cout = G_0_7;
endmodule




module fam_prefix_sklansky_w2_v4 (input logic [1:0] a, input logic [1:0] b, input logic cin,
  output logic [1:0] s, output logic cout);
  // prefix graph: {'n': 2, 'levels': 1, 'size': 1, 'fanout': 1, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [1:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [1:0] g0, p0;
  assign g0 = {gi[1:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  logic [2:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign s = pi_ ^ c[1:0];
  assign cout = c[2];
endmodule



// -------------------------------------------------------------- barrel_mux_tree
// ceil(AW / K) stages of 2^K:1 muxes (RADIX_LOG2 = K; 0 selects one full-width
// stage of W:1 muxes). DIR: 0 mirrored_datapath (a left and a right datapath,
// the result selected by the direction), 1 data_reversal (a right operation is
// a left one on the reversed word), 2 amount_negation (one left rotator; a right
// operation rotates by W - amt, a shift merges the fill through the keep mask).
// ORDER: 0 small_shift_first, 1 large_shift_first. ONE_HOT: the stages' select
// encoding.
module fam_shift_barrel_mux_tree #(parameter int W = 16, parameter int RADIX_LOG2 = 1, parameter int ONE_HOT = 0,
                                   parameter int DIR = 1, parameter int ORDER = 0, parameter int STICKY = 0)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic [2:0] op, output logic [W-1:0] y, output logic sticky);
  localparam int AW = $clog2(W);
  localparam int K = (RADIX_LOG2 == 0 || RADIX_LOG2 > AW) ? AW : RADIX_LOG2;
  localparam int NS = (AW + K - 1) / K;
  wire right = (op == 3'd1) || (op == 3'd2) || (op == 3'd4);
  wire rot = (op == 3'd3) || (op == 3'd4);
  wire arith = (op == 3'd2);
  wire fill = arith & a[W-1];
  logic [W-1:0] mask;
  fam_shift_keep_mask #(.W(W), .STICKY(STICKY)) u_mask (.a(a), .amt(amt), .right(right), .rot(rot), .mask(mask), .sticky(sticky));
  genvar s, i;
  generate
    if (DIR == 1) begin : reversed
      logic [W-1:0] rev_in, x, back;
      for (i = 0; i < W; i = i + 1) begin : rv
        assign rev_in[i] = a[W-1-i];
      end
      assign x = right ? rev_in : a;
      logic [W-1:0] st [0:NS];
      assign st[0] = x;
      for (s = 0; s < NS; s = s + 1) begin : stage
        localparam int G = ORDER ? (NS - 1 - s) : s;          // the digit this stage consumes
        localparam int KB = (G * K + K <= AW) ? K : AW - G * K;
        fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(0), .ONE_HOT(ONE_HOT))
          u (.x(st[s]), .digit(amt[G*K +: KB]), .rot(rot), .fill(fill), .y(st[s+1]));
      end
      for (i = 0; i < W; i = i + 1) begin : rb
        assign back[i] = st[NS][W-1-i];
      end
      assign y = right ? back : st[NS];
    end else if (DIR == 0) begin : mirrored
      logic [W-1:0] lft [0:NS];
      logic [W-1:0] rgt [0:NS];
      assign lft[0] = a;
      assign rgt[0] = a;
      for (s = 0; s < NS; s = s + 1) begin : stage
        localparam int G = ORDER ? (NS - 1 - s) : s;
        localparam int KB = (G * K + K <= AW) ? K : AW - G * K;
        fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(0), .ONE_HOT(ONE_HOT))
          ul (.x(lft[s]), .digit(amt[G*K +: KB]), .rot(rot), .fill(1'b0), .y(lft[s+1]));
        fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(1), .ONE_HOT(ONE_HOT))
          ur (.x(rgt[s]), .digit(amt[G*K +: KB]), .rot(rot), .fill(fill), .y(rgt[s+1]));
      end
      assign y = right ? rgt[NS] : lft[NS];
    end else begin : negated
      // one left rotator; a right operation is a left rotation by W - amt, and a shift takes
      // its fill through the keep mask (zero and overflow flags fall out of the mask)
      logic [AW-1:0] lamt;
      assign lamt = right ? (W - amt) : amt;
      logic [W-1:0] st [0:NS];
      assign st[0] = a;
      for (s = 0; s < NS; s = s + 1) begin : stage
        localparam int G = ORDER ? (NS - 1 - s) : s;
        localparam int KB = (G * K + K <= AW) ? K : AW - G * K;
        fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(0), .ONE_HOT(ONE_HOT))
          u (.x(st[s]), .digit(lamt[G*K +: KB]), .rot(1'b1), .fill(1'b0), .y(st[s+1]));
      end
      assign y = (st[NS] & mask) | ({W{fill}} & ~mask);
    end
  endgenerate
endmodule




// ---------------------------------------------------------------- butterfly_network
// a rotator on a switch network of lg(W) stages of W/2 two-input switches, stage
// l pairing the bits at distance D = 2^l inside every block of 2D, each switch
// under its own control. On the inverse butterfly (NETWORK = 0, small distance
// first) a rotate right by k over a 2D-block whose two halves are already
// rotated by k mod D swaps the pair (i, i+D) at the block-local index i when
// i >= D - (k mod D), and every pair when bit l of k is set (Hilewitz and Lee's
// rotation on the ibfly). The butterfly (NETWORK = 1) is the same stages in the
// reverse order, which composes the inverse permutation, so it takes the controls
// of a rotation by W - k. The shifts merge a mask as the masked family does; a
// left amount is W - amt. The network needs a power-of-two width.
module fam_shift_butterfly_network #(parameter int W = 16, parameter int NETWORK = 0, parameter int STICKY = 0)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic [2:0] op, output logic [W-1:0] y, output logic sticky);
  localparam int AW = $clog2(W);
  wire right = (op == 3'd1) || (op == 3'd2) || (op == 3'd4);
  wire rot = (op == 3'd3) || (op == 3'd4);
  wire arith = (op == 3'd2);
  wire fill = arith & a[W-1];
  logic [AW-1:0] k0, k;                              // the right-rotation amount, and the controls' amount
  assign k0 = right ? amt : (W - amt);
  assign k = NETWORK ? (W - k0) : k0;
  logic [W-1:0] st [0:AW];
  assign st[0] = a;
  genvar s, i;
  generate
    for (s = 0; s < AW; s = s + 1) begin : stage
      localparam int L = NETWORK ? (AW - 1 - s) : s;   // the switch distance of this stage: 2^L
      localparam int D = 1 << L;
      logic [AW-1:0] kmod;                             // k mod D (the low L bits of k)
      if (L == 0) begin : k0_
        assign kmod = '0;
      end else begin : kl
        assign kmod = {{(AW - L){1'b0}}, k[L-1:0]};
      end
      for (i = 0; i < W; i = i + 1) begin : bit_
        localparam int J = i % (2 * D);              // the block-local index
        if (J < D) begin : sw
          // the switch of the pair (i, i+D): crossed when J >= D - (k mod D), inverted by bit L of k
          wire ctrl = ((J >= D - kmod) ^ k[L]);
          assign st[s+1][i] = ctrl ? st[s][i+D] : st[s][i];
          assign st[s+1][i+D] = ctrl ? st[s][i] : st[s][i+D];
        end
      end
    end
  endgenerate
  logic [W-1:0] mask;
  fam_shift_keep_mask #(.W(W), .STICKY(STICKY)) u_mask (.a(a), .amt(amt), .right(right), .rot(rot), .mask(mask), .sticky(sticky));
  assign y = rot ? st[AW] : ((st[AW] & mask) | ({W{fill}} & ~mask));
endmodule





// ----------------------------------------------------------- the keep mask
// mask[i] = 1 where a shift keeps the input bit that lands at i (a rotate keeps
// every bit): the thermometer of the amount for the direction. sticky is the OR
// of the input bits a shift moves out (the low amt bits of a right shift, the
// top amt bits of a left one; none for a rotate), read through the mask of the
// opposite direction, in parallel with the datapath.
module fam_shift_keep_mask #(parameter int W = 16, parameter int STICKY = 1)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic right, input logic rot,
   output logic [W-1:0] mask, output logic sticky);
  logic [W-1:0] kept_in;
  genvar i;
  generate
    for (i = 0; i < W; i = i + 1) begin : mk
      assign mask[i] = rot | (right ? (i < W - amt) : (i >= amt));
      assign kept_in[i] = rot | (right ? (i >= amt) : (i < W - amt));
    end
  endgenerate
  assign sticky = STICKY ? |(a & ~kept_in) : 1'b0;
endmodule




// ------------------------------------------------------------------ masked_merged
// a left rotator (the `rotator` slot's barrel: R_RADIX_LOG2, R_ONE_HOT, R_ORDER)
// plus a mask that turns the rotation into a shift by merging in the fill bits.
// MASKGEN: 0 thermometer_decode (one thermometer per direction, selected), 1
// two_thermometer_and (a low and a high bound thermometer ANDed), 2 lut (a table
// over the direction and the amount). MERGE: 0 and_or_merge, 1 per_bit_mux.
module fam_shift_masked_merged #(parameter int W = 16, parameter int MASKGEN = 0, parameter int MERGE = 0,
                                 parameter int R_RADIX_LOG2 = 1, parameter int R_ONE_HOT = 0, parameter int R_ORDER = 0, parameter int STICKY = 0)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic [2:0] op, output logic [W-1:0] y, output logic sticky);
  localparam int AW = $clog2(W);
  localparam int K = (R_RADIX_LOG2 == 0 || R_RADIX_LOG2 > AW) ? AW : R_RADIX_LOG2;
  localparam int NS = (AW + K - 1) / K;
  wire right = (op == 3'd1) || (op == 3'd2) || (op == 3'd4);
  wire rot = (op == 3'd3) || (op == 3'd4);
  wire arith = (op == 3'd2);
  wire fill = arith & a[W-1];
  // rotate left by amt (a right operation by k is a left rotation by W - k)
  logic [AW-1:0] lamt;
  assign lamt = right ? (W - amt) : amt;
  logic [W-1:0] st [0:NS];
  assign st[0] = a;
  genvar s, i;
  logic [W-1:0] mask;                 // 1 where the rotated bit is kept
  generate
    for (s = 0; s < NS; s = s + 1) begin : stage
      localparam int G = R_ORDER ? (NS - 1 - s) : s;
      localparam int KB = (G * K + K <= AW) ? K : AW - G * K;
      fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(0), .ONE_HOT(R_ONE_HOT))
        u (.x(st[s]), .digit(lamt[G*K +: KB]), .rot(1'b1), .fill(1'b0), .y(st[s+1]));
    end
    if (MASKGEN == 0) begin : thermo
      for (i = 0; i < W; i = i + 1) begin : mk
        assign mask[i] = right ? (i < W - amt) : (i >= amt);
      end
    end else if (MASKGEN == 1) begin : two_thermo
      // the field kept lies between a low and a high bound: [amt, W-1] for a left shift,
      // [0, W-1-amt] for a right one; each bound is a thermometer, the mask their AND. The
      // high bound is signed: a right amount at or past W (an amount code W leaves the whole
      // word when W is below a power of two) puts it below zero, and no bit is kept
      logic [AW:0] lo;
      logic signed [AW+1:0] hi;
      assign lo = right ? {(AW+1){1'b0}} : {1'b0, amt};
      assign hi = right ? ($signed(W - 1) - $signed({2'b00, amt})) : $signed(W - 1);
      logic [W-1:0] ge_lo, le_hi;
      for (i = 0; i < W; i = i + 1) begin : mk
        assign ge_lo[i] = (i >= lo);
        assign le_hi[i] = (hi >= 0) && (i <= hi);
      end
      assign mask = ge_lo & le_hi;
    end else begin : lut
      // the mask read from a table over the direction and the amount
      logic [AW:0] idx;
      assign idx = {right, amt};
      logic [W-1:0] tab [0:2*(1<<AW)-1];
      for (i = 0; i < 2 * (1 << AW); i = i + 1) begin : t
        localparam int RT = i >> AW;
        localparam int AM = i & ((1 << AW) - 1);
        genvar j;
        for (j = 0; j < W; j = j + 1) begin : bt
          assign tab[i][j] = RT ? (j < W - AM) : (j >= AM);
        end
      end
      assign mask = tab[idx];
    end
  endgenerate
  logic [W-1:0] mask_unused;
  fam_shift_keep_mask #(.W(W), .STICKY(STICKY)) u_sticky (.a(a), .amt(amt), .right(right), .rot(rot), .mask(mask_unused), .sticky(sticky));
  generate
    if (MERGE == 0) begin : and_or
      assign y = rot ? st[NS] : ((st[NS] & mask) | ({W{fill}} & ~mask));
    end else begin : per_bit
      for (i = 0; i < W; i = i + 1) begin : mx
        assign y[i] = (rot | mask[i]) ? st[NS][i] : fill;
      end
    end
  endgenerate
endmodule

// The shifter families of chiALU. One interface:
//   #(parameter int W) (input [W-1:0] a, input [AW-1:0] amt, input [2:0] op, output [W-1:0] y)
// op: 0 shl, 1 shr_logical, 2 shr_arith, 3 rol, 4 ror; amt is below W.
// Every family has `output sticky`, the OR of the bits a shift moves out (0 for a rotate), built
// when STICKY = 1 (the sticky_collect choice; an alignment shifter asks for it) and tied to 0
// otherwise; a consumer that does not collect it leaves the port unconnected.

// ------------------------------------------------------------------ one mux stage
// One stage of a shifter: the K-bit digit of the amount selects among R = 2^K
// candidates, candidate d being the input displaced by d * 2^SH to the left
// (RIGHT = 0) or to the right (RIGHT = 1), the vacated bits taken from the
// other end under `rot` or from `fill`. ONE_HOT = 1 decodes the digit to R
// select lines and forms the mux as an AND-OR (the select_encoding choice);
// ONE_HOT = 0 indexes the candidates by the binary digit.
module fam_shift_stage #(parameter int W = 16, parameter int K = 1, parameter int SH = 0,
                         parameter int RIGHT = 0, parameter int ONE_HOT = 0)
  (input logic [W-1:0] x, input logic [K-1:0] digit, input logic rot, input logic fill, output logic [W-1:0] y);
  localparam int R = 1 << K;
  localparam int D = 1 << SH;
  logic [W*R-1:0] cand;                       // candidate d at [d*W +: W]
  genvar d, i;
  generate
    for (d = 0; d < R; d = d + 1) begin : c
      for (i = 0; i < W; i = i + 1) begin : b
        localparam int S = d * D;             // the displacement of this candidate
        if (S >= W) begin : far
          // a displacement past the word: a rotate wraps it (mod W), a shift clears the word
          localparam int IDX = ((RIGHT ? (i + S) : (i - S)) % W + W) % W;
          assign cand[d*W + i] = rot ? x[IDX] : fill;
        end else if (RIGHT) begin : r
          if (i + S < W) begin : in_
            assign cand[d*W + i] = x[i + S];
          end else begin : out_
            assign cand[d*W + i] = rot ? x[i + S - W] : fill;
          end
        end else begin : l
          if (i >= S) begin : in_
            assign cand[d*W + i] = x[i - S];
          end else begin : out_
            assign cand[d*W + i] = rot ? x[W - S + i] : fill;
          end
        end
      end
    end
    if (ONE_HOT) begin : onehot
      logic [R-1:0] sel;
      for (d = 0; d < R; d = d + 1) begin : dec
        assign sel[d] = (digit == d);
      end
      for (i = 0; i < W; i = i + 1) begin : orb
        logic [R-1:0] t;
        for (d = 0; d < R; d = d + 1) begin : and_
          assign t[d] = sel[d] & cand[d*W + i];
        end
        assign y[i] = |t;
      end
    end else begin : binary
      assign y = cand[digit*W +: W];
    end
  endgenerate
endmodule
