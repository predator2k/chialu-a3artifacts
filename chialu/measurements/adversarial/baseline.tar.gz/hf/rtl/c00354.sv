// ADIR-MEMBER packages
// alu_core_m0_pkg: the exact-arithmetic functions of mode 0 (1xfp16)
package alu_core_m0_pkg;

  // ---- m0: V = {special[1:0], sign, exp[13] (signed), sig[11]}
  //           X = {special[1:0], sign, exp[13] (signed), sig[26], sticky}
  localparam int m0_SW = 11, m0_EW = 13, m0_XW = 26;
  localparam int m0_VW = 27, m0_XT = 43;
  function automatic [26:0] m0_mkv(input [1:0] sp, input s, input signed [12:0] e, input [10:0] sig);
    m0_mkv = {sp, s, e, sig};
  endfunction
  function automatic [42:0] m0_mkx(input [1:0] sp, input s, input signed [12:0] e, input [25:0] sig, input st);
    m0_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [42:0] m0_x(input [26:0] v);   // widen V to X
    m0_x = {v[26:26-1], v[26-2], v[26-3 -: 13], {{(26-11){1'b0}}, v[10:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [42:0] m0_norm(input [42:0] x);
    logic [25:0] s; logic signed [12:0] e; integer k;
    s = x[26:1]; e = x[26+13:26+1];
    if (s != 0) begin
      for (k = 16; k >= 1; k = k / 2) begin
        if (k < 26) begin
          if (s[25 -: 1] == 1'b0 && (s >> (26 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m0_norm = {x[42:42-1], x[42-2], e, s, x[0]};
  endfunction

  function automatic m0_rup(input [2:0] rnd, input s, input inexact, input [26:0] rest, input [26:0] halfv,
                             input st, input lsb, input [26+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m0_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m0_rup = 1'b0;
      3'd2: m0_rup = inexact && s;
      3'd3: m0_rup = inexact && !s;
      3'd4: m0_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m0_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [42:0] m0_add(input [42:0] a, input [42:0] b, input sub);
    logic [42:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [12:0] ea, eb, d; logic [26:0] ms, mb, r; logic st, stb; integer sh;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[42:42-1]; spb = nb[42:42-1];
    sa = na[42-2]; sb = nb[42-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m0_add = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m0_add = (sa == sb) ? m0_mkx(2'd2, sa, 0, 0, 1'b0) : m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_add = m0_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m0_add = m0_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[26:1] == 0 && !na[0]) m0_add = {nb[42:42-1], sb, nb[42-3:0]};
    else if (nb[26:1] == 0 && !nb[0]) m0_add = na;
    else begin
      ea = na[26+13:26+1]; eb = nb[26+13:26+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[26:1] >= nb[26:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[26+13:26+1] - sml[26+13:26+1];
      ms = {1'b0, sml[26:1]}; stb = sml[0];
      if (d > 26 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 26 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[26:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[26]) begin st = st | r[0]; r = r >> 1; m0_add = m0_mkx(2'd0, sr, big[26+13:26+1] + 1, r[25:0], st); end
      else m0_add = m0_mkx(2'd0, sr, big[26+13:26+1], r[25:0], st);
    end
  endfunction
  function automatic [42:0] m0_mul(input [42:0] a, input [42:0] b);
    logic [42:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*26-1:0] pr; logic st; integer k;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[42:42-1]; spb = nb[42:42-1]; s = na[42-2] ^ nb[42-2];
    if (spa == 2'd1 || spb == 2'd1) m0_mul = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[26:1] == 0 && !na[0]) || (spb == 2'd0 && nb[26:1] == 0 && !nb[0]))
        m0_mul = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m0_mul = m0_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[26:1] * nb[26:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[25:0] != 0);
      m0_mul = m0_mkx(2'd0, s, na[26+13:26+1] + nb[26+13:26+1] + 26, pr[2*26-1:26], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*26+1:0] m0_udiv(input [25:0] a, input [25:0] dv);
    logic [26+1:0] r; logic [26:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 26; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[25:0], ge};
      if (i > 0) r = {r[26:0], 1'b0};
    end
    m0_udiv = {q, r[26:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*26+13+2:0] m0_mulx(input [42:0] a, input [42:0] b);
    logic [42:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*26-1:0] pr;
    na = m0_norm(a); nb = m0_norm(b);
    pr = na[26:1] * nb[26:1];
    spa = na[42:42-1]; spb = nb[42:42-1]; s = na[42-2] ^ nb[42-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[26:1] == 0) || (spb == 2'd0 && nb[26:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m0_mulx = {sp, s, na[26+13:26+1] + nb[26+13:26+1], pr};
  endfunction
  function automatic [42:0] m0_div(input [42:0] a, input [42:0] b);
    logic [42:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*26+1:0] qr; logic [26:0] q, r;
    na = m0_norm(a); nb = m0_norm(b);
    spa = na[42:42-1]; spb = nb[42:42-1]; s = na[42-2] ^ nb[42-2];
    if (spa == 2'd1 || spb == 2'd1) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_div = m0_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m0_div = m0_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[26:1] == 0 && !nb[0]) begin
      if (na[26:1] == 0 && !na[0]) m0_div = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m0_div = m0_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[26:1] == 0 && !na[0]) m0_div = m0_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m0_udiv(na[26:1], nb[26:1]);     // both normalized: nonzero finite
      q = qr[2*26+1:26+1]; r = qr[26:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[26]) m0_div = m0_mkx(2'd0, s, na[26+13:26+1] - nb[26+13:26+1] - 26 + 1, q[26:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m0_div = m0_mkx(2'd0, s, na[26+13:26+1] - nb[26+13:26+1] - 26, q[25:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [42:0] m0_sqrt(input [42:0] a);
    logic [42:0] na; logic [1:0] spa; logic signed [12:0] e; logic [26:0] m; logic [2*26+3:0] rad;
    logic [26+2:0] rem, trial; logic [26:0] root; logic ge; integer i;
    na = m0_norm(a); spa = na[42:42-1];
    if (spa == 2'd1) m0_sqrt = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m0_sqrt = na[42-2] ? m0_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[26:1] == 0 && !na[0]) m0_sqrt = na;
    else if (na[42-2]) m0_sqrt = m0_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[26+13:26+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[26:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[26:1]};
      rad = {{(26+3){1'b0}}, m} << 26;
      rem = 0; root = 0;
      for (i = 26; i >= 0; i = i - 1) begin
        rem = {rem[26:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[25:0], ge};
      end
      m0_sqrt = m0_mkx(2'd0, 1'b0, (e >>> 1) - 13 + 1, root[26:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m0_lt(input [42:0] a, input [42:0] b);
    logic [42:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [12:0] ea, eb;
    na = m0_norm(a); nb = m0_norm(b);
    za = (na[26:1] == 0) && !na[0]; zb = (nb[26:1] == 0) && !nb[0];
    sa = na[42-2] && !za; sb = nb[42-2] && !zb;
    if (na[42:42-1] == 2'd1 || nb[42:42-1] == 2'd1) m0_lt = 1'b0;
    else if (na[42:42-1] == 2'd2 || nb[42:42-1] == 2'd2) begin
      if (na[42:42-1] == 2'd2 && nb[42:42-1] == 2'd2) m0_lt = na[42-2] && !nb[42-2];
      else if (na[42:42-1] == 2'd2) m0_lt = na[42-2];
      else m0_lt = !nb[42-2];
    end else if (za && zb) m0_lt = 1'b0;
    else if (sa != sb) m0_lt = sa;
    else begin
      ea = na[26+13:26+1]; eb = nb[26+13:26+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[26:1] < nb[26:1] || (na[26:1] == nb[26:1] && !na[0] && nb[0])));
      m0_lt = sa ? !mag_lt && !(za && zb) && !m0_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m0_eq(input [42:0] a, input [42:0] b);
    logic [42:0] na, nb; logic za, zb;
    na = m0_norm(a); nb = m0_norm(b);
    za = (na[26:1] == 0) && !na[0]; zb = (nb[26:1] == 0) && !nb[0];
    if (na[42:42-1] == 2'd1 || nb[42:42-1] == 2'd1) m0_eq = 1'b0;
    else if (na[42:42-1] == 2'd2 || nb[42:42-1] == 2'd2)
      m0_eq = (na[42:42-1] == nb[42:42-1]) && (na[42-2] == nb[42-2]);
    else if (za || zb) m0_eq = za && zb;
    else m0_eq = (na[42-2] == nb[42-2]) && (na[26+13:26+1] == nb[26+13:26+1]) && (na[26:1] == nb[26:1]) && (na[0] == nb[0]);
  endfunction

  // fp16 pattern -> V (bit VW = denormal-read flag returned beside)
  function automatic [27:0] m0_unpack_s(input [15:0] b, input daz);
    logic [4:0] e; logic [9:0] m; logic [10:0] sig; logic signed [12:0] ex; logic den, s;
    e = b[14:10]; m = b[9:0]; s = b[15]; den = 1'b0; sig = 0; ex = 0;
    if ((e == 5'd31 && m != 0)) m0_unpack_s = {1'b0, m0_mkv(2'd1, 1'b0, 0, 0)};
    else if ((e == 5'd31 && m == 0)) m0_unpack_s = {1'b0, m0_mkv(2'd2, s, 0, 0)};
    else begin
    if (e == 0) begin sig = {{(11-10){1'b0}}, m}; ex = -24; if (m != 0) den = 1'b1; if (daz && m != 0) sig = 0; end
    else begin sig = {{(11-10-1){1'b0}}, 1'b1, m}; ex = e - 25; end
      m0_unpack_s = {den, m0_mkv(2'd0, s, ex, sig)};
    end
  endfunction

  // X -> fp16 (fp16): sign(1) exp 5 man 10, top field 30, max finite 15'd31743
  function automatic [10+16-1:0] m0_pack_fp16(input [42:0] x0, input [2:0] rnd, input [7:0] word, input ftz);
    logic [42:0] x; logic [1:0] sp; logic s; logic signed [12:0] e, eu, biased; logic [25:0] sig;
    logic st, inexact, up, upn, half_eq, gt_half, tiny, ovf, unf, carry_n, to_inf; integer sh, shn, sht;
    logic [26:0] keep, rest, keepn, restn, halfv, halfn; logic [26+8:0] fint, fintn; logic [10-1:0] fl;
    logic [16+13:0] code; logic [16:0] mag; logic [16-1:0] outb;
    x = m0_norm(x0); sp = x[42:42-1]; s = x[42-2] & 1; sig = x[26:1]; st = x[0]; e = x[26+13:26+1];
    fl = 0; outb = 0;
    if (sp == 2'd1) begin fl[5] = 1'b1; outb = 16'd32256; end
    else if (sp == 2'd2) begin
      outb = {s, 15'd31744}; if (!1) begin fl[4] = 1'b1; fl[2] = 1'b1; end
    end else if (sig == 0 && !st) begin outb = 1 ? 0 : {s, {15{1'b0}}}; end
    else begin
      if (sig == 0) begin sig = 1 << 25; e = e - (2*26-1); end // normalize the lone sticky's tiny value
      eu = e + 25;                 // exponent of the leading one
      biased = eu + 15;
      shn = 26 - 1 - 10;           // bits dropped at the normal precision
      sh = (biased >= 1) ? shn : shn + (1 - biased);
      sht = sh;
      if (sh > 26 + 1) sh = 26 + 1;
      keep = {1'b0, sig} >> sh; rest = {1'b0, sig} & ((sh > 26) ? {(26+1){1'b1}} : ({1'b0, {26{1'b1}}} >> (26 - sh)));
      halfv = (sh == 0) ? 0 : ({{26{1'b0}}, 1'b1} << (sh - 1));
      keepn = {1'b0, sig} >> shn; restn = {1'b0, sig} & ({1'b0, {26{1'b1}}} >> (26 - shn));
      halfn = (shn == 0) ? 0 : ({{26{1'b0}}, 1'b1} << (shn - 1));
      inexact = (rest != 0) | st;
      fint = (sht - 8 > 26) ? 0 : (sht >= 8) ? (rest >> (sht - 8)) : (rest << (8 - sht));
      fintn = (shn >= 8) ? (restn >> (shn - 8)) : (restn << (8 - shn));
      up = m0_rup(rnd, s, inexact, rest, halfv, st, keep[0], fint, word);
      upn = m0_rup(rnd, s, (restn != 0) | st, restn, halfn, st, keepn[0], fintn, word);
      carry_n = ((keepn + upn) == ({{26{1'b0}}, 1'b1} << (10 + 1)));
      mag = keep + up;
      if (biased < 1) biased = 0;
      code = (biased < 1) ? mag : ((biased << 10) + mag - ({{(16+13){1'b0}}, 1'b1} << 10));
      tiny = 0 ? (eu < -14) : ((eu < -14) && !(eu == -14 - 1 && carry_n) && !(eu + 15 == 0 && carry_n));
      ovf = (code > 15'd31743);
      if (ovf) begin
        to_inf = 1 && (rnd == 3'd0 || (rnd == 3'd3 && !s) || (rnd == 3'd2 && s) || rnd == 3'd5 || (rnd == 3'd4 && (eu > 15 || up)));
        outb = to_inf ? {s, 15'd31744} : {s, 15'd31743};
        fl[2] = 1'b1; fl[4] = 1'b1;
      end else begin
        outb = {s, code[14:0]};
        if (inexact) fl[4] = 1'b1;
        if (tiny && inexact) fl[3] = 1'b1;
        if (ftz && code[15-1:10] == 0 && code[9:0] != 0) begin
          outb = {s, {15{1'b0}}}; fl[4] = 1'b1; fl[3] = 1'b1;
        end

      end
    end
    m0_pack_fp16 = {fl, outb};
  endfunction
endpackage

// alu_core_m1_pkg: the exact-arithmetic functions of mode 1 (1xbf16)
package alu_core_m1_pkg;

  // ---- m1: V = {special[1:0], sign, exp[16] (signed), sig[8]}
  //           X = {special[1:0], sign, exp[16] (signed), sig[20], sticky}
  localparam int m1_SW = 8, m1_EW = 16, m1_XW = 20;
  localparam int m1_VW = 27, m1_XT = 40;
  function automatic [26:0] m1_mkv(input [1:0] sp, input s, input signed [15:0] e, input [7:0] sig);
    m1_mkv = {sp, s, e, sig};
  endfunction
  function automatic [39:0] m1_mkx(input [1:0] sp, input s, input signed [15:0] e, input [19:0] sig, input st);
    m1_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [39:0] m1_x(input [26:0] v);   // widen V to X
    m1_x = {v[26:26-1], v[26-2], v[26-3 -: 16], {{(20-8){1'b0}}, v[7:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [39:0] m1_norm(input [39:0] x);
    logic [19:0] s; logic signed [15:0] e; integer k;
    s = x[20:1]; e = x[20+16:20+1];
    if (s != 0) begin
      for (k = 16; k >= 1; k = k / 2) begin
        if (k < 20) begin
          if (s[19 -: 1] == 1'b0 && (s >> (20 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m1_norm = {x[39:39-1], x[39-2], e, s, x[0]};
  endfunction

  function automatic m1_rup(input [2:0] rnd, input s, input inexact, input [20:0] rest, input [20:0] halfv,
                             input st, input lsb, input [20+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m1_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m1_rup = 1'b0;
      3'd2: m1_rup = inexact && s;
      3'd3: m1_rup = inexact && !s;
      3'd4: m1_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m1_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [39:0] m1_add(input [39:0] a, input [39:0] b, input sub);
    logic [39:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [15:0] ea, eb, d; logic [20:0] ms, mb, r; logic st, stb; integer sh;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[39:39-1]; spb = nb[39:39-1];
    sa = na[39-2]; sb = nb[39-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m1_add = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m1_add = (sa == sb) ? m1_mkx(2'd2, sa, 0, 0, 1'b0) : m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_add = m1_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m1_add = m1_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[20:1] == 0 && !na[0]) m1_add = {nb[39:39-1], sb, nb[39-3:0]};
    else if (nb[20:1] == 0 && !nb[0]) m1_add = na;
    else begin
      ea = na[20+16:20+1]; eb = nb[20+16:20+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[20:1] >= nb[20:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[20+16:20+1] - sml[20+16:20+1];
      ms = {1'b0, sml[20:1]}; stb = sml[0];
      if (d > 20 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 20 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[20:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[20]) begin st = st | r[0]; r = r >> 1; m1_add = m1_mkx(2'd0, sr, big[20+16:20+1] + 1, r[19:0], st); end
      else m1_add = m1_mkx(2'd0, sr, big[20+16:20+1], r[19:0], st);
    end
  endfunction
  function automatic [39:0] m1_mul(input [39:0] a, input [39:0] b);
    logic [39:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*20-1:0] pr; logic st; integer k;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[39:39-1]; spb = nb[39:39-1]; s = na[39-2] ^ nb[39-2];
    if (spa == 2'd1 || spb == 2'd1) m1_mul = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[20:1] == 0 && !na[0]) || (spb == 2'd0 && nb[20:1] == 0 && !nb[0]))
        m1_mul = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m1_mul = m1_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[20:1] * nb[20:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[19:0] != 0);
      m1_mul = m1_mkx(2'd0, s, na[20+16:20+1] + nb[20+16:20+1] + 20, pr[2*20-1:20], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*20+1:0] m1_udiv(input [19:0] a, input [19:0] dv);
    logic [20+1:0] r; logic [20:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 20; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[19:0], ge};
      if (i > 0) r = {r[20:0], 1'b0};
    end
    m1_udiv = {q, r[20:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*20+16+2:0] m1_mulx(input [39:0] a, input [39:0] b);
    logic [39:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*20-1:0] pr;
    na = m1_norm(a); nb = m1_norm(b);
    pr = na[20:1] * nb[20:1];
    spa = na[39:39-1]; spb = nb[39:39-1]; s = na[39-2] ^ nb[39-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[20:1] == 0) || (spb == 2'd0 && nb[20:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m1_mulx = {sp, s, na[20+16:20+1] + nb[20+16:20+1], pr};
  endfunction
  function automatic [39:0] m1_div(input [39:0] a, input [39:0] b);
    logic [39:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*20+1:0] qr; logic [20:0] q, r;
    na = m1_norm(a); nb = m1_norm(b);
    spa = na[39:39-1]; spb = nb[39:39-1]; s = na[39-2] ^ nb[39-2];
    if (spa == 2'd1 || spb == 2'd1) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_div = m1_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m1_div = m1_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[20:1] == 0 && !nb[0]) begin
      if (na[20:1] == 0 && !na[0]) m1_div = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m1_div = m1_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[20:1] == 0 && !na[0]) m1_div = m1_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m1_udiv(na[20:1], nb[20:1]);     // both normalized: nonzero finite
      q = qr[2*20+1:20+1]; r = qr[20:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[20]) m1_div = m1_mkx(2'd0, s, na[20+16:20+1] - nb[20+16:20+1] - 20 + 1, q[20:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m1_div = m1_mkx(2'd0, s, na[20+16:20+1] - nb[20+16:20+1] - 20, q[19:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [39:0] m1_sqrt(input [39:0] a);
    logic [39:0] na; logic [1:0] spa; logic signed [15:0] e; logic [20:0] m; logic [2*20+3:0] rad;
    logic [20+2:0] rem, trial; logic [20:0] root; logic ge; integer i;
    na = m1_norm(a); spa = na[39:39-1];
    if (spa == 2'd1) m1_sqrt = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m1_sqrt = na[39-2] ? m1_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[20:1] == 0 && !na[0]) m1_sqrt = na;
    else if (na[39-2]) m1_sqrt = m1_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[20+16:20+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[20:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[20:1]};
      rad = {{(20+3){1'b0}}, m} << 20;
      rem = 0; root = 0;
      for (i = 20; i >= 0; i = i - 1) begin
        rem = {rem[20:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[19:0], ge};
      end
      m1_sqrt = m1_mkx(2'd0, 1'b0, (e >>> 1) - 10 + 1, root[20:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m1_lt(input [39:0] a, input [39:0] b);
    logic [39:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [15:0] ea, eb;
    na = m1_norm(a); nb = m1_norm(b);
    za = (na[20:1] == 0) && !na[0]; zb = (nb[20:1] == 0) && !nb[0];
    sa = na[39-2] && !za; sb = nb[39-2] && !zb;
    if (na[39:39-1] == 2'd1 || nb[39:39-1] == 2'd1) m1_lt = 1'b0;
    else if (na[39:39-1] == 2'd2 || nb[39:39-1] == 2'd2) begin
      if (na[39:39-1] == 2'd2 && nb[39:39-1] == 2'd2) m1_lt = na[39-2] && !nb[39-2];
      else if (na[39:39-1] == 2'd2) m1_lt = na[39-2];
      else m1_lt = !nb[39-2];
    end else if (za && zb) m1_lt = 1'b0;
    else if (sa != sb) m1_lt = sa;
    else begin
      ea = na[20+16:20+1]; eb = nb[20+16:20+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[20:1] < nb[20:1] || (na[20:1] == nb[20:1] && !na[0] && nb[0])));
      m1_lt = sa ? !mag_lt && !(za && zb) && !m1_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m1_eq(input [39:0] a, input [39:0] b);
    logic [39:0] na, nb; logic za, zb;
    na = m1_norm(a); nb = m1_norm(b);
    za = (na[20:1] == 0) && !na[0]; zb = (nb[20:1] == 0) && !nb[0];
    if (na[39:39-1] == 2'd1 || nb[39:39-1] == 2'd1) m1_eq = 1'b0;
    else if (na[39:39-1] == 2'd2 || nb[39:39-1] == 2'd2)
      m1_eq = (na[39:39-1] == nb[39:39-1]) && (na[39-2] == nb[39-2]);
    else if (za || zb) m1_eq = za && zb;
    else m1_eq = (na[39-2] == nb[39-2]) && (na[20+16:20+1] == nb[20+16:20+1]) && (na[20:1] == nb[20:1]) && (na[0] == nb[0]);
  endfunction

  // bf16 pattern -> V (bit VW = denormal-read flag returned beside)
  function automatic [27:0] m1_unpack_s(input [15:0] b, input daz);
    logic [7:0] e; logic [6:0] m; logic [7:0] sig; logic signed [15:0] ex; logic den, s;
    e = b[14:7]; m = b[6:0]; s = b[15]; den = 1'b0; sig = 0; ex = 0;
    if ((e == 8'd255 && m != 0)) m1_unpack_s = {1'b0, m1_mkv(2'd1, 1'b0, 0, 0)};
    else if ((e == 8'd255 && m == 0)) m1_unpack_s = {1'b0, m1_mkv(2'd2, s, 0, 0)};
    else begin
    if (e == 0) begin sig = {{(8-7){1'b0}}, m}; ex = -133; if (m != 0) den = 1'b1; if (daz && m != 0) sig = 0; end
    else begin sig = {{(8-7-1){1'b0}}, 1'b1, m}; ex = e - 134; end
      m1_unpack_s = {den, m1_mkv(2'd0, s, ex, sig)};
    end
  endfunction

  // X -> bf16 (bf16): sign(1) exp 8 man 7, top field 254, max finite 15'd32639
  function automatic [10+16-1:0] m1_pack_bf16(input [39:0] x0, input [2:0] rnd, input [7:0] word, input ftz);
    logic [39:0] x; logic [1:0] sp; logic s; logic signed [15:0] e, eu, biased; logic [19:0] sig;
    logic st, inexact, up, upn, half_eq, gt_half, tiny, ovf, unf, carry_n, to_inf; integer sh, shn, sht;
    logic [20:0] keep, rest, keepn, restn, halfv, halfn; logic [20+8:0] fint, fintn; logic [10-1:0] fl;
    logic [16+16:0] code; logic [16:0] mag; logic [16-1:0] outb;
    x = m1_norm(x0); sp = x[39:39-1]; s = x[39-2] & 1; sig = x[20:1]; st = x[0]; e = x[20+16:20+1];
    fl = 0; outb = 0;
    if (sp == 2'd1) begin fl[5] = 1'b1; outb = 16'd32704; end
    else if (sp == 2'd2) begin
      outb = {s, 15'd32640}; if (!1) begin fl[4] = 1'b1; fl[2] = 1'b1; end
    end else if (sig == 0 && !st) begin outb = 1 ? 0 : {s, {15{1'b0}}}; end
    else begin
      if (sig == 0) begin sig = 1 << 19; e = e - (2*20-1); end // normalize the lone sticky's tiny value
      eu = e + 19;                 // exponent of the leading one
      biased = eu + 127;
      shn = 20 - 1 - 7;           // bits dropped at the normal precision
      sh = (biased >= 1) ? shn : shn + (1 - biased);
      sht = sh;
      if (sh > 20 + 1) sh = 20 + 1;
      keep = {1'b0, sig} >> sh; rest = {1'b0, sig} & ((sh > 20) ? {(20+1){1'b1}} : ({1'b0, {20{1'b1}}} >> (20 - sh)));
      halfv = (sh == 0) ? 0 : ({{20{1'b0}}, 1'b1} << (sh - 1));
      keepn = {1'b0, sig} >> shn; restn = {1'b0, sig} & ({1'b0, {20{1'b1}}} >> (20 - shn));
      halfn = (shn == 0) ? 0 : ({{20{1'b0}}, 1'b1} << (shn - 1));
      inexact = (rest != 0) | st;
      fint = (sht - 8 > 20) ? 0 : (sht >= 8) ? (rest >> (sht - 8)) : (rest << (8 - sht));
      fintn = (shn >= 8) ? (restn >> (shn - 8)) : (restn << (8 - shn));
      up = m1_rup(rnd, s, inexact, rest, halfv, st, keep[0], fint, word);
      upn = m1_rup(rnd, s, (restn != 0) | st, restn, halfn, st, keepn[0], fintn, word);
      carry_n = ((keepn + upn) == ({{20{1'b0}}, 1'b1} << (7 + 1)));
      mag = keep + up;
      if (biased < 1) biased = 0;
      code = (biased < 1) ? mag : ((biased << 7) + mag - ({{(16+16){1'b0}}, 1'b1} << 7));
      tiny = 0 ? (eu < -126) : ((eu < -126) && !(eu == -126 - 1 && carry_n) && !(eu + 127 == 0 && carry_n));
      ovf = (code > 15'd32639);
      if (ovf) begin
        to_inf = 1 && (rnd == 3'd0 || (rnd == 3'd3 && !s) || (rnd == 3'd2 && s) || rnd == 3'd5 || (rnd == 3'd4 && (eu > 127 || up)));
        outb = to_inf ? {s, 15'd32640} : {s, 15'd32639};
        fl[2] = 1'b1; fl[4] = 1'b1;
      end else begin
        outb = {s, code[14:0]};
        if (inexact) fl[4] = 1'b1;
        if (tiny && inexact) fl[3] = 1'b1;
        if (ftz && code[15-1:7] == 0 && code[6:0] != 0) begin
          outb = {s, {15{1'b0}}}; fl[4] = 1'b1; fl[3] = 1'b1;
        end

      end
    end
    m1_pack_bf16 = {fl, outb};
  endfunction
endpackage

// alu_core_m2_pkg: the exact-arithmetic functions of mode 2 (2xfp8e5m2)
package alu_core_m2_pkg;

  // ---- m2: V = {special[1:0], sign, exp[13] (signed), sig[3]}
  //           X = {special[1:0], sign, exp[13] (signed), sig[10], sticky}
  localparam int m2_SW = 3, m2_EW = 13, m2_XW = 10;
  localparam int m2_VW = 19, m2_XT = 27;
  function automatic [18:0] m2_mkv(input [1:0] sp, input s, input signed [12:0] e, input [2:0] sig);
    m2_mkv = {sp, s, e, sig};
  endfunction
  function automatic [26:0] m2_mkx(input [1:0] sp, input s, input signed [12:0] e, input [9:0] sig, input st);
    m2_mkx = {sp, s, e, sig, st};
  endfunction
  function automatic [26:0] m2_x(input [18:0] v);   // widen V to X
    m2_x = {v[18:18-1], v[18-2], v[18-3 -: 13], {{(10-3){1'b0}}, v[2:0]}, 1'b0};
  endfunction
  // normalize: leading one at bit XW-1 (zero stays zero)
  function automatic [26:0] m2_norm(input [26:0] x);
    logic [9:0] s; logic signed [12:0] e; integer k;
    s = x[10:1]; e = x[10+13:10+1];
    if (s != 0) begin
      for (k = 8; k >= 1; k = k / 2) begin
        if (k < 10) begin
          if (s[9 -: 1] == 1'b0 && (s >> (10 - k)) == 0) begin
            s = s << k; e = e - k;
          end
        end
      end
    end
    m2_norm = {x[26:26-1], x[26-2], e, s, x[0]};
  endfunction

  function automatic m2_rup(input [2:0] rnd, input s, input inexact, input [10:0] rest, input [10:0] halfv,
                             input st, input lsb, input [10+8:0] fint, input [7:0] word);
    logic gt_half, half_eq;
    gt_half = rest > halfv; half_eq = (rest == halfv) && (halfv != 0);
    case (rnd)
      3'd0: m2_rup = gt_half || (half_eq && (st || lsb));
      3'd1: m2_rup = 1'b0;
      3'd2: m2_rup = inexact && s;
      3'd3: m2_rup = inexact && !s;
      3'd4: m2_rup = inexact && (0 ? (fint >= word) : (fint > word));
      default: m2_rup = inexact;   // 5: away from zero
    endcase
  endfunction

  // a +/- b on X (normalized inputs); specials: nan wins, inf-inf = nan
  function automatic [26:0] m2_add(input [26:0] a, input [26:0] b, input sub);
    logic [26:0] na, nb, big, sml; logic [1:0] spa, spb; logic sa, sb, sr, sw;
    logic signed [12:0] ea, eb, d; logic [10:0] ms, mb, r; logic st, stb; integer sh;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[26:26-1]; spb = nb[26:26-1];
    sa = na[26-2]; sb = nb[26-2] ^ sub;
    if (spa == 2'd1 || spb == 2'd1) m2_add = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m2_add = (sa == sb) ? m2_mkx(2'd2, sa, 0, 0, 1'b0) : m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_add = m2_mkx(2'd2, sa, 0, 0, 1'b0);
    else if (spb == 2'd2) m2_add = m2_mkx(2'd2, sb, 0, 0, 1'b0);
    else if (na[10:1] == 0 && !na[0]) m2_add = {nb[26:26-1], sb, nb[26-3:0]};
    else if (nb[10:1] == 0 && !nb[0]) m2_add = na;
    else begin
      ea = na[10+13:10+1]; eb = nb[10+13:10+1];
      // order by magnitude (both normalized): larger exponent, then sig
      if (ea > eb || (ea == eb && na[10:1] >= nb[10:1])) begin big = na; sml = nb; sw = 1'b0; end
      else begin big = nb; sml = na; sw = 1'b1; end
      d = big[10+13:10+1] - sml[10+13:10+1];
      ms = {1'b0, sml[10:1]}; stb = sml[0];
      if (d > 10 + 1) begin stb = stb | (ms != 0); ms = 0; end
      else begin
        for (sh = 0; sh < 10 + 2; sh = sh + 1) begin
          if (sh < d) begin stb = stb | ms[0]; ms = ms >> 1; end
        end
      end
      mb = {1'b0, big[10:1]}; st = big[0] | stb;
      if ((sw ? sb : sa) == (sw ? sa : sb)) begin
        r = mb + ms;
        sr = sw ? sb : sa;
      end else begin
        // subtract: the sticky of the smaller operand borrows one lsb
        r = mb - ms - (stb ? 1'b1 : 1'b0);
        sr = sw ? sb : sa;
        if (r == 0 && !st) sr = 1'b0;
      end
      if (r[10]) begin st = st | r[0]; r = r >> 1; m2_add = m2_mkx(2'd0, sr, big[10+13:10+1] + 1, r[9:0], st); end
      else m2_add = m2_mkx(2'd0, sr, big[10+13:10+1], r[9:0], st);
    end
  endfunction
  function automatic [26:0] m2_mul(input [26:0] a, input [26:0] b);
    logic [26:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*10-1:0] pr; logic st; integer k;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[26:26-1]; spb = nb[26:26-1]; s = na[26-2] ^ nb[26-2];
    if (spa == 2'd1 || spb == 2'd1) m2_mul = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 || spb == 2'd2) begin
      if ((spa == 2'd0 && na[10:1] == 0 && !na[0]) || (spb == 2'd0 && nb[10:1] == 0 && !nb[0]))
        m2_mul = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m2_mul = m2_mkx(2'd2, s, 0, 0, 1'b0);
    end else begin
      pr = na[10:1] * nb[10:1];
      st = na[0] | nb[0];
      // keep the top XW bits of the product, the rest folds into sticky
      st = st | (pr[9:0] != 0);
      m2_mul = m2_mkx(2'd0, s, na[10+13:10+1] + nb[10+13:10+1] + 10, pr[2*10-1:10], st);
    end
  endfunction
  // restoring division (a << XW) / dv of two XW-bit significands with dv
  // normalized (dv >= 2^(XW-1)): {q[XW:0], r[XW:0]}, XW+1 quotient bits.
  // The first step compares a itself (the partial remainder after the
  // dividend's top XW bits: with dv normalized no earlier step can
  // subtract, so those steps are omitted), then one step per zero bit
  // shifted in. Every step assigns r and q unconditionally (a ternary on
  // the compare): the loop unrolls into straight-line logic rather than
  // a chain of if/else switches in one process, which yosys's latch
  // analysis (proc_dlatch) never finishes on
  function automatic [2*10+1:0] m2_udiv(input [9:0] a, input [9:0] dv);
    logic [10+1:0] r; logic [10:0] q; logic ge; integer i;
    r = {2'b0, a}; q = 0;
    for (i = 10; i >= 0; i = i - 1) begin
      ge = (r >= {2'b0, dv});
      r = ge ? r - {2'b0, dv} : r;
      q = {q[9:0], ge};
      if (i > 0) r = {r[10:0], 1'b0};
    end
    m2_udiv = {q, r[10:0]};
  endfunction
  // the exact product: {special[1:0], sign, exp[EW], sig[2XW]} (no sticky)
  function automatic [2*10+13+2:0] m2_mulx(input [26:0] a, input [26:0] b);
    logic [26:0] na, nb; logic [1:0] spa, spb, sp; logic s; logic [2*10-1:0] pr;
    na = m2_norm(a); nb = m2_norm(b);
    pr = na[10:1] * nb[10:1];
    spa = na[26:26-1]; spb = nb[26:26-1]; s = na[26-2] ^ nb[26-2];
    if (spa == 2'd1 || spb == 2'd1) sp = 2'd1;
    else if (spa == 2'd2 || spb == 2'd2)
      sp = ((spa == 2'd0 && na[10:1] == 0) || (spb == 2'd0 && nb[10:1] == 0)) ? 2'd1 : 2'd2;
    else sp = 2'd0;
    m2_mulx = {sp, s, na[10+13:10+1] + nb[10+13:10+1], pr};
  endfunction
  function automatic [26:0] m2_div(input [26:0] a, input [26:0] b);
    logic [26:0] na, nb; logic [1:0] spa, spb; logic s; logic [2*10+1:0] qr; logic [10:0] q, r;
    na = m2_norm(a); nb = m2_norm(b);
    spa = na[26:26-1]; spb = nb[26:26-1]; s = na[26-2] ^ nb[26-2];
    if (spa == 2'd1 || spb == 2'd1) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2 && spb == 2'd2) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_div = m2_mkx(2'd2, s, 0, 0, 1'b0);
    else if (spb == 2'd2) m2_div = m2_mkx(2'd0, s, 0, 0, 1'b0);
    else if (nb[10:1] == 0 && !nb[0]) begin
      if (na[10:1] == 0 && !na[0]) m2_div = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
      else m2_div = m2_mkx(2'd2, s, 0, 0, 1'b0);
    end else if (na[10:1] == 0 && !na[0]) m2_div = m2_mkx(2'd0, s, 0, 0, 1'b0);
    else begin
      qr = m2_udiv(na[10:1], nb[10:1]);     // both normalized: nonzero finite
      q = qr[2*10+1:10+1]; r = qr[10:0];
      // q < 2^(XW+1): drop one bit when it carries
      if (q[10]) m2_div = m2_mkx(2'd0, s, na[10+13:10+1] - nb[10+13:10+1] - 10 + 1, q[10:1], (r != 0) | q[0] | na[0] | nb[0]);
      else m2_div = m2_mkx(2'd0, s, na[10+13:10+1] - nb[10+13:10+1] - 10, q[9:0], (r != 0) | na[0] | nb[0]);
    end
  endfunction
  function automatic [26:0] m2_sqrt(input [26:0] a);
    logic [26:0] na; logic [1:0] spa; logic signed [12:0] e; logic [10:0] m; logic [2*10+3:0] rad;
    logic [10+2:0] rem, trial; logic [10:0] root; logic ge; integer i;
    na = m2_norm(a); spa = na[26:26-1];
    if (spa == 2'd1) m2_sqrt = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else if (spa == 2'd2) m2_sqrt = na[26-2] ? m2_mkx(2'd1, 1'b0, 0, 0, 1'b0) : na;
    else if (na[10:1] == 0 && !na[0]) m2_sqrt = na;
    else if (na[26-2]) m2_sqrt = m2_mkx(2'd1, 1'b0, 0, 0, 1'b0);
    else begin
      e = na[10+13:10+1];
      // value = m * 2^e with e even; radicand = m * 2^(2K): root = sqrt(m) * 2^K, XW+1 bits
      if (e[0]) begin m = {na[10:1], 1'b0}; e = e - 1; end
      else m = {1'b0, na[10:1]};
      rad = {{(10+3){1'b0}}, m} << 10;
      rem = 0; root = 0;
      for (i = 10; i >= 0; i = i - 1) begin
        rem = {rem[10:0], rad[2*i +: 2]};
        trial = {root, 2'b01};
        ge = (rem >= trial);                  // unconditional assignments, as in udiv
        rem = ge ? rem - trial : rem;
        root = {root[9:0], ge};
      end
      m2_sqrt = m2_mkx(2'd0, 1'b0, (e >>> 1) - 5 + 1, root[10:1], (rem != 0) | root[0] | na[0]);
    end
  endfunction
  // X ordering treats NaN as unordered and compares finite values by sign and magnitude
  function automatic m2_lt(input [26:0] a, input [26:0] b);
    logic [26:0] na, nb; logic za, zb, sa, sb, mag_lt; logic signed [12:0] ea, eb;
    na = m2_norm(a); nb = m2_norm(b);
    za = (na[10:1] == 0) && !na[0]; zb = (nb[10:1] == 0) && !nb[0];
    sa = na[26-2] && !za; sb = nb[26-2] && !zb;
    if (na[26:26-1] == 2'd1 || nb[26:26-1] == 2'd1) m2_lt = 1'b0;
    else if (na[26:26-1] == 2'd2 || nb[26:26-1] == 2'd2) begin
      if (na[26:26-1] == 2'd2 && nb[26:26-1] == 2'd2) m2_lt = na[26-2] && !nb[26-2];
      else if (na[26:26-1] == 2'd2) m2_lt = na[26-2];
      else m2_lt = !nb[26-2];
    end else if (za && zb) m2_lt = 1'b0;
    else if (sa != sb) m2_lt = sa;
    else begin
      ea = na[10+13:10+1]; eb = nb[10+13:10+1];
      if (za) mag_lt = 1'b1; else if (zb) mag_lt = 1'b0;
      else mag_lt = (ea < eb) || (ea == eb && (na[10:1] < nb[10:1] || (na[10:1] == nb[10:1] && !na[0] && nb[0])));
      m2_lt = sa ? !mag_lt && !(za && zb) && !m2_eq(na, nb) : mag_lt;
    end
  endfunction
  function automatic m2_eq(input [26:0] a, input [26:0] b);
    logic [26:0] na, nb; logic za, zb;
    na = m2_norm(a); nb = m2_norm(b);
    za = (na[10:1] == 0) && !na[0]; zb = (nb[10:1] == 0) && !nb[0];
    if (na[26:26-1] == 2'd1 || nb[26:26-1] == 2'd1) m2_eq = 1'b0;
    else if (na[26:26-1] == 2'd2 || nb[26:26-1] == 2'd2)
      m2_eq = (na[26:26-1] == nb[26:26-1]) && (na[26-2] == nb[26-2]);
    else if (za || zb) m2_eq = za && zb;
    else m2_eq = (na[26-2] == nb[26-2]) && (na[10+13:10+1] == nb[10+13:10+1]) && (na[10:1] == nb[10:1]) && (na[0] == nb[0]);
  endfunction

  // fp8e5m2 pattern -> V (bit VW = denormal-read flag returned beside)
  function automatic [19:0] m2_unpack_s(input [7:0] b, input daz);
    logic [4:0] e; logic [1:0] m; logic [2:0] sig; logic signed [12:0] ex; logic den, s;
    e = b[6:2]; m = b[1:0]; s = b[7]; den = 1'b0; sig = 0; ex = 0;
    if ((e == 5'd31 && m != 0)) m2_unpack_s = {1'b0, m2_mkv(2'd1, 1'b0, 0, 0)};
    else if ((e == 5'd31 && m == 0)) m2_unpack_s = {1'b0, m2_mkv(2'd2, s, 0, 0)};
    else begin
    if (e == 0) begin sig = {{(3-2){1'b0}}, m}; ex = -16; if (m != 0) den = 1'b1; if (daz && m != 0) sig = 0; end
    else begin sig = {{(3-2-1){1'b0}}, 1'b1, m}; ex = e - 17; end
      m2_unpack_s = {den, m2_mkv(2'd0, s, ex, sig)};
    end
  endfunction

  // X -> fp8e5m2 (fp8e5m2): sign(1) exp 5 man 2, top field 30, max finite 7'd123
  function automatic [10+8-1:0] m2_pack_fp8e5m2(input [26:0] x0, input [2:0] rnd, input [7:0] word, input ftz);
    logic [26:0] x; logic [1:0] sp; logic s; logic signed [12:0] e, eu, biased; logic [9:0] sig;
    logic st, inexact, up, upn, half_eq, gt_half, tiny, ovf, unf, carry_n, to_inf; integer sh, shn, sht;
    logic [10:0] keep, rest, keepn, restn, halfv, halfn; logic [10+8:0] fint, fintn; logic [10-1:0] fl;
    logic [8+13:0] code; logic [8:0] mag; logic [8-1:0] outb;
    x = m2_norm(x0); sp = x[26:26-1]; s = x[26-2] & 1; sig = x[10:1]; st = x[0]; e = x[10+13:10+1];
    fl = 0; outb = 0;
    if (sp == 2'd1) begin fl[5] = 1'b1; outb = 8'd126; end
    else if (sp == 2'd2) begin
      outb = {s, 7'd124}; if (!1) begin fl[4] = 1'b1; fl[2] = 1'b1; end
    end else if (sig == 0 && !st) begin outb = 1 ? 0 : {s, {7{1'b0}}}; end
    else begin
      if (sig == 0) begin sig = 1 << 9; e = e - (2*10-1); end // normalize the lone sticky's tiny value
      eu = e + 9;                 // exponent of the leading one
      biased = eu + 15;
      shn = 10 - 1 - 2;           // bits dropped at the normal precision
      sh = (biased >= 1) ? shn : shn + (1 - biased);
      sht = sh;
      if (sh > 10 + 1) sh = 10 + 1;
      keep = {1'b0, sig} >> sh; rest = {1'b0, sig} & ((sh > 10) ? {(10+1){1'b1}} : ({1'b0, {10{1'b1}}} >> (10 - sh)));
      halfv = (sh == 0) ? 0 : ({{10{1'b0}}, 1'b1} << (sh - 1));
      keepn = {1'b0, sig} >> shn; restn = {1'b0, sig} & ({1'b0, {10{1'b1}}} >> (10 - shn));
      halfn = (shn == 0) ? 0 : ({{10{1'b0}}, 1'b1} << (shn - 1));
      inexact = (rest != 0) | st;
      fint = (sht - 8 > 10) ? 0 : (sht >= 8) ? (rest >> (sht - 8)) : (rest << (8 - sht));
      fintn = (shn >= 8) ? (restn >> (shn - 8)) : (restn << (8 - shn));
      up = m2_rup(rnd, s, inexact, rest, halfv, st, keep[0], fint, word);
      upn = m2_rup(rnd, s, (restn != 0) | st, restn, halfn, st, keepn[0], fintn, word);
      carry_n = ((keepn + upn) == ({{10{1'b0}}, 1'b1} << (2 + 1)));
      mag = keep + up;
      if (biased < 1) biased = 0;
      code = (biased < 1) ? mag : ((biased << 2) + mag - ({{(8+13){1'b0}}, 1'b1} << 2));
      tiny = 0 ? (eu < -14) : ((eu < -14) && !(eu == -14 - 1 && carry_n) && !(eu + 15 == 0 && carry_n));
      ovf = (code > 7'd123);
      if (ovf) begin
        to_inf = 1 && (rnd == 3'd0 || (rnd == 3'd3 && !s) || (rnd == 3'd2 && s) || rnd == 3'd5 || (rnd == 3'd4 && (eu > 15 || up)));
        outb = to_inf ? {s, 7'd124} : {s, 7'd123};
        fl[2] = 1'b1; fl[4] = 1'b1;
      end else begin
        outb = {s, code[6:0]};
        if (inexact) fl[4] = 1'b1;
        if (tiny && inexact) fl[3] = 1'b1;
        if (ftz && code[7-1:2] == 0 && code[1:0] != 0) begin
          outb = {s, {7{1'b0}}}; fl[4] = 1'b1; fl[3] = 1'b1;
        end

      end
    end
    m2_pack_fp8e5m2 = {fl, outb};
  endfunction
endpackage
// ADIR-MEMBER top
// EVOLVE-BLOCK-START
// ADIR-DECL v1
// VAR core.fp_adder.m0.family=two_path
// VAR core.fp_adder.m0.operand_order=shift_each_operand
// VAR core.fp_adder.m0.sig_adder.family=end_around_carry
// VAR core.fp_adder.m0.exp.adder.family=fpga_carry_chain
// VAR core.fp_adder.m0.path_threshold=3
// VAR core.fp_adder.m0.close_path_trigger=exp_diff_and_effective_sub
// VAR core.fp_adder.m0.path_select_point=late_result_mux
// VAR core.fp_adder.m0.sig_adder.modulus=generic_p_correction
// VAR core.fp_adder.m0.sig_adder.topology=ladner_fischer
// VAR core.fp_adder.m0.sig_adder.modulus_value=84
// VAR core.fp_adder.m0.exp.adder.chain_segment_length=8
// VAR core.fp_adder.m0.far_align.sticky_method=trailing_zero_compare
// VAR core.fp_adder.m0.far_align.shifter.family=masked_merged
// VAR core.fp_adder.m0.far_align.shifter.mask_generator=lut
// VAR core.fp_adder.m0.far_align.shifter.rotator.select_encoding=one_hot_decoded
// VAR core.fp_adder.m0.far_align.tzc.strategy=isolate_then_encode
// VAR core.fp_adder.m0.far_align.tzc.lzd.family=priority_encoder
// VAR core.fp_adder.m0.far_align.tzc.lzd.output_form=one_hot_then_encode
// VAR core.fp_adder.m0.far_align.tzc.lzd.lookahead_group=12
// VAR core.fp_adder.m0.far_align.tzc.lzd.levels=3
// VAR core.fp_adder.m0.close_norm.coarse_granularity=8
// VAR core.fp_adder.m0.close_norm.shifter.stage_radix=full_width_single_stage
// VAR core.fp_adder.m0.close_norm.shifter.select_encoding=one_hot_decoded
// VAR core.fp_adder.m0.close_norm.shifter.direction_handling=data_reversal
// VAR core.fp_adder.m0.near_lz.string_form=dual_pos_neg_strings
// VAR core.fp_adder.m0.near_lz.zero_result_detect=operand_function_or
// VAR core.fp_adder.m0.near_lz.encoder.family=prefix_lzc
// VAR core.fp_adder.m0.near_lz.encoder.prefix_topology=sklansky
// VAR core.fp_adder.m0.near_lz.encoder.counter.counter_primitive=lut_rom
// VAR core.fp_adder.m0.near_lz.encoder.counter.tree_shape=linear_chain
// VAR core.fp_adder.m0.near_lz.encoder.counter.final_adder.family=sparse_prefix_hybrid
// VAR core.fp_adder.m0.near_lz.encoder.counter.final_adder.log2_sparsity=1
// VAR core.fp_adder.m0.near_lz.encoder.counter.final_adder.sum_block.full_adder_logic=two_half_adders_or
// VAR core.fp_multiplier.m0.sig_mul.family=direct_pp_parallel
// VAR core.fp_multiplier.m0.exp_adder.family=ling_prefix
// VAR core.fp_multiplier.m0.sig_mul.reduction.family=tiled_cpa_reduction_tree
// VAR core.fp_multiplier.m0.sig_mul.reduction.carry_assimilation=staggered_tiling
// VAR core.fp_multiplier.m0.sig_mul.reduction.cpa.family=hybrid_arrival_driven
// VAR core.fp_multiplier.m0.sig_mul.reduction.cpa.region_count=3
// VAR core.fp_multiplier.m0.sig_mul.reduction.cpa.region_adder_mix=ripple_skip
// VAR core.fp_multiplier.m0.sig_mul.reduction.cpa.arrival_model=measured_tree_profile
// VAR core.fp_multiplier.m0.sig_mul.reduction.cpa.boundary_search=delay_bound_boundary_enumeration
// VAR core.fp_multiplier.m0.sig_mul.reduction.tile_adder.family=compound_flagged_prefix
// VAR core.fp_multiplier.m0.sig_mul.reduction.tile_adder.topology=brent_kung
// VAR core.fp_multiplier.m0.sig_mul.reduction.tile_adder.outputs=sum_sum1_summinus1
// VAR core.fp_multiplier.m0.sig_mul.hard_multiple_adder.full_adder_logic=half_sum_mux_carry
// VAR core.fp_multiplier.m0.exp_adder.topology=han_carlson
// VAR core.fp_multiplier.m0.exp_adder.pseudo_carry_group=3
// VAR core.fp_fma.m1.family=reduced_latency_fma
// VAR core.fp_fma.m1.subnormal_representation=pseudo_normalized_wide_exponent
// VAR core.fp_fma.m1.negation_handling=complement_recode
// VAR core.fp_fma.m1.rounding_position=fused_with_cpa_dual_sum
// VAR core.fp_fma.m1.add_skip_for_pure_addition=true
// VAR core.fp_fma.m1.multiplier.family=booth_recoded_parallel
// VAR core.fp_fma.m1.multiplier.booth_radix=8
// VAR core.fp_fma.m1.multiplier.hard_multiple_gen=partially_redundant
// VAR core.fp_fma.m1.multiplier.reduction.family=tiled_cpa_reduction_tree
// VAR core.fp_fma.m1.multiplier.reduction.adder_width=4
// VAR core.fp_fma.m1.multiplier.reduction.carry_assimilation=terminal_compressor
// VAR core.fp_fma.m1.multiplier.reduction.terminal_reduction=compressor_9_2
// VAR core.fp_fma.m1.multiplier.reduction.cpa.adder.family=manchester_carry_chain
// VAR core.fp_fma.m1.multiplier.hard_multiple_adder.family=parallel_prefix
// VAR core.fp_fma.m1.multiplier.hard_multiple_adder.topology=kogge_stone
// VAR core.fp_fma.m1.multiplier.negation_incrementer.structure=select_blocks
// VAR core.fp_fma.m1.align.sticky_method=precomputed_mask
// VAR core.fp_fma.m1.align.shifter.family=funnel
// VAR core.fp_fma.m1.align.shifter.sticky_collect=true
// VAR core.fp_fma.m1.align.shifter.amount_preprocess=subtract_from_n
// VAR core.fp_fma.m1.align.tzc.isolate_circuit=ripple_kill_chain
// VAR core.fp_fma.m1.align.tzc.lzd.family=priority_encoder
// VAR core.fp_fma.m1.align.tzc.lzd.output_form=direct_binary
// VAR core.fp_fma.m1.align.tzc.lzd.levels=2
// VAR core.fp_fma.m1.align.tzc.negation_incrementer.structure=prefix_and_tree
// VAR core.fp_fma.m1.align.tzc.negation_incrementer.topology=brent_kung
// VAR core.fp_fma.m1.lza.correction_scheme=compensation_in_rounding
// VAR core.fp_fma.m1.lza.indicator_restriction=positive_result_only
// VAR core.fp_fma.m1.lza.encoder.valid_flag_propagation=true
// VAR core.fp_fma.m1.cpa.family=prefix_synthesis_nonuniform_arrival
// VAR core.fp_fma.m1.cpa.arrival_profile=msb_late
// VAR core.fp_fma.m1.norm_shifter.family=butterfly_network
// VAR core.fp_fma.m1.norm_shifter.network=butterfly
// VAR core.fp_multiplier.m2.sig_mul.family=segmented_grid
// VAR core.fp_multiplier.m2.exp_adder.family=manchester_carry_chain
// VAR core.fp_multiplier.m2.sig_mul.recursion_depth=2
// VAR core.fp_multiplier.m2.sig_mul.seg_w=8
// VAR core.fp_multiplier.m2.sig_mul.num_seg=4
// VAR core.fp_multiplier.m2.sig_mul.segment_shape=rectangular
// VAR core.fp_multiplier.m2.sig_mul.merge_form=shift_add_tree
// VAR core.fp_multiplier.m2.sig_mul.segment.family=booth_recoded_parallel
// VAR core.fp_multiplier.m2.sig_mul.segment.sign_extension=roorda_compact
// VAR core.fp_multiplier.m2.sig_mul.segment.negative_pp_encoding=twos_complement_row
// VAR core.fp_multiplier.m2.sig_mul.segment.reduction.family=compressor_4_2_tree
// VAR core.fp_multiplier.m2.sig_mul.segment.reduction.cpa.adder.family=ling_prefix
// VAR core.fp_multiplier.m2.sig_mul.segment.reduction.cpa.adder.topology=han_carlson
// VAR core.fp_multiplier.m2.sig_mul.segment.reduction.cpa.adder.sum_recovery=xor_correction
// VAR core.fp_multiplier.m2.sig_mul.segment.hard_multiple_adder.family=ling_prefix
// VAR core.fp_multiplier.m2.sig_mul.segment.hard_multiple_adder.topology=knowles_mixed
// VAR core.fp_multiplier.m2.sig_mul.segment.hard_multiple_adder.sum_recovery=xor_correction
// VAR core.fp_multiplier.m2.sig_mul.merge_adder.family=manchester_carry_chain
// VAR core.fp_multiplier.m2.sig_mul.merge_adder.variable_skip=true
// VAR core.fp_multiplier.m2.sig_mul.merge_tree.family=tiled_cpa_reduction_tree
// VAR core.fp_multiplier.m2.sig_mul.merge_tree.terminal_reduction=compressor_4_2
// VAR core.fp_multiplier.m2.sig_mul.merge_tree.cpa.family=hybrid_arrival_driven
// VAR core.fp_multiplier.m2.sig_mul.merge_tree.cpa.region_count=3
// VAR core.fp_multiplier.m2.sig_mul.merge_tree.cpa.region_adder_mix=uniform_cla
// VAR core.fp_multiplier.m2.sig_mul.merge_tree.cpa.arrival_model=measured_tree_profile
// VAR core.fp_multiplier.m2.sig_mul.merge_tree.cpa.boundary_search=delay_bound_boundary_enumeration
// VAR core.fp_multiplier.m2.sig_mul.merge_tree.tile_adder.family=end_around_carry
// VAR core.fp_multiplier.m2.sig_mul.merge_tree.tile_adder.modulus=mod_2n_plus_1_diminished_one
// VAR core.fp_multiplier.m2.sig_mul.merge_tree.tile_adder.topology=han_carlson
// VAR core.fp_multiplier.m2.sig_mul.merge_tree.tile_adder.incrementer.structure=prefix_and_tree
// VAR core.fp_multiplier.m2.sig_mul.merge_tree.tile_adder.incrementer.topology=kogge_stone
// VAR core.fp_multiplier.m2.exp_adder.chain_segment_length=4
// VAR core.fp_comparator.m0.family=dedicated_magnitude_comparator
// VAR core.fp_comparator.m0.comparator.family=subtractor_comparator
// VAR core.fp_comparator.m0.comparator.zero_detect=operand_xnor
// VAR core.fp_comparator.m0.comparator.subtractor.family=ling_prefix
// VAR core.fp_comparator.m0.comparator.subtractor.topology=kogge_stone
// VAR core.fp_comparator.m0.comparator.subtractor.pseudo_carry_group=2
// VAR core.fp_comparator.m0.comparator.subtractor.sum_recovery=xor_correction
// VAR core.fp_comparator.m1.family=dedicated_magnitude_comparator
// VAR core.fp_comparator.m1.comparator.family=subtractor_comparator
// VAR core.fp_comparator.m1.comparator.subtractor.full_adder_logic=two_half_adders_or
// VAR core.fp_comparator.m1.comparator.subtractor.chunk_width_bits=2
// VAR core.fp_comparator.m2.comparator.family=subtractor_comparator
// VAR core.fp_comparator.m2.comparator.subtractor.family=prefix_synthesis_nonuniform_arrival
// VAR core.rounder.m0.lzc.family=prefix_lzc
// VAR core.rounder.m0.shifter.family=butterfly_network
// VAR core.rounder.m0.shifter.sticky_collect=true
// VAR core.rounder.m0.round.family=injection
// VAR core.rounder.m0.exp_adder.family=carry_select
// VAR core.rounder.m0.exp_incrementer.structure=prefix_and_tree
// VAR core.rounder.m0.lzc.prefix_topology=brent_kung
// VAR core.rounder.m0.lzc.count_form=lookahead_flags
// VAR core.rounder.m0.lzc.counter.tree_shape=wallace_style
// VAR core.rounder.m0.lzc.counter.final_adder.family=parallel_prefix
// VAR core.rounder.m0.lzc.counter.final_adder.topology=harris
// VAR core.rounder.m0.lzc.counter.final_adder.log2_sparsity=1
// VAR core.rounder.m0.lzc.counter.final_adder.fanout_cap=6
// VAR core.rounder.m0.shifter.network=butterfly
// VAR core.rounder.m0.round.injection_adder.family=end_around_carry
// VAR core.rounder.m0.round.injection_adder.modulus=mod_2n_plus_1_diminished_one
// VAR core.rounder.m0.round.injection_adder.topology=harris
// VAR core.rounder.m0.round.injection_adder.log2_sparsity=2
// VAR core.rounder.m0.round.injection_adder.fanout_cap=5
// VAR core.rounder.m0.round.injection_adder.incrementer.structure=prefix_and_tree
// VAR core.rounder.m0.round.injection_adder.incrementer.topology=brent_kung
// VAR core.rounder.m0.exp_adder.block_sizing=delay_balanced_dp
// VAR core.rounder.m0.exp_adder.block_width=7
// VAR core.rounder.m0.exp_adder.select_source=lookahead_tree
// VAR core.rounder.m0.exp_adder.block_adder.family=parallel_prefix
// VAR core.rounder.m0.exp_adder.block_adder.valency=4
// VAR core.rounder.m1.lzc.block_primitive=nibble_cell
// VAR core.rounder.m1.shifter.family=masked_merged
// VAR core.rounder.m1.round.family=compound_adder_select
// VAR core.rounder.m1.round.incrementer.structure=select_blocks
// VAR core.rounder.m1.exp_adder.family=sparse_prefix_hybrid
// VAR core.rounder.m1.exp_incrementer.structure=prefix_and_tree
// VAR core.rounder.m1.exp_incrementer.topology=brent_kung
// VAR core.rounder.m1.shifter.merge_style=per_bit_mux
// VAR core.rounder.m1.shifter.rotator.stage_radix=full_width_single_stage
// VAR core.rounder.m1.exp_adder.log2_sparsity=2
// VAR core.rounder.m1.exp_adder.sum_block_style=ripple_precompute
// VAR core.rounder.m2.lzc.family=priority_encoder
// VAR core.rounder.m2.lzc.output_form=one_hot_then_encode
// VAR core.rounder.m2.shifter.family=butterfly_network
// VAR core.rounder.m2.shifter.sticky_collect=true
// VAR core.rounder.m2.round.incrementer.structure=prefix_and_tree
// VAR core.rounder.m2.round.incrementer.topology=kogge_stone
// VAR core.rounder.m2.exp_adder.family=end_around_carry
// VAR core.rounder.m2.exp_incrementer.structure=prefix_and_tree
// VAR core.rounder.m2.exp_incrementer.topology=brent_kung
// VAR core.rounder.m2.lzc.lookahead_group=8
// VAR core.rounder.m2.lzc.levels=3
// VAR core.rounder.m2.exp_adder.topology=ladner_fischer
// VAR core.rounder.m2.exp_adder.incrementer.structure=select_blocks
// VAR core.unpacker.m0.family=shared_per_lane
// VAR core.unpacker.m0.denormal_handling=in_datapath
// VAR core.unpacker.m1.family=shared_per_lane
// VAR core.unpacker.m1.lzc.block_primitive=nibble_cell
// VAR core.unpacker.m1.lzc.valid_flag_propagation=true
// VAR core.unpacker.m1.shifter.stage_radix=4
// VAR core.unpacker.m1.shifter.stage_order=large_shift_first
// VAR core.unpacker.m1.shifter.direction_handling=amount_negation
// VAR core.unpacker.m1.shifter.sticky_collect=true
// VAR core.unpacker.m2.lzc.family=prefix_lzc
// VAR core.unpacker.m2.shifter.stage_radix=full_width_single_stage
// VAR core.unpacker.m2.lzc.prefix_topology=brent_kung
// VAR core.unpacker.m2.lzc.count_form=lookahead_flags
// VAR core.unpacker.m2.lzc.counter.counter_primitive=counter_7_3
// VAR core.unpacker.m2.lzc.counter.tree_shape=wallace_style
// VAR core.unpacker.m2.lzc.counter.final_adder.family=ling_prefix
// VAR core.unpacker.m2.lzc.counter.final_adder.topology=knowles_mixed
// STRUCTURE m0.l0.fp_adder kind=fp_adder slot=fp_adder mode=0 lane=0 width=16 format=fp16 ops=fadd,fsub sv=alu_core_u_m0_l0_fp_adder
// STRUCTURE m0.l0.unpacker kind=unpacker slot=unpacker mode=0 lane=0 width=16 format=fp16 ops=fadd,fsub,fmul,fmin,fmax,fcmp sv=alu_core_u_m0_l0_unpacker
// STRUCTURE m0.l0.rounder kind=rounder slot=rounder mode=0 lane=0 width=16 format=fp16 ops=fadd,fsub,fmul sv=alu_core_u_m0_l0_rounder
// STRUCTURE m0.l0.fp_fma kind=fp_fma slot=fp_fma mode=0 lane=0 width=16 format=fp16 ops=fadd,fsub,fmul
// STRUCTURE m0.l0.fp_multiplier kind=fp_multiplier slot=fp_multiplier mode=0 lane=0 width=16 format=fp16 ops=fmul sv=alu_core_u_m0_l0_fp_multiplier
// STRUCTURE m0.l0.fp_comparator kind=fp_comparator slot=fp_comparator mode=0 lane=0 width=16 format=fp16 ops=fmin,fmax,fcmp sv=alu_core_u_m0_l0_fp_comparator
// STRUCTURE m1.l0.fp_adder kind=fp_adder slot=fp_adder mode=1 lane=0 width=16 format=bf16 ops=fadd,fsub sv=alu_core_u_m1_l0_fp_fma group=m1.l0.fp_fma
// STRUCTURE m1.l0.unpacker kind=unpacker slot=unpacker mode=1 lane=0 width=16 format=bf16 ops=fadd,fsub,fmul,fmin,fmax,fcmp sv=alu_core_u_m1_l0_unpacker
// STRUCTURE m1.l0.rounder kind=rounder slot=rounder mode=1 lane=0 width=16 format=bf16 ops=fadd,fsub,fmul sv=alu_core_u_m1_l0_rounder
// STRUCTURE m1.l0.fp_fma kind=fp_fma slot=fp_fma mode=1 lane=0 width=16 format=bf16 ops=fadd,fsub,fmul sv=alu_core_u_m1_l0_fp_fma group=m1.l0.fp_fma
// STRUCTURE m1.l0.fp_multiplier kind=fp_multiplier slot=fp_multiplier mode=1 lane=0 width=16 format=bf16 ops=fmul sv=alu_core_u_m1_l0_fp_fma group=m1.l0.fp_fma
// STRUCTURE m1.l0.fp_comparator kind=fp_comparator slot=fp_comparator mode=1 lane=0 width=16 format=bf16 ops=fmin,fmax,fcmp sv=alu_core_u_m1_l0_fp_comparator
// STRUCTURE m2.l0.fp_multiplier kind=fp_multiplier slot=fp_multiplier mode=2 lane=0 width=8 format=fp8e5m2 ops=fmul sv=alu_core_u_m2_l0_fp_multiplier
// STRUCTURE m2.l1.fp_multiplier kind=fp_multiplier slot=fp_multiplier mode=2 lane=1 width=8 format=fp8e5m2 ops=fmul sv=alu_core_u_m2_l1_fp_multiplier
// STRUCTURE m2.l0.unpacker kind=unpacker slot=unpacker mode=2 lane=0 width=8 format=fp8e5m2 ops=fmul,fmin,fmax,fcmp sv=alu_core_u_m2_l0_unpacker
// STRUCTURE m2.l0.rounder kind=rounder slot=rounder mode=2 lane=0 width=8 format=fp8e5m2 ops=fmul sv=alu_core_u_m2_l0_rounder
// STRUCTURE m2.l0.fp_fma kind=fp_fma slot=fp_fma mode=2 lane=0 width=8 format=fp8e5m2 ops=fmul
// STRUCTURE m2.l1.unpacker kind=unpacker slot=unpacker mode=2 lane=1 width=8 format=fp8e5m2 ops=fmul,fmin,fmax,fcmp sv=alu_core_u_m2_l1_unpacker
// STRUCTURE m2.l1.rounder kind=rounder slot=rounder mode=2 lane=1 width=8 format=fp8e5m2 ops=fmul sv=alu_core_u_m2_l1_rounder
// STRUCTURE m2.l1.fp_fma kind=fp_fma slot=fp_fma mode=2 lane=1 width=8 format=fp8e5m2 ops=fmul
// STRUCTURE m2.l0.fp_comparator kind=fp_comparator slot=fp_comparator mode=2 lane=0 width=8 format=fp8e5m2 ops=fmin,fmax,fcmp sv=alu_core_u_m2_l0_fp_comparator
// STRUCTURE m2.l1.fp_comparator kind=fp_comparator slot=fp_comparator mode=2 lane=1 width=8 format=fp8e5m2 ops=fmin,fmax,fcmp sv=alu_core_u_m2_l1_fp_comparator
// ADIR-END
module alu_core (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [1:0] rounding_sel,
  output logic [15:0] y,
  output logic [3:0] flags
);
  // alu_core: behavioral reference derived from the instance (modes 1xfp16, 1xbf16, 2xfp8e5m2; ops fadd, fsub, fmul, fmin, fmax, fcmp). Every (mode, op) pair computes the verify layer's exact semantics.
  // HIERARCHY: 17 physical structure modules instantiated by alu_core, built from 13 lane modules (one per mode and kind, parameter LANE) and 3 packages of engine functions (one per mode); a float mode's datapath is split into an unpacker (the xa/xb/den buses), the arithmetic and converter structures (unrounded results on the x bus) and a rounder (y and the flags); 0 misc lane modules and 0 block-conversion group modules
  // UNIT m0.l0.fp_adder module=alu_core_u_m0_l0_fp_adder kind=fp_adder members=m0.l0.fp_adder
  // UNIT m0.l0.unpacker module=alu_core_u_m0_l0_unpacker kind=unpacker members=m0.l0.unpacker
  // UNIT m0.l0.rounder module=alu_core_u_m0_l0_rounder kind=rounder members=m0.l0.rounder
  // UNIT m0.l0.fp_multiplier module=alu_core_u_m0_l0_fp_multiplier kind=fp_multiplier members=m0.l0.fp_multiplier
  // UNIT m0.l0.fp_comparator module=alu_core_u_m0_l0_fp_comparator kind=fp_comparator members=m0.l0.fp_comparator
  // UNIT m1.l0.unpacker module=alu_core_u_m1_l0_unpacker kind=unpacker members=m1.l0.unpacker
  // UNIT m1.l0.rounder module=alu_core_u_m1_l0_rounder kind=rounder members=m1.l0.rounder
  // UNIT m1.l0.fp_fma module=alu_core_u_m1_l0_fp_fma kind=fp_fma members=m1.l0.fp_fma,m1.l0.fp_adder,m1.l0.fp_multiplier
  // UNIT m1.l0.fp_comparator module=alu_core_u_m1_l0_fp_comparator kind=fp_comparator members=m1.l0.fp_comparator
  // UNIT m2.l0.fp_multiplier module=alu_core_u_m2_l0_fp_multiplier kind=fp_multiplier members=m2.l0.fp_multiplier
  // UNIT m2.l1.fp_multiplier module=alu_core_u_m2_l1_fp_multiplier kind=fp_multiplier members=m2.l1.fp_multiplier
  // UNIT m2.l0.unpacker module=alu_core_u_m2_l0_unpacker kind=unpacker members=m2.l0.unpacker
  // UNIT m2.l0.rounder module=alu_core_u_m2_l0_rounder kind=rounder members=m2.l0.rounder
  // UNIT m2.l1.unpacker module=alu_core_u_m2_l1_unpacker kind=unpacker members=m2.l1.unpacker
  // UNIT m2.l1.rounder module=alu_core_u_m2_l1_rounder kind=rounder members=m2.l1.rounder
  // UNIT m2.l0.fp_comparator module=alu_core_u_m2_l0_fp_comparator kind=fp_comparator members=m2.l0.fp_comparator
  // UNIT m2.l1.fp_comparator module=alu_core_u_m2_l1_fp_comparator kind=fp_comparator members=m2.l1.fp_comparator
  // // STRUCTURE m0.l0.fp_adder kind=fp_adder slot=fp_adder mode=0 lane=0 width=16 format=fp16 ops=fadd,fsub sv=alu_core_u_m0_l0_fp_adder
  // // STRUCTURE m0.l0.unpacker kind=unpacker slot=unpacker mode=0 lane=0 width=16 format=fp16 ops=fadd,fsub,fmul,fmin,fmax,fcmp sv=alu_core_u_m0_l0_unpacker
  // // STRUCTURE m0.l0.rounder kind=rounder slot=rounder mode=0 lane=0 width=16 format=fp16 ops=fadd,fsub,fmul sv=alu_core_u_m0_l0_rounder
  // // STRUCTURE m0.l0.fp_fma kind=fp_fma slot=fp_fma mode=0 lane=0 width=16 format=fp16 ops=fadd,fsub,fmul
  // // STRUCTURE m0.l0.fp_multiplier kind=fp_multiplier slot=fp_multiplier mode=0 lane=0 width=16 format=fp16 ops=fmul sv=alu_core_u_m0_l0_fp_multiplier
  // // STRUCTURE m0.l0.fp_comparator kind=fp_comparator slot=fp_comparator mode=0 lane=0 width=16 format=fp16 ops=fmin,fmax,fcmp sv=alu_core_u_m0_l0_fp_comparator
  // // STRUCTURE m1.l0.fp_adder kind=fp_adder slot=fp_adder mode=1 lane=0 width=16 format=bf16 ops=fadd,fsub sv=alu_core_u_m1_l0_fp_fma
  // // STRUCTURE m1.l0.unpacker kind=unpacker slot=unpacker mode=1 lane=0 width=16 format=bf16 ops=fadd,fsub,fmul,fmin,fmax,fcmp sv=alu_core_u_m1_l0_unpacker
  // // STRUCTURE m1.l0.rounder kind=rounder slot=rounder mode=1 lane=0 width=16 format=bf16 ops=fadd,fsub,fmul sv=alu_core_u_m1_l0_rounder
  // // STRUCTURE m1.l0.fp_fma kind=fp_fma slot=fp_fma mode=1 lane=0 width=16 format=bf16 ops=fadd,fsub,fmul sv=alu_core_u_m1_l0_fp_fma
  // // STRUCTURE m1.l0.fp_multiplier kind=fp_multiplier slot=fp_multiplier mode=1 lane=0 width=16 format=bf16 ops=fmul sv=alu_core_u_m1_l0_fp_fma
  // // STRUCTURE m1.l0.fp_comparator kind=fp_comparator slot=fp_comparator mode=1 lane=0 width=16 format=bf16 ops=fmin,fmax,fcmp sv=alu_core_u_m1_l0_fp_comparator
  // // STRUCTURE m2.l0.fp_multiplier kind=fp_multiplier slot=fp_multiplier mode=2 lane=0 width=8 format=fp8e5m2 ops=fmul sv=alu_core_u_m2_l0_fp_multiplier
  // // STRUCTURE m2.l1.fp_multiplier kind=fp_multiplier slot=fp_multiplier mode=2 lane=1 width=8 format=fp8e5m2 ops=fmul sv=alu_core_u_m2_l1_fp_multiplier
  // // STRUCTURE m2.l0.unpacker kind=unpacker slot=unpacker mode=2 lane=0 width=8 format=fp8e5m2 ops=fmul,fmin,fmax,fcmp sv=alu_core_u_m2_l0_unpacker
  // // STRUCTURE m2.l0.rounder kind=rounder slot=rounder mode=2 lane=0 width=8 format=fp8e5m2 ops=fmul sv=alu_core_u_m2_l0_rounder
  // // STRUCTURE m2.l0.fp_fma kind=fp_fma slot=fp_fma mode=2 lane=0 width=8 format=fp8e5m2 ops=fmul
  // // STRUCTURE m2.l1.unpacker kind=unpacker slot=unpacker mode=2 lane=1 width=8 format=fp8e5m2 ops=fmul,fmin,fmax,fcmp sv=alu_core_u_m2_l1_unpacker
  // // STRUCTURE m2.l1.rounder kind=rounder slot=rounder mode=2 lane=1 width=8 format=fp8e5m2 ops=fmul sv=alu_core_u_m2_l1_rounder
  // // STRUCTURE m2.l1.fp_fma kind=fp_fma slot=fp_fma mode=2 lane=1 width=8 format=fp8e5m2 ops=fmul
  // // STRUCTURE m2.l0.fp_comparator kind=fp_comparator slot=fp_comparator mode=2 lane=0 width=8 format=fp8e5m2 ops=fmin,fmax,fcmp sv=alu_core_u_m2_l0_fp_comparator
  // // STRUCTURE m2.l1.fp_comparator kind=fp_comparator slot=fp_comparator mode=2 lane=1 width=8 format=fp8e5m2 ops=fmin,fmax,fcmp sv=alu_core_u_m2_l1_fp_comparator
  // LIBRARY: fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13, fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w1, fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w2, fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w3, fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w4, fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14, fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14_component_block_adder_adder_w2, fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14_component_block_adder_adder_w3, fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14_component_block_adder_adder_w4, fam_adder_carry_skip_w7, fam_adder_carry_skip_w7_component_block_adder_adder_w3, fam_adder_carry_skip_w7_component_block_adder_adder_w4, fam_adder_carry_skip_w8, fam_adder_carry_skip_w8_component_block_adder_adder_w4, fam_adder_eac_cyclic_prefix_level_p71ad0afc38c98cc878595b2be2d3d81b739691b88149561a71e54f41570fbe7b_w27, fam_adder_eac_two_pass_prefix_pd56b842a1a7958bea4204a91e282cb4fb8608ad6f9dec53b5d5c8cdf1ffc23b7_w27, fam_adder_eac_two_pass_prefix_pe78b8b2e14aea3b9e263e35c4eb909349e1798e5a3c0e9bc52ba3c6f4f857ee3_w13, fam_adder_eac_two_pass_prefix_pe78b8b2e14aea3b9e263e35c4eb909349e1798e5a3c0e9bc52ba3c6f4f857ee3_w14, fam_adder_manchester_carry_chain, fam_adder_ripple_carry, fam_adder_ripple_chunk, fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w16, fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w16_component_sum_block_adder_w4, fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w17, fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w17_component_sum_block_adder_w1, fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w17_component_sum_block_adder_w4, fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w3, fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w3_component_sum_block_adder_w1, fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w3_component_sum_block_adder_w2, fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w4, fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w4_component_sum_block_adder_w2, fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w5, fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w5_component_sum_block_adder_w1, fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w5_component_sum_block_adder_w2, fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w6, fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w6_component_sum_block_adder_w2, fam_binary_decode_fam_adder_eac_cyclic_prefix_level_p71ad0afc38c98cc878595b2be2d3d81b739691b88149561a71e54f41570fbe7b_w27, fam_binary_decode_fam_adder_eac_two_pass_prefix_pd56b842a1a7958bea4204a91e282cb4fb8608ad6f9dec53b5d5c8cdf1ffc23b7_w27, fam_binary_decode_fam_adder_eac_two_pass_prefix_pe78b8b2e14aea3b9e263e35c4eb909349e1798e5a3c0e9bc52ba3c6f4f857ee3_w13, fam_binary_decode_fam_adder_eac_two_pass_prefix_pe78b8b2e14aea3b9e263e35c4eb909349e1798e5a3c0e9bc52ba3c6f4f857ee3_w14, fam_cmp_subtractor_ling_prefix_p6e18491987e97adb7af7143255ee504d7ae2c4e4893b558c56b954fb17ad0f22_operand_xnor_u_w13, fam_cmp_subtractor_ling_prefix_p6e18491987e97adb7af7143255ee504d7ae2c4e4893b558c56b954fb17ad0f22_operand_xnor_u_w27, fam_cmp_subtractor_prefix_synthesis_nonuniform_arrival_p91919e29d8984fc7b1564e16baf52afcd8459b99d9f7793d8c56df316dce0a37_sum_or_tree_u_w24, fam_cmp_subtractor_ripple_carry_p0a9f116f38aacd499cf3fe7c2675658275429e00f2c08fee42fa2d9523cdc581_sum_or_tree_u_w16, fam_cmp_subtractor_ripple_carry_p0a9f116f38aacd499cf3fe7c2675658275429e00f2c08fee42fa2d9523cdc581_sum_or_tree_u_w21, fam_count_lzd_nibble_cell_binary_count_vflat_w20, fam_count_lzd_nibble_cell_binary_count_vprop_w8, fam_count_lzd_pair_cell_binary_count_vprop_w64, fam_count_lzd_pair_cell_binary_count_vprop_w8, fam_count_popcount_linear_chain_lut_rom_sparse_prefix_hybrid_p3651d_w26, fam_count_prefix_lzc_brent_kung_flags_w26, fam_count_prefix_lzc_brent_kung_flags_w3, fam_count_prefix_lzc_sklansky_pcomp_pct_p63edf_w26, fam_count_priority_encoder_g8_l3_one_hot_then_encode_w10, fam_count_tzc_isolate_then_encode_twos_complement_and_pe7180_w27, fam_dot_lza_w34_p17e51f58317a, fam_fp_add_two_path_x26e13s11_p384822081789, fam_fp_cmp_dedicated_magnitude_comparator_x20e16s8_pd5e3e6118bdf, fam_fp_cmp_dedicated_magnitude_comparator_x26e13s11_pe3208de2c98a, fam_fp_cmp_integer_compare_on_bits_x10e13s3_pf4b323d9500d, fam_fp_fma_core_reduced_latency_fma_x20e16s8_bf16_p6f6a2e63b089, fam_fp_fma_reduced_latency_fma_x20e16s8_p3ef0d7160561, fam_fp_mul_sig_mul_then_round_x10e13s3_padd344eaa93c, fam_fp_mul_sig_mul_then_round_x26e13s11_pd2d07246771c, fam_fp_round_dedicated_per_op_compound_adder_select_bf16_x20e16s8_p925d37aacdb3, fam_fp_round_dedicated_per_op_increment_adder_fp8e5m2_x10e13s3_p9d3fabee2f30, fam_fp_round_dedicated_per_op_injection_fp16_x26e13s11_p511c8e3eed31, fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a, fam_fp_unpack_shared_per_lane_bf16_x20e16s8_p9ea5912e1006, fam_fp_unpack_shared_per_lane_fp16_x26e13s11_p68f91d4e9d3f, fam_incr_prefix_and, fam_mul_booth4_dadda_3_2_w4_u_p4789ec73, fam_mul_booth8_dadda_3_2_w8_u_p206e54d6, fam_mul_direct_dadda_3_2_w11_u_pf6dd732b, fam_mul_segmented_grid_w3_u_pf3c3f225, fam_mul_segmented_grid_w3_u_pf3c3f225_g00, fam_mul_segmented_grid_w3_u_pf3c3f225_g10, fam_prefix_arrival_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_w24, fam_prefix_arrival_0_0_0_0_0_1_1_1_1_1_1_1_1_1_2_2_2_2_2_2_2_2_2_3_3_3_3_3_3_3_3_3_4_4_4_4_4_4_4_4_4_4_5_5_5_5_5_5_5_5_5_6_6_6_6_6_6_6_6_6_7_7_7_7_7_w65, fam_prefix_arrival_0_0_0_1_1_1_1_1_1_2_2_2_2_2_2_3_3_3_3_3_4_4_4_4_4_4_5_5_5_5_5_5_6_6_6_w35, fam_prefix_brent_kung_w1_flagm_dual, fam_prefix_brent_kung_w2_flagm_dual, fam_prefix_han_carlson_w13_ling3_sel, fam_prefix_han_carlson_w8_ling, fam_prefix_harris_l2f2_w27, fam_prefix_kogge_stone_w13_ling2, fam_prefix_kogge_stone_w27_ling2, fam_prefix_kogge_stone_w4, fam_prefix_kogge_stone_w8_flag_dual, fam_prefix_ladner_fischer_w13, fam_prefix_ladner_fischer_w14, fam_prefix_ladner_fischer_w27, fam_prefix_ladner_fischer_w28, fam_prefix_net_sklansky_w2, fam_prefix_net_sklansky_w3, fam_prefix_net_sklansky_w4, fam_prefix_net_sklansky_w5, fam_prefix_sklansky_w1_v4, fam_prefix_sklansky_w2_v4, fam_prefix_sklansky_w3_v4, fam_prefix_sklansky_w4_v4, fam_shift_barrel_mux_tree, fam_shift_butterfly_network, fam_shift_funnel, fam_shift_keep_mask, fam_shift_masked_merged, fam_shift_stage (chialu.targets.rtl.families: the modules of the declared families the lane modules instantiate; their text follows the generated modules)
  logic [2:0] rnd_sel;
  logic [2:0] rnd;
  logic daz;
  logic ftz;
  logic dual;
  logic [15:0] y_m0_m0_l0_fp_adder;
  logic [19:0] fl_m0_m0_l0_fp_adder;
  logic [42:0] x_m0_m0_m0_l0_fp_adder;
  logic [42:0] xa_m0_m0_m0_l0_unpacker;
  logic [42:0] xb_m0_m0_m0_l0_unpacker;
  logic dena_m0_m0_m0_l0_unpacker;
  logic denb_m0_m0_m0_l0_unpacker;
  logic [15:0] y_m0_m0_l0_rounder;
  logic [19:0] fl_m0_m0_l0_rounder;
  logic [15:0] y_m0_m0_l0_fp_multiplier;
  logic [19:0] fl_m0_m0_l0_fp_multiplier;
  logic [42:0] x_m0_m0_m0_l0_fp_multiplier;
  logic [15:0] y_m0_m0_l0_fp_comparator;
  logic [19:0] fl_m0_m0_l0_fp_comparator;
  logic [15:0] y_m0;
  logic [19:0] fl_m0;
  logic [42:0] x_m0;
  logic [42:0] xa_m0;
  logic [42:0] xb_m0;
  logic dena_m0;
  logic denb_m0;
  logic [39:0] xa_m1_m1_m1_l0_unpacker;
  logic [39:0] xb_m1_m1_m1_l0_unpacker;
  logic dena_m1_m1_m1_l0_unpacker;
  logic denb_m1_m1_m1_l0_unpacker;
  logic [15:0] y_m1_m1_l0_rounder;
  logic [19:0] fl_m1_m1_l0_rounder;
  logic [15:0] y_m1_m1_l0_fp_fma;
  logic [19:0] fl_m1_m1_l0_fp_fma;
  logic [39:0] x_m1_m1_m1_l0_fp_fma;
  logic [15:0] y_m1_m1_l0_fp_comparator;
  logic [19:0] fl_m1_m1_l0_fp_comparator;
  logic [15:0] y_m1;
  logic [19:0] fl_m1;
  logic [39:0] xa_m1;
  logic [39:0] xb_m1;
  logic dena_m1;
  logic denb_m1;
  logic [39:0] x_m1;
  logic [15:0] y_m2_m2_l0_fp_multiplier;
  logic [19:0] fl_m2_m2_l0_fp_multiplier;
  logic [53:0] x_m2_m2_m2_l0_fp_multiplier;
  logic [15:0] y_m2_m2_l1_fp_multiplier;
  logic [19:0] fl_m2_m2_l1_fp_multiplier;
  logic [53:0] x_m2_m2_m2_l1_fp_multiplier;
  logic [53:0] xa_m2_m2_m2_l0_unpacker;
  logic [53:0] xb_m2_m2_m2_l0_unpacker;
  logic [1:0] dena_m2_m2_m2_l0_unpacker;
  logic [1:0] denb_m2_m2_m2_l0_unpacker;
  logic [15:0] y_m2_m2_l0_rounder;
  logic [19:0] fl_m2_m2_l0_rounder;
  logic [53:0] xa_m2_m2_m2_l1_unpacker;
  logic [53:0] xb_m2_m2_m2_l1_unpacker;
  logic [1:0] dena_m2_m2_m2_l1_unpacker;
  logic [1:0] denb_m2_m2_m2_l1_unpacker;
  logic [15:0] y_m2_m2_l1_rounder;
  logic [19:0] fl_m2_m2_l1_rounder;
  logic [15:0] y_m2_m2_l0_fp_comparator;
  logic [19:0] fl_m2_m2_l0_fp_comparator;
  logic [15:0] y_m2_m2_l1_fp_comparator;
  logic [19:0] fl_m2_m2_l1_fp_comparator;
  logic [15:0] y_m2;
  logic [19:0] fl_m2;
  logic [53:0] x_m2;
  logic [53:0] xa_m2;
  logic [53:0] xb_m2;
  logic [1:0] dena_m2;
  logic [1:0] denb_m2;
  logic [19:0] fl_all;
  always_comb begin
    case (rounding_sel)
      2'd0: rnd_sel = 3'd0;
      2'd1: rnd_sel = 3'd1;
      2'd2: rnd_sel = 3'd2;
      2'd3: rnd_sel = 3'd3;
      default: rnd_sel = 3'd0;
    endcase
  end
  assign rnd = rnd_sel;
  assign daz = 1'b0;
  assign ftz = 1'b0;
  assign dual = 1'b0;
  assign y_m0 = y_m0_m0_l0_fp_adder | y_m0_m0_l0_rounder | y_m0_m0_l0_fp_multiplier | y_m0_m0_l0_fp_comparator;
  assign fl_m0 = fl_m0_m0_l0_fp_adder | fl_m0_m0_l0_rounder | fl_m0_m0_l0_fp_multiplier | fl_m0_m0_l0_fp_comparator;
  assign x_m0 = x_m0_m0_m0_l0_fp_adder | x_m0_m0_m0_l0_fp_multiplier;
  assign xa_m0 = xa_m0_m0_m0_l0_unpacker;
  assign xb_m0 = xb_m0_m0_m0_l0_unpacker;
  assign dena_m0 = dena_m0_m0_m0_l0_unpacker;
  assign denb_m0 = denb_m0_m0_m0_l0_unpacker;
  assign y_m1 = y_m1_m1_l0_rounder | y_m1_m1_l0_fp_fma | y_m1_m1_l0_fp_comparator;
  assign fl_m1 = fl_m1_m1_l0_rounder | fl_m1_m1_l0_fp_fma | fl_m1_m1_l0_fp_comparator;
  assign xa_m1 = xa_m1_m1_m1_l0_unpacker;
  assign xb_m1 = xb_m1_m1_m1_l0_unpacker;
  assign dena_m1 = dena_m1_m1_m1_l0_unpacker;
  assign denb_m1 = denb_m1_m1_m1_l0_unpacker;
  assign x_m1 = x_m1_m1_m1_l0_fp_fma;
  assign y_m2 = y_m2_m2_l0_fp_multiplier | y_m2_m2_l1_fp_multiplier | y_m2_m2_l0_rounder | y_m2_m2_l1_rounder | y_m2_m2_l0_fp_comparator | y_m2_m2_l1_fp_comparator;
  assign fl_m2 = fl_m2_m2_l0_fp_multiplier | fl_m2_m2_l1_fp_multiplier | fl_m2_m2_l0_rounder | fl_m2_m2_l1_rounder | fl_m2_m2_l0_fp_comparator | fl_m2_m2_l1_fp_comparator;
  assign x_m2 = x_m2_m2_m2_l0_fp_multiplier | x_m2_m2_m2_l1_fp_multiplier;
  assign xa_m2 = xa_m2_m2_m2_l0_unpacker | xa_m2_m2_m2_l1_unpacker;
  assign xb_m2 = xb_m2_m2_m2_l0_unpacker | xb_m2_m2_m2_l1_unpacker;
  assign dena_m2 = dena_m2_m2_m2_l0_unpacker | dena_m2_m2_m2_l1_unpacker;
  assign denb_m2 = denb_m2_m2_m2_l0_unpacker | denb_m2_m2_m2_l1_unpacker;
  alu_core_u_m0_l0_fp_adder u_m0_l0_fp_adder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_fp_adder), .fl_m0(fl_m0_m0_l0_fp_adder), .xa_m0(xa_m0), .xb_m0(xb_m0), .dena_m0(dena_m0), .denb_m0(denb_m0), .x_m0(x_m0_m0_m0_l0_fp_adder));
  alu_core_u_m0_l0_unpacker u_m0_l0_unpacker (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .xa_m0(xa_m0_m0_m0_l0_unpacker), .xb_m0(xb_m0_m0_m0_l0_unpacker), .dena_m0(dena_m0_m0_m0_l0_unpacker), .denb_m0(denb_m0_m0_m0_l0_unpacker));
  alu_core_u_m0_l0_rounder u_m0_l0_rounder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_rounder), .fl_m0(fl_m0_m0_l0_rounder), .xa_m0(xa_m0), .xb_m0(xb_m0), .dena_m0(dena_m0), .denb_m0(denb_m0), .x_m0(x_m0));
  alu_core_u_m0_l0_fp_multiplier u_m0_l0_fp_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_fp_multiplier), .fl_m0(fl_m0_m0_l0_fp_multiplier), .xa_m0(xa_m0), .xb_m0(xb_m0), .dena_m0(dena_m0), .denb_m0(denb_m0), .x_m0(x_m0_m0_m0_l0_fp_multiplier));
  alu_core_u_m0_l0_fp_comparator u_m0_l0_fp_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_m0_l0_fp_comparator), .fl_m0(fl_m0_m0_l0_fp_comparator), .xa_m0(xa_m0), .xb_m0(xb_m0), .dena_m0(dena_m0), .denb_m0(denb_m0));
  alu_core_u_m1_l0_unpacker u_m1_l0_unpacker (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .xa_m1(xa_m1_m1_m1_l0_unpacker), .xb_m1(xb_m1_m1_m1_l0_unpacker), .dena_m1(dena_m1_m1_m1_l0_unpacker), .denb_m1(denb_m1_m1_m1_l0_unpacker));
  alu_core_u_m1_l0_rounder u_m1_l0_rounder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_rounder), .fl_m1(fl_m1_m1_l0_rounder), .xa_m1(xa_m1), .xb_m1(xb_m1), .dena_m1(dena_m1), .denb_m1(denb_m1), .x_m1(x_m1));
  alu_core_u_m1_l0_fp_fma u_m1_l0_fp_fma (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_fp_fma), .fl_m1(fl_m1_m1_l0_fp_fma), .xa_m1(xa_m1), .xb_m1(xb_m1), .dena_m1(dena_m1), .denb_m1(denb_m1), .x_m1(x_m1_m1_m1_l0_fp_fma));
  alu_core_u_m1_l0_fp_comparator u_m1_l0_fp_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_m1_l0_fp_comparator), .fl_m1(fl_m1_m1_l0_fp_comparator), .xa_m1(xa_m1), .xb_m1(xb_m1), .dena_m1(dena_m1), .denb_m1(denb_m1));
  alu_core_u_m2_l0_fp_multiplier u_m2_l0_fp_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_fp_multiplier), .fl_m2(fl_m2_m2_l0_fp_multiplier), .xa_m2(xa_m2), .xb_m2(xb_m2), .dena_m2(dena_m2), .denb_m2(denb_m2), .x_m2(x_m2_m2_m2_l0_fp_multiplier));
  alu_core_u_m2_l1_fp_multiplier u_m2_l1_fp_multiplier (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_fp_multiplier), .fl_m2(fl_m2_m2_l1_fp_multiplier), .xa_m2(xa_m2), .xb_m2(xb_m2), .dena_m2(dena_m2), .denb_m2(denb_m2), .x_m2(x_m2_m2_m2_l1_fp_multiplier));
  alu_core_u_m2_l0_unpacker u_m2_l0_unpacker (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .xa_m2(xa_m2_m2_m2_l0_unpacker), .xb_m2(xb_m2_m2_m2_l0_unpacker), .dena_m2(dena_m2_m2_m2_l0_unpacker), .denb_m2(denb_m2_m2_m2_l0_unpacker));
  alu_core_u_m2_l0_rounder u_m2_l0_rounder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_rounder), .fl_m2(fl_m2_m2_l0_rounder), .xa_m2(xa_m2), .xb_m2(xb_m2), .dena_m2(dena_m2), .denb_m2(denb_m2), .x_m2(x_m2));
  alu_core_u_m2_l1_unpacker u_m2_l1_unpacker (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .xa_m2(xa_m2_m2_m2_l1_unpacker), .xb_m2(xb_m2_m2_m2_l1_unpacker), .dena_m2(dena_m2_m2_m2_l1_unpacker), .denb_m2(denb_m2_m2_m2_l1_unpacker));
  alu_core_u_m2_l1_rounder u_m2_l1_rounder (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_rounder), .fl_m2(fl_m2_m2_l1_rounder), .xa_m2(xa_m2), .xb_m2(xb_m2), .dena_m2(dena_m2), .denb_m2(denb_m2), .x_m2(x_m2));
  alu_core_u_m2_l0_fp_comparator u_m2_l0_fp_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l0_fp_comparator), .fl_m2(fl_m2_m2_l0_fp_comparator), .xa_m2(xa_m2), .xb_m2(xb_m2), .dena_m2(dena_m2), .denb_m2(denb_m2));
  alu_core_u_m2_l1_fp_comparator u_m2_l1_fp_comparator (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_m2_l1_fp_comparator), .fl_m2(fl_m2_m2_l1_fp_comparator), .xa_m2(xa_m2), .xb_m2(xb_m2), .dena_m2(dena_m2), .denb_m2(denb_m2));
  always_comb begin
    case (mode)
      2'd0: begin y = y_m0; fl_all = fl_m0; end
      2'd1: begin y = y_m1; fl_all = fl_m1; end
      2'd2: begin y = y_m2; fl_all = fl_m2; end
      default: begin y = '0; fl_all = '0; end
    endcase
  end
  assign flags[0] = fl_all[0] | fl_all[10];
  assign flags[1] = fl_all[2] | fl_all[12];
  assign flags[2] = fl_all[3] | fl_all[13];
  assign flags[3] = fl_all[4] | fl_all[14];
endmodule
// EVOLVE-BLOCK-END

module alu_core_m0_fp_adder #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0,
  input  logic [42:0] xa_m0,
  input  logic [42:0] xb_m0,
  input  logic [0:0] dena_m0,
  input  logic [0:0] denb_m0,
  output logic [42:0] x_m0
);
  // alu_core_m0_fp_adder: lane LANE of mode 0 (fp16) for the fp_adder ops fadd, fsub; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [27:0] m0_uaLANE;
  logic [27:0] m0_ubLANE;
  logic [42:0] m0_xa [0:0];
  logic m0_dena [0:0];
  logic [42:0] m0_xb [0:0];
  logic m0_denb [0:0];
  logic [42:0] m0_fa_xaLANE;
  logic [42:0] m0_fa_xbLANE;
  logic m0_fa_subLANE;
  logic [42:0] m0_fa_yLANE;
  logic [25:0] m0_o0t0_LANE;
  logic [42:0] m0_o0t0_LANE_x;
  logic [42:0] m0_o0t0_LANE_z;
  logic [25:0] m0_o1t0_LANE;
  logic [42:0] m0_o1t0_LANE_x;
  logic [42:0] m0_o1t0_LANE_z;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_uaLANE = m0_unpack_s(m0_aLANE, daz);
  assign m0_ubLANE = m0_unpack_s(m0_bLANE, daz);
  assign m0_xa[LANE] = xa_m0[LANE*43 +: 43];
  assign m0_dena[LANE] = dena_m0[LANE];
  assign m0_xb[LANE] = xb_m0[LANE*43 +: 43];
  assign m0_denb[LANE] = denb_m0[LANE];
  // structure core.fp_adder.m0: family two_path realized by the library module fam_fp_add_two_path_x26e13s11_p384822081789
  fam_fp_add_two_path_x26e13s11_p384822081789 u_m0_faddLANE (.xa(m0_fa_xaLANE), .xb(m0_fa_xbLANE), .sub(m0_fa_subLANE), .y(m0_fa_yLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_fa_xaLANE = 'x; m0_fa_xbLANE = 'x; m0_fa_subLANE = 'x; m0_o0t0_LANE = 'x; m0_o0t0_LANE_x = 'x; m0_o0t0_LANE_z = 'x;
    m0_o1t0_LANE = 'x; m0_o1t0_LANE_x = 'x; m0_o1t0_LANE_z = 'x;
    x_m0 = '0;
    case (op)
      3'd0: begin
        m0_fa_xaLANE = m0_xa[LANE]; m0_fa_xbLANE = m0_xb[LANE]; m0_fa_subLANE = 1'b0; m0_o0t0_LANE_x = m0_fa_yLANE;
        m0_o0t0_LANE_z = { m0_o0t0_LANE_x[42:41], (m0_o0t0_LANE_x[42:41] == 2'd0 && m0_o0t0_LANE_x[26:0] == 0) ? (((m0_xa[LANE][42:41] == 2'd0 && m0_xa[LANE][26:0] == 0) && (m0_xb[LANE][42:41] == 2'd0 && m0_xb[LANE][26:0] == 0)) ? ((rnd == 3'd2) ? (m0_aLANE[15] | (m0_bLANE[15] ^ 1'b0)) : (m0_aLANE[15] & (m0_bLANE[15] ^ 1'b0))) : ((rnd == 3'd2) ? 1'b1 : 1'b0)) : m0_o0t0_LANE_x[40], m0_o0t0_LANE_x[39:0] };
        x_m0[LANE*43 +: 43] = m0_o0t0_LANE_z;
      end
      3'd1: begin
        m0_fa_xaLANE = m0_xa[LANE]; m0_fa_xbLANE = m0_xb[LANE]; m0_fa_subLANE = 1'b1; m0_o1t0_LANE_x = m0_fa_yLANE;
        m0_o1t0_LANE_z = { m0_o1t0_LANE_x[42:41], (m0_o1t0_LANE_x[42:41] == 2'd0 && m0_o1t0_LANE_x[26:0] == 0) ? (((m0_xa[LANE][42:41] == 2'd0 && m0_xa[LANE][26:0] == 0) && (m0_xb[LANE][42:41] == 2'd0 && m0_xb[LANE][26:0] == 0)) ? ((rnd == 3'd2) ? (m0_aLANE[15] | (m0_bLANE[15] ^ 1'b1)) : (m0_aLANE[15] & (m0_bLANE[15] ^ 1'b1))) : ((rnd == 3'd2) ? 1'b1 : 1'b0)) : m0_o1t0_LANE_x[40], m0_o1t0_LANE_x[39:0] };
        x_m0[LANE*43 +: 43] = m0_o1t0_LANE_z;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_fp_comparator #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0,
  input  logic [42:0] xa_m0,
  input  logic [42:0] xb_m0,
  input  logic [0:0] dena_m0,
  input  logic [0:0] denb_m0
);
  // alu_core_m0_fp_comparator: lane LANE of mode 0 (fp16) for the fp_comparator ops fmin, fmax, fcmp; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [27:0] m0_uaLANE;
  logic [27:0] m0_ubLANE;
  logic [42:0] m0_xa [0:0];
  logic m0_dena [0:0];
  logic [42:0] m0_xb [0:0];
  logic m0_denb [0:0];
  logic [42:0] m0_fc_xaLANE;
  logic [42:0] m0_fc_xbLANE;
  logic m0_fc_ltLANE;
  logic m0_fc_eqLANE;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_uaLANE = m0_unpack_s(m0_aLANE, daz);
  assign m0_ubLANE = m0_unpack_s(m0_bLANE, daz);
  assign m0_xa[LANE] = xa_m0[LANE*43 +: 43];
  assign m0_dena[LANE] = dena_m0[LANE];
  assign m0_xb[LANE] = xb_m0[LANE*43 +: 43];
  assign m0_denb[LANE] = denb_m0[LANE];
  // structure core.fp_comparator.m0: family dedicated_magnitude_comparator realized by the library module fam_fp_cmp_dedicated_magnitude_comparator_x26e13s11_pe3208de2c98a
  fam_fp_cmp_dedicated_magnitude_comparator_x26e13s11_pe3208de2c98a u_m0_fcmpLANE (.xa(m0_fc_xaLANE), .xb(m0_fc_xbLANE), .lt(m0_fc_ltLANE), .eq(m0_fc_eqLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_fc_xaLANE = 'x; m0_fc_xbLANE = 'x;
    case (op)
      3'd3: begin
        m0_fc_xaLANE = m0_xa[LANE]; m0_fc_xbLANE = m0_xb[LANE];
        y_m0[((LANE*16)+0) +: 16] = ((m0_xa[LANE][42:41] == 2'd1) && (m0_xb[LANE][42:41] == 2'd1)) ? (1'b0 ? ((m0_xa[LANE][42:41] == 2'd1) ? m0_aLANE : m0_bLANE) : 16'd32256) : (m0_xa[LANE][42:41] == 2'd1) ? m0_bLANE : (m0_xb[LANE][42:41] == 2'd1) ? m0_aLANE : ((((m0_xa[LANE][42:41] == 2'd0 && m0_xa[LANE][26:0] == 0) && (m0_xb[LANE][42:41] == 2'd0 && m0_xb[LANE][26:0] == 0)) ? (m0_aLANE[15] == 1'b1 || m0_aLANE[15] == m0_bLANE[15]) : (m0_fc_ltLANE || m0_fc_eqLANE)) ? m0_aLANE : m0_bLANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_xa[LANE][42:41] == 2'd1) || (m0_xb[LANE][42:41] == 2'd1)) ? (((10'd1 << 9)) | ((((m0_xa[LANE][42:41] == 2'd1) && !m0_aLANE[9]) || ((m0_xb[LANE][42:41] == 2'd1) && !m0_bLANE[9])) ? (10'd1 << 0) : 10'd0) | ((1'b0 || ((m0_xa[LANE][42:41] == 2'd1) && (m0_xb[LANE][42:41] == 2'd1))) ? (10'd1 << 5) : 10'd0)) : 10'd0) | (m0_dena[LANE] | m0_denb[LANE] ? (10'd1 << 6) : 10'd0);
      end
      3'd4: begin
        m0_fc_xaLANE = m0_xa[LANE]; m0_fc_xbLANE = m0_xb[LANE];
        y_m0[((LANE*16)+0) +: 16] = ((m0_xa[LANE][42:41] == 2'd1) && (m0_xb[LANE][42:41] == 2'd1)) ? (1'b0 ? ((m0_xa[LANE][42:41] == 2'd1) ? m0_aLANE : m0_bLANE) : 16'd32256) : (m0_xa[LANE][42:41] == 2'd1) ? m0_bLANE : (m0_xb[LANE][42:41] == 2'd1) ? m0_aLANE : ((((m0_xa[LANE][42:41] == 2'd0 && m0_xa[LANE][26:0] == 0) && (m0_xb[LANE][42:41] == 2'd0 && m0_xb[LANE][26:0] == 0)) ? (m0_aLANE[15] == 1'b0 || m0_aLANE[15] == m0_bLANE[15]) : ((!m0_fc_ltLANE && !m0_fc_eqLANE) || m0_fc_eqLANE)) ? m0_aLANE : m0_bLANE);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_xa[LANE][42:41] == 2'd1) || (m0_xb[LANE][42:41] == 2'd1)) ? (((10'd1 << 9)) | ((((m0_xa[LANE][42:41] == 2'd1) && !m0_aLANE[9]) || ((m0_xb[LANE][42:41] == 2'd1) && !m0_bLANE[9])) ? (10'd1 << 0) : 10'd0) | ((1'b0 || ((m0_xa[LANE][42:41] == 2'd1) && (m0_xb[LANE][42:41] == 2'd1))) ? (10'd1 << 5) : 10'd0)) : 10'd0) | (m0_dena[LANE] | m0_denb[LANE] ? (10'd1 << 6) : 10'd0);
      end
      3'd5: begin
        m0_fc_xaLANE = m0_xa[LANE]; m0_fc_xbLANE = m0_xb[LANE];
        y_m0[((LANE*16)+0) +: 16] = ((m0_xa[LANE][42:41] == 2'd1) || (m0_xb[LANE][42:41] == 2'd1)) ? 16'd0 : {{13{1'b0}}, ((!m0_fc_ltLANE && !m0_fc_eqLANE)), (m0_fc_eqLANE), (m0_fc_ltLANE)};
        fl_m0[(0+LANE)*10 +: 10] = ((m0_xa[LANE][42:41] == 2'd1) || (m0_xb[LANE][42:41] == 2'd1) ? (10'd1 << 9) : 10'd0) | ((((m0_xa[LANE][42:41] == 2'd1) && !m0_aLANE[9]) || ((m0_xb[LANE][42:41] == 2'd1) && !m0_bLANE[9])) ? (10'd1 << 0) : 10'd0) | (m0_dena[LANE] | m0_denb[LANE] ? (10'd1 << 6) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_fp_multiplier #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0,
  input  logic [42:0] xa_m0,
  input  logic [42:0] xb_m0,
  input  logic [0:0] dena_m0,
  input  logic [0:0] denb_m0,
  output logic [42:0] x_m0
);
  // alu_core_m0_fp_multiplier: lane LANE of mode 0 (fp16) for the fp_multiplier ops fmul; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [27:0] m0_uaLANE;
  logic [27:0] m0_ubLANE;
  logic [42:0] m0_xa [0:0];
  logic m0_dena [0:0];
  logic [42:0] m0_xb [0:0];
  logic m0_denb [0:0];
  logic [42:0] m0_fm_xaLANE;
  logic [42:0] m0_fm_xbLANE;
  logic [42:0] m0_fm_yLANE;
  logic [25:0] m0_o2t0_LANE;
  logic [42:0] m0_o2t0_LANE_x;
  logic [42:0] m0_o2t0_LANE_z;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_uaLANE = m0_unpack_s(m0_aLANE, daz);
  assign m0_ubLANE = m0_unpack_s(m0_bLANE, daz);
  assign m0_xa[LANE] = xa_m0[LANE*43 +: 43];
  assign m0_dena[LANE] = dena_m0[LANE];
  assign m0_xb[LANE] = xb_m0[LANE*43 +: 43];
  assign m0_denb[LANE] = denb_m0[LANE];
  // structure core.fp_multiplier.m0: family sig_mul_then_round realized by the library module fam_fp_mul_sig_mul_then_round_x26e13s11_pd2d07246771c
  fam_fp_mul_sig_mul_then_round_x26e13s11_pd2d07246771c u_m0_fmulLANE (.xa(m0_fm_xaLANE), .xb(m0_fm_xbLANE), .y(m0_fm_yLANE));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_fm_xaLANE = 'x; m0_fm_xbLANE = 'x; m0_o2t0_LANE = 'x; m0_o2t0_LANE_x = 'x; m0_o2t0_LANE_z = 'x;
    x_m0 = '0;
    case (op)
      3'd2: begin
        m0_fm_xaLANE = m0_xa[LANE]; m0_fm_xbLANE = m0_xb[LANE]; m0_o2t0_LANE_x = m0_fm_yLANE;
        m0_o2t0_LANE_z = { m0_o2t0_LANE_x[42:41], (m0_o2t0_LANE_x[42:41] == 2'd0 && m0_o2t0_LANE_x[26:0] == 0) ? (m0_aLANE[15] ^ m0_bLANE[15]) : m0_o2t0_LANE_x[40], m0_o2t0_LANE_x[39:0] };
        x_m0[LANE*43 +: 43] = m0_o2t0_LANE_z;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_rounder #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0,
  input  logic [42:0] xa_m0,
  input  logic [42:0] xb_m0,
  input  logic [0:0] dena_m0,
  input  logic [0:0] denb_m0,
  input  logic [42:0] x_m0
);
  // alu_core_m0_rounder: lane LANE of mode 0 (fp16) for the rounder ops fadd, fsub, fmul; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic d_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [27:0] m0_uaLANE;
  logic [27:0] m0_ubLANE;
  logic [42:0] m0_xa [0:0];
  logic m0_dena [0:0];
  logic [42:0] m0_xb [0:0];
  logic m0_denb [0:0];
  logic [42:0] m0_rd_xLANE_fadd;
  logic [7:0] m0_rd_wLANE_fadd;
  logic [9:0] m0_rd_flLANE_fadd;
  logic [15:0] m0_rd_bLANE_fadd;
  logic [42:0] m0_rd_xLANE_fmul;
  logic [7:0] m0_rd_wLANE_fmul;
  logic [9:0] m0_rd_flLANE_fmul;
  logic [15:0] m0_rd_bLANE_fmul;
  logic [42:0] m0_rd_xLANE_fsub;
  logic [7:0] m0_rd_wLANE_fsub;
  logic [9:0] m0_rd_flLANE_fsub;
  logic [15:0] m0_rd_bLANE_fsub;
  logic [25:0] m0_o0t0_LANE;
  logic [42:0] m0_o0t0_LANE_x;
  logic [42:0] m0_o0t0_LANE_z;
  logic [25:0] m0_o1t0_LANE;
  logic [42:0] m0_o1t0_LANE_x;
  logic [42:0] m0_o1t0_LANE_z;
  logic [25:0] m0_o2t0_LANE;
  logic [42:0] m0_o2t0_LANE_x;
  logic [42:0] m0_o2t0_LANE_z;
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  assign m0_uaLANE = m0_unpack_s(m0_aLANE, daz);
  assign m0_ubLANE = m0_unpack_s(m0_bLANE, daz);
  assign m0_xa[LANE] = xa_m0[LANE*43 +: 43];
  assign m0_dena[LANE] = dena_m0[LANE];
  assign m0_xb[LANE] = xb_m0[LANE*43 +: 43];
  assign m0_denb[LANE] = denb_m0[LANE];
  // structure core.rounder.m0: family dedicated_per_op realized by the library module fam_fp_round_dedicated_per_op_injection_fp16_x26e13s11_p511c8e3eed31 (fadd)
  fam_fp_round_dedicated_per_op_injection_fp16_x26e13s11_p511c8e3eed31 u_m0_roundLANE_fadd (.x(m0_rd_xLANE_fadd), .rnd(rnd), .word(m0_rd_wLANE_fadd), .ftz(ftz), .fl(m0_rd_flLANE_fadd), .bits(m0_rd_bLANE_fadd));
  // structure core.rounder.m0: family dedicated_per_op realized by the library module fam_fp_round_dedicated_per_op_injection_fp16_x26e13s11_p511c8e3eed31 (fmul)
  fam_fp_round_dedicated_per_op_injection_fp16_x26e13s11_p511c8e3eed31 u_m0_roundLANE_fmul (.x(m0_rd_xLANE_fmul), .rnd(rnd), .word(m0_rd_wLANE_fmul), .ftz(ftz), .fl(m0_rd_flLANE_fmul), .bits(m0_rd_bLANE_fmul));
  // structure core.rounder.m0: family dedicated_per_op realized by the library module fam_fp_round_dedicated_per_op_injection_fp16_x26e13s11_p511c8e3eed31 (fsub)
  fam_fp_round_dedicated_per_op_injection_fp16_x26e13s11_p511c8e3eed31 u_m0_roundLANE_fsub (.x(m0_rd_xLANE_fsub), .rnd(rnd), .word(m0_rd_wLANE_fsub), .ftz(ftz), .fl(m0_rd_flLANE_fsub), .bits(m0_rd_bLANE_fsub));
  always_comb begin
    y_m0 = '0; d_m0 = '0; fl_m0 = '0;
    m0_rd_xLANE_fadd = 'x; m0_rd_wLANE_fadd = 'x; m0_rd_xLANE_fmul = 'x; m0_rd_wLANE_fmul = 'x; m0_rd_xLANE_fsub = 'x; m0_rd_wLANE_fsub = 'x;
    m0_o0t0_LANE = 'x; m0_o0t0_LANE_x = 'x; m0_o0t0_LANE_z = 'x; m0_o1t0_LANE = 'x; m0_o1t0_LANE_x = 'x; m0_o1t0_LANE_z = 'x;
    m0_o2t0_LANE = 'x; m0_o2t0_LANE_x = 'x; m0_o2t0_LANE_z = 'x;
    case (op)
      3'd0: begin
        m0_o0t0_LANE_z = x_m0[LANE*43 +: 43];
        m0_rd_xLANE_fadd = m0_o0t0_LANE_z; m0_rd_wLANE_fadd = 8'd0; m0_o0t0_LANE = {m0_rd_flLANE_fadd, m0_rd_bLANE_fadd};
        y_m0[((LANE*16)+0) +: 16] = (m0_o0t0_LANE_z[42:41] == 2'd1) ? (((m0_xa[LANE][42:41] == 2'd1) || (m0_xb[LANE][42:41] == 2'd1)) ? 16'd32256 : 16'd32256) : ((m0_o0t0_LANE_z[42:41] == 2'd0 && m0_o0t0_LANE_z[26:0] == 0) ? {m0_o0t0_LANE_z[40], 15'd0} : m0_o0t0_LANE[15:0]);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_xa[LANE][42:41] == 2'd1) || (m0_xb[LANE][42:41] == 2'd1)) ? (((10'd1 << 5) | (((m0_xa[LANE][42:41] == 2'd1) && !m0_aLANE[9]) || ((m0_xb[LANE][42:41] == 2'd1) && !m0_bLANE[9]) ? (10'd1 << 0) : 10'd0)) | (m0_dena[LANE] | m0_denb[LANE] ? (10'd1 << 6) : 10'd0)) : (m0_o0t0_LANE[25:16] | ((((m0_xa[LANE][42:41] == 2'd1) && !m0_aLANE[9]) || ((m0_xb[LANE][42:41] == 2'd1) && !m0_bLANE[9]) || ((m0_o0t0_LANE_z[42:41] == 2'd1) && !((m0_xa[LANE][42:41] == 2'd1) || (m0_xb[LANE][42:41] == 2'd1)))) ? (10'd1 << 0) : 10'd0) | (m0_dena[LANE] | m0_denb[LANE] ? (10'd1 << 6) : 10'd0)));
      end
      3'd1: begin
        m0_o1t0_LANE_z = x_m0[LANE*43 +: 43];
        m0_rd_xLANE_fsub = m0_o1t0_LANE_z; m0_rd_wLANE_fsub = 8'd0; m0_o1t0_LANE = {m0_rd_flLANE_fsub, m0_rd_bLANE_fsub};
        y_m0[((LANE*16)+0) +: 16] = (m0_o1t0_LANE_z[42:41] == 2'd1) ? (((m0_xa[LANE][42:41] == 2'd1) || (m0_xb[LANE][42:41] == 2'd1)) ? 16'd32256 : 16'd32256) : ((m0_o1t0_LANE_z[42:41] == 2'd0 && m0_o1t0_LANE_z[26:0] == 0) ? {m0_o1t0_LANE_z[40], 15'd0} : m0_o1t0_LANE[15:0]);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_xa[LANE][42:41] == 2'd1) || (m0_xb[LANE][42:41] == 2'd1)) ? (((10'd1 << 5) | (((m0_xa[LANE][42:41] == 2'd1) && !m0_aLANE[9]) || ((m0_xb[LANE][42:41] == 2'd1) && !m0_bLANE[9]) ? (10'd1 << 0) : 10'd0)) | (m0_dena[LANE] | m0_denb[LANE] ? (10'd1 << 6) : 10'd0)) : (m0_o1t0_LANE[25:16] | ((((m0_xa[LANE][42:41] == 2'd1) && !m0_aLANE[9]) || ((m0_xb[LANE][42:41] == 2'd1) && !m0_bLANE[9]) || ((m0_o1t0_LANE_z[42:41] == 2'd1) && !((m0_xa[LANE][42:41] == 2'd1) || (m0_xb[LANE][42:41] == 2'd1)))) ? (10'd1 << 0) : 10'd0) | (m0_dena[LANE] | m0_denb[LANE] ? (10'd1 << 6) : 10'd0)));
      end
      3'd2: begin
        m0_o2t0_LANE_z = x_m0[LANE*43 +: 43];
        m0_rd_xLANE_fmul = m0_o2t0_LANE_z; m0_rd_wLANE_fmul = 8'd0; m0_o2t0_LANE = {m0_rd_flLANE_fmul, m0_rd_bLANE_fmul};
        y_m0[((LANE*16)+0) +: 16] = (m0_o2t0_LANE_z[42:41] == 2'd1) ? (((m0_xa[LANE][42:41] == 2'd1) || (m0_xb[LANE][42:41] == 2'd1)) ? 16'd32256 : 16'd32256) : ((m0_o2t0_LANE_z[42:41] == 2'd0 && m0_o2t0_LANE_z[26:0] == 0) ? {m0_o2t0_LANE_z[40], 15'd0} : m0_o2t0_LANE[15:0]);
        fl_m0[(0+LANE)*10 +: 10] = (((m0_xa[LANE][42:41] == 2'd1) || (m0_xb[LANE][42:41] == 2'd1)) ? (((10'd1 << 5) | (((m0_xa[LANE][42:41] == 2'd1) && !m0_aLANE[9]) || ((m0_xb[LANE][42:41] == 2'd1) && !m0_bLANE[9]) ? (10'd1 << 0) : 10'd0)) | (m0_dena[LANE] | m0_denb[LANE] ? (10'd1 << 6) : 10'd0)) : (m0_o2t0_LANE[25:16] | ((((m0_xa[LANE][42:41] == 2'd1) && !m0_aLANE[9]) || ((m0_xb[LANE][42:41] == 2'd1) && !m0_bLANE[9]) || ((m0_o2t0_LANE_z[42:41] == 2'd1) && !((m0_xa[LANE][42:41] == 2'd1) || (m0_xb[LANE][42:41] == 2'd1)))) ? (10'd1 << 0) : 10'd0) | (m0_dena[LANE] | m0_denb[LANE] ? (10'd1 << 6) : 10'd0)));
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m0_unpacker #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [42:0] xa_m0,
  output logic [42:0] xb_m0,
  output logic [0:0] dena_m0,
  output logic [0:0] denb_m0
);
  // alu_core_m0_unpacker: lane LANE of mode 0 (fp16) for the unpacker ops ; the result buses are the mode's, with only this lane's bits written
  import alu_core_m0_pkg::*;
  logic [15:0] y_m0;
  logic d_m0;
  logic [19:0] fl_m0;
  logic [15:0] m0_aLANE;
  logic [15:0] m0_bLANE;
  logic [27:0] m0_uaLANE;
  logic [27:0] m0_ubLANE;
  logic [42:0] m0_xa [0:0];
  logic m0_dena [0:0];
  logic [42:0] m0_xb [0:0];
  logic m0_denb [0:0];
  assign m0_aLANE = a[(LANE*16) +: 16];
  assign m0_bLANE = b[(LANE*16) +: 16];
  // structure core.unpacker.m0: family shared_per_lane realized by the library module fam_fp_unpack_shared_per_lane_fp16_x26e13s11_p68f91d4e9d3f
  fam_fp_unpack_shared_per_lane_fp16_x26e13s11_p68f91d4e9d3f u_m0_unpack_aLANE (.b(m0_aLANE), .daz(daz), .u(m0_uaLANE));
  // structure core.unpacker.m0: family shared_per_lane realized by the library module fam_fp_unpack_shared_per_lane_fp16_x26e13s11_p68f91d4e9d3f
  fam_fp_unpack_shared_per_lane_fp16_x26e13s11_p68f91d4e9d3f u_m0_unpack_bLANE (.b(m0_bLANE), .daz(daz), .u(m0_ubLANE));
  assign m0_xa[LANE] = m0_x(m0_uaLANE[26:0]);
  assign m0_dena[LANE] = m0_uaLANE[27];
  assign m0_xb[LANE] = m0_x(m0_ubLANE[26:0]);
  assign m0_denb[LANE] = m0_ubLANE[27];
  always_comb begin
    xa_m0 = '0; dena_m0 = '0; xb_m0 = '0; denb_m0 = '0;
    xa_m0[LANE*43 +: 43] = m0_xa[LANE];
    dena_m0[LANE] = m0_dena[LANE];
    xb_m0[LANE*43 +: 43] = m0_xb[LANE];
    denb_m0[LANE] = m0_denb[LANE];
  end
endmodule

module alu_core_m1_fp_adder_fp_fma_fp_multiplier #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1,
  input  logic [39:0] xa_m1,
  input  logic [39:0] xb_m1,
  input  logic [0:0] dena_m1,
  input  logic [0:0] denb_m1,
  output logic [39:0] x_m1
);
  // alu_core_m1_fp_adder_fp_fma_fp_multiplier: lane LANE of mode 1 (bf16) for the fp_adder/fp_fma/fp_multiplier ops fadd, fsub, fmul; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [27:0] m1_uaLANE;
  logic [27:0] m1_ubLANE;
  logic [39:0] m1_xa [0:0];
  logic m1_dena [0:0];
  logic [39:0] m1_xb [0:0];
  logic m1_denb [0:0];
  logic [39:0] m1_ff_xaLANE;
  logic [39:0] m1_ff_xbLANE;
  logic [39:0] m1_ff_xcLANE;
  logic [2:0] m1_ff_opLANE;
  logic [39:0] m1_ff_yLANE;
  logic [25:0] m1_o0t0_LANE;
  logic [39:0] m1_o0t0_LANE_x;
  logic [39:0] m1_o0t0_LANE_z;
  logic [25:0] m1_o1t0_LANE;
  logic [39:0] m1_o1t0_LANE_x;
  logic [39:0] m1_o1t0_LANE_z;
  logic [25:0] m1_o2t0_LANE;
  logic [39:0] m1_o2t0_LANE_x;
  logic [39:0] m1_o2t0_LANE_z;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_uaLANE = m1_unpack_s(m1_aLANE, daz);
  assign m1_ubLANE = m1_unpack_s(m1_bLANE, daz);
  assign m1_xa[LANE] = xa_m1[LANE*40 +: 40];
  assign m1_dena[LANE] = dena_m1[LANE];
  assign m1_xb[LANE] = xb_m1[LANE*40 +: 40];
  assign m1_denb[LANE] = denb_m1[LANE];
  // structure core.fp_fma.m1: family reduced_latency_fma realized by the library module fam_fp_fma_reduced_latency_fma_x20e16s8_p3ef0d7160561; the fadd, fsub and fmul of structures core.fp_adder.m1 and core.fp_multiplier.m1 go through it
  fam_fp_fma_reduced_latency_fma_x20e16s8_p3ef0d7160561 u_m1_ffmaLANE (.xa(m1_ff_xaLANE), .xb(m1_ff_xbLANE), .xc(m1_ff_xcLANE), .fop(m1_ff_opLANE), .rnd(rnd), .y(m1_ff_yLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_ff_xaLANE = 'x; m1_ff_xbLANE = 'x; m1_ff_xcLANE = 'x; m1_ff_opLANE = 'x; m1_o0t0_LANE = 'x; m1_o0t0_LANE_x = 'x;
    m1_o0t0_LANE_z = 'x; m1_o1t0_LANE = 'x; m1_o1t0_LANE_x = 'x; m1_o1t0_LANE_z = 'x; m1_o2t0_LANE = 'x; m1_o2t0_LANE_x = 'x;
    m1_o2t0_LANE_z = 'x;
    x_m1 = '0;
    case (op)
      3'd0: begin
        m1_ff_xaLANE = m1_xa[LANE]; m1_ff_xbLANE = m1_xb[LANE]; m1_ff_opLANE = 3'd0; m1_o0t0_LANE_x = m1_ff_yLANE;
        m1_o0t0_LANE_z = { m1_o0t0_LANE_x[39:38], (m1_o0t0_LANE_x[39:38] == 2'd0 && m1_o0t0_LANE_x[20:0] == 0) ? (((m1_xa[LANE][39:38] == 2'd0 && m1_xa[LANE][20:0] == 0) && (m1_xb[LANE][39:38] == 2'd0 && m1_xb[LANE][20:0] == 0)) ? ((rnd == 3'd2) ? (m1_aLANE[15] | (m1_bLANE[15] ^ 1'b0)) : (m1_aLANE[15] & (m1_bLANE[15] ^ 1'b0))) : ((rnd == 3'd2) ? 1'b1 : 1'b0)) : m1_o0t0_LANE_x[37], m1_o0t0_LANE_x[36:0] };
        x_m1[LANE*40 +: 40] = m1_o0t0_LANE_z;
      end
      3'd1: begin
        m1_ff_xaLANE = m1_xa[LANE]; m1_ff_xbLANE = m1_xb[LANE]; m1_ff_opLANE = 3'd1; m1_o1t0_LANE_x = m1_ff_yLANE;
        m1_o1t0_LANE_z = { m1_o1t0_LANE_x[39:38], (m1_o1t0_LANE_x[39:38] == 2'd0 && m1_o1t0_LANE_x[20:0] == 0) ? (((m1_xa[LANE][39:38] == 2'd0 && m1_xa[LANE][20:0] == 0) && (m1_xb[LANE][39:38] == 2'd0 && m1_xb[LANE][20:0] == 0)) ? ((rnd == 3'd2) ? (m1_aLANE[15] | (m1_bLANE[15] ^ 1'b1)) : (m1_aLANE[15] & (m1_bLANE[15] ^ 1'b1))) : ((rnd == 3'd2) ? 1'b1 : 1'b0)) : m1_o1t0_LANE_x[37], m1_o1t0_LANE_x[36:0] };
        x_m1[LANE*40 +: 40] = m1_o1t0_LANE_z;
      end
      3'd2: begin
        m1_ff_xaLANE = m1_xa[LANE]; m1_ff_xbLANE = m1_xb[LANE]; m1_ff_opLANE = 3'd2; m1_o2t0_LANE_x = m1_ff_yLANE;
        m1_o2t0_LANE_z = { m1_o2t0_LANE_x[39:38], (m1_o2t0_LANE_x[39:38] == 2'd0 && m1_o2t0_LANE_x[20:0] == 0) ? (m1_aLANE[15] ^ m1_bLANE[15]) : m1_o2t0_LANE_x[37], m1_o2t0_LANE_x[36:0] };
        x_m1[LANE*40 +: 40] = m1_o2t0_LANE_z;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_fp_comparator #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1,
  input  logic [39:0] xa_m1,
  input  logic [39:0] xb_m1,
  input  logic [0:0] dena_m1,
  input  logic [0:0] denb_m1
);
  // alu_core_m1_fp_comparator: lane LANE of mode 1 (bf16) for the fp_comparator ops fmin, fmax, fcmp; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [27:0] m1_uaLANE;
  logic [27:0] m1_ubLANE;
  logic [39:0] m1_xa [0:0];
  logic m1_dena [0:0];
  logic [39:0] m1_xb [0:0];
  logic m1_denb [0:0];
  logic [39:0] m1_fc_xaLANE;
  logic [39:0] m1_fc_xbLANE;
  logic m1_fc_ltLANE;
  logic m1_fc_eqLANE;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_uaLANE = m1_unpack_s(m1_aLANE, daz);
  assign m1_ubLANE = m1_unpack_s(m1_bLANE, daz);
  assign m1_xa[LANE] = xa_m1[LANE*40 +: 40];
  assign m1_dena[LANE] = dena_m1[LANE];
  assign m1_xb[LANE] = xb_m1[LANE*40 +: 40];
  assign m1_denb[LANE] = denb_m1[LANE];
  // structure core.fp_comparator.m1: family dedicated_magnitude_comparator realized by the library module fam_fp_cmp_dedicated_magnitude_comparator_x20e16s8_pd5e3e6118bdf
  fam_fp_cmp_dedicated_magnitude_comparator_x20e16s8_pd5e3e6118bdf u_m1_fcmpLANE (.xa(m1_fc_xaLANE), .xb(m1_fc_xbLANE), .lt(m1_fc_ltLANE), .eq(m1_fc_eqLANE));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_fc_xaLANE = 'x; m1_fc_xbLANE = 'x;
    case (op)
      3'd3: begin
        m1_fc_xaLANE = m1_xa[LANE]; m1_fc_xbLANE = m1_xb[LANE];
        y_m1[((LANE*16)+0) +: 16] = ((m1_xa[LANE][39:38] == 2'd1) && (m1_xb[LANE][39:38] == 2'd1)) ? (1'b0 ? ((m1_xa[LANE][39:38] == 2'd1) ? m1_aLANE : m1_bLANE) : 16'd32704) : (m1_xa[LANE][39:38] == 2'd1) ? m1_bLANE : (m1_xb[LANE][39:38] == 2'd1) ? m1_aLANE : ((((m1_xa[LANE][39:38] == 2'd0 && m1_xa[LANE][20:0] == 0) && (m1_xb[LANE][39:38] == 2'd0 && m1_xb[LANE][20:0] == 0)) ? (m1_aLANE[15] == 1'b1 || m1_aLANE[15] == m1_bLANE[15]) : (m1_fc_ltLANE || m1_fc_eqLANE)) ? m1_aLANE : m1_bLANE);
        fl_m1[(0+LANE)*10 +: 10] = (((m1_xa[LANE][39:38] == 2'd1) || (m1_xb[LANE][39:38] == 2'd1)) ? (((10'd1 << 9)) | ((((m1_xa[LANE][39:38] == 2'd1) && !m1_aLANE[6]) || ((m1_xb[LANE][39:38] == 2'd1) && !m1_bLANE[6])) ? (10'd1 << 0) : 10'd0) | ((1'b0 || ((m1_xa[LANE][39:38] == 2'd1) && (m1_xb[LANE][39:38] == 2'd1))) ? (10'd1 << 5) : 10'd0)) : 10'd0) | (m1_dena[LANE] | m1_denb[LANE] ? (10'd1 << 6) : 10'd0);
      end
      3'd4: begin
        m1_fc_xaLANE = m1_xa[LANE]; m1_fc_xbLANE = m1_xb[LANE];
        y_m1[((LANE*16)+0) +: 16] = ((m1_xa[LANE][39:38] == 2'd1) && (m1_xb[LANE][39:38] == 2'd1)) ? (1'b0 ? ((m1_xa[LANE][39:38] == 2'd1) ? m1_aLANE : m1_bLANE) : 16'd32704) : (m1_xa[LANE][39:38] == 2'd1) ? m1_bLANE : (m1_xb[LANE][39:38] == 2'd1) ? m1_aLANE : ((((m1_xa[LANE][39:38] == 2'd0 && m1_xa[LANE][20:0] == 0) && (m1_xb[LANE][39:38] == 2'd0 && m1_xb[LANE][20:0] == 0)) ? (m1_aLANE[15] == 1'b0 || m1_aLANE[15] == m1_bLANE[15]) : ((!m1_fc_ltLANE && !m1_fc_eqLANE) || m1_fc_eqLANE)) ? m1_aLANE : m1_bLANE);
        fl_m1[(0+LANE)*10 +: 10] = (((m1_xa[LANE][39:38] == 2'd1) || (m1_xb[LANE][39:38] == 2'd1)) ? (((10'd1 << 9)) | ((((m1_xa[LANE][39:38] == 2'd1) && !m1_aLANE[6]) || ((m1_xb[LANE][39:38] == 2'd1) && !m1_bLANE[6])) ? (10'd1 << 0) : 10'd0) | ((1'b0 || ((m1_xa[LANE][39:38] == 2'd1) && (m1_xb[LANE][39:38] == 2'd1))) ? (10'd1 << 5) : 10'd0)) : 10'd0) | (m1_dena[LANE] | m1_denb[LANE] ? (10'd1 << 6) : 10'd0);
      end
      3'd5: begin
        m1_fc_xaLANE = m1_xa[LANE]; m1_fc_xbLANE = m1_xb[LANE];
        y_m1[((LANE*16)+0) +: 16] = ((m1_xa[LANE][39:38] == 2'd1) || (m1_xb[LANE][39:38] == 2'd1)) ? 16'd0 : {{13{1'b0}}, ((!m1_fc_ltLANE && !m1_fc_eqLANE)), (m1_fc_eqLANE), (m1_fc_ltLANE)};
        fl_m1[(0+LANE)*10 +: 10] = ((m1_xa[LANE][39:38] == 2'd1) || (m1_xb[LANE][39:38] == 2'd1) ? (10'd1 << 9) : 10'd0) | ((((m1_xa[LANE][39:38] == 2'd1) && !m1_aLANE[6]) || ((m1_xb[LANE][39:38] == 2'd1) && !m1_bLANE[6])) ? (10'd1 << 0) : 10'd0) | (m1_dena[LANE] | m1_denb[LANE] ? (10'd1 << 6) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_rounder #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1,
  input  logic [39:0] xa_m1,
  input  logic [39:0] xb_m1,
  input  logic [0:0] dena_m1,
  input  logic [0:0] denb_m1,
  input  logic [39:0] x_m1
);
  // alu_core_m1_rounder: lane LANE of mode 1 (bf16) for the rounder ops fadd, fsub, fmul; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic d_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [27:0] m1_uaLANE;
  logic [27:0] m1_ubLANE;
  logic [39:0] m1_xa [0:0];
  logic m1_dena [0:0];
  logic [39:0] m1_xb [0:0];
  logic m1_denb [0:0];
  logic [39:0] m1_rd_xLANE_fadd;
  logic [7:0] m1_rd_wLANE_fadd;
  logic [9:0] m1_rd_flLANE_fadd;
  logic [15:0] m1_rd_bLANE_fadd;
  logic [39:0] m1_rd_xLANE_fmul;
  logic [7:0] m1_rd_wLANE_fmul;
  logic [9:0] m1_rd_flLANE_fmul;
  logic [15:0] m1_rd_bLANE_fmul;
  logic [39:0] m1_rd_xLANE_fsub;
  logic [7:0] m1_rd_wLANE_fsub;
  logic [9:0] m1_rd_flLANE_fsub;
  logic [15:0] m1_rd_bLANE_fsub;
  logic [25:0] m1_o0t0_LANE;
  logic [39:0] m1_o0t0_LANE_x;
  logic [39:0] m1_o0t0_LANE_z;
  logic [25:0] m1_o1t0_LANE;
  logic [39:0] m1_o1t0_LANE_x;
  logic [39:0] m1_o1t0_LANE_z;
  logic [25:0] m1_o2t0_LANE;
  logic [39:0] m1_o2t0_LANE_x;
  logic [39:0] m1_o2t0_LANE_z;
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  assign m1_uaLANE = m1_unpack_s(m1_aLANE, daz);
  assign m1_ubLANE = m1_unpack_s(m1_bLANE, daz);
  assign m1_xa[LANE] = xa_m1[LANE*40 +: 40];
  assign m1_dena[LANE] = dena_m1[LANE];
  assign m1_xb[LANE] = xb_m1[LANE*40 +: 40];
  assign m1_denb[LANE] = denb_m1[LANE];
  // structure core.rounder.m1: family dedicated_per_op realized by the library module fam_fp_round_dedicated_per_op_compound_adder_select_bf16_x20e16s8_p925d37aacdb3 (fadd)
  fam_fp_round_dedicated_per_op_compound_adder_select_bf16_x20e16s8_p925d37aacdb3 u_m1_roundLANE_fadd (.x(m1_rd_xLANE_fadd), .rnd(rnd), .word(m1_rd_wLANE_fadd), .ftz(ftz), .fl(m1_rd_flLANE_fadd), .bits(m1_rd_bLANE_fadd));
  // structure core.rounder.m1: family dedicated_per_op realized by the library module fam_fp_round_dedicated_per_op_compound_adder_select_bf16_x20e16s8_p925d37aacdb3 (fmul)
  fam_fp_round_dedicated_per_op_compound_adder_select_bf16_x20e16s8_p925d37aacdb3 u_m1_roundLANE_fmul (.x(m1_rd_xLANE_fmul), .rnd(rnd), .word(m1_rd_wLANE_fmul), .ftz(ftz), .fl(m1_rd_flLANE_fmul), .bits(m1_rd_bLANE_fmul));
  // structure core.rounder.m1: family dedicated_per_op realized by the library module fam_fp_round_dedicated_per_op_compound_adder_select_bf16_x20e16s8_p925d37aacdb3 (fsub)
  fam_fp_round_dedicated_per_op_compound_adder_select_bf16_x20e16s8_p925d37aacdb3 u_m1_roundLANE_fsub (.x(m1_rd_xLANE_fsub), .rnd(rnd), .word(m1_rd_wLANE_fsub), .ftz(ftz), .fl(m1_rd_flLANE_fsub), .bits(m1_rd_bLANE_fsub));
  always_comb begin
    y_m1 = '0; d_m1 = '0; fl_m1 = '0;
    m1_rd_xLANE_fadd = 'x; m1_rd_wLANE_fadd = 'x; m1_rd_xLANE_fmul = 'x; m1_rd_wLANE_fmul = 'x; m1_rd_xLANE_fsub = 'x; m1_rd_wLANE_fsub = 'x;
    m1_o0t0_LANE = 'x; m1_o0t0_LANE_x = 'x; m1_o0t0_LANE_z = 'x; m1_o1t0_LANE = 'x; m1_o1t0_LANE_x = 'x; m1_o1t0_LANE_z = 'x;
    m1_o2t0_LANE = 'x; m1_o2t0_LANE_x = 'x; m1_o2t0_LANE_z = 'x;
    case (op)
      3'd0: begin
        m1_o0t0_LANE_z = x_m1[LANE*40 +: 40];
        m1_rd_xLANE_fadd = m1_o0t0_LANE_z; m1_rd_wLANE_fadd = 8'd0; m1_o0t0_LANE = {m1_rd_flLANE_fadd, m1_rd_bLANE_fadd};
        y_m1[((LANE*16)+0) +: 16] = (m1_o0t0_LANE_z[39:38] == 2'd1) ? (((m1_xa[LANE][39:38] == 2'd1) || (m1_xb[LANE][39:38] == 2'd1)) ? 16'd32704 : 16'd32704) : ((m1_o0t0_LANE_z[39:38] == 2'd0 && m1_o0t0_LANE_z[20:0] == 0) ? {m1_o0t0_LANE_z[37], 15'd0} : m1_o0t0_LANE[15:0]);
        fl_m1[(0+LANE)*10 +: 10] = (((m1_xa[LANE][39:38] == 2'd1) || (m1_xb[LANE][39:38] == 2'd1)) ? (((10'd1 << 5) | (((m1_xa[LANE][39:38] == 2'd1) && !m1_aLANE[6]) || ((m1_xb[LANE][39:38] == 2'd1) && !m1_bLANE[6]) ? (10'd1 << 0) : 10'd0)) | (m1_dena[LANE] | m1_denb[LANE] ? (10'd1 << 6) : 10'd0)) : (m1_o0t0_LANE[25:16] | ((((m1_xa[LANE][39:38] == 2'd1) && !m1_aLANE[6]) || ((m1_xb[LANE][39:38] == 2'd1) && !m1_bLANE[6]) || ((m1_o0t0_LANE_z[39:38] == 2'd1) && !((m1_xa[LANE][39:38] == 2'd1) || (m1_xb[LANE][39:38] == 2'd1)))) ? (10'd1 << 0) : 10'd0) | (m1_dena[LANE] | m1_denb[LANE] ? (10'd1 << 6) : 10'd0)));
      end
      3'd1: begin
        m1_o1t0_LANE_z = x_m1[LANE*40 +: 40];
        m1_rd_xLANE_fsub = m1_o1t0_LANE_z; m1_rd_wLANE_fsub = 8'd0; m1_o1t0_LANE = {m1_rd_flLANE_fsub, m1_rd_bLANE_fsub};
        y_m1[((LANE*16)+0) +: 16] = (m1_o1t0_LANE_z[39:38] == 2'd1) ? (((m1_xa[LANE][39:38] == 2'd1) || (m1_xb[LANE][39:38] == 2'd1)) ? 16'd32704 : 16'd32704) : ((m1_o1t0_LANE_z[39:38] == 2'd0 && m1_o1t0_LANE_z[20:0] == 0) ? {m1_o1t0_LANE_z[37], 15'd0} : m1_o1t0_LANE[15:0]);
        fl_m1[(0+LANE)*10 +: 10] = (((m1_xa[LANE][39:38] == 2'd1) || (m1_xb[LANE][39:38] == 2'd1)) ? (((10'd1 << 5) | (((m1_xa[LANE][39:38] == 2'd1) && !m1_aLANE[6]) || ((m1_xb[LANE][39:38] == 2'd1) && !m1_bLANE[6]) ? (10'd1 << 0) : 10'd0)) | (m1_dena[LANE] | m1_denb[LANE] ? (10'd1 << 6) : 10'd0)) : (m1_o1t0_LANE[25:16] | ((((m1_xa[LANE][39:38] == 2'd1) && !m1_aLANE[6]) || ((m1_xb[LANE][39:38] == 2'd1) && !m1_bLANE[6]) || ((m1_o1t0_LANE_z[39:38] == 2'd1) && !((m1_xa[LANE][39:38] == 2'd1) || (m1_xb[LANE][39:38] == 2'd1)))) ? (10'd1 << 0) : 10'd0) | (m1_dena[LANE] | m1_denb[LANE] ? (10'd1 << 6) : 10'd0)));
      end
      3'd2: begin
        m1_o2t0_LANE_z = x_m1[LANE*40 +: 40];
        m1_rd_xLANE_fmul = m1_o2t0_LANE_z; m1_rd_wLANE_fmul = 8'd0; m1_o2t0_LANE = {m1_rd_flLANE_fmul, m1_rd_bLANE_fmul};
        y_m1[((LANE*16)+0) +: 16] = (m1_o2t0_LANE_z[39:38] == 2'd1) ? (((m1_xa[LANE][39:38] == 2'd1) || (m1_xb[LANE][39:38] == 2'd1)) ? 16'd32704 : 16'd32704) : ((m1_o2t0_LANE_z[39:38] == 2'd0 && m1_o2t0_LANE_z[20:0] == 0) ? {m1_o2t0_LANE_z[37], 15'd0} : m1_o2t0_LANE[15:0]);
        fl_m1[(0+LANE)*10 +: 10] = (((m1_xa[LANE][39:38] == 2'd1) || (m1_xb[LANE][39:38] == 2'd1)) ? (((10'd1 << 5) | (((m1_xa[LANE][39:38] == 2'd1) && !m1_aLANE[6]) || ((m1_xb[LANE][39:38] == 2'd1) && !m1_bLANE[6]) ? (10'd1 << 0) : 10'd0)) | (m1_dena[LANE] | m1_denb[LANE] ? (10'd1 << 6) : 10'd0)) : (m1_o2t0_LANE[25:16] | ((((m1_xa[LANE][39:38] == 2'd1) && !m1_aLANE[6]) || ((m1_xb[LANE][39:38] == 2'd1) && !m1_bLANE[6]) || ((m1_o2t0_LANE_z[39:38] == 2'd1) && !((m1_xa[LANE][39:38] == 2'd1) || (m1_xb[LANE][39:38] == 2'd1)))) ? (10'd1 << 0) : 10'd0) | (m1_dena[LANE] | m1_denb[LANE] ? (10'd1 << 6) : 10'd0)));
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m1_unpacker #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [39:0] xa_m1,
  output logic [39:0] xb_m1,
  output logic [0:0] dena_m1,
  output logic [0:0] denb_m1
);
  // alu_core_m1_unpacker: lane LANE of mode 1 (bf16) for the unpacker ops ; the result buses are the mode's, with only this lane's bits written
  import alu_core_m1_pkg::*;
  logic [15:0] y_m1;
  logic d_m1;
  logic [19:0] fl_m1;
  logic [15:0] m1_aLANE;
  logic [15:0] m1_bLANE;
  logic [27:0] m1_uaLANE;
  logic [27:0] m1_ubLANE;
  logic [39:0] m1_xa [0:0];
  logic m1_dena [0:0];
  logic [39:0] m1_xb [0:0];
  logic m1_denb [0:0];
  assign m1_aLANE = a[(LANE*16) +: 16];
  assign m1_bLANE = b[(LANE*16) +: 16];
  // structure core.unpacker.m1: family shared_per_lane realized by the library module fam_fp_unpack_shared_per_lane_bf16_x20e16s8_p9ea5912e1006
  fam_fp_unpack_shared_per_lane_bf16_x20e16s8_p9ea5912e1006 u_m1_unpack_aLANE (.b(m1_aLANE), .daz(daz), .u(m1_uaLANE));
  // structure core.unpacker.m1: family shared_per_lane realized by the library module fam_fp_unpack_shared_per_lane_bf16_x20e16s8_p9ea5912e1006
  fam_fp_unpack_shared_per_lane_bf16_x20e16s8_p9ea5912e1006 u_m1_unpack_bLANE (.b(m1_bLANE), .daz(daz), .u(m1_ubLANE));
  assign m1_xa[LANE] = m1_x(m1_uaLANE[26:0]);
  assign m1_dena[LANE] = m1_uaLANE[27];
  assign m1_xb[LANE] = m1_x(m1_ubLANE[26:0]);
  assign m1_denb[LANE] = m1_ubLANE[27];
  always_comb begin
    xa_m1 = '0; dena_m1 = '0; xb_m1 = '0; denb_m1 = '0;
    xa_m1[LANE*40 +: 40] = m1_xa[LANE];
    dena_m1[LANE] = m1_dena[LANE];
    xb_m1[LANE*40 +: 40] = m1_xb[LANE];
    denb_m1[LANE] = m1_denb[LANE];
  end
endmodule

module alu_core_m2_fp_comparator #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2,
  input  logic [53:0] xa_m2,
  input  logic [53:0] xb_m2,
  input  logic [1:0] dena_m2,
  input  logic [1:0] denb_m2
);
  // alu_core_m2_fp_comparator: lane LANE of mode 2 (fp8e5m2) for the fp_comparator ops fmin, fmax, fcmp; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [19:0] m2_uaLANE;
  logic [19:0] m2_ubLANE;
  logic [26:0] m2_xa [0:1];
  logic m2_dena [0:1];
  logic [26:0] m2_xb [0:1];
  logic m2_denb [0:1];
  logic [26:0] m2_fc_xaLANE;
  logic [26:0] m2_fc_xbLANE;
  logic m2_fc_ltLANE;
  logic m2_fc_eqLANE;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  // structure core.unpacker.m2: family per_unit_unpack realized by the library module fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a
  fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a u_m2_unpack_aLANE (.b(m2_aLANE), .daz(daz), .u(m2_uaLANE));
  // structure core.unpacker.m2: family per_unit_unpack realized by the library module fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a
  fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a u_m2_unpack_bLANE (.b(m2_bLANE), .daz(daz), .u(m2_ubLANE));
  assign m2_xa[LANE] = m2_x(m2_uaLANE[18:0]);
  assign m2_dena[LANE] = m2_uaLANE[19];
  assign m2_xb[LANE] = m2_x(m2_ubLANE[18:0]);
  assign m2_denb[LANE] = m2_ubLANE[19];
  // structure core.fp_comparator.m2: family integer_compare_on_bits realized by the library module fam_fp_cmp_integer_compare_on_bits_x10e13s3_pf4b323d9500d
  fam_fp_cmp_integer_compare_on_bits_x10e13s3_pf4b323d9500d u_m2_fcmpLANE (.xa(m2_fc_xaLANE), .xb(m2_fc_xbLANE), .lt(m2_fc_ltLANE), .eq(m2_fc_eqLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_fc_xaLANE = 'x; m2_fc_xbLANE = 'x;
    case (op)
      3'd3: begin
        m2_fc_xaLANE = m2_xa[LANE]; m2_fc_xbLANE = m2_xb[LANE];
        y_m2[((LANE*8)+0) +: 8] = ((m2_xa[LANE][26:25] == 2'd1) && (m2_xb[LANE][26:25] == 2'd1)) ? (1'b0 ? ((m2_xa[LANE][26:25] == 2'd1) ? m2_aLANE : m2_bLANE) : 8'd126) : (m2_xa[LANE][26:25] == 2'd1) ? m2_bLANE : (m2_xb[LANE][26:25] == 2'd1) ? m2_aLANE : ((((m2_xa[LANE][26:25] == 2'd0 && m2_xa[LANE][10:0] == 0) && (m2_xb[LANE][26:25] == 2'd0 && m2_xb[LANE][10:0] == 0)) ? (m2_aLANE[7] == 1'b1 || m2_aLANE[7] == m2_bLANE[7]) : (m2_fc_ltLANE || m2_fc_eqLANE)) ? m2_aLANE : m2_bLANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_xa[LANE][26:25] == 2'd1) || (m2_xb[LANE][26:25] == 2'd1)) ? (((10'd1 << 9)) | ((((m2_xa[LANE][26:25] == 2'd1) && !m2_aLANE[1]) || ((m2_xb[LANE][26:25] == 2'd1) && !m2_bLANE[1])) ? (10'd1 << 0) : 10'd0) | ((1'b0 || ((m2_xa[LANE][26:25] == 2'd1) && (m2_xb[LANE][26:25] == 2'd1))) ? (10'd1 << 5) : 10'd0)) : 10'd0) | (m2_dena[LANE] | m2_denb[LANE] ? (10'd1 << 6) : 10'd0);
      end
      3'd4: begin
        m2_fc_xaLANE = m2_xa[LANE]; m2_fc_xbLANE = m2_xb[LANE];
        y_m2[((LANE*8)+0) +: 8] = ((m2_xa[LANE][26:25] == 2'd1) && (m2_xb[LANE][26:25] == 2'd1)) ? (1'b0 ? ((m2_xa[LANE][26:25] == 2'd1) ? m2_aLANE : m2_bLANE) : 8'd126) : (m2_xa[LANE][26:25] == 2'd1) ? m2_bLANE : (m2_xb[LANE][26:25] == 2'd1) ? m2_aLANE : ((((m2_xa[LANE][26:25] == 2'd0 && m2_xa[LANE][10:0] == 0) && (m2_xb[LANE][26:25] == 2'd0 && m2_xb[LANE][10:0] == 0)) ? (m2_aLANE[7] == 1'b0 || m2_aLANE[7] == m2_bLANE[7]) : ((!m2_fc_ltLANE && !m2_fc_eqLANE) || m2_fc_eqLANE)) ? m2_aLANE : m2_bLANE);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_xa[LANE][26:25] == 2'd1) || (m2_xb[LANE][26:25] == 2'd1)) ? (((10'd1 << 9)) | ((((m2_xa[LANE][26:25] == 2'd1) && !m2_aLANE[1]) || ((m2_xb[LANE][26:25] == 2'd1) && !m2_bLANE[1])) ? (10'd1 << 0) : 10'd0) | ((1'b0 || ((m2_xa[LANE][26:25] == 2'd1) && (m2_xb[LANE][26:25] == 2'd1))) ? (10'd1 << 5) : 10'd0)) : 10'd0) | (m2_dena[LANE] | m2_denb[LANE] ? (10'd1 << 6) : 10'd0);
      end
      3'd5: begin
        m2_fc_xaLANE = m2_xa[LANE]; m2_fc_xbLANE = m2_xb[LANE];
        y_m2[((LANE*8)+0) +: 8] = ((m2_xa[LANE][26:25] == 2'd1) || (m2_xb[LANE][26:25] == 2'd1)) ? 8'd0 : {{5{1'b0}}, ((!m2_fc_ltLANE && !m2_fc_eqLANE)), (m2_fc_eqLANE), (m2_fc_ltLANE)};
        fl_m2[(0+LANE)*10 +: 10] = ((m2_xa[LANE][26:25] == 2'd1) || (m2_xb[LANE][26:25] == 2'd1) ? (10'd1 << 9) : 10'd0) | ((((m2_xa[LANE][26:25] == 2'd1) && !m2_aLANE[1]) || ((m2_xb[LANE][26:25] == 2'd1) && !m2_bLANE[1])) ? (10'd1 << 0) : 10'd0) | (m2_dena[LANE] | m2_denb[LANE] ? (10'd1 << 6) : 10'd0);
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_fp_multiplier #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2,
  input  logic [53:0] xa_m2,
  input  logic [53:0] xb_m2,
  input  logic [1:0] dena_m2,
  input  logic [1:0] denb_m2,
  output logic [53:0] x_m2
);
  // alu_core_m2_fp_multiplier: lane LANE of mode 2 (fp8e5m2) for the fp_multiplier ops fmul; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [19:0] m2_uaLANE;
  logic [19:0] m2_ubLANE;
  logic [26:0] m2_xa [0:1];
  logic m2_dena [0:1];
  logic [26:0] m2_xb [0:1];
  logic m2_denb [0:1];
  logic [26:0] m2_fm_xaLANE;
  logic [26:0] m2_fm_xbLANE;
  logic [26:0] m2_fm_yLANE;
  logic [17:0] m2_o2t0_LANE;
  logic [26:0] m2_o2t0_LANE_x;
  logic [26:0] m2_o2t0_LANE_z;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  // structure core.unpacker.m2: family per_unit_unpack realized by the library module fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a
  fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a u_m2_unpack_aLANE (.b(m2_aLANE), .daz(daz), .u(m2_uaLANE));
  // structure core.unpacker.m2: family per_unit_unpack realized by the library module fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a
  fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a u_m2_unpack_bLANE (.b(m2_bLANE), .daz(daz), .u(m2_ubLANE));
  assign m2_xa[LANE] = m2_x(m2_uaLANE[18:0]);
  assign m2_dena[LANE] = m2_uaLANE[19];
  assign m2_xb[LANE] = m2_x(m2_ubLANE[18:0]);
  assign m2_denb[LANE] = m2_ubLANE[19];
  // structure core.fp_multiplier.m2: family sig_mul_then_round realized by the library module fam_fp_mul_sig_mul_then_round_x10e13s3_padd344eaa93c
  fam_fp_mul_sig_mul_then_round_x10e13s3_padd344eaa93c u_m2_fmulLANE (.xa(m2_fm_xaLANE), .xb(m2_fm_xbLANE), .y(m2_fm_yLANE));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_fm_xaLANE = 'x; m2_fm_xbLANE = 'x; m2_o2t0_LANE = 'x; m2_o2t0_LANE_x = 'x; m2_o2t0_LANE_z = 'x;
    x_m2 = '0;
    case (op)
      3'd2: begin
        m2_fm_xaLANE = m2_xa[LANE]; m2_fm_xbLANE = m2_xb[LANE]; m2_o2t0_LANE_x = m2_fm_yLANE;
        m2_o2t0_LANE_z = { m2_o2t0_LANE_x[26:25], (m2_o2t0_LANE_x[26:25] == 2'd0 && m2_o2t0_LANE_x[10:0] == 0) ? (m2_aLANE[7] ^ m2_bLANE[7]) : m2_o2t0_LANE_x[24], m2_o2t0_LANE_x[23:0] };
        x_m2[LANE*27 +: 27] = m2_o2t0_LANE_z;
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_rounder #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2,
  input  logic [53:0] xa_m2,
  input  logic [53:0] xb_m2,
  input  logic [1:0] dena_m2,
  input  logic [1:0] denb_m2,
  input  logic [53:0] x_m2
);
  // alu_core_m2_rounder: lane LANE of mode 2 (fp8e5m2) for the rounder ops fmul; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic d_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [19:0] m2_uaLANE;
  logic [19:0] m2_ubLANE;
  logic [26:0] m2_xa [0:1];
  logic m2_dena [0:1];
  logic [26:0] m2_xb [0:1];
  logic m2_denb [0:1];
  logic [26:0] m2_rd_xLANE_fmul;
  logic [7:0] m2_rd_wLANE_fmul;
  logic [9:0] m2_rd_flLANE_fmul;
  logic [7:0] m2_rd_bLANE_fmul;
  logic [17:0] m2_o2t0_LANE;
  logic [26:0] m2_o2t0_LANE_x;
  logic [26:0] m2_o2t0_LANE_z;
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  // structure core.unpacker.m2: family per_unit_unpack realized by the library module fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a
  fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a u_m2_unpack_aLANE (.b(m2_aLANE), .daz(daz), .u(m2_uaLANE));
  // structure core.unpacker.m2: family per_unit_unpack realized by the library module fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a
  fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a u_m2_unpack_bLANE (.b(m2_bLANE), .daz(daz), .u(m2_ubLANE));
  assign m2_xa[LANE] = m2_x(m2_uaLANE[18:0]);
  assign m2_dena[LANE] = m2_uaLANE[19];
  assign m2_xb[LANE] = m2_x(m2_ubLANE[18:0]);
  assign m2_denb[LANE] = m2_ubLANE[19];
  // structure core.rounder.m2: family dedicated_per_op realized by the library module fam_fp_round_dedicated_per_op_increment_adder_fp8e5m2_x10e13s3_p9d3fabee2f30 (fmul)
  fam_fp_round_dedicated_per_op_increment_adder_fp8e5m2_x10e13s3_p9d3fabee2f30 u_m2_roundLANE_fmul (.x(m2_rd_xLANE_fmul), .rnd(rnd), .word(m2_rd_wLANE_fmul), .ftz(ftz), .fl(m2_rd_flLANE_fmul), .bits(m2_rd_bLANE_fmul));
  always_comb begin
    y_m2 = '0; d_m2 = '0; fl_m2 = '0;
    m2_rd_xLANE_fmul = 'x; m2_rd_wLANE_fmul = 'x; m2_o2t0_LANE = 'x; m2_o2t0_LANE_x = 'x; m2_o2t0_LANE_z = 'x;
    case (op)
      3'd2: begin
        m2_o2t0_LANE_z = x_m2[LANE*27 +: 27];
        m2_rd_xLANE_fmul = m2_o2t0_LANE_z; m2_rd_wLANE_fmul = 8'd0; m2_o2t0_LANE = {m2_rd_flLANE_fmul, m2_rd_bLANE_fmul};
        y_m2[((LANE*8)+0) +: 8] = (m2_o2t0_LANE_z[26:25] == 2'd1) ? (((m2_xa[LANE][26:25] == 2'd1) || (m2_xb[LANE][26:25] == 2'd1)) ? 8'd126 : 8'd126) : ((m2_o2t0_LANE_z[26:25] == 2'd0 && m2_o2t0_LANE_z[10:0] == 0) ? {m2_o2t0_LANE_z[24], 7'd0} : m2_o2t0_LANE[7:0]);
        fl_m2[(0+LANE)*10 +: 10] = (((m2_xa[LANE][26:25] == 2'd1) || (m2_xb[LANE][26:25] == 2'd1)) ? (((10'd1 << 5) | (((m2_xa[LANE][26:25] == 2'd1) && !m2_aLANE[1]) || ((m2_xb[LANE][26:25] == 2'd1) && !m2_bLANE[1]) ? (10'd1 << 0) : 10'd0)) | (m2_dena[LANE] | m2_denb[LANE] ? (10'd1 << 6) : 10'd0)) : (m2_o2t0_LANE[17:8] | ((((m2_xa[LANE][26:25] == 2'd1) && !m2_aLANE[1]) || ((m2_xb[LANE][26:25] == 2'd1) && !m2_bLANE[1]) || ((m2_o2t0_LANE_z[26:25] == 2'd1) && !((m2_xa[LANE][26:25] == 2'd1) || (m2_xb[LANE][26:25] == 2'd1)))) ? (10'd1 << 0) : 10'd0) | (m2_dena[LANE] | m2_denb[LANE] ? (10'd1 << 6) : 10'd0)));
      end
      default: ;
    endcase
  end
endmodule

module alu_core_m2_unpacker #(parameter int LANE = 0) (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [53:0] xa_m2,
  output logic [53:0] xb_m2,
  output logic [1:0] dena_m2,
  output logic [1:0] denb_m2
);
  // alu_core_m2_unpacker: lane LANE of mode 2 (fp8e5m2) for the unpacker ops ; the result buses are the mode's, with only this lane's bits written
  import alu_core_m2_pkg::*;
  logic [15:0] y_m2;
  logic d_m2;
  logic [19:0] fl_m2;
  logic [7:0] m2_aLANE;
  logic [7:0] m2_bLANE;
  logic [19:0] m2_uaLANE;
  logic [19:0] m2_ubLANE;
  logic [26:0] m2_xa [0:1];
  logic m2_dena [0:1];
  logic [26:0] m2_xb [0:1];
  logic m2_denb [0:1];
  assign m2_aLANE = a[(LANE*8) +: 8];
  assign m2_bLANE = b[(LANE*8) +: 8];
  // structure core.unpacker.m2: family per_unit_unpack realized by the library module fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a
  fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a u_m2_unpack_aLANE (.b(m2_aLANE), .daz(daz), .u(m2_uaLANE));
  // structure core.unpacker.m2: family per_unit_unpack realized by the library module fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a
  fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a u_m2_unpack_bLANE (.b(m2_bLANE), .daz(daz), .u(m2_ubLANE));
  assign m2_xa[LANE] = m2_x(m2_uaLANE[18:0]);
  assign m2_dena[LANE] = m2_uaLANE[19];
  assign m2_xb[LANE] = m2_x(m2_ubLANE[18:0]);
  assign m2_denb[LANE] = m2_ubLANE[19];
  always_comb begin
    xa_m2 = '0; dena_m2 = '0; xb_m2 = '0; denb_m2 = '0;
    xa_m2[LANE*27 +: 27] = m2_xa[LANE];
    dena_m2[LANE] = m2_dena[LANE];
    xb_m2[LANE*27 +: 27] = m2_xb[LANE];
    denb_m2[LANE] = m2_denb[LANE];
  end
endmodule
// ADIR-MEMBER m0_l0_fp_adder
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_fp_adder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0,
  input  logic [42:0] xa_m0,
  input  logic [42:0] xb_m0,
  input  logic [0:0] dena_m0,
  input  logic [0:0] denb_m0,
  output logic [42:0] x_m0
);
  // alu_core_u_m0_l0_fp_adder: physical structure `m0.l0.fp_adder` (kind fp_adder, slot fp_adder); realizes m0.l0.fp_adder: fp_adder, mode 0 lane 0, fp16, ops fadd, fsub
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  logic [42:0] x_m0_l0;
  alu_core_m0_fp_adder #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0), .xa_m0(xa_m0), .xb_m0(xb_m0), .dena_m0(dena_m0), .denb_m0(denb_m0), .x_m0(x_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
  assign x_m0 = x_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_unpacker
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_unpacker (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [42:0] xa_m0,
  output logic [42:0] xb_m0,
  output logic [0:0] dena_m0,
  output logic [0:0] denb_m0
);
  // alu_core_u_m0_l0_unpacker: physical structure `m0.l0.unpacker` (kind unpacker, slot unpacker); realizes m0.l0.unpacker: unpacker, mode 0 lane 0, fp16, ops fadd, fsub, fmul, fmin, fmax, fcmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [42:0] xa_m0_l0;
  logic [42:0] xb_m0_l0;
  logic dena_m0_l0;
  logic denb_m0_l0;
  alu_core_m0_unpacker #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .xa_m0(xa_m0_l0), .xb_m0(xb_m0_l0), .dena_m0(dena_m0_l0), .denb_m0(denb_m0_l0));
  assign xa_m0 = xa_m0_l0;
  assign xb_m0 = xb_m0_l0;
  assign dena_m0 = dena_m0_l0;
  assign denb_m0 = denb_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_rounder
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_rounder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0,
  input  logic [42:0] xa_m0,
  input  logic [42:0] xb_m0,
  input  logic [0:0] dena_m0,
  input  logic [0:0] denb_m0,
  input  logic [42:0] x_m0
);
  // alu_core_u_m0_l0_rounder: physical structure `m0.l0.rounder` (kind rounder, slot rounder); realizes m0.l0.rounder: rounder, mode 0 lane 0, fp16, ops fadd, fsub, fmul
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_rounder #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0), .xa_m0(xa_m0), .xb_m0(xb_m0), .dena_m0(dena_m0), .denb_m0(denb_m0), .x_m0(x_m0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_fp_fma
// m0.l0.fp_fma: realized inline in the top (member top)
// ADIR-MEMBER m0_l0_fp_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_fp_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0,
  input  logic [42:0] xa_m0,
  input  logic [42:0] xb_m0,
  input  logic [0:0] dena_m0,
  input  logic [0:0] denb_m0,
  output logic [42:0] x_m0
);
  // alu_core_u_m0_l0_fp_multiplier: physical structure `m0.l0.fp_multiplier` (kind fp_multiplier, slot fp_multiplier); realizes m0.l0.fp_multiplier: fp_multiplier, mode 0 lane 0, fp16, ops fmul
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  logic [42:0] x_m0_l0;
  alu_core_m0_fp_multiplier #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0), .xa_m0(xa_m0), .xb_m0(xb_m0), .dena_m0(dena_m0), .denb_m0(denb_m0), .x_m0(x_m0_l0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
  assign x_m0 = x_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m0_l0_fp_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m0_l0_fp_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m0,
  output logic [19:0] fl_m0,
  input  logic [42:0] xa_m0,
  input  logic [42:0] xb_m0,
  input  logic [0:0] dena_m0,
  input  logic [0:0] denb_m0
);
  // alu_core_u_m0_l0_fp_comparator: physical structure `m0.l0.fp_comparator` (kind fp_comparator, slot fp_comparator); realizes m0.l0.fp_comparator: fp_comparator, mode 0 lane 0, fp16, ops fmin, fmax, fcmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m0_l0;
  logic [19:0] fl_m0_l0;
  alu_core_m0_fp_comparator #(.LANE(0)) u_m0_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m0(y_m0_l0), .fl_m0(fl_m0_l0), .xa_m0(xa_m0), .xb_m0(xb_m0), .dena_m0(dena_m0), .denb_m0(denb_m0));
  assign y_m0 = y_m0_l0;
  assign fl_m0 = fl_m0_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_fp_adder
// m1.l0.fp_adder: realized by the unit module in member m1_l0_fp_fma
// ADIR-MEMBER m1_l0_unpacker
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_unpacker (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [39:0] xa_m1,
  output logic [39:0] xb_m1,
  output logic [0:0] dena_m1,
  output logic [0:0] denb_m1
);
  // alu_core_u_m1_l0_unpacker: physical structure `m1.l0.unpacker` (kind unpacker, slot unpacker); realizes m1.l0.unpacker: unpacker, mode 1 lane 0, bf16, ops fadd, fsub, fmul, fmin, fmax, fcmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [39:0] xa_m1_l0;
  logic [39:0] xb_m1_l0;
  logic dena_m1_l0;
  logic denb_m1_l0;
  alu_core_m1_unpacker #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .xa_m1(xa_m1_l0), .xb_m1(xb_m1_l0), .dena_m1(dena_m1_l0), .denb_m1(denb_m1_l0));
  assign xa_m1 = xa_m1_l0;
  assign xb_m1 = xb_m1_l0;
  assign dena_m1 = dena_m1_l0;
  assign denb_m1 = denb_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_rounder
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_rounder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1,
  input  logic [39:0] xa_m1,
  input  logic [39:0] xb_m1,
  input  logic [0:0] dena_m1,
  input  logic [0:0] denb_m1,
  input  logic [39:0] x_m1
);
  // alu_core_u_m1_l0_rounder: physical structure `m1.l0.rounder` (kind rounder, slot rounder); realizes m1.l0.rounder: rounder, mode 1 lane 0, bf16, ops fadd, fsub, fmul
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_rounder #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0), .xa_m1(xa_m1), .xb_m1(xb_m1), .dena_m1(dena_m1), .denb_m1(denb_m1), .x_m1(x_m1));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_fp_fma
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_fp_fma (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1,
  input  logic [39:0] xa_m1,
  input  logic [39:0] xb_m1,
  input  logic [0:0] dena_m1,
  input  logic [0:0] denb_m1,
  output logic [39:0] x_m1
);
  // alu_core_u_m1_l0_fp_fma: physical structure `m1.l0.fp_fma` (kind fp_fma, slot fp_fma); realizes m1.l0.fp_fma: fp_fma, mode 1 lane 0, bf16, ops fadd, fsub, fmul, m1.l0.fp_adder: fp_adder, mode 1 lane 0, bf16, ops fadd, fsub, m1.l0.fp_multiplier: fp_multiplier, mode 1 lane 0, bf16, ops fmul
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  logic [39:0] x_m1_l0;
  alu_core_m1_fp_adder_fp_fma_fp_multiplier #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0), .xa_m1(xa_m1), .xb_m1(xb_m1), .dena_m1(dena_m1), .denb_m1(denb_m1), .x_m1(x_m1_l0));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
  assign x_m1 = x_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m1_l0_fp_multiplier
// m1.l0.fp_multiplier: realized by the unit module in member m1_l0_fp_fma
// ADIR-MEMBER m1_l0_fp_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m1_l0_fp_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m1,
  output logic [19:0] fl_m1,
  input  logic [39:0] xa_m1,
  input  logic [39:0] xb_m1,
  input  logic [0:0] dena_m1,
  input  logic [0:0] denb_m1
);
  // alu_core_u_m1_l0_fp_comparator: physical structure `m1.l0.fp_comparator` (kind fp_comparator, slot fp_comparator); realizes m1.l0.fp_comparator: fp_comparator, mode 1 lane 0, bf16, ops fmin, fmax, fcmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m1_l0;
  logic [19:0] fl_m1_l0;
  alu_core_m1_fp_comparator #(.LANE(0)) u_m1_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m1(y_m1_l0), .fl_m1(fl_m1_l0), .xa_m1(xa_m1), .xb_m1(xb_m1), .dena_m1(dena_m1), .denb_m1(denb_m1));
  assign y_m1 = y_m1_l0;
  assign fl_m1 = fl_m1_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_fp_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_fp_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2,
  input  logic [53:0] xa_m2,
  input  logic [53:0] xb_m2,
  input  logic [1:0] dena_m2,
  input  logic [1:0] denb_m2,
  output logic [53:0] x_m2
);
  // alu_core_u_m2_l0_fp_multiplier: physical structure `m2.l0.fp_multiplier` (kind fp_multiplier, slot fp_multiplier); realizes m2.l0.fp_multiplier: fp_multiplier, mode 2 lane 0, fp8e5m2, ops fmul
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  logic [53:0] x_m2_l0;
  alu_core_m2_fp_multiplier #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0), .xa_m2(xa_m2), .xb_m2(xb_m2), .dena_m2(dena_m2), .denb_m2(denb_m2), .x_m2(x_m2_l0));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
  assign x_m2 = x_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_fp_multiplier
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_fp_multiplier (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2,
  input  logic [53:0] xa_m2,
  input  logic [53:0] xb_m2,
  input  logic [1:0] dena_m2,
  input  logic [1:0] denb_m2,
  output logic [53:0] x_m2
);
  // alu_core_u_m2_l1_fp_multiplier: physical structure `m2.l1.fp_multiplier` (kind fp_multiplier, slot fp_multiplier); realizes m2.l1.fp_multiplier: fp_multiplier, mode 2 lane 1, fp8e5m2, ops fmul
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  logic [53:0] x_m2_l1;
  alu_core_m2_fp_multiplier #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1), .xa_m2(xa_m2), .xb_m2(xb_m2), .dena_m2(dena_m2), .denb_m2(denb_m2), .x_m2(x_m2_l1));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
  assign x_m2 = x_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_unpacker
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_unpacker (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [53:0] xa_m2,
  output logic [53:0] xb_m2,
  output logic [1:0] dena_m2,
  output logic [1:0] denb_m2
);
  // alu_core_u_m2_l0_unpacker: physical structure `m2.l0.unpacker` (kind unpacker, slot unpacker); realizes m2.l0.unpacker: unpacker, mode 2 lane 0, fp8e5m2, ops fmul, fmin, fmax, fcmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [53:0] xa_m2_l0;
  logic [53:0] xb_m2_l0;
  logic [1:0] dena_m2_l0;
  logic [1:0] denb_m2_l0;
  alu_core_m2_unpacker #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .xa_m2(xa_m2_l0), .xb_m2(xb_m2_l0), .dena_m2(dena_m2_l0), .denb_m2(denb_m2_l0));
  assign xa_m2 = xa_m2_l0;
  assign xb_m2 = xb_m2_l0;
  assign dena_m2 = dena_m2_l0;
  assign denb_m2 = denb_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_rounder
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_rounder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2,
  input  logic [53:0] xa_m2,
  input  logic [53:0] xb_m2,
  input  logic [1:0] dena_m2,
  input  logic [1:0] denb_m2,
  input  logic [53:0] x_m2
);
  // alu_core_u_m2_l0_rounder: physical structure `m2.l0.rounder` (kind rounder, slot rounder); realizes m2.l0.rounder: rounder, mode 2 lane 0, fp8e5m2, ops fmul
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_rounder #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0), .xa_m2(xa_m2), .xb_m2(xb_m2), .dena_m2(dena_m2), .denb_m2(denb_m2), .x_m2(x_m2));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l0_fp_fma
// m2.l0.fp_fma: realized inline in the top (member top)
// ADIR-MEMBER m2_l1_unpacker
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_unpacker (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [53:0] xa_m2,
  output logic [53:0] xb_m2,
  output logic [1:0] dena_m2,
  output logic [1:0] denb_m2
);
  // alu_core_u_m2_l1_unpacker: physical structure `m2.l1.unpacker` (kind unpacker, slot unpacker); realizes m2.l1.unpacker: unpacker, mode 2 lane 1, fp8e5m2, ops fmul, fmin, fmax, fcmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [53:0] xa_m2_l1;
  logic [53:0] xb_m2_l1;
  logic [1:0] dena_m2_l1;
  logic [1:0] denb_m2_l1;
  alu_core_m2_unpacker #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .xa_m2(xa_m2_l1), .xb_m2(xb_m2_l1), .dena_m2(dena_m2_l1), .denb_m2(denb_m2_l1));
  assign xa_m2 = xa_m2_l1;
  assign xb_m2 = xb_m2_l1;
  assign dena_m2 = dena_m2_l1;
  assign denb_m2 = denb_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_rounder
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_rounder (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2,
  input  logic [53:0] xa_m2,
  input  logic [53:0] xb_m2,
  input  logic [1:0] dena_m2,
  input  logic [1:0] denb_m2,
  input  logic [53:0] x_m2
);
  // alu_core_u_m2_l1_rounder: physical structure `m2.l1.rounder` (kind rounder, slot rounder); realizes m2.l1.rounder: rounder, mode 2 lane 1, fp8e5m2, ops fmul
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_rounder #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1), .xa_m2(xa_m2), .xb_m2(xb_m2), .dena_m2(dena_m2), .denb_m2(denb_m2), .x_m2(x_m2));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_fp_fma
// m2.l1.fp_fma: realized inline in the top (member top)
// ADIR-MEMBER m2_l0_fp_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m2_l0_fp_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2,
  input  logic [53:0] xa_m2,
  input  logic [53:0] xb_m2,
  input  logic [1:0] dena_m2,
  input  logic [1:0] denb_m2
);
  // alu_core_u_m2_l0_fp_comparator: physical structure `m2.l0.fp_comparator` (kind fp_comparator, slot fp_comparator); realizes m2.l0.fp_comparator: fp_comparator, mode 2 lane 0, fp8e5m2, ops fmin, fmax, fcmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l0;
  logic [19:0] fl_m2_l0;
  alu_core_m2_fp_comparator #(.LANE(0)) u_m2_l0 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l0), .fl_m2(fl_m2_l0), .xa_m2(xa_m2), .xb_m2(xb_m2), .dena_m2(dena_m2), .denb_m2(denb_m2));
  assign y_m2 = y_m2_l0;
  assign fl_m2 = fl_m2_l0;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER m2_l1_fp_comparator
// EVOLVE-BLOCK-START
module alu_core_u_m2_l1_fp_comparator (
  input  logic [15:0] a,
  input  logic [15:0] b,
  input  logic [2:0] op,
  input  logic [1:0] mode,
  input  logic [2:0] rnd,
  input  logic [0:0] daz,
  input  logic [0:0] ftz,
  input  logic [0:0] dual,
  output logic [15:0] y_m2,
  output logic [19:0] fl_m2,
  input  logic [53:0] xa_m2,
  input  logic [53:0] xb_m2,
  input  logic [1:0] dena_m2,
  input  logic [1:0] denb_m2
);
  // alu_core_u_m2_l1_fp_comparator: physical structure `m2.l1.fp_comparator` (kind fp_comparator, slot fp_comparator); realizes m2.l1.fp_comparator: fp_comparator, mode 2 lane 1, fp8e5m2, ops fmin, fmax, fcmp
  // the seed's body: one instance of the lane module per lane, defined outside the mutable regions; the lane module instantiates the family library's module of the declared family where the library has one (a comment names it) and is behavioral otherwise; a rewrite replaces these instances with the family's logic inside this module, keeps the module's name and ports, and may share one datapath among the lanes
  logic [15:0] y_m2_l1;
  logic [19:0] fl_m2_l1;
  alu_core_m2_fp_comparator #(.LANE(1)) u_m2_l1 (.a(a), .b(b), .op(op), .mode(mode), .rnd(rnd), .daz(daz), .ftz(ftz), .dual(dual), .y_m2(y_m2_l1), .fl_m2(fl_m2_l1), .xa_m2(xa_m2), .xb_m2(xb_m2), .dena_m2(dena_m2), .denb_m2(denb_m2));
  assign y_m2 = y_m2_l1;
  assign fl_m2 = fl_m2_l1;
endmodule
// EVOLVE-BLOCK-END
// ADIR-MEMBER library
// ---- the family library modules the lane modules instantiate (chialu/targets/rtl/families; fixed text, replaced by editing the instances)

// carry_select: blocks [1, 2, 3, 3, 4] (delay_balanced_dp), full_duplicate, selects lookahead_tree
module fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13 (input logic [12:0] a, input logic [12:0] b, input logic cin, output logic [12:0] s, output logic cout);
  logic s0_0;
  logic s0_1;
  logic co0_0;
  logic co0_1;
  // block 0 (1 bits), carry-in 0
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w1 u1 (.a(a[0:0]), .b(b[0:0]), .cin(1'b0), .s(s0_0), .cout(co0_0));
  // block 0, carry-in 1
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w1 u2 (.a(a[0:0]), .b(b[0:0]), .cin(1'b1), .s(s0_1), .cout(co0_1));
  logic bp0; assign bp0 = co0_1 & ~co0_0;
  logic [1:0] s1_0;
  logic [1:0] s1_1;
  logic co1_0;
  logic co1_1;
  // block 1 (2 bits), carry-in 0
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w2 u3 (.a(a[2:1]), .b(b[2:1]), .cin(1'b0), .s(s1_0), .cout(co1_0));
  // block 1, carry-in 1
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w2 u4 (.a(a[2:1]), .b(b[2:1]), .cin(1'b1), .s(s1_1), .cout(co1_1));
  logic bp1; assign bp1 = co1_1 & ~co1_0;
  logic [2:0] s2_0;
  logic [2:0] s2_1;
  logic co2_0;
  logic co2_1;
  // block 2 (3 bits), carry-in 0
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w3 u5 (.a(a[5:3]), .b(b[5:3]), .cin(1'b0), .s(s2_0), .cout(co2_0));
  // block 2, carry-in 1
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w3 u6 (.a(a[5:3]), .b(b[5:3]), .cin(1'b1), .s(s2_1), .cout(co2_1));
  logic bp2; assign bp2 = co2_1 & ~co2_0;
  logic [2:0] s3_0;
  logic [2:0] s3_1;
  logic co3_0;
  logic co3_1;
  // block 3 (3 bits), carry-in 0
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w3 u7 (.a(a[8:6]), .b(b[8:6]), .cin(1'b0), .s(s3_0), .cout(co3_0));
  // block 3, carry-in 1
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w3 u8 (.a(a[8:6]), .b(b[8:6]), .cin(1'b1), .s(s3_1), .cout(co3_1));
  logic bp3; assign bp3 = co3_1 & ~co3_0;
  logic [3:0] s4_0;
  logic [3:0] s4_1;
  logic co4_0;
  logic co4_1;
  // block 4 (4 bits), carry-in 0
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w4 u9 (.a(a[12:9]), .b(b[12:9]), .cin(1'b0), .s(s4_0), .cout(co4_0));
  // block 4, carry-in 1
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w4 u10 (.a(a[12:9]), .b(b[12:9]), .cin(1'b1), .s(s4_1), .cout(co4_1));
  logic bp4; assign bp4 = co4_1 & ~co4_0;
  logic la_t0_0; assign la_t0_0 = co0_0 | (bp0 & cin);
  logic la_t1_0; assign la_t1_0 = co0_0 | (bp0 & cin);
  logic la_t1_1; assign la_t1_1 = co1_0 | (bp1 & la_t1_0);
  logic la_t2_0; assign la_t2_0 = co0_0 | (bp0 & cin);
  logic la_t2_1; assign la_t2_1 = co1_0 | (bp1 & la_t2_0);
  logic la_t2_2; assign la_t2_2 = co2_0 | (bp2 & la_t2_1);
  logic la_t3_0; assign la_t3_0 = co0_0 | (bp0 & cin);
  logic la_t3_1; assign la_t3_1 = co1_0 | (bp1 & la_t3_0);
  logic la_t3_2; assign la_t3_2 = co2_0 | (bp2 & la_t3_1);
  logic la_t3_3; assign la_t3_3 = co3_0 | (bp3 & la_t3_2);
  logic la_t4_0; assign la_t4_0 = co0_0 | (bp0 & cin);
  logic la_t4_1; assign la_t4_1 = co1_0 | (bp1 & la_t4_0);
  logic la_t4_2; assign la_t4_2 = co2_0 | (bp2 & la_t4_1);
  logic la_t4_3; assign la_t4_3 = co3_0 | (bp3 & la_t4_2);
  logic la_t4_4; assign la_t4_4 = co4_0 | (bp4 & la_t4_3);
  assign s[0:0] = cin ? s0_1 : s0_0;
  assign s[2:1] = la_t0_0 ? s1_1 : s1_0;
  assign s[5:3] = la_t1_1 ? s2_1 : s2_0;
  assign s[8:6] = la_t2_2 ? s3_1 : s3_0;
  assign s[12:9] = la_t3_3 ? s4_1 : s4_0;
  assign cout = la_t4_4;
endmodule




module fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w1(input wire [0:0] a, input wire [0:0] b, input wire [0:0] cin, output wire [0:0] s, output wire [0:0] cout);
fam_prefix_sklansky_w1_v4 implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule





module fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_prefix_sklansky_w2_v4 implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule





module fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w3(input wire [2:0] a, input wire [2:0] b, input wire [0:0] cin, output wire [2:0] s, output wire [0:0] cout);
fam_prefix_sklansky_w3_v4 implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule





module fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13_component_block_adder_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_prefix_sklansky_w4_v4 implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule


// carry_select: blocks [1, 2, 3, 3, 4] (delay_balanced_dp), full_duplicate, selects lookahead_tree






























// carry_select: blocks [2, 2, 3, 3, 4] (delay_balanced_dp), full_duplicate, selects lookahead_tree
module fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14 (input logic [13:0] a, input logic [13:0] b, input logic cin, output logic [13:0] s, output logic cout);
  logic [1:0] s0_0;
  logic [1:0] s0_1;
  logic co0_0;
  logic co0_1;
  // block 0 (2 bits), carry-in 0
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14_component_block_adder_adder_w2 u1 (.a(a[1:0]), .b(b[1:0]), .cin(1'b0), .s(s0_0), .cout(co0_0));
  // block 0, carry-in 1
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14_component_block_adder_adder_w2 u2 (.a(a[1:0]), .b(b[1:0]), .cin(1'b1), .s(s0_1), .cout(co0_1));
  logic bp0; assign bp0 = co0_1 & ~co0_0;
  logic [1:0] s1_0;
  logic [1:0] s1_1;
  logic co1_0;
  logic co1_1;
  // block 1 (2 bits), carry-in 0
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14_component_block_adder_adder_w2 u3 (.a(a[3:2]), .b(b[3:2]), .cin(1'b0), .s(s1_0), .cout(co1_0));
  // block 1, carry-in 1
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14_component_block_adder_adder_w2 u4 (.a(a[3:2]), .b(b[3:2]), .cin(1'b1), .s(s1_1), .cout(co1_1));
  logic bp1; assign bp1 = co1_1 & ~co1_0;
  logic [2:0] s2_0;
  logic [2:0] s2_1;
  logic co2_0;
  logic co2_1;
  // block 2 (3 bits), carry-in 0
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14_component_block_adder_adder_w3 u5 (.a(a[6:4]), .b(b[6:4]), .cin(1'b0), .s(s2_0), .cout(co2_0));
  // block 2, carry-in 1
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14_component_block_adder_adder_w3 u6 (.a(a[6:4]), .b(b[6:4]), .cin(1'b1), .s(s2_1), .cout(co2_1));
  logic bp2; assign bp2 = co2_1 & ~co2_0;
  logic [2:0] s3_0;
  logic [2:0] s3_1;
  logic co3_0;
  logic co3_1;
  // block 3 (3 bits), carry-in 0
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14_component_block_adder_adder_w3 u7 (.a(a[9:7]), .b(b[9:7]), .cin(1'b0), .s(s3_0), .cout(co3_0));
  // block 3, carry-in 1
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14_component_block_adder_adder_w3 u8 (.a(a[9:7]), .b(b[9:7]), .cin(1'b1), .s(s3_1), .cout(co3_1));
  logic bp3; assign bp3 = co3_1 & ~co3_0;
  logic [3:0] s4_0;
  logic [3:0] s4_1;
  logic co4_0;
  logic co4_1;
  // block 4 (4 bits), carry-in 0
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14_component_block_adder_adder_w4 u9 (.a(a[13:10]), .b(b[13:10]), .cin(1'b0), .s(s4_0), .cout(co4_0));
  // block 4, carry-in 1
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14_component_block_adder_adder_w4 u10 (.a(a[13:10]), .b(b[13:10]), .cin(1'b1), .s(s4_1), .cout(co4_1));
  logic bp4; assign bp4 = co4_1 & ~co4_0;
  logic la_t0_0; assign la_t0_0 = co0_0 | (bp0 & cin);
  logic la_t1_0; assign la_t1_0 = co0_0 | (bp0 & cin);
  logic la_t1_1; assign la_t1_1 = co1_0 | (bp1 & la_t1_0);
  logic la_t2_0; assign la_t2_0 = co0_0 | (bp0 & cin);
  logic la_t2_1; assign la_t2_1 = co1_0 | (bp1 & la_t2_0);
  logic la_t2_2; assign la_t2_2 = co2_0 | (bp2 & la_t2_1);
  logic la_t3_0; assign la_t3_0 = co0_0 | (bp0 & cin);
  logic la_t3_1; assign la_t3_1 = co1_0 | (bp1 & la_t3_0);
  logic la_t3_2; assign la_t3_2 = co2_0 | (bp2 & la_t3_1);
  logic la_t3_3; assign la_t3_3 = co3_0 | (bp3 & la_t3_2);
  logic la_t4_0; assign la_t4_0 = co0_0 | (bp0 & cin);
  logic la_t4_1; assign la_t4_1 = co1_0 | (bp1 & la_t4_0);
  logic la_t4_2; assign la_t4_2 = co2_0 | (bp2 & la_t4_1);
  logic la_t4_3; assign la_t4_3 = co3_0 | (bp3 & la_t4_2);
  logic la_t4_4; assign la_t4_4 = co4_0 | (bp4 & la_t4_3);
  assign s[1:0] = cin ? s0_1 : s0_0;
  assign s[3:2] = la_t0_0 ? s1_1 : s1_0;
  assign s[6:4] = la_t1_1 ? s2_1 : s2_0;
  assign s[9:7] = la_t2_2 ? s3_1 : s3_0;
  assign s[13:10] = la_t3_3 ? s4_1 : s4_0;
  assign cout = la_t4_4;
endmodule




module fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14_component_block_adder_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_prefix_sklansky_w2_v4 implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule








module fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14_component_block_adder_adder_w3(input wire [2:0] a, input wire [2:0] b, input wire [0:0] cin, output wire [2:0] s, output wire [0:0] cout);
fam_prefix_sklansky_w3_v4 implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule








module fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14_component_block_adder_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_prefix_sklansky_w4_v4 implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule





































































































































































































































































































































// carry_skip: blocks [4, 3] (uniform), 1 skip level, mux
module fam_adder_carry_skip_w7 (input logic [6:0] a, input logic [6:0] b, input logic cin, output logic [6:0] s, output logic cout);
  logic P0; assign P0 = &(a[3:0] ^ b[3:0]);
  logic P1; assign P1 = &(a[6:4] ^ b[6:4]);
  logic [3:0] s0;
  logic co0;
  // block 0 (4 bits)
  fam_adder_carry_skip_w7_component_block_adder_adder_w4 u1 (.a(a[3:0]), .b(b[3:0]), .cin(cin), .s(s0), .cout(co0));
  assign s[3:0] = s0;
  logic bc0;
  assign bc0 = P0 ? cin : co0;
  logic [2:0] s1;
  logic co1;
  // block 1 (3 bits)
  fam_adder_carry_skip_w7_component_block_adder_adder_w3 u2 (.a(a[6:4]), .b(b[6:4]), .cin(bc0), .s(s1), .cout(co1));
  assign s[6:4] = s1;
  logic bc1;
  assign bc1 = P1 ? bc0 : co1;
  assign cout = bc1;
endmodule




module fam_adder_carry_skip_w7_component_block_adder_adder_w3(input wire [2:0] a, input wire [2:0] b, input wire [0:0] cin, output wire [2:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(3), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_carry_skip_w7_component_block_adder_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule


// carry_skip: blocks [4, 4] (uniform), 1 skip level, mux
module fam_adder_carry_skip_w8 (input logic [7:0] a, input logic [7:0] b, input logic cin, output logic [7:0] s, output logic cout);
  logic P0; assign P0 = &(a[3:0] ^ b[3:0]);
  logic P1; assign P1 = &(a[7:4] ^ b[7:4]);
  logic [3:0] s0;
  logic co0;
  // block 0 (4 bits)
  fam_adder_carry_skip_w8_component_block_adder_adder_w4 u1 (.a(a[3:0]), .b(b[3:0]), .cin(cin), .s(s0), .cout(co0));
  assign s[3:0] = s0;
  logic bc0;
  assign bc0 = P0 ? cin : co0;
  logic [3:0] s1;
  logic co1;
  // block 1 (4 bits)
  fam_adder_carry_skip_w8_component_block_adder_adder_w4 u2 (.a(a[7:4]), .b(b[7:4]), .cin(bc0), .s(s1), .cout(co1));
  assign s[7:4] = s1;
  logic bc1;
  assign bc1 = P1 ? bc0 : co1;
  assign cout = bc1;
endmodule




module fam_adder_carry_skip_w8_component_block_adder_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule


// end_around_carry (generic_p_correction, cyclic_prefix_level, ladner_fischer, the incrementer prefix_and_incrementer): the carry-out re-enters as the carry-in
module fam_adder_eac_cyclic_prefix_level_p71ad0afc38c98cc878595b2be2d3d81b739691b88149561a71e54f41570fbe7b_w27 (input logic [26:0] a, input logic [26:0] b, input logic cin, output logic [26:0] s, output logic cout);
  logic [27:0] t;
  // the sum
  fam_prefix_ladner_fischer_w27 u1 (.a(a), .b(b), .cin(cin), .s(t[26:0]), .cout(t[27]));
  localparam [27:0] MODULUS = 28'd84;
  localparam integer REDUCTION_STAGES = 22;
  logic [27:0] difference21;
  logic nonnegative21;
  // complete generic-p reduction, shifted modulus 21
  fam_prefix_ladner_fischer_w28 u2 (.a(t), .b(28'd92274687), .cin(1'b1), .s(difference21), .cout(nonnegative21));
  logic [27:0] remainder21; assign remainder21 = nonnegative21 ? difference21 : t;
  logic [27:0] difference20;
  logic nonnegative20;
  // complete generic-p reduction, shifted modulus 20
  fam_prefix_ladner_fischer_w28 u3 (.a(remainder21), .b(28'd180355071), .cin(1'b1), .s(difference20), .cout(nonnegative20));
  logic [27:0] remainder20; assign remainder20 = nonnegative20 ? difference20 : remainder21;
  logic [27:0] difference19;
  logic nonnegative19;
  // complete generic-p reduction, shifted modulus 19
  fam_prefix_ladner_fischer_w28 u4 (.a(remainder20), .b(28'd224395263), .cin(1'b1), .s(difference19), .cout(nonnegative19));
  logic [27:0] remainder19; assign remainder19 = nonnegative19 ? difference19 : remainder20;
  logic [27:0] difference18;
  logic nonnegative18;
  // complete generic-p reduction, shifted modulus 18
  fam_prefix_ladner_fischer_w28 u5 (.a(remainder19), .b(28'd246415359), .cin(1'b1), .s(difference18), .cout(nonnegative18));
  logic [27:0] remainder18; assign remainder18 = nonnegative18 ? difference18 : remainder19;
  logic [27:0] difference17;
  logic nonnegative17;
  // complete generic-p reduction, shifted modulus 17
  fam_prefix_ladner_fischer_w28 u6 (.a(remainder18), .b(28'd257425407), .cin(1'b1), .s(difference17), .cout(nonnegative17));
  logic [27:0] remainder17; assign remainder17 = nonnegative17 ? difference17 : remainder18;
  logic [27:0] difference16;
  logic nonnegative16;
  // complete generic-p reduction, shifted modulus 16
  fam_prefix_ladner_fischer_w28 u7 (.a(remainder17), .b(28'd262930431), .cin(1'b1), .s(difference16), .cout(nonnegative16));
  logic [27:0] remainder16; assign remainder16 = nonnegative16 ? difference16 : remainder17;
  logic [27:0] difference15;
  logic nonnegative15;
  // complete generic-p reduction, shifted modulus 15
  fam_prefix_ladner_fischer_w28 u8 (.a(remainder16), .b(28'd265682943), .cin(1'b1), .s(difference15), .cout(nonnegative15));
  logic [27:0] remainder15; assign remainder15 = nonnegative15 ? difference15 : remainder16;
  logic [27:0] difference14;
  logic nonnegative14;
  // complete generic-p reduction, shifted modulus 14
  fam_prefix_ladner_fischer_w28 u9 (.a(remainder15), .b(28'd267059199), .cin(1'b1), .s(difference14), .cout(nonnegative14));
  logic [27:0] remainder14; assign remainder14 = nonnegative14 ? difference14 : remainder15;
  logic [27:0] difference13;
  logic nonnegative13;
  // complete generic-p reduction, shifted modulus 13
  fam_prefix_ladner_fischer_w28 u10 (.a(remainder14), .b(28'd267747327), .cin(1'b1), .s(difference13), .cout(nonnegative13));
  logic [27:0] remainder13; assign remainder13 = nonnegative13 ? difference13 : remainder14;
  logic [27:0] difference12;
  logic nonnegative12;
  // complete generic-p reduction, shifted modulus 12
  fam_prefix_ladner_fischer_w28 u11 (.a(remainder13), .b(28'd268091391), .cin(1'b1), .s(difference12), .cout(nonnegative12));
  logic [27:0] remainder12; assign remainder12 = nonnegative12 ? difference12 : remainder13;
  logic [27:0] difference11;
  logic nonnegative11;
  // complete generic-p reduction, shifted modulus 11
  fam_prefix_ladner_fischer_w28 u12 (.a(remainder12), .b(28'd268263423), .cin(1'b1), .s(difference11), .cout(nonnegative11));
  logic [27:0] remainder11; assign remainder11 = nonnegative11 ? difference11 : remainder12;
  logic [27:0] difference10;
  logic nonnegative10;
  // complete generic-p reduction, shifted modulus 10
  fam_prefix_ladner_fischer_w28 u13 (.a(remainder11), .b(28'd268349439), .cin(1'b1), .s(difference10), .cout(nonnegative10));
  logic [27:0] remainder10; assign remainder10 = nonnegative10 ? difference10 : remainder11;
  logic [27:0] difference9;
  logic nonnegative9;
  // complete generic-p reduction, shifted modulus 9
  fam_prefix_ladner_fischer_w28 u14 (.a(remainder10), .b(28'd268392447), .cin(1'b1), .s(difference9), .cout(nonnegative9));
  logic [27:0] remainder9; assign remainder9 = nonnegative9 ? difference9 : remainder10;
  logic [27:0] difference8;
  logic nonnegative8;
  // complete generic-p reduction, shifted modulus 8
  fam_prefix_ladner_fischer_w28 u15 (.a(remainder9), .b(28'd268413951), .cin(1'b1), .s(difference8), .cout(nonnegative8));
  logic [27:0] remainder8; assign remainder8 = nonnegative8 ? difference8 : remainder9;
  logic [27:0] difference7;
  logic nonnegative7;
  // complete generic-p reduction, shifted modulus 7
  fam_prefix_ladner_fischer_w28 u16 (.a(remainder8), .b(28'd268424703), .cin(1'b1), .s(difference7), .cout(nonnegative7));
  logic [27:0] remainder7; assign remainder7 = nonnegative7 ? difference7 : remainder8;
  logic [27:0] difference6;
  logic nonnegative6;
  // complete generic-p reduction, shifted modulus 6
  fam_prefix_ladner_fischer_w28 u17 (.a(remainder7), .b(28'd268430079), .cin(1'b1), .s(difference6), .cout(nonnegative6));
  logic [27:0] remainder6; assign remainder6 = nonnegative6 ? difference6 : remainder7;
  logic [27:0] difference5;
  logic nonnegative5;
  // complete generic-p reduction, shifted modulus 5
  fam_prefix_ladner_fischer_w28 u18 (.a(remainder6), .b(28'd268432767), .cin(1'b1), .s(difference5), .cout(nonnegative5));
  logic [27:0] remainder5; assign remainder5 = nonnegative5 ? difference5 : remainder6;
  logic [27:0] difference4;
  logic nonnegative4;
  // complete generic-p reduction, shifted modulus 4
  fam_prefix_ladner_fischer_w28 u19 (.a(remainder5), .b(28'd268434111), .cin(1'b1), .s(difference4), .cout(nonnegative4));
  logic [27:0] remainder4; assign remainder4 = nonnegative4 ? difference4 : remainder5;
  logic [27:0] difference3;
  logic nonnegative3;
  // complete generic-p reduction, shifted modulus 3
  fam_prefix_ladner_fischer_w28 u20 (.a(remainder4), .b(28'd268434783), .cin(1'b1), .s(difference3), .cout(nonnegative3));
  logic [27:0] remainder3; assign remainder3 = nonnegative3 ? difference3 : remainder4;
  logic [27:0] difference2;
  logic nonnegative2;
  // complete generic-p reduction, shifted modulus 2
  fam_prefix_ladner_fischer_w28 u21 (.a(remainder3), .b(28'd268435119), .cin(1'b1), .s(difference2), .cout(nonnegative2));
  logic [27:0] remainder2; assign remainder2 = nonnegative2 ? difference2 : remainder3;
  logic [27:0] difference1;
  logic nonnegative1;
  // complete generic-p reduction, shifted modulus 1
  fam_prefix_ladner_fischer_w28 u22 (.a(remainder2), .b(28'd268435287), .cin(1'b1), .s(difference1), .cout(nonnegative1));
  logic [27:0] remainder1; assign remainder1 = nonnegative1 ? difference1 : remainder2;
  logic [27:0] difference0;
  logic nonnegative0;
  // complete generic-p reduction, shifted modulus 0
  fam_prefix_ladner_fischer_w28 u23 (.a(remainder1), .b(28'd268435371), .cin(1'b1), .s(difference0), .cout(nonnegative0));
  logic [27:0] remainder0; assign remainder0 = nonnegative0 ? difference0 : remainder1;
  assign s = remainder0[26:0];
  assign cout = t[27];
endmodule


// end_around_carry (mod_2n_plus_1_diminished_one, two_pass_prefix, harris, the incrementer prefix_and_incrementer): the carry-out re-enters as the carry-in
module fam_adder_eac_two_pass_prefix_pd56b842a1a7958bea4204a91e282cb4fb8608ad6f9dec53b5d5c8cdf1ffc23b7_w27 (input logic [26:0] a, input logic [26:0] b, input logic cin, output logic [26:0] s, output logic cout);
  logic [26:0] r;
  logic c1;
  // pass 1: the sum and its carry-out
  fam_prefix_harris_l2f2_w27 u1 (.a(a), .b(b), .cin(cin), .s(r), .cout(c1));
  logic back; assign back = ~c1;
  logic [26:0] ri;
  logic wrap;
  // pass 2: the re-entering carry through the incrementer
  fam_incr_prefix_and #(.W(27), .STRUCTURE(1), .B(4), .TOPO(1)) u2 (.a(r), .cin(back), .s(ri), .cout(wrap));
  assign s = ri;
  assign cout = c1;
endmodule


// end_around_carry (mod_2n_minus_1, two_pass_prefix, ladner_fischer, the incrementer prefix_and_incrementer): the carry-out re-enters as the carry-in
module fam_adder_eac_two_pass_prefix_pe78b8b2e14aea3b9e263e35c4eb909349e1798e5a3c0e9bc52ba3c6f4f857ee3_w13 (input logic [12:0] a, input logic [12:0] b, input logic cin, output logic [12:0] s, output logic cout);
  logic [12:0] r;
  logic c1;
  // pass 1: the sum and its carry-out
  fam_prefix_ladner_fischer_w13 u1 (.a(a), .b(b), .cin(cin), .s(r), .cout(c1));
  logic back; assign back = c1;
  logic [12:0] ri;
  logic wrap;
  // pass 2: the re-entering carry through the incrementer
  fam_incr_prefix_and #(.W(13), .STRUCTURE(2), .B(4), .TOPO(0)) u2 (.a(r), .cin(back), .s(ri), .cout(wrap));
  assign s = wrap ? 13'd1 : ri;
  assign cout = c1;
endmodule


// end_around_carry (mod_2n_minus_1, two_pass_prefix, ladner_fischer, the incrementer prefix_and_incrementer): the carry-out re-enters as the carry-in
module fam_adder_eac_two_pass_prefix_pe78b8b2e14aea3b9e263e35c4eb909349e1798e5a3c0e9bc52ba3c6f4f857ee3_w14 (input logic [13:0] a, input logic [13:0] b, input logic cin, output logic [13:0] s, output logic cout);
  logic [13:0] r;
  logic c1;
  // pass 1: the sum and its carry-out
  fam_prefix_ladner_fischer_w14 u1 (.a(a), .b(b), .cin(cin), .s(r), .cout(c1));
  logic back; assign back = c1;
  logic [13:0] ri;
  logic wrap;
  // pass 2: the re-entering carry through the incrementer
  fam_incr_prefix_and #(.W(14), .STRUCTURE(2), .B(4), .TOPO(0)) u2 (.a(r), .cin(back), .s(ri), .cout(wrap));
  assign s = wrap ? 14'd1 : ri;
  assign cout = c1;
endmodule



// -------------------------------------------------------- manchester_carry_chain
// the pass-device carry chain in its synthesizable form: per bit a kill, a
// propagate and a generate, the carry passing through the chain in segments of
// SEG bits (chain_segment_length). VARSKIP = 1 (variable_skip) bypasses a
// segment whose bits all propagate: the segment's carry-out is its carry-in.
module fam_adder_manchester_carry_chain #(parameter int W = 16, parameter int SEG = 4, parameter int VARSKIP = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  localparam int NS = (W + SEG - 1) / SEG;
  logic [W-1:0] g, p, k, pass;
  assign g = a & b;
  assign p = a ^ b;
  assign k = ~(a | b);
  assign pass = ~g & ~k;              // the carry passes when neither killed nor generated
  logic [NS:0] sc;                    // the carry into each segment
  assign sc[0] = cin;
  genvar j, i;
  generate
    for (j = 0; j < NS; j = j + 1) begin : seg
      localparam int LO = j * SEG;
      localparam int HI = (LO + SEG > W) ? W : LO + SEG;
      logic [HI-LO:0] c;
      assign c[0] = sc[j];
      for (i = 0; i < HI - LO; i = i + 1) begin : bit_
        assign c[i+1] = (pass[LO+i] & c[i]) | g[LO+i];
        assign s[LO+i] = p[LO+i] ^ c[i];
      end
      if (VARSKIP) begin : skip
        wire allpass = &pass[HI-1:LO];
        assign sc[j+1] = allpass ? sc[j] : c[HI-LO];
      end else begin : chain
        assign sc[j+1] = c[HI-LO];
      end
    end
  endgenerate
  assign cout = sc[NS];
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).
module fam_adder_ripple_carry #(parameter int W = 16, parameter int CHUNK = 1, parameter int FORM = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  localparam int BLOCKS = (W + CHUNK - 1) / CHUNK;
  logic [BLOCKS:0] block_carry;
  assign block_carry[0] = cin;
  for (genvar block_index = 0; block_index < BLOCKS; block_index = block_index + 1) begin : chunk
    localparam int LO = block_index * CHUNK;
    localparam int BW = LO + CHUNK > W ? W - LO : CHUNK;
    (* keep_hierarchy = "yes" *) fam_adder_ripple_chunk #(.W(BW), .FORM(FORM)) u_chunk(
      .a(a[LO +: BW]), .b(b[LO +: BW]), .cin(block_carry[block_index]),
      .s(s[LO +: BW]), .cout(block_carry[block_index+1]));
  end
  assign cout = block_carry[BLOCKS];
endmodule







module fam_adder_ripple_chunk #(parameter int W = 1, parameter int FORM = 0)
  (input logic [W-1:0] a, input logic [W-1:0] b, input logic cin,
   output logic [W-1:0] s, output logic cout);
  logic [W:0] c;
  assign c[0] = cin;
  genvar i;
  generate
    for (i = 0; i < W; i = i + 1) begin : fa
      if (FORM == 1) begin : two_ha
        wire s1 = a[i] ^ b[i];
        wire c1 = a[i] & b[i];
        wire c2 = s1 & c[i];
        assign s[i] = s1 ^ c[i];
        assign c[i+1] = c1 | c2;
      end else if (FORM == 2) begin : maj
        assign s[i] = a[i] ^ b[i] ^ c[i];
        assign c[i+1] = (a[i] & b[i]) | (a[i] & c[i]) | (b[i] & c[i]);
      end else if (FORM == 3) begin : muxc
        wire p = a[i] ^ b[i];
        assign s[i] = p ^ c[i];
        assign c[i+1] = p ? c[i] : a[i];
      end else begin : gp
        wire g = a[i] & b[i];
        wire p = a[i] ^ b[i];
        assign s[i] = p ^ c[i];
        assign c[i+1] = g | (p & c[i]);
      end
    end
  endgenerate
  assign cout = c[W];
endmodule


// sparse_prefix_hybrid: a sklansky prefix network over blocks of 4 bits, the sums by ripple_precompute
module fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w16 (input logic [15:0] a, input logic [15:0] b, input logic cin, output logic [15:0] s, output logic cout);
  logic [15:0] g; assign g = a & b;
  logic [15:0] p; assign p = a ^ b;
  logic BG0; assign BG0 = (g[3] | (p[3] & (g[2] | (p[2] & (g[1] | (p[1] & g[0]))))));
  logic BP0; assign BP0 = (p[3] & (p[2] & (p[1] & p[0])));
  logic BG1; assign BG1 = (g[7] | (p[7] & (g[6] | (p[6] & (g[5] | (p[5] & g[4]))))));
  logic BP1; assign BP1 = (p[7] & (p[6] & (p[5] & p[4])));
  logic BG2; assign BG2 = (g[11] | (p[11] & (g[10] | (p[10] & (g[9] | (p[9] & g[8]))))));
  logic BP2; assign BP2 = (p[11] & (p[10] & (p[9] & p[8])));
  logic BG3; assign BG3 = (g[15] | (p[15] & (g[14] | (p[14] & (g[13] | (p[13] & g[12]))))));
  logic BP3; assign BP3 = (p[15] & (p[14] & (p[13] & p[12])));
  logic [3:0] net_g; assign net_g = {BG3, BG2, BG1, BG0};
  logic [3:0] net_p; assign net_p = {BP3, BP2, BP1, BP0};
  logic [3:0] net_c;
  logic net_co;
  // the prefix network over the blocks (sklansky)
  fam_prefix_net_sklansky_w4 u1 (.g(net_g), .p(net_p), .cin(cin), .c(net_c), .cout(net_co));
  logic [3:0] s0;
  logic x0;
  // block 0: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w16_component_sum_block_adder_w4 u2 (.a(a[3:0]), .b(b[3:0]), .cin(net_c[0]), .s(s0), .cout(x0));
  assign s[3:0] = s0;
  logic [3:0] s1;
  logic x1;
  // block 1: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w16_component_sum_block_adder_w4 u3 (.a(a[7:4]), .b(b[7:4]), .cin(net_c[1]), .s(s1), .cout(x1));
  assign s[7:4] = s1;
  logic [3:0] s2;
  logic x2;
  // block 2: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w16_component_sum_block_adder_w4 u4 (.a(a[11:8]), .b(b[11:8]), .cin(net_c[2]), .s(s2), .cout(x2));
  assign s[11:8] = s2;
  logic [3:0] s3;
  logic x3;
  // block 3: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w16_component_sum_block_adder_w4 u5 (.a(a[15:12]), .b(b[15:12]), .cin(net_c[3]), .s(s3), .cout(x3));
  assign s[15:12] = s3;
  assign cout = net_co;
endmodule




module fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w16_component_sum_block_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule


// sparse_prefix_hybrid: a sklansky prefix network over blocks of 4 bits, the sums by ripple_precompute









// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).








// sparse_prefix_hybrid: a sklansky prefix network over blocks of 4 bits, the sums by ripple_precompute
module fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w17 (input logic [16:0] a, input logic [16:0] b, input logic cin, output logic [16:0] s, output logic cout);
  logic [16:0] g; assign g = a & b;
  logic [16:0] p; assign p = a ^ b;
  logic BG0; assign BG0 = (g[3] | (p[3] & (g[2] | (p[2] & (g[1] | (p[1] & g[0]))))));
  logic BP0; assign BP0 = (p[3] & (p[2] & (p[1] & p[0])));
  logic BG1; assign BG1 = (g[7] | (p[7] & (g[6] | (p[6] & (g[5] | (p[5] & g[4]))))));
  logic BP1; assign BP1 = (p[7] & (p[6] & (p[5] & p[4])));
  logic BG2; assign BG2 = (g[11] | (p[11] & (g[10] | (p[10] & (g[9] | (p[9] & g[8]))))));
  logic BP2; assign BP2 = (p[11] & (p[10] & (p[9] & p[8])));
  logic BG3; assign BG3 = (g[15] | (p[15] & (g[14] | (p[14] & (g[13] | (p[13] & g[12]))))));
  logic BP3; assign BP3 = (p[15] & (p[14] & (p[13] & p[12])));
  logic BG4; assign BG4 = g[16];
  logic BP4; assign BP4 = p[16];
  logic [4:0] net_g; assign net_g = {BG4, BG3, BG2, BG1, BG0};
  logic [4:0] net_p; assign net_p = {BP4, BP3, BP2, BP1, BP0};
  logic [4:0] net_c;
  logic net_co;
  // the prefix network over the blocks (sklansky)
  fam_prefix_net_sklansky_w5 u1 (.g(net_g), .p(net_p), .cin(cin), .c(net_c), .cout(net_co));
  logic [3:0] s0;
  logic x0;
  // block 0: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w17_component_sum_block_adder_w4 u2 (.a(a[3:0]), .b(b[3:0]), .cin(net_c[0]), .s(s0), .cout(x0));
  assign s[3:0] = s0;
  logic [3:0] s1;
  logic x1;
  // block 1: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w17_component_sum_block_adder_w4 u3 (.a(a[7:4]), .b(b[7:4]), .cin(net_c[1]), .s(s1), .cout(x1));
  assign s[7:4] = s1;
  logic [3:0] s2;
  logic x2;
  // block 2: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w17_component_sum_block_adder_w4 u4 (.a(a[11:8]), .b(b[11:8]), .cin(net_c[2]), .s(s2), .cout(x2));
  assign s[11:8] = s2;
  logic [3:0] s3;
  logic x3;
  // block 3: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w17_component_sum_block_adder_w4 u5 (.a(a[15:12]), .b(b[15:12]), .cin(net_c[3]), .s(s3), .cout(x3));
  assign s[15:12] = s3;
  logic s4;
  logic x4;
  // block 4: the block rippled from the tree's carry
  fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w17_component_sum_block_adder_w1 u6 (.a(a[16:16]), .b(b[16:16]), .cin(net_c[4]), .s(s4), .cout(x4));
  assign s[16:16] = s4;
  assign cout = net_co;
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).









module fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w17_component_sum_block_adder_w1(input wire [0:0] a, input wire [0:0] b, input wire [0:0] cin, output wire [0:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(1), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule
// sparse_prefix_hybrid: a sklansky prefix network over blocks of 4 bits, the sums by ripple_precompute









// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).













module fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w17_component_sum_block_adder_w4(input wire [3:0] a, input wire [3:0] b, input wire [0:0] cin, output wire [3:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule


// sparse_prefix_hybrid: a sklansky prefix network over blocks of 2 bits, the sums by carry_select
module fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w3 (input logic [2:0] a, input logic [2:0] b, input logic cin, output logic [2:0] s, output logic cout);
  logic [2:0] g; assign g = a & b;
  logic [2:0] p; assign p = a ^ b;
  logic BG0; assign BG0 = (g[1] | (p[1] & g[0]));
  logic BP0; assign BP0 = (p[1] & p[0]);
  logic BG1; assign BG1 = g[2];
  logic BP1; assign BP1 = p[2];
  logic [1:0] net_g; assign net_g = {BG1, BG0};
  logic [1:0] net_p; assign net_p = {BP1, BP0};
  logic [1:0] net_c;
  logic net_co;
  // the prefix network over the blocks (sklansky)
  fam_prefix_net_sklansky_w2 u1 (.g(net_g), .p(net_p), .cin(cin), .c(net_c), .cout(net_co));
  logic [1:0] s0_0;
  logic [1:0] s0_1;
  logic x0_0;
  logic x0_1;
  // block 0: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w3_component_sum_block_adder_w2 u2 (.a(a[1:0]), .b(b[1:0]), .cin(1'b0), .s(s0_0), .cout(x0_0));
  // block 0: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w3_component_sum_block_adder_w2 u3 (.a(a[1:0]), .b(b[1:0]), .cin(1'b1), .s(s0_1), .cout(x0_1));
  assign s[1:0] = net_c[0] ? s0_1 : s0_0;
  logic s1_0;
  logic s1_1;
  logic x1_0;
  logic x1_1;
  // block 1: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w3_component_sum_block_adder_w1 u4 (.a(a[2:2]), .b(b[2:2]), .cin(1'b0), .s(s1_0), .cout(x1_0));
  // block 1: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w3_component_sum_block_adder_w1 u5 (.a(a[2:2]), .b(b[2:2]), .cin(1'b1), .s(s1_1), .cout(x1_1));
  assign s[2:2] = net_c[1] ? s1_1 : s1_0;
  assign cout = net_co;
endmodule




module fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w3_component_sum_block_adder_w1(input wire [0:0] a, input wire [0:0] b, input wire [0:0] cin, output wire [0:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(1), .CHUNK(1), .FORM(1)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w3_component_sum_block_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(1)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule


// sparse_prefix_hybrid: a sklansky prefix network over blocks of 2 bits, the sums by carry_select
module fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w4 (input logic [3:0] a, input logic [3:0] b, input logic cin, output logic [3:0] s, output logic cout);
  logic [3:0] g; assign g = a & b;
  logic [3:0] p; assign p = a ^ b;
  logic BG0; assign BG0 = (g[1] | (p[1] & g[0]));
  logic BP0; assign BP0 = (p[1] & p[0]);
  logic BG1; assign BG1 = (g[3] | (p[3] & g[2]));
  logic BP1; assign BP1 = (p[3] & p[2]);
  logic [1:0] net_g; assign net_g = {BG1, BG0};
  logic [1:0] net_p; assign net_p = {BP1, BP0};
  logic [1:0] net_c;
  logic net_co;
  // the prefix network over the blocks (sklansky)
  fam_prefix_net_sklansky_w2 u1 (.g(net_g), .p(net_p), .cin(cin), .c(net_c), .cout(net_co));
  logic [1:0] s0_0;
  logic [1:0] s0_1;
  logic x0_0;
  logic x0_1;
  // block 0: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w4_component_sum_block_adder_w2 u2 (.a(a[1:0]), .b(b[1:0]), .cin(1'b0), .s(s0_0), .cout(x0_0));
  // block 0: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w4_component_sum_block_adder_w2 u3 (.a(a[1:0]), .b(b[1:0]), .cin(1'b1), .s(s0_1), .cout(x0_1));
  assign s[1:0] = net_c[0] ? s0_1 : s0_0;
  logic [1:0] s1_0;
  logic [1:0] s1_1;
  logic x1_0;
  logic x1_1;
  // block 1: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w4_component_sum_block_adder_w2 u4 (.a(a[3:2]), .b(b[3:2]), .cin(1'b0), .s(s1_0), .cout(x1_0));
  // block 1: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w4_component_sum_block_adder_w2 u5 (.a(a[3:2]), .b(b[3:2]), .cin(1'b1), .s(s1_1), .cout(x1_1));
  assign s[3:2] = net_c[1] ? s1_1 : s1_0;
  assign cout = net_co;
endmodule







module fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w4_component_sum_block_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(1)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).








// sparse_prefix_hybrid: a sklansky prefix network over blocks of 2 bits, the sums by carry_select
module fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w5 (input logic [4:0] a, input logic [4:0] b, input logic cin, output logic [4:0] s, output logic cout);
  logic [4:0] g; assign g = a & b;
  logic [4:0] p; assign p = a ^ b;
  logic BG0; assign BG0 = (g[1] | (p[1] & g[0]));
  logic BP0; assign BP0 = (p[1] & p[0]);
  logic BG1; assign BG1 = (g[3] | (p[3] & g[2]));
  logic BP1; assign BP1 = (p[3] & p[2]);
  logic BG2; assign BG2 = g[4];
  logic BP2; assign BP2 = p[4];
  logic [2:0] net_g; assign net_g = {BG2, BG1, BG0};
  logic [2:0] net_p; assign net_p = {BP2, BP1, BP0};
  logic [2:0] net_c;
  logic net_co;
  // the prefix network over the blocks (sklansky)
  fam_prefix_net_sklansky_w3 u1 (.g(net_g), .p(net_p), .cin(cin), .c(net_c), .cout(net_co));
  logic [1:0] s0_0;
  logic [1:0] s0_1;
  logic x0_0;
  logic x0_1;
  // block 0: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w5_component_sum_block_adder_w2 u2 (.a(a[1:0]), .b(b[1:0]), .cin(1'b0), .s(s0_0), .cout(x0_0));
  // block 0: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w5_component_sum_block_adder_w2 u3 (.a(a[1:0]), .b(b[1:0]), .cin(1'b1), .s(s0_1), .cout(x0_1));
  assign s[1:0] = net_c[0] ? s0_1 : s0_0;
  logic [1:0] s1_0;
  logic [1:0] s1_1;
  logic x1_0;
  logic x1_1;
  // block 1: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w5_component_sum_block_adder_w2 u4 (.a(a[3:2]), .b(b[3:2]), .cin(1'b0), .s(s1_0), .cout(x1_0));
  // block 1: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w5_component_sum_block_adder_w2 u5 (.a(a[3:2]), .b(b[3:2]), .cin(1'b1), .s(s1_1), .cout(x1_1));
  assign s[3:2] = net_c[1] ? s1_1 : s1_0;
  logic s2_0;
  logic s2_1;
  logic x2_0;
  logic x2_1;
  // block 2: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w5_component_sum_block_adder_w1 u6 (.a(a[4:4]), .b(b[4:4]), .cin(1'b0), .s(s2_0), .cout(x2_0));
  // block 2: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w5_component_sum_block_adder_w1 u7 (.a(a[4:4]), .b(b[4:4]), .cin(1'b1), .s(s2_1), .cout(x2_1));
  assign s[4:4] = net_c[2] ? s2_1 : s2_0;
  assign cout = net_co;
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).









module fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w5_component_sum_block_adder_w1(input wire [0:0] a, input wire [0:0] b, input wire [0:0] cin, output wire [0:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(1), .CHUNK(1), .FORM(1)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule




module fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w5_component_sum_block_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(1)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule


// sparse_prefix_hybrid: a sklansky prefix network over blocks of 2 bits, the sums by carry_select
module fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w6 (input logic [5:0] a, input logic [5:0] b, input logic cin, output logic [5:0] s, output logic cout);
  logic [5:0] g; assign g = a & b;
  logic [5:0] p; assign p = a ^ b;
  logic BG0; assign BG0 = (g[1] | (p[1] & g[0]));
  logic BP0; assign BP0 = (p[1] & p[0]);
  logic BG1; assign BG1 = (g[3] | (p[3] & g[2]));
  logic BP1; assign BP1 = (p[3] & p[2]);
  logic BG2; assign BG2 = (g[5] | (p[5] & g[4]));
  logic BP2; assign BP2 = (p[5] & p[4]);
  logic [2:0] net_g; assign net_g = {BG2, BG1, BG0};
  logic [2:0] net_p; assign net_p = {BP2, BP1, BP0};
  logic [2:0] net_c;
  logic net_co;
  // the prefix network over the blocks (sklansky)
  fam_prefix_net_sklansky_w3 u1 (.g(net_g), .p(net_p), .cin(cin), .c(net_c), .cout(net_co));
  logic [1:0] s0_0;
  logic [1:0] s0_1;
  logic x0_0;
  logic x0_1;
  // block 0: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w6_component_sum_block_adder_w2 u2 (.a(a[1:0]), .b(b[1:0]), .cin(1'b0), .s(s0_0), .cout(x0_0));
  // block 0: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w6_component_sum_block_adder_w2 u3 (.a(a[1:0]), .b(b[1:0]), .cin(1'b1), .s(s0_1), .cout(x0_1));
  assign s[1:0] = net_c[0] ? s0_1 : s0_0;
  logic [1:0] s1_0;
  logic [1:0] s1_1;
  logic x1_0;
  logic x1_1;
  // block 1: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w6_component_sum_block_adder_w2 u4 (.a(a[3:2]), .b(b[3:2]), .cin(1'b0), .s(s1_0), .cout(x1_0));
  // block 1: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w6_component_sum_block_adder_w2 u5 (.a(a[3:2]), .b(b[3:2]), .cin(1'b1), .s(s1_1), .cout(x1_1));
  assign s[3:2] = net_c[1] ? s1_1 : s1_0;
  logic [1:0] s2_0;
  logic [1:0] s2_1;
  logic x2_0;
  logic x2_1;
  // block 2: the sum under carry-in 0
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w6_component_sum_block_adder_w2 u6 (.a(a[5:4]), .b(b[5:4]), .cin(1'b0), .s(s2_0), .cout(x2_0));
  // block 2: the sum under carry-in 1
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w6_component_sum_block_adder_w2 u7 (.a(a[5:4]), .b(b[5:4]), .cin(1'b1), .s(s2_1), .cout(x2_1));
  assign s[5:4] = net_c[2] ? s2_1 : s2_0;
  assign cout = net_co;
endmodule







module fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w6_component_sum_block_adder_w2(input wire [1:0] a, input wire [1:0] b, input wire [0:0] cin, output wire [1:0] s, output wire [0:0] cout);
fam_adder_ripple_carry #(.W(2), .CHUNK(1), .FORM(1)) implementation(.a(a), .b(b), .cin(cin), .s(s), .cout(cout));
endmodule


// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).











// trailing_zero (isolate_then_encode, twos_complement_and): the lowest one isolated and encoded

// selected EAC followed by an ordinary binary sum/carry decoder
module fam_binary_decode_fam_adder_eac_cyclic_prefix_level_p71ad0afc38c98cc878595b2be2d3d81b739691b88149561a71e54f41570fbe7b_w27 (input logic [26:0] a,b, input logic cin, output logic [26:0] s, output logic cout);
  logic [26:0] rns_eac1_a; assign rns_eac1_a = a;
  logic [26:0] rns_eac1_b; assign rns_eac1_b = b;
  logic rns_eac1_cin; assign rns_eac1_cin = cin;
  logic [26:0] rns_eac1_encoded_sum;
  logic rns_eac1_encoded_carry;
  // : selected EAC followed by binary encoding decode
  fam_adder_eac_cyclic_prefix_level_p71ad0afc38c98cc878595b2be2d3d81b739691b88149561a71e54f41570fbe7b_w27 u1 (.a(rns_eac1_a), .b(rns_eac1_b), .cin(rns_eac1_cin), .s(rns_eac1_encoded_sum), .cout(rns_eac1_encoded_carry));
  logic [20:0] rns_eac1_qa; assign rns_eac1_qa = rns_eac1_a / 27'd84;
  logic [20:0] rns_eac1_qb; assign rns_eac1_qb = rns_eac1_b / 27'd84;
  logic [6:0] rns_eac1_ra; assign rns_eac1_ra = rns_eac1_a % 27'd84;
  logic [6:0] rns_eac1_rb; assign rns_eac1_rb = rns_eac1_b % 27'd84;
  logic [7:0] rns_eac1_partial; assign rns_eac1_partial = rns_eac1_ra + rns_eac1_rb + rns_eac1_cin;
  logic rns_eac1_quotient_carry; assign rns_eac1_quotient_carry = rns_eac1_partial >= 8'd84;
  logic [21:0] rns_eac1_quotient; assign rns_eac1_quotient = rns_eac1_qa + rns_eac1_qb + rns_eac1_quotient_carry;
  logic [27:0] rns_eac1_coarse; assign rns_eac1_coarse = rns_eac1_quotient * 28'd84;
  logic [27:0] rns_eac1_decoded_sum; assign rns_eac1_decoded_sum = rns_eac1_coarse + rns_eac1_encoded_sum;
  logic rns_eac1_raw_carry; assign rns_eac1_raw_carry = rns_eac1_encoded_carry;
  assign s = rns_eac1_decoded_sum[26:0];
  assign cout = rns_eac1_raw_carry;
endmodule







// selected EAC followed by an ordinary binary sum/carry decoder
module fam_binary_decode_fam_adder_eac_two_pass_prefix_pd56b842a1a7958bea4204a91e282cb4fb8608ad6f9dec53b5d5c8cdf1ffc23b7_w27 (input logic [26:0] a,b, input logic cin, output logic [26:0] s, output logic cout);
  logic [26:0] rns_eac1_a; assign rns_eac1_a = a;
  logic [26:0] rns_eac1_b; assign rns_eac1_b = b;
  logic rns_eac1_cin; assign rns_eac1_cin = cin;
  logic [26:0] rns_eac1_encoded_sum;
  logic rns_eac1_encoded_carry;
  // : selected EAC followed by binary encoding decode
  fam_adder_eac_two_pass_prefix_pd56b842a1a7958bea4204a91e282cb4fb8608ad6f9dec53b5d5c8cdf1ffc23b7_w27 u1 (.a(rns_eac1_a), .b(rns_eac1_b), .cin(rns_eac1_cin), .s(rns_eac1_encoded_sum), .cout(rns_eac1_encoded_carry));
  logic rns_eac1_all_max; assign rns_eac1_all_max = (&rns_eac1_a) & (&rns_eac1_b) & rns_eac1_cin;
  logic rns_eac1_raw_carry; assign rns_eac1_raw_carry = rns_eac1_encoded_carry;
  logic rns_eac1_decrement; assign rns_eac1_decrement = ~rns_eac1_raw_carry;
  logic [26:0] rns_eac1_decoded_sum;
  assign rns_eac1_decoded_sum[0] = rns_eac1_encoded_sum[0] ^ rns_eac1_decrement;
  assign rns_eac1_decoded_sum[1] = rns_eac1_encoded_sum[1] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[0:0]));
  assign rns_eac1_decoded_sum[2] = rns_eac1_encoded_sum[2] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[1:0]));
  assign rns_eac1_decoded_sum[3] = rns_eac1_encoded_sum[3] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[2:0]));
  assign rns_eac1_decoded_sum[4] = rns_eac1_encoded_sum[4] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[3:0]));
  assign rns_eac1_decoded_sum[5] = rns_eac1_encoded_sum[5] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[4:0]));
  assign rns_eac1_decoded_sum[6] = rns_eac1_encoded_sum[6] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[5:0]));
  assign rns_eac1_decoded_sum[7] = rns_eac1_encoded_sum[7] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[6:0]));
  assign rns_eac1_decoded_sum[8] = rns_eac1_encoded_sum[8] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[7:0]));
  assign rns_eac1_decoded_sum[9] = rns_eac1_encoded_sum[9] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[8:0]));
  assign rns_eac1_decoded_sum[10] = rns_eac1_encoded_sum[10] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[9:0]));
  assign rns_eac1_decoded_sum[11] = rns_eac1_encoded_sum[11] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[10:0]));
  assign rns_eac1_decoded_sum[12] = rns_eac1_encoded_sum[12] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[11:0]));
  assign rns_eac1_decoded_sum[13] = rns_eac1_encoded_sum[13] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[12:0]));
  assign rns_eac1_decoded_sum[14] = rns_eac1_encoded_sum[14] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[13:0]));
  assign rns_eac1_decoded_sum[15] = rns_eac1_encoded_sum[15] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[14:0]));
  assign rns_eac1_decoded_sum[16] = rns_eac1_encoded_sum[16] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[15:0]));
  assign rns_eac1_decoded_sum[17] = rns_eac1_encoded_sum[17] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[16:0]));
  assign rns_eac1_decoded_sum[18] = rns_eac1_encoded_sum[18] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[17:0]));
  assign rns_eac1_decoded_sum[19] = rns_eac1_encoded_sum[19] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[18:0]));
  assign rns_eac1_decoded_sum[20] = rns_eac1_encoded_sum[20] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[19:0]));
  assign rns_eac1_decoded_sum[21] = rns_eac1_encoded_sum[21] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[20:0]));
  assign rns_eac1_decoded_sum[22] = rns_eac1_encoded_sum[22] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[21:0]));
  assign rns_eac1_decoded_sum[23] = rns_eac1_encoded_sum[23] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[22:0]));
  assign rns_eac1_decoded_sum[24] = rns_eac1_encoded_sum[24] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[23:0]));
  assign rns_eac1_decoded_sum[25] = rns_eac1_encoded_sum[25] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[24:0]));
  assign rns_eac1_decoded_sum[26] = rns_eac1_encoded_sum[26] ^ (rns_eac1_decrement & ~(|rns_eac1_encoded_sum[25:0]));
  assign s = rns_eac1_decoded_sum;
  assign cout = rns_eac1_raw_carry;
endmodule


// selected EAC followed by an ordinary binary sum/carry decoder
module fam_binary_decode_fam_adder_eac_two_pass_prefix_pe78b8b2e14aea3b9e263e35c4eb909349e1798e5a3c0e9bc52ba3c6f4f857ee3_w13 (input logic [12:0] a,b, input logic cin, output logic [12:0] s, output logic cout);
  logic [12:0] rns_eac1_a; assign rns_eac1_a = a;
  logic [12:0] rns_eac1_b; assign rns_eac1_b = b;
  logic rns_eac1_cin; assign rns_eac1_cin = cin;
  logic [12:0] rns_eac1_encoded_sum;
  logic rns_eac1_encoded_carry;
  // : selected EAC followed by binary encoding decode
  fam_adder_eac_two_pass_prefix_pe78b8b2e14aea3b9e263e35c4eb909349e1798e5a3c0e9bc52ba3c6f4f857ee3_w13 u1 (.a(rns_eac1_a), .b(rns_eac1_b), .cin(rns_eac1_cin), .s(rns_eac1_encoded_sum), .cout(rns_eac1_encoded_carry));
  logic rns_eac1_all_max; assign rns_eac1_all_max = (&rns_eac1_a) & (&rns_eac1_b) & rns_eac1_cin;
  logic rns_eac1_raw_carry; assign rns_eac1_raw_carry = rns_eac1_encoded_carry | (rns_eac1_cin & (&(rns_eac1_a ^ rns_eac1_b)));
  logic [12:0] rns_eac1_decoded_sum;
  assign rns_eac1_decoded_sum[0] = rns_eac1_encoded_sum[0] ^ rns_eac1_raw_carry;
  assign rns_eac1_decoded_sum[1] = rns_eac1_encoded_sum[1] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[0:0]));
  assign rns_eac1_decoded_sum[2] = rns_eac1_encoded_sum[2] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[1:0]));
  assign rns_eac1_decoded_sum[3] = rns_eac1_encoded_sum[3] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[2:0]));
  assign rns_eac1_decoded_sum[4] = rns_eac1_encoded_sum[4] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[3:0]));
  assign rns_eac1_decoded_sum[5] = rns_eac1_encoded_sum[5] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[4:0]));
  assign rns_eac1_decoded_sum[6] = rns_eac1_encoded_sum[6] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[5:0]));
  assign rns_eac1_decoded_sum[7] = rns_eac1_encoded_sum[7] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[6:0]));
  assign rns_eac1_decoded_sum[8] = rns_eac1_encoded_sum[8] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[7:0]));
  assign rns_eac1_decoded_sum[9] = rns_eac1_encoded_sum[9] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[8:0]));
  assign rns_eac1_decoded_sum[10] = rns_eac1_encoded_sum[10] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[9:0]));
  assign rns_eac1_decoded_sum[11] = rns_eac1_encoded_sum[11] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[10:0]));
  assign rns_eac1_decoded_sum[12] = rns_eac1_encoded_sum[12] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[11:0]));
  assign s = rns_eac1_all_max ? {13{1'b1}} : rns_eac1_decoded_sum;
  assign cout = rns_eac1_raw_carry;
endmodule


// selected EAC followed by an ordinary binary sum/carry decoder

// end_around_carry (mod_2n_minus_1, two_pass_prefix, ladner_fischer, the incrementer prefix_and_incrementer): the carry-out re-enters as the carry-in


// selected EAC followed by an ordinary binary sum/carry decoder
module fam_binary_decode_fam_adder_eac_two_pass_prefix_pe78b8b2e14aea3b9e263e35c4eb909349e1798e5a3c0e9bc52ba3c6f4f857ee3_w14 (input logic [13:0] a,b, input logic cin, output logic [13:0] s, output logic cout);
  logic [13:0] rns_eac1_a; assign rns_eac1_a = a;
  logic [13:0] rns_eac1_b; assign rns_eac1_b = b;
  logic rns_eac1_cin; assign rns_eac1_cin = cin;
  logic [13:0] rns_eac1_encoded_sum;
  logic rns_eac1_encoded_carry;
  // : selected EAC followed by binary encoding decode
  fam_adder_eac_two_pass_prefix_pe78b8b2e14aea3b9e263e35c4eb909349e1798e5a3c0e9bc52ba3c6f4f857ee3_w14 u1 (.a(rns_eac1_a), .b(rns_eac1_b), .cin(rns_eac1_cin), .s(rns_eac1_encoded_sum), .cout(rns_eac1_encoded_carry));
  logic rns_eac1_all_max; assign rns_eac1_all_max = (&rns_eac1_a) & (&rns_eac1_b) & rns_eac1_cin;
  logic rns_eac1_raw_carry; assign rns_eac1_raw_carry = rns_eac1_encoded_carry | (rns_eac1_cin & (&(rns_eac1_a ^ rns_eac1_b)));
  logic [13:0] rns_eac1_decoded_sum;
  assign rns_eac1_decoded_sum[0] = rns_eac1_encoded_sum[0] ^ rns_eac1_raw_carry;
  assign rns_eac1_decoded_sum[1] = rns_eac1_encoded_sum[1] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[0:0]));
  assign rns_eac1_decoded_sum[2] = rns_eac1_encoded_sum[2] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[1:0]));
  assign rns_eac1_decoded_sum[3] = rns_eac1_encoded_sum[3] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[2:0]));
  assign rns_eac1_decoded_sum[4] = rns_eac1_encoded_sum[4] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[3:0]));
  assign rns_eac1_decoded_sum[5] = rns_eac1_encoded_sum[5] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[4:0]));
  assign rns_eac1_decoded_sum[6] = rns_eac1_encoded_sum[6] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[5:0]));
  assign rns_eac1_decoded_sum[7] = rns_eac1_encoded_sum[7] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[6:0]));
  assign rns_eac1_decoded_sum[8] = rns_eac1_encoded_sum[8] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[7:0]));
  assign rns_eac1_decoded_sum[9] = rns_eac1_encoded_sum[9] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[8:0]));
  assign rns_eac1_decoded_sum[10] = rns_eac1_encoded_sum[10] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[9:0]));
  assign rns_eac1_decoded_sum[11] = rns_eac1_encoded_sum[11] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[10:0]));
  assign rns_eac1_decoded_sum[12] = rns_eac1_encoded_sum[12] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[11:0]));
  assign rns_eac1_decoded_sum[13] = rns_eac1_encoded_sum[13] ^ (rns_eac1_raw_carry & ~(|rns_eac1_encoded_sum[12:0]));
  assign s = rns_eac1_all_max ? {14{1'b1}} : rns_eac1_decoded_sum;
  assign cout = rns_eac1_raw_carry;
endmodule


// subtractor_comparator (ling_prefix, operand_xnor, unsigned): a - b through the adder's carry-out, the sum path unused
module fam_cmp_subtractor_ling_prefix_p6e18491987e97adb7af7143255ee504d7ae2c4e4893b558c56b954fb17ad0f22_operand_xnor_u_w13 (input logic [12:0] a, input logic [12:0] b, output logic lt, output logic eq);
  logic [12:0] ax, bx, nb, s;
  logic co;
  assign ax = {a[12] ^ 1'b0, a[11:0]};
  assign bx = {b[12] ^ 1'b0, b[11:0]};
  assign nb = ~bx;
  // the subtractor: the adder (ling_prefix) on a and ~b with a carry in; no carry out means a < b
  fam_prefix_kogge_stone_w13_ling2 u_sub (.a(ax), .b(nb), .cin(1'b1), .s(s), .cout(co));
  assign lt = ~co;
  assign eq = &(ax ~^ bx);     // the operands' XNOR tree
endmodule


// subtractor_comparator (ling_prefix, operand_xnor, unsigned): a - b through the adder's carry-out, the sum path unused
module fam_cmp_subtractor_ling_prefix_p6e18491987e97adb7af7143255ee504d7ae2c4e4893b558c56b954fb17ad0f22_operand_xnor_u_w27 (input logic [26:0] a, input logic [26:0] b, output logic lt, output logic eq);
  logic [26:0] ax, bx, nb, s;
  logic co;
  assign ax = {a[26] ^ 1'b0, a[25:0]};
  assign bx = {b[26] ^ 1'b0, b[25:0]};
  assign nb = ~bx;
  // the subtractor: the adder (ling_prefix) on a and ~b with a carry in; no carry out means a < b
  fam_prefix_kogge_stone_w27_ling2 u_sub (.a(ax), .b(nb), .cin(1'b1), .s(s), .cout(co));
  assign lt = ~co;
  assign eq = &(ax ~^ bx);     // the operands' XNOR tree
endmodule


// subtractor_comparator (prefix_synthesis_nonuniform_arrival, sum_or_tree, unsigned): a - b through the adder's carry-out, the sum path unused
module fam_cmp_subtractor_prefix_synthesis_nonuniform_arrival_p91919e29d8984fc7b1564e16baf52afcd8459b99d9f7793d8c56df316dce0a37_sum_or_tree_u_w24 (input logic [23:0] a, input logic [23:0] b, output logic lt, output logic eq);
  logic [23:0] ax, bx, nb, s;
  logic co;
  assign ax = {a[23] ^ 1'b0, a[22:0]};
  assign bx = {b[23] ^ 1'b0, b[22:0]};
  assign nb = ~bx;
  // the subtractor: the adder (prefix_synthesis_nonuniform_arrival) on a and ~b with a carry in; no carry out means a < b
  fam_prefix_arrival_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_w24 u_sub (.a(ax), .b(nb), .cin(1'b1), .s(s), .cout(co));
  assign lt = ~co;
  assign eq = (s == '0);       // the difference is zero
endmodule


// subtractor_comparator (ripple_carry, sum_or_tree, unsigned): a - b through the adder's carry-out, the sum path unused
module fam_cmp_subtractor_ripple_carry_p0a9f116f38aacd499cf3fe7c2675658275429e00f2c08fee42fa2d9523cdc581_sum_or_tree_u_w16 (input logic [15:0] a, input logic [15:0] b, output logic lt, output logic eq);
  logic [15:0] ax, bx, nb, s;
  logic co;
  assign ax = {a[15] ^ 1'b0, a[14:0]};
  assign bx = {b[15] ^ 1'b0, b[14:0]};
  assign nb = ~bx;
  // the subtractor: the adder (ripple_carry) on a and ~b with a carry in; no carry out means a < b
  fam_adder_ripple_carry #(.W(16), .CHUNK(2), .FORM(1)) u_sub (.a(ax), .b(nb), .cin(1'b1), .s(s), .cout(co));
  assign lt = ~co;
  assign eq = (s == '0);       // the difference is zero
endmodule


// subtractor_comparator (ripple_carry, sum_or_tree, unsigned): a - b through the adder's carry-out, the sum path unused
module fam_cmp_subtractor_ripple_carry_p0a9f116f38aacd499cf3fe7c2675658275429e00f2c08fee42fa2d9523cdc581_sum_or_tree_u_w21 (input logic [20:0] a, input logic [20:0] b, output logic lt, output logic eq);
  logic [20:0] ax, bx, nb, s;
  logic co;
  assign ax = {a[20] ^ 1'b0, a[19:0]};
  assign bx = {b[20] ^ 1'b0, b[19:0]};
  assign nb = ~bx;
  // the subtractor: the adder (ripple_carry) on a and ~b with a carry in; no carry out means a < b
  fam_adder_ripple_carry #(.W(21), .CHUNK(2), .FORM(1)) u_sub (.a(ax), .b(nb), .cin(1'b1), .s(s), .cout(co));
  assign lt = ~co;
  assign eq = (s == '0);       // the difference is zero
endmodule




// lzd_cell_tree (nibble_cell, binary_count, valid flags flat): the leading zeros of a 20-bit word
module fam_count_lzd_nibble_cell_binary_count_vflat_w20 (input logic [19:0] a, output logic [4:0] n);
  logic v0_0; assign v0_0 = a[19] | a[18] | a[17] | a[16];
  logic [1:0] p0_0; assign p0_0 = a[19] ? 2'd0 : a[18] ? 2'd1 : a[17] ? 2'd2 : 2'd3;
  logic v0_1; assign v0_1 = a[15] | a[14] | a[13] | a[12];
  logic [1:0] p0_1; assign p0_1 = a[15] ? 2'd0 : a[14] ? 2'd1 : a[13] ? 2'd2 : 2'd3;
  logic v0_2; assign v0_2 = a[11] | a[10] | a[9] | a[8];
  logic [1:0] p0_2; assign p0_2 = a[11] ? 2'd0 : a[10] ? 2'd1 : a[9] ? 2'd2 : 2'd3;
  logic v0_3; assign v0_3 = a[7] | a[6] | a[5] | a[4];
  logic [1:0] p0_3; assign p0_3 = a[7] ? 2'd0 : a[6] ? 2'd1 : a[5] ? 2'd2 : 2'd3;
  logic v0_4; assign v0_4 = a[3] | a[2] | a[1] | a[0];
  logic [1:0] p0_4; assign p0_4 = a[3] ? 2'd0 : a[2] ? 2'd1 : a[1] ? 2'd2 : 2'd3;
  logic v0_5; assign v0_5 = 1'b0 | 1'b0 | 1'b0 | 1'b0;
  logic [1:0] p0_5; assign p0_5 = 1'b0 ? 2'd0 : 1'b0 ? 2'd1 : 1'b0 ? 2'd2 : 2'd3;
  logic v0_6; assign v0_6 = 1'b0 | 1'b0 | 1'b0 | 1'b0;
  logic [1:0] p0_6; assign p0_6 = 1'b0 ? 2'd0 : 1'b0 ? 2'd1 : 1'b0 ? 2'd2 : 2'd3;
  logic v0_7; assign v0_7 = 1'b0 | 1'b0 | 1'b0 | 1'b0;
  logic [1:0] p0_7; assign p0_7 = 1'b0 ? 2'd0 : 1'b0 ? 2'd1 : 1'b0 ? 2'd2 : 2'd3;
  logic v1_0; assign v1_0 = a[19] | a[18] | a[17] | a[16] | a[15] | a[14] | a[13] | a[12];
  logic [2:0] p1_0; assign p1_0 = v0_0 ? {1'b0, p0_0} : {1'b1, p0_1};
  logic v1_1; assign v1_1 = a[11] | a[10] | a[9] | a[8] | a[7] | a[6] | a[5] | a[4];
  logic [2:0] p1_1; assign p1_1 = v0_2 ? {1'b0, p0_2} : {1'b1, p0_3};
  logic v1_2; assign v1_2 = a[3] | a[2] | a[1] | a[0] | 1'b0 | 1'b0 | 1'b0 | 1'b0;
  logic [2:0] p1_2; assign p1_2 = v0_4 ? {1'b0, p0_4} : {1'b1, p0_5};
  logic v1_3; assign v1_3 = 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0;
  logic [2:0] p1_3; assign p1_3 = v0_6 ? {1'b0, p0_6} : {1'b1, p0_7};
  logic v2_0; assign v2_0 = a[19] | a[18] | a[17] | a[16] | a[15] | a[14] | a[13] | a[12] | a[11] | a[10] | a[9] | a[8] | a[7] | a[6] | a[5] | a[4];
  logic [3:0] p2_0; assign p2_0 = v1_0 ? {1'b0, p1_0} : {1'b1, p1_1};
  logic v2_1; assign v2_1 = a[3] | a[2] | a[1] | a[0] | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0;
  logic [3:0] p2_1; assign p2_1 = v1_2 ? {1'b0, p1_2} : {1'b1, p1_3};
  logic v3_0; assign v3_0 = a[19] | a[18] | a[17] | a[16] | a[15] | a[14] | a[13] | a[12] | a[11] | a[10] | a[9] | a[8] | a[7] | a[6] | a[5] | a[4] | a[3] | a[2] | a[1] | a[0] | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0 | 1'b0;
  logic [4:0] p3_0; assign p3_0 = v2_0 ? {1'b0, p2_0} : {1'b1, p2_1};
  assign n = v3_0 ? p3_0 : 5'd20;
endmodule


// lzd_cell_tree (nibble_cell, binary_count, valid flags propagated): the leading zeros of a 8-bit word
module fam_count_lzd_nibble_cell_binary_count_vprop_w8 (input logic [7:0] a, output logic [3:0] n);
  logic v0_0; assign v0_0 = a[7] | a[6] | a[5] | a[4];
  logic [1:0] p0_0; assign p0_0 = a[7] ? 2'd0 : a[6] ? 2'd1 : a[5] ? 2'd2 : 2'd3;
  logic v0_1; assign v0_1 = a[3] | a[2] | a[1] | a[0];
  logic [1:0] p0_1; assign p0_1 = a[3] ? 2'd0 : a[2] ? 2'd1 : a[1] ? 2'd2 : 2'd3;
  logic v1_0; assign v1_0 = v0_0 | v0_1;
  logic [2:0] p1_0; assign p1_0 = v0_0 ? {1'b0, p0_0} : {1'b1, p0_1};
  assign n = v1_0 ? {1'd0, p1_0} : 4'd8;
endmodule



// lzd_cell_tree (pair_cell, binary_count, valid flags propagated): the leading zeros of a 64-bit word
module fam_count_lzd_pair_cell_binary_count_vprop_w64 (input logic [63:0] a, output logic [6:0] n);
  logic v0_0; assign v0_0 = a[63] | a[62];
  logic p0_0; assign p0_0 = ~a[63];
  logic v0_1; assign v0_1 = a[61] | a[60];
  logic p0_1; assign p0_1 = ~a[61];
  logic v0_2; assign v0_2 = a[59] | a[58];
  logic p0_2; assign p0_2 = ~a[59];
  logic v0_3; assign v0_3 = a[57] | a[56];
  logic p0_3; assign p0_3 = ~a[57];
  logic v0_4; assign v0_4 = a[55] | a[54];
  logic p0_4; assign p0_4 = ~a[55];
  logic v0_5; assign v0_5 = a[53] | a[52];
  logic p0_5; assign p0_5 = ~a[53];
  logic v0_6; assign v0_6 = a[51] | a[50];
  logic p0_6; assign p0_6 = ~a[51];
  logic v0_7; assign v0_7 = a[49] | a[48];
  logic p0_7; assign p0_7 = ~a[49];
  logic v0_8; assign v0_8 = a[47] | a[46];
  logic p0_8; assign p0_8 = ~a[47];
  logic v0_9; assign v0_9 = a[45] | a[44];
  logic p0_9; assign p0_9 = ~a[45];
  logic v0_10; assign v0_10 = a[43] | a[42];
  logic p0_10; assign p0_10 = ~a[43];
  logic v0_11; assign v0_11 = a[41] | a[40];
  logic p0_11; assign p0_11 = ~a[41];
  logic v0_12; assign v0_12 = a[39] | a[38];
  logic p0_12; assign p0_12 = ~a[39];
  logic v0_13; assign v0_13 = a[37] | a[36];
  logic p0_13; assign p0_13 = ~a[37];
  logic v0_14; assign v0_14 = a[35] | a[34];
  logic p0_14; assign p0_14 = ~a[35];
  logic v0_15; assign v0_15 = a[33] | a[32];
  logic p0_15; assign p0_15 = ~a[33];
  logic v0_16; assign v0_16 = a[31] | a[30];
  logic p0_16; assign p0_16 = ~a[31];
  logic v0_17; assign v0_17 = a[29] | a[28];
  logic p0_17; assign p0_17 = ~a[29];
  logic v0_18; assign v0_18 = a[27] | a[26];
  logic p0_18; assign p0_18 = ~a[27];
  logic v0_19; assign v0_19 = a[25] | a[24];
  logic p0_19; assign p0_19 = ~a[25];
  logic v0_20; assign v0_20 = a[23] | a[22];
  logic p0_20; assign p0_20 = ~a[23];
  logic v0_21; assign v0_21 = a[21] | a[20];
  logic p0_21; assign p0_21 = ~a[21];
  logic v0_22; assign v0_22 = a[19] | a[18];
  logic p0_22; assign p0_22 = ~a[19];
  logic v0_23; assign v0_23 = a[17] | a[16];
  logic p0_23; assign p0_23 = ~a[17];
  logic v0_24; assign v0_24 = a[15] | a[14];
  logic p0_24; assign p0_24 = ~a[15];
  logic v0_25; assign v0_25 = a[13] | a[12];
  logic p0_25; assign p0_25 = ~a[13];
  logic v0_26; assign v0_26 = a[11] | a[10];
  logic p0_26; assign p0_26 = ~a[11];
  logic v0_27; assign v0_27 = a[9] | a[8];
  logic p0_27; assign p0_27 = ~a[9];
  logic v0_28; assign v0_28 = a[7] | a[6];
  logic p0_28; assign p0_28 = ~a[7];
  logic v0_29; assign v0_29 = a[5] | a[4];
  logic p0_29; assign p0_29 = ~a[5];
  logic v0_30; assign v0_30 = a[3] | a[2];
  logic p0_30; assign p0_30 = ~a[3];
  logic v0_31; assign v0_31 = a[1] | a[0];
  logic p0_31; assign p0_31 = ~a[1];
  logic v1_0; assign v1_0 = v0_0 | v0_1;
  logic [1:0] p1_0; assign p1_0 = v0_0 ? {1'b0, p0_0} : {1'b1, p0_1};
  logic v1_1; assign v1_1 = v0_2 | v0_3;
  logic [1:0] p1_1; assign p1_1 = v0_2 ? {1'b0, p0_2} : {1'b1, p0_3};
  logic v1_2; assign v1_2 = v0_4 | v0_5;
  logic [1:0] p1_2; assign p1_2 = v0_4 ? {1'b0, p0_4} : {1'b1, p0_5};
  logic v1_3; assign v1_3 = v0_6 | v0_7;
  logic [1:0] p1_3; assign p1_3 = v0_6 ? {1'b0, p0_6} : {1'b1, p0_7};
  logic v1_4; assign v1_4 = v0_8 | v0_9;
  logic [1:0] p1_4; assign p1_4 = v0_8 ? {1'b0, p0_8} : {1'b1, p0_9};
  logic v1_5; assign v1_5 = v0_10 | v0_11;
  logic [1:0] p1_5; assign p1_5 = v0_10 ? {1'b0, p0_10} : {1'b1, p0_11};
  logic v1_6; assign v1_6 = v0_12 | v0_13;
  logic [1:0] p1_6; assign p1_6 = v0_12 ? {1'b0, p0_12} : {1'b1, p0_13};
  logic v1_7; assign v1_7 = v0_14 | v0_15;
  logic [1:0] p1_7; assign p1_7 = v0_14 ? {1'b0, p0_14} : {1'b1, p0_15};
  logic v1_8; assign v1_8 = v0_16 | v0_17;
  logic [1:0] p1_8; assign p1_8 = v0_16 ? {1'b0, p0_16} : {1'b1, p0_17};
  logic v1_9; assign v1_9 = v0_18 | v0_19;
  logic [1:0] p1_9; assign p1_9 = v0_18 ? {1'b0, p0_18} : {1'b1, p0_19};
  logic v1_10; assign v1_10 = v0_20 | v0_21;
  logic [1:0] p1_10; assign p1_10 = v0_20 ? {1'b0, p0_20} : {1'b1, p0_21};
  logic v1_11; assign v1_11 = v0_22 | v0_23;
  logic [1:0] p1_11; assign p1_11 = v0_22 ? {1'b0, p0_22} : {1'b1, p0_23};
  logic v1_12; assign v1_12 = v0_24 | v0_25;
  logic [1:0] p1_12; assign p1_12 = v0_24 ? {1'b0, p0_24} : {1'b1, p0_25};
  logic v1_13; assign v1_13 = v0_26 | v0_27;
  logic [1:0] p1_13; assign p1_13 = v0_26 ? {1'b0, p0_26} : {1'b1, p0_27};
  logic v1_14; assign v1_14 = v0_28 | v0_29;
  logic [1:0] p1_14; assign p1_14 = v0_28 ? {1'b0, p0_28} : {1'b1, p0_29};
  logic v1_15; assign v1_15 = v0_30 | v0_31;
  logic [1:0] p1_15; assign p1_15 = v0_30 ? {1'b0, p0_30} : {1'b1, p0_31};
  logic v2_0; assign v2_0 = v1_0 | v1_1;
  logic [2:0] p2_0; assign p2_0 = v1_0 ? {1'b0, p1_0} : {1'b1, p1_1};
  logic v2_1; assign v2_1 = v1_2 | v1_3;
  logic [2:0] p2_1; assign p2_1 = v1_2 ? {1'b0, p1_2} : {1'b1, p1_3};
  logic v2_2; assign v2_2 = v1_4 | v1_5;
  logic [2:0] p2_2; assign p2_2 = v1_4 ? {1'b0, p1_4} : {1'b1, p1_5};
  logic v2_3; assign v2_3 = v1_6 | v1_7;
  logic [2:0] p2_3; assign p2_3 = v1_6 ? {1'b0, p1_6} : {1'b1, p1_7};
  logic v2_4; assign v2_4 = v1_8 | v1_9;
  logic [2:0] p2_4; assign p2_4 = v1_8 ? {1'b0, p1_8} : {1'b1, p1_9};
  logic v2_5; assign v2_5 = v1_10 | v1_11;
  logic [2:0] p2_5; assign p2_5 = v1_10 ? {1'b0, p1_10} : {1'b1, p1_11};
  logic v2_6; assign v2_6 = v1_12 | v1_13;
  logic [2:0] p2_6; assign p2_6 = v1_12 ? {1'b0, p1_12} : {1'b1, p1_13};
  logic v2_7; assign v2_7 = v1_14 | v1_15;
  logic [2:0] p2_7; assign p2_7 = v1_14 ? {1'b0, p1_14} : {1'b1, p1_15};
  logic v3_0; assign v3_0 = v2_0 | v2_1;
  logic [3:0] p3_0; assign p3_0 = v2_0 ? {1'b0, p2_0} : {1'b1, p2_1};
  logic v3_1; assign v3_1 = v2_2 | v2_3;
  logic [3:0] p3_1; assign p3_1 = v2_2 ? {1'b0, p2_2} : {1'b1, p2_3};
  logic v3_2; assign v3_2 = v2_4 | v2_5;
  logic [3:0] p3_2; assign p3_2 = v2_4 ? {1'b0, p2_4} : {1'b1, p2_5};
  logic v3_3; assign v3_3 = v2_6 | v2_7;
  logic [3:0] p3_3; assign p3_3 = v2_6 ? {1'b0, p2_6} : {1'b1, p2_7};
  logic v4_0; assign v4_0 = v3_0 | v3_1;
  logic [4:0] p4_0; assign p4_0 = v3_0 ? {1'b0, p3_0} : {1'b1, p3_1};
  logic v4_1; assign v4_1 = v3_2 | v3_3;
  logic [4:0] p4_1; assign p4_1 = v3_2 ? {1'b0, p3_2} : {1'b1, p3_3};
  logic v5_0; assign v5_0 = v4_0 | v4_1;
  logic [5:0] p5_0; assign p5_0 = v4_0 ? {1'b0, p4_0} : {1'b1, p4_1};
  assign n = v5_0 ? {1'd0, p5_0} : 7'd64;
endmodule


// lzd_cell_tree (pair_cell, binary_count, valid flags propagated): the leading zeros of a 8-bit word
module fam_count_lzd_pair_cell_binary_count_vprop_w8 (input logic [7:0] a, output logic [3:0] n);
  logic v0_0; assign v0_0 = a[7] | a[6];
  logic p0_0; assign p0_0 = ~a[7];
  logic v0_1; assign v0_1 = a[5] | a[4];
  logic p0_1; assign p0_1 = ~a[5];
  logic v0_2; assign v0_2 = a[3] | a[2];
  logic p0_2; assign p0_2 = ~a[3];
  logic v0_3; assign v0_3 = a[1] | a[0];
  logic p0_3; assign p0_3 = ~a[1];
  logic v1_0; assign v1_0 = v0_0 | v0_1;
  logic [1:0] p1_0; assign p1_0 = v0_0 ? {1'b0, p0_0} : {1'b1, p0_1};
  logic v1_1; assign v1_1 = v0_2 | v0_3;
  logic [1:0] p1_1; assign p1_1 = v0_2 ? {1'b0, p0_2} : {1'b1, p0_3};
  logic v2_0; assign v2_0 = v1_0 | v1_1;
  logic [2:0] p2_0; assign p2_0 = v1_0 ? {1'b0, p1_0} : {1'b1, p1_1};
  assign n = v2_0 ? {1'd0, p2_0} : 4'd8;
endmodule


// popcount_counter_tree (linear_chain, lut_rom, adders sparse_prefix_hybrid): the count of the ones of a 26-bit word
module fam_count_popcount_linear_chain_lut_rom_sparse_prefix_hybrid_p3651d_w26 (input logic [25:0] a, output logic [4:0] n);
  logic [2:0] g0_rom1;
  always_comb begin case ({a[5], a[4], a[3], a[2], a[1], a[0]})
    6'd0: g0_rom1 = 3'd0;
    6'd1: g0_rom1 = 3'd1;
    6'd2: g0_rom1 = 3'd1;
    6'd3: g0_rom1 = 3'd2;
    6'd4: g0_rom1 = 3'd1;
    6'd5: g0_rom1 = 3'd2;
    6'd6: g0_rom1 = 3'd2;
    6'd7: g0_rom1 = 3'd3;
    6'd8: g0_rom1 = 3'd1;
    6'd9: g0_rom1 = 3'd2;
    6'd10: g0_rom1 = 3'd2;
    6'd11: g0_rom1 = 3'd3;
    6'd12: g0_rom1 = 3'd2;
    6'd13: g0_rom1 = 3'd3;
    6'd14: g0_rom1 = 3'd3;
    6'd15: g0_rom1 = 3'd4;
    6'd16: g0_rom1 = 3'd1;
    6'd17: g0_rom1 = 3'd2;
    6'd18: g0_rom1 = 3'd2;
    6'd19: g0_rom1 = 3'd3;
    6'd20: g0_rom1 = 3'd2;
    6'd21: g0_rom1 = 3'd3;
    6'd22: g0_rom1 = 3'd3;
    6'd23: g0_rom1 = 3'd4;
    6'd24: g0_rom1 = 3'd2;
    6'd25: g0_rom1 = 3'd3;
    6'd26: g0_rom1 = 3'd3;
    6'd27: g0_rom1 = 3'd4;
    6'd28: g0_rom1 = 3'd3;
    6'd29: g0_rom1 = 3'd4;
    6'd30: g0_rom1 = 3'd4;
    6'd31: g0_rom1 = 3'd5;
    6'd32: g0_rom1 = 3'd1;
    6'd33: g0_rom1 = 3'd2;
    6'd34: g0_rom1 = 3'd2;
    6'd35: g0_rom1 = 3'd3;
    6'd36: g0_rom1 = 3'd2;
    6'd37: g0_rom1 = 3'd3;
    6'd38: g0_rom1 = 3'd3;
    6'd39: g0_rom1 = 3'd4;
    6'd40: g0_rom1 = 3'd2;
    6'd41: g0_rom1 = 3'd3;
    6'd42: g0_rom1 = 3'd3;
    6'd43: g0_rom1 = 3'd4;
    6'd44: g0_rom1 = 3'd3;
    6'd45: g0_rom1 = 3'd4;
    6'd46: g0_rom1 = 3'd4;
    6'd47: g0_rom1 = 3'd5;
    6'd48: g0_rom1 = 3'd2;
    6'd49: g0_rom1 = 3'd3;
    6'd50: g0_rom1 = 3'd3;
    6'd51: g0_rom1 = 3'd4;
    6'd52: g0_rom1 = 3'd3;
    6'd53: g0_rom1 = 3'd4;
    6'd54: g0_rom1 = 3'd4;
    6'd55: g0_rom1 = 3'd5;
    6'd56: g0_rom1 = 3'd3;
    6'd57: g0_rom1 = 3'd4;
    6'd58: g0_rom1 = 3'd4;
    6'd59: g0_rom1 = 3'd5;
    6'd60: g0_rom1 = 3'd4;
    6'd61: g0_rom1 = 3'd5;
    6'd62: g0_rom1 = 3'd5;
    6'd63: g0_rom1 = 3'd6;
    default: g0_rom1 = 3'd0;
  endcase end
  logic [2:0] gc0; assign gc0 = {g0_rom1[2], g0_rom1[1], g0_rom1[0]};
  logic [2:0] g1_rom2;
  always_comb begin case ({a[11], a[10], a[9], a[8], a[7], a[6]})
    6'd0: g1_rom2 = 3'd0;
    6'd1: g1_rom2 = 3'd1;
    6'd2: g1_rom2 = 3'd1;
    6'd3: g1_rom2 = 3'd2;
    6'd4: g1_rom2 = 3'd1;
    6'd5: g1_rom2 = 3'd2;
    6'd6: g1_rom2 = 3'd2;
    6'd7: g1_rom2 = 3'd3;
    6'd8: g1_rom2 = 3'd1;
    6'd9: g1_rom2 = 3'd2;
    6'd10: g1_rom2 = 3'd2;
    6'd11: g1_rom2 = 3'd3;
    6'd12: g1_rom2 = 3'd2;
    6'd13: g1_rom2 = 3'd3;
    6'd14: g1_rom2 = 3'd3;
    6'd15: g1_rom2 = 3'd4;
    6'd16: g1_rom2 = 3'd1;
    6'd17: g1_rom2 = 3'd2;
    6'd18: g1_rom2 = 3'd2;
    6'd19: g1_rom2 = 3'd3;
    6'd20: g1_rom2 = 3'd2;
    6'd21: g1_rom2 = 3'd3;
    6'd22: g1_rom2 = 3'd3;
    6'd23: g1_rom2 = 3'd4;
    6'd24: g1_rom2 = 3'd2;
    6'd25: g1_rom2 = 3'd3;
    6'd26: g1_rom2 = 3'd3;
    6'd27: g1_rom2 = 3'd4;
    6'd28: g1_rom2 = 3'd3;
    6'd29: g1_rom2 = 3'd4;
    6'd30: g1_rom2 = 3'd4;
    6'd31: g1_rom2 = 3'd5;
    6'd32: g1_rom2 = 3'd1;
    6'd33: g1_rom2 = 3'd2;
    6'd34: g1_rom2 = 3'd2;
    6'd35: g1_rom2 = 3'd3;
    6'd36: g1_rom2 = 3'd2;
    6'd37: g1_rom2 = 3'd3;
    6'd38: g1_rom2 = 3'd3;
    6'd39: g1_rom2 = 3'd4;
    6'd40: g1_rom2 = 3'd2;
    6'd41: g1_rom2 = 3'd3;
    6'd42: g1_rom2 = 3'd3;
    6'd43: g1_rom2 = 3'd4;
    6'd44: g1_rom2 = 3'd3;
    6'd45: g1_rom2 = 3'd4;
    6'd46: g1_rom2 = 3'd4;
    6'd47: g1_rom2 = 3'd5;
    6'd48: g1_rom2 = 3'd2;
    6'd49: g1_rom2 = 3'd3;
    6'd50: g1_rom2 = 3'd3;
    6'd51: g1_rom2 = 3'd4;
    6'd52: g1_rom2 = 3'd3;
    6'd53: g1_rom2 = 3'd4;
    6'd54: g1_rom2 = 3'd4;
    6'd55: g1_rom2 = 3'd5;
    6'd56: g1_rom2 = 3'd3;
    6'd57: g1_rom2 = 3'd4;
    6'd58: g1_rom2 = 3'd4;
    6'd59: g1_rom2 = 3'd5;
    6'd60: g1_rom2 = 3'd4;
    6'd61: g1_rom2 = 3'd5;
    6'd62: g1_rom2 = 3'd5;
    6'd63: g1_rom2 = 3'd6;
    default: g1_rom2 = 3'd0;
  endcase end
  logic [2:0] gc1; assign gc1 = {g1_rom2[2], g1_rom2[1], g1_rom2[0]};
  logic [2:0] g2_rom3;
  always_comb begin case ({a[17], a[16], a[15], a[14], a[13], a[12]})
    6'd0: g2_rom3 = 3'd0;
    6'd1: g2_rom3 = 3'd1;
    6'd2: g2_rom3 = 3'd1;
    6'd3: g2_rom3 = 3'd2;
    6'd4: g2_rom3 = 3'd1;
    6'd5: g2_rom3 = 3'd2;
    6'd6: g2_rom3 = 3'd2;
    6'd7: g2_rom3 = 3'd3;
    6'd8: g2_rom3 = 3'd1;
    6'd9: g2_rom3 = 3'd2;
    6'd10: g2_rom3 = 3'd2;
    6'd11: g2_rom3 = 3'd3;
    6'd12: g2_rom3 = 3'd2;
    6'd13: g2_rom3 = 3'd3;
    6'd14: g2_rom3 = 3'd3;
    6'd15: g2_rom3 = 3'd4;
    6'd16: g2_rom3 = 3'd1;
    6'd17: g2_rom3 = 3'd2;
    6'd18: g2_rom3 = 3'd2;
    6'd19: g2_rom3 = 3'd3;
    6'd20: g2_rom3 = 3'd2;
    6'd21: g2_rom3 = 3'd3;
    6'd22: g2_rom3 = 3'd3;
    6'd23: g2_rom3 = 3'd4;
    6'd24: g2_rom3 = 3'd2;
    6'd25: g2_rom3 = 3'd3;
    6'd26: g2_rom3 = 3'd3;
    6'd27: g2_rom3 = 3'd4;
    6'd28: g2_rom3 = 3'd3;
    6'd29: g2_rom3 = 3'd4;
    6'd30: g2_rom3 = 3'd4;
    6'd31: g2_rom3 = 3'd5;
    6'd32: g2_rom3 = 3'd1;
    6'd33: g2_rom3 = 3'd2;
    6'd34: g2_rom3 = 3'd2;
    6'd35: g2_rom3 = 3'd3;
    6'd36: g2_rom3 = 3'd2;
    6'd37: g2_rom3 = 3'd3;
    6'd38: g2_rom3 = 3'd3;
    6'd39: g2_rom3 = 3'd4;
    6'd40: g2_rom3 = 3'd2;
    6'd41: g2_rom3 = 3'd3;
    6'd42: g2_rom3 = 3'd3;
    6'd43: g2_rom3 = 3'd4;
    6'd44: g2_rom3 = 3'd3;
    6'd45: g2_rom3 = 3'd4;
    6'd46: g2_rom3 = 3'd4;
    6'd47: g2_rom3 = 3'd5;
    6'd48: g2_rom3 = 3'd2;
    6'd49: g2_rom3 = 3'd3;
    6'd50: g2_rom3 = 3'd3;
    6'd51: g2_rom3 = 3'd4;
    6'd52: g2_rom3 = 3'd3;
    6'd53: g2_rom3 = 3'd4;
    6'd54: g2_rom3 = 3'd4;
    6'd55: g2_rom3 = 3'd5;
    6'd56: g2_rom3 = 3'd3;
    6'd57: g2_rom3 = 3'd4;
    6'd58: g2_rom3 = 3'd4;
    6'd59: g2_rom3 = 3'd5;
    6'd60: g2_rom3 = 3'd4;
    6'd61: g2_rom3 = 3'd5;
    6'd62: g2_rom3 = 3'd5;
    6'd63: g2_rom3 = 3'd6;
    default: g2_rom3 = 3'd0;
  endcase end
  logic [2:0] gc2; assign gc2 = {g2_rom3[2], g2_rom3[1], g2_rom3[0]};
  logic [2:0] g3_rom4;
  always_comb begin case ({a[23], a[22], a[21], a[20], a[19], a[18]})
    6'd0: g3_rom4 = 3'd0;
    6'd1: g3_rom4 = 3'd1;
    6'd2: g3_rom4 = 3'd1;
    6'd3: g3_rom4 = 3'd2;
    6'd4: g3_rom4 = 3'd1;
    6'd5: g3_rom4 = 3'd2;
    6'd6: g3_rom4 = 3'd2;
    6'd7: g3_rom4 = 3'd3;
    6'd8: g3_rom4 = 3'd1;
    6'd9: g3_rom4 = 3'd2;
    6'd10: g3_rom4 = 3'd2;
    6'd11: g3_rom4 = 3'd3;
    6'd12: g3_rom4 = 3'd2;
    6'd13: g3_rom4 = 3'd3;
    6'd14: g3_rom4 = 3'd3;
    6'd15: g3_rom4 = 3'd4;
    6'd16: g3_rom4 = 3'd1;
    6'd17: g3_rom4 = 3'd2;
    6'd18: g3_rom4 = 3'd2;
    6'd19: g3_rom4 = 3'd3;
    6'd20: g3_rom4 = 3'd2;
    6'd21: g3_rom4 = 3'd3;
    6'd22: g3_rom4 = 3'd3;
    6'd23: g3_rom4 = 3'd4;
    6'd24: g3_rom4 = 3'd2;
    6'd25: g3_rom4 = 3'd3;
    6'd26: g3_rom4 = 3'd3;
    6'd27: g3_rom4 = 3'd4;
    6'd28: g3_rom4 = 3'd3;
    6'd29: g3_rom4 = 3'd4;
    6'd30: g3_rom4 = 3'd4;
    6'd31: g3_rom4 = 3'd5;
    6'd32: g3_rom4 = 3'd1;
    6'd33: g3_rom4 = 3'd2;
    6'd34: g3_rom4 = 3'd2;
    6'd35: g3_rom4 = 3'd3;
    6'd36: g3_rom4 = 3'd2;
    6'd37: g3_rom4 = 3'd3;
    6'd38: g3_rom4 = 3'd3;
    6'd39: g3_rom4 = 3'd4;
    6'd40: g3_rom4 = 3'd2;
    6'd41: g3_rom4 = 3'd3;
    6'd42: g3_rom4 = 3'd3;
    6'd43: g3_rom4 = 3'd4;
    6'd44: g3_rom4 = 3'd3;
    6'd45: g3_rom4 = 3'd4;
    6'd46: g3_rom4 = 3'd4;
    6'd47: g3_rom4 = 3'd5;
    6'd48: g3_rom4 = 3'd2;
    6'd49: g3_rom4 = 3'd3;
    6'd50: g3_rom4 = 3'd3;
    6'd51: g3_rom4 = 3'd4;
    6'd52: g3_rom4 = 3'd3;
    6'd53: g3_rom4 = 3'd4;
    6'd54: g3_rom4 = 3'd4;
    6'd55: g3_rom4 = 3'd5;
    6'd56: g3_rom4 = 3'd3;
    6'd57: g3_rom4 = 3'd4;
    6'd58: g3_rom4 = 3'd4;
    6'd59: g3_rom4 = 3'd5;
    6'd60: g3_rom4 = 3'd4;
    6'd61: g3_rom4 = 3'd5;
    6'd62: g3_rom4 = 3'd5;
    6'd63: g3_rom4 = 3'd6;
    default: g3_rom4 = 3'd0;
  endcase end
  logic [2:0] gc3; assign gc3 = {g3_rom4[2], g3_rom4[1], g3_rom4[0]};
  logic g4_s5; assign g4_s5 = a[24] ^ a[25];
  logic g4_c6; assign g4_c6 = a[24] & a[25];
  logic [1:0] gc4; assign gc4 = {g4_c6, g4_s5};
  logic [2:0] s1;
  logic co1;
  // count adder 1 (sparse_prefix_hybrid, 3 bits)
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w3 u1 (.a(gc0), .b(gc1), .cin(1'b0), .s(s1), .cout(co1));
  logic [3:0] t1; assign t1 = {co1, s1};
  logic [3:0] s2;
  logic co2;
  // count adder 2 (sparse_prefix_hybrid, 4 bits)
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w4 u2 (.a(t1), .b({1'd0, gc2}), .cin(1'b0), .s(s2), .cout(co2));
  logic [4:0] t2; assign t2 = {co2, s2};
  logic [4:0] s3;
  logic co3;
  // count adder 3 (sparse_prefix_hybrid, 5 bits)
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w5 u3 (.a(t2), .b({2'd0, gc3}), .cin(1'b0), .s(s3), .cout(co3));
  logic [5:0] t3; assign t3 = {co3, s3};
  logic [5:0] s4;
  logic co4;
  // count adder 4 (sparse_prefix_hybrid, 6 bits)
  fam_adder_sparse_prefix_hybrid_p601f72b7580996e8fa9d634e70ddcd4034bdbbc2fec4b19e8f79d52f786e1906_w6 u4 (.a(t3), .b({4'd0, gc4}), .cin(1'b0), .s(s4), .cout(co4));
  logic [6:0] t4; assign t4 = {co4, s4};
  assign n = t4[4:0];
endmodule




// prefix_lzc (brent_kung prefix OR, lookahead_flags): the leading zeros of a 26-bit word
module fam_count_prefix_lzc_brent_kung_flags_w26 (input logic [25:0] a, output logic [4:0] n);
  logic x0; assign x0 = a[25];
  logic x1; assign x1 = a[24];
  logic x2; assign x2 = a[23];
  logic x3; assign x3 = a[22];
  logic x4; assign x4 = a[21];
  logic x5; assign x5 = a[20];
  logic x6; assign x6 = a[19];
  logic x7; assign x7 = a[18];
  logic x8; assign x8 = a[17];
  logic x9; assign x9 = a[16];
  logic x10; assign x10 = a[15];
  logic x11; assign x11 = a[14];
  logic x12; assign x12 = a[13];
  logic x13; assign x13 = a[12];
  logic x14; assign x14 = a[11];
  logic x15; assign x15 = a[10];
  logic x16; assign x16 = a[9];
  logic x17; assign x17 = a[8];
  logic x18; assign x18 = a[7];
  logic x19; assign x19 = a[6];
  logic x20; assign x20 = a[5];
  logic x21; assign x21 = a[4];
  logic x22; assign x22 = a[3];
  logic x23; assign x23 = a[2];
  logic x24; assign x24 = a[1];
  logic x25; assign x25 = a[0];
  logic p_bu0_1; assign p_bu0_1 = x1 | x0;
  logic p_bu0_3; assign p_bu0_3 = x3 | x2;
  logic p_bu0_5; assign p_bu0_5 = x5 | x4;
  logic p_bu0_7; assign p_bu0_7 = x7 | x6;
  logic p_bu0_9; assign p_bu0_9 = x9 | x8;
  logic p_bu0_11; assign p_bu0_11 = x11 | x10;
  logic p_bu0_13; assign p_bu0_13 = x13 | x12;
  logic p_bu0_15; assign p_bu0_15 = x15 | x14;
  logic p_bu0_17; assign p_bu0_17 = x17 | x16;
  logic p_bu0_19; assign p_bu0_19 = x19 | x18;
  logic p_bu0_21; assign p_bu0_21 = x21 | x20;
  logic p_bu0_23; assign p_bu0_23 = x23 | x22;
  logic p_bu0_25; assign p_bu0_25 = x25 | x24;
  logic p_bu1_3; assign p_bu1_3 = p_bu0_3 | p_bu0_1;
  logic p_bu1_7; assign p_bu1_7 = p_bu0_7 | p_bu0_5;
  logic p_bu1_11; assign p_bu1_11 = p_bu0_11 | p_bu0_9;
  logic p_bu1_15; assign p_bu1_15 = p_bu0_15 | p_bu0_13;
  logic p_bu1_19; assign p_bu1_19 = p_bu0_19 | p_bu0_17;
  logic p_bu1_23; assign p_bu1_23 = p_bu0_23 | p_bu0_21;
  logic p_bu2_7; assign p_bu2_7 = p_bu1_7 | p_bu1_3;
  logic p_bu2_15; assign p_bu2_15 = p_bu1_15 | p_bu1_11;
  logic p_bu2_23; assign p_bu2_23 = p_bu1_23 | p_bu1_19;
  logic p_bu3_15; assign p_bu3_15 = p_bu2_15 | p_bu2_7;
  logic p_bd6_23; assign p_bd6_23 = p_bu2_23 | p_bu3_15;
  logic p_bd7_11; assign p_bd7_11 = p_bu1_11 | p_bu2_7;
  logic p_bd7_19; assign p_bd7_19 = p_bu1_19 | p_bu3_15;
  logic p_bd8_5; assign p_bd8_5 = p_bu0_5 | p_bu1_3;
  logic p_bd8_9; assign p_bd8_9 = p_bu0_9 | p_bu2_7;
  logic p_bd8_13; assign p_bd8_13 = p_bu0_13 | p_bd7_11;
  logic p_bd8_17; assign p_bd8_17 = p_bu0_17 | p_bu3_15;
  logic p_bd8_21; assign p_bd8_21 = p_bu0_21 | p_bd7_19;
  logic p_bd8_25; assign p_bd8_25 = p_bu0_25 | p_bd6_23;
  logic p_bd9_2; assign p_bd9_2 = x2 | p_bu0_1;
  logic p_bd9_4; assign p_bd9_4 = x4 | p_bu1_3;
  logic p_bd9_6; assign p_bd9_6 = x6 | p_bd8_5;
  logic p_bd9_8; assign p_bd9_8 = x8 | p_bu2_7;
  logic p_bd9_10; assign p_bd9_10 = x10 | p_bd8_9;
  logic p_bd9_12; assign p_bd9_12 = x12 | p_bd7_11;
  logic p_bd9_14; assign p_bd9_14 = x14 | p_bd8_13;
  logic p_bd9_16; assign p_bd9_16 = x16 | p_bu3_15;
  logic p_bd9_18; assign p_bd9_18 = x18 | p_bd8_17;
  logic p_bd9_20; assign p_bd9_20 = x20 | p_bd7_19;
  logic p_bd9_22; assign p_bd9_22 = x22 | p_bd8_21;
  logic p_bd9_24; assign p_bd9_24 = x24 | p_bd6_23;
  logic f0; assign f0 = x0;
  logic f1; assign f1 = p_bu0_1 & ~x0;
  logic f2; assign f2 = p_bd9_2 & ~p_bu0_1;
  logic f3; assign f3 = p_bu1_3 & ~p_bd9_2;
  logic f4; assign f4 = p_bd9_4 & ~p_bu1_3;
  logic f5; assign f5 = p_bd8_5 & ~p_bd9_4;
  logic f6; assign f6 = p_bd9_6 & ~p_bd8_5;
  logic f7; assign f7 = p_bu2_7 & ~p_bd9_6;
  logic f8; assign f8 = p_bd9_8 & ~p_bu2_7;
  logic f9; assign f9 = p_bd8_9 & ~p_bd9_8;
  logic f10; assign f10 = p_bd9_10 & ~p_bd8_9;
  logic f11; assign f11 = p_bd7_11 & ~p_bd9_10;
  logic f12; assign f12 = p_bd9_12 & ~p_bd7_11;
  logic f13; assign f13 = p_bd8_13 & ~p_bd9_12;
  logic f14; assign f14 = p_bd9_14 & ~p_bd8_13;
  logic f15; assign f15 = p_bu3_15 & ~p_bd9_14;
  logic f16; assign f16 = p_bd9_16 & ~p_bu3_15;
  logic f17; assign f17 = p_bd8_17 & ~p_bd9_16;
  logic f18; assign f18 = p_bd9_18 & ~p_bd8_17;
  logic f19; assign f19 = p_bd7_19 & ~p_bd9_18;
  logic f20; assign f20 = p_bd9_20 & ~p_bd7_19;
  logic f21; assign f21 = p_bd8_21 & ~p_bd9_20;
  logic f22; assign f22 = p_bd9_22 & ~p_bd8_21;
  logic f23; assign f23 = p_bd6_23 & ~p_bd9_22;
  logic f24; assign f24 = p_bd9_24 & ~p_bd6_23;
  logic f25; assign f25 = p_bd8_25 & ~p_bd9_24;
  logic [4:0] enc;
  // the leading-one flags encoded by one OR tree per count bit
  assign enc[0] = f1 | f3 | f5 | f7 | f9 | f11 | f13 | f15 | f17 | f19 | f21 | f23 | f25;
  assign enc[1] = f2 | f3 | f6 | f7 | f10 | f11 | f14 | f15 | f18 | f19 | f22 | f23;
  assign enc[2] = f4 | f5 | f6 | f7 | f12 | f13 | f14 | f15 | f20 | f21 | f22 | f23;
  assign enc[3] = f8 | f9 | f10 | f11 | f12 | f13 | f14 | f15 | f24 | f25;
  assign enc[4] = f16 | f17 | f18 | f19 | f20 | f21 | f22 | f23 | f24 | f25;
  assign n = p_bd8_25 ? enc : 5'd26;
endmodule


// prefix_lzc (brent_kung prefix OR, lookahead_flags): the leading zeros of a 3-bit word
module fam_count_prefix_lzc_brent_kung_flags_w3 (input logic [2:0] a, output logic [1:0] n);
  logic x0; assign x0 = a[2];
  logic x1; assign x1 = a[1];
  logic x2; assign x2 = a[0];
  logic p_bu0_1; assign p_bu0_1 = x1 | x0;
  logic p_bd3_2; assign p_bd3_2 = x2 | p_bu0_1;
  logic f0; assign f0 = x0;
  logic f1; assign f1 = p_bu0_1 & ~x0;
  logic f2; assign f2 = p_bd3_2 & ~p_bu0_1;
  logic [1:0] enc;
  // the leading-one flags encoded by one OR tree per count bit
  assign enc[0] = f1;
  assign enc[1] = f2;
  assign n = p_bd3_2 ? enc : 2'd3;
endmodule
























// trailing_zero (isolate_then_encode, twos_complement_and): the lowest one isolated and encoded

// trailing_zero (isolate_then_encode, twos_complement_and): the lowest one isolated and encoded

// selected EAC followed by an ordinary binary sum/carry decoder

// end_around_carry (generic_p_correction, cyclic_prefix_level, ladner_fischer, the incrementer prefix_and_incrementer): the carry-out re-enters as the carry-in
























// prefix_lzc (sklansky prefix OR, popcount_of_complement): the leading zeros of a 26-bit word
module fam_count_prefix_lzc_sklansky_pcomp_pct_p63edf_w26 (input logic [25:0] a, output logic [4:0] n);
  logic x0; assign x0 = a[25];
  logic x1; assign x1 = a[24];
  logic x2; assign x2 = a[23];
  logic x3; assign x3 = a[22];
  logic x4; assign x4 = a[21];
  logic x5; assign x5 = a[20];
  logic x6; assign x6 = a[19];
  logic x7; assign x7 = a[18];
  logic x8; assign x8 = a[17];
  logic x9; assign x9 = a[16];
  logic x10; assign x10 = a[15];
  logic x11; assign x11 = a[14];
  logic x12; assign x12 = a[13];
  logic x13; assign x13 = a[12];
  logic x14; assign x14 = a[11];
  logic x15; assign x15 = a[10];
  logic x16; assign x16 = a[9];
  logic x17; assign x17 = a[8];
  logic x18; assign x18 = a[7];
  logic x19; assign x19 = a[6];
  logic x20; assign x20 = a[5];
  logic x21; assign x21 = a[4];
  logic x22; assign x22 = a[3];
  logic x23; assign x23 = a[2];
  logic x24; assign x24 = a[1];
  logic x25; assign x25 = a[0];
  logic p_sk0_1; assign p_sk0_1 = x1 | x0;
  logic p_sk0_3; assign p_sk0_3 = x3 | x2;
  logic p_sk0_5; assign p_sk0_5 = x5 | x4;
  logic p_sk0_7; assign p_sk0_7 = x7 | x6;
  logic p_sk0_9; assign p_sk0_9 = x9 | x8;
  logic p_sk0_11; assign p_sk0_11 = x11 | x10;
  logic p_sk0_13; assign p_sk0_13 = x13 | x12;
  logic p_sk0_15; assign p_sk0_15 = x15 | x14;
  logic p_sk0_17; assign p_sk0_17 = x17 | x16;
  logic p_sk0_19; assign p_sk0_19 = x19 | x18;
  logic p_sk0_21; assign p_sk0_21 = x21 | x20;
  logic p_sk0_23; assign p_sk0_23 = x23 | x22;
  logic p_sk0_25; assign p_sk0_25 = x25 | x24;
  logic p_sk1_2; assign p_sk1_2 = x2 | p_sk0_1;
  logic p_sk1_3; assign p_sk1_3 = p_sk0_3 | p_sk0_1;
  logic p_sk1_6; assign p_sk1_6 = x6 | p_sk0_5;
  logic p_sk1_7; assign p_sk1_7 = p_sk0_7 | p_sk0_5;
  logic p_sk1_10; assign p_sk1_10 = x10 | p_sk0_9;
  logic p_sk1_11; assign p_sk1_11 = p_sk0_11 | p_sk0_9;
  logic p_sk1_14; assign p_sk1_14 = x14 | p_sk0_13;
  logic p_sk1_15; assign p_sk1_15 = p_sk0_15 | p_sk0_13;
  logic p_sk1_18; assign p_sk1_18 = x18 | p_sk0_17;
  logic p_sk1_19; assign p_sk1_19 = p_sk0_19 | p_sk0_17;
  logic p_sk1_22; assign p_sk1_22 = x22 | p_sk0_21;
  logic p_sk1_23; assign p_sk1_23 = p_sk0_23 | p_sk0_21;
  logic p_sk2_4; assign p_sk2_4 = x4 | p_sk1_3;
  logic p_sk2_5; assign p_sk2_5 = p_sk0_5 | p_sk1_3;
  logic p_sk2_6; assign p_sk2_6 = p_sk1_6 | p_sk1_3;
  logic p_sk2_7; assign p_sk2_7 = p_sk1_7 | p_sk1_3;
  logic p_sk2_12; assign p_sk2_12 = x12 | p_sk1_11;
  logic p_sk2_13; assign p_sk2_13 = p_sk0_13 | p_sk1_11;
  logic p_sk2_14; assign p_sk2_14 = p_sk1_14 | p_sk1_11;
  logic p_sk2_15; assign p_sk2_15 = p_sk1_15 | p_sk1_11;
  logic p_sk2_20; assign p_sk2_20 = x20 | p_sk1_19;
  logic p_sk2_21; assign p_sk2_21 = p_sk0_21 | p_sk1_19;
  logic p_sk2_22; assign p_sk2_22 = p_sk1_22 | p_sk1_19;
  logic p_sk2_23; assign p_sk2_23 = p_sk1_23 | p_sk1_19;
  logic p_sk3_8; assign p_sk3_8 = x8 | p_sk2_7;
  logic p_sk3_9; assign p_sk3_9 = p_sk0_9 | p_sk2_7;
  logic p_sk3_10; assign p_sk3_10 = p_sk1_10 | p_sk2_7;
  logic p_sk3_11; assign p_sk3_11 = p_sk1_11 | p_sk2_7;
  logic p_sk3_12; assign p_sk3_12 = p_sk2_12 | p_sk2_7;
  logic p_sk3_13; assign p_sk3_13 = p_sk2_13 | p_sk2_7;
  logic p_sk3_14; assign p_sk3_14 = p_sk2_14 | p_sk2_7;
  logic p_sk3_15; assign p_sk3_15 = p_sk2_15 | p_sk2_7;
  logic p_sk3_24; assign p_sk3_24 = x24 | p_sk2_23;
  logic p_sk3_25; assign p_sk3_25 = p_sk0_25 | p_sk2_23;
  logic p_sk4_16; assign p_sk4_16 = x16 | p_sk3_15;
  logic p_sk4_17; assign p_sk4_17 = p_sk0_17 | p_sk3_15;
  logic p_sk4_18; assign p_sk4_18 = p_sk1_18 | p_sk3_15;
  logic p_sk4_19; assign p_sk4_19 = p_sk1_19 | p_sk3_15;
  logic p_sk4_20; assign p_sk4_20 = p_sk2_20 | p_sk3_15;
  logic p_sk4_21; assign p_sk4_21 = p_sk2_21 | p_sk3_15;
  logic p_sk4_22; assign p_sk4_22 = p_sk2_22 | p_sk3_15;
  logic p_sk4_23; assign p_sk4_23 = p_sk2_23 | p_sk3_15;
  logic p_sk4_24; assign p_sk4_24 = p_sk3_24 | p_sk3_15;
  logic p_sk4_25; assign p_sk4_25 = p_sk3_25 | p_sk3_15;
  logic [25:0] zeros; assign zeros = {~x0, ~p_sk0_1, ~p_sk1_2, ~p_sk1_3, ~p_sk2_4, ~p_sk2_5, ~p_sk2_6, ~p_sk2_7, ~p_sk3_8, ~p_sk3_9, ~p_sk3_10, ~p_sk3_11, ~p_sk3_12, ~p_sk3_13, ~p_sk3_14, ~p_sk3_15, ~p_sk4_16, ~p_sk4_17, ~p_sk4_18, ~p_sk4_19, ~p_sk4_20, ~p_sk4_21, ~p_sk4_22, ~p_sk4_23, ~p_sk4_24, ~p_sk4_25};
  // the count of the positions above the leading one (popcount_counter_tree)
  fam_count_popcount_linear_chain_lut_rom_sparse_prefix_hybrid_p3651d_w26 u1 (.a(zeros), .n(n));
endmodule


// priority_encoder (groups of 8, 3 lookahead levels, one_hot_then_encode): the leading zeros of a 10-bit word
module fam_count_priority_encoder_g8_l3_one_hot_then_encode_w10 (input logic [9:0] a, output logic [3:0] n);
  logic any0; assign any0 = a[9] | a[8] | a[7] | a[6] | a[5] | a[4] | a[3] | a[2];
  logic any1; assign any1 = a[1] | a[0];
  logic any2_0; assign any2_0 = any0 | any1;
  logic any3_0; assign any3_0 = any2_0;
  logic kg0; assign kg0 = 1'b0;
  logic kg1; assign kg1 = any0;
  logic fg0; assign fg0 = any0 & ~kg0;
  logic fg1; assign fg1 = any1 & ~kg1;
  logic kb0; assign kb0 = 1'b0;
  logic oh0; assign oh0 = a[9] & ~kb0 & fg0;
  logic kc0; assign kc0 = kb0 | a[9];
  logic kb1; assign kb1 = kc0;
  logic oh1; assign oh1 = a[8] & ~kb1 & fg0;
  logic kc1; assign kc1 = kb1 | a[8];
  logic kb2; assign kb2 = kc1;
  logic oh2; assign oh2 = a[7] & ~kb2 & fg0;
  logic kc2; assign kc2 = kb2 | a[7];
  logic kb3; assign kb3 = kc2;
  logic oh3; assign oh3 = a[6] & ~kb3 & fg0;
  logic kc3; assign kc3 = kb3 | a[6];
  logic kb4; assign kb4 = kc3;
  logic oh4; assign oh4 = a[5] & ~kb4 & fg0;
  logic kc4; assign kc4 = kb4 | a[5];
  logic kb5; assign kb5 = kc4;
  logic oh5; assign oh5 = a[4] & ~kb5 & fg0;
  logic kc5; assign kc5 = kb5 | a[4];
  logic kb6; assign kb6 = kc5;
  logic oh6; assign oh6 = a[3] & ~kb6 & fg0;
  logic kc6; assign kc6 = kb6 | a[3];
  logic kb7; assign kb7 = kc6;
  logic oh7; assign oh7 = a[2] & ~kb7 & fg0;
  logic kc7; assign kc7 = kb7 | a[2];
  logic kb8; assign kb8 = 1'b0;
  logic oh8; assign oh8 = a[1] & ~kb8 & fg1;
  logic kc8; assign kc8 = kb8 | a[1];
  logic kb9; assign kb9 = kc8;
  logic oh9; assign oh9 = a[0] & ~kb9 & fg1;
  logic kc9; assign kc9 = kb9 | a[0];
  logic v; assign v = any0 | any1;
  logic [3:0] enc;
  // the one-hot leading-one vector encoded to the count
  assign enc[0] = oh1 | oh3 | oh5 | oh7 | oh9;
  assign enc[1] = oh2 | oh3 | oh6 | oh7;
  assign enc[2] = oh4 | oh5 | oh6 | oh7;
  assign enc[3] = oh8 | oh9;
  assign n = v ? enc : 4'd10;
endmodule


// trailing_zero (isolate_then_encode, twos_complement_and): the lowest one isolated and encoded
module fam_count_tzc_isolate_then_encode_twos_complement_and_pe7180_w27 (input logic [26:0] a, output logic [4:0] n);
  logic [26:0] low;
  logic [26:0] na; assign na = ~a;
  logic [26:0] neg;
  // -a = ~a + 1 through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(27), .STRUCTURE(0), .B(4), .TOPO(0)) u1 (.a(na), .cin(1'b1), .s(neg), .cout());
  assign low = a & neg;
  logic [4:0] enc;
  // the isolated one encoded to its index
  assign enc[0] = low[1] | low[3] | low[5] | low[7] | low[9] | low[11] | low[13] | low[15] | low[17] | low[19] | low[21] | low[23] | low[25];
  assign enc[1] = low[2] | low[3] | low[6] | low[7] | low[10] | low[11] | low[14] | low[15] | low[18] | low[19] | low[22] | low[23] | low[26];
  assign enc[2] = low[4] | low[5] | low[6] | low[7] | low[12] | low[13] | low[14] | low[15] | low[20] | low[21] | low[22] | low[23];
  assign enc[3] = low[8] | low[9] | low[10] | low[11] | low[12] | low[13] | low[14] | low[15] | low[24] | low[25] | low[26];
  assign enc[4] = low[16] | low[17] | low[18] | low[19] | low[20] | low[21] | low[22] | low[23] | low[24] | low[25] | low[26];
  assign n = (low == 27'd0) ? 5'd27 : enc;
endmodule


// fp significand adder (single_path): 1 path; operands ordered by magnitude before one shifter; align full_align on a barrel_mux_tree shifter, sticky by or_tree_shifted_out; significand adder prefix_synthesis_nonuniform_arrival; leading zeros by lza (lzd_cell_tree, single_indicator); normalize single_barrel on a butterfly_network shifter; exponent path on ripple_carry adders; subnormals as normalized into the wide exponent; window of 29 guard bits below the larger operand's lsb (the significands are the unpacker's: 35 stored bits)
module fam_dot_lza_w34_p17e51f58317a (
  input logic [77:0] xa,
  input logic [77:0] xb,
  input logic sub,
  output logic [77:0] y,
  output logic predict_zero
);
  logic [1:0] a_sp; assign a_sp = xa[77:76];
  logic a_s; assign a_s = xa[75];
  logic signed [9:0] a_e; assign a_e = $signed(xa[74:65]);
  logic [63:0] a_sig; assign a_sig = xa[64:1];
  logic a_st; assign a_st = xa[0];
  logic a_z; assign a_z = (a_sp == 2'd0) && (a_sig == 0) && !a_st;
  logic [77:0] xbs; assign xbs = {xb[77:76], xb[75] ^ sub, xb[74:0]};
  logic [1:0] b_sp; assign b_sp = xbs[77:76];
  logic b_s; assign b_s = xbs[75];
  logic signed [9:0] b_e; assign b_e = $signed(xbs[74:65]);
  logic [63:0] b_sig; assign b_sig = xbs[64:1];
  logic b_st; assign b_st = xbs[0];
  logic b_z; assign b_z = (b_sp == 2'd0) && (b_sig == 0) && !b_st;
  logic [6:0] a_lz;
  // operand a: leading zeros (pseudo-normalized representation)
  fam_count_lzd_pair_cell_binary_count_vprop_w64 u1 (.a(a_sig), .n(a_lz));
  logic [5:0] a_lzs; assign a_lzs = (a_sig == 0) ? 6'd0 : a_lz[5:0];
  logic [63:0] a_nsig;
  // operand a normalized
  fam_shift_butterfly_network #(.W(64), .NETWORK(1), .STICKY(0)) u2 (.a(a_sig), .amt(a_lzs), .op(3'd0), .y(a_nsig), .sticky());
  logic signed [9:0] a_lzx; assign a_lzx = $signed({{(10-7){1'b0}}, a_lz});
  logic [9:0] a_ne_nb; assign a_ne_nb = ~(a_lzx);
  logic signed [9:0] a_ne;
  // operand a: the exponent lowered by the count
  fam_adder_ripple_carry #(.W(10), .CHUNK(1), .FORM(0)) u3 (.a(a_e), .b(a_ne_nb), .cin(1'b1), .s(a_ne), .cout());
  logic [6:0] b_lz;
  // operand b: leading zeros (pseudo-normalized representation)
  fam_count_lzd_pair_cell_binary_count_vprop_w64 u4 (.a(b_sig), .n(b_lz));
  logic [5:0] b_lzs; assign b_lzs = (b_sig == 0) ? 6'd0 : b_lz[5:0];
  logic [63:0] b_nsig;
  // operand b normalized
  fam_shift_butterfly_network #(.W(64), .NETWORK(1), .STICKY(0)) u5 (.a(b_sig), .amt(b_lzs), .op(3'd0), .y(b_nsig), .sticky());
  logic signed [9:0] b_lzx; assign b_lzx = $signed({{(10-7){1'b0}}, b_lz});
  logic [9:0] b_ne_nb; assign b_ne_nb = ~(b_lzx);
  logic signed [9:0] b_ne;
  // operand b: the exponent lowered by the count
  fam_adder_ripple_carry #(.W(10), .CHUNK(1), .FORM(0)) u6 (.a(b_e), .b(b_ne_nb), .cin(1'b1), .s(b_ne), .cout());
  logic signed [10:0] eax; assign eax = $signed({a_ne[9], a_ne});
  logic signed [10:0] ebx; assign ebx = $signed({b_ne[9], b_ne});
  logic [10:0] d_nb; assign d_nb = ~(ebx);
  logic signed [10:0] d;
  // the exponent difference
  fam_adder_ripple_carry #(.W(11), .CHUNK(1), .FORM(0)) u7 (.a(eax), .b(d_nb), .cin(1'b1), .s(d), .cout());
  logic signed [10:0] zero_x; assign zero_x = 11'sd0;
  logic [10:0] dn_nb; assign dn_nb = ~(d);
  logic signed [10:0] dn;
  // the difference negated
  fam_adder_ripple_carry #(.W(11), .CHUNK(1), .FORM(0)) u8 (.a(zero_x), .b(dn_nb), .cin(1'b1), .s(dn), .cout());
  logic a_big; assign a_big = (d > 0) || (d == 0 && a_nsig >= b_nsig);
  logic [10:0] dabs; assign dabs = a_big ? d : dn;
  logic signed [9:0] e_big; assign e_big = a_big ? a_ne : b_ne;
  logic s_big; assign s_big = a_big ? a_s : b_s;
  logic eff_sub; assign eff_sub = a_s ^ b_s;
  logic [63:0] big_sig; assign big_sig = a_big ? a_nsig : b_nsig;
  logic [63:0] sml_sig; assign sml_sig = a_big ? b_nsig : a_nsig;
  logic big_st; assign big_st = a_big ? a_st : b_st;
  logic sml_st; assign sml_st = a_big ? b_st : a_st;
  logic [64:0] mb; assign mb = {1'b0, big_sig};
  logic [64:0] ms0; assign ms0 = {1'b0, sml_sig};
  logic far_f; assign far_f = 1'b1 && (dabs > 64);
  logic [6:0] amt_f; assign amt_f = (!(1'b1) || far_f) ? 7'd0 : dabs[6:0];
  logic [64:0] mssh_f;
  logic stk0_f;
  // align: the operand shifted right by the exponent difference
  fam_shift_barrel_mux_tree #(.W(65), .RADIX_LOG2(1), .ONE_HOT(0), .DIR(1), .ORDER(0), .STICKY(1)) u9 (.a(ms0), .amt(amt_f), .op(3'd1), .y(mssh_f), .sticky(stk0_f));
  logic [64:0] m_f; assign m_f = far_f ? 65'd0 : mssh_f;
  logic stk_f; assign stk_f = far_f ? (sml_sig != 0) : stk0_f;
  logic stb_f; assign stb_f = sml_st | stk_f;
  logic [64:0] ms_f; assign ms_f = m_f;
  logic [64:0] bop_f; assign bop_f = eff_sub ? ~ms_f : ms_f;
  logic cin_f; assign cin_f = eff_sub ? ~stb_f : 1'b0;
  logic co_f;
  logic [64:0] r_f;
  // add: the significand adder (prefix_synthesis_nonuniform_arrival)
  fam_prefix_arrival_0_0_0_0_0_1_1_1_1_1_1_1_1_1_2_2_2_2_2_2_2_2_2_3_3_3_3_3_3_3_3_3_4_4_4_4_4_4_4_4_4_4_5_5_5_5_5_5_5_5_5_6_6_6_6_6_6_6_6_6_7_7_7_7_7_w65 u10 (.a(mb), .b(bop_f), .cin(cin_f), .s(r_f), .cout(co_f));
  logic st_f; assign st_f = big_st | stb_f;
  logic ovf_f; assign ovf_f = r_f[64];
  logic [63:0] sig0_f; assign sig0_f = ovf_f ? r_f[64:1] : r_f[63:0];
  logic st0_f; assign st0_f = st_f | (ovf_f & r_f[0]);
  logic signed [9:0] e0n_f_c; assign e0n_f_c = 10'sd0;
  logic signed [9:0] e0n_f;
  // normalize: the window's exponent origin
  fam_adder_ripple_carry #(.W(10), .CHUNK(1), .FORM(0)) u11 (.a(e_big), .b(e0n_f_c), .cin(1'b0), .s(e0n_f), .cout());
  logic signed [9:0] e0o_f_c; assign e0o_f_c = 10'sd1;
  logic signed [9:0] e0o_f;
  // normalize: the window's exponent origin after a carry out
  fam_adder_ripple_carry #(.W(10), .CHUNK(1), .FORM(0)) u12 (.a(e_big), .b(e0o_f_c), .cin(1'b0), .s(e0o_f), .cout());
  logic signed [9:0] e0_f; assign e0_f = ovf_f ? e0o_f : e0n_f;
  logic [64:0] t_f0; assign t_f0 = mb ^ bop_f;
  logic [64:0] g_f0; assign g_f0 = mb & bop_f;
  logic [64:0] z_f0; assign z_f0 = ~mb & ~bop_f;
  logic [64:0] f_f0;
  assign f_f0[0] = (t_f0[1] & g_f0[0] & ~1'b0) | (~t_f0[1] & z_f0[0] & ~1'b0);
  assign f_f0[1] = (t_f0[2] & g_f0[1] & ~z_f0[0]) | (~t_f0[2] & z_f0[1] & ~z_f0[0]);
  assign f_f0[2] = (t_f0[3] & g_f0[2] & ~z_f0[1]) | (~t_f0[3] & z_f0[2] & ~z_f0[1]);
  assign f_f0[3] = (t_f0[4] & g_f0[3] & ~z_f0[2]) | (~t_f0[4] & z_f0[3] & ~z_f0[2]);
  assign f_f0[4] = (t_f0[5] & g_f0[4] & ~z_f0[3]) | (~t_f0[5] & z_f0[4] & ~z_f0[3]);
  assign f_f0[5] = (t_f0[6] & g_f0[5] & ~z_f0[4]) | (~t_f0[6] & z_f0[5] & ~z_f0[4]);
  assign f_f0[6] = (t_f0[7] & g_f0[6] & ~z_f0[5]) | (~t_f0[7] & z_f0[6] & ~z_f0[5]);
  assign f_f0[7] = (t_f0[8] & g_f0[7] & ~z_f0[6]) | (~t_f0[8] & z_f0[7] & ~z_f0[6]);
  assign f_f0[8] = (t_f0[9] & g_f0[8] & ~z_f0[7]) | (~t_f0[9] & z_f0[8] & ~z_f0[7]);
  assign f_f0[9] = (t_f0[10] & g_f0[9] & ~z_f0[8]) | (~t_f0[10] & z_f0[9] & ~z_f0[8]);
  assign f_f0[10] = (t_f0[11] & g_f0[10] & ~z_f0[9]) | (~t_f0[11] & z_f0[10] & ~z_f0[9]);
  assign f_f0[11] = (t_f0[12] & g_f0[11] & ~z_f0[10]) | (~t_f0[12] & z_f0[11] & ~z_f0[10]);
  assign f_f0[12] = (t_f0[13] & g_f0[12] & ~z_f0[11]) | (~t_f0[13] & z_f0[12] & ~z_f0[11]);
  assign f_f0[13] = (t_f0[14] & g_f0[13] & ~z_f0[12]) | (~t_f0[14] & z_f0[13] & ~z_f0[12]);
  assign f_f0[14] = (t_f0[15] & g_f0[14] & ~z_f0[13]) | (~t_f0[15] & z_f0[14] & ~z_f0[13]);
  assign f_f0[15] = (t_f0[16] & g_f0[15] & ~z_f0[14]) | (~t_f0[16] & z_f0[15] & ~z_f0[14]);
  assign f_f0[16] = (t_f0[17] & g_f0[16] & ~z_f0[15]) | (~t_f0[17] & z_f0[16] & ~z_f0[15]);
  assign f_f0[17] = (t_f0[18] & g_f0[17] & ~z_f0[16]) | (~t_f0[18] & z_f0[17] & ~z_f0[16]);
  assign f_f0[18] = (t_f0[19] & g_f0[18] & ~z_f0[17]) | (~t_f0[19] & z_f0[18] & ~z_f0[17]);
  assign f_f0[19] = (t_f0[20] & g_f0[19] & ~z_f0[18]) | (~t_f0[20] & z_f0[19] & ~z_f0[18]);
  assign f_f0[20] = (t_f0[21] & g_f0[20] & ~z_f0[19]) | (~t_f0[21] & z_f0[20] & ~z_f0[19]);
  assign f_f0[21] = (t_f0[22] & g_f0[21] & ~z_f0[20]) | (~t_f0[22] & z_f0[21] & ~z_f0[20]);
  assign f_f0[22] = (t_f0[23] & g_f0[22] & ~z_f0[21]) | (~t_f0[23] & z_f0[22] & ~z_f0[21]);
  assign f_f0[23] = (t_f0[24] & g_f0[23] & ~z_f0[22]) | (~t_f0[24] & z_f0[23] & ~z_f0[22]);
  assign f_f0[24] = (t_f0[25] & g_f0[24] & ~z_f0[23]) | (~t_f0[25] & z_f0[24] & ~z_f0[23]);
  assign f_f0[25] = (t_f0[26] & g_f0[25] & ~z_f0[24]) | (~t_f0[26] & z_f0[25] & ~z_f0[24]);
  assign f_f0[26] = (t_f0[27] & g_f0[26] & ~z_f0[25]) | (~t_f0[27] & z_f0[26] & ~z_f0[25]);
  assign f_f0[27] = (t_f0[28] & g_f0[27] & ~z_f0[26]) | (~t_f0[28] & z_f0[27] & ~z_f0[26]);
  assign f_f0[28] = (t_f0[29] & g_f0[28] & ~z_f0[27]) | (~t_f0[29] & z_f0[28] & ~z_f0[27]);
  assign f_f0[29] = (t_f0[30] & g_f0[29] & ~z_f0[28]) | (~t_f0[30] & z_f0[29] & ~z_f0[28]);
  assign f_f0[30] = (t_f0[31] & g_f0[30] & ~z_f0[29]) | (~t_f0[31] & z_f0[30] & ~z_f0[29]);
  assign f_f0[31] = (t_f0[32] & g_f0[31] & ~z_f0[30]) | (~t_f0[32] & z_f0[31] & ~z_f0[30]);
  assign f_f0[32] = (t_f0[33] & g_f0[32] & ~z_f0[31]) | (~t_f0[33] & z_f0[32] & ~z_f0[31]);
  assign f_f0[33] = (t_f0[34] & g_f0[33] & ~z_f0[32]) | (~t_f0[34] & z_f0[33] & ~z_f0[32]);
  assign f_f0[34] = (t_f0[35] & g_f0[34] & ~z_f0[33]) | (~t_f0[35] & z_f0[34] & ~z_f0[33]);
  assign f_f0[35] = (t_f0[36] & g_f0[35] & ~z_f0[34]) | (~t_f0[36] & z_f0[35] & ~z_f0[34]);
  assign f_f0[36] = (t_f0[37] & g_f0[36] & ~z_f0[35]) | (~t_f0[37] & z_f0[36] & ~z_f0[35]);
  assign f_f0[37] = (t_f0[38] & g_f0[37] & ~z_f0[36]) | (~t_f0[38] & z_f0[37] & ~z_f0[36]);
  assign f_f0[38] = (t_f0[39] & g_f0[38] & ~z_f0[37]) | (~t_f0[39] & z_f0[38] & ~z_f0[37]);
  assign f_f0[39] = (t_f0[40] & g_f0[39] & ~z_f0[38]) | (~t_f0[40] & z_f0[39] & ~z_f0[38]);
  assign f_f0[40] = (t_f0[41] & g_f0[40] & ~z_f0[39]) | (~t_f0[41] & z_f0[40] & ~z_f0[39]);
  assign f_f0[41] = (t_f0[42] & g_f0[41] & ~z_f0[40]) | (~t_f0[42] & z_f0[41] & ~z_f0[40]);
  assign f_f0[42] = (t_f0[43] & g_f0[42] & ~z_f0[41]) | (~t_f0[43] & z_f0[42] & ~z_f0[41]);
  assign f_f0[43] = (t_f0[44] & g_f0[43] & ~z_f0[42]) | (~t_f0[44] & z_f0[43] & ~z_f0[42]);
  assign f_f0[44] = (t_f0[45] & g_f0[44] & ~z_f0[43]) | (~t_f0[45] & z_f0[44] & ~z_f0[43]);
  assign f_f0[45] = (t_f0[46] & g_f0[45] & ~z_f0[44]) | (~t_f0[46] & z_f0[45] & ~z_f0[44]);
  assign f_f0[46] = (t_f0[47] & g_f0[46] & ~z_f0[45]) | (~t_f0[47] & z_f0[46] & ~z_f0[45]);
  assign f_f0[47] = (t_f0[48] & g_f0[47] & ~z_f0[46]) | (~t_f0[48] & z_f0[47] & ~z_f0[46]);
  assign f_f0[48] = (t_f0[49] & g_f0[48] & ~z_f0[47]) | (~t_f0[49] & z_f0[48] & ~z_f0[47]);
  assign f_f0[49] = (t_f0[50] & g_f0[49] & ~z_f0[48]) | (~t_f0[50] & z_f0[49] & ~z_f0[48]);
  assign f_f0[50] = (t_f0[51] & g_f0[50] & ~z_f0[49]) | (~t_f0[51] & z_f0[50] & ~z_f0[49]);
  assign f_f0[51] = (t_f0[52] & g_f0[51] & ~z_f0[50]) | (~t_f0[52] & z_f0[51] & ~z_f0[50]);
  assign f_f0[52] = (t_f0[53] & g_f0[52] & ~z_f0[51]) | (~t_f0[53] & z_f0[52] & ~z_f0[51]);
  assign f_f0[53] = (t_f0[54] & g_f0[53] & ~z_f0[52]) | (~t_f0[54] & z_f0[53] & ~z_f0[52]);
  assign f_f0[54] = (t_f0[55] & g_f0[54] & ~z_f0[53]) | (~t_f0[55] & z_f0[54] & ~z_f0[53]);
  assign f_f0[55] = (t_f0[56] & g_f0[55] & ~z_f0[54]) | (~t_f0[56] & z_f0[55] & ~z_f0[54]);
  assign f_f0[56] = (t_f0[57] & g_f0[56] & ~z_f0[55]) | (~t_f0[57] & z_f0[56] & ~z_f0[55]);
  assign f_f0[57] = (t_f0[58] & g_f0[57] & ~z_f0[56]) | (~t_f0[58] & z_f0[57] & ~z_f0[56]);
  assign f_f0[58] = (t_f0[59] & g_f0[58] & ~z_f0[57]) | (~t_f0[59] & z_f0[58] & ~z_f0[57]);
  assign f_f0[59] = (t_f0[60] & g_f0[59] & ~z_f0[58]) | (~t_f0[60] & z_f0[59] & ~z_f0[58]);
  assign f_f0[60] = (t_f0[61] & g_f0[60] & ~z_f0[59]) | (~t_f0[61] & z_f0[60] & ~z_f0[59]);
  assign f_f0[61] = (t_f0[62] & g_f0[61] & ~z_f0[60]) | (~t_f0[62] & z_f0[61] & ~z_f0[60]);
  assign f_f0[62] = (t_f0[63] & g_f0[62] & ~z_f0[61]) | (~t_f0[63] & z_f0[62] & ~z_f0[61]);
  assign f_f0[63] = (t_f0[64] & g_f0[63] & ~z_f0[62]) | (~t_f0[64] & z_f0[63] & ~z_f0[62]);
  assign f_f0[64] = (1'b0 & g_f0[64] & ~z_f0[63]) | (~1'b0 & z_f0[64] & ~z_f0[63]);
  logic [63:0] fw_f0; assign fw_f0 = ovf_f ? f_f0[64:1] : f_f0[63:0];
  logic [63:0] fws_f; assign fws_f = fw_f0;
  logic [6:0] lzp_f;
  // normalize: leading zeros of the indicator string
  fam_count_lzd_pair_cell_binary_count_vprop_w64 u13 (.a(fws_f), .n(lzp_f));
  logic [5:0] lzs_f; assign lzs_f = (!eff_sub || fws_f == 0) ? 6'd0 : lzp_f[5:0];
  logic fz_f; assign fz_f = fws_f == 0;
  logic [63:0] sign_f;
  // normalize: the normalize shifter
  fam_shift_butterfly_network #(.W(64), .NETWORK(1), .STICKY(0)) u14 (.a(sig0_f), .amt(lzs_f), .op(3'd0), .y(sign_f), .sticky());
  logic signed [9:0] lzx_f; assign lzx_f = $signed({{(10-6){1'b0}}, lzs_f});
  logic [9:0] en_f_nb; assign en_f_nb = ~(lzx_f);
  logic signed [9:0] en_f;
  // normalize: the exponent lowered by the normalize count
  fam_adder_ripple_carry #(.W(10), .CHUNK(1), .FORM(0)) u15 (.a(e0_f), .b(en_f_nb), .cin(1'b1), .s(en_f), .cout());
  logic zero_f; assign zero_f = (sign_f == 0) && !st0_f;
  logic sr_f; assign sr_f = zero_f ? 1'b0 : s_big;
  logic [77:0] y_f; assign y_f = {2'd0, sr_f, en_f, sign_f, st0_f};
  logic both_inf; assign both_inf = (a_sp == 2'd2) && (b_sp == 2'd2);
  logic [77:0] y_sp; assign y_sp = (a_sp == 2'd1 || b_sp == 2'd1) ? {2'd1, 1'b0, 10'sd0, 64'd0, 1'b0} : both_inf ? ((a_s == b_s) ? {2'd2, a_s, 10'sd0, 64'd0, 1'b0} : {2'd1, 1'b0, 10'sd0, 64'd0, 1'b0}) : (a_sp == 2'd2) ? {2'd2, a_s, 10'sd0, 64'd0, 1'b0} : (b_sp == 2'd2) ? {2'd2, b_s, 10'sd0, 64'd0, 1'b0} : a_z ? xbs : b_z ? xa : y_f;
  assign y = y_sp;
  assign predict_zero = a_z ? b_z : b_z ? a_z : zero_f;
endmodule

// fp significand adder (two_path): 2 paths; operands each shifted by its own amount, the magnitude of the difference by end_around_carry; align full_align on a masked_merged shifter, sticky by trailing_zero_compare; significand adder end_around_carry; leading zeros by lza (prefix_lzc, dual_pos_neg_strings); normalize coarse_fine on a barrel_mux_tree shifter; exponent path on fpga_carry_chain adders; subnormals as stored; window of 15 guard bits below the larger operand's lsb (the significands are the unpacker's: 11 stored bits)
module fam_fp_add_two_path_x26e13s11_p384822081789 (
  input logic [42:0] xa,
  input logic [42:0] xb,
  input logic sub,
  output logic [42:0] y
);
  logic [1:0] a_sp; assign a_sp = xa[42:41];
  logic a_s; assign a_s = xa[40];
  logic signed [12:0] a_e; assign a_e = $signed(xa[39:27]);
  logic [25:0] a_sig; assign a_sig = xa[26:1];
  logic a_st; assign a_st = xa[0];
  logic a_z; assign a_z = (a_sp == 2'd0) && (a_sig == 0) && !a_st;
  logic [42:0] xbs; assign xbs = {xb[42:41], xb[40] ^ sub, xb[39:0]};
  logic [1:0] b_sp; assign b_sp = xbs[42:41];
  logic b_s; assign b_s = xbs[40];
  logic signed [12:0] b_e; assign b_e = $signed(xbs[39:27]);
  logic [25:0] b_sig; assign b_sig = xbs[26:1];
  logic b_st; assign b_st = xbs[0];
  logic b_z; assign b_z = (b_sp == 2'd0) && (b_sig == 0) && !b_st;
  logic signed [13:0] eax; assign eax = $signed({a_e[12], a_e});
  logic signed [13:0] ebx; assign ebx = $signed({b_e[12], b_e});
  logic [13:0] d_nb; assign d_nb = ~(ebx);
  logic signed [13:0] d;
  // the exponent difference
  fam_adder_ripple_carry #(.W(14), .CHUNK(8), .FORM(0)) u1 (.a(eax), .b(d_nb), .cin(1'b1), .s(d), .cout());
  logic signed [13:0] zero_x; assign zero_x = 14'sd0;
  logic [13:0] dn_nb; assign dn_nb = ~(d);
  logic signed [13:0] dn;
  // the difference negated
  fam_adder_ripple_carry #(.W(14), .CHUNK(8), .FORM(0)) u2 (.a(zero_x), .b(dn_nb), .cin(1'b1), .s(dn), .cout());
  logic a_big; assign a_big = d >= 0;
  logic [13:0] dabs; assign dabs = a_big ? d : dn;
  logic signed [12:0] e_big; assign e_big = a_big ? a_e : b_e;
  logic s_big; assign s_big = a_big ? a_s : b_s;
  logic eff_sub; assign eff_sub = a_s ^ b_s;
  logic [26:0] ma0; assign ma0 = {1'b0, a_sig[10:0], 15'd0};
  logic [26:0] mb0; assign mb0 = {1'b0, b_sig[10:0], 15'd0};
  logic close; assign close = (dabs <= 3) && eff_sub;
  logic far_fa; assign far_fa = ~a_big && (dabs > 26);
  logic [4:0] amt_fa; assign amt_fa = (!(~a_big) || far_fa) ? 5'd0 : dabs[4:0];
  logic [26:0] mssh_fa;
  // far path align (operand a): the operand shifted right by the exponent difference
  fam_shift_masked_merged #(.W(27), .MASKGEN(2), .MERGE(0), .R_RADIX_LOG2(1), .R_ONE_HOT(1), .R_ORDER(0), .STICKY(0)) u3 (.a(ma0), .amt(amt_fa), .op(3'd1), .y(mssh_fa), .sticky());
  logic [26:0] m_fa; assign m_fa = far_fa ? 27'd0 : mssh_fa;
  logic [4:0] tz_fa;
  // far path align (operand a): trailing zeros of the operand
  fam_count_tzc_isolate_then_encode_twos_complement_and_pe7180_w27 u4 (.a(ma0), .n(tz_fa));
  logic stk_fa; assign stk_fa = far_fa ? (a_sig != 0) : ((ma0 != 0) && (tz_fa < amt_fa));
  logic stb_fa; assign stb_fa = a_st | stk_fa;
  logic far_fb; assign far_fb = a_big && (dabs > 26);
  logic [4:0] amt_fb; assign amt_fb = (!(a_big) || far_fb) ? 5'd0 : dabs[4:0];
  logic [26:0] mssh_fb;
  // far path align (operand b): the operand shifted right by the exponent difference
  fam_shift_masked_merged #(.W(27), .MASKGEN(2), .MERGE(0), .R_RADIX_LOG2(1), .R_ONE_HOT(1), .R_ORDER(0), .STICKY(0)) u5 (.a(mb0), .amt(amt_fb), .op(3'd1), .y(mssh_fb), .sticky());
  logic [26:0] m_fb; assign m_fb = far_fb ? 27'd0 : mssh_fb;
  logic [4:0] tz_fb;
  // far path align (operand b): trailing zeros of the operand
  fam_count_tzc_isolate_then_encode_twos_complement_and_pe7180_w27 u6 (.a(mb0), .n(tz_fb));
  logic stk_fb; assign stk_fb = far_fb ? (b_sig != 0) : ((mb0 != 0) && (tz_fb < amt_fb));
  logic stb_fb; assign stb_fb = b_st | stk_fb;
  logic [26:0] ma_f; assign ma_f = m_fa;
  logic [26:0] mb_f; assign mb_f = m_fb;
  logic sta_f; assign sta_f = stb_fa;
  logic stb_f; assign stb_f = stb_fb;
  logic [26:0] yop_f; assign yop_f = eff_sub ? ~mb_f : mb_f;
  logic [26:0] nma_f; assign nma_f = ~ma_f;
  logic stall_f; assign stall_f = sta_f | stb_f;
  logic cop_f;
  logic [26:0] rp_f;
  // far path: the significand adder, X + Y or X + ~Y (end_around_carry)
  fam_binary_decode_fam_adder_eac_cyclic_prefix_level_p71ad0afc38c98cc878595b2be2d3d81b739691b88149561a71e54f41570fbe7b_w27 u7 (.a(ma_f), .b(yop_f), .cin(1'b0), .s(rp_f), .cout(cop_f));
  logic [26:0] rpi_f;
  logic rpic_f;
  // far path: the end-around carry through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(27), .STRUCTURE(1), .B(4), .TOPO(0)) u8 (.a(rp_f), .cin(1'b1), .s(rpi_f), .cout(rpic_f));
  logic neg_f; assign neg_f = eff_sub && !cop_f;
  logic [26:0] r_f; assign r_f = !eff_sub ? rp_f : cop_f ? (stb_f ? rp_f : rpi_f) : (sta_f ? ~rpi_f : ~rp_f);
  logic st_f; assign st_f = 1'b0 | stall_f;
  logic ovf_f; assign ovf_f = r_f[26];
  logic [25:0] sig0_f; assign sig0_f = ovf_f ? r_f[26:1] : r_f[25:0];
  logic st0_f; assign st0_f = st_f | (ovf_f & r_f[0]);
  logic signed [12:0] e0n_f_c; assign e0n_f_c = -13'sd15;
  logic signed [12:0] e0n_f;
  // far path: the window's exponent origin
  fam_adder_ripple_carry #(.W(13), .CHUNK(8), .FORM(0)) u9 (.a(e_big), .b(e0n_f_c), .cin(1'b0), .s(e0n_f), .cout());
  logic signed [12:0] e0o_f_c; assign e0o_f_c = -13'sd14;
  logic signed [12:0] e0o_f;
  // far path: the window's exponent origin after a carry out
  fam_adder_ripple_carry #(.W(13), .CHUNK(8), .FORM(0)) u10 (.a(e_big), .b(e0o_f_c), .cin(1'b0), .s(e0o_f), .cout());
  logic signed [12:0] e0_f; assign e0_f = ovf_f ? e0o_f : e0n_f;
  logic zero_f; assign zero_f = (sig0_f == 0) && !st0_f;
  logic sr_f; assign sr_f = zero_f ? 1'b0 : (neg_f ? b_s : a_s);
  logic [42:0] y_f; assign y_f = {2'd0, sr_f, e0_f, sig0_f, st0_f};
  logic far_ca; assign far_ca = ~a_big && (dabs > 3);
  logic [1:0] amt_ca; assign amt_ca = (!(~a_big) || far_ca) ? 2'd0 : dabs[1:0];
  logic [4:0] amtw_ca; assign amtw_ca = {{(5-2){1'b0}}, amt_ca};
  logic [26:0] mssh_ca;
  // close path align (operand a): the operand shifted right by the exponent difference
  fam_shift_masked_merged #(.W(27), .MASKGEN(2), .MERGE(0), .R_RADIX_LOG2(1), .R_ONE_HOT(1), .R_ORDER(0), .STICKY(0)) u11 (.a(ma0), .amt(amtw_ca), .op(3'd1), .y(mssh_ca), .sticky());
  logic [26:0] m_ca; assign m_ca = far_ca ? 27'd0 : mssh_ca;
  logic [4:0] tz_ca;
  // close path align (operand a): trailing zeros of the operand
  fam_count_tzc_isolate_then_encode_twos_complement_and_pe7180_w27 u12 (.a(ma0), .n(tz_ca));
  logic stk_ca; assign stk_ca = far_ca ? (a_sig != 0) : ((ma0 != 0) && (tz_ca < amt_ca));
  logic stb_ca; assign stb_ca = a_st | stk_ca;
  logic far_cb; assign far_cb = a_big && (dabs > 3);
  logic [1:0] amt_cb; assign amt_cb = (!(a_big) || far_cb) ? 2'd0 : dabs[1:0];
  logic [4:0] amtw_cb; assign amtw_cb = {{(5-2){1'b0}}, amt_cb};
  logic [26:0] mssh_cb;
  // close path align (operand b): the operand shifted right by the exponent difference
  fam_shift_masked_merged #(.W(27), .MASKGEN(2), .MERGE(0), .R_RADIX_LOG2(1), .R_ONE_HOT(1), .R_ORDER(0), .STICKY(0)) u13 (.a(mb0), .amt(amtw_cb), .op(3'd1), .y(mssh_cb), .sticky());
  logic [26:0] m_cb; assign m_cb = far_cb ? 27'd0 : mssh_cb;
  logic [4:0] tz_cb;
  // close path align (operand b): trailing zeros of the operand
  fam_count_tzc_isolate_then_encode_twos_complement_and_pe7180_w27 u14 (.a(mb0), .n(tz_cb));
  logic stk_cb; assign stk_cb = far_cb ? (b_sig != 0) : ((mb0 != 0) && (tz_cb < amt_cb));
  logic stb_cb; assign stb_cb = b_st | stk_cb;
  logic [26:0] ma_c; assign ma_c = m_ca;
  logic [26:0] mb_c; assign mb_c = m_cb;
  logic sta_c; assign sta_c = stb_ca;
  logic stb_c; assign stb_c = stb_cb;
  logic [26:0] yop_c; assign yop_c = eff_sub ? ~mb_c : mb_c;
  logic [26:0] nma_c; assign nma_c = ~ma_c;
  logic stall_c; assign stall_c = sta_c | stb_c;
  logic cop_c;
  logic [26:0] rp_c;
  // close path: the significand adder, X + Y or X + ~Y (end_around_carry)
  fam_binary_decode_fam_adder_eac_cyclic_prefix_level_p71ad0afc38c98cc878595b2be2d3d81b739691b88149561a71e54f41570fbe7b_w27 u15 (.a(ma_c), .b(yop_c), .cin(1'b0), .s(rp_c), .cout(cop_c));
  logic [26:0] rpi_c;
  logic rpic_c;
  // close path: the end-around carry through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(27), .STRUCTURE(1), .B(4), .TOPO(0)) u16 (.a(rp_c), .cin(1'b1), .s(rpi_c), .cout(rpic_c));
  logic neg_c; assign neg_c = eff_sub && !cop_c;
  logic [26:0] r_c; assign r_c = !eff_sub ? rp_c : cop_c ? (stb_c ? rp_c : rpi_c) : (sta_c ? ~rpi_c : ~rp_c);
  logic st_c; assign st_c = 1'b0 | stall_c;
  logic ovf_c; assign ovf_c = r_c[26];
  logic [25:0] sig0_c; assign sig0_c = ovf_c ? r_c[26:1] : r_c[25:0];
  logic st0_c; assign st0_c = st_c | (ovf_c & r_c[0]);
  logic signed [12:0] e0n_c_c; assign e0n_c_c = -13'sd15;
  logic signed [12:0] e0n_c;
  // close path: the window's exponent origin
  fam_adder_ripple_carry #(.W(13), .CHUNK(8), .FORM(0)) u17 (.a(e_big), .b(e0n_c_c), .cin(1'b0), .s(e0n_c), .cout());
  logic signed [12:0] e0o_c_c; assign e0o_c_c = -13'sd14;
  logic signed [12:0] e0o_c;
  // close path: the window's exponent origin after a carry out
  fam_adder_ripple_carry #(.W(13), .CHUNK(8), .FORM(0)) u18 (.a(e_big), .b(e0o_c_c), .cin(1'b0), .s(e0o_c), .cout());
  logic signed [12:0] e0_c; assign e0_c = ovf_c ? e0o_c : e0n_c;
  logic [26:0] t_c0; assign t_c0 = ma_c ^ yop_c;
  logic [26:0] g_c0; assign g_c0 = ma_c & yop_c;
  logic [26:0] z_c0; assign z_c0 = ~ma_c & ~yop_c;
  logic [26:0] f_c0;
  assign f_c0[0] = (t_c0[1] & ((g_c0[0] & ~1'b0) | (z_c0[0] & ~1'b0))) | (~t_c0[1] & ((z_c0[0] & ~1'b0) | (g_c0[0] & ~1'b0)));
  assign f_c0[1] = (t_c0[2] & ((g_c0[1] & ~z_c0[0]) | (z_c0[1] & ~g_c0[0]))) | (~t_c0[2] & ((z_c0[1] & ~z_c0[0]) | (g_c0[1] & ~g_c0[0])));
  assign f_c0[2] = (t_c0[3] & ((g_c0[2] & ~z_c0[1]) | (z_c0[2] & ~g_c0[1]))) | (~t_c0[3] & ((z_c0[2] & ~z_c0[1]) | (g_c0[2] & ~g_c0[1])));
  assign f_c0[3] = (t_c0[4] & ((g_c0[3] & ~z_c0[2]) | (z_c0[3] & ~g_c0[2]))) | (~t_c0[4] & ((z_c0[3] & ~z_c0[2]) | (g_c0[3] & ~g_c0[2])));
  assign f_c0[4] = (t_c0[5] & ((g_c0[4] & ~z_c0[3]) | (z_c0[4] & ~g_c0[3]))) | (~t_c0[5] & ((z_c0[4] & ~z_c0[3]) | (g_c0[4] & ~g_c0[3])));
  assign f_c0[5] = (t_c0[6] & ((g_c0[5] & ~z_c0[4]) | (z_c0[5] & ~g_c0[4]))) | (~t_c0[6] & ((z_c0[5] & ~z_c0[4]) | (g_c0[5] & ~g_c0[4])));
  assign f_c0[6] = (t_c0[7] & ((g_c0[6] & ~z_c0[5]) | (z_c0[6] & ~g_c0[5]))) | (~t_c0[7] & ((z_c0[6] & ~z_c0[5]) | (g_c0[6] & ~g_c0[5])));
  assign f_c0[7] = (t_c0[8] & ((g_c0[7] & ~z_c0[6]) | (z_c0[7] & ~g_c0[6]))) | (~t_c0[8] & ((z_c0[7] & ~z_c0[6]) | (g_c0[7] & ~g_c0[6])));
  assign f_c0[8] = (t_c0[9] & ((g_c0[8] & ~z_c0[7]) | (z_c0[8] & ~g_c0[7]))) | (~t_c0[9] & ((z_c0[8] & ~z_c0[7]) | (g_c0[8] & ~g_c0[7])));
  assign f_c0[9] = (t_c0[10] & ((g_c0[9] & ~z_c0[8]) | (z_c0[9] & ~g_c0[8]))) | (~t_c0[10] & ((z_c0[9] & ~z_c0[8]) | (g_c0[9] & ~g_c0[8])));
  assign f_c0[10] = (t_c0[11] & ((g_c0[10] & ~z_c0[9]) | (z_c0[10] & ~g_c0[9]))) | (~t_c0[11] & ((z_c0[10] & ~z_c0[9]) | (g_c0[10] & ~g_c0[9])));
  assign f_c0[11] = (t_c0[12] & ((g_c0[11] & ~z_c0[10]) | (z_c0[11] & ~g_c0[10]))) | (~t_c0[12] & ((z_c0[11] & ~z_c0[10]) | (g_c0[11] & ~g_c0[10])));
  assign f_c0[12] = (t_c0[13] & ((g_c0[12] & ~z_c0[11]) | (z_c0[12] & ~g_c0[11]))) | (~t_c0[13] & ((z_c0[12] & ~z_c0[11]) | (g_c0[12] & ~g_c0[11])));
  assign f_c0[13] = (t_c0[14] & ((g_c0[13] & ~z_c0[12]) | (z_c0[13] & ~g_c0[12]))) | (~t_c0[14] & ((z_c0[13] & ~z_c0[12]) | (g_c0[13] & ~g_c0[12])));
  assign f_c0[14] = (t_c0[15] & ((g_c0[14] & ~z_c0[13]) | (z_c0[14] & ~g_c0[13]))) | (~t_c0[15] & ((z_c0[14] & ~z_c0[13]) | (g_c0[14] & ~g_c0[13])));
  assign f_c0[15] = (t_c0[16] & ((g_c0[15] & ~z_c0[14]) | (z_c0[15] & ~g_c0[14]))) | (~t_c0[16] & ((z_c0[15] & ~z_c0[14]) | (g_c0[15] & ~g_c0[14])));
  assign f_c0[16] = (t_c0[17] & ((g_c0[16] & ~z_c0[15]) | (z_c0[16] & ~g_c0[15]))) | (~t_c0[17] & ((z_c0[16] & ~z_c0[15]) | (g_c0[16] & ~g_c0[15])));
  assign f_c0[17] = (t_c0[18] & ((g_c0[17] & ~z_c0[16]) | (z_c0[17] & ~g_c0[16]))) | (~t_c0[18] & ((z_c0[17] & ~z_c0[16]) | (g_c0[17] & ~g_c0[16])));
  assign f_c0[18] = (t_c0[19] & ((g_c0[18] & ~z_c0[17]) | (z_c0[18] & ~g_c0[17]))) | (~t_c0[19] & ((z_c0[18] & ~z_c0[17]) | (g_c0[18] & ~g_c0[17])));
  assign f_c0[19] = (t_c0[20] & ((g_c0[19] & ~z_c0[18]) | (z_c0[19] & ~g_c0[18]))) | (~t_c0[20] & ((z_c0[19] & ~z_c0[18]) | (g_c0[19] & ~g_c0[18])));
  assign f_c0[20] = (t_c0[21] & ((g_c0[20] & ~z_c0[19]) | (z_c0[20] & ~g_c0[19]))) | (~t_c0[21] & ((z_c0[20] & ~z_c0[19]) | (g_c0[20] & ~g_c0[19])));
  assign f_c0[21] = (t_c0[22] & ((g_c0[21] & ~z_c0[20]) | (z_c0[21] & ~g_c0[20]))) | (~t_c0[22] & ((z_c0[21] & ~z_c0[20]) | (g_c0[21] & ~g_c0[20])));
  assign f_c0[22] = (t_c0[23] & ((g_c0[22] & ~z_c0[21]) | (z_c0[22] & ~g_c0[21]))) | (~t_c0[23] & ((z_c0[22] & ~z_c0[21]) | (g_c0[22] & ~g_c0[21])));
  assign f_c0[23] = (t_c0[24] & ((g_c0[23] & ~z_c0[22]) | (z_c0[23] & ~g_c0[22]))) | (~t_c0[24] & ((z_c0[23] & ~z_c0[22]) | (g_c0[23] & ~g_c0[22])));
  assign f_c0[24] = (t_c0[25] & ((g_c0[24] & ~z_c0[23]) | (z_c0[24] & ~g_c0[23]))) | (~t_c0[25] & ((z_c0[24] & ~z_c0[23]) | (g_c0[24] & ~g_c0[23])));
  assign f_c0[25] = (t_c0[26] & ((g_c0[25] & ~z_c0[24]) | (z_c0[25] & ~g_c0[24]))) | (~t_c0[26] & ((z_c0[25] & ~z_c0[24]) | (g_c0[25] & ~g_c0[24])));
  assign f_c0[26] = (1'b0 & ((g_c0[26] & ~z_c0[25]) | (z_c0[26] & ~g_c0[25]))) | (~1'b0 & ((z_c0[26] & ~z_c0[25]) | (g_c0[26] & ~g_c0[25])));
  logic [25:0] fw_c0; assign fw_c0 = ovf_c ? f_c0[26:1] : f_c0[25:0];
  logic [26:0] t_c1; assign t_c1 = mb_c ^ nma_c;
  logic [26:0] g_c1; assign g_c1 = mb_c & nma_c;
  logic [26:0] z_c1; assign z_c1 = ~mb_c & ~nma_c;
  logic [26:0] f_c1;
  assign f_c1[0] = (t_c1[1] & ((g_c1[0] & ~1'b0) | (z_c1[0] & ~1'b0))) | (~t_c1[1] & ((z_c1[0] & ~1'b0) | (g_c1[0] & ~1'b0)));
  assign f_c1[1] = (t_c1[2] & ((g_c1[1] & ~z_c1[0]) | (z_c1[1] & ~g_c1[0]))) | (~t_c1[2] & ((z_c1[1] & ~z_c1[0]) | (g_c1[1] & ~g_c1[0])));
  assign f_c1[2] = (t_c1[3] & ((g_c1[2] & ~z_c1[1]) | (z_c1[2] & ~g_c1[1]))) | (~t_c1[3] & ((z_c1[2] & ~z_c1[1]) | (g_c1[2] & ~g_c1[1])));
  assign f_c1[3] = (t_c1[4] & ((g_c1[3] & ~z_c1[2]) | (z_c1[3] & ~g_c1[2]))) | (~t_c1[4] & ((z_c1[3] & ~z_c1[2]) | (g_c1[3] & ~g_c1[2])));
  assign f_c1[4] = (t_c1[5] & ((g_c1[4] & ~z_c1[3]) | (z_c1[4] & ~g_c1[3]))) | (~t_c1[5] & ((z_c1[4] & ~z_c1[3]) | (g_c1[4] & ~g_c1[3])));
  assign f_c1[5] = (t_c1[6] & ((g_c1[5] & ~z_c1[4]) | (z_c1[5] & ~g_c1[4]))) | (~t_c1[6] & ((z_c1[5] & ~z_c1[4]) | (g_c1[5] & ~g_c1[4])));
  assign f_c1[6] = (t_c1[7] & ((g_c1[6] & ~z_c1[5]) | (z_c1[6] & ~g_c1[5]))) | (~t_c1[7] & ((z_c1[6] & ~z_c1[5]) | (g_c1[6] & ~g_c1[5])));
  assign f_c1[7] = (t_c1[8] & ((g_c1[7] & ~z_c1[6]) | (z_c1[7] & ~g_c1[6]))) | (~t_c1[8] & ((z_c1[7] & ~z_c1[6]) | (g_c1[7] & ~g_c1[6])));
  assign f_c1[8] = (t_c1[9] & ((g_c1[8] & ~z_c1[7]) | (z_c1[8] & ~g_c1[7]))) | (~t_c1[9] & ((z_c1[8] & ~z_c1[7]) | (g_c1[8] & ~g_c1[7])));
  assign f_c1[9] = (t_c1[10] & ((g_c1[9] & ~z_c1[8]) | (z_c1[9] & ~g_c1[8]))) | (~t_c1[10] & ((z_c1[9] & ~z_c1[8]) | (g_c1[9] & ~g_c1[8])));
  assign f_c1[10] = (t_c1[11] & ((g_c1[10] & ~z_c1[9]) | (z_c1[10] & ~g_c1[9]))) | (~t_c1[11] & ((z_c1[10] & ~z_c1[9]) | (g_c1[10] & ~g_c1[9])));
  assign f_c1[11] = (t_c1[12] & ((g_c1[11] & ~z_c1[10]) | (z_c1[11] & ~g_c1[10]))) | (~t_c1[12] & ((z_c1[11] & ~z_c1[10]) | (g_c1[11] & ~g_c1[10])));
  assign f_c1[12] = (t_c1[13] & ((g_c1[12] & ~z_c1[11]) | (z_c1[12] & ~g_c1[11]))) | (~t_c1[13] & ((z_c1[12] & ~z_c1[11]) | (g_c1[12] & ~g_c1[11])));
  assign f_c1[13] = (t_c1[14] & ((g_c1[13] & ~z_c1[12]) | (z_c1[13] & ~g_c1[12]))) | (~t_c1[14] & ((z_c1[13] & ~z_c1[12]) | (g_c1[13] & ~g_c1[12])));
  assign f_c1[14] = (t_c1[15] & ((g_c1[14] & ~z_c1[13]) | (z_c1[14] & ~g_c1[13]))) | (~t_c1[15] & ((z_c1[14] & ~z_c1[13]) | (g_c1[14] & ~g_c1[13])));
  assign f_c1[15] = (t_c1[16] & ((g_c1[15] & ~z_c1[14]) | (z_c1[15] & ~g_c1[14]))) | (~t_c1[16] & ((z_c1[15] & ~z_c1[14]) | (g_c1[15] & ~g_c1[14])));
  assign f_c1[16] = (t_c1[17] & ((g_c1[16] & ~z_c1[15]) | (z_c1[16] & ~g_c1[15]))) | (~t_c1[17] & ((z_c1[16] & ~z_c1[15]) | (g_c1[16] & ~g_c1[15])));
  assign f_c1[17] = (t_c1[18] & ((g_c1[17] & ~z_c1[16]) | (z_c1[17] & ~g_c1[16]))) | (~t_c1[18] & ((z_c1[17] & ~z_c1[16]) | (g_c1[17] & ~g_c1[16])));
  assign f_c1[18] = (t_c1[19] & ((g_c1[18] & ~z_c1[17]) | (z_c1[18] & ~g_c1[17]))) | (~t_c1[19] & ((z_c1[18] & ~z_c1[17]) | (g_c1[18] & ~g_c1[17])));
  assign f_c1[19] = (t_c1[20] & ((g_c1[19] & ~z_c1[18]) | (z_c1[19] & ~g_c1[18]))) | (~t_c1[20] & ((z_c1[19] & ~z_c1[18]) | (g_c1[19] & ~g_c1[18])));
  assign f_c1[20] = (t_c1[21] & ((g_c1[20] & ~z_c1[19]) | (z_c1[20] & ~g_c1[19]))) | (~t_c1[21] & ((z_c1[20] & ~z_c1[19]) | (g_c1[20] & ~g_c1[19])));
  assign f_c1[21] = (t_c1[22] & ((g_c1[21] & ~z_c1[20]) | (z_c1[21] & ~g_c1[20]))) | (~t_c1[22] & ((z_c1[21] & ~z_c1[20]) | (g_c1[21] & ~g_c1[20])));
  assign f_c1[22] = (t_c1[23] & ((g_c1[22] & ~z_c1[21]) | (z_c1[22] & ~g_c1[21]))) | (~t_c1[23] & ((z_c1[22] & ~z_c1[21]) | (g_c1[22] & ~g_c1[21])));
  assign f_c1[23] = (t_c1[24] & ((g_c1[23] & ~z_c1[22]) | (z_c1[23] & ~g_c1[22]))) | (~t_c1[24] & ((z_c1[23] & ~z_c1[22]) | (g_c1[23] & ~g_c1[22])));
  assign f_c1[24] = (t_c1[25] & ((g_c1[24] & ~z_c1[23]) | (z_c1[24] & ~g_c1[23]))) | (~t_c1[25] & ((z_c1[24] & ~z_c1[23]) | (g_c1[24] & ~g_c1[23])));
  assign f_c1[25] = (t_c1[26] & ((g_c1[25] & ~z_c1[24]) | (z_c1[25] & ~g_c1[24]))) | (~t_c1[26] & ((z_c1[25] & ~z_c1[24]) | (g_c1[25] & ~g_c1[24])));
  assign f_c1[26] = (1'b0 & ((g_c1[26] & ~z_c1[25]) | (z_c1[26] & ~g_c1[25]))) | (~1'b0 & ((z_c1[26] & ~z_c1[25]) | (g_c1[26] & ~g_c1[25])));
  logic [25:0] fw_c1; assign fw_c1 = ovf_c ? f_c1[26:1] : f_c1[25:0];
  logic [25:0] fws_c; assign fws_c = (!neg_c) ? fw_c0 : fw_c1;
  logic [4:0] lzp_c;
  // close path: leading zeros of the indicator string
  fam_count_prefix_lzc_sklansky_pcomp_pct_p63edf_w26 u19 (.a(fws_c), .n(lzp_c));
  logic [4:0] lzs_c; assign lzs_c = (!eff_sub || fws_c == 0) ? 5'd0 : lzp_c[4:0];
  logic fz_c; assign fz_c = fws_c == 0;
  logic [4:0] cshift_c; assign cshift_c = {lzs_c[4:3], 3'd0};
  logic [4:0] fshift_c; assign fshift_c = {{(5-3){1'b0}}, lzs_c[2:0]};
  logic [25:0] sigc_c;
  // close path: the coarse normalize stage (multiples of 8)
  fam_shift_barrel_mux_tree #(.W(26), .RADIX_LOG2(0), .ONE_HOT(1), .DIR(1), .ORDER(0), .STICKY(0)) u20 (.a(sig0_c), .amt(cshift_c), .op(3'd0), .y(sigc_c), .sticky());
  logic [25:0] sign_c;
  // close path: the fine normalize stage
  fam_shift_barrel_mux_tree #(.W(26), .RADIX_LOG2(0), .ONE_HOT(1), .DIR(1), .ORDER(0), .STICKY(0)) u21 (.a(sigc_c), .amt(fshift_c), .op(3'd0), .y(sign_c), .sticky());
  logic signed [12:0] lzx_c; assign lzx_c = $signed({{(13-5){1'b0}}, lzs_c});
  logic [12:0] en_c_nb; assign en_c_nb = ~(lzx_c);
  logic signed [12:0] en_c;
  // close path: the exponent lowered by the normalize count
  fam_adder_ripple_carry #(.W(13), .CHUNK(8), .FORM(0)) u22 (.a(e0_c), .b(en_c_nb), .cin(1'b1), .s(en_c), .cout());
  logic fix_c; assign fix_c = ~sign_c[25] && (sign_c != 0);
  logic [25:0] sigf_c; assign sigf_c = fix_c ? {sign_c[24:0], 1'b0} : sign_c;
  logic signed [12:0] enm_c_c; assign enm_c_c = -13'sd1;
  logic signed [12:0] enm_c;
  // close path: the exponent of the corrected position
  fam_adder_ripple_carry #(.W(13), .CHUNK(8), .FORM(0)) u23 (.a(en_c), .b(enm_c_c), .cin(1'b0), .s(enm_c), .cout());
  logic signed [12:0] ef_c; assign ef_c = fix_c ? enm_c : en_c;
  logic zero_c; assign zero_c = eff_sub && (ma_c == mb_c) && !stall_c;
  logic sr_c; assign sr_c = zero_c ? 1'b0 : (neg_c ? b_s : a_s);
  logic [42:0] y_c; assign y_c = {2'd0, sr_c, ef_c, sigf_c, st0_c};
  logic [42:0] y_sel; assign y_sel = close ? y_c : (y_f);
  logic both_inf; assign both_inf = (a_sp == 2'd2) && (b_sp == 2'd2);
  logic [42:0] y_sp; assign y_sp = (a_sp == 2'd1 || b_sp == 2'd1) ? {2'd1, 1'b0, 13'sd0, 26'd0, 1'b0} : both_inf ? ((a_s == b_s) ? {2'd2, a_s, 13'sd0, 26'd0, 1'b0} : {2'd1, 1'b0, 13'sd0, 26'd0, 1'b0}) : (a_sp == 2'd2) ? {2'd2, a_s, 13'sd0, 26'd0, 1'b0} : (b_sp == 2'd2) ? {2'd2, b_s, 13'sd0, 26'd0, 1'b0} : a_z ? xbs : b_z ? xa : y_sel;
  assign y = y_sp;
endmodule

// fp comparator (dedicated_magnitude_comparator, subtractor_comparator)
module fam_fp_cmp_dedicated_magnitude_comparator_x20e16s8_pd5e3e6118bdf (
  input logic [39:0] xa,
  input logic [39:0] xb,
  output logic lt,
  output logic eq
);
  logic [1:0] a_sp; assign a_sp = xa[39:38];
  logic a_s; assign a_s = xa[37];
  logic signed [15:0] a_e; assign a_e = $signed(xa[36:21]);
  logic [19:0] a_sig; assign a_sig = xa[20:1];
  logic a_st; assign a_st = xa[0];
  logic a_z; assign a_z = (a_sp == 2'd0) && (a_sig == 0) && !a_st;
  logic [1:0] b_sp; assign b_sp = xb[39:38];
  logic b_s; assign b_s = xb[37];
  logic signed [15:0] b_e; assign b_e = $signed(xb[36:21]);
  logic [19:0] b_sig; assign b_sig = xb[20:1];
  logic b_st; assign b_st = xb[0];
  logic b_z; assign b_z = (b_sp == 2'd0) && (b_sig == 0) && !b_st;
  logic sa; assign sa = a_s && !a_z;
  logic sb; assign sb = b_s && !b_z;
  logic [15:0] aeu; assign aeu = {~a_e[15], a_e[14:0]};
  logic [15:0] beu; assign beu = {~b_e[15], b_e[14:0]};
  logic elt;
  logic eeq;
  // the exponents compared (subtractor_comparator)
  fam_cmp_subtractor_ripple_carry_p0a9f116f38aacd499cf3fe7c2675658275429e00f2c08fee42fa2d9523cdc581_sum_or_tree_u_w16 u1 (.a(aeu), .b(beu), .lt(elt), .eq(eeq));
  logic slt;
  logic seq;
  // the significands compared (subtractor_comparator)
  fam_cmp_subtractor_ripple_carry_p0a9f116f38aacd499cf3fe7c2675658275429e00f2c08fee42fa2d9523cdc581_sum_or_tree_u_w21 u2 (.a({a_sig, a_st}), .b({b_sig, b_st}), .lt(slt), .eq(seq));
  logic mlt; assign mlt = elt || (eeq && slt);
  logic meq; assign meq = eeq && seq;
  logic mag_lt; assign mag_lt = a_z ? 1'b1 : b_z ? 1'b0 : mlt;
  logic fin_eq; assign fin_eq = (a_z || b_z) ? (a_z && b_z) : ((a_s == b_s) && meq);
  logic fin_lt; assign fin_lt = (a_z && b_z) ? 1'b0 : (sa != sb) ? sa : (sa ? (!mag_lt && !fin_eq) : mag_lt);
  logic inf_lt; assign inf_lt = (a_sp == 2'd2 && b_sp == 2'd2) ? (a_s && !b_s) : (a_sp == 2'd2) ? a_s : !b_s;
  logic inf_eq; assign inf_eq = (a_sp == b_sp) && (a_s == b_s);
  logic any_inf; assign any_inf = (a_sp == 2'd2) || (b_sp == 2'd2);
  logic nan_any; assign nan_any = (a_sp == 2'd1) || (b_sp == 2'd1);
  assign lt = !nan_any && (any_inf ? inf_lt : fin_lt);
  assign eq = !nan_any && (any_inf ? inf_eq : fin_eq);
endmodule

// fp comparator (dedicated_magnitude_comparator, subtractor_comparator)
module fam_fp_cmp_dedicated_magnitude_comparator_x26e13s11_pe3208de2c98a (
  input logic [42:0] xa,
  input logic [42:0] xb,
  output logic lt,
  output logic eq
);
  logic [1:0] a_sp; assign a_sp = xa[42:41];
  logic a_s; assign a_s = xa[40];
  logic signed [12:0] a_e; assign a_e = $signed(xa[39:27]);
  logic [25:0] a_sig; assign a_sig = xa[26:1];
  logic a_st; assign a_st = xa[0];
  logic a_z; assign a_z = (a_sp == 2'd0) && (a_sig == 0) && !a_st;
  logic [1:0] b_sp; assign b_sp = xb[42:41];
  logic b_s; assign b_s = xb[40];
  logic signed [12:0] b_e; assign b_e = $signed(xb[39:27]);
  logic [25:0] b_sig; assign b_sig = xb[26:1];
  logic b_st; assign b_st = xb[0];
  logic b_z; assign b_z = (b_sp == 2'd0) && (b_sig == 0) && !b_st;
  logic sa; assign sa = a_s && !a_z;
  logic sb; assign sb = b_s && !b_z;
  logic [12:0] aeu; assign aeu = {~a_e[12], a_e[11:0]};
  logic [12:0] beu; assign beu = {~b_e[12], b_e[11:0]};
  logic elt;
  logic eeq;
  // the exponents compared (subtractor_comparator)
  fam_cmp_subtractor_ling_prefix_p6e18491987e97adb7af7143255ee504d7ae2c4e4893b558c56b954fb17ad0f22_operand_xnor_u_w13 u1 (.a(aeu), .b(beu), .lt(elt), .eq(eeq));
  logic slt;
  logic seq;
  // the significands compared (subtractor_comparator)
  fam_cmp_subtractor_ling_prefix_p6e18491987e97adb7af7143255ee504d7ae2c4e4893b558c56b954fb17ad0f22_operand_xnor_u_w27 u2 (.a({a_sig, a_st}), .b({b_sig, b_st}), .lt(slt), .eq(seq));
  logic mlt; assign mlt = elt || (eeq && slt);
  logic meq; assign meq = eeq && seq;
  logic mag_lt; assign mag_lt = a_z ? 1'b1 : b_z ? 1'b0 : mlt;
  logic fin_eq; assign fin_eq = (a_z || b_z) ? (a_z && b_z) : ((a_s == b_s) && meq);
  logic fin_lt; assign fin_lt = (a_z && b_z) ? 1'b0 : (sa != sb) ? sa : (sa ? (!mag_lt && !fin_eq) : mag_lt);
  logic inf_lt; assign inf_lt = (a_sp == 2'd2 && b_sp == 2'd2) ? (a_s && !b_s) : (a_sp == 2'd2) ? a_s : !b_s;
  logic inf_eq; assign inf_eq = (a_sp == b_sp) && (a_s == b_s);
  logic any_inf; assign any_inf = (a_sp == 2'd2) || (b_sp == 2'd2);
  logic nan_any; assign nan_any = (a_sp == 2'd1) || (b_sp == 2'd1);
  assign lt = !nan_any && (any_inf ? inf_lt : fin_lt);
  assign eq = !nan_any && (any_inf ? inf_eq : fin_eq);
endmodule

// fp comparator (integer_compare_on_bits, subtractor_comparator)
module fam_fp_cmp_integer_compare_on_bits_x10e13s3_pf4b323d9500d (
  input logic [26:0] xa,
  input logic [26:0] xb,
  output logic lt,
  output logic eq
);
  logic [1:0] a_sp; assign a_sp = xa[26:25];
  logic a_s; assign a_s = xa[24];
  logic signed [12:0] a_e; assign a_e = $signed(xa[23:11]);
  logic [9:0] a_sig; assign a_sig = xa[10:1];
  logic a_st; assign a_st = xa[0];
  logic a_z; assign a_z = (a_sp == 2'd0) && (a_sig == 0) && !a_st;
  logic [1:0] b_sp; assign b_sp = xb[26:25];
  logic b_s; assign b_s = xb[24];
  logic signed [12:0] b_e; assign b_e = $signed(xb[23:11]);
  logic [9:0] b_sig; assign b_sig = xb[10:1];
  logic b_st; assign b_st = xb[0];
  logic b_z; assign b_z = (b_sp == 2'd0) && (b_sig == 0) && !b_st;
  logic sa; assign sa = a_s && !a_z;
  logic sb; assign sb = b_s && !b_z;
  logic [12:0] aeu; assign aeu = {~a_e[12], a_e[11:0]};
  logic [12:0] beu; assign beu = {~b_e[12], b_e[11:0]};
  logic [23:0] ma; assign ma = {aeu, a_sig, a_st};
  logic [23:0] mb; assign mb = {beu, b_sig, b_st};
  logic mlt;
  logic meq;
  // the magnitude words compared as integers (subtractor_comparator)
  fam_cmp_subtractor_prefix_synthesis_nonuniform_arrival_p91919e29d8984fc7b1564e16baf52afcd8459b99d9f7793d8c56df316dce0a37_sum_or_tree_u_w24 u1 (.a(ma), .b(mb), .lt(mlt), .eq(meq));
  logic mag_lt; assign mag_lt = a_z ? 1'b1 : b_z ? 1'b0 : mlt;
  logic fin_eq; assign fin_eq = (a_z || b_z) ? (a_z && b_z) : ((a_s == b_s) && meq);
  logic fin_lt; assign fin_lt = (a_z && b_z) ? 1'b0 : (sa != sb) ? sa : (sa ? (!mag_lt && !fin_eq) : mag_lt);
  logic inf_lt; assign inf_lt = (a_sp == 2'd2 && b_sp == 2'd2) ? (a_s && !b_s) : (a_sp == 2'd2) ? a_s : !b_s;
  logic inf_eq; assign inf_eq = (a_sp == b_sp) && (a_s == b_s);
  logic any_inf; assign any_inf = (a_sp == 2'd2) || (b_sp == 2'd2);
  logic nan_any; assign nan_any = (a_sp == 2'd1) || (b_sp == 2'd1);
  assign lt = !nan_any && (any_inf ? inf_lt : fin_lt);
  assign eq = !nan_any && (any_inf ? inf_eq : fin_eq);
endmodule


// fused multiply-add (reduced_latency_fma): the 8-bit addend aligned against the 16-bit product over a 34-bit window (7 guard bits below the product for the X's 20-bit significand; a sticky lsb holds what leaves it), the significand multiplier booth_recoded_parallel, the window adder prefix_synthesis_nonuniform_arrival, negation by complement_recode, leading zeros by lza, one normalize; meets the fused contract; the rounding for 8 bits is fused into the compound adder for a normal result (it leaves with the ROUNDED code, the seed packs it through the library rounder); a subnormal, an overflow and the stochastic mode leave unrounded
module fam_fp_fma_core_reduced_latency_fma_x20e16s8_bf16_p6f6a2e63b089 (
  input logic [39:0] xa,
  input logic [39:0] xb,
  input logic [39:0] xc,
  input logic [2:0] rnd,
  output logic [39:0] y
);
  logic [1:0] a_sp; assign a_sp = xa[39:38];
  logic a_s; assign a_s = xa[37];
  logic signed [15:0] a_e; assign a_e = $signed(xa[36:21]);
  logic [19:0] a_sig; assign a_sig = xa[20:1];
  logic a_st; assign a_st = xa[0];
  logic a_z; assign a_z = (a_sp == 2'd0) && (a_sig == 0) && !a_st;
  logic [1:0] b_sp; assign b_sp = xb[39:38];
  logic b_s; assign b_s = xb[37];
  logic signed [15:0] b_e; assign b_e = $signed(xb[36:21]);
  logic [19:0] b_sig; assign b_sig = xb[20:1];
  logic b_st; assign b_st = xb[0];
  logic b_z; assign b_z = (b_sp == 2'd0) && (b_sig == 0) && !b_st;
  logic [1:0] c_sp; assign c_sp = xc[39:38];
  logic c_s; assign c_s = xc[37];
  logic signed [15:0] c_e; assign c_e = $signed(xc[36:21]);
  logic [19:0] c_sig; assign c_sig = xc[20:1];
  logic c_st; assign c_st = xc[0];
  logic c_z; assign c_z = (c_sp == 2'd0) && (c_sig == 0) && !c_st;
  logic [7:0] sa0; assign sa0 = a_sig[7:0];
  logic [3:0] a_lz;
  // operand a's leading zeros
  fam_count_lzd_pair_cell_binary_count_vprop_w8 u1 (.a(sa0), .n(a_lz));
  logic [2:0] a_lzs; assign a_lzs = (sa0 == 0) ? 3'd0 : a_lz[2:0];
  logic [7:0] sa;
  // operand a normalized
  fam_shift_butterfly_network #(.W(8), .NETWORK(1), .STICKY(0)) u2 (.a(sa0), .amt(a_lzs), .op(3'd0), .y(sa), .sticky());
  logic signed [18:0] ea; assign ea = $signed({{3{a_e[15]}}, a_e}) - $signed({{(19-3){1'b0}}, a_lzs});
  logic [7:0] sb0; assign sb0 = b_sig[7:0];
  logic [3:0] b_lz;
  // operand b's leading zeros
  fam_count_lzd_pair_cell_binary_count_vprop_w8 u3 (.a(sb0), .n(b_lz));
  logic [2:0] b_lzs; assign b_lzs = (sb0 == 0) ? 3'd0 : b_lz[2:0];
  logic [7:0] sb;
  // operand b normalized
  fam_shift_butterfly_network #(.W(8), .NETWORK(1), .STICKY(0)) u4 (.a(sb0), .amt(b_lzs), .op(3'd0), .y(sb), .sticky());
  logic signed [18:0] eb; assign eb = $signed({{3{b_e[15]}}, b_e}) - $signed({{(19-3){1'b0}}, b_lzs});
  logic [15:0] p_mul;
  // the significand product (booth_recoded_parallel)
  fam_mul_booth8_dadda_3_2_w8_u_p206e54d6 u5 (.a(sa), .b(sb), .p(p_mul));
  logic pure_add; assign pure_add = !a_s && (ea == -19'sd7) && (sa == 8'd128);
  logic [15:0] p; assign p = pure_add ? {1'b0, sb, 7'd0} : p_mul;
  logic signed [18:0] ep; assign ep = ea + eb;
  logic sp; assign sp = a_s ^ b_s;
  logic [7:0] sc0; assign sc0 = c_sig[7:0];
  logic signed [18:0] ec0; assign ec0 = $signed({{3{c_e[15]}}, c_e});
  logic [3:0] c_lz;
  // the addend's leading zeros
  fam_count_lzd_pair_cell_binary_count_vprop_w8 u6 (.a(sc0), .n(c_lz));
  logic [2:0] c_lzs; assign c_lzs = (sc0 == 0) ? 3'd0 : c_lz[2:0];
  logic [7:0] sc;
  // the addend normalized
  fam_shift_butterfly_network #(.W(8), .NETWORK(1), .STICKY(0)) u7 (.a(sc0), .amt(c_lzs), .op(3'd0), .y(sc), .sticky());
  logic signed [18:0] ec; assign ec = ec0 - $signed({{(19-3){1'b0}}, c_lzs});
  logic eff_sub; assign eff_sub = sp ^ c_s;
  logic signed [18:0] ep_e; assign ep_e = (p == 0) ? (ec - 19'sd18) : ep;
  logic signed [18:0] d; assign d = ec - ep_e;
  logic signed [18:0] shc0; assign shc0 = 19'sd18 - d;
  logic signed [18:0] shc; assign shc = (sc0 == 0) ? 19'sd0 : shc0;
  logic c_case; assign c_case = shc >= 0;
  logic signed [18:0] ef; assign ef = (c_case ? ep_e : (ep_e - shc)) - 19'sd7;
  logic [33:0] w0c; assign w0c = {1'b0, sc, 25'd0};
  logic [33:0] w0p; assign w0p = {{(34-16-7){1'b0}}, p, 7'd0};
  logic signed [18:0] amt0; assign amt0 = c_case ? shc : (-shc);
  logic far; assign far = amt0 >= 34;
  logic [5:0] amt; assign amt = far ? 6'd0 : amt0[5:0];
  logic [33:0] wsel; assign wsel = c_case ? w0c : w0p;
  logic [33:0] wsh;
  // the alignment shifter (the addend, or the product when the addend is far larger)
  fam_shift_funnel #(.W(34), .RADIX_LOG2(1), .AMT_PRE(1), .STICKY(1)) u8 (.a(wsel), .amt(amt), .op(3'd1), .y(wsh), .sticky());
  logic [33:0] wmask; assign wmask = far ? {34{1'b1}} : ~({34{1'b1}} << amt);
  logic wst; assign wst = |(wsel & wmask);
  logic [33:0] wal; assign wal = far ? 34'd0 : wsh;
  logic [33:0] c_al; assign c_al = c_case ? wal : w0c;
  logic [33:0] p_al; assign p_al = c_case ? w0p : wal;
  logic st_c; assign st_c = c_case ? wst : 1'b0;
  logic st_p; assign st_p = c_case ? 1'b0 : wst;
  logic [34:0] X; assign X = {p_al, st_p};
  logic [34:0] Y; assign Y = {c_al, st_c};
  logic [34:0] f_yop; assign f_yop = eff_sub ? ~Y : Y;
  logic [34:0] f_r;
  logic f_co;
  // f: X + Y (or X - Y in two's complement)
  fam_prefix_arrival_0_0_0_1_1_1_1_1_1_2_2_2_2_2_2_3_3_3_3_3_4_4_4_4_4_4_5_5_5_5_5_5_6_6_6_w35 u9 (.a(X), .b(f_yop), .cin(eff_sub), .s(f_r), .cout(f_co));
  logic f_neg; assign f_neg = eff_sub && !f_co;
  logic [34:0] f_mag; assign f_mag = f_neg ? (~f_r + 35'd1) : f_r;
  logic f_s; assign f_s = f_neg ? c_s : sp;
  logic [33:0] f_v; assign f_v = f_mag[34:1];
  logic f_stv; assign f_stv = f_mag[0];
  logic [1:0] f_lc; assign f_lc = f_neg ? (2'd1 + {1'b0, X[0] & f_yop[0]}) : eff_sub ? {1'b0, X[0] | f_yop[0]} : {1'b0, X[0] & f_yop[0]};
  logic [33:0] f_lx; assign f_lx = X[34:1];
  logic [33:0] f_ly; assign f_ly = f_yop[34:1];
  logic fx_neg; assign fx_neg = f_s;
  logic [33:0] fx_mag; assign fx_mag = f_v;
  logic fx_look_cin; assign fx_look_cin = f_v[0] ^ f_lx[0] ^ f_ly[0];
  logic signed [34:0] fx_look_a; assign fx_look_a = {f_lx[33], f_lx};
  logic [1:0] fx_look_adj; assign fx_look_adj = f_lc;
  logic signed [34:0] fx_look_b; assign fx_look_b = $signed({f_ly[33], f_ly}) + $signed({{(35-2){1'b0}}, fx_look_adj});
  logic [34:0] fx_look_am; assign fx_look_am = fx_look_a[34] ? -fx_look_a : fx_look_a;
  logic [63:0] fx_look_a_normal_input; assign fx_look_a_normal_input = {29'd0, fx_look_am};
  logic [6:0] fx_look_a_lz;
  // normalize a real lookahead operand
  fam_count_lzd_pair_cell_binary_count_vprop_w64 u10 (.a(fx_look_a_normal_input), .n(fx_look_a_lz));
  logic [5:0] fx_look_a_count; assign fx_look_a_count = (fx_look_am == 0) ? 0 : fx_look_a_lz[5:0];
  logic [63:0] fx_look_a_normalized;
  // the lookahead operand's declared normalizer
  fam_shift_butterfly_network #(.W(64), .NETWORK(1), .STICKY(0)) u11 (.a(fx_look_a_normal_input), .amt(fx_look_a_count), .op(3'd0), .y(fx_look_a_normalized), .sticky());
  logic signed [9:0] fx_look_a_exp; assign fx_look_a_exp = -$signed({1'b0, fx_look_a_count});
  logic [77:0] fx_look_ax; assign fx_look_ax = {2'd0, fx_look_a[34], fx_look_a_exp, fx_look_a_normalized, 1'b0};
  logic [34:0] fx_look_bm; assign fx_look_bm = fx_look_b[34] ? -fx_look_b : fx_look_b;
  logic [63:0] fx_look_b_normal_input; assign fx_look_b_normal_input = {29'd0, fx_look_bm};
  logic [6:0] fx_look_b_lz;
  // normalize a real lookahead operand
  fam_count_lzd_pair_cell_binary_count_vprop_w64 u12 (.a(fx_look_b_normal_input), .n(fx_look_b_lz));
  logic [5:0] fx_look_b_count; assign fx_look_b_count = (fx_look_bm == 0) ? 0 : fx_look_b_lz[5:0];
  logic [63:0] fx_look_b_normalized;
  // the lookahead operand's declared normalizer
  fam_shift_butterfly_network #(.W(64), .NETWORK(1), .STICKY(0)) u13 (.a(fx_look_b_normal_input), .amt(fx_look_b_count), .op(3'd0), .y(fx_look_b_normalized), .sticky());
  logic signed [9:0] fx_look_b_exp; assign fx_look_b_exp = -$signed({1'b0, fx_look_b_count});
  logic [77:0] fx_look_bx; assign fx_look_bx = {2'd0, fx_look_b[34], fx_look_b_exp, fx_look_b_normalized, 1'b0};
  logic [77:0] fx_look_result;
  logic fx_look_zero;
  fam_dot_lza_w34_p17e51f58317a u14 (.xa(fx_look_ax), .xb(fx_look_bx), .sub(1'b0), .y(fx_look_result), .predict_zero(fx_look_zero));
  logic signed [9:0] fx_look_exp; assign fx_look_exp = $signed(fx_look_result[74:65]);
  logic fx_look_bypass; assign fx_look_bypass = (fx_look_am == 0) || (fx_look_bm == 0);
  logic signed [9:0] fx_look_shift; assign fx_look_shift = (fx_look_bypass ? -10'sd30 : -10'sd30) - fx_look_exp;
  logic [5:0] fx_lzs; assign fx_lzs = (fx_mag == 0 || fx_look_shift < 0) ? 0 : (fx_look_shift >= 34) ? 6'd33 : fx_look_shift[5:0];
  logic [6:0] fx_lz; assign fx_lz = {1'b0, fx_lzs};
  logic [63:0] fx_nm_shifted_butterfly_input; assign fx_nm_shifted_butterfly_input = {{30{1'b0}}, fx_mag};
  logic [63:0] fx_nm_shifted_butterfly_result;
  // normalize the actual reduction result by its selected lookahead shift (power-of-two butterfly payload adapter)
  fam_shift_butterfly_network #(.W(64), .NETWORK(1), .STICKY(0)) u15 (.a(fx_nm_shifted_butterfly_input), .amt(fx_lzs), .op(3'd0), .y(fx_nm_shifted_butterfly_result), .sticky());
  logic [33:0] fx_nm_shifted; assign fx_nm_shifted = fx_nm_shifted_butterfly_result[33:0];
  logic [33:0] fx_nm; assign fx_nm = fx_look_zero ? 34'd0 : fx_nm_shifted;
  logic [19:0] fx_sig; assign fx_sig = fx_nm[33:14];
  logic fx_st; assign fx_st = (|fx_nm[13:0]) | f_stv;
  logic signed [18:0] fx_e0; assign fx_e0 = ef + 19'sd14 - $signed({{(19-7){1'b0}}, fx_lz});
  logic signed [15:0] fx_e; assign fx_e = fx_e0[15:0];
  logic fx_zero; assign fx_zero = (fx_mag == 0) && !(f_stv);
  logic [39:0] y_fx; assign y_fx = fx_zero ? {2'd0, 1'b0, 16'sd0, 20'd0, 1'b0} : {2'd0, fx_neg, fx_e, fx_sig, fx_st};
  logic [34:0] pd_a; assign pd_a = f_neg ? Y : X;
  logic [34:0] pd_b; assign pd_b = eff_sub ? ~(f_neg ? X : Y) : Y;
  logic [6:0] pd_cut; assign pd_cut = 7'd27 - fx_lz;
  logic signed [18:0] pd_exp; assign pd_exp = ef + 19'sd14 - $signed({1'b0, fx_lz});
  logic signed [18:0] pd_biased; assign pd_biased = pd_exp + 19'sd146;
  logic pd_eligible; assign pd_eligible = (|f_mag[34:1]) && (pd_cut >= 2) && (pd_cut <= 7'd27) && (pd_biased >= 1) && (pd_biased <= 19'sd254) && (rnd != 3'd4);
  logic [7:0] pd_k2_a; assign pd_k2_a = pd_a[9:2];
  logic [7:0] pd_k2_b; assign pd_k2_b = pd_b[9:2];
  logic pd_k2_cin; assign pd_k2_cin = pd_a[2] ^ pd_b[2] ^ f_mag[2];
  logic [7:0] pd_k2_s0;
  logic [7:0] pd_k2_s1;
  logic [7:0] pd_k2_s2;
  logic pd_k2_cout;
  logic pd_k2_cout2;
  // post-normalization compound CPA at rounding cut 2
  fam_prefix_kogge_stone_w8_flag_dual u16 (.a(pd_k2_a), .b(pd_k2_b), .cin(1'b0), .s(pd_k2_s0), .cout(pd_k2_cout), .s1(pd_k2_s1));
  // cut 2: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u17 (.a(pd_k2_s1), .cin(1'b1), .s(pd_k2_s2), .cout(pd_k2_cout2));
  logic [7:0] pd_k2_down; assign pd_k2_down = pd_k2_cin ? pd_k2_s1 : pd_k2_s0;
  logic [7:0] pd_k2_up; assign pd_k2_up = pd_k2_cin ? pd_k2_s2 : pd_k2_s1;
  logic pd_k2_guard; assign pd_k2_guard = f_mag[1];
  logic pd_k2_sticky; assign pd_k2_sticky = |f_mag[0:0];
  logic pd_k2_inexact; assign pd_k2_inexact = pd_k2_guard | pd_k2_sticky;
  logic pd_k2_increment; assign pd_k2_increment = (rnd == 3'd0) ? (pd_k2_guard && (pd_k2_sticky || pd_k2_down[0])) : (rnd == 3'd2) ? (pd_k2_inexact && f_s) : (rnd == 3'd3) ? (pd_k2_inexact && !f_s) : (rnd == 3'd5) ? pd_k2_inexact : 1'b0;
  logic [7:0] pd_k2_keep; assign pd_k2_keep = pd_k2_increment ? pd_k2_up : pd_k2_down;
  logic pd_k2_carry; assign pd_k2_carry = pd_k2_increment && (&pd_k2_down[7:0]);
  logic [19:0] pd_k2_sig; assign pd_k2_sig = pd_k2_carry ? (20'd1 << 19) : {pd_k2_keep[7:0], 12'd0};
  logic signed [18:0] pd_k2_ewide; assign pd_k2_ewide = pd_exp + (pd_k2_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k2_e; assign pd_k2_e = pd_k2_ewide[15:0];
  logic [1:0] pd_k2_special; assign pd_k2_special = pd_k2_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k2_y; assign pd_k2_y = {pd_k2_special, f_s, pd_k2_e, pd_k2_sig, 1'b0};
  logic [7:0] pd_k3_a; assign pd_k3_a = pd_a[10:3];
  logic [7:0] pd_k3_b; assign pd_k3_b = pd_b[10:3];
  logic pd_k3_cin; assign pd_k3_cin = pd_a[3] ^ pd_b[3] ^ f_mag[3];
  logic [7:0] pd_k3_s0;
  logic [7:0] pd_k3_s1;
  logic [7:0] pd_k3_s2;
  logic pd_k3_cout;
  logic pd_k3_cout2;
  // post-normalization compound CPA at rounding cut 3
  fam_prefix_kogge_stone_w8_flag_dual u18 (.a(pd_k3_a), .b(pd_k3_b), .cin(1'b0), .s(pd_k3_s0), .cout(pd_k3_cout), .s1(pd_k3_s1));
  // cut 3: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u19 (.a(pd_k3_s1), .cin(1'b1), .s(pd_k3_s2), .cout(pd_k3_cout2));
  logic [7:0] pd_k3_down; assign pd_k3_down = pd_k3_cin ? pd_k3_s1 : pd_k3_s0;
  logic [7:0] pd_k3_up; assign pd_k3_up = pd_k3_cin ? pd_k3_s2 : pd_k3_s1;
  logic pd_k3_guard; assign pd_k3_guard = f_mag[2];
  logic pd_k3_sticky; assign pd_k3_sticky = |f_mag[1:0];
  logic pd_k3_inexact; assign pd_k3_inexact = pd_k3_guard | pd_k3_sticky;
  logic pd_k3_increment; assign pd_k3_increment = (rnd == 3'd0) ? (pd_k3_guard && (pd_k3_sticky || pd_k3_down[0])) : (rnd == 3'd2) ? (pd_k3_inexact && f_s) : (rnd == 3'd3) ? (pd_k3_inexact && !f_s) : (rnd == 3'd5) ? pd_k3_inexact : 1'b0;
  logic [7:0] pd_k3_keep; assign pd_k3_keep = pd_k3_increment ? pd_k3_up : pd_k3_down;
  logic pd_k3_carry; assign pd_k3_carry = pd_k3_increment && (&pd_k3_down[7:0]);
  logic [19:0] pd_k3_sig; assign pd_k3_sig = pd_k3_carry ? (20'd1 << 19) : {pd_k3_keep[7:0], 12'd0};
  logic signed [18:0] pd_k3_ewide; assign pd_k3_ewide = pd_exp + (pd_k3_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k3_e; assign pd_k3_e = pd_k3_ewide[15:0];
  logic [1:0] pd_k3_special; assign pd_k3_special = pd_k3_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k3_y; assign pd_k3_y = {pd_k3_special, f_s, pd_k3_e, pd_k3_sig, 1'b0};
  logic [7:0] pd_k4_a; assign pd_k4_a = pd_a[11:4];
  logic [7:0] pd_k4_b; assign pd_k4_b = pd_b[11:4];
  logic pd_k4_cin; assign pd_k4_cin = pd_a[4] ^ pd_b[4] ^ f_mag[4];
  logic [7:0] pd_k4_s0;
  logic [7:0] pd_k4_s1;
  logic [7:0] pd_k4_s2;
  logic pd_k4_cout;
  logic pd_k4_cout2;
  // post-normalization compound CPA at rounding cut 4
  fam_prefix_kogge_stone_w8_flag_dual u20 (.a(pd_k4_a), .b(pd_k4_b), .cin(1'b0), .s(pd_k4_s0), .cout(pd_k4_cout), .s1(pd_k4_s1));
  // cut 4: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u21 (.a(pd_k4_s1), .cin(1'b1), .s(pd_k4_s2), .cout(pd_k4_cout2));
  logic [7:0] pd_k4_down; assign pd_k4_down = pd_k4_cin ? pd_k4_s1 : pd_k4_s0;
  logic [7:0] pd_k4_up; assign pd_k4_up = pd_k4_cin ? pd_k4_s2 : pd_k4_s1;
  logic pd_k4_guard; assign pd_k4_guard = f_mag[3];
  logic pd_k4_sticky; assign pd_k4_sticky = |f_mag[2:0];
  logic pd_k4_inexact; assign pd_k4_inexact = pd_k4_guard | pd_k4_sticky;
  logic pd_k4_increment; assign pd_k4_increment = (rnd == 3'd0) ? (pd_k4_guard && (pd_k4_sticky || pd_k4_down[0])) : (rnd == 3'd2) ? (pd_k4_inexact && f_s) : (rnd == 3'd3) ? (pd_k4_inexact && !f_s) : (rnd == 3'd5) ? pd_k4_inexact : 1'b0;
  logic [7:0] pd_k4_keep; assign pd_k4_keep = pd_k4_increment ? pd_k4_up : pd_k4_down;
  logic pd_k4_carry; assign pd_k4_carry = pd_k4_increment && (&pd_k4_down[7:0]);
  logic [19:0] pd_k4_sig; assign pd_k4_sig = pd_k4_carry ? (20'd1 << 19) : {pd_k4_keep[7:0], 12'd0};
  logic signed [18:0] pd_k4_ewide; assign pd_k4_ewide = pd_exp + (pd_k4_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k4_e; assign pd_k4_e = pd_k4_ewide[15:0];
  logic [1:0] pd_k4_special; assign pd_k4_special = pd_k4_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k4_y; assign pd_k4_y = {pd_k4_special, f_s, pd_k4_e, pd_k4_sig, 1'b0};
  logic [7:0] pd_k5_a; assign pd_k5_a = pd_a[12:5];
  logic [7:0] pd_k5_b; assign pd_k5_b = pd_b[12:5];
  logic pd_k5_cin; assign pd_k5_cin = pd_a[5] ^ pd_b[5] ^ f_mag[5];
  logic [7:0] pd_k5_s0;
  logic [7:0] pd_k5_s1;
  logic [7:0] pd_k5_s2;
  logic pd_k5_cout;
  logic pd_k5_cout2;
  // post-normalization compound CPA at rounding cut 5
  fam_prefix_kogge_stone_w8_flag_dual u22 (.a(pd_k5_a), .b(pd_k5_b), .cin(1'b0), .s(pd_k5_s0), .cout(pd_k5_cout), .s1(pd_k5_s1));
  // cut 5: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u23 (.a(pd_k5_s1), .cin(1'b1), .s(pd_k5_s2), .cout(pd_k5_cout2));
  logic [7:0] pd_k5_down; assign pd_k5_down = pd_k5_cin ? pd_k5_s1 : pd_k5_s0;
  logic [7:0] pd_k5_up; assign pd_k5_up = pd_k5_cin ? pd_k5_s2 : pd_k5_s1;
  logic pd_k5_guard; assign pd_k5_guard = f_mag[4];
  logic pd_k5_sticky; assign pd_k5_sticky = |f_mag[3:0];
  logic pd_k5_inexact; assign pd_k5_inexact = pd_k5_guard | pd_k5_sticky;
  logic pd_k5_increment; assign pd_k5_increment = (rnd == 3'd0) ? (pd_k5_guard && (pd_k5_sticky || pd_k5_down[0])) : (rnd == 3'd2) ? (pd_k5_inexact && f_s) : (rnd == 3'd3) ? (pd_k5_inexact && !f_s) : (rnd == 3'd5) ? pd_k5_inexact : 1'b0;
  logic [7:0] pd_k5_keep; assign pd_k5_keep = pd_k5_increment ? pd_k5_up : pd_k5_down;
  logic pd_k5_carry; assign pd_k5_carry = pd_k5_increment && (&pd_k5_down[7:0]);
  logic [19:0] pd_k5_sig; assign pd_k5_sig = pd_k5_carry ? (20'd1 << 19) : {pd_k5_keep[7:0], 12'd0};
  logic signed [18:0] pd_k5_ewide; assign pd_k5_ewide = pd_exp + (pd_k5_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k5_e; assign pd_k5_e = pd_k5_ewide[15:0];
  logic [1:0] pd_k5_special; assign pd_k5_special = pd_k5_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k5_y; assign pd_k5_y = {pd_k5_special, f_s, pd_k5_e, pd_k5_sig, 1'b0};
  logic [7:0] pd_k6_a; assign pd_k6_a = pd_a[13:6];
  logic [7:0] pd_k6_b; assign pd_k6_b = pd_b[13:6];
  logic pd_k6_cin; assign pd_k6_cin = pd_a[6] ^ pd_b[6] ^ f_mag[6];
  logic [7:0] pd_k6_s0;
  logic [7:0] pd_k6_s1;
  logic [7:0] pd_k6_s2;
  logic pd_k6_cout;
  logic pd_k6_cout2;
  // post-normalization compound CPA at rounding cut 6
  fam_prefix_kogge_stone_w8_flag_dual u24 (.a(pd_k6_a), .b(pd_k6_b), .cin(1'b0), .s(pd_k6_s0), .cout(pd_k6_cout), .s1(pd_k6_s1));
  // cut 6: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u25 (.a(pd_k6_s1), .cin(1'b1), .s(pd_k6_s2), .cout(pd_k6_cout2));
  logic [7:0] pd_k6_down; assign pd_k6_down = pd_k6_cin ? pd_k6_s1 : pd_k6_s0;
  logic [7:0] pd_k6_up; assign pd_k6_up = pd_k6_cin ? pd_k6_s2 : pd_k6_s1;
  logic pd_k6_guard; assign pd_k6_guard = f_mag[5];
  logic pd_k6_sticky; assign pd_k6_sticky = |f_mag[4:0];
  logic pd_k6_inexact; assign pd_k6_inexact = pd_k6_guard | pd_k6_sticky;
  logic pd_k6_increment; assign pd_k6_increment = (rnd == 3'd0) ? (pd_k6_guard && (pd_k6_sticky || pd_k6_down[0])) : (rnd == 3'd2) ? (pd_k6_inexact && f_s) : (rnd == 3'd3) ? (pd_k6_inexact && !f_s) : (rnd == 3'd5) ? pd_k6_inexact : 1'b0;
  logic [7:0] pd_k6_keep; assign pd_k6_keep = pd_k6_increment ? pd_k6_up : pd_k6_down;
  logic pd_k6_carry; assign pd_k6_carry = pd_k6_increment && (&pd_k6_down[7:0]);
  logic [19:0] pd_k6_sig; assign pd_k6_sig = pd_k6_carry ? (20'd1 << 19) : {pd_k6_keep[7:0], 12'd0};
  logic signed [18:0] pd_k6_ewide; assign pd_k6_ewide = pd_exp + (pd_k6_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k6_e; assign pd_k6_e = pd_k6_ewide[15:0];
  logic [1:0] pd_k6_special; assign pd_k6_special = pd_k6_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k6_y; assign pd_k6_y = {pd_k6_special, f_s, pd_k6_e, pd_k6_sig, 1'b0};
  logic [7:0] pd_k7_a; assign pd_k7_a = pd_a[14:7];
  logic [7:0] pd_k7_b; assign pd_k7_b = pd_b[14:7];
  logic pd_k7_cin; assign pd_k7_cin = pd_a[7] ^ pd_b[7] ^ f_mag[7];
  logic [7:0] pd_k7_s0;
  logic [7:0] pd_k7_s1;
  logic [7:0] pd_k7_s2;
  logic pd_k7_cout;
  logic pd_k7_cout2;
  // post-normalization compound CPA at rounding cut 7
  fam_prefix_kogge_stone_w8_flag_dual u26 (.a(pd_k7_a), .b(pd_k7_b), .cin(1'b0), .s(pd_k7_s0), .cout(pd_k7_cout), .s1(pd_k7_s1));
  // cut 7: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u27 (.a(pd_k7_s1), .cin(1'b1), .s(pd_k7_s2), .cout(pd_k7_cout2));
  logic [7:0] pd_k7_down; assign pd_k7_down = pd_k7_cin ? pd_k7_s1 : pd_k7_s0;
  logic [7:0] pd_k7_up; assign pd_k7_up = pd_k7_cin ? pd_k7_s2 : pd_k7_s1;
  logic pd_k7_guard; assign pd_k7_guard = f_mag[6];
  logic pd_k7_sticky; assign pd_k7_sticky = |f_mag[5:0];
  logic pd_k7_inexact; assign pd_k7_inexact = pd_k7_guard | pd_k7_sticky;
  logic pd_k7_increment; assign pd_k7_increment = (rnd == 3'd0) ? (pd_k7_guard && (pd_k7_sticky || pd_k7_down[0])) : (rnd == 3'd2) ? (pd_k7_inexact && f_s) : (rnd == 3'd3) ? (pd_k7_inexact && !f_s) : (rnd == 3'd5) ? pd_k7_inexact : 1'b0;
  logic [7:0] pd_k7_keep; assign pd_k7_keep = pd_k7_increment ? pd_k7_up : pd_k7_down;
  logic pd_k7_carry; assign pd_k7_carry = pd_k7_increment && (&pd_k7_down[7:0]);
  logic [19:0] pd_k7_sig; assign pd_k7_sig = pd_k7_carry ? (20'd1 << 19) : {pd_k7_keep[7:0], 12'd0};
  logic signed [18:0] pd_k7_ewide; assign pd_k7_ewide = pd_exp + (pd_k7_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k7_e; assign pd_k7_e = pd_k7_ewide[15:0];
  logic [1:0] pd_k7_special; assign pd_k7_special = pd_k7_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k7_y; assign pd_k7_y = {pd_k7_special, f_s, pd_k7_e, pd_k7_sig, 1'b0};
  logic [7:0] pd_k8_a; assign pd_k8_a = pd_a[15:8];
  logic [7:0] pd_k8_b; assign pd_k8_b = pd_b[15:8];
  logic pd_k8_cin; assign pd_k8_cin = pd_a[8] ^ pd_b[8] ^ f_mag[8];
  logic [7:0] pd_k8_s0;
  logic [7:0] pd_k8_s1;
  logic [7:0] pd_k8_s2;
  logic pd_k8_cout;
  logic pd_k8_cout2;
  // post-normalization compound CPA at rounding cut 8
  fam_prefix_kogge_stone_w8_flag_dual u28 (.a(pd_k8_a), .b(pd_k8_b), .cin(1'b0), .s(pd_k8_s0), .cout(pd_k8_cout), .s1(pd_k8_s1));
  // cut 8: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u29 (.a(pd_k8_s1), .cin(1'b1), .s(pd_k8_s2), .cout(pd_k8_cout2));
  logic [7:0] pd_k8_down; assign pd_k8_down = pd_k8_cin ? pd_k8_s1 : pd_k8_s0;
  logic [7:0] pd_k8_up; assign pd_k8_up = pd_k8_cin ? pd_k8_s2 : pd_k8_s1;
  logic pd_k8_guard; assign pd_k8_guard = f_mag[7];
  logic pd_k8_sticky; assign pd_k8_sticky = |f_mag[6:0];
  logic pd_k8_inexact; assign pd_k8_inexact = pd_k8_guard | pd_k8_sticky;
  logic pd_k8_increment; assign pd_k8_increment = (rnd == 3'd0) ? (pd_k8_guard && (pd_k8_sticky || pd_k8_down[0])) : (rnd == 3'd2) ? (pd_k8_inexact && f_s) : (rnd == 3'd3) ? (pd_k8_inexact && !f_s) : (rnd == 3'd5) ? pd_k8_inexact : 1'b0;
  logic [7:0] pd_k8_keep; assign pd_k8_keep = pd_k8_increment ? pd_k8_up : pd_k8_down;
  logic pd_k8_carry; assign pd_k8_carry = pd_k8_increment && (&pd_k8_down[7:0]);
  logic [19:0] pd_k8_sig; assign pd_k8_sig = pd_k8_carry ? (20'd1 << 19) : {pd_k8_keep[7:0], 12'd0};
  logic signed [18:0] pd_k8_ewide; assign pd_k8_ewide = pd_exp + (pd_k8_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k8_e; assign pd_k8_e = pd_k8_ewide[15:0];
  logic [1:0] pd_k8_special; assign pd_k8_special = pd_k8_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k8_y; assign pd_k8_y = {pd_k8_special, f_s, pd_k8_e, pd_k8_sig, 1'b0};
  logic [7:0] pd_k9_a; assign pd_k9_a = pd_a[16:9];
  logic [7:0] pd_k9_b; assign pd_k9_b = pd_b[16:9];
  logic pd_k9_cin; assign pd_k9_cin = pd_a[9] ^ pd_b[9] ^ f_mag[9];
  logic [7:0] pd_k9_s0;
  logic [7:0] pd_k9_s1;
  logic [7:0] pd_k9_s2;
  logic pd_k9_cout;
  logic pd_k9_cout2;
  // post-normalization compound CPA at rounding cut 9
  fam_prefix_kogge_stone_w8_flag_dual u30 (.a(pd_k9_a), .b(pd_k9_b), .cin(1'b0), .s(pd_k9_s0), .cout(pd_k9_cout), .s1(pd_k9_s1));
  // cut 9: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u31 (.a(pd_k9_s1), .cin(1'b1), .s(pd_k9_s2), .cout(pd_k9_cout2));
  logic [7:0] pd_k9_down; assign pd_k9_down = pd_k9_cin ? pd_k9_s1 : pd_k9_s0;
  logic [7:0] pd_k9_up; assign pd_k9_up = pd_k9_cin ? pd_k9_s2 : pd_k9_s1;
  logic pd_k9_guard; assign pd_k9_guard = f_mag[8];
  logic pd_k9_sticky; assign pd_k9_sticky = |f_mag[7:0];
  logic pd_k9_inexact; assign pd_k9_inexact = pd_k9_guard | pd_k9_sticky;
  logic pd_k9_increment; assign pd_k9_increment = (rnd == 3'd0) ? (pd_k9_guard && (pd_k9_sticky || pd_k9_down[0])) : (rnd == 3'd2) ? (pd_k9_inexact && f_s) : (rnd == 3'd3) ? (pd_k9_inexact && !f_s) : (rnd == 3'd5) ? pd_k9_inexact : 1'b0;
  logic [7:0] pd_k9_keep; assign pd_k9_keep = pd_k9_increment ? pd_k9_up : pd_k9_down;
  logic pd_k9_carry; assign pd_k9_carry = pd_k9_increment && (&pd_k9_down[7:0]);
  logic [19:0] pd_k9_sig; assign pd_k9_sig = pd_k9_carry ? (20'd1 << 19) : {pd_k9_keep[7:0], 12'd0};
  logic signed [18:0] pd_k9_ewide; assign pd_k9_ewide = pd_exp + (pd_k9_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k9_e; assign pd_k9_e = pd_k9_ewide[15:0];
  logic [1:0] pd_k9_special; assign pd_k9_special = pd_k9_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k9_y; assign pd_k9_y = {pd_k9_special, f_s, pd_k9_e, pd_k9_sig, 1'b0};
  logic [7:0] pd_k10_a; assign pd_k10_a = pd_a[17:10];
  logic [7:0] pd_k10_b; assign pd_k10_b = pd_b[17:10];
  logic pd_k10_cin; assign pd_k10_cin = pd_a[10] ^ pd_b[10] ^ f_mag[10];
  logic [7:0] pd_k10_s0;
  logic [7:0] pd_k10_s1;
  logic [7:0] pd_k10_s2;
  logic pd_k10_cout;
  logic pd_k10_cout2;
  // post-normalization compound CPA at rounding cut 10
  fam_prefix_kogge_stone_w8_flag_dual u32 (.a(pd_k10_a), .b(pd_k10_b), .cin(1'b0), .s(pd_k10_s0), .cout(pd_k10_cout), .s1(pd_k10_s1));
  // cut 10: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u33 (.a(pd_k10_s1), .cin(1'b1), .s(pd_k10_s2), .cout(pd_k10_cout2));
  logic [7:0] pd_k10_down; assign pd_k10_down = pd_k10_cin ? pd_k10_s1 : pd_k10_s0;
  logic [7:0] pd_k10_up; assign pd_k10_up = pd_k10_cin ? pd_k10_s2 : pd_k10_s1;
  logic pd_k10_guard; assign pd_k10_guard = f_mag[9];
  logic pd_k10_sticky; assign pd_k10_sticky = |f_mag[8:0];
  logic pd_k10_inexact; assign pd_k10_inexact = pd_k10_guard | pd_k10_sticky;
  logic pd_k10_increment; assign pd_k10_increment = (rnd == 3'd0) ? (pd_k10_guard && (pd_k10_sticky || pd_k10_down[0])) : (rnd == 3'd2) ? (pd_k10_inexact && f_s) : (rnd == 3'd3) ? (pd_k10_inexact && !f_s) : (rnd == 3'd5) ? pd_k10_inexact : 1'b0;
  logic [7:0] pd_k10_keep; assign pd_k10_keep = pd_k10_increment ? pd_k10_up : pd_k10_down;
  logic pd_k10_carry; assign pd_k10_carry = pd_k10_increment && (&pd_k10_down[7:0]);
  logic [19:0] pd_k10_sig; assign pd_k10_sig = pd_k10_carry ? (20'd1 << 19) : {pd_k10_keep[7:0], 12'd0};
  logic signed [18:0] pd_k10_ewide; assign pd_k10_ewide = pd_exp + (pd_k10_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k10_e; assign pd_k10_e = pd_k10_ewide[15:0];
  logic [1:0] pd_k10_special; assign pd_k10_special = pd_k10_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k10_y; assign pd_k10_y = {pd_k10_special, f_s, pd_k10_e, pd_k10_sig, 1'b0};
  logic [7:0] pd_k11_a; assign pd_k11_a = pd_a[18:11];
  logic [7:0] pd_k11_b; assign pd_k11_b = pd_b[18:11];
  logic pd_k11_cin; assign pd_k11_cin = pd_a[11] ^ pd_b[11] ^ f_mag[11];
  logic [7:0] pd_k11_s0;
  logic [7:0] pd_k11_s1;
  logic [7:0] pd_k11_s2;
  logic pd_k11_cout;
  logic pd_k11_cout2;
  // post-normalization compound CPA at rounding cut 11
  fam_prefix_kogge_stone_w8_flag_dual u34 (.a(pd_k11_a), .b(pd_k11_b), .cin(1'b0), .s(pd_k11_s0), .cout(pd_k11_cout), .s1(pd_k11_s1));
  // cut 11: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u35 (.a(pd_k11_s1), .cin(1'b1), .s(pd_k11_s2), .cout(pd_k11_cout2));
  logic [7:0] pd_k11_down; assign pd_k11_down = pd_k11_cin ? pd_k11_s1 : pd_k11_s0;
  logic [7:0] pd_k11_up; assign pd_k11_up = pd_k11_cin ? pd_k11_s2 : pd_k11_s1;
  logic pd_k11_guard; assign pd_k11_guard = f_mag[10];
  logic pd_k11_sticky; assign pd_k11_sticky = |f_mag[9:0];
  logic pd_k11_inexact; assign pd_k11_inexact = pd_k11_guard | pd_k11_sticky;
  logic pd_k11_increment; assign pd_k11_increment = (rnd == 3'd0) ? (pd_k11_guard && (pd_k11_sticky || pd_k11_down[0])) : (rnd == 3'd2) ? (pd_k11_inexact && f_s) : (rnd == 3'd3) ? (pd_k11_inexact && !f_s) : (rnd == 3'd5) ? pd_k11_inexact : 1'b0;
  logic [7:0] pd_k11_keep; assign pd_k11_keep = pd_k11_increment ? pd_k11_up : pd_k11_down;
  logic pd_k11_carry; assign pd_k11_carry = pd_k11_increment && (&pd_k11_down[7:0]);
  logic [19:0] pd_k11_sig; assign pd_k11_sig = pd_k11_carry ? (20'd1 << 19) : {pd_k11_keep[7:0], 12'd0};
  logic signed [18:0] pd_k11_ewide; assign pd_k11_ewide = pd_exp + (pd_k11_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k11_e; assign pd_k11_e = pd_k11_ewide[15:0];
  logic [1:0] pd_k11_special; assign pd_k11_special = pd_k11_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k11_y; assign pd_k11_y = {pd_k11_special, f_s, pd_k11_e, pd_k11_sig, 1'b0};
  logic [7:0] pd_k12_a; assign pd_k12_a = pd_a[19:12];
  logic [7:0] pd_k12_b; assign pd_k12_b = pd_b[19:12];
  logic pd_k12_cin; assign pd_k12_cin = pd_a[12] ^ pd_b[12] ^ f_mag[12];
  logic [7:0] pd_k12_s0;
  logic [7:0] pd_k12_s1;
  logic [7:0] pd_k12_s2;
  logic pd_k12_cout;
  logic pd_k12_cout2;
  // post-normalization compound CPA at rounding cut 12
  fam_prefix_kogge_stone_w8_flag_dual u36 (.a(pd_k12_a), .b(pd_k12_b), .cin(1'b0), .s(pd_k12_s0), .cout(pd_k12_cout), .s1(pd_k12_s1));
  // cut 12: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u37 (.a(pd_k12_s1), .cin(1'b1), .s(pd_k12_s2), .cout(pd_k12_cout2));
  logic [7:0] pd_k12_down; assign pd_k12_down = pd_k12_cin ? pd_k12_s1 : pd_k12_s0;
  logic [7:0] pd_k12_up; assign pd_k12_up = pd_k12_cin ? pd_k12_s2 : pd_k12_s1;
  logic pd_k12_guard; assign pd_k12_guard = f_mag[11];
  logic pd_k12_sticky; assign pd_k12_sticky = |f_mag[10:0];
  logic pd_k12_inexact; assign pd_k12_inexact = pd_k12_guard | pd_k12_sticky;
  logic pd_k12_increment; assign pd_k12_increment = (rnd == 3'd0) ? (pd_k12_guard && (pd_k12_sticky || pd_k12_down[0])) : (rnd == 3'd2) ? (pd_k12_inexact && f_s) : (rnd == 3'd3) ? (pd_k12_inexact && !f_s) : (rnd == 3'd5) ? pd_k12_inexact : 1'b0;
  logic [7:0] pd_k12_keep; assign pd_k12_keep = pd_k12_increment ? pd_k12_up : pd_k12_down;
  logic pd_k12_carry; assign pd_k12_carry = pd_k12_increment && (&pd_k12_down[7:0]);
  logic [19:0] pd_k12_sig; assign pd_k12_sig = pd_k12_carry ? (20'd1 << 19) : {pd_k12_keep[7:0], 12'd0};
  logic signed [18:0] pd_k12_ewide; assign pd_k12_ewide = pd_exp + (pd_k12_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k12_e; assign pd_k12_e = pd_k12_ewide[15:0];
  logic [1:0] pd_k12_special; assign pd_k12_special = pd_k12_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k12_y; assign pd_k12_y = {pd_k12_special, f_s, pd_k12_e, pd_k12_sig, 1'b0};
  logic [7:0] pd_k13_a; assign pd_k13_a = pd_a[20:13];
  logic [7:0] pd_k13_b; assign pd_k13_b = pd_b[20:13];
  logic pd_k13_cin; assign pd_k13_cin = pd_a[13] ^ pd_b[13] ^ f_mag[13];
  logic [7:0] pd_k13_s0;
  logic [7:0] pd_k13_s1;
  logic [7:0] pd_k13_s2;
  logic pd_k13_cout;
  logic pd_k13_cout2;
  // post-normalization compound CPA at rounding cut 13
  fam_prefix_kogge_stone_w8_flag_dual u38 (.a(pd_k13_a), .b(pd_k13_b), .cin(1'b0), .s(pd_k13_s0), .cout(pd_k13_cout), .s1(pd_k13_s1));
  // cut 13: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u39 (.a(pd_k13_s1), .cin(1'b1), .s(pd_k13_s2), .cout(pd_k13_cout2));
  logic [7:0] pd_k13_down; assign pd_k13_down = pd_k13_cin ? pd_k13_s1 : pd_k13_s0;
  logic [7:0] pd_k13_up; assign pd_k13_up = pd_k13_cin ? pd_k13_s2 : pd_k13_s1;
  logic pd_k13_guard; assign pd_k13_guard = f_mag[12];
  logic pd_k13_sticky; assign pd_k13_sticky = |f_mag[11:0];
  logic pd_k13_inexact; assign pd_k13_inexact = pd_k13_guard | pd_k13_sticky;
  logic pd_k13_increment; assign pd_k13_increment = (rnd == 3'd0) ? (pd_k13_guard && (pd_k13_sticky || pd_k13_down[0])) : (rnd == 3'd2) ? (pd_k13_inexact && f_s) : (rnd == 3'd3) ? (pd_k13_inexact && !f_s) : (rnd == 3'd5) ? pd_k13_inexact : 1'b0;
  logic [7:0] pd_k13_keep; assign pd_k13_keep = pd_k13_increment ? pd_k13_up : pd_k13_down;
  logic pd_k13_carry; assign pd_k13_carry = pd_k13_increment && (&pd_k13_down[7:0]);
  logic [19:0] pd_k13_sig; assign pd_k13_sig = pd_k13_carry ? (20'd1 << 19) : {pd_k13_keep[7:0], 12'd0};
  logic signed [18:0] pd_k13_ewide; assign pd_k13_ewide = pd_exp + (pd_k13_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k13_e; assign pd_k13_e = pd_k13_ewide[15:0];
  logic [1:0] pd_k13_special; assign pd_k13_special = pd_k13_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k13_y; assign pd_k13_y = {pd_k13_special, f_s, pd_k13_e, pd_k13_sig, 1'b0};
  logic [7:0] pd_k14_a; assign pd_k14_a = pd_a[21:14];
  logic [7:0] pd_k14_b; assign pd_k14_b = pd_b[21:14];
  logic pd_k14_cin; assign pd_k14_cin = pd_a[14] ^ pd_b[14] ^ f_mag[14];
  logic [7:0] pd_k14_s0;
  logic [7:0] pd_k14_s1;
  logic [7:0] pd_k14_s2;
  logic pd_k14_cout;
  logic pd_k14_cout2;
  // post-normalization compound CPA at rounding cut 14
  fam_prefix_kogge_stone_w8_flag_dual u40 (.a(pd_k14_a), .b(pd_k14_b), .cin(1'b0), .s(pd_k14_s0), .cout(pd_k14_cout), .s1(pd_k14_s1));
  // cut 14: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u41 (.a(pd_k14_s1), .cin(1'b1), .s(pd_k14_s2), .cout(pd_k14_cout2));
  logic [7:0] pd_k14_down; assign pd_k14_down = pd_k14_cin ? pd_k14_s1 : pd_k14_s0;
  logic [7:0] pd_k14_up; assign pd_k14_up = pd_k14_cin ? pd_k14_s2 : pd_k14_s1;
  logic pd_k14_guard; assign pd_k14_guard = f_mag[13];
  logic pd_k14_sticky; assign pd_k14_sticky = |f_mag[12:0];
  logic pd_k14_inexact; assign pd_k14_inexact = pd_k14_guard | pd_k14_sticky;
  logic pd_k14_increment; assign pd_k14_increment = (rnd == 3'd0) ? (pd_k14_guard && (pd_k14_sticky || pd_k14_down[0])) : (rnd == 3'd2) ? (pd_k14_inexact && f_s) : (rnd == 3'd3) ? (pd_k14_inexact && !f_s) : (rnd == 3'd5) ? pd_k14_inexact : 1'b0;
  logic [7:0] pd_k14_keep; assign pd_k14_keep = pd_k14_increment ? pd_k14_up : pd_k14_down;
  logic pd_k14_carry; assign pd_k14_carry = pd_k14_increment && (&pd_k14_down[7:0]);
  logic [19:0] pd_k14_sig; assign pd_k14_sig = pd_k14_carry ? (20'd1 << 19) : {pd_k14_keep[7:0], 12'd0};
  logic signed [18:0] pd_k14_ewide; assign pd_k14_ewide = pd_exp + (pd_k14_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k14_e; assign pd_k14_e = pd_k14_ewide[15:0];
  logic [1:0] pd_k14_special; assign pd_k14_special = pd_k14_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k14_y; assign pd_k14_y = {pd_k14_special, f_s, pd_k14_e, pd_k14_sig, 1'b0};
  logic [7:0] pd_k15_a; assign pd_k15_a = pd_a[22:15];
  logic [7:0] pd_k15_b; assign pd_k15_b = pd_b[22:15];
  logic pd_k15_cin; assign pd_k15_cin = pd_a[15] ^ pd_b[15] ^ f_mag[15];
  logic [7:0] pd_k15_s0;
  logic [7:0] pd_k15_s1;
  logic [7:0] pd_k15_s2;
  logic pd_k15_cout;
  logic pd_k15_cout2;
  // post-normalization compound CPA at rounding cut 15
  fam_prefix_kogge_stone_w8_flag_dual u42 (.a(pd_k15_a), .b(pd_k15_b), .cin(1'b0), .s(pd_k15_s0), .cout(pd_k15_cout), .s1(pd_k15_s1));
  // cut 15: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u43 (.a(pd_k15_s1), .cin(1'b1), .s(pd_k15_s2), .cout(pd_k15_cout2));
  logic [7:0] pd_k15_down; assign pd_k15_down = pd_k15_cin ? pd_k15_s1 : pd_k15_s0;
  logic [7:0] pd_k15_up; assign pd_k15_up = pd_k15_cin ? pd_k15_s2 : pd_k15_s1;
  logic pd_k15_guard; assign pd_k15_guard = f_mag[14];
  logic pd_k15_sticky; assign pd_k15_sticky = |f_mag[13:0];
  logic pd_k15_inexact; assign pd_k15_inexact = pd_k15_guard | pd_k15_sticky;
  logic pd_k15_increment; assign pd_k15_increment = (rnd == 3'd0) ? (pd_k15_guard && (pd_k15_sticky || pd_k15_down[0])) : (rnd == 3'd2) ? (pd_k15_inexact && f_s) : (rnd == 3'd3) ? (pd_k15_inexact && !f_s) : (rnd == 3'd5) ? pd_k15_inexact : 1'b0;
  logic [7:0] pd_k15_keep; assign pd_k15_keep = pd_k15_increment ? pd_k15_up : pd_k15_down;
  logic pd_k15_carry; assign pd_k15_carry = pd_k15_increment && (&pd_k15_down[7:0]);
  logic [19:0] pd_k15_sig; assign pd_k15_sig = pd_k15_carry ? (20'd1 << 19) : {pd_k15_keep[7:0], 12'd0};
  logic signed [18:0] pd_k15_ewide; assign pd_k15_ewide = pd_exp + (pd_k15_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k15_e; assign pd_k15_e = pd_k15_ewide[15:0];
  logic [1:0] pd_k15_special; assign pd_k15_special = pd_k15_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k15_y; assign pd_k15_y = {pd_k15_special, f_s, pd_k15_e, pd_k15_sig, 1'b0};
  logic [7:0] pd_k16_a; assign pd_k16_a = pd_a[23:16];
  logic [7:0] pd_k16_b; assign pd_k16_b = pd_b[23:16];
  logic pd_k16_cin; assign pd_k16_cin = pd_a[16] ^ pd_b[16] ^ f_mag[16];
  logic [7:0] pd_k16_s0;
  logic [7:0] pd_k16_s1;
  logic [7:0] pd_k16_s2;
  logic pd_k16_cout;
  logic pd_k16_cout2;
  // post-normalization compound CPA at rounding cut 16
  fam_prefix_kogge_stone_w8_flag_dual u44 (.a(pd_k16_a), .b(pd_k16_b), .cin(1'b0), .s(pd_k16_s0), .cout(pd_k16_cout), .s1(pd_k16_s1));
  // cut 16: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u45 (.a(pd_k16_s1), .cin(1'b1), .s(pd_k16_s2), .cout(pd_k16_cout2));
  logic [7:0] pd_k16_down; assign pd_k16_down = pd_k16_cin ? pd_k16_s1 : pd_k16_s0;
  logic [7:0] pd_k16_up; assign pd_k16_up = pd_k16_cin ? pd_k16_s2 : pd_k16_s1;
  logic pd_k16_guard; assign pd_k16_guard = f_mag[15];
  logic pd_k16_sticky; assign pd_k16_sticky = |f_mag[14:0];
  logic pd_k16_inexact; assign pd_k16_inexact = pd_k16_guard | pd_k16_sticky;
  logic pd_k16_increment; assign pd_k16_increment = (rnd == 3'd0) ? (pd_k16_guard && (pd_k16_sticky || pd_k16_down[0])) : (rnd == 3'd2) ? (pd_k16_inexact && f_s) : (rnd == 3'd3) ? (pd_k16_inexact && !f_s) : (rnd == 3'd5) ? pd_k16_inexact : 1'b0;
  logic [7:0] pd_k16_keep; assign pd_k16_keep = pd_k16_increment ? pd_k16_up : pd_k16_down;
  logic pd_k16_carry; assign pd_k16_carry = pd_k16_increment && (&pd_k16_down[7:0]);
  logic [19:0] pd_k16_sig; assign pd_k16_sig = pd_k16_carry ? (20'd1 << 19) : {pd_k16_keep[7:0], 12'd0};
  logic signed [18:0] pd_k16_ewide; assign pd_k16_ewide = pd_exp + (pd_k16_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k16_e; assign pd_k16_e = pd_k16_ewide[15:0];
  logic [1:0] pd_k16_special; assign pd_k16_special = pd_k16_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k16_y; assign pd_k16_y = {pd_k16_special, f_s, pd_k16_e, pd_k16_sig, 1'b0};
  logic [7:0] pd_k17_a; assign pd_k17_a = pd_a[24:17];
  logic [7:0] pd_k17_b; assign pd_k17_b = pd_b[24:17];
  logic pd_k17_cin; assign pd_k17_cin = pd_a[17] ^ pd_b[17] ^ f_mag[17];
  logic [7:0] pd_k17_s0;
  logic [7:0] pd_k17_s1;
  logic [7:0] pd_k17_s2;
  logic pd_k17_cout;
  logic pd_k17_cout2;
  // post-normalization compound CPA at rounding cut 17
  fam_prefix_kogge_stone_w8_flag_dual u46 (.a(pd_k17_a), .b(pd_k17_b), .cin(1'b0), .s(pd_k17_s0), .cout(pd_k17_cout), .s1(pd_k17_s1));
  // cut 17: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u47 (.a(pd_k17_s1), .cin(1'b1), .s(pd_k17_s2), .cout(pd_k17_cout2));
  logic [7:0] pd_k17_down; assign pd_k17_down = pd_k17_cin ? pd_k17_s1 : pd_k17_s0;
  logic [7:0] pd_k17_up; assign pd_k17_up = pd_k17_cin ? pd_k17_s2 : pd_k17_s1;
  logic pd_k17_guard; assign pd_k17_guard = f_mag[16];
  logic pd_k17_sticky; assign pd_k17_sticky = |f_mag[15:0];
  logic pd_k17_inexact; assign pd_k17_inexact = pd_k17_guard | pd_k17_sticky;
  logic pd_k17_increment; assign pd_k17_increment = (rnd == 3'd0) ? (pd_k17_guard && (pd_k17_sticky || pd_k17_down[0])) : (rnd == 3'd2) ? (pd_k17_inexact && f_s) : (rnd == 3'd3) ? (pd_k17_inexact && !f_s) : (rnd == 3'd5) ? pd_k17_inexact : 1'b0;
  logic [7:0] pd_k17_keep; assign pd_k17_keep = pd_k17_increment ? pd_k17_up : pd_k17_down;
  logic pd_k17_carry; assign pd_k17_carry = pd_k17_increment && (&pd_k17_down[7:0]);
  logic [19:0] pd_k17_sig; assign pd_k17_sig = pd_k17_carry ? (20'd1 << 19) : {pd_k17_keep[7:0], 12'd0};
  logic signed [18:0] pd_k17_ewide; assign pd_k17_ewide = pd_exp + (pd_k17_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k17_e; assign pd_k17_e = pd_k17_ewide[15:0];
  logic [1:0] pd_k17_special; assign pd_k17_special = pd_k17_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k17_y; assign pd_k17_y = {pd_k17_special, f_s, pd_k17_e, pd_k17_sig, 1'b0};
  logic [7:0] pd_k18_a; assign pd_k18_a = pd_a[25:18];
  logic [7:0] pd_k18_b; assign pd_k18_b = pd_b[25:18];
  logic pd_k18_cin; assign pd_k18_cin = pd_a[18] ^ pd_b[18] ^ f_mag[18];
  logic [7:0] pd_k18_s0;
  logic [7:0] pd_k18_s1;
  logic [7:0] pd_k18_s2;
  logic pd_k18_cout;
  logic pd_k18_cout2;
  // post-normalization compound CPA at rounding cut 18
  fam_prefix_kogge_stone_w8_flag_dual u48 (.a(pd_k18_a), .b(pd_k18_b), .cin(1'b0), .s(pd_k18_s0), .cout(pd_k18_cout), .s1(pd_k18_s1));
  // cut 18: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u49 (.a(pd_k18_s1), .cin(1'b1), .s(pd_k18_s2), .cout(pd_k18_cout2));
  logic [7:0] pd_k18_down; assign pd_k18_down = pd_k18_cin ? pd_k18_s1 : pd_k18_s0;
  logic [7:0] pd_k18_up; assign pd_k18_up = pd_k18_cin ? pd_k18_s2 : pd_k18_s1;
  logic pd_k18_guard; assign pd_k18_guard = f_mag[17];
  logic pd_k18_sticky; assign pd_k18_sticky = |f_mag[16:0];
  logic pd_k18_inexact; assign pd_k18_inexact = pd_k18_guard | pd_k18_sticky;
  logic pd_k18_increment; assign pd_k18_increment = (rnd == 3'd0) ? (pd_k18_guard && (pd_k18_sticky || pd_k18_down[0])) : (rnd == 3'd2) ? (pd_k18_inexact && f_s) : (rnd == 3'd3) ? (pd_k18_inexact && !f_s) : (rnd == 3'd5) ? pd_k18_inexact : 1'b0;
  logic [7:0] pd_k18_keep; assign pd_k18_keep = pd_k18_increment ? pd_k18_up : pd_k18_down;
  logic pd_k18_carry; assign pd_k18_carry = pd_k18_increment && (&pd_k18_down[7:0]);
  logic [19:0] pd_k18_sig; assign pd_k18_sig = pd_k18_carry ? (20'd1 << 19) : {pd_k18_keep[7:0], 12'd0};
  logic signed [18:0] pd_k18_ewide; assign pd_k18_ewide = pd_exp + (pd_k18_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k18_e; assign pd_k18_e = pd_k18_ewide[15:0];
  logic [1:0] pd_k18_special; assign pd_k18_special = pd_k18_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k18_y; assign pd_k18_y = {pd_k18_special, f_s, pd_k18_e, pd_k18_sig, 1'b0};
  logic [7:0] pd_k19_a; assign pd_k19_a = pd_a[26:19];
  logic [7:0] pd_k19_b; assign pd_k19_b = pd_b[26:19];
  logic pd_k19_cin; assign pd_k19_cin = pd_a[19] ^ pd_b[19] ^ f_mag[19];
  logic [7:0] pd_k19_s0;
  logic [7:0] pd_k19_s1;
  logic [7:0] pd_k19_s2;
  logic pd_k19_cout;
  logic pd_k19_cout2;
  // post-normalization compound CPA at rounding cut 19
  fam_prefix_kogge_stone_w8_flag_dual u50 (.a(pd_k19_a), .b(pd_k19_b), .cin(1'b0), .s(pd_k19_s0), .cout(pd_k19_cout), .s1(pd_k19_s1));
  // cut 19: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u51 (.a(pd_k19_s1), .cin(1'b1), .s(pd_k19_s2), .cout(pd_k19_cout2));
  logic [7:0] pd_k19_down; assign pd_k19_down = pd_k19_cin ? pd_k19_s1 : pd_k19_s0;
  logic [7:0] pd_k19_up; assign pd_k19_up = pd_k19_cin ? pd_k19_s2 : pd_k19_s1;
  logic pd_k19_guard; assign pd_k19_guard = f_mag[18];
  logic pd_k19_sticky; assign pd_k19_sticky = |f_mag[17:0];
  logic pd_k19_inexact; assign pd_k19_inexact = pd_k19_guard | pd_k19_sticky;
  logic pd_k19_increment; assign pd_k19_increment = (rnd == 3'd0) ? (pd_k19_guard && (pd_k19_sticky || pd_k19_down[0])) : (rnd == 3'd2) ? (pd_k19_inexact && f_s) : (rnd == 3'd3) ? (pd_k19_inexact && !f_s) : (rnd == 3'd5) ? pd_k19_inexact : 1'b0;
  logic [7:0] pd_k19_keep; assign pd_k19_keep = pd_k19_increment ? pd_k19_up : pd_k19_down;
  logic pd_k19_carry; assign pd_k19_carry = pd_k19_increment && (&pd_k19_down[7:0]);
  logic [19:0] pd_k19_sig; assign pd_k19_sig = pd_k19_carry ? (20'd1 << 19) : {pd_k19_keep[7:0], 12'd0};
  logic signed [18:0] pd_k19_ewide; assign pd_k19_ewide = pd_exp + (pd_k19_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k19_e; assign pd_k19_e = pd_k19_ewide[15:0];
  logic [1:0] pd_k19_special; assign pd_k19_special = pd_k19_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k19_y; assign pd_k19_y = {pd_k19_special, f_s, pd_k19_e, pd_k19_sig, 1'b0};
  logic [7:0] pd_k20_a; assign pd_k20_a = pd_a[27:20];
  logic [7:0] pd_k20_b; assign pd_k20_b = pd_b[27:20];
  logic pd_k20_cin; assign pd_k20_cin = pd_a[20] ^ pd_b[20] ^ f_mag[20];
  logic [7:0] pd_k20_s0;
  logic [7:0] pd_k20_s1;
  logic [7:0] pd_k20_s2;
  logic pd_k20_cout;
  logic pd_k20_cout2;
  // post-normalization compound CPA at rounding cut 20
  fam_prefix_kogge_stone_w8_flag_dual u52 (.a(pd_k20_a), .b(pd_k20_b), .cin(1'b0), .s(pd_k20_s0), .cout(pd_k20_cout), .s1(pd_k20_s1));
  // cut 20: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u53 (.a(pd_k20_s1), .cin(1'b1), .s(pd_k20_s2), .cout(pd_k20_cout2));
  logic [7:0] pd_k20_down; assign pd_k20_down = pd_k20_cin ? pd_k20_s1 : pd_k20_s0;
  logic [7:0] pd_k20_up; assign pd_k20_up = pd_k20_cin ? pd_k20_s2 : pd_k20_s1;
  logic pd_k20_guard; assign pd_k20_guard = f_mag[19];
  logic pd_k20_sticky; assign pd_k20_sticky = |f_mag[18:0];
  logic pd_k20_inexact; assign pd_k20_inexact = pd_k20_guard | pd_k20_sticky;
  logic pd_k20_increment; assign pd_k20_increment = (rnd == 3'd0) ? (pd_k20_guard && (pd_k20_sticky || pd_k20_down[0])) : (rnd == 3'd2) ? (pd_k20_inexact && f_s) : (rnd == 3'd3) ? (pd_k20_inexact && !f_s) : (rnd == 3'd5) ? pd_k20_inexact : 1'b0;
  logic [7:0] pd_k20_keep; assign pd_k20_keep = pd_k20_increment ? pd_k20_up : pd_k20_down;
  logic pd_k20_carry; assign pd_k20_carry = pd_k20_increment && (&pd_k20_down[7:0]);
  logic [19:0] pd_k20_sig; assign pd_k20_sig = pd_k20_carry ? (20'd1 << 19) : {pd_k20_keep[7:0], 12'd0};
  logic signed [18:0] pd_k20_ewide; assign pd_k20_ewide = pd_exp + (pd_k20_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k20_e; assign pd_k20_e = pd_k20_ewide[15:0];
  logic [1:0] pd_k20_special; assign pd_k20_special = pd_k20_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k20_y; assign pd_k20_y = {pd_k20_special, f_s, pd_k20_e, pd_k20_sig, 1'b0};
  logic [7:0] pd_k21_a; assign pd_k21_a = pd_a[28:21];
  logic [7:0] pd_k21_b; assign pd_k21_b = pd_b[28:21];
  logic pd_k21_cin; assign pd_k21_cin = pd_a[21] ^ pd_b[21] ^ f_mag[21];
  logic [7:0] pd_k21_s0;
  logic [7:0] pd_k21_s1;
  logic [7:0] pd_k21_s2;
  logic pd_k21_cout;
  logic pd_k21_cout2;
  // post-normalization compound CPA at rounding cut 21
  fam_prefix_kogge_stone_w8_flag_dual u54 (.a(pd_k21_a), .b(pd_k21_b), .cin(1'b0), .s(pd_k21_s0), .cout(pd_k21_cout), .s1(pd_k21_s1));
  // cut 21: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u55 (.a(pd_k21_s1), .cin(1'b1), .s(pd_k21_s2), .cout(pd_k21_cout2));
  logic [7:0] pd_k21_down; assign pd_k21_down = pd_k21_cin ? pd_k21_s1 : pd_k21_s0;
  logic [7:0] pd_k21_up; assign pd_k21_up = pd_k21_cin ? pd_k21_s2 : pd_k21_s1;
  logic pd_k21_guard; assign pd_k21_guard = f_mag[20];
  logic pd_k21_sticky; assign pd_k21_sticky = |f_mag[19:0];
  logic pd_k21_inexact; assign pd_k21_inexact = pd_k21_guard | pd_k21_sticky;
  logic pd_k21_increment; assign pd_k21_increment = (rnd == 3'd0) ? (pd_k21_guard && (pd_k21_sticky || pd_k21_down[0])) : (rnd == 3'd2) ? (pd_k21_inexact && f_s) : (rnd == 3'd3) ? (pd_k21_inexact && !f_s) : (rnd == 3'd5) ? pd_k21_inexact : 1'b0;
  logic [7:0] pd_k21_keep; assign pd_k21_keep = pd_k21_increment ? pd_k21_up : pd_k21_down;
  logic pd_k21_carry; assign pd_k21_carry = pd_k21_increment && (&pd_k21_down[7:0]);
  logic [19:0] pd_k21_sig; assign pd_k21_sig = pd_k21_carry ? (20'd1 << 19) : {pd_k21_keep[7:0], 12'd0};
  logic signed [18:0] pd_k21_ewide; assign pd_k21_ewide = pd_exp + (pd_k21_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k21_e; assign pd_k21_e = pd_k21_ewide[15:0];
  logic [1:0] pd_k21_special; assign pd_k21_special = pd_k21_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k21_y; assign pd_k21_y = {pd_k21_special, f_s, pd_k21_e, pd_k21_sig, 1'b0};
  logic [7:0] pd_k22_a; assign pd_k22_a = pd_a[29:22];
  logic [7:0] pd_k22_b; assign pd_k22_b = pd_b[29:22];
  logic pd_k22_cin; assign pd_k22_cin = pd_a[22] ^ pd_b[22] ^ f_mag[22];
  logic [7:0] pd_k22_s0;
  logic [7:0] pd_k22_s1;
  logic [7:0] pd_k22_s2;
  logic pd_k22_cout;
  logic pd_k22_cout2;
  // post-normalization compound CPA at rounding cut 22
  fam_prefix_kogge_stone_w8_flag_dual u56 (.a(pd_k22_a), .b(pd_k22_b), .cin(1'b0), .s(pd_k22_s0), .cout(pd_k22_cout), .s1(pd_k22_s1));
  // cut 22: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u57 (.a(pd_k22_s1), .cin(1'b1), .s(pd_k22_s2), .cout(pd_k22_cout2));
  logic [7:0] pd_k22_down; assign pd_k22_down = pd_k22_cin ? pd_k22_s1 : pd_k22_s0;
  logic [7:0] pd_k22_up; assign pd_k22_up = pd_k22_cin ? pd_k22_s2 : pd_k22_s1;
  logic pd_k22_guard; assign pd_k22_guard = f_mag[21];
  logic pd_k22_sticky; assign pd_k22_sticky = |f_mag[20:0];
  logic pd_k22_inexact; assign pd_k22_inexact = pd_k22_guard | pd_k22_sticky;
  logic pd_k22_increment; assign pd_k22_increment = (rnd == 3'd0) ? (pd_k22_guard && (pd_k22_sticky || pd_k22_down[0])) : (rnd == 3'd2) ? (pd_k22_inexact && f_s) : (rnd == 3'd3) ? (pd_k22_inexact && !f_s) : (rnd == 3'd5) ? pd_k22_inexact : 1'b0;
  logic [7:0] pd_k22_keep; assign pd_k22_keep = pd_k22_increment ? pd_k22_up : pd_k22_down;
  logic pd_k22_carry; assign pd_k22_carry = pd_k22_increment && (&pd_k22_down[7:0]);
  logic [19:0] pd_k22_sig; assign pd_k22_sig = pd_k22_carry ? (20'd1 << 19) : {pd_k22_keep[7:0], 12'd0};
  logic signed [18:0] pd_k22_ewide; assign pd_k22_ewide = pd_exp + (pd_k22_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k22_e; assign pd_k22_e = pd_k22_ewide[15:0];
  logic [1:0] pd_k22_special; assign pd_k22_special = pd_k22_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k22_y; assign pd_k22_y = {pd_k22_special, f_s, pd_k22_e, pd_k22_sig, 1'b0};
  logic [7:0] pd_k23_a; assign pd_k23_a = pd_a[30:23];
  logic [7:0] pd_k23_b; assign pd_k23_b = pd_b[30:23];
  logic pd_k23_cin; assign pd_k23_cin = pd_a[23] ^ pd_b[23] ^ f_mag[23];
  logic [7:0] pd_k23_s0;
  logic [7:0] pd_k23_s1;
  logic [7:0] pd_k23_s2;
  logic pd_k23_cout;
  logic pd_k23_cout2;
  // post-normalization compound CPA at rounding cut 23
  fam_prefix_kogge_stone_w8_flag_dual u58 (.a(pd_k23_a), .b(pd_k23_b), .cin(1'b0), .s(pd_k23_s0), .cout(pd_k23_cout), .s1(pd_k23_s1));
  // cut 23: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u59 (.a(pd_k23_s1), .cin(1'b1), .s(pd_k23_s2), .cout(pd_k23_cout2));
  logic [7:0] pd_k23_down; assign pd_k23_down = pd_k23_cin ? pd_k23_s1 : pd_k23_s0;
  logic [7:0] pd_k23_up; assign pd_k23_up = pd_k23_cin ? pd_k23_s2 : pd_k23_s1;
  logic pd_k23_guard; assign pd_k23_guard = f_mag[22];
  logic pd_k23_sticky; assign pd_k23_sticky = |f_mag[21:0];
  logic pd_k23_inexact; assign pd_k23_inexact = pd_k23_guard | pd_k23_sticky;
  logic pd_k23_increment; assign pd_k23_increment = (rnd == 3'd0) ? (pd_k23_guard && (pd_k23_sticky || pd_k23_down[0])) : (rnd == 3'd2) ? (pd_k23_inexact && f_s) : (rnd == 3'd3) ? (pd_k23_inexact && !f_s) : (rnd == 3'd5) ? pd_k23_inexact : 1'b0;
  logic [7:0] pd_k23_keep; assign pd_k23_keep = pd_k23_increment ? pd_k23_up : pd_k23_down;
  logic pd_k23_carry; assign pd_k23_carry = pd_k23_increment && (&pd_k23_down[7:0]);
  logic [19:0] pd_k23_sig; assign pd_k23_sig = pd_k23_carry ? (20'd1 << 19) : {pd_k23_keep[7:0], 12'd0};
  logic signed [18:0] pd_k23_ewide; assign pd_k23_ewide = pd_exp + (pd_k23_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k23_e; assign pd_k23_e = pd_k23_ewide[15:0];
  logic [1:0] pd_k23_special; assign pd_k23_special = pd_k23_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k23_y; assign pd_k23_y = {pd_k23_special, f_s, pd_k23_e, pd_k23_sig, 1'b0};
  logic [7:0] pd_k24_a; assign pd_k24_a = pd_a[31:24];
  logic [7:0] pd_k24_b; assign pd_k24_b = pd_b[31:24];
  logic pd_k24_cin; assign pd_k24_cin = pd_a[24] ^ pd_b[24] ^ f_mag[24];
  logic [7:0] pd_k24_s0;
  logic [7:0] pd_k24_s1;
  logic [7:0] pd_k24_s2;
  logic pd_k24_cout;
  logic pd_k24_cout2;
  // post-normalization compound CPA at rounding cut 24
  fam_prefix_kogge_stone_w8_flag_dual u60 (.a(pd_k24_a), .b(pd_k24_b), .cin(1'b0), .s(pd_k24_s0), .cout(pd_k24_cout), .s1(pd_k24_s1));
  // cut 24: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u61 (.a(pd_k24_s1), .cin(1'b1), .s(pd_k24_s2), .cout(pd_k24_cout2));
  logic [7:0] pd_k24_down; assign pd_k24_down = pd_k24_cin ? pd_k24_s1 : pd_k24_s0;
  logic [7:0] pd_k24_up; assign pd_k24_up = pd_k24_cin ? pd_k24_s2 : pd_k24_s1;
  logic pd_k24_guard; assign pd_k24_guard = f_mag[23];
  logic pd_k24_sticky; assign pd_k24_sticky = |f_mag[22:0];
  logic pd_k24_inexact; assign pd_k24_inexact = pd_k24_guard | pd_k24_sticky;
  logic pd_k24_increment; assign pd_k24_increment = (rnd == 3'd0) ? (pd_k24_guard && (pd_k24_sticky || pd_k24_down[0])) : (rnd == 3'd2) ? (pd_k24_inexact && f_s) : (rnd == 3'd3) ? (pd_k24_inexact && !f_s) : (rnd == 3'd5) ? pd_k24_inexact : 1'b0;
  logic [7:0] pd_k24_keep; assign pd_k24_keep = pd_k24_increment ? pd_k24_up : pd_k24_down;
  logic pd_k24_carry; assign pd_k24_carry = pd_k24_increment && (&pd_k24_down[7:0]);
  logic [19:0] pd_k24_sig; assign pd_k24_sig = pd_k24_carry ? (20'd1 << 19) : {pd_k24_keep[7:0], 12'd0};
  logic signed [18:0] pd_k24_ewide; assign pd_k24_ewide = pd_exp + (pd_k24_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k24_e; assign pd_k24_e = pd_k24_ewide[15:0];
  logic [1:0] pd_k24_special; assign pd_k24_special = pd_k24_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k24_y; assign pd_k24_y = {pd_k24_special, f_s, pd_k24_e, pd_k24_sig, 1'b0};
  logic [7:0] pd_k25_a; assign pd_k25_a = pd_a[32:25];
  logic [7:0] pd_k25_b; assign pd_k25_b = pd_b[32:25];
  logic pd_k25_cin; assign pd_k25_cin = pd_a[25] ^ pd_b[25] ^ f_mag[25];
  logic [7:0] pd_k25_s0;
  logic [7:0] pd_k25_s1;
  logic [7:0] pd_k25_s2;
  logic pd_k25_cout;
  logic pd_k25_cout2;
  // post-normalization compound CPA at rounding cut 25
  fam_prefix_kogge_stone_w8_flag_dual u62 (.a(pd_k25_a), .b(pd_k25_b), .cin(1'b0), .s(pd_k25_s0), .cout(pd_k25_cout), .s1(pd_k25_s1));
  // cut 25: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u63 (.a(pd_k25_s1), .cin(1'b1), .s(pd_k25_s2), .cout(pd_k25_cout2));
  logic [7:0] pd_k25_down; assign pd_k25_down = pd_k25_cin ? pd_k25_s1 : pd_k25_s0;
  logic [7:0] pd_k25_up; assign pd_k25_up = pd_k25_cin ? pd_k25_s2 : pd_k25_s1;
  logic pd_k25_guard; assign pd_k25_guard = f_mag[24];
  logic pd_k25_sticky; assign pd_k25_sticky = |f_mag[23:0];
  logic pd_k25_inexact; assign pd_k25_inexact = pd_k25_guard | pd_k25_sticky;
  logic pd_k25_increment; assign pd_k25_increment = (rnd == 3'd0) ? (pd_k25_guard && (pd_k25_sticky || pd_k25_down[0])) : (rnd == 3'd2) ? (pd_k25_inexact && f_s) : (rnd == 3'd3) ? (pd_k25_inexact && !f_s) : (rnd == 3'd5) ? pd_k25_inexact : 1'b0;
  logic [7:0] pd_k25_keep; assign pd_k25_keep = pd_k25_increment ? pd_k25_up : pd_k25_down;
  logic pd_k25_carry; assign pd_k25_carry = pd_k25_increment && (&pd_k25_down[7:0]);
  logic [19:0] pd_k25_sig; assign pd_k25_sig = pd_k25_carry ? (20'd1 << 19) : {pd_k25_keep[7:0], 12'd0};
  logic signed [18:0] pd_k25_ewide; assign pd_k25_ewide = pd_exp + (pd_k25_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k25_e; assign pd_k25_e = pd_k25_ewide[15:0];
  logic [1:0] pd_k25_special; assign pd_k25_special = pd_k25_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k25_y; assign pd_k25_y = {pd_k25_special, f_s, pd_k25_e, pd_k25_sig, 1'b0};
  logic [7:0] pd_k26_a; assign pd_k26_a = pd_a[33:26];
  logic [7:0] pd_k26_b; assign pd_k26_b = pd_b[33:26];
  logic pd_k26_cin; assign pd_k26_cin = pd_a[26] ^ pd_b[26] ^ f_mag[26];
  logic [7:0] pd_k26_s0;
  logic [7:0] pd_k26_s1;
  logic [7:0] pd_k26_s2;
  logic pd_k26_cout;
  logic pd_k26_cout2;
  // post-normalization compound CPA at rounding cut 26
  fam_prefix_kogge_stone_w8_flag_dual u64 (.a(pd_k26_a), .b(pd_k26_b), .cin(1'b0), .s(pd_k26_s0), .cout(pd_k26_cout), .s1(pd_k26_s1));
  // cut 26: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u65 (.a(pd_k26_s1), .cin(1'b1), .s(pd_k26_s2), .cout(pd_k26_cout2));
  logic [7:0] pd_k26_down; assign pd_k26_down = pd_k26_cin ? pd_k26_s1 : pd_k26_s0;
  logic [7:0] pd_k26_up; assign pd_k26_up = pd_k26_cin ? pd_k26_s2 : pd_k26_s1;
  logic pd_k26_guard; assign pd_k26_guard = f_mag[25];
  logic pd_k26_sticky; assign pd_k26_sticky = |f_mag[24:0];
  logic pd_k26_inexact; assign pd_k26_inexact = pd_k26_guard | pd_k26_sticky;
  logic pd_k26_increment; assign pd_k26_increment = (rnd == 3'd0) ? (pd_k26_guard && (pd_k26_sticky || pd_k26_down[0])) : (rnd == 3'd2) ? (pd_k26_inexact && f_s) : (rnd == 3'd3) ? (pd_k26_inexact && !f_s) : (rnd == 3'd5) ? pd_k26_inexact : 1'b0;
  logic [7:0] pd_k26_keep; assign pd_k26_keep = pd_k26_increment ? pd_k26_up : pd_k26_down;
  logic pd_k26_carry; assign pd_k26_carry = pd_k26_increment && (&pd_k26_down[7:0]);
  logic [19:0] pd_k26_sig; assign pd_k26_sig = pd_k26_carry ? (20'd1 << 19) : {pd_k26_keep[7:0], 12'd0};
  logic signed [18:0] pd_k26_ewide; assign pd_k26_ewide = pd_exp + (pd_k26_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k26_e; assign pd_k26_e = pd_k26_ewide[15:0];
  logic [1:0] pd_k26_special; assign pd_k26_special = pd_k26_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k26_y; assign pd_k26_y = {pd_k26_special, f_s, pd_k26_e, pd_k26_sig, 1'b0};
  logic [7:0] pd_k27_a; assign pd_k27_a = pd_a[34:27];
  logic [7:0] pd_k27_b; assign pd_k27_b = pd_b[34:27];
  logic pd_k27_cin; assign pd_k27_cin = pd_a[27] ^ pd_b[27] ^ f_mag[27];
  logic [7:0] pd_k27_s0;
  logic [7:0] pd_k27_s1;
  logic [7:0] pd_k27_s2;
  logic pd_k27_cout;
  logic pd_k27_cout2;
  // post-normalization compound CPA at rounding cut 27
  fam_prefix_kogge_stone_w8_flag_dual u66 (.a(pd_k27_a), .b(pd_k27_b), .cin(1'b0), .s(pd_k27_s0), .cout(pd_k27_cout), .s1(pd_k27_s1));
  // cut 27: candidate for simultaneous low carry and rounding increment
  fam_incr_prefix_and #(.W(8), .STRUCTURE(1), .B(4), .TOPO(0)) u67 (.a(pd_k27_s1), .cin(1'b1), .s(pd_k27_s2), .cout(pd_k27_cout2));
  logic [7:0] pd_k27_down; assign pd_k27_down = pd_k27_cin ? pd_k27_s1 : pd_k27_s0;
  logic [7:0] pd_k27_up; assign pd_k27_up = pd_k27_cin ? pd_k27_s2 : pd_k27_s1;
  logic pd_k27_guard; assign pd_k27_guard = f_mag[26];
  logic pd_k27_sticky; assign pd_k27_sticky = |f_mag[25:0];
  logic pd_k27_inexact; assign pd_k27_inexact = pd_k27_guard | pd_k27_sticky;
  logic pd_k27_increment; assign pd_k27_increment = (rnd == 3'd0) ? (pd_k27_guard && (pd_k27_sticky || pd_k27_down[0])) : (rnd == 3'd2) ? (pd_k27_inexact && f_s) : (rnd == 3'd3) ? (pd_k27_inexact && !f_s) : (rnd == 3'd5) ? pd_k27_inexact : 1'b0;
  logic [7:0] pd_k27_keep; assign pd_k27_keep = pd_k27_increment ? pd_k27_up : pd_k27_down;
  logic pd_k27_carry; assign pd_k27_carry = pd_k27_increment && (&pd_k27_down[7:0]);
  logic [19:0] pd_k27_sig; assign pd_k27_sig = pd_k27_carry ? (20'd1 << 19) : {pd_k27_keep[7:0], 12'd0};
  logic signed [18:0] pd_k27_ewide; assign pd_k27_ewide = pd_exp + (pd_k27_carry ? 19'sd1 : 19'sd0);
  logic signed [15:0] pd_k27_e; assign pd_k27_e = pd_k27_ewide[15:0];
  logic [1:0] pd_k27_special; assign pd_k27_special = pd_k27_inexact ? 2'd3 : 2'd0;
  logic [39:0] pd_k27_y; assign pd_k27_y = {pd_k27_special, f_s, pd_k27_e, pd_k27_sig, 1'b0};
  logic pd_increment; assign pd_increment = (pd_cut == 7'd2) ? pd_k2_increment : (pd_cut == 7'd3) ? pd_k3_increment : (pd_cut == 7'd4) ? pd_k4_increment : (pd_cut == 7'd5) ? pd_k5_increment : (pd_cut == 7'd6) ? pd_k6_increment : (pd_cut == 7'd7) ? pd_k7_increment : (pd_cut == 7'd8) ? pd_k8_increment : (pd_cut == 7'd9) ? pd_k9_increment : (pd_cut == 7'd10) ? pd_k10_increment : (pd_cut == 7'd11) ? pd_k11_increment : (pd_cut == 7'd12) ? pd_k12_increment : (pd_cut == 7'd13) ? pd_k13_increment : (pd_cut == 7'd14) ? pd_k14_increment : (pd_cut == 7'd15) ? pd_k15_increment : (pd_cut == 7'd16) ? pd_k16_increment : (pd_cut == 7'd17) ? pd_k17_increment : (pd_cut == 7'd18) ? pd_k18_increment : (pd_cut == 7'd19) ? pd_k19_increment : (pd_cut == 7'd20) ? pd_k20_increment : (pd_cut == 7'd21) ? pd_k21_increment : (pd_cut == 7'd22) ? pd_k22_increment : (pd_cut == 7'd23) ? pd_k23_increment : (pd_cut == 7'd24) ? pd_k24_increment : (pd_cut == 7'd25) ? pd_k25_increment : (pd_cut == 7'd26) ? pd_k26_increment : (pd_cut == 7'd27) ? pd_k27_increment : 1'b0;
  logic pd_carry; assign pd_carry = (pd_cut == 7'd2) ? pd_k2_carry : (pd_cut == 7'd3) ? pd_k3_carry : (pd_cut == 7'd4) ? pd_k4_carry : (pd_cut == 7'd5) ? pd_k5_carry : (pd_cut == 7'd6) ? pd_k6_carry : (pd_cut == 7'd7) ? pd_k7_carry : (pd_cut == 7'd8) ? pd_k8_carry : (pd_cut == 7'd9) ? pd_k9_carry : (pd_cut == 7'd10) ? pd_k10_carry : (pd_cut == 7'd11) ? pd_k11_carry : (pd_cut == 7'd12) ? pd_k12_carry : (pd_cut == 7'd13) ? pd_k13_carry : (pd_cut == 7'd14) ? pd_k14_carry : (pd_cut == 7'd15) ? pd_k15_carry : (pd_cut == 7'd16) ? pd_k16_carry : (pd_cut == 7'd17) ? pd_k17_carry : (pd_cut == 7'd18) ? pd_k18_carry : (pd_cut == 7'd19) ? pd_k19_carry : (pd_cut == 7'd20) ? pd_k20_carry : (pd_cut == 7'd21) ? pd_k21_carry : (pd_cut == 7'd22) ? pd_k22_carry : (pd_cut == 7'd23) ? pd_k23_carry : (pd_cut == 7'd24) ? pd_k24_carry : (pd_cut == 7'd25) ? pd_k25_carry : (pd_cut == 7'd26) ? pd_k26_carry : (pd_cut == 7'd27) ? pd_k27_carry : 1'b0;
  logic pd_low_carry; assign pd_low_carry = (pd_cut == 7'd2) ? pd_k2_cin : (pd_cut == 7'd3) ? pd_k3_cin : (pd_cut == 7'd4) ? pd_k4_cin : (pd_cut == 7'd5) ? pd_k5_cin : (pd_cut == 7'd6) ? pd_k6_cin : (pd_cut == 7'd7) ? pd_k7_cin : (pd_cut == 7'd8) ? pd_k8_cin : (pd_cut == 7'd9) ? pd_k9_cin : (pd_cut == 7'd10) ? pd_k10_cin : (pd_cut == 7'd11) ? pd_k11_cin : (pd_cut == 7'd12) ? pd_k12_cin : (pd_cut == 7'd13) ? pd_k13_cin : (pd_cut == 7'd14) ? pd_k14_cin : (pd_cut == 7'd15) ? pd_k15_cin : (pd_cut == 7'd16) ? pd_k16_cin : (pd_cut == 7'd17) ? pd_k17_cin : (pd_cut == 7'd18) ? pd_k18_cin : (pd_cut == 7'd19) ? pd_k19_cin : (pd_cut == 7'd20) ? pd_k20_cin : (pd_cut == 7'd21) ? pd_k21_cin : (pd_cut == 7'd22) ? pd_k22_cin : (pd_cut == 7'd23) ? pd_k23_cin : (pd_cut == 7'd24) ? pd_k24_cin : (pd_cut == 7'd25) ? pd_k25_cin : (pd_cut == 7'd26) ? pd_k26_cin : (pd_cut == 7'd27) ? pd_k27_cin : 1'b0;
  logic [39:0] pd_candidate; assign pd_candidate = (pd_cut == 7'd2) ? pd_k2_y : (pd_cut == 7'd3) ? pd_k3_y : (pd_cut == 7'd4) ? pd_k4_y : (pd_cut == 7'd5) ? pd_k5_y : (pd_cut == 7'd6) ? pd_k6_y : (pd_cut == 7'd7) ? pd_k7_y : (pd_cut == 7'd8) ? pd_k8_y : (pd_cut == 7'd9) ? pd_k9_y : (pd_cut == 7'd10) ? pd_k10_y : (pd_cut == 7'd11) ? pd_k11_y : (pd_cut == 7'd12) ? pd_k12_y : (pd_cut == 7'd13) ? pd_k13_y : (pd_cut == 7'd14) ? pd_k14_y : (pd_cut == 7'd15) ? pd_k15_y : (pd_cut == 7'd16) ? pd_k16_y : (pd_cut == 7'd17) ? pd_k17_y : (pd_cut == 7'd18) ? pd_k18_y : (pd_cut == 7'd19) ? pd_k19_y : (pd_cut == 7'd20) ? pd_k20_y : (pd_cut == 7'd21) ? pd_k21_y : (pd_cut == 7'd22) ? pd_k22_y : (pd_cut == 7'd23) ? pd_k23_y : (pd_cut == 7'd24) ? pd_k24_y : (pd_cut == 7'd25) ? pd_k25_y : (pd_cut == 7'd26) ? pd_k26_y : (pd_cut == 7'd27) ? pd_k27_y : y_fx;
  logic [39:0] y_pd; assign y_pd = pd_eligible ? pd_candidate : y_fx;
  assign y = y_pd;
endmodule

// fp fused multiply-add (reduced_latency_fma): the mode's adder, its multiplier and the fused ops fmadd, fmsub, fnmsub, fnmadd through one datapath fam_fp_fma_core_reduced_latency_fma_x20e16s8_bf16_p6f6a2e63b089 under the op code fop (0 fadd, 1 fsub, 2 fmul, 3 fmadd, 4 fmsub, 5 fnmsub, 6 fnmadd): fadd is 1 * xa + xb, fmul is xa * xb + (a zero of the product's sign), a fused op negates xa for the negated product and xc for the negated addend; the window sum's negation by complement_recode; the rounding for bf16 fused into the window adder's compound sum (a normal result leaves rounded, with the ROUNDED code; a subnormal, an overflow and the stochastic mode leave unrounded); the significand multiplier booth_recoded_parallel; the specials as the engine orders them for each op
module fam_fp_fma_reduced_latency_fma_x20e16s8_p3ef0d7160561 (
  input logic [39:0] xa,
  input logic [39:0] xb,
  input logic [39:0] xc,
  input logic [2:0] fop,
  input logic [2:0] rnd,
  output logic [39:0] y
);
  logic [1:0] a_sp; assign a_sp = xa[39:38];
  logic a_s; assign a_s = xa[37];
  logic signed [15:0] a_e; assign a_e = $signed(xa[36:21]);
  logic [19:0] a_sig; assign a_sig = xa[20:1];
  logic a_st; assign a_st = xa[0];
  logic a_z; assign a_z = (a_sp == 2'd0) && (a_sig == 0) && !a_st;
  logic [1:0] b_sp; assign b_sp = xb[39:38];
  logic b_s; assign b_s = xb[37];
  logic signed [15:0] b_e; assign b_e = $signed(xb[36:21]);
  logic [19:0] b_sig; assign b_sig = xb[20:1];
  logic b_st; assign b_st = xb[0];
  logic b_z; assign b_z = (b_sp == 2'd0) && (b_sig == 0) && !b_st;
  logic is_add; assign is_add = fop[2:1] == 2'b00;
  logic is_mul; assign is_mul = fop == 3'd2;
  logic neg_p; assign neg_p = (fop == 3'd5) || (fop == 3'd6);
  logic neg_c; assign neg_c = (fop == 3'd1) || (fop == 3'd4) || (fop == 3'd6);
  logic [39:0] xan; assign xan = {xa[39:38], xa[37] ^ neg_p, xa[36:0]};
  logic [39:0] addend; assign addend = is_add ? xb : xc;
  logic [39:0] xcn; assign xcn = {addend[39:38], addend[37] ^ neg_c, addend[36:0]};
  logic ps; assign ps = a_s ^ b_s;
  logic [39:0] fa; assign fa = is_add ? {2'd0, 1'b0, -16'sd7, 20'd128, 1'b0} : xan;
  logic [39:0] fb; assign fb = is_add ? xa : xb;
  logic [39:0] fc; assign fc = is_mul ? {2'd0, ps, 16'sd0, 20'd0, 1'b0} : xcn;
  logic [39:0] yf;
  // the fused datapath: fc + fa * fb
  fam_fp_fma_core_reduced_latency_fma_x20e16s8_bf16_p6f6a2e63b089 u_fma (.xa(fa), .xb(fb), .xc(fc), .rnd(rnd), .y(yf));
  logic [1:0] fa_sp; assign fa_sp = fa[39:38];
  logic fa_s; assign fa_s = fa[37];
  logic signed [15:0] fa_e; assign fa_e = $signed(fa[36:21]);
  logic [19:0] fa_sig; assign fa_sig = fa[20:1];
  logic fa_st; assign fa_st = fa[0];
  logic fa_z; assign fa_z = (fa_sp == 2'd0) && (fa_sig == 0) && !fa_st;
  logic [1:0] fb_sp; assign fb_sp = fb[39:38];
  logic fb_s; assign fb_s = fb[37];
  logic signed [15:0] fb_e; assign fb_e = $signed(fb[36:21]);
  logic [19:0] fb_sig; assign fb_sig = fb[20:1];
  logic fb_st; assign fb_st = fb[0];
  logic fb_z; assign fb_z = (fb_sp == 2'd0) && (fb_sig == 0) && !fb_st;
  logic [1:0] fc_sp; assign fc_sp = fc[39:38];
  logic fc_s; assign fc_s = fc[37];
  logic signed [15:0] fc_e; assign fc_e = $signed(fc[36:21]);
  logic [19:0] fc_sig; assign fc_sig = fc[20:1];
  logic fc_st; assign fc_st = fc[0];
  logic fc_z; assign fc_z = (fc_sp == 2'd0) && (fc_sig == 0) && !fc_st;
  logic p_nan; assign p_nan = (fa_sp == 2'd1) || (fb_sp == 2'd1);
  logic p_inf; assign p_inf = (fa_sp == 2'd2) || (fb_sp == 2'd2);
  logic p_inv; assign p_inv = p_inf && ((fa_sp == 2'd0 && fa_z) || (fb_sp == 2'd0 && fb_z));
  logic fps; assign fps = fa_s ^ fb_s;
  logic c_nan; assign c_nan = fc_sp == 2'd1;
  logic c_inf; assign c_inf = fc_sp == 2'd2;
  logic [39:0] y_sp; assign y_sp = (p_nan || c_nan || p_inv) ? {2'd1, 1'b0, 16'sd0, 20'd0, 1'b0} : (p_inf && c_inf && (fps != fc_s)) ? {2'd1, 1'b0, 16'sd0, 20'd0, 1'b0} : p_inf ? {2'd2, fps, 16'sd0, 20'd0, 1'b0} : c_inf ? {2'd2, fc_s, 16'sd0, 20'd0, 1'b0} : yf;
  assign y = y_sp;
endmodule

// fp significand multiplier (sig_mul_then_round): segmented_grid over the 3-bit significands, the exact product in the X field, the exponent sum on a manchester_carry_chain adder
module fam_fp_mul_sig_mul_then_round_x10e13s3_padd344eaa93c (
  input logic [26:0] xa,
  input logic [26:0] xb,
  output logic [26:0] y
);
  logic [1:0] a_sp; assign a_sp = xa[26:25];
  logic a_s; assign a_s = xa[24];
  logic signed [12:0] a_e; assign a_e = $signed(xa[23:11]);
  logic [9:0] a_sig; assign a_sig = xa[10:1];
  logic a_st; assign a_st = xa[0];
  logic a_z; assign a_z = (a_sp == 2'd0) && (a_sig == 0) && !a_st;
  logic [1:0] b_sp; assign b_sp = xb[26:25];
  logic b_s; assign b_s = xb[24];
  logic signed [12:0] b_e; assign b_e = $signed(xb[23:11]);
  logic [9:0] b_sig; assign b_sig = xb[10:1];
  logic b_st; assign b_st = xb[0];
  logic b_z; assign b_z = (b_sp == 2'd0) && (b_sig == 0) && !b_st;
  logic s; assign s = a_s ^ b_s;
  logic [2:0] sa; assign sa = a_sig[2:0];
  logic [2:0] sb; assign sb = b_sig[2:0];
  logic [5:0] p;
  // the significand product (segmented_grid)
  fam_mul_segmented_grid_w3_u_pf3c3f225 u1 (.a(sa), .b(sb), .p(p));
  logic signed [12:0] e;
  // the exponent sum
  fam_adder_manchester_carry_chain #(.W(13), .SEG(4), .VARSKIP(0)) u2 (.a(a_e), .b(b_e), .cin(1'b0), .s(e), .cout());
  logic st; assign st = a_st | b_st;
  logic [26:0] y_fin; assign y_fin = {2'd0, s, e, {{(10-6){1'b0}}, p}, st};
  logic [26:0] y_sp; assign y_sp = (a_sp == 2'd1 || b_sp == 2'd1) ? {2'd1, 1'b0, 13'sd0, 10'd0, 1'b0} : (a_sp == 2'd2 || b_sp == 2'd2) ? (((a_sp == 2'd0 && a_z) || (b_sp == 2'd0 && b_z)) ? {2'd1, 1'b0, 13'sd0, 10'd0, 1'b0} : {2'd2, s, 13'sd0, 10'd0, 1'b0}) : y_fin;
  assign y = y_sp;
endmodule

// fp significand multiplier (sig_mul_then_round): direct_pp_parallel over the 11-bit significands, the exact product in the X field, the exponent sum on a ling_prefix adder
module fam_fp_mul_sig_mul_then_round_x26e13s11_pd2d07246771c (
  input logic [42:0] xa,
  input logic [42:0] xb,
  output logic [42:0] y
);
  logic [1:0] a_sp; assign a_sp = xa[42:41];
  logic a_s; assign a_s = xa[40];
  logic signed [12:0] a_e; assign a_e = $signed(xa[39:27]);
  logic [25:0] a_sig; assign a_sig = xa[26:1];
  logic a_st; assign a_st = xa[0];
  logic a_z; assign a_z = (a_sp == 2'd0) && (a_sig == 0) && !a_st;
  logic [1:0] b_sp; assign b_sp = xb[42:41];
  logic b_s; assign b_s = xb[40];
  logic signed [12:0] b_e; assign b_e = $signed(xb[39:27]);
  logic [25:0] b_sig; assign b_sig = xb[26:1];
  logic b_st; assign b_st = xb[0];
  logic b_z; assign b_z = (b_sp == 2'd0) && (b_sig == 0) && !b_st;
  logic s; assign s = a_s ^ b_s;
  logic [10:0] sa; assign sa = a_sig[10:0];
  logic [10:0] sb; assign sb = b_sig[10:0];
  logic [21:0] p;
  // the significand product (direct_pp_parallel)
  fam_mul_direct_dadda_3_2_w11_u_pf6dd732b u1 (.a(sa), .b(sb), .p(p));
  logic signed [12:0] e;
  // the exponent sum
  fam_prefix_han_carlson_w13_ling3_sel u2 (.a(a_e), .b(b_e), .cin(1'b0), .s(e), .cout());
  logic st; assign st = a_st | b_st;
  logic [42:0] y_fin; assign y_fin = {2'd0, s, e, {{(26-22){1'b0}}, p}, st};
  logic [42:0] y_sp; assign y_sp = (a_sp == 2'd1 || b_sp == 2'd1) ? {2'd1, 1'b0, 13'sd0, 26'd0, 1'b0} : (a_sp == 2'd2 || b_sp == 2'd2) ? (((a_sp == 2'd0 && a_z) || (b_sp == 2'd0 && b_z)) ? {2'd1, 1'b0, 13'sd0, 26'd0, 1'b0} : {2'd2, s, 13'sd0, 26'd0, 1'b0}) : y_fin;
  assign y = y_sp;
endmodule

// fp rounder (dedicated_per_op, rounding compound_adder_select, leading zeros lzd_cell_tree, shifts masked_merged, exponent sparse_prefix_hybrid / prefix_and_incrementer): X -> bf16 pattern and flags
module fam_fp_round_dedicated_per_op_compound_adder_select_bf16_x20e16s8_p925d37aacdb3 (
  input logic [39:0] x,
  input logic [2:0] rnd,
  input logic [7:0] word,
  input logic ftz,
  output logic [9:0] fl,
  output logic [15:0] bits
);
  logic [1:0] x_sp; assign x_sp = x[39:38];
  logic x_s; assign x_s = x[37];
  logic signed [15:0] x_e; assign x_e = $signed(x[36:21]);
  logic [19:0] x_sig; assign x_sig = x[20:1];
  logic x_st; assign x_st = x[0];
  logic x_z; assign x_z = (x_sp == 2'd0) && (x_sig == 0) && !x_st;
  logic s; assign s = x_s & 1'd1;
  logic lone; assign lone = (x_sig == 0) && x_st;
  logic [19:0] sig_in; assign sig_in = lone ? 20'd1 : x_sig;
  logic signed [15:0] e_lone_c; assign e_lone_c = -16'sd20;
  logic signed [15:0] e_lone;
  // the exponent of a lone sticky's unit
  fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w16 u1 (.a(x_e), .b(e_lone_c), .cin(1'b0), .s(e_lone), .cout());
  logic signed [15:0] e_in; assign e_in = lone ? e_lone : x_e;
  logic [4:0] lz;
  // the normalizer's leading-zero count
  fam_count_lzd_nibble_cell_binary_count_vflat_w20 u2 (.a(sig_in), .n(lz));
  logic [4:0] lzs; assign lzs = (sig_in == 0) ? 5'd0 : lz[4:0];
  logic [19:0] sig;
  // the normalizer's left shift
  fam_shift_masked_merged #(.W(20), .MASKGEN(0), .MERGE(1), .R_RADIX_LOG2(0), .R_ONE_HOT(0), .R_ORDER(0), .STICKY(0)) u3 (.a(sig_in), .amt(lzs), .op(3'd0), .y(sig), .sticky());
  logic signed [15:0] lzx; assign lzx = $signed({{(16-5){1'b0}}, lzs});
  logic [15:0] e_nb; assign e_nb = ~(lzx);
  logic signed [15:0] e;
  // the exponent lowered by the normalize count
  fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w16 u4 (.a(e_in), .b(e_nb), .cin(1'b1), .s(e), .cout());
  logic normal; assign normal = e >= -16'sd145;
  logic signed [16:0] shc; assign shc = -17'sd133;
  logic signed [16:0] ex; assign ex = $signed({e[15], e});
  logic [16:0] shsub_nb; assign shsub_nb = ~(ex);
  logic signed [16:0] shsub;
  // the subnormal result's extra right shift
  fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w17 u5 (.a(shc), .b(shsub_nb), .cin(1'b1), .s(shsub), .cout());
  logic signed [16:0] sht; assign sht = normal ? 17'sd12 : shsub;
  logic signed [16:0] sh; assign sh = (sht > 17'sd21) ? 17'sd21 : sht;
  logic [4:0] sha; assign sha = sh[4:0];
  logic [20:0] sigw; assign sigw = {1'b0, sig};
  logic [4:0] shk; assign shk = (sh > 17'sd20) ? 5'd20 : sha;
  logic [20:0] keep;
  // the right shift to the kept bits
  fam_shift_masked_merged #(.W(21), .MASKGEN(0), .MERGE(1), .R_RADIX_LOG2(0), .R_ONE_HOT(0), .R_ORDER(0), .STICKY(0)) u6 (.a(sigw), .amt(shk), .op(3'd1), .y(keep), .sticky());
  // the mask of the dropped positions
  logic [20:0] restmask;
  assign restmask[0] = (sha > 0);
  assign restmask[1] = (sha > 1);
  assign restmask[2] = (sha > 2);
  assign restmask[3] = (sha > 3);
  assign restmask[4] = (sha > 4);
  assign restmask[5] = (sha > 5);
  assign restmask[6] = (sha > 6);
  assign restmask[7] = (sha > 7);
  assign restmask[8] = (sha > 8);
  assign restmask[9] = (sha > 9);
  assign restmask[10] = (sha > 10);
  assign restmask[11] = (sha > 11);
  assign restmask[12] = (sha > 12);
  assign restmask[13] = (sha > 13);
  assign restmask[14] = (sha > 14);
  assign restmask[15] = (sha > 15);
  assign restmask[16] = (sha > 16);
  assign restmask[17] = (sha > 17);
  assign restmask[18] = (sha > 18);
  assign restmask[19] = (sha > 19);
  assign restmask[20] = (sha > 20);
  logic [20:0] rest; assign rest = sigw & restmask;
  // the half position (one below the kept lsb)
  logic [20:0] halfv;
  assign halfv[0] = (sha == 1);
  assign halfv[1] = (sha == 2);
  assign halfv[2] = (sha == 3);
  assign halfv[3] = (sha == 4);
  assign halfv[4] = (sha == 5);
  assign halfv[5] = (sha == 6);
  assign halfv[6] = (sha == 7);
  assign halfv[7] = (sha == 8);
  assign halfv[8] = (sha == 9);
  assign halfv[9] = (sha == 10);
  assign halfv[10] = (sha == 11);
  assign halfv[11] = (sha == 12);
  assign halfv[12] = (sha == 13);
  assign halfv[13] = (sha == 14);
  assign halfv[14] = (sha == 15);
  assign halfv[15] = (sha == 16);
  assign halfv[16] = (sha == 17);
  assign halfv[17] = (sha == 18);
  assign halfv[18] = (sha == 19);
  assign halfv[19] = (sha == 20);
  assign halfv[20] = (sha == 21);
  logic [20:0] keepn; assign keepn = sigw >> 12;
  logic [20:0] restn; assign restn = sigw & ({1'b0, {20{1'b1}}} >> 8);
  logic [20:0] halfn; assign halfn = {20'd0, 1'b1} << 11;
  logic inexact; assign inexact = (rest != 0) | x_st;
  logic [28:0] restw; assign restw = {rest, 8'd0};
  logic [4:0] fsh; assign fsh = sht[4:0];
  logic [28:0] fint0;
  // the dropped bits aligned to the stochastic word
  fam_shift_masked_merged #(.W(29), .MASKGEN(0), .MERGE(1), .R_RADIX_LOG2(0), .R_ONE_HOT(0), .R_ORDER(0), .STICKY(0)) u7 (.a(restw), .amt(fsh), .op(3'd1), .y(fint0), .sticky());
  logic [28:0] fint; assign fint = (sht > 17'sd28) ? 29'd0 : fint0;
  logic [28:0] fintn; assign fintn = restn >> 4;
  logic gt_half; assign gt_half = rest > halfv;
  logic half_eq; assign half_eq = (rest == halfv) && (halfv != 0);
  logic up; assign up = (rnd == 3'd0) ? (gt_half || (half_eq && (x_st || keep[0]))) : (rnd == 3'd1) ? 1'b0 : (rnd == 3'd2) ? (inexact && s) : (rnd == 3'd3) ? (inexact && !s) : (rnd == 3'd4) ? (inexact && (0 ? (fint >= word) : (fint > word))) : inexact;
  logic gt_halfn; assign gt_halfn = restn > halfn;
  logic half_eqn; assign half_eqn = (restn == halfn) && (halfn != 0);
  logic upn; assign upn = (rnd == 3'd0) ? (gt_halfn || (half_eqn && (x_st || keepn[0]))) : (rnd == 3'd1) ? 1'b0 : (rnd == 3'd2) ? (((restn != 0) | x_st) && s) : (rnd == 3'd3) ? (((restn != 0) | x_st) && !s) : (rnd == 3'd4) ? (((restn != 0) | x_st) && (0 ? (fintn >= word) : (fintn > word))) : ((restn != 0) | x_st);
  logic rounded; assign rounded = x_sp == 2'd3;
  logic upr; assign upr = rounded ? 1'b0 : up;
  logic inexact_r; assign inexact_r = rounded | inexact;
  logic carry_n; assign carry_n = upn && (&keepn[7:0]);
  logic [20:0] mag;
  logic [20:0] k1;
  // the kept bits plus one, in parallel with the decision (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(21), .STRUCTURE(2), .B(4), .TOPO(0)) u8 (.a(keep), .cin(1'b1), .s(k1), .cout());
  assign mag = upr ? k1 : keep;
  logic signed [15:0] bfield_c; assign bfield_c = 16'sd146;
  logic signed [15:0] bfield;
  // the biased exponent field
  fam_adder_sparse_prefix_hybrid_p1a8a0c26ad5b7feb19d3442ad404bb606989da7d1fa5fd3634f926263cc18510_w16 u9 (.a(e), .b(bfield_c), .cin(1'b0), .s(bfield), .cout());
  logic [15:0] bfu; assign bfu = bfield;
  logic [15:0] efield;
  // the exponent field incremented on a rounding carry (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(16), .STRUCTURE(1), .B(4), .TOPO(1)) u10 (.a(bfu), .cin(mag[8]), .s(efield), .cout());
  logic [32:0] code; assign code = normal ? {{(33-16-7){1'b0}}, efield, mag[6:0]} : {{(33-21){1'b0}}, mag};
  logic tiny; assign tiny = (e < -16'sd145) && !(e == -16'sd146 && carry_n) && !(e == -16'sd146 && carry_n);
  logic ovf; assign ovf = code > 33'd32639;
  logic to_inf; assign to_inf = 1 && (rnd == 3'd0 || (rnd == 3'd3 && !s) || (rnd == 3'd2 && s) || rnd == 3'd5 || (rnd == 3'd4 && (e > 16'sd108 || up)));
  logic ftz_hit; assign ftz_hit = ftz && code[14:7] == 0 && (code[6:0] != 0);
  logic is_zero; assign is_zero = (x_sig == 0) && (!x_st || rounded);
  logic tiny_r; assign tiny_r = rounded ? x_st : tiny;
  logic [9:0] fl_fin; assign fl_fin = ovf ? ((1 << 2) | (1 << 4)) : ((inexact_r ? (1 << 4) : 0) | ((tiny_r && inexact_r) ? (1 << 3) : 0) | (ftz_hit ? ((1 << 4) | (1 << 3)) : 0));
  logic [15:0] bits_fin; assign bits_fin = ovf ? (to_inf ? {s, 15'd32640} : {s, 15'd32639}) : (ftz_hit ? {s, 15'd0} : {s, code[14:0]});
  logic [9:0] fl_zero; assign fl_zero = rounded ? ((1 << 4) | (1 << 3)) : 10'd0;
  assign fl = (x_sp == 2'd1) ? (1 << 5) : (x_sp == 2'd2) ? 0 : is_zero ? fl_zero : fl_fin;
  assign bits = (x_sp == 2'd1) ? 16'd32704 : (x_sp == 2'd2) ? {s, 15'd32640} : is_zero ? (rounded ? {s, 15'd0} : 16'd0) : bits_fin;
endmodule

// fp rounder (dedicated_per_op, rounding increment_adder, leading zeros priority_encoder, shifts butterfly_network, exponent end_around_carry / prefix_and_incrementer): X -> fp8e5m2 pattern and flags
module fam_fp_round_dedicated_per_op_increment_adder_fp8e5m2_x10e13s3_p9d3fabee2f30 (
  input logic [26:0] x,
  input logic [2:0] rnd,
  input logic [7:0] word,
  input logic ftz,
  output logic [9:0] fl,
  output logic [7:0] bits
);
  logic [1:0] x_sp; assign x_sp = x[26:25];
  logic x_s; assign x_s = x[24];
  logic signed [12:0] x_e; assign x_e = $signed(x[23:11]);
  logic [9:0] x_sig; assign x_sig = x[10:1];
  logic x_st; assign x_st = x[0];
  logic x_z; assign x_z = (x_sp == 2'd0) && (x_sig == 0) && !x_st;
  logic s; assign s = x_s & 1'd1;
  logic lone; assign lone = (x_sig == 0) && x_st;
  logic [9:0] sig_in; assign sig_in = lone ? 10'd1 : x_sig;
  logic signed [12:0] e_lone_c; assign e_lone_c = -13'sd10;
  logic signed [12:0] e_lone;
  // the exponent of a lone sticky's unit
  fam_binary_decode_fam_adder_eac_two_pass_prefix_pe78b8b2e14aea3b9e263e35c4eb909349e1798e5a3c0e9bc52ba3c6f4f857ee3_w13 u1 (.a(x_e), .b(e_lone_c), .cin(1'b0), .s(e_lone), .cout());
  logic signed [12:0] e_in; assign e_in = lone ? e_lone : x_e;
  logic [3:0] lz;
  // the normalizer's leading-zero count
  fam_count_priority_encoder_g8_l3_one_hot_then_encode_w10 u2 (.a(sig_in), .n(lz));
  logic [3:0] lzs; assign lzs = (sig_in == 0) ? 4'd0 : lz[3:0];
  logic [9:0] sig;
  logic [15:0] sig_network_a; assign sig_network_a = {6'd0, sig_in};
  logic [15:0] sig_network_y;
  // the normalizer's left shift; 10-bit payload in a 16-bit butterfly network
  fam_shift_butterfly_network #(.W(16), .NETWORK(0), .STICKY(1)) u3 (.a(sig_network_a), .amt(lzs), .op(3'd0), .y(sig_network_y), .sticky());
  assign sig = sig_network_y[9:0];
  logic signed [12:0] lzx; assign lzx = $signed({{(13-4){1'b0}}, lzs});
  logic [12:0] e_nb; assign e_nb = ~(lzx);
  logic signed [12:0] e;
  // the exponent lowered by the normalize count
  fam_binary_decode_fam_adder_eac_two_pass_prefix_pe78b8b2e14aea3b9e263e35c4eb909349e1798e5a3c0e9bc52ba3c6f4f857ee3_w13 u4 (.a(e_in), .b(e_nb), .cin(1'b1), .s(e), .cout());
  logic normal; assign normal = e >= -13'sd23;
  logic signed [13:0] shc; assign shc = -14'sd16;
  logic signed [13:0] ex; assign ex = $signed({e[12], e});
  logic [13:0] shsub_nb; assign shsub_nb = ~(ex);
  logic signed [13:0] shsub;
  // the subnormal result's extra right shift
  fam_binary_decode_fam_adder_eac_two_pass_prefix_pe78b8b2e14aea3b9e263e35c4eb909349e1798e5a3c0e9bc52ba3c6f4f857ee3_w14 u5 (.a(shc), .b(shsub_nb), .cin(1'b1), .s(shsub), .cout());
  logic signed [13:0] sht; assign sht = normal ? 14'sd7 : shsub;
  logic signed [13:0] sh; assign sh = (sht > 14'sd11) ? 14'sd11 : sht;
  logic [3:0] sha; assign sha = sh[3:0];
  logic [10:0] sigw; assign sigw = {1'b0, sig};
  logic [3:0] shk; assign shk = (sh > 14'sd10) ? 4'd10 : sha;
  logic [10:0] keep;
  logic [15:0] keep_network_a; assign keep_network_a = {5'd0, sigw};
  logic [15:0] keep_network_y;
  // the right shift to the kept bits; 11-bit payload in a 16-bit butterfly network
  fam_shift_butterfly_network #(.W(16), .NETWORK(0), .STICKY(1)) u6 (.a(keep_network_a), .amt(shk), .op(3'd1), .y(keep_network_y), .sticky());
  assign keep = keep_network_y[10:0];
  // the mask of the dropped positions
  logic [10:0] restmask;
  assign restmask[0] = (sha > 0);
  assign restmask[1] = (sha > 1);
  assign restmask[2] = (sha > 2);
  assign restmask[3] = (sha > 3);
  assign restmask[4] = (sha > 4);
  assign restmask[5] = (sha > 5);
  assign restmask[6] = (sha > 6);
  assign restmask[7] = (sha > 7);
  assign restmask[8] = (sha > 8);
  assign restmask[9] = (sha > 9);
  assign restmask[10] = (sha > 10);
  logic [10:0] rest; assign rest = sigw & restmask;
  // the half position (one below the kept lsb)
  logic [10:0] halfv;
  assign halfv[0] = (sha == 1);
  assign halfv[1] = (sha == 2);
  assign halfv[2] = (sha == 3);
  assign halfv[3] = (sha == 4);
  assign halfv[4] = (sha == 5);
  assign halfv[5] = (sha == 6);
  assign halfv[6] = (sha == 7);
  assign halfv[7] = (sha == 8);
  assign halfv[8] = (sha == 9);
  assign halfv[9] = (sha == 10);
  assign halfv[10] = (sha == 11);
  logic [10:0] keepn; assign keepn = sigw >> 7;
  logic [10:0] restn; assign restn = sigw & ({1'b0, {10{1'b1}}} >> 3);
  logic [10:0] halfn; assign halfn = {10'd0, 1'b1} << 6;
  logic inexact; assign inexact = (rest != 0) | x_st;
  logic [18:0] restw; assign restw = {rest, 8'd0};
  logic [4:0] fsh; assign fsh = sht[4:0];
  logic [18:0] fint0;
  logic [31:0] fint0_network_a; assign fint0_network_a = {13'd0, restw};
  logic [31:0] fint0_network_y;
  // the dropped bits aligned to the stochastic word; 19-bit payload in a 32-bit butterfly network
  fam_shift_butterfly_network #(.W(32), .NETWORK(0), .STICKY(1)) u7 (.a(fint0_network_a), .amt(fsh), .op(3'd1), .y(fint0_network_y), .sticky());
  assign fint0 = fint0_network_y[18:0];
  logic [18:0] fint; assign fint = (sht > 14'sd18) ? 19'd0 : fint0;
  logic [18:0] fintn; assign fintn = restn << 1;
  logic gt_half; assign gt_half = rest > halfv;
  logic half_eq; assign half_eq = (rest == halfv) && (halfv != 0);
  logic up; assign up = (rnd == 3'd0) ? (gt_half || (half_eq && (x_st || keep[0]))) : (rnd == 3'd1) ? 1'b0 : (rnd == 3'd2) ? (inexact && s) : (rnd == 3'd3) ? (inexact && !s) : (rnd == 3'd4) ? (inexact && (0 ? (fint >= word) : (fint > word))) : inexact;
  logic gt_halfn; assign gt_halfn = restn > halfn;
  logic half_eqn; assign half_eqn = (restn == halfn) && (halfn != 0);
  logic upn; assign upn = (rnd == 3'd0) ? (gt_halfn || (half_eqn && (x_st || keepn[0]))) : (rnd == 3'd1) ? 1'b0 : (rnd == 3'd2) ? (((restn != 0) | x_st) && s) : (rnd == 3'd3) ? (((restn != 0) | x_st) && !s) : (rnd == 3'd4) ? (((restn != 0) | x_st) && (0 ? (fintn >= word) : (fintn > word))) : ((restn != 0) | x_st);
  logic rounded; assign rounded = x_sp == 2'd3;
  logic upr; assign upr = rounded ? 1'b0 : up;
  logic inexact_r; assign inexact_r = rounded | inexact;
  logic carry_n; assign carry_n = upn && (&keepn[2:0]);
  logic [10:0] mag;
  logic [10:0] mag0;
  // the rounding increment (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(11), .STRUCTURE(1), .B(4), .TOPO(2)) u8 (.a(keep), .cin(upr), .s(mag0), .cout());
  assign mag = mag0;
  logic signed [12:0] bfield_c; assign bfield_c = 13'sd24;
  logic signed [12:0] bfield;
  // the biased exponent field
  fam_binary_decode_fam_adder_eac_two_pass_prefix_pe78b8b2e14aea3b9e263e35c4eb909349e1798e5a3c0e9bc52ba3c6f4f857ee3_w13 u9 (.a(e), .b(bfield_c), .cin(1'b0), .s(bfield), .cout());
  logic [12:0] bfu; assign bfu = bfield;
  logic [12:0] efield;
  // the exponent field incremented on a rounding carry (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(13), .STRUCTURE(1), .B(4), .TOPO(1)) u10 (.a(bfu), .cin(mag[3]), .s(efield), .cout());
  logic [21:0] code; assign code = normal ? {{(22-13-2){1'b0}}, efield, mag[1:0]} : {{(22-11){1'b0}}, mag};
  logic tiny; assign tiny = (e < -13'sd23) && !(e == -13'sd24 && carry_n) && !(e == -13'sd24 && carry_n);
  logic ovf; assign ovf = code > 22'd123;
  logic to_inf; assign to_inf = 1 && (rnd == 3'd0 || (rnd == 3'd3 && !s) || (rnd == 3'd2 && s) || rnd == 3'd5 || (rnd == 3'd4 && (e > 13'sd6 || up)));
  logic ftz_hit; assign ftz_hit = ftz && code[6:2] == 0 && (code[1:0] != 0);
  logic is_zero; assign is_zero = (x_sig == 0) && (!x_st || rounded);
  logic tiny_r; assign tiny_r = rounded ? x_st : tiny;
  logic [9:0] fl_fin; assign fl_fin = ovf ? ((1 << 2) | (1 << 4)) : ((inexact_r ? (1 << 4) : 0) | ((tiny_r && inexact_r) ? (1 << 3) : 0) | (ftz_hit ? ((1 << 4) | (1 << 3)) : 0));
  logic [7:0] bits_fin; assign bits_fin = ovf ? (to_inf ? {s, 7'd124} : {s, 7'd123}) : (ftz_hit ? {s, 7'd0} : {s, code[6:0]});
  logic [9:0] fl_zero; assign fl_zero = rounded ? ((1 << 4) | (1 << 3)) : 10'd0;
  assign fl = (x_sp == 2'd1) ? (1 << 5) : (x_sp == 2'd2) ? 0 : is_zero ? fl_zero : fl_fin;
  assign bits = (x_sp == 2'd1) ? 8'd126 : (x_sp == 2'd2) ? {s, 7'd124} : is_zero ? (rounded ? {s, 7'd0} : 8'd0) : bits_fin;
endmodule

// fp rounder (dedicated_per_op, rounding injection, leading zeros prefix_lzc, shifts butterfly_network, exponent carry_select / prefix_and_incrementer): X -> fp16 pattern and flags
module fam_fp_round_dedicated_per_op_injection_fp16_x26e13s11_p511c8e3eed31 (
  input logic [42:0] x,
  input logic [2:0] rnd,
  input logic [7:0] word,
  input logic ftz,
  output logic [9:0] fl,
  output logic [15:0] bits
);
  logic [1:0] x_sp; assign x_sp = x[42:41];
  logic x_s; assign x_s = x[40];
  logic signed [12:0] x_e; assign x_e = $signed(x[39:27]);
  logic [25:0] x_sig; assign x_sig = x[26:1];
  logic x_st; assign x_st = x[0];
  logic x_z; assign x_z = (x_sp == 2'd0) && (x_sig == 0) && !x_st;
  logic s; assign s = x_s & 1'd1;
  logic lone; assign lone = (x_sig == 0) && x_st;
  logic [25:0] sig_in; assign sig_in = lone ? 26'd1 : x_sig;
  logic signed [12:0] e_lone_c; assign e_lone_c = -13'sd26;
  logic signed [12:0] e_lone;
  // the exponent of a lone sticky's unit
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13 u1 (.a(x_e), .b(e_lone_c), .cin(1'b0), .s(e_lone), .cout());
  logic signed [12:0] e_in; assign e_in = lone ? e_lone : x_e;
  logic [4:0] lz;
  // the normalizer's leading-zero count
  fam_count_prefix_lzc_brent_kung_flags_w26 u2 (.a(sig_in), .n(lz));
  logic [4:0] lzs; assign lzs = (sig_in == 0) ? 5'd0 : lz[4:0];
  logic [25:0] sig;
  logic [31:0] sig_network_a; assign sig_network_a = {6'd0, sig_in};
  logic [31:0] sig_network_y;
  // the normalizer's left shift; 26-bit payload in a 32-bit butterfly network
  fam_shift_butterfly_network #(.W(32), .NETWORK(1), .STICKY(1)) u3 (.a(sig_network_a), .amt(lzs), .op(3'd0), .y(sig_network_y), .sticky());
  assign sig = sig_network_y[25:0];
  logic signed [12:0] lzx; assign lzx = $signed({{(13-5){1'b0}}, lzs});
  logic [12:0] e_nb; assign e_nb = ~(lzx);
  logic signed [12:0] e;
  // the exponent lowered by the normalize count
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13 u4 (.a(e_in), .b(e_nb), .cin(1'b1), .s(e), .cout());
  logic normal; assign normal = e >= -13'sd39;
  logic signed [13:0] shc; assign shc = -14'sd24;
  logic signed [13:0] ex; assign ex = $signed({e[12], e});
  logic [13:0] shsub_nb; assign shsub_nb = ~(ex);
  logic signed [13:0] shsub;
  // the subnormal result's extra right shift
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w14 u5 (.a(shc), .b(shsub_nb), .cin(1'b1), .s(shsub), .cout());
  logic signed [13:0] sht; assign sht = normal ? 14'sd15 : shsub;
  logic signed [13:0] sh; assign sh = (sht > 14'sd27) ? 14'sd27 : sht;
  logic [4:0] sha; assign sha = sh[4:0];
  logic [26:0] sigw; assign sigw = {1'b0, sig};
  logic [4:0] shk; assign shk = (sh > 14'sd26) ? 5'd26 : sha;
  logic [26:0] keep;
  logic [31:0] keep_network_a; assign keep_network_a = {5'd0, sigw};
  logic [31:0] keep_network_y;
  // the right shift to the kept bits; 27-bit payload in a 32-bit butterfly network
  fam_shift_butterfly_network #(.W(32), .NETWORK(1), .STICKY(1)) u6 (.a(keep_network_a), .amt(shk), .op(3'd1), .y(keep_network_y), .sticky());
  assign keep = keep_network_y[26:0];
  // the mask of the dropped positions
  logic [26:0] restmask;
  assign restmask[0] = (sha > 0);
  assign restmask[1] = (sha > 1);
  assign restmask[2] = (sha > 2);
  assign restmask[3] = (sha > 3);
  assign restmask[4] = (sha > 4);
  assign restmask[5] = (sha > 5);
  assign restmask[6] = (sha > 6);
  assign restmask[7] = (sha > 7);
  assign restmask[8] = (sha > 8);
  assign restmask[9] = (sha > 9);
  assign restmask[10] = (sha > 10);
  assign restmask[11] = (sha > 11);
  assign restmask[12] = (sha > 12);
  assign restmask[13] = (sha > 13);
  assign restmask[14] = (sha > 14);
  assign restmask[15] = (sha > 15);
  assign restmask[16] = (sha > 16);
  assign restmask[17] = (sha > 17);
  assign restmask[18] = (sha > 18);
  assign restmask[19] = (sha > 19);
  assign restmask[20] = (sha > 20);
  assign restmask[21] = (sha > 21);
  assign restmask[22] = (sha > 22);
  assign restmask[23] = (sha > 23);
  assign restmask[24] = (sha > 24);
  assign restmask[25] = (sha > 25);
  assign restmask[26] = (sha > 26);
  logic [26:0] rest; assign rest = sigw & restmask;
  // the half position (one below the kept lsb)
  logic [26:0] halfv;
  assign halfv[0] = (sha == 1);
  assign halfv[1] = (sha == 2);
  assign halfv[2] = (sha == 3);
  assign halfv[3] = (sha == 4);
  assign halfv[4] = (sha == 5);
  assign halfv[5] = (sha == 6);
  assign halfv[6] = (sha == 7);
  assign halfv[7] = (sha == 8);
  assign halfv[8] = (sha == 9);
  assign halfv[9] = (sha == 10);
  assign halfv[10] = (sha == 11);
  assign halfv[11] = (sha == 12);
  assign halfv[12] = (sha == 13);
  assign halfv[13] = (sha == 14);
  assign halfv[14] = (sha == 15);
  assign halfv[15] = (sha == 16);
  assign halfv[16] = (sha == 17);
  assign halfv[17] = (sha == 18);
  assign halfv[18] = (sha == 19);
  assign halfv[19] = (sha == 20);
  assign halfv[20] = (sha == 21);
  assign halfv[21] = (sha == 22);
  assign halfv[22] = (sha == 23);
  assign halfv[23] = (sha == 24);
  assign halfv[24] = (sha == 25);
  assign halfv[25] = (sha == 26);
  assign halfv[26] = (sha == 27);
  logic [26:0] keepn; assign keepn = sigw >> 15;
  logic [26:0] restn; assign restn = sigw & ({1'b0, {26{1'b1}}} >> 11);
  logic [26:0] halfn; assign halfn = {26'd0, 1'b1} << 14;
  logic inexact; assign inexact = (rest != 0) | x_st;
  logic [34:0] restw; assign restw = {rest, 8'd0};
  logic [5:0] fsh; assign fsh = sht[5:0];
  logic [34:0] fint0;
  logic [63:0] fint0_network_a; assign fint0_network_a = {29'd0, restw};
  logic [63:0] fint0_network_y;
  // the dropped bits aligned to the stochastic word; 35-bit payload in a 64-bit butterfly network
  fam_shift_butterfly_network #(.W(64), .NETWORK(1), .STICKY(1)) u7 (.a(fint0_network_a), .amt(fsh), .op(3'd1), .y(fint0_network_y), .sticky());
  assign fint0 = fint0_network_y[34:0];
  logic [34:0] fint; assign fint = (sht > 14'sd34) ? 35'd0 : fint0;
  logic [34:0] fintn; assign fintn = restn >> 7;
  logic gt_half; assign gt_half = rest > halfv;
  logic half_eq; assign half_eq = (rest == halfv) && (halfv != 0);
  logic up; assign up = (rnd == 3'd0) ? (gt_half || (half_eq && (x_st || keep[0]))) : (rnd == 3'd1) ? 1'b0 : (rnd == 3'd2) ? (inexact && s) : (rnd == 3'd3) ? (inexact && !s) : (rnd == 3'd4) ? (inexact && (0 ? (fint >= word) : (fint > word))) : inexact;
  logic gt_halfn; assign gt_halfn = restn > halfn;
  logic half_eqn; assign half_eqn = (restn == halfn) && (halfn != 0);
  logic upn; assign upn = (rnd == 3'd0) ? (gt_halfn || (half_eqn && (x_st || keepn[0]))) : (rnd == 3'd1) ? 1'b0 : (rnd == 3'd2) ? (((restn != 0) | x_st) && s) : (rnd == 3'd3) ? (((restn != 0) | x_st) && !s) : (rnd == 3'd4) ? (((restn != 0) | x_st) && (0 ? (fintn >= word) : (fintn > word))) : ((restn != 0) | x_st);
  logic rounded; assign rounded = x_sp == 2'd3;
  logic upr; assign upr = rounded ? 1'b0 : up;
  logic inexact_r; assign inexact_r = rounded | inexact;
  logic carry_n; assign carry_n = upn && (&keepn[10:0]);
  logic [26:0] mag;
  logic [26:0] ones; assign ones = restmask;
  logic [26:0] inj; assign inj = (rnd == 3'd0) ? halfv : (rnd == 3'd2) ? (s ? ones : 0) : (rnd == 3'd3) ? (s ? 0 : ones) : (rnd == 3'd5) ? ones : 0;
  logic [26:0] sigw_i; assign sigw_i = (sha != 0) ? (sigw | {26'd0, x_st}) : sigw;
  logic [26:0] sum_i;
  logic sum_ico;
  // the injection added (end_around_carry)
  fam_binary_decode_fam_adder_eac_two_pass_prefix_pd56b842a1a7958bea4204a91e282cb4fb8608ad6f9dec53b5d5c8cdf1ffc23b7_w27 u8 (.a(sigw_i), .b(inj), .cin(1'b0), .s(sum_i), .cout(sum_ico));
  logic [27:0] sum_iw; assign sum_iw = {sum_ico, sum_i};
  logic [27:0] magiw;
  logic [31:0] magiw_network_a; assign magiw_network_a = {4'd0, sum_iw};
  logic [31:0] magiw_network_y;
  // the injected sum shifted to the kept bits; 28-bit payload in a 32-bit butterfly network
  fam_shift_butterfly_network #(.W(32), .NETWORK(1), .STICKY(1)) u9 (.a(magiw_network_a), .amt(sha), .op(3'd1), .y(magiw_network_y), .sticky());
  assign magiw = magiw_network_y[27:0];
  logic [26:0] magi; assign magi = magiw[26:0];
  logic tie; assign tie = (rnd == 3'd0) && half_eq && !x_st;
  logic [26:0] magt; assign magt = tie ? {magi[26:1], 1'b0} : magi;
  logic [26:0] uprw; assign uprw = {26'd0, upr};
  logic [26:0] mags;
  // the stochastic mode's increment (end_around_carry)
  fam_binary_decode_fam_adder_eac_two_pass_prefix_pd56b842a1a7958bea4204a91e282cb4fb8608ad6f9dec53b5d5c8cdf1ffc23b7_w27 u10 (.a(keep), .b(uprw), .cin(1'b0), .s(mags), .cout());
  assign mag = rounded ? keep : (rnd == 3'd4 || sha == 0) ? mags : magt;
  logic signed [12:0] bfield_c; assign bfield_c = 13'sd40;
  logic signed [12:0] bfield;
  // the biased exponent field
  fam_adder_carry_select_p25f2f107085728eb33a59f5c8187846b6b0cd93fdb8b4a07873b1cb48a3aa5c3_w13 u11 (.a(e), .b(bfield_c), .cin(1'b0), .s(bfield), .cout());
  logic [12:0] bfu; assign bfu = bfield;
  logic [12:0] efield;
  // the exponent field incremented on a rounding carry (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(13), .STRUCTURE(1), .B(4), .TOPO(0)) u12 (.a(bfu), .cin(mag[11]), .s(efield), .cout());
  logic [29:0] code; assign code = normal ? {{(30-13-10){1'b0}}, efield, mag[9:0]} : {{(30-27){1'b0}}, mag};
  logic tiny; assign tiny = (e < -13'sd39) && !(e == -13'sd40 && carry_n) && !(e == -13'sd40 && carry_n);
  logic ovf; assign ovf = code > 30'd31743;
  logic to_inf; assign to_inf = 1 && (rnd == 3'd0 || (rnd == 3'd3 && !s) || (rnd == 3'd2 && s) || rnd == 3'd5 || (rnd == 3'd4 && (e > -13'sd10 || up)));
  logic ftz_hit; assign ftz_hit = ftz && code[14:10] == 0 && (code[9:0] != 0);
  logic is_zero; assign is_zero = (x_sig == 0) && (!x_st || rounded);
  logic tiny_r; assign tiny_r = rounded ? x_st : tiny;
  logic [9:0] fl_fin; assign fl_fin = ovf ? ((1 << 2) | (1 << 4)) : ((inexact_r ? (1 << 4) : 0) | ((tiny_r && inexact_r) ? (1 << 3) : 0) | (ftz_hit ? ((1 << 4) | (1 << 3)) : 0));
  logic [15:0] bits_fin; assign bits_fin = ovf ? (to_inf ? {s, 15'd31744} : {s, 15'd31743}) : (ftz_hit ? {s, 15'd0} : {s, code[14:0]});
  logic [9:0] fl_zero; assign fl_zero = rounded ? ((1 << 4) | (1 << 3)) : 10'd0;
  assign fl = (x_sp == 2'd1) ? (1 << 5) : (x_sp == 2'd2) ? 0 : is_zero ? fl_zero : fl_fin;
  assign bits = (x_sp == 2'd1) ? 16'd32256 : (x_sp == 2'd2) ? {s, 15'd31744} : is_zero ? (rounded ? {s, 15'd0} : 16'd0) : bits_fin;
endmodule

// fp unpacker (per_unit_unpack): fp8e5m2 pattern -> V; the fields split, the specials decoded, the hidden one restored, a subnormal normalized in the unpacker
module fam_fp_unpack_per_unit_unpack_fp8e5m2_x10e13s3_p9ad4f6fb5c4a (
  input logic [7:0] b,
  input logic daz,
  output logic [19:0] u
);
  logic [4:0] e; assign e = b[6:2];
  logic [1:0] mant; assign mant = b[1:0];
  logic s; assign s = b[7];
  logic nan; assign nan = (e == 5'd31 && mant != 0);
  logic inf; assign inf = (e == 5'd31 && mant == 0);
  logic sub_; assign sub_ = (e == 0);
  logic den; assign den = sub_ && (mant != 0);
  logic [2:0] sig0; assign sig0 = sub_ ? {{(3-2){1'b0}}, mant} : {{(3-2-1){1'b0}}, 1'b1, mant};
  logic [2:0] sig1; assign sig1 = (sub_ && daz) ? 3'd0 : sig0;
  logic signed [12:0] ex0; assign ex0 = sub_ ? -13'sd16 : $signed({{(13-5){1'b0}}, e}) - 13'sd17;
  logic [1:0] lz;
  // the subnormal's leading-zero count
  fam_count_prefix_lzc_brent_kung_flags_w3 u1 (.a(sig1), .n(lz));
  logic [1:0] lzs; assign lzs = (sig1 == 0) ? 2'd0 : lz[1:0];
  logic [2:0] sign;
  // the subnormal normalized
  fam_shift_barrel_mux_tree #(.W(3), .RADIX_LOG2(0), .ONE_HOT(0), .DIR(0), .ORDER(0), .STICKY(0)) u2 (.a(sig1), .amt(lzs), .op(3'd0), .y(sign), .sticky());
  logic signed [12:0] exn; assign exn = ex0 - $signed({{(13-2){1'b0}}, lz});
  logic [18:0] v_nan; assign v_nan = {2'd1, 1'b0, 13'sd0, 3'd0};
  logic [18:0] v_inf; assign v_inf = {2'd2, s, 13'sd0, 3'd0};
  logic [18:0] v_fin; assign v_fin = {2'd0, s, exn, sign};
  assign u = nan ? {1'b0, v_nan} : inf ? {1'b0, v_inf} : {den, v_fin};
endmodule

// fp unpacker (shared_per_lane): bf16 pattern -> V; the fields split, the specials decoded, the hidden one restored, a subnormal normalized in the unpacker
module fam_fp_unpack_shared_per_lane_bf16_x20e16s8_p9ea5912e1006 (
  input logic [15:0] b,
  input logic daz,
  output logic [27:0] u
);
  logic [7:0] e; assign e = b[14:7];
  logic [6:0] mant; assign mant = b[6:0];
  logic s; assign s = b[15];
  logic nan; assign nan = (e == 8'd255 && mant != 0);
  logic inf; assign inf = (e == 8'd255 && mant == 0);
  logic sub_; assign sub_ = (e == 0);
  logic den; assign den = sub_ && (mant != 0);
  logic [7:0] sig0; assign sig0 = sub_ ? {{(8-7){1'b0}}, mant} : {{(8-7-1){1'b0}}, 1'b1, mant};
  logic [7:0] sig1; assign sig1 = (sub_ && daz) ? 8'd0 : sig0;
  logic signed [15:0] ex0; assign ex0 = sub_ ? -16'sd133 : $signed({{(16-8){1'b0}}, e}) - 16'sd134;
  logic [3:0] lz;
  // the subnormal's leading-zero count
  fam_count_lzd_nibble_cell_binary_count_vprop_w8 u1 (.a(sig1), .n(lz));
  logic [2:0] lzs; assign lzs = (sig1 == 0) ? 3'd0 : lz[2:0];
  logic [7:0] sign;
  // the subnormal normalized
  fam_shift_barrel_mux_tree #(.W(8), .RADIX_LOG2(2), .ONE_HOT(0), .DIR(2), .ORDER(1), .STICKY(1)) u2 (.a(sig1), .amt(lzs), .op(3'd0), .y(sign), .sticky());
  logic signed [15:0] exn; assign exn = ex0 - $signed({{(16-4){1'b0}}, lz});
  logic [26:0] v_nan; assign v_nan = {2'd1, 1'b0, 16'sd0, 8'd0};
  logic [26:0] v_inf; assign v_inf = {2'd2, s, 16'sd0, 8'd0};
  logic [26:0] v_fin; assign v_fin = {2'd0, s, exn, sign};
  assign u = nan ? {1'b0, v_nan} : inf ? {1'b0, v_inf} : {den, v_fin};
endmodule

// fp unpacker (shared_per_lane): fp16 pattern -> V; the fields split, the specials decoded, the hidden one restored, a subnormal left as stored
module fam_fp_unpack_shared_per_lane_fp16_x26e13s11_p68f91d4e9d3f (
  input logic [15:0] b,
  input logic daz,
  output logic [27:0] u
);
  logic [4:0] e; assign e = b[14:10];
  logic [9:0] mant; assign mant = b[9:0];
  logic s; assign s = b[15];
  logic nan; assign nan = (e == 5'd31 && mant != 0);
  logic inf; assign inf = (e == 5'd31 && mant == 0);
  logic sub_; assign sub_ = (e == 0);
  logic den; assign den = sub_ && (mant != 0);
  logic [10:0] sig0; assign sig0 = sub_ ? {{(11-10){1'b0}}, mant} : {{(11-10-1){1'b0}}, 1'b1, mant};
  logic [10:0] sig1; assign sig1 = (sub_ && daz) ? 11'd0 : sig0;
  logic signed [12:0] ex0; assign ex0 = sub_ ? -13'sd24 : $signed({{(13-5){1'b0}}, e}) - 13'sd25;
  logic [26:0] v_nan; assign v_nan = {2'd1, 1'b0, 13'sd0, 11'd0};
  logic [26:0] v_inf; assign v_inf = {2'd2, s, 13'sd0, 11'd0};
  logic [26:0] v_fin; assign v_fin = {2'd0, s, ex0, sig1};
  assign u = nan ? {1'b0, v_nan} : inf ? {1'b0, v_inf} : {den, v_fin};
endmodule




// ------------------------------------------------------------ prefix_and_incrementer
// s = a + cin: the carry into bit i is cin AND every lower bit, a prefix AND
// (STRUCTURE 0 a ripple AND chain, 1 a prefix AND tree of topology TOPO, 2
// select blocks of B bits whose block carry is the AND of the block)
module fam_incr_prefix_and #(parameter int W = 16, parameter int STRUCTURE = 1, parameter int B = 4, parameter int TOPO = 0)
  (input logic [W-1:0] a, input logic cin, output logic [W-1:0] s, output logic cout);
  // STRUCTURE: 0 ripple_and_chain, 1 prefix_and_tree (TOPO: 0 sklansky, 1 brent_kung, 2 kogge_stone),
  // 2 select_blocks of B bits
  logic [W:0] c;
  assign c[0] = cin;
  genvar i, l;
  generate
    if (STRUCTURE == 0) begin : ripple
      for (i = 0; i < W; i = i + 1) begin : ch
        assign c[i+1] = c[i] & a[i];
      end
    end else if (STRUCTURE == 1) begin : tree
      localparam int L = (W <= 1) ? 1 : $clog2(W);
      if (TOPO == 2) begin : kogge_stone
        // p[l][i]: AND of a[i] down to a[i - 2^l + 1]
        logic [W-1:0] p [0:L];
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : lvl
          for (i = 0; i < W; i = i + 1) begin : pos
            if (i >= (1 << l)) begin : comb
              assign p[l+1][i] = p[l][i] & p[l][i - (1 << l)];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[L][i];
        end
      end else if (TOPO == 1) begin : brent_kung
        // an up-sweep over the odd positions of each level, then a down-sweep filling the rest
        logic [W-1:0] p [0:2*L];
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : up
          for (i = 0; i < W; i = i + 1) begin : pos
            if (((i + 1) % (2 << l)) == 0) begin : comb
              assign p[l+1][i] = p[l][i] & p[l][i - (1 << l)];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (l = 0; l < L; l = l + 1) begin : down
          localparam int D = 1 << (L - 1 - l);
          for (i = 0; i < W; i = i + 1) begin : pos
            if (((i + 1) % (2 * D)) == D && (i + 1) > D) begin : comb
              assign p[L+l+1][i] = p[L+l][i] & p[L+l][i - D];
            end else begin : keep
              assign p[L+l+1][i] = p[L+l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[2*L][i];
        end
      end else begin : sklansky
        logic [W-1:0] p [0:L];           // p[l][i]: AND of a[i] down to a[i - 2^l + 1]
        for (i = 0; i < W; i = i + 1) begin : leaf
          assign p[0][i] = a[i];
        end
        for (l = 0; l < L; l = l + 1) begin : lvl
          for (i = 0; i < W; i = i + 1) begin : pos
            if ((i / (1 << l)) % 2 == 1) begin : comb   // the upper half of every block takes the lower half's end
              assign p[l+1][i] = p[l][i] & p[l][(i / (1 << l)) * (1 << l) - 1];
            end else begin : keep
              assign p[l+1][i] = p[l][i];
            end
          end
        end
        for (i = 0; i < W; i = i + 1) begin : cy
          assign c[i+1] = cin & p[L][i];
        end
      end
    end else begin : blocks
      localparam int NB = (W + B - 1) / B;
      logic [NB:0] bc;                  // the carry into each block
      assign bc[0] = cin;
      for (i = 0; i < NB; i = i + 1) begin : blk
        localparam int LO = i * B;
        localparam int HI = (LO + B - 1 < W - 1) ? LO + B - 1 : W - 1;
        logic all1;
        assign all1 = &a[HI:LO];
        assign bc[i+1] = bc[i] & all1;
        genvar j;
        for (j = LO; j <= HI; j = j + 1) begin : bit_
          if (j == LO) begin : first
            assign c[j+1] = bc[i] & a[j];
          end else begin : rest
            assign c[j+1] = c[j] & a[j];
          end
        end
      end
    end
  endgenerate
  assign s = a ^ c[W-1:0];
  assign cout = c[W];
endmodule



module fam_mul_booth4_dadda_3_2_w4_u_p4789ec73 (input logic [3:0] a, input logic [3:0] b, output logic [7:0] p);
  // booth_recoded_parallel: {'pp_bits': 18, 'full_adders': 3, 'half_adders': 1, 'cells': 0, 'tree_depth': 1}
  logic neg1, sel3, sel4, pp5, pp6, pp7, pp8, pp9, pp10, pp11, pp12, pp13, pp14, pp15, pp16, pp17, pp18, pp19, pp20, pp21, pp22, pp23, pp24, pp25, neg27, sel29, sel30, pp31, pp32, pp33, pp34, pp35, pp36, pp37, pp38, pp39, pp40, pp41, pp42, pp43, pp44, pp45, pp46, pp47, pp48, pp49, pp50, pp51, neg53, sel55, sel56, pp57, pp58, pp59, pp60, pp61, pp62, pp63, pp64, pp65, pp66, pp67, pp68, pp69, pp70, pp71, pp72, pp73, pp74, pp75, pp76, pp77, t78, t79, t80, t81, t82, t83, t84, t85;
  logic [6:0] a_ext;
  logic [1:0] lo0;
  logic [1:0] mg2;
  logic [6:0] m2;
  logic [6:0] nm1_i;
  logic [6:0] nm2_i;
  logic [1:0] lo26;
  logic [1:0] mg28;
  logic [1:0] lo52;
  logic [1:0] mg54;
  logic [6:0] nm1; logic nm1_co;
  // -1a = ~(1a) + 1 through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(7), .STRUCTURE(0), .B(4), .TOPO(0)) u_i1 (.a(nm1_i), .cin(1'b1), .s(nm1), .cout(nm1_co));
  logic [6:0] nm2; logic nm2_co;
  // -2a = ~(2a) + 1 through the incrementer (prefix_and_incrementer)
  fam_incr_prefix_and #(.W(7), .STRUCTURE(0), .B(4), .TOPO(0)) u_i2 (.a(nm2_i), .cin(1'b1), .s(nm2), .cout(nm2_co));
  assign a_ext = {{3{1'b0}}, a};
  assign lo0 = {1'b0, {b[0]}} + {{1{1'b0}}, 1'b0};
  assign neg1 = b[1] & ~(1'b0 & b[0]);
  assign mg2 = b[1] ? (2'd2 - lo0) : lo0;
  assign sel3 = (mg2 == 2'd1);
  assign sel4 = (mg2 == 2'd2);
  assign m2 = {a_ext[5:0], 1'd0};
  assign pp5 = (sel3 & a_ext[0]) | (sel4 & m2[0]);
  assign nm1_i = ~a_ext;
  assign nm2_i = ~m2;
  assign pp6 = (sel3 & nm1[0]) | (sel4 & nm2[0]);
  assign pp7 = neg1 ? pp6 : pp5;
  assign pp8 = (sel3 & a_ext[1]) | (sel4 & m2[1]);
  assign pp9 = (sel3 & nm1[1]) | (sel4 & nm2[1]);
  assign pp10 = neg1 ? pp9 : pp8;
  assign pp11 = (sel3 & a_ext[2]) | (sel4 & m2[2]);
  assign pp12 = (sel3 & nm1[2]) | (sel4 & nm2[2]);
  assign pp13 = neg1 ? pp12 : pp11;
  assign pp14 = (sel3 & a_ext[3]) | (sel4 & m2[3]);
  assign pp15 = (sel3 & nm1[3]) | (sel4 & nm2[3]);
  assign pp16 = neg1 ? pp15 : pp14;
  assign pp17 = (sel3 & a_ext[4]) | (sel4 & m2[4]);
  assign pp18 = (sel3 & nm1[4]) | (sel4 & nm2[4]);
  assign pp19 = neg1 ? pp18 : pp17;
  assign pp20 = (sel3 & a_ext[5]) | (sel4 & m2[5]);
  assign pp21 = (sel3 & nm1[5]) | (sel4 & nm2[5]);
  assign pp22 = neg1 ? pp21 : pp20;
  assign pp23 = (sel3 & a_ext[6]) | (sel4 & m2[6]);
  assign pp24 = (sel3 & nm1[6]) | (sel4 & nm2[6]);
  assign pp25 = neg1 ? pp24 : pp23;
  assign lo26 = {1'b0, {b[2]}} + {{1{1'b0}}, b[1]};
  assign neg27 = b[3] & ~(b[1] & b[2]);
  assign mg28 = b[3] ? (2'd2 - lo26) : lo26;
  assign sel29 = (mg28 == 2'd1);
  assign sel30 = (mg28 == 2'd2);
  assign pp31 = (sel29 & a_ext[0]) | (sel30 & m2[0]);
  assign pp32 = (sel29 & nm1[0]) | (sel30 & nm2[0]);
  assign pp33 = neg27 ? pp32 : pp31;
  assign pp34 = (sel29 & a_ext[1]) | (sel30 & m2[1]);
  assign pp35 = (sel29 & nm1[1]) | (sel30 & nm2[1]);
  assign pp36 = neg27 ? pp35 : pp34;
  assign pp37 = (sel29 & a_ext[2]) | (sel30 & m2[2]);
  assign pp38 = (sel29 & nm1[2]) | (sel30 & nm2[2]);
  assign pp39 = neg27 ? pp38 : pp37;
  assign pp40 = (sel29 & a_ext[3]) | (sel30 & m2[3]);
  assign pp41 = (sel29 & nm1[3]) | (sel30 & nm2[3]);
  assign pp42 = neg27 ? pp41 : pp40;
  assign pp43 = (sel29 & a_ext[4]) | (sel30 & m2[4]);
  assign pp44 = (sel29 & nm1[4]) | (sel30 & nm2[4]);
  assign pp45 = neg27 ? pp44 : pp43;
  assign pp46 = (sel29 & a_ext[5]) | (sel30 & m2[5]);
  assign pp47 = (sel29 & nm1[5]) | (sel30 & nm2[5]);
  assign pp48 = neg27 ? pp47 : pp46;
  assign pp49 = (sel29 & a_ext[6]) | (sel30 & m2[6]);
  assign pp50 = (sel29 & nm1[6]) | (sel30 & nm2[6]);
  assign pp51 = neg27 ? pp50 : pp49;
  assign lo52 = {1'b0, {1'b0}} + {{1{1'b0}}, b[3]};
  assign neg53 = 1'b0 & ~(b[3] & 1'b0);
  assign mg54 = 1'b0 ? (2'd2 - lo52) : lo52;
  assign sel55 = (mg54 == 2'd1);
  assign sel56 = (mg54 == 2'd2);
  assign pp57 = (sel55 & a_ext[0]) | (sel56 & m2[0]);
  assign pp58 = (sel55 & nm1[0]) | (sel56 & nm2[0]);
  assign pp59 = neg53 ? pp58 : pp57;
  assign pp60 = (sel55 & a_ext[1]) | (sel56 & m2[1]);
  assign pp61 = (sel55 & nm1[1]) | (sel56 & nm2[1]);
  assign pp62 = neg53 ? pp61 : pp60;
  assign pp63 = (sel55 & a_ext[2]) | (sel56 & m2[2]);
  assign pp64 = (sel55 & nm1[2]) | (sel56 & nm2[2]);
  assign pp65 = neg53 ? pp64 : pp63;
  assign pp66 = (sel55 & a_ext[3]) | (sel56 & m2[3]);
  assign pp67 = (sel55 & nm1[3]) | (sel56 & nm2[3]);
  assign pp68 = neg53 ? pp67 : pp66;
  assign pp69 = (sel55 & a_ext[4]) | (sel56 & m2[4]);
  assign pp70 = (sel55 & nm1[4]) | (sel56 & nm2[4]);
  assign pp71 = neg53 ? pp70 : pp69;
  assign pp72 = (sel55 & a_ext[5]) | (sel56 & m2[5]);
  assign pp73 = (sel55 & nm1[5]) | (sel56 & nm2[5]);
  assign pp74 = neg53 ? pp73 : pp72;
  assign pp75 = (sel55 & a_ext[6]) | (sel56 & m2[6]);
  assign pp76 = (sel55 & nm1[6]) | (sel56 & nm2[6]);
  assign pp77 = neg53 ? pp76 : pp75;
  assign t78 = pp19 ^ pp39;
  assign t79 = pp19 & pp39;
  assign t80 = pp22 ^ pp42 ^ pp62;
  assign t81 = (pp22 & pp42) | (pp22 & pp62) | (pp42 & pp62);
  assign t82 = pp25 ^ pp45 ^ pp65;
  assign t83 = (pp25 & pp45) | (pp25 & pp65) | (pp45 & pp65);
  assign t84 = pp25 ^ pp48 ^ pp68;
  assign t85 = (pp25 & pp48) | (pp25 & pp68) | (pp48 & pp68);
  logic [7:0] row_s, row_c;
  assign row_s = {t83, t81, t79, pp59, pp16, pp13, pp10, pp7};
  assign row_c = {t84, t82, t80, t78, pp36, pp33, 1'b0, 1'b0};
  fam_prefix_han_carlson_w8_ling u_cpa (.a(row_s), .b(row_c), .cin(1'b0), .s(p), .cout());
endmodule


// lzd_cell_tree (pair_cell, binary_count, valid flags propagated): the leading zeros of a 8-bit word

module fam_mul_booth8_dadda_3_2_w8_u_p206e54d6 (input logic [7:0] a, input logic [7:0] b, output logic [15:0] p);
  // booth_recoded_parallel: {'pp_bits': 60, 'full_adders': 12, 'half_adders': 9, 'cells': 0, 'tree_depth': 3}
  logic neg1, sel3, sel4, sel5, sel6, pp7, pp8, pp9, pp10, pp11, pp12, pp13, pp14, pp15, pp16, pp17, pp18, pp19, pp20, pp21, pp22, neg24, sel26, sel27, sel28, sel29, pp30, pp31, pp32, pp33, pp34, pp35, pp36, pp37, pp38, pp39, pp40, pp41, pp42, pp43, pp44, pp45, neg47, sel49, sel50, sel51, sel52, pp53, pp54, pp55, pp56, pp57, pp58, pp59, pp60, pp61, pp62, pp63, pp64, pp65, pp66, pp67, pp68, ns69, ns70, t71, t72, t73, t74, t75, t76, t77, t78, t79, t80, t81, t82, t83, t84, t85, t86, t87, t88, t89, t90, t91, t92, t93, t94, t95, t96, t97, t98, t99, t100, t101, t102, t103, t104, t105, t106, t107, t108, t109, t110, t111, t112;
  logic [11:0] a_ext;
  logic [2:0] lo0;
  logic [2:0] mg2;
  logic [11:0] m2;
  logic [11:0] m3;
  logic [11:0] m4;
  logic [2:0] lo23;
  logic [2:0] mg25;
  logic [2:0] lo46;
  logic [2:0] mg48;
  logic [3:0] m3_t0; logic m3_c0;
  // 3a tile 0 (parallel_prefix, 4 bits): 2a + a without carry propagation across tiles
  fam_prefix_kogge_stone_w4 u_i1 (.a(m2[3:0]), .b(a_ext[3:0]), .cin(1'b0), .s(m3_t0), .cout(m3_c0));
  logic [3:0] m3_t1; logic m3_c1;
  // 3a tile 1 (parallel_prefix, 4 bits): 2a + a without carry propagation across tiles
  fam_prefix_kogge_stone_w4 u_i2 (.a(m2[7:4]), .b(a_ext[7:4]), .cin(1'b0), .s(m3_t1), .cout(m3_c1));
  logic [3:0] m3_t2; logic m3_c2;
  // 3a tile 2 (parallel_prefix, 4 bits): 2a + a without carry propagation across tiles
  fam_prefix_kogge_stone_w4 u_i3 (.a(m2[11:8]), .b(a_ext[11:8]), .cin(1'b0), .s(m3_t2), .cout(m3_c2));
  logic [3:0] ts1; logic tc1;
  // tile 1 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) u_i4 (.a({pp10, pp9, pp8, pp7}), .b({pp30, 1'b0, 1'b0, neg1}), .cin(1'b0), .s(ts1), .cout(tc1));
  logic [3:0] ts2; logic tc2;
  // tile 2 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) u_i5 (.a({pp14, pp13, pp12, pp11}), .b({pp34, pp33, pp32, pp31}), .cin(1'b0), .s(ts2), .cout(tc2));
  logic [3:0] ts3; logic tc3;
  // tile 3 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) u_i6 (.a({ns69, pp17, pp16, pp15}), .b({pp38, pp37, pp36, pp35}), .cin(1'b0), .s(ts3), .cout(tc3));
  logic [3:0] ts4; logic tc4;
  // tile 4 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) u_i7 (.a({pp62, ns70, pp40, pp39}), .b({1'b1, pp61, pp60, pp59}), .cin(1'b0), .s(ts4), .cout(tc4));
  logic [3:0] ts5; logic tc5;
  // tile 5 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) u_i8 (.a({pp54, pp53, 1'b1, pp19}), .b({pp42, neg47, 1'b0, pp20}), .cin(1'b0), .s(ts5), .cout(tc5));
  logic [3:0] ts6; logic tc6;
  // tile 6 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) u_i9 (.a({pp58, pp57, pp56, pp55}), .b({1'b1, pp65, 1'b1, pp21}), .cin(1'b0), .s(ts6), .cout(tc6));
  logic [3:0] ts7; logic tc7;
  // tile 7 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) u_i10 (.a({1'b1, pp67, 1'b1, 1'b1}), .b({1'b0, pp68, 1'b1, 1'b1}), .cin(1'b0), .s(ts7), .cout(tc7));
  logic [3:0] ts8; logic tc8;
  // tile 8 (ripple_carry, 4 bits) at level 0
  fam_adder_ripple_carry #(.W(4), .CHUNK(1), .FORM(0)) u_i11 (.a({pp44, pp66, 1'b0, pp22}), .b({pp45, 1'b0, 1'b0, 1'b0}), .cin(1'b0), .s(ts8), .cout(tc8));
  assign a_ext = {{4{1'b0}}, a};
  assign lo0 = {1'b0, {b[1], b[0]}} + {{2{1'b0}}, 1'b0};
  assign neg1 = b[2] & ~(1'b0 & b[0] & b[1]);
  assign mg2 = b[2] ? (3'd4 - lo0) : lo0;
  assign sel3 = (mg2 == 3'd1);
  assign sel4 = (mg2 == 3'd2);
  assign sel5 = (mg2 == 3'd3);
  assign sel6 = (mg2 == 3'd4);
  assign m2 = {a_ext[10:0], 1'd0};
  assign m3 = {m3_t2, m3_t1, m3_t0};
  assign m4 = {a_ext[9:0], 2'd0};
  assign pp7 = ((sel3 & a_ext[0]) | (sel4 & m2[0]) | (sel5 & m3[0]) | (sel6 & m4[0])) ^ neg1;
  assign pp8 = ((sel3 & a_ext[1]) | (sel4 & m2[1]) | (sel5 & m3[1]) | (sel6 & m4[1])) ^ neg1;
  assign pp9 = ((sel3 & a_ext[2]) | (sel4 & m2[2]) | (sel5 & m3[2]) | (sel6 & m4[2])) ^ neg1;
  assign pp10 = ((sel3 & a_ext[3]) | (sel4 & m2[3]) | (sel5 & m3[3]) | (sel6 & m4[3])) ^ neg1;
  assign pp11 = ((sel3 & a_ext[4]) | (sel4 & m2[4]) | (sel5 & m3[4]) | (sel6 & m4[4])) ^ neg1;
  assign pp12 = ((sel3 & a_ext[5]) | (sel4 & m2[5]) | (sel5 & m3[5]) | (sel6 & m4[5])) ^ neg1;
  assign pp13 = ((sel3 & a_ext[6]) | (sel4 & m2[6]) | (sel5 & m3[6]) | (sel6 & m4[6])) ^ neg1;
  assign pp14 = ((sel3 & a_ext[7]) | (sel4 & m2[7]) | (sel5 & m3[7]) | (sel6 & m4[7])) ^ neg1;
  assign pp15 = ((sel3 & a_ext[8]) | (sel4 & m2[8]) | (sel5 & m3[8]) | (sel6 & m4[8])) ^ neg1;
  assign pp16 = ((sel3 & a_ext[9]) | (sel4 & m2[9]) | (sel5 & m3[9]) | (sel6 & m4[9])) ^ neg1;
  assign pp17 = ((sel3 & a_ext[10]) | (sel4 & m2[10]) | (sel5 & m3[10]) | (sel6 & m4[10])) ^ neg1;
  assign pp18 = ((sel3 & a_ext[11]) | (sel4 & m2[11]) | (sel5 & m3[11]) | (sel6 & m4[11])) ^ neg1;
  assign pp19 = sel5 & (m3_c0 ^ neg1);
  assign pp20 = ~(neg1 & (sel5));
  assign pp21 = sel5 & (m3_c1 ^ neg1);
  assign pp22 = ~(neg1 & (sel5));
  assign lo23 = {1'b0, {b[4], b[3]}} + {{2{1'b0}}, b[2]};
  assign neg24 = b[5] & ~(b[2] & b[3] & b[4]);
  assign mg25 = b[5] ? (3'd4 - lo23) : lo23;
  assign sel26 = (mg25 == 3'd1);
  assign sel27 = (mg25 == 3'd2);
  assign sel28 = (mg25 == 3'd3);
  assign sel29 = (mg25 == 3'd4);
  assign pp30 = ((sel26 & a_ext[0]) | (sel27 & m2[0]) | (sel28 & m3[0]) | (sel29 & m4[0])) ^ neg24;
  assign pp31 = ((sel26 & a_ext[1]) | (sel27 & m2[1]) | (sel28 & m3[1]) | (sel29 & m4[1])) ^ neg24;
  assign pp32 = ((sel26 & a_ext[2]) | (sel27 & m2[2]) | (sel28 & m3[2]) | (sel29 & m4[2])) ^ neg24;
  assign pp33 = ((sel26 & a_ext[3]) | (sel27 & m2[3]) | (sel28 & m3[3]) | (sel29 & m4[3])) ^ neg24;
  assign pp34 = ((sel26 & a_ext[4]) | (sel27 & m2[4]) | (sel28 & m3[4]) | (sel29 & m4[4])) ^ neg24;
  assign pp35 = ((sel26 & a_ext[5]) | (sel27 & m2[5]) | (sel28 & m3[5]) | (sel29 & m4[5])) ^ neg24;
  assign pp36 = ((sel26 & a_ext[6]) | (sel27 & m2[6]) | (sel28 & m3[6]) | (sel29 & m4[6])) ^ neg24;
  assign pp37 = ((sel26 & a_ext[7]) | (sel27 & m2[7]) | (sel28 & m3[7]) | (sel29 & m4[7])) ^ neg24;
  assign pp38 = ((sel26 & a_ext[8]) | (sel27 & m2[8]) | (sel28 & m3[8]) | (sel29 & m4[8])) ^ neg24;
  assign pp39 = ((sel26 & a_ext[9]) | (sel27 & m2[9]) | (sel28 & m3[9]) | (sel29 & m4[9])) ^ neg24;
  assign pp40 = ((sel26 & a_ext[10]) | (sel27 & m2[10]) | (sel28 & m3[10]) | (sel29 & m4[10])) ^ neg24;
  assign pp41 = ((sel26 & a_ext[11]) | (sel27 & m2[11]) | (sel28 & m3[11]) | (sel29 & m4[11])) ^ neg24;
  assign pp42 = sel28 & (m3_c0 ^ neg24);
  assign pp43 = ~(neg24 & (sel28));
  assign pp44 = sel28 & (m3_c1 ^ neg24);
  assign pp45 = ~(neg24 & (sel28));
  assign lo46 = {1'b0, {b[7], b[6]}} + {{2{1'b0}}, b[5]};
  assign neg47 = 1'b0 & ~(b[5] & b[6] & b[7]);
  assign mg48 = 1'b0 ? (3'd4 - lo46) : lo46;
  assign sel49 = (mg48 == 3'd1);
  assign sel50 = (mg48 == 3'd2);
  assign sel51 = (mg48 == 3'd3);
  assign sel52 = (mg48 == 3'd4);
  assign pp53 = ((sel49 & a_ext[0]) | (sel50 & m2[0]) | (sel51 & m3[0]) | (sel52 & m4[0])) ^ neg47;
  assign pp54 = ((sel49 & a_ext[1]) | (sel50 & m2[1]) | (sel51 & m3[1]) | (sel52 & m4[1])) ^ neg47;
  assign pp55 = ((sel49 & a_ext[2]) | (sel50 & m2[2]) | (sel51 & m3[2]) | (sel52 & m4[2])) ^ neg47;
  assign pp56 = ((sel49 & a_ext[3]) | (sel50 & m2[3]) | (sel51 & m3[3]) | (sel52 & m4[3])) ^ neg47;
  assign pp57 = ((sel49 & a_ext[4]) | (sel50 & m2[4]) | (sel51 & m3[4]) | (sel52 & m4[4])) ^ neg47;
  assign pp58 = ((sel49 & a_ext[5]) | (sel50 & m2[5]) | (sel51 & m3[5]) | (sel52 & m4[5])) ^ neg47;
  assign pp59 = ((sel49 & a_ext[6]) | (sel50 & m2[6]) | (sel51 & m3[6]) | (sel52 & m4[6])) ^ neg47;
  assign pp60 = ((sel49 & a_ext[7]) | (sel50 & m2[7]) | (sel51 & m3[7]) | (sel52 & m4[7])) ^ neg47;
  assign pp61 = ((sel49 & a_ext[8]) | (sel50 & m2[8]) | (sel51 & m3[8]) | (sel52 & m4[8])) ^ neg47;
  assign pp62 = ((sel49 & a_ext[9]) | (sel50 & m2[9]) | (sel51 & m3[9]) | (sel52 & m4[9])) ^ neg47;
  assign pp63 = ((sel49 & a_ext[10]) | (sel50 & m2[10]) | (sel51 & m3[10]) | (sel52 & m4[10])) ^ neg47;
  assign pp64 = ((sel49 & a_ext[11]) | (sel50 & m2[11]) | (sel51 & m3[11]) | (sel52 & m4[11])) ^ neg47;
  assign pp65 = sel51 & (m3_c0 ^ neg47);
  assign pp66 = ~(neg47 & (sel51));
  assign pp67 = sel51 & (m3_c1 ^ neg47);
  assign pp68 = ~(neg47 & (sel51));
  assign ns69 = ~pp18;
  assign ns70 = ~pp41;
  assign t71 = ts3[0] ^ ts6[0];
  assign t72 = ts3[0] & ts6[0];
  assign t73 = ts4[0] ^ ts7[0];
  assign t74 = ts4[0] & ts7[0];
  assign t75 = ts2[0] ^ ts5[0];
  assign t76 = ts2[0] & ts5[0];
  assign t77 = ts8[0] ^ tc2;
  assign t78 = ts8[0] & tc2;
  assign t79 = ts3[1] ^ ts6[1] ^ ts8[1];
  assign t80 = (ts3[1] & ts6[1]) | (ts3[1] & ts8[1]) | (ts6[1] & ts8[1]);
  assign t81 = ts3[2] ^ ts6[2];
  assign t82 = ts3[2] & ts6[2];
  assign t83 = ts3[3] ^ ts6[3];
  assign t84 = ts3[3] & ts6[3];
  assign t85 = tc3 ^ tc6 ^ tc8;
  assign t86 = (tc3 & tc6) | (tc3 & tc8) | (tc6 & tc8);
  assign t87 = ts4[1] ^ ts7[1];
  assign t88 = ts4[1] & ts7[1];
  assign t89 = 1'b1 ^ tc1;
  assign t90 = 1'b1 & tc1;
  assign t91 = ts2[1] ^ ts5[1] ^ t76;
  assign t92 = (ts2[1] & ts5[1]) | (ts2[1] & t76) | (ts5[1] & t76);
  assign t93 = ts2[2] ^ ts5[2] ^ 1'b1;
  assign t94 = (ts2[2] & ts5[2]) | (ts2[2] & 1'b1) | (ts5[2] & 1'b1);
  assign t95 = ts2[3] ^ ts5[3] ^ pp43;
  assign t96 = (ts2[3] & ts5[3]) | (ts2[3] & pp43) | (ts5[3] & pp43);
  assign t97 = tc5 ^ t71 ^ t77;
  assign t98 = (tc5 & t71) | (tc5 & t77) | (t71 & t77);
  assign t99 = t72 ^ t78 ^ t79;
  assign t100 = (t72 & t78) | (t72 & t79) | (t78 & t79);
  assign t101 = ts8[2] ^ t80 ^ t81;
  assign t102 = (ts8[2] & t80) | (ts8[2] & t81) | (t80 & t81);
  assign t103 = ts8[3] ^ t82 ^ t83;
  assign t104 = (ts8[3] & t82) | (ts8[3] & t83) | (t82 & t83);
  assign t105 = t73 ^ t84 ^ t85;
  assign t106 = (t73 & t84) | (t73 & t85) | (t84 & t85);
  assign t107 = t74 ^ t86 ^ t87;
  assign t108 = (t74 & t86) | (t74 & t87) | (t86 & t87);
  assign t109 = ts4[2] ^ ts7[2] ^ t88;
  assign t110 = (ts4[2] & ts7[2]) | (ts4[2] & t88) | (ts7[2] & t88);
  assign t111 = ts4[3] ^ ts7[3];
  assign t112 = ts4[3] & ts7[3];
  logic [15:0] row_s, row_c;
  assign row_s = {t110, t108, t106, t104, t102, t100, t98, t96, t94, t92, t90, t75, ts1[3], ts1[2], ts1[1], ts1[0]};
  assign row_c = {t111, t109, t107, t105, t103, t101, t99, t97, t95, t93, t91, t89, neg24, 1'b0, 1'b0, 1'b0};
  fam_adder_manchester_carry_chain #(.W(16), .SEG(2), .VARSKIP(0)) u_cpa (.a(row_s), .b(row_c), .cin(1'b0), .s(p), .cout());
endmodule


module fam_mul_direct_dadda_3_2_w11_u_pf6dd732b (input logic [10:0] a, input logic [10:0] b, output logic [21:0] p);
  // direct_pp_parallel: {'pp_bits': 121, 'full_adders': 0, 'half_adders': 2, 'cells': 0, 'tree_depth': 34}
  logic pp0, pp1, pp2, pp3, pp4, pp5, pp6, pp7, pp8, pp9, pp10, pp11, pp12, pp13, pp14, pp15, pp16, pp17, pp18, pp19, pp20, pp21, pp22, pp23, pp24, pp25, pp26, pp27, pp28, pp29, pp30, pp31, pp32, pp33, pp34, pp35, pp36, pp37, pp38, pp39, pp40, pp41, pp42, pp43, pp44, pp45, pp46, pp47, pp48, pp49, pp50, pp51, pp52, pp53, pp54, pp55, pp56, pp57, pp58, pp59, pp60, pp61, pp62, pp63, pp64, pp65, pp66, pp67, pp68, pp69, pp70, pp71, pp72, pp73, pp74, pp75, pp76, pp77, pp78, pp79, pp80, pp81, pp82, pp83, pp84, pp85, pp86, pp87, pp88, pp89, pp90, pp91, pp92, pp93, pp94, pp95, pp96, pp97, pp98, pp99, pp100, pp101, pp102, pp103, pp104, pp105, pp106, pp107, pp108, pp109, pp110, pp111, pp112, pp113, pp114, pp115, pp116, pp117, pp118, pp119, pp120, t121, t122, t123, t124;
  logic [1:0] ts1; logic tc1;
  // tile 1 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i1 (.a({pp1, pp0}), .b({pp11, 1'b0}), .cin(1'b0), .s(ts1), .cout(tc1));
  logic [1:0] ts2; logic tc2;
  // tile 2 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i2 (.a({pp3, pp2}), .b({pp13, pp12}), .cin(1'b0), .s(ts2), .cout(tc2));
  logic [1:0] ts3; logic tc3;
  // tile 3 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i3 (.a({pp5, pp4}), .b({pp15, pp14}), .cin(1'b0), .s(ts3), .cout(tc3));
  logic [1:0] ts4; logic tc4;
  // tile 4 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i4 (.a({pp7, pp6}), .b({pp17, pp16}), .cin(1'b0), .s(ts4), .cout(tc4));
  logic [1:0] ts5; logic tc5;
  // tile 5 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i5 (.a({pp9, pp8}), .b({pp19, pp18}), .cin(1'b0), .s(ts5), .cout(tc5));
  logic [1:0] ts6; logic tc6;
  // tile 6 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i6 (.a({pp21, pp10}), .b({pp31, pp20}), .cin(1'b0), .s(ts6), .cout(tc6));
  logic [1:0] ts7; logic tc7;
  // tile 7 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i7 (.a({pp43, pp32}), .b({pp53, pp42}), .cin(1'b0), .s(ts7), .cout(tc7));
  logic [1:0] ts8; logic tc8;
  // tile 8 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i8 (.a({pp65, pp54}), .b({pp75, pp64}), .cin(1'b0), .s(ts8), .cout(tc8));
  logic [1:0] ts9; logic tc9;
  // tile 9 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i9 (.a({pp87, pp76}), .b({pp97, pp86}), .cin(1'b0), .s(ts9), .cout(tc9));
  logic [1:0] ts10; logic tc10;
  // tile 10 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i10 (.a({pp109, pp98}), .b({pp119, pp108}), .cin(1'b0), .s(ts10), .cout(tc10));
  logic [1:0] ts11; logic tc11;
  // tile 11 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i11 (.a({pp23, pp22}), .b({pp33, 1'b0}), .cin(1'b0), .s(ts11), .cout(tc11));
  logic [1:0] ts12; logic tc12;
  // tile 12 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i12 (.a({pp25, pp24}), .b({pp35, pp34}), .cin(1'b0), .s(ts12), .cout(tc12));
  logic [1:0] ts13; logic tc13;
  // tile 13 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i13 (.a({pp27, pp26}), .b({pp37, pp36}), .cin(1'b0), .s(ts13), .cout(tc13));
  logic [1:0] ts14; logic tc14;
  // tile 14 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i14 (.a({pp29, pp28}), .b({pp39, pp38}), .cin(1'b0), .s(ts14), .cout(tc14));
  logic [1:0] ts15; logic tc15;
  // tile 15 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i15 (.a({pp41, pp30}), .b({pp51, pp40}), .cin(1'b0), .s(ts15), .cout(tc15));
  logic [1:0] ts16; logic tc16;
  // tile 16 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i16 (.a({pp63, pp52}), .b({pp73, pp62}), .cin(1'b0), .s(ts16), .cout(tc16));
  logic [1:0] ts17; logic tc17;
  // tile 17 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i17 (.a({pp85, pp74}), .b({pp95, pp84}), .cin(1'b0), .s(ts17), .cout(tc17));
  logic [1:0] ts18; logic tc18;
  // tile 18 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i18 (.a({pp107, pp96}), .b({pp117, pp106}), .cin(1'b0), .s(ts18), .cout(tc18));
  logic [1:0] ts19; logic tc19;
  // tile 19 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i19 (.a({pp45, pp44}), .b({pp55, 1'b0}), .cin(1'b0), .s(ts19), .cout(tc19));
  logic [1:0] ts20; logic tc20;
  // tile 20 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i20 (.a({pp47, pp46}), .b({pp57, pp56}), .cin(1'b0), .s(ts20), .cout(tc20));
  logic [1:0] ts21; logic tc21;
  // tile 21 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i21 (.a({pp49, pp48}), .b({pp59, pp58}), .cin(1'b0), .s(ts21), .cout(tc21));
  logic [1:0] ts22; logic tc22;
  // tile 22 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i22 (.a({pp61, pp50}), .b({pp71, pp60}), .cin(1'b0), .s(ts22), .cout(tc22));
  logic [1:0] ts23; logic tc23;
  // tile 23 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i23 (.a({pp83, pp72}), .b({pp93, pp82}), .cin(1'b0), .s(ts23), .cout(tc23));
  logic [1:0] ts24; logic tc24;
  // tile 24 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i24 (.a({pp105, pp94}), .b({pp115, pp104}), .cin(1'b0), .s(ts24), .cout(tc24));
  logic [1:0] ts25; logic tc25;
  // tile 25 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i25 (.a({pp67, pp66}), .b({pp77, 1'b0}), .cin(1'b0), .s(ts25), .cout(tc25));
  logic [1:0] ts26; logic tc26;
  // tile 26 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i26 (.a({pp69, pp68}), .b({pp79, pp78}), .cin(1'b0), .s(ts26), .cout(tc26));
  logic [1:0] ts27; logic tc27;
  // tile 27 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i27 (.a({pp81, pp70}), .b({pp91, pp80}), .cin(1'b0), .s(ts27), .cout(tc27));
  logic [1:0] ts28; logic tc28;
  // tile 28 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i28 (.a({pp103, pp92}), .b({pp113, pp102}), .cin(1'b0), .s(ts28), .cout(tc28));
  logic [1:0] ts29; logic tc29;
  // tile 29 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i29 (.a({pp89, pp88}), .b({pp99, 1'b0}), .cin(1'b0), .s(ts29), .cout(tc29));
  logic [1:0] ts30; logic tc30;
  // tile 30 (compound_flagged_prefix, 2 bits) at level 0
  fam_prefix_brent_kung_w2_flagm_dual u_i30 (.a({pp101, pp90}), .b({pp111, pp100}), .cin(1'b0), .s(ts30), .cout(tc30));
  logic [1:0] ts31; logic tc31;
  // tile 31 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i31 (.a({ts2[0], ts1[1]}), .b({ts11[0], 1'b0}), .cin(1'b0), .s(ts31), .cout(tc31));
  logic [1:0] ts32; logic tc32;
  // tile 32 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i32 (.a({ts3[0], ts2[1]}), .b({ts12[0], ts11[1]}), .cin(1'b0), .s(ts32), .cout(tc32));
  logic [1:0] ts33; logic tc33;
  // tile 33 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i33 (.a({ts4[0], ts3[1]}), .b({ts13[0], ts12[1]}), .cin(1'b0), .s(ts33), .cout(tc33));
  logic [1:0] ts34; logic tc34;
  // tile 34 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i34 (.a({ts5[0], ts4[1]}), .b({ts14[0], ts13[1]}), .cin(1'b0), .s(ts34), .cout(tc34));
  logic [1:0] ts35; logic tc35;
  // tile 35 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i35 (.a({ts6[0], ts5[1]}), .b({ts15[0], ts14[1]}), .cin(1'b0), .s(ts35), .cout(tc35));
  logic [1:0] ts36; logic tc36;
  // tile 36 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i36 (.a({ts7[0], ts6[1]}), .b({ts16[0], ts15[1]}), .cin(1'b0), .s(ts36), .cout(tc36));
  logic [1:0] ts37; logic tc37;
  // tile 37 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i37 (.a({ts8[0], ts7[1]}), .b({ts17[0], ts16[1]}), .cin(1'b0), .s(ts37), .cout(tc37));
  logic [1:0] ts38; logic tc38;
  // tile 38 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i38 (.a({ts9[0], ts8[1]}), .b({ts18[0], ts17[1]}), .cin(1'b0), .s(ts38), .cout(tc38));
  logic [1:0] ts39; logic tc39;
  // tile 39 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i39 (.a({ts10[0], ts9[1]}), .b({pp118, ts18[1]}), .cin(1'b0), .s(ts39), .cout(tc39));
  logic [1:0] ts40; logic tc40;
  // tile 40 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i40 (.a({ts20[0], ts19[1]}), .b({ts25[0], 1'b0}), .cin(1'b0), .s(ts40), .cout(tc40));
  logic [1:0] ts41; logic tc41;
  // tile 41 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i41 (.a({ts21[0], ts20[1]}), .b({ts26[0], ts25[1]}), .cin(1'b0), .s(ts41), .cout(tc41));
  logic [1:0] ts42; logic tc42;
  // tile 42 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i42 (.a({ts22[0], ts21[1]}), .b({ts27[0], ts26[1]}), .cin(1'b0), .s(ts42), .cout(tc42));
  logic [1:0] ts43; logic tc43;
  // tile 43 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i43 (.a({ts23[0], ts22[1]}), .b({ts28[0], ts27[1]}), .cin(1'b0), .s(ts43), .cout(tc43));
  logic [1:0] ts44; logic tc44;
  // tile 44 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i44 (.a({ts24[0], ts23[1]}), .b({pp114, ts28[1]}), .cin(1'b0), .s(ts44), .cout(tc44));
  logic [1:0] ts45; logic tc45;
  // tile 45 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i45 (.a({ts30[0], ts29[1]}), .b({pp110, 1'b0}), .cin(1'b0), .s(ts45), .cout(tc45));
  logic [1:0] ts46; logic tc46;
  // tile 46 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i46 (.a({tc2, 1'b0}), .b({tc11, 1'b0}), .cin(1'b0), .s(ts46), .cout(tc46));
  logic [1:0] ts47; logic tc47;
  // tile 47 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i47 (.a({tc3, 1'b0}), .b({tc12, 1'b0}), .cin(1'b0), .s(ts47), .cout(tc47));
  logic [1:0] ts48; logic tc48;
  // tile 48 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i48 (.a({tc4, 1'b0}), .b({tc13, 1'b0}), .cin(1'b0), .s(ts48), .cout(tc48));
  logic [1:0] ts49; logic tc49;
  // tile 49 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i49 (.a({tc5, 1'b0}), .b({tc14, 1'b0}), .cin(1'b0), .s(ts49), .cout(tc49));
  logic [1:0] ts50; logic tc50;
  // tile 50 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i50 (.a({tc6, 1'b0}), .b({tc15, 1'b0}), .cin(1'b0), .s(ts50), .cout(tc50));
  logic [1:0] ts51; logic tc51;
  // tile 51 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i51 (.a({tc7, 1'b0}), .b({tc16, 1'b0}), .cin(1'b0), .s(ts51), .cout(tc51));
  logic [1:0] ts52; logic tc52;
  // tile 52 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i52 (.a({tc8, 1'b0}), .b({tc17, 1'b0}), .cin(1'b0), .s(ts52), .cout(tc52));
  logic [1:0] ts53; logic tc53;
  // tile 53 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i53 (.a({tc9, 1'b0}), .b({tc18, 1'b0}), .cin(1'b0), .s(ts53), .cout(tc53));
  logic [1:0] ts54; logic tc54;
  // tile 54 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i54 (.a({tc20, 1'b0}), .b({tc25, 1'b0}), .cin(1'b0), .s(ts54), .cout(tc54));
  logic [1:0] ts55; logic tc55;
  // tile 55 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i55 (.a({tc21, 1'b0}), .b({tc26, 1'b0}), .cin(1'b0), .s(ts55), .cout(tc55));
  logic [1:0] ts56; logic tc56;
  // tile 56 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i56 (.a({tc22, 1'b0}), .b({tc27, 1'b0}), .cin(1'b0), .s(ts56), .cout(tc56));
  logic [1:0] ts57; logic tc57;
  // tile 57 (compound_flagged_prefix, 2 bits) at level 1
  fam_prefix_brent_kung_w2_flagm_dual u_i57 (.a({tc23, 1'b0}), .b({tc28, 1'b0}), .cin(1'b0), .s(ts57), .cout(tc57));
  logic [1:0] ts58; logic tc58;
  // tile 58 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i58 (.a({ts33[0], ts32[1]}), .b({ts40[0], ts19[0]}), .cin(1'b0), .s(ts58), .cout(tc58));
  logic [1:0] ts59; logic tc59;
  // tile 59 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i59 (.a({ts34[0], ts33[1]}), .b({ts41[0], ts40[1]}), .cin(1'b0), .s(ts59), .cout(tc59));
  logic [1:0] ts60; logic tc60;
  // tile 60 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i60 (.a({ts35[0], ts34[1]}), .b({ts42[0], ts41[1]}), .cin(1'b0), .s(ts60), .cout(tc60));
  logic [1:0] ts61; logic tc61;
  // tile 61 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i61 (.a({ts36[0], ts35[1]}), .b({ts43[0], ts42[1]}), .cin(1'b0), .s(ts61), .cout(tc61));
  logic [1:0] ts62; logic tc62;
  // tile 62 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i62 (.a({ts37[0], ts36[1]}), .b({ts44[0], ts43[1]}), .cin(1'b0), .s(ts62), .cout(tc62));
  logic [1:0] ts63; logic tc63;
  // tile 63 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i63 (.a({ts38[0], ts37[1]}), .b({ts24[1], ts44[1]}), .cin(1'b0), .s(ts63), .cout(tc63));
  logic [1:0] ts64; logic tc64;
  // tile 64 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i64 (.a({ts39[0], ts38[1]}), .b({1'b0, pp116}), .cin(1'b0), .s(ts64), .cout(tc64));
  logic [1:0] ts65; logic tc65;
  // tile 65 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i65 (.a({ts45[0], ts29[0]}), .b({ts49[0], ts48[1]}), .cin(1'b0), .s(ts65), .cout(tc65));
  logic [1:0] ts66; logic tc66;
  // tile 66 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i66 (.a({ts30[1], ts45[1]}), .b({ts50[0], ts49[1]}), .cin(1'b0), .s(ts66), .cout(tc66));
  logic [1:0] ts67; logic tc67;
  // tile 67 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i67 (.a({1'b0, pp112}), .b({ts51[0], ts50[1]}), .cin(1'b0), .s(ts67), .cout(tc67));
  logic [1:0] ts68; logic tc68;
  // tile 68 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i68 (.a({ts56[0], ts55[1]}), .b({1'b0, tc29}), .cin(1'b0), .s(ts68), .cout(tc68));
  logic [1:0] ts69; logic tc69;
  // tile 69 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i69 (.a({ts57[0], ts56[1]}), .b({1'b0, tc30}), .cin(1'b0), .s(ts69), .cout(tc69));
  logic [1:0] ts70; logic tc70;
  // tile 70 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i70 (.a({tc33, 1'b0}), .b({tc40, 1'b0}), .cin(1'b0), .s(ts70), .cout(tc70));
  logic [1:0] ts71; logic tc71;
  // tile 71 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i71 (.a({tc34, 1'b0}), .b({tc41, 1'b0}), .cin(1'b0), .s(ts71), .cout(tc71));
  logic [1:0] ts72; logic tc72;
  // tile 72 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i72 (.a({tc35, 1'b0}), .b({tc42, 1'b0}), .cin(1'b0), .s(ts72), .cout(tc72));
  logic [1:0] ts73; logic tc73;
  // tile 73 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i73 (.a({tc36, 1'b0}), .b({tc43, 1'b0}), .cin(1'b0), .s(ts73), .cout(tc73));
  logic [1:0] ts74; logic tc74;
  // tile 74 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i74 (.a({tc37, 1'b0}), .b({tc44, 1'b0}), .cin(1'b0), .s(ts74), .cout(tc74));
  logic [1:0] ts75; logic tc75;
  // tile 75 (compound_flagged_prefix, 2 bits) at level 2
  fam_prefix_brent_kung_w2_flagm_dual u_i75 (.a({tc45, 1'b0}), .b({tc49, 1'b0}), .cin(1'b0), .s(ts75), .cout(tc75));
  logic [1:0] ts76; logic tc76;
  // tile 76 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i76 (.a({ts31[1], ts31[0]}), .b({tc1, 1'b0}), .cin(1'b0), .s(ts76), .cout(tc76));
  logic [1:0] ts77; logic tc77;
  // tile 77 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i77 (.a({ts58[0], ts32[0]}), .b({ts46[1], ts46[0]}), .cin(1'b0), .s(ts77), .cout(tc77));
  logic [1:0] ts78; logic tc78;
  // tile 78 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i78 (.a({ts59[0], ts58[1]}), .b({ts47[1], ts47[0]}), .cin(1'b0), .s(ts78), .cout(tc78));
  logic [1:0] ts79; logic tc79;
  // tile 79 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i79 (.a({ts60[0], ts59[1]}), .b({ts65[0], ts48[0]}), .cin(1'b0), .s(ts79), .cout(tc79));
  logic [1:0] ts80; logic tc80;
  // tile 80 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i80 (.a({ts61[0], ts60[1]}), .b({ts66[0], ts65[1]}), .cin(1'b0), .s(ts80), .cout(tc80));
  logic [1:0] ts81; logic tc81;
  // tile 81 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i81 (.a({ts62[0], ts61[1]}), .b({ts67[0], ts66[1]}), .cin(1'b0), .s(ts81), .cout(tc81));
  logic [1:0] ts82; logic tc82;
  // tile 82 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i82 (.a({ts63[0], ts62[1]}), .b({ts51[1], ts67[1]}), .cin(1'b0), .s(ts82), .cout(tc82));
  logic [1:0] ts83; logic tc83;
  // tile 83 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i83 (.a({ts64[0], ts63[1]}), .b({ts52[1], ts52[0]}), .cin(1'b0), .s(ts83), .cout(tc83));
  logic [1:0] ts84; logic tc84;
  // tile 84 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i84 (.a({ts39[1], ts64[1]}), .b({ts53[1], ts53[0]}), .cin(1'b0), .s(ts84), .cout(tc84));
  logic [1:0] ts85; logic tc85;
  // tile 85 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i85 (.a({pp120, ts10[1]}), .b({tc10, 1'b0}), .cin(1'b0), .s(ts85), .cout(tc85));
  logic [1:0] ts86; logic tc86;
  // tile 86 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i86 (.a({tc19, 1'b0}), .b({ts70[0], tc32}), .cin(1'b0), .s(ts86), .cout(tc86));
  logic [1:0] ts87; logic tc87;
  // tile 87 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i87 (.a({ts54[1], ts54[0]}), .b({ts71[0], ts70[1]}), .cin(1'b0), .s(ts87), .cout(tc87));
  logic [1:0] ts88; logic tc88;
  // tile 88 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i88 (.a({ts68[0], ts55[0]}), .b({ts72[0], ts71[1]}), .cin(1'b0), .s(ts88), .cout(tc88));
  logic [1:0] ts89; logic tc89;
  // tile 89 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i89 (.a({ts69[0], ts68[1]}), .b({ts73[0], ts72[1]}), .cin(1'b0), .s(ts89), .cout(tc89));
  logic [1:0] ts90; logic tc90;
  // tile 90 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i90 (.a({ts57[1], ts69[1]}), .b({ts74[0], ts73[1]}), .cin(1'b0), .s(ts90), .cout(tc90));
  logic [1:0] ts91; logic tc91;
  // tile 91 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i91 (.a({tc24, 1'b0}), .b({1'b0, ts74[1]}), .cin(1'b0), .s(ts91), .cout(tc91));
  logic [1:0] ts92; logic tc92;
  // tile 92 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i92 (.a({ts75[0], tc48}), .b({1'b0, tc54}), .cin(1'b0), .s(ts92), .cout(tc92));
  logic [1:0] ts93; logic tc93;
  // tile 93 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i93 (.a({1'b0, ts75[1]}), .b({1'b0, tc55}), .cin(1'b0), .s(ts93), .cout(tc93));
  logic [1:0] ts94; logic tc94;
  // tile 94 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i94 (.a({1'b0, tc50}), .b({1'b0, tc56}), .cin(1'b0), .s(ts94), .cout(tc94));
  logic [1:0] ts95; logic tc95;
  // tile 95 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i95 (.a({1'b0, tc51}), .b({1'b0, tc57}), .cin(1'b0), .s(ts95), .cout(tc95));
  logic [1:0] ts96; logic tc96;
  // tile 96 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i96 (.a({tc60, 1'b0}), .b({tc65, 1'b0}), .cin(1'b0), .s(ts96), .cout(tc96));
  logic [1:0] ts97; logic tc97;
  // tile 97 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i97 (.a({tc61, 1'b0}), .b({tc66, 1'b0}), .cin(1'b0), .s(ts97), .cout(tc97));
  logic [1:0] ts98; logic tc98;
  // tile 98 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i98 (.a({tc62, 1'b0}), .b({tc67, 1'b0}), .cin(1'b0), .s(ts98), .cout(tc98));
  logic [1:0] ts99; logic tc99;
  // tile 99 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i99 (.a({tc68, 1'b0}), .b({tc72, 1'b0}), .cin(1'b0), .s(ts99), .cout(tc99));
  logic [1:0] ts100; logic tc100;
  // tile 100 (compound_flagged_prefix, 2 bits) at level 3
  fam_prefix_brent_kung_w2_flagm_dual u_i100 (.a({tc69, 1'b0}), .b({tc73, 1'b0}), .cin(1'b0), .s(ts100), .cout(tc100));
  logic [1:0] ts101; logic tc101;
  // tile 101 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i101 (.a({ts77[0], ts76[1]}), .b({tc31, 1'b0}), .cin(1'b0), .s(ts101), .cout(tc101));
  logic [1:0] ts102; logic tc102;
  // tile 102 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i102 (.a({ts78[0], ts77[1]}), .b({ts86[0], 1'b0}), .cin(1'b0), .s(ts102), .cout(tc102));
  logic [1:0] ts103; logic tc103;
  // tile 103 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i103 (.a({ts79[0], ts78[1]}), .b({ts87[0], ts86[1]}), .cin(1'b0), .s(ts103), .cout(tc103));
  logic [1:0] ts104; logic tc104;
  // tile 104 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i104 (.a({ts80[0], ts79[1]}), .b({ts88[0], ts87[1]}), .cin(1'b0), .s(ts104), .cout(tc104));
  logic [1:0] ts105; logic tc105;
  // tile 105 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i105 (.a({ts81[0], ts80[1]}), .b({ts89[0], ts88[1]}), .cin(1'b0), .s(ts105), .cout(tc105));
  logic [1:0] ts106; logic tc106;
  // tile 106 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i106 (.a({ts82[0], ts81[1]}), .b({ts90[0], ts89[1]}), .cin(1'b0), .s(ts106), .cout(tc106));
  logic [1:0] ts107; logic tc107;
  // tile 107 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i107 (.a({ts83[0], ts82[1]}), .b({ts91[0], ts90[1]}), .cin(1'b0), .s(ts107), .cout(tc107));
  logic [1:0] ts108; logic tc108;
  // tile 108 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i108 (.a({ts84[0], ts83[1]}), .b({tc38, ts91[1]}), .cin(1'b0), .s(ts108), .cout(tc108));
  logic [1:0] ts109; logic tc109;
  // tile 109 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i109 (.a({ts85[0], ts84[1]}), .b({tc39, 1'b0}), .cin(1'b0), .s(ts109), .cout(tc109));
  logic [1:0] ts110; logic tc110;
  // tile 110 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i110 (.a({tc47, 1'b0}), .b({1'b0, tc58}), .cin(1'b0), .s(ts110), .cout(tc110));
  logic [1:0] ts111; logic tc111;
  // tile 111 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i111 (.a({ts92[0], 1'b0}), .b({ts96[0], tc59}), .cin(1'b0), .s(ts111), .cout(tc111));
  logic [1:0] ts112; logic tc112;
  // tile 112 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i112 (.a({ts93[0], ts92[1]}), .b({ts97[0], ts96[1]}), .cin(1'b0), .s(ts112), .cout(tc112));
  logic [1:0] ts113; logic tc113;
  // tile 113 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i113 (.a({ts94[0], ts93[1]}), .b({ts98[0], ts97[1]}), .cin(1'b0), .s(ts113), .cout(tc113));
  logic [1:0] ts114; logic tc114;
  // tile 114 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i114 (.a({ts95[0], ts94[1]}), .b({1'b0, ts98[1]}), .cin(1'b0), .s(ts114), .cout(tc114));
  logic [1:0] ts115; logic tc115;
  // tile 115 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i115 (.a({tc52, ts95[1]}), .b({1'b0, tc63}), .cin(1'b0), .s(ts115), .cout(tc115));
  logic [1:0] ts116; logic tc116;
  // tile 116 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i116 (.a({tc53, 1'b0}), .b({1'b0, tc64}), .cin(1'b0), .s(ts116), .cout(tc116));
  logic [1:0] ts117; logic tc117;
  // tile 117 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i117 (.a({ts100[0], ts99[1]}), .b({1'b0, tc75}), .cin(1'b0), .s(ts117), .cout(tc117));
  logic [1:0] ts118; logic tc118;
  // tile 118 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i118 (.a({tc78, 1'b0}), .b({tc86, 1'b0}), .cin(1'b0), .s(ts118), .cout(tc118));
  logic [1:0] ts119; logic tc119;
  // tile 119 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i119 (.a({tc79, 1'b0}), .b({tc87, 1'b0}), .cin(1'b0), .s(ts119), .cout(tc119));
  logic [1:0] ts120; logic tc120;
  // tile 120 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i120 (.a({tc80, 1'b0}), .b({tc88, 1'b0}), .cin(1'b0), .s(ts120), .cout(tc120));
  logic [1:0] ts121; logic tc121;
  // tile 121 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i121 (.a({tc81, 1'b0}), .b({tc89, 1'b0}), .cin(1'b0), .s(ts121), .cout(tc121));
  logic [1:0] ts122; logic tc122;
  // tile 122 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i122 (.a({tc82, 1'b0}), .b({tc90, 1'b0}), .cin(1'b0), .s(ts122), .cout(tc122));
  logic [1:0] ts123; logic tc123;
  // tile 123 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i123 (.a({tc83, 1'b0}), .b({tc91, 1'b0}), .cin(1'b0), .s(ts123), .cout(tc123));
  logic [1:0] ts124; logic tc124;
  // tile 124 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i124 (.a({tc92, 1'b0}), .b({tc96, 1'b0}), .cin(1'b0), .s(ts124), .cout(tc124));
  logic [1:0] ts125; logic tc125;
  // tile 125 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i125 (.a({tc93, 1'b0}), .b({tc97, 1'b0}), .cin(1'b0), .s(ts125), .cout(tc125));
  logic [1:0] ts126; logic tc126;
  // tile 126 (compound_flagged_prefix, 2 bits) at level 4
  fam_prefix_brent_kung_w2_flagm_dual u_i126 (.a({tc94, 1'b0}), .b({tc98, 1'b0}), .cin(1'b0), .s(ts126), .cout(tc126));
  logic [1:0] ts127; logic tc127;
  // tile 127 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i127 (.a({ts103[0], ts102[1]}), .b({ts110[0], tc46}), .cin(1'b0), .s(ts127), .cout(tc127));
  logic [1:0] ts128; logic tc128;
  // tile 128 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i128 (.a({ts104[0], ts103[1]}), .b({ts111[0], ts110[1]}), .cin(1'b0), .s(ts128), .cout(tc128));
  logic [1:0] ts129; logic tc129;
  // tile 129 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i129 (.a({ts105[0], ts104[1]}), .b({ts112[0], ts111[1]}), .cin(1'b0), .s(ts129), .cout(tc129));
  logic [1:0] ts130; logic tc130;
  // tile 130 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i130 (.a({ts106[0], ts105[1]}), .b({ts113[0], ts112[1]}), .cin(1'b0), .s(ts130), .cout(tc130));
  logic [1:0] ts131; logic tc131;
  // tile 131 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i131 (.a({ts107[0], ts106[1]}), .b({ts114[0], ts113[1]}), .cin(1'b0), .s(ts131), .cout(tc131));
  logic [1:0] ts132; logic tc132;
  // tile 132 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i132 (.a({ts108[0], ts107[1]}), .b({ts115[0], ts114[1]}), .cin(1'b0), .s(ts132), .cout(tc132));
  logic [1:0] ts133; logic tc133;
  // tile 133 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i133 (.a({ts109[0], ts108[1]}), .b({ts116[0], ts115[1]}), .cin(1'b0), .s(ts133), .cout(tc133));
  logic [1:0] ts134; logic tc134;
  // tile 134 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i134 (.a({ts85[1], ts109[1]}), .b({1'b0, ts116[1]}), .cin(1'b0), .s(ts134), .cout(tc134));
  logic [1:0] ts135; logic tc135;
  // tile 135 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i135 (.a({tc70, 1'b0}), .b({ts119[0], ts118[1]}), .cin(1'b0), .s(ts135), .cout(tc135));
  logic [1:0] ts136; logic tc136;
  // tile 136 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i136 (.a({tc71, 1'b0}), .b({ts120[0], ts119[1]}), .cin(1'b0), .s(ts136), .cout(tc136));
  logic [1:0] ts137; logic tc137;
  // tile 137 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i137 (.a({ts117[0], ts99[0]}), .b({ts121[0], ts120[1]}), .cin(1'b0), .s(ts137), .cout(tc137));
  logic [1:0] ts138; logic tc138;
  // tile 138 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i138 (.a({ts100[1], ts117[1]}), .b({ts122[0], ts121[1]}), .cin(1'b0), .s(ts138), .cout(tc138));
  logic [1:0] ts139; logic tc139;
  // tile 139 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i139 (.a({tc74, 1'b0}), .b({ts123[0], ts122[1]}), .cin(1'b0), .s(ts139), .cout(tc139));
  logic [1:0] ts140; logic tc140;
  // tile 140 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i140 (.a({ts126[0], ts125[1]}), .b({1'b0, tc99}), .cin(1'b0), .s(ts140), .cout(tc140));
  logic [1:0] ts141; logic tc141;
  // tile 141 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i141 (.a({1'b0, ts126[1]}), .b({1'b0, tc100}), .cin(1'b0), .s(ts141), .cout(tc141));
  logic [1:0] ts142; logic tc142;
  // tile 142 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i142 (.a({tc103, 1'b0}), .b({tc110, 1'b0}), .cin(1'b0), .s(ts142), .cout(tc142));
  logic [1:0] ts143; logic tc143;
  // tile 143 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i143 (.a({tc104, 1'b0}), .b({tc111, 1'b0}), .cin(1'b0), .s(ts143), .cout(tc143));
  logic [1:0] ts144; logic tc144;
  // tile 144 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i144 (.a({tc105, 1'b0}), .b({tc112, 1'b0}), .cin(1'b0), .s(ts144), .cout(tc144));
  logic [1:0] ts145; logic tc145;
  // tile 145 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i145 (.a({tc106, 1'b0}), .b({tc113, 1'b0}), .cin(1'b0), .s(ts145), .cout(tc145));
  logic [1:0] ts146; logic tc146;
  // tile 146 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i146 (.a({tc107, 1'b0}), .b({tc114, 1'b0}), .cin(1'b0), .s(ts146), .cout(tc146));
  logic [1:0] ts147; logic tc147;
  // tile 147 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i147 (.a({tc108, 1'b0}), .b({tc115, 1'b0}), .cin(1'b0), .s(ts147), .cout(tc147));
  logic [1:0] ts148; logic tc148;
  // tile 148 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i148 (.a({tc109, 1'b0}), .b({tc116, 1'b0}), .cin(1'b0), .s(ts148), .cout(tc148));
  logic [1:0] ts149; logic tc149;
  // tile 149 (compound_flagged_prefix, 2 bits) at level 5
  fam_prefix_brent_kung_w2_flagm_dual u_i149 (.a({tc117, 1'b0}), .b({tc121, 1'b0}), .cin(1'b0), .s(ts149), .cout(tc149));
  logic [1:0] ts150; logic tc150;
  // tile 150 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i150 (.a({ts101[1], ts101[0]}), .b({tc76, 1'b0}), .cin(1'b0), .s(ts150), .cout(tc150));
  logic [1:0] ts151; logic tc151;
  // tile 151 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i151 (.a({ts127[0], ts102[0]}), .b({tc77, 1'b0}), .cin(1'b0), .s(ts151), .cout(tc151));
  logic [1:0] ts152; logic tc152;
  // tile 152 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i152 (.a({ts128[0], ts127[1]}), .b({ts135[0], ts118[0]}), .cin(1'b0), .s(ts152), .cout(tc152));
  logic [1:0] ts153; logic tc153;
  // tile 153 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i153 (.a({ts129[0], ts128[1]}), .b({ts136[0], ts135[1]}), .cin(1'b0), .s(ts153), .cout(tc153));
  logic [1:0] ts154; logic tc154;
  // tile 154 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i154 (.a({ts130[0], ts129[1]}), .b({ts137[0], ts136[1]}), .cin(1'b0), .s(ts154), .cout(tc154));
  logic [1:0] ts155; logic tc155;
  // tile 155 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i155 (.a({ts131[0], ts130[1]}), .b({ts138[0], ts137[1]}), .cin(1'b0), .s(ts155), .cout(tc155));
  logic [1:0] ts156; logic tc156;
  // tile 156 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i156 (.a({ts132[0], ts131[1]}), .b({ts139[0], ts138[1]}), .cin(1'b0), .s(ts156), .cout(tc156));
  logic [1:0] ts157; logic tc157;
  // tile 157 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i157 (.a({ts133[0], ts132[1]}), .b({ts123[1], ts139[1]}), .cin(1'b0), .s(ts157), .cout(tc157));
  logic [1:0] ts158; logic tc158;
  // tile 158 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i158 (.a({ts134[0], ts133[1]}), .b({tc84, 1'b0}), .cin(1'b0), .s(ts158), .cout(tc158));
  logic [1:0] ts159; logic tc159;
  // tile 159 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i159 (.a({1'b0, ts134[1]}), .b({tc85, 1'b0}), .cin(1'b0), .s(ts159), .cout(tc159));
  logic [1:0] ts160; logic tc160;
  // tile 160 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i160 (.a({ts124[1], ts124[0]}), .b({ts144[0], ts143[1]}), .cin(1'b0), .s(ts160), .cout(tc160));
  logic [1:0] ts161; logic tc161;
  // tile 161 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i161 (.a({ts140[0], ts125[0]}), .b({ts145[0], ts144[1]}), .cin(1'b0), .s(ts161), .cout(tc161));
  logic [1:0] ts162; logic tc162;
  // tile 162 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i162 (.a({ts141[0], ts140[1]}), .b({ts146[0], ts145[1]}), .cin(1'b0), .s(ts162), .cout(tc162));
  logic [1:0] ts163; logic tc163;
  // tile 163 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i163 (.a({tc95, ts141[1]}), .b({ts147[0], ts146[1]}), .cin(1'b0), .s(ts163), .cout(tc163));
  logic [1:0] ts164; logic tc164;
  // tile 164 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i164 (.a({ts149[0], tc120}), .b({1'b0, tc124}), .cin(1'b0), .s(ts164), .cout(tc164));
  logic [1:0] ts165; logic tc165;
  // tile 165 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i165 (.a({1'b0, ts149[1]}), .b({1'b0, tc125}), .cin(1'b0), .s(ts165), .cout(tc165));
  logic [1:0] ts166; logic tc166;
  // tile 166 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i166 (.a({1'b0, tc122}), .b({1'b0, tc126}), .cin(1'b0), .s(ts166), .cout(tc166));
  logic [1:0] ts167; logic tc167;
  // tile 167 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i167 (.a({tc128, 1'b0}), .b({tc135, 1'b0}), .cin(1'b0), .s(ts167), .cout(tc167));
  logic [1:0] ts168; logic tc168;
  // tile 168 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i168 (.a({tc129, 1'b0}), .b({tc136, 1'b0}), .cin(1'b0), .s(ts168), .cout(tc168));
  logic [1:0] ts169; logic tc169;
  // tile 169 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i169 (.a({tc130, 1'b0}), .b({tc137, 1'b0}), .cin(1'b0), .s(ts169), .cout(tc169));
  logic [1:0] ts170; logic tc170;
  // tile 170 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i170 (.a({tc131, 1'b0}), .b({tc138, 1'b0}), .cin(1'b0), .s(ts170), .cout(tc170));
  logic [1:0] ts171; logic tc171;
  // tile 171 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i171 (.a({tc132, 1'b0}), .b({tc139, 1'b0}), .cin(1'b0), .s(ts171), .cout(tc171));
  logic [1:0] ts172; logic tc172;
  // tile 172 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i172 (.a({tc140, 1'b0}), .b({tc145, 1'b0}), .cin(1'b0), .s(ts172), .cout(tc172));
  logic [1:0] ts173; logic tc173;
  // tile 173 (compound_flagged_prefix, 2 bits) at level 6
  fam_prefix_brent_kung_w2_flagm_dual u_i173 (.a({tc141, 1'b0}), .b({tc146, 1'b0}), .cin(1'b0), .s(ts173), .cout(tc173));
  logic [1:0] ts174; logic tc174;
  // tile 174 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i174 (.a({ts151[0], ts150[1]}), .b({tc101, 1'b0}), .cin(1'b0), .s(ts174), .cout(tc174));
  logic [1:0] ts175; logic tc175;
  // tile 175 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i175 (.a({ts152[0], ts151[1]}), .b({tc102, 1'b0}), .cin(1'b0), .s(ts175), .cout(tc175));
  logic [1:0] ts176; logic tc176;
  // tile 176 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i176 (.a({ts153[0], ts152[1]}), .b({ts142[1], ts142[0]}), .cin(1'b0), .s(ts176), .cout(tc176));
  logic [1:0] ts177; logic tc177;
  // tile 177 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i177 (.a({ts154[0], ts153[1]}), .b({ts160[0], ts143[0]}), .cin(1'b0), .s(ts177), .cout(tc177));
  logic [1:0] ts178; logic tc178;
  // tile 178 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i178 (.a({ts155[0], ts154[1]}), .b({ts161[0], ts160[1]}), .cin(1'b0), .s(ts178), .cout(tc178));
  logic [1:0] ts179; logic tc179;
  // tile 179 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i179 (.a({ts156[0], ts155[1]}), .b({ts162[0], ts161[1]}), .cin(1'b0), .s(ts179), .cout(tc179));
  logic [1:0] ts180; logic tc180;
  // tile 180 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i180 (.a({ts157[0], ts156[1]}), .b({ts163[0], ts162[1]}), .cin(1'b0), .s(ts180), .cout(tc180));
  logic [1:0] ts181; logic tc181;
  // tile 181 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i181 (.a({ts158[0], ts157[1]}), .b({ts147[1], ts163[1]}), .cin(1'b0), .s(ts181), .cout(tc181));
  logic [1:0] ts182; logic tc182;
  // tile 182 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i182 (.a({ts159[0], ts158[1]}), .b({ts148[1], ts148[0]}), .cin(1'b0), .s(ts182), .cout(tc182));
  logic [1:0] ts183; logic tc183;
  // tile 183 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i183 (.a({tc118, 1'b0}), .b({ts167[0], tc127}), .cin(1'b0), .s(ts183), .cout(tc183));
  logic [1:0] ts184; logic tc184;
  // tile 184 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i184 (.a({tc119, 1'b0}), .b({ts168[0], ts167[1]}), .cin(1'b0), .s(ts184), .cout(tc184));
  logic [1:0] ts185; logic tc185;
  // tile 185 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i185 (.a({ts164[0], 1'b0}), .b({ts169[0], ts168[1]}), .cin(1'b0), .s(ts185), .cout(tc185));
  logic [1:0] ts186; logic tc186;
  // tile 186 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i186 (.a({ts165[0], ts164[1]}), .b({ts170[0], ts169[1]}), .cin(1'b0), .s(ts186), .cout(tc186));
  logic [1:0] ts187; logic tc187;
  // tile 187 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i187 (.a({ts166[0], ts165[1]}), .b({ts171[0], ts170[1]}), .cin(1'b0), .s(ts187), .cout(tc187));
  logic [1:0] ts188; logic tc188;
  // tile 188 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i188 (.a({tc123, ts166[1]}), .b({1'b0, ts171[1]}), .cin(1'b0), .s(ts188), .cout(tc188));
  logic [1:0] ts189; logic tc189;
  // tile 189 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i189 (.a({ts173[0], ts172[1]}), .b({1'b0, tc149}), .cin(1'b0), .s(ts189), .cout(tc189));
  logic [1:0] ts190; logic tc190;
  // tile 190 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i190 (.a({tc154, 1'b0}), .b({tc160, 1'b0}), .cin(1'b0), .s(ts190), .cout(tc190));
  logic [1:0] ts191; logic tc191;
  // tile 191 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i191 (.a({tc155, 1'b0}), .b({tc161, 1'b0}), .cin(1'b0), .s(ts191), .cout(tc191));
  logic [1:0] ts192; logic tc192;
  // tile 192 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i192 (.a({tc156, 1'b0}), .b({tc162, 1'b0}), .cin(1'b0), .s(ts192), .cout(tc192));
  logic [1:0] ts193; logic tc193;
  // tile 193 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i193 (.a({tc157, 1'b0}), .b({tc163, 1'b0}), .cin(1'b0), .s(ts193), .cout(tc193));
  logic [1:0] ts194; logic tc194;
  // tile 194 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i194 (.a({tc164, 1'b0}), .b({tc169, 1'b0}), .cin(1'b0), .s(ts194), .cout(tc194));
  logic [1:0] ts195; logic tc195;
  // tile 195 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i195 (.a({tc165, 1'b0}), .b({tc170, 1'b0}), .cin(1'b0), .s(ts195), .cout(tc195));
  logic [1:0] ts196; logic tc196;
  // tile 196 (compound_flagged_prefix, 2 bits) at level 7
  fam_prefix_brent_kung_w2_flagm_dual u_i196 (.a({tc166, 1'b0}), .b({tc171, 1'b0}), .cin(1'b0), .s(ts196), .cout(tc196));
  logic [1:0] ts197; logic tc197;
  // tile 197 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i197 (.a({ts176[0], ts175[1]}), .b({ts183[0], 1'b0}), .cin(1'b0), .s(ts197), .cout(tc197));
  logic [1:0] ts198; logic tc198;
  // tile 198 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i198 (.a({ts177[0], ts176[1]}), .b({ts184[0], ts183[1]}), .cin(1'b0), .s(ts198), .cout(tc198));
  logic [1:0] ts199; logic tc199;
  // tile 199 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i199 (.a({ts178[0], ts177[1]}), .b({ts185[0], ts184[1]}), .cin(1'b0), .s(ts199), .cout(tc199));
  logic [1:0] ts200; logic tc200;
  // tile 200 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i200 (.a({ts179[0], ts178[1]}), .b({ts186[0], ts185[1]}), .cin(1'b0), .s(ts200), .cout(tc200));
  logic [1:0] ts201; logic tc201;
  // tile 201 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i201 (.a({ts180[0], ts179[1]}), .b({ts187[0], ts186[1]}), .cin(1'b0), .s(ts201), .cout(tc201));
  logic [1:0] ts202; logic tc202;
  // tile 202 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i202 (.a({ts181[0], ts180[1]}), .b({ts188[0], ts187[1]}), .cin(1'b0), .s(ts202), .cout(tc202));
  logic [1:0] ts203; logic tc203;
  // tile 203 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i203 (.a({ts182[0], ts181[1]}), .b({tc133, ts188[1]}), .cin(1'b0), .s(ts203), .cout(tc203));
  logic [1:0] ts204; logic tc204;
  // tile 204 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i204 (.a({ts159[1], ts182[1]}), .b({tc134, 1'b0}), .cin(1'b0), .s(ts204), .cout(tc204));
  logic [1:0] ts205; logic tc205;
  // tile 205 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i205 (.a({tc142, 1'b0}), .b({1'b0, tc152}), .cin(1'b0), .s(ts205), .cout(tc205));
  logic [1:0] ts206; logic tc206;
  // tile 206 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i206 (.a({tc143, 1'b0}), .b({ts190[0], tc153}), .cin(1'b0), .s(ts206), .cout(tc206));
  logic [1:0] ts207; logic tc207;
  // tile 207 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i207 (.a({tc144, 1'b0}), .b({ts191[0], ts190[1]}), .cin(1'b0), .s(ts207), .cout(tc207));
  logic [1:0] ts208; logic tc208;
  // tile 208 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i208 (.a({ts189[0], ts172[0]}), .b({ts192[0], ts191[1]}), .cin(1'b0), .s(ts208), .cout(tc208));
  logic [1:0] ts209; logic tc209;
  // tile 209 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i209 (.a({ts173[1], ts189[1]}), .b({ts193[0], ts192[1]}), .cin(1'b0), .s(ts209), .cout(tc209));
  logic [1:0] ts210; logic tc210;
  // tile 210 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i210 (.a({tc147, 1'b0}), .b({1'b0, ts193[1]}), .cin(1'b0), .s(ts210), .cout(tc210));
  logic [1:0] ts211; logic tc211;
  // tile 211 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i211 (.a({tc148, 1'b0}), .b({1'b0, tc158}), .cin(1'b0), .s(ts211), .cout(tc211));
  logic [1:0] ts212; logic tc212;
  // tile 212 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i212 (.a({ts196[0], ts195[1]}), .b({1'b0, tc172}), .cin(1'b0), .s(ts212), .cout(tc212));
  logic [1:0] ts213; logic tc213;
  // tile 213 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i213 (.a({1'b0, ts196[1]}), .b({1'b0, tc173}), .cin(1'b0), .s(ts213), .cout(tc213));
  logic [1:0] ts214; logic tc214;
  // tile 214 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i214 (.a({tc176, 1'b0}), .b({tc183, 1'b0}), .cin(1'b0), .s(ts214), .cout(tc214));
  logic [1:0] ts215; logic tc215;
  // tile 215 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i215 (.a({tc177, 1'b0}), .b({tc184, 1'b0}), .cin(1'b0), .s(ts215), .cout(tc215));
  logic [1:0] ts216; logic tc216;
  // tile 216 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i216 (.a({tc178, 1'b0}), .b({tc185, 1'b0}), .cin(1'b0), .s(ts216), .cout(tc216));
  logic [1:0] ts217; logic tc217;
  // tile 217 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i217 (.a({tc179, 1'b0}), .b({tc186, 1'b0}), .cin(1'b0), .s(ts217), .cout(tc217));
  logic [1:0] ts218; logic tc218;
  // tile 218 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i218 (.a({tc180, 1'b0}), .b({tc187, 1'b0}), .cin(1'b0), .s(ts218), .cout(tc218));
  logic [1:0] ts219; logic tc219;
  // tile 219 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i219 (.a({tc181, 1'b0}), .b({tc188, 1'b0}), .cin(1'b0), .s(ts219), .cout(tc219));
  logic [1:0] ts220; logic tc220;
  // tile 220 (compound_flagged_prefix, 2 bits) at level 8
  fam_prefix_brent_kung_w2_flagm_dual u_i220 (.a({tc189, 1'b0}), .b({tc192, 1'b0}), .cin(1'b0), .s(ts220), .cout(tc220));
  logic [1:0] ts221; logic tc221;
  // tile 221 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i221 (.a({ts174[1], ts174[0]}), .b({tc150, 1'b0}), .cin(1'b0), .s(ts221), .cout(tc221));
  logic [1:0] ts222; logic tc222;
  // tile 222 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i222 (.a({ts197[0], ts175[0]}), .b({tc151, 1'b0}), .cin(1'b0), .s(ts222), .cout(tc222));
  logic [1:0] ts223; logic tc223;
  // tile 223 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i223 (.a({ts198[0], ts197[1]}), .b({ts205[0], 1'b0}), .cin(1'b0), .s(ts223), .cout(tc223));
  logic [1:0] ts224; logic tc224;
  // tile 224 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i224 (.a({ts199[0], ts198[1]}), .b({ts206[0], ts205[1]}), .cin(1'b0), .s(ts224), .cout(tc224));
  logic [1:0] ts225; logic tc225;
  // tile 225 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i225 (.a({ts200[0], ts199[1]}), .b({ts207[0], ts206[1]}), .cin(1'b0), .s(ts225), .cout(tc225));
  logic [1:0] ts226; logic tc226;
  // tile 226 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i226 (.a({ts201[0], ts200[1]}), .b({ts208[0], ts207[1]}), .cin(1'b0), .s(ts226), .cout(tc226));
  logic [1:0] ts227; logic tc227;
  // tile 227 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i227 (.a({ts202[0], ts201[1]}), .b({ts209[0], ts208[1]}), .cin(1'b0), .s(ts227), .cout(tc227));
  logic [1:0] ts228; logic tc228;
  // tile 228 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i228 (.a({ts203[0], ts202[1]}), .b({ts210[0], ts209[1]}), .cin(1'b0), .s(ts228), .cout(tc228));
  logic [1:0] ts229; logic tc229;
  // tile 229 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i229 (.a({ts204[0], ts203[1]}), .b({ts211[0], ts210[1]}), .cin(1'b0), .s(ts229), .cout(tc229));
  logic ts230; logic tc230;
  // tile 230 (compound_flagged_prefix, 1 bits) at level 9
  fam_prefix_brent_kung_w1_flagm_dual u_i230 (.a({ts204[1]}), .b({ts211[1]}), .cin(1'b0), .s(ts230), .cout(tc230));
  logic [1:0] ts231; logic tc231;
  // tile 231 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i231 (.a({tc167, 1'b0}), .b({ts215[0], ts214[1]}), .cin(1'b0), .s(ts231), .cout(tc231));
  logic [1:0] ts232; logic tc232;
  // tile 232 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i232 (.a({tc168, 1'b0}), .b({ts216[0], ts215[1]}), .cin(1'b0), .s(ts232), .cout(tc232));
  logic [1:0] ts233; logic tc233;
  // tile 233 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i233 (.a({ts194[1], ts194[0]}), .b({ts217[0], ts216[1]}), .cin(1'b0), .s(ts233), .cout(tc233));
  logic [1:0] ts234; logic tc234;
  // tile 234 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i234 (.a({ts212[0], ts195[0]}), .b({ts218[0], ts217[1]}), .cin(1'b0), .s(ts234), .cout(tc234));
  logic [1:0] ts235; logic tc235;
  // tile 235 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i235 (.a({ts213[0], ts212[1]}), .b({ts219[0], ts218[1]}), .cin(1'b0), .s(ts235), .cout(tc235));
  logic [1:0] ts236; logic tc236;
  // tile 236 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i236 (.a({1'b0, ts213[1]}), .b({1'b0, ts219[1]}), .cin(1'b0), .s(ts236), .cout(tc236));
  logic [1:0] ts237; logic tc237;
  // tile 237 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i237 (.a({ts220[0], tc191}), .b({1'b0, tc194}), .cin(1'b0), .s(ts237), .cout(tc237));
  logic [1:0] ts238; logic tc238;
  // tile 238 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i238 (.a({1'b0, ts220[1]}), .b({1'b0, tc195}), .cin(1'b0), .s(ts238), .cout(tc238));
  logic [1:0] ts239; logic tc239;
  // tile 239 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i239 (.a({1'b0, tc193}), .b({1'b0, tc196}), .cin(1'b0), .s(ts239), .cout(tc239));
  logic [1:0] ts240; logic tc240;
  // tile 240 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i240 (.a({tc198, 1'b0}), .b({tc205, 1'b0}), .cin(1'b0), .s(ts240), .cout(tc240));
  logic [1:0] ts241; logic tc241;
  // tile 241 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i241 (.a({tc199, 1'b0}), .b({tc206, 1'b0}), .cin(1'b0), .s(ts241), .cout(tc241));
  logic [1:0] ts242; logic tc242;
  // tile 242 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i242 (.a({tc200, 1'b0}), .b({tc207, 1'b0}), .cin(1'b0), .s(ts242), .cout(tc242));
  logic [1:0] ts243; logic tc243;
  // tile 243 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i243 (.a({tc201, 1'b0}), .b({tc208, 1'b0}), .cin(1'b0), .s(ts243), .cout(tc243));
  logic [1:0] ts244; logic tc244;
  // tile 244 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i244 (.a({tc202, 1'b0}), .b({tc209, 1'b0}), .cin(1'b0), .s(ts244), .cout(tc244));
  logic [1:0] ts245; logic tc245;
  // tile 245 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i245 (.a({tc203, 1'b0}), .b({tc210, 1'b0}), .cin(1'b0), .s(ts245), .cout(tc245));
  logic [1:0] ts246; logic tc246;
  // tile 246 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i246 (.a({tc212, 1'b0}), .b({tc218, 1'b0}), .cin(1'b0), .s(ts246), .cout(tc246));
  logic [1:0] ts247; logic tc247;
  // tile 247 (compound_flagged_prefix, 2 bits) at level 9
  fam_prefix_brent_kung_w2_flagm_dual u_i247 (.a({tc213, 1'b0}), .b({tc219, 1'b0}), .cin(1'b0), .s(ts247), .cout(tc247));
  logic [1:0] ts248; logic tc248;
  // tile 248 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i248 (.a({ts222[0], ts221[1]}), .b({tc174, 1'b0}), .cin(1'b0), .s(ts248), .cout(tc248));
  logic [1:0] ts249; logic tc249;
  // tile 249 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i249 (.a({ts223[0], ts222[1]}), .b({tc175, 1'b0}), .cin(1'b0), .s(ts249), .cout(tc249));
  logic [1:0] ts250; logic tc250;
  // tile 250 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i250 (.a({ts224[0], ts223[1]}), .b({ts231[0], ts214[0]}), .cin(1'b0), .s(ts250), .cout(tc250));
  logic [1:0] ts251; logic tc251;
  // tile 251 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i251 (.a({ts225[0], ts224[1]}), .b({ts232[0], ts231[1]}), .cin(1'b0), .s(ts251), .cout(tc251));
  logic [1:0] ts252; logic tc252;
  // tile 252 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i252 (.a({ts226[0], ts225[1]}), .b({ts233[0], ts232[1]}), .cin(1'b0), .s(ts252), .cout(tc252));
  logic [1:0] ts253; logic tc253;
  // tile 253 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i253 (.a({ts227[0], ts226[1]}), .b({ts234[0], ts233[1]}), .cin(1'b0), .s(ts253), .cout(tc253));
  logic [1:0] ts254; logic tc254;
  // tile 254 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i254 (.a({ts228[0], ts227[1]}), .b({ts235[0], ts234[1]}), .cin(1'b0), .s(ts254), .cout(tc254));
  logic [1:0] ts255; logic tc255;
  // tile 255 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i255 (.a({ts229[0], ts228[1]}), .b({ts236[0], ts235[1]}), .cin(1'b0), .s(ts255), .cout(tc255));
  logic [1:0] ts256; logic tc256;
  // tile 256 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i256 (.a({ts230, ts229[1]}), .b({tc182, ts236[1]}), .cin(1'b0), .s(ts256), .cout(tc256));
  logic [1:0] ts257; logic tc257;
  // tile 257 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i257 (.a({tc190, 1'b0}), .b({ts242[0], ts241[1]}), .cin(1'b0), .s(ts257), .cout(tc257));
  logic [1:0] ts258; logic tc258;
  // tile 258 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i258 (.a({ts237[0], 1'b0}), .b({ts243[0], ts242[1]}), .cin(1'b0), .s(ts258), .cout(tc258));
  logic [1:0] ts259; logic tc259;
  // tile 259 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i259 (.a({ts238[0], ts237[1]}), .b({ts244[0], ts243[1]}), .cin(1'b0), .s(ts259), .cout(tc259));
  logic [1:0] ts260; logic tc260;
  // tile 260 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i260 (.a({ts239[0], ts238[1]}), .b({ts245[0], ts244[1]}), .cin(1'b0), .s(ts260), .cout(tc260));
  logic [1:0] ts261; logic tc261;
  // tile 261 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i261 (.a({1'b0, ts239[1]}), .b({1'b0, ts245[1]}), .cin(1'b0), .s(ts261), .cout(tc261));
  logic [1:0] ts262; logic tc262;
  // tile 262 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i262 (.a({ts247[0], ts246[1]}), .b({1'b0, tc220}), .cin(1'b0), .s(ts262), .cout(tc262));
  logic [1:0] ts263; logic tc263;
  // tile 263 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i263 (.a({tc224, 1'b0}), .b({tc231, 1'b0}), .cin(1'b0), .s(ts263), .cout(tc263));
  logic [1:0] ts264; logic tc264;
  // tile 264 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i264 (.a({tc225, 1'b0}), .b({tc232, 1'b0}), .cin(1'b0), .s(ts264), .cout(tc264));
  logic [1:0] ts265; logic tc265;
  // tile 265 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i265 (.a({tc226, 1'b0}), .b({tc233, 1'b0}), .cin(1'b0), .s(ts265), .cout(tc265));
  logic [1:0] ts266; logic tc266;
  // tile 266 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i266 (.a({tc227, 1'b0}), .b({tc234, 1'b0}), .cin(1'b0), .s(ts266), .cout(tc266));
  logic [1:0] ts267; logic tc267;
  // tile 267 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i267 (.a({tc228, 1'b0}), .b({tc235, 1'b0}), .cin(1'b0), .s(ts267), .cout(tc267));
  logic [1:0] ts268; logic tc268;
  // tile 268 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i268 (.a({tc229, 1'b0}), .b({tc236, 1'b0}), .cin(1'b0), .s(ts268), .cout(tc268));
  logic [1:0] ts269; logic tc269;
  // tile 269 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i269 (.a({tc237, 1'b0}), .b({tc243, 1'b0}), .cin(1'b0), .s(ts269), .cout(tc269));
  logic [1:0] ts270; logic tc270;
  // tile 270 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i270 (.a({tc238, 1'b0}), .b({tc244, 1'b0}), .cin(1'b0), .s(ts270), .cout(tc270));
  logic [1:0] ts271; logic tc271;
  // tile 271 (compound_flagged_prefix, 2 bits) at level 10
  fam_prefix_brent_kung_w2_flagm_dual u_i271 (.a({tc239, 1'b0}), .b({tc245, 1'b0}), .cin(1'b0), .s(ts271), .cout(tc271));
  logic [1:0] ts272; logic tc272;
  // tile 272 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i272 (.a({ts250[0], ts249[1]}), .b({tc197, 1'b0}), .cin(1'b0), .s(ts272), .cout(tc272));
  logic [1:0] ts273; logic tc273;
  // tile 273 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i273 (.a({ts251[0], ts250[1]}), .b({ts240[1], ts240[0]}), .cin(1'b0), .s(ts273), .cout(tc273));
  logic [1:0] ts274; logic tc274;
  // tile 274 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i274 (.a({ts252[0], ts251[1]}), .b({ts257[0], ts241[0]}), .cin(1'b0), .s(ts274), .cout(tc274));
  logic [1:0] ts275; logic tc275;
  // tile 275 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i275 (.a({ts253[0], ts252[1]}), .b({ts258[0], ts257[1]}), .cin(1'b0), .s(ts275), .cout(tc275));
  logic [1:0] ts276; logic tc276;
  // tile 276 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i276 (.a({ts254[0], ts253[1]}), .b({ts259[0], ts258[1]}), .cin(1'b0), .s(ts276), .cout(tc276));
  logic [1:0] ts277; logic tc277;
  // tile 277 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i277 (.a({ts255[0], ts254[1]}), .b({ts260[0], ts259[1]}), .cin(1'b0), .s(ts277), .cout(tc277));
  logic [1:0] ts278; logic tc278;
  // tile 278 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i278 (.a({ts256[0], ts255[1]}), .b({ts261[0], ts260[1]}), .cin(1'b0), .s(ts278), .cout(tc278));
  logic ts279; logic tc279;
  // tile 279 (compound_flagged_prefix, 1 bits) at level 11
  fam_prefix_brent_kung_w1_flagm_dual u_i279 (.a({ts256[1]}), .b({ts261[1]}), .cin(1'b0), .s(ts279), .cout(tc279));
  logic [1:0] ts280; logic tc280;
  // tile 280 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i280 (.a({tc214, 1'b0}), .b({ts263[0], tc223}), .cin(1'b0), .s(ts280), .cout(tc280));
  logic [1:0] ts281; logic tc281;
  // tile 281 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i281 (.a({tc215, 1'b0}), .b({ts264[0], ts263[1]}), .cin(1'b0), .s(ts281), .cout(tc281));
  logic [1:0] ts282; logic tc282;
  // tile 282 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i282 (.a({tc216, 1'b0}), .b({ts265[0], ts264[1]}), .cin(1'b0), .s(ts282), .cout(tc282));
  logic [1:0] ts283; logic tc283;
  // tile 283 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i283 (.a({tc217, 1'b0}), .b({ts266[0], ts265[1]}), .cin(1'b0), .s(ts283), .cout(tc283));
  logic [1:0] ts284; logic tc284;
  // tile 284 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i284 (.a({ts262[0], ts246[0]}), .b({ts267[0], ts266[1]}), .cin(1'b0), .s(ts284), .cout(tc284));
  logic [1:0] ts285; logic tc285;
  // tile 285 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i285 (.a({ts247[1], ts262[1]}), .b({ts268[0], ts267[1]}), .cin(1'b0), .s(ts285), .cout(tc285));
  logic [1:0] ts286; logic tc286;
  // tile 286 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i286 (.a({ts271[0], ts270[1]}), .b({1'b0, tc246}), .cin(1'b0), .s(ts286), .cout(tc286));
  logic ts287; logic tc287;
  // tile 287 (compound_flagged_prefix, 1 bits) at level 11
  fam_prefix_brent_kung_w1_flagm_dual u_i287 (.a({ts271[1]}), .b({tc247}), .cin(1'b0), .s(ts287), .cout(tc287));
  logic [1:0] ts288; logic tc288;
  // tile 288 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i288 (.a({tc252, 1'b0}), .b({tc257, 1'b0}), .cin(1'b0), .s(ts288), .cout(tc288));
  logic [1:0] ts289; logic tc289;
  // tile 289 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i289 (.a({tc253, 1'b0}), .b({tc258, 1'b0}), .cin(1'b0), .s(ts289), .cout(tc289));
  logic [1:0] ts290; logic tc290;
  // tile 290 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i290 (.a({tc254, 1'b0}), .b({tc259, 1'b0}), .cin(1'b0), .s(ts290), .cout(tc290));
  logic [1:0] ts291; logic tc291;
  // tile 291 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i291 (.a({tc255, 1'b0}), .b({tc260, 1'b0}), .cin(1'b0), .s(ts291), .cout(tc291));
  logic [1:0] ts292; logic tc292;
  // tile 292 (compound_flagged_prefix, 2 bits) at level 11
  fam_prefix_brent_kung_w2_flagm_dual u_i292 (.a({tc262, 1'b0}), .b({tc267, 1'b0}), .cin(1'b0), .s(ts292), .cout(tc292));
  logic [1:0] ts293; logic tc293;
  // tile 293 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i293 (.a({ts248[1], ts248[0]}), .b({tc221, 1'b0}), .cin(1'b0), .s(ts293), .cout(tc293));
  logic [1:0] ts294; logic tc294;
  // tile 294 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i294 (.a({ts272[0], ts249[0]}), .b({tc222, 1'b0}), .cin(1'b0), .s(ts294), .cout(tc294));
  logic [1:0] ts295; logic tc295;
  // tile 295 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i295 (.a({ts273[0], ts272[1]}), .b({ts280[0], 1'b0}), .cin(1'b0), .s(ts295), .cout(tc295));
  logic [1:0] ts296; logic tc296;
  // tile 296 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i296 (.a({ts274[0], ts273[1]}), .b({ts281[0], ts280[1]}), .cin(1'b0), .s(ts296), .cout(tc296));
  logic [1:0] ts297; logic tc297;
  // tile 297 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i297 (.a({ts275[0], ts274[1]}), .b({ts282[0], ts281[1]}), .cin(1'b0), .s(ts297), .cout(tc297));
  logic [1:0] ts298; logic tc298;
  // tile 298 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i298 (.a({ts276[0], ts275[1]}), .b({ts283[0], ts282[1]}), .cin(1'b0), .s(ts298), .cout(tc298));
  logic [1:0] ts299; logic tc299;
  // tile 299 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i299 (.a({ts277[0], ts276[1]}), .b({ts284[0], ts283[1]}), .cin(1'b0), .s(ts299), .cout(tc299));
  logic [1:0] ts300; logic tc300;
  // tile 300 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i300 (.a({ts278[0], ts277[1]}), .b({ts285[0], ts284[1]}), .cin(1'b0), .s(ts300), .cout(tc300));
  logic [1:0] ts301; logic tc301;
  // tile 301 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i301 (.a({ts279, ts278[1]}), .b({ts268[1], ts285[1]}), .cin(1'b0), .s(ts301), .cout(tc301));
  logic [1:0] ts302; logic tc302;
  // tile 302 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i302 (.a({tc240, 1'b0}), .b({1'b0, tc250}), .cin(1'b0), .s(ts302), .cout(tc302));
  logic [1:0] ts303; logic tc303;
  // tile 303 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i303 (.a({tc241, 1'b0}), .b({ts288[0], tc251}), .cin(1'b0), .s(ts303), .cout(tc303));
  logic [1:0] ts304; logic tc304;
  // tile 304 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i304 (.a({tc242, 1'b0}), .b({ts289[0], ts288[1]}), .cin(1'b0), .s(ts304), .cout(tc304));
  logic [1:0] ts305; logic tc305;
  // tile 305 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i305 (.a({ts269[1], ts269[0]}), .b({ts290[0], ts289[1]}), .cin(1'b0), .s(ts305), .cout(tc305));
  logic [1:0] ts306; logic tc306;
  // tile 306 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i306 (.a({ts286[0], ts270[0]}), .b({ts291[0], ts290[1]}), .cin(1'b0), .s(ts306), .cout(tc306));
  logic [1:0] ts307; logic tc307;
  // tile 307 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i307 (.a({ts287, ts286[1]}), .b({1'b0, ts291[1]}), .cin(1'b0), .s(ts307), .cout(tc307));
  logic [1:0] ts308; logic tc308;
  // tile 308 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i308 (.a({ts292[0], tc266}), .b({1'b0, tc269}), .cin(1'b0), .s(ts308), .cout(tc308));
  logic [1:0] ts309; logic tc309;
  // tile 309 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i309 (.a({1'b0, ts292[1]}), .b({1'b0, tc270}), .cin(1'b0), .s(ts309), .cout(tc309));
  logic [1:0] ts310; logic tc310;
  // tile 310 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i310 (.a({tc273, 1'b0}), .b({tc280, 1'b0}), .cin(1'b0), .s(ts310), .cout(tc310));
  logic [1:0] ts311; logic tc311;
  // tile 311 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i311 (.a({tc274, 1'b0}), .b({tc281, 1'b0}), .cin(1'b0), .s(ts311), .cout(tc311));
  logic [1:0] ts312; logic tc312;
  // tile 312 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i312 (.a({tc275, 1'b0}), .b({tc282, 1'b0}), .cin(1'b0), .s(ts312), .cout(tc312));
  logic [1:0] ts313; logic tc313;
  // tile 313 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i313 (.a({tc276, 1'b0}), .b({tc283, 1'b0}), .cin(1'b0), .s(ts313), .cout(tc313));
  logic [1:0] ts314; logic tc314;
  // tile 314 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i314 (.a({tc277, 1'b0}), .b({tc284, 1'b0}), .cin(1'b0), .s(ts314), .cout(tc314));
  logic [1:0] ts315; logic tc315;
  // tile 315 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i315 (.a({tc278, 1'b0}), .b({tc285, 1'b0}), .cin(1'b0), .s(ts315), .cout(tc315));
  logic [1:0] ts316; logic tc316;
  // tile 316 (compound_flagged_prefix, 2 bits) at level 12
  fam_prefix_brent_kung_w2_flagm_dual u_i316 (.a({tc286, 1'b0}), .b({tc291, 1'b0}), .cin(1'b0), .s(ts316), .cout(tc316));
  logic [1:0] ts317; logic tc317;
  // tile 317 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i317 (.a({ts294[0], ts293[1]}), .b({tc248, 1'b0}), .cin(1'b0), .s(ts317), .cout(tc317));
  logic [1:0] ts318; logic tc318;
  // tile 318 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i318 (.a({ts295[0], ts294[1]}), .b({tc249, 1'b0}), .cin(1'b0), .s(ts318), .cout(tc318));
  logic [1:0] ts319; logic tc319;
  // tile 319 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i319 (.a({ts296[0], ts295[1]}), .b({ts302[0], 1'b0}), .cin(1'b0), .s(ts319), .cout(tc319));
  logic [1:0] ts320; logic tc320;
  // tile 320 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i320 (.a({ts297[0], ts296[1]}), .b({ts303[0], ts302[1]}), .cin(1'b0), .s(ts320), .cout(tc320));
  logic [1:0] ts321; logic tc321;
  // tile 321 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i321 (.a({ts298[0], ts297[1]}), .b({ts304[0], ts303[1]}), .cin(1'b0), .s(ts321), .cout(tc321));
  logic [1:0] ts322; logic tc322;
  // tile 322 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i322 (.a({ts299[0], ts298[1]}), .b({ts305[0], ts304[1]}), .cin(1'b0), .s(ts322), .cout(tc322));
  logic [1:0] ts323; logic tc323;
  // tile 323 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i323 (.a({ts300[0], ts299[1]}), .b({ts306[0], ts305[1]}), .cin(1'b0), .s(ts323), .cout(tc323));
  logic [1:0] ts324; logic tc324;
  // tile 324 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i324 (.a({ts301[0], ts300[1]}), .b({ts307[0], ts306[1]}), .cin(1'b0), .s(ts324), .cout(tc324));
  logic ts325; logic tc325;
  // tile 325 (compound_flagged_prefix, 1 bits) at level 13
  fam_prefix_brent_kung_w1_flagm_dual u_i325 (.a({ts301[1]}), .b({ts307[1]}), .cin(1'b0), .s(ts325), .cout(tc325));
  logic [1:0] ts326; logic tc326;
  // tile 326 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i326 (.a({tc263, 1'b0}), .b({ts311[0], ts310[1]}), .cin(1'b0), .s(ts326), .cout(tc326));
  logic [1:0] ts327; logic tc327;
  // tile 327 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i327 (.a({tc264, 1'b0}), .b({ts312[0], ts311[1]}), .cin(1'b0), .s(ts327), .cout(tc327));
  logic [1:0] ts328; logic tc328;
  // tile 328 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i328 (.a({tc265, 1'b0}), .b({ts313[0], ts312[1]}), .cin(1'b0), .s(ts328), .cout(tc328));
  logic [1:0] ts329; logic tc329;
  // tile 329 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i329 (.a({ts308[0], 1'b0}), .b({ts314[0], ts313[1]}), .cin(1'b0), .s(ts329), .cout(tc329));
  logic [1:0] ts330; logic tc330;
  // tile 330 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i330 (.a({ts309[0], ts308[1]}), .b({ts315[0], ts314[1]}), .cin(1'b0), .s(ts330), .cout(tc330));
  logic ts331; logic tc331;
  // tile 331 (compound_flagged_prefix, 1 bits) at level 13
  fam_prefix_brent_kung_w1_flagm_dual u_i331 (.a({ts309[1]}), .b({ts315[1]}), .cin(1'b0), .s(ts331), .cout(tc331));
  logic ts332; logic tc332;
  // tile 332 (compound_flagged_prefix, 1 bits) at level 13
  fam_prefix_brent_kung_w1_flagm_dual u_i332 (.a({ts316[1]}), .b({tc292}), .cin(1'b0), .s(ts332), .cout(tc332));
  logic [1:0] ts333; logic tc333;
  // tile 333 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i333 (.a({tc296, 1'b0}), .b({tc302, 1'b0}), .cin(1'b0), .s(ts333), .cout(tc333));
  logic [1:0] ts334; logic tc334;
  // tile 334 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i334 (.a({tc297, 1'b0}), .b({tc303, 1'b0}), .cin(1'b0), .s(ts334), .cout(tc334));
  logic [1:0] ts335; logic tc335;
  // tile 335 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i335 (.a({tc298, 1'b0}), .b({tc304, 1'b0}), .cin(1'b0), .s(ts335), .cout(tc335));
  logic [1:0] ts336; logic tc336;
  // tile 336 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i336 (.a({tc299, 1'b0}), .b({tc305, 1'b0}), .cin(1'b0), .s(ts336), .cout(tc336));
  logic [1:0] ts337; logic tc337;
  // tile 337 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i337 (.a({tc300, 1'b0}), .b({tc306, 1'b0}), .cin(1'b0), .s(ts337), .cout(tc337));
  logic [1:0] ts338; logic tc338;
  // tile 338 (compound_flagged_prefix, 2 bits) at level 13
  fam_prefix_brent_kung_w2_flagm_dual u_i338 (.a({tc308, 1'b0}), .b({tc314, 1'b0}), .cin(1'b0), .s(ts338), .cout(tc338));
  logic [1:0] ts339; logic tc339;
  // tile 339 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i339 (.a({ts319[0], ts318[1]}), .b({tc272, 1'b0}), .cin(1'b0), .s(ts339), .cout(tc339));
  logic [1:0] ts340; logic tc340;
  // tile 340 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i340 (.a({ts320[0], ts319[1]}), .b({ts326[0], ts310[0]}), .cin(1'b0), .s(ts340), .cout(tc340));
  logic [1:0] ts341; logic tc341;
  // tile 341 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i341 (.a({ts321[0], ts320[1]}), .b({ts327[0], ts326[1]}), .cin(1'b0), .s(ts341), .cout(tc341));
  logic [1:0] ts342; logic tc342;
  // tile 342 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i342 (.a({ts322[0], ts321[1]}), .b({ts328[0], ts327[1]}), .cin(1'b0), .s(ts342), .cout(tc342));
  logic [1:0] ts343; logic tc343;
  // tile 343 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i343 (.a({ts323[0], ts322[1]}), .b({ts329[0], ts328[1]}), .cin(1'b0), .s(ts343), .cout(tc343));
  logic [1:0] ts344; logic tc344;
  // tile 344 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i344 (.a({ts324[0], ts323[1]}), .b({ts330[0], ts329[1]}), .cin(1'b0), .s(ts344), .cout(tc344));
  logic [1:0] ts345; logic tc345;
  // tile 345 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i345 (.a({ts325, ts324[1]}), .b({ts331, ts330[1]}), .cin(1'b0), .s(ts345), .cout(tc345));
  logic [1:0] ts346; logic tc346;
  // tile 346 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i346 (.a({tc288, 1'b0}), .b({ts335[0], ts334[1]}), .cin(1'b0), .s(ts346), .cout(tc346));
  logic [1:0] ts347; logic tc347;
  // tile 347 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i347 (.a({tc289, 1'b0}), .b({ts336[0], ts335[1]}), .cin(1'b0), .s(ts347), .cout(tc347));
  logic [1:0] ts348; logic tc348;
  // tile 348 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i348 (.a({tc290, 1'b0}), .b({ts337[0], ts336[1]}), .cin(1'b0), .s(ts348), .cout(tc348));
  logic [1:0] ts349; logic tc349;
  // tile 349 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i349 (.a({ts332, ts316[0]}), .b({1'b0, ts337[1]}), .cin(1'b0), .s(ts349), .cout(tc349));
  logic [1:0] ts350; logic tc350;
  // tile 350 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i350 (.a({1'b0, tc310}), .b({tc320, 1'b0}), .cin(1'b0), .s(ts350), .cout(tc350));
  logic [1:0] ts351; logic tc351;
  // tile 351 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i351 (.a({1'b0, tc311}), .b({tc321, 1'b0}), .cin(1'b0), .s(ts351), .cout(tc351));
  logic [1:0] ts352; logic tc352;
  // tile 352 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i352 (.a({1'b0, tc312}), .b({tc322, 1'b0}), .cin(1'b0), .s(ts352), .cout(tc352));
  logic [1:0] ts353; logic tc353;
  // tile 353 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i353 (.a({ts338[0], tc313}), .b({tc323, 1'b0}), .cin(1'b0), .s(ts353), .cout(tc353));
  logic [1:0] ts354; logic tc354;
  // tile 354 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i354 (.a({1'b0, ts338[1]}), .b({tc324, 1'b0}), .cin(1'b0), .s(ts354), .cout(tc354));
  logic [1:0] ts355; logic tc355;
  // tile 355 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i355 (.a({tc326, 1'b0}), .b({tc333, 1'b0}), .cin(1'b0), .s(ts355), .cout(tc355));
  logic [1:0] ts356; logic tc356;
  // tile 356 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i356 (.a({tc327, 1'b0}), .b({tc334, 1'b0}), .cin(1'b0), .s(ts356), .cout(tc356));
  logic [1:0] ts357; logic tc357;
  // tile 357 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i357 (.a({tc328, 1'b0}), .b({tc335, 1'b0}), .cin(1'b0), .s(ts357), .cout(tc357));
  logic [1:0] ts358; logic tc358;
  // tile 358 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i358 (.a({tc329, 1'b0}), .b({tc336, 1'b0}), .cin(1'b0), .s(ts358), .cout(tc358));
  logic [1:0] ts359; logic tc359;
  // tile 359 (compound_flagged_prefix, 2 bits) at level 14
  fam_prefix_brent_kung_w2_flagm_dual u_i359 (.a({tc330, 1'b0}), .b({tc337, 1'b0}), .cin(1'b0), .s(ts359), .cout(tc359));
  logic [1:0] ts360; logic tc360;
  // tile 360 (compound_flagged_prefix, 2 bits) at level 15
  fam_prefix_brent_kung_w2_flagm_dual u_i360 (.a({ts317[1], ts317[0]}), .b({tc293, 1'b0}), .cin(1'b0), .s(ts360), .cout(tc360));
  logic [1:0] ts361; logic tc361;
  // tile 361 (compound_flagged_prefix, 2 bits) at level 15
  fam_prefix_brent_kung_w2_flagm_dual u_i361 (.a({ts339[0], ts318[0]}), .b({tc294, 1'b0}), .cin(1'b0), .s(ts361), .cout(tc361));
  logic [1:0] ts362; logic tc362;
  // tile 362 (compound_flagged_prefix, 2 bits) at level 15
  fam_prefix_brent_kung_w2_flagm_dual u_i362 (.a({ts340[0], ts339[1]}), .b({tc295, 1'b0}), .cin(1'b0), .s(ts362), .cout(tc362));
  logic [1:0] ts363; logic tc363;
  // tile 363 (compound_flagged_prefix, 2 bits) at level 15
  fam_prefix_brent_kung_w2_flagm_dual u_i363 (.a({ts341[0], ts340[1]}), .b({ts333[1], ts333[0]}), .cin(1'b0), .s(ts363), .cout(tc363));
  logic [1:0] ts364; logic tc364;
  // tile 364 (compound_flagged_prefix, 2 bits) at level 15
  fam_prefix_brent_kung_w2_flagm_dual u_i364 (.a({ts342[0], ts341[1]}), .b({ts346[0], ts334[0]}), .cin(1'b0), .s(ts364), .cout(tc364));
  logic [1:0] ts365; logic tc365;
  // tile 365 (compound_flagged_prefix, 2 bits) at level 15
  fam_prefix_brent_kung_w2_flagm_dual u_i365 (.a({ts343[0], ts342[1]}), .b({ts347[0], ts346[1]}), .cin(1'b0), .s(ts365), .cout(tc365));
  logic [1:0] ts366; logic tc366;
  // tile 366 (compound_flagged_prefix, 2 bits) at level 15
  fam_prefix_brent_kung_w2_flagm_dual u_i366 (.a({ts344[0], ts343[1]}), .b({ts348[0], ts347[1]}), .cin(1'b0), .s(ts366), .cout(tc366));
  logic [1:0] ts367; logic tc367;
  // tile 367 (compound_flagged_prefix, 2 bits) at level 15
  fam_prefix_brent_kung_w2_flagm_dual u_i367 (.a({ts345[0], ts344[1]}), .b({ts349[0], ts348[1]}), .cin(1'b0), .s(ts367), .cout(tc367));
  logic ts368; logic tc368;
  // tile 368 (compound_flagged_prefix, 1 bits) at level 15
  fam_prefix_brent_kung_w1_flagm_dual u_i368 (.a({ts345[1]}), .b({ts349[1]}), .cin(1'b0), .s(ts368), .cout(tc368));
  logic [1:0] ts369; logic tc369;
  // tile 369 (compound_flagged_prefix, 2 bits) at level 15
  fam_prefix_brent_kung_w2_flagm_dual u_i369 (.a({ts350[0], tc319}), .b({ts355[0], 1'b0}), .cin(1'b0), .s(ts369), .cout(tc369));
  logic [1:0] ts370; logic tc370;
  // tile 370 (compound_flagged_prefix, 2 bits) at level 15
  fam_prefix_brent_kung_w2_flagm_dual u_i370 (.a({ts351[0], ts350[1]}), .b({ts356[0], ts355[1]}), .cin(1'b0), .s(ts370), .cout(tc370));
  logic [1:0] ts371; logic tc371;
  // tile 371 (compound_flagged_prefix, 2 bits) at level 15
  fam_prefix_brent_kung_w2_flagm_dual u_i371 (.a({ts352[0], ts351[1]}), .b({ts357[0], ts356[1]}), .cin(1'b0), .s(ts371), .cout(tc371));
  logic [1:0] ts372; logic tc372;
  // tile 372 (compound_flagged_prefix, 2 bits) at level 15
  fam_prefix_brent_kung_w2_flagm_dual u_i372 (.a({ts353[0], ts352[1]}), .b({ts358[0], ts357[1]}), .cin(1'b0), .s(ts372), .cout(tc372));
  logic [1:0] ts373; logic tc373;
  // tile 373 (compound_flagged_prefix, 2 bits) at level 15
  fam_prefix_brent_kung_w2_flagm_dual u_i373 (.a({ts354[0], ts353[1]}), .b({ts359[0], ts358[1]}), .cin(1'b0), .s(ts373), .cout(tc373));
  logic ts374; logic tc374;
  // tile 374 (compound_flagged_prefix, 1 bits) at level 15
  fam_prefix_brent_kung_w1_flagm_dual u_i374 (.a({ts354[1]}), .b({ts359[1]}), .cin(1'b0), .s(ts374), .cout(tc374));
  logic [1:0] ts375; logic tc375;
  // tile 375 (compound_flagged_prefix, 2 bits) at level 15
  fam_prefix_brent_kung_w2_flagm_dual u_i375 (.a({tc346, 1'b0}), .b({tc351, 1'b0}), .cin(1'b0), .s(ts375), .cout(tc375));
  logic [1:0] ts376; logic tc376;
  // tile 376 (compound_flagged_prefix, 2 bits) at level 15
  fam_prefix_brent_kung_w2_flagm_dual u_i376 (.a({tc347, 1'b0}), .b({tc352, 1'b0}), .cin(1'b0), .s(ts376), .cout(tc376));
  logic [1:0] ts377; logic tc377;
  // tile 377 (compound_flagged_prefix, 2 bits) at level 15
  fam_prefix_brent_kung_w2_flagm_dual u_i377 (.a({tc348, 1'b0}), .b({tc353, 1'b0}), .cin(1'b0), .s(ts377), .cout(tc377));
  logic [1:0] ts378; logic tc378;
  // tile 378 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i378 (.a({ts361[0], ts360[1]}), .b({tc317, 1'b0}), .cin(1'b0), .s(ts378), .cout(tc378));
  logic [1:0] ts379; logic tc379;
  // tile 379 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i379 (.a({ts362[0], ts361[1]}), .b({tc318, 1'b0}), .cin(1'b0), .s(ts379), .cout(tc379));
  logic [1:0] ts380; logic tc380;
  // tile 380 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i380 (.a({ts363[0], ts362[1]}), .b({ts369[0], 1'b0}), .cin(1'b0), .s(ts380), .cout(tc380));
  logic [1:0] ts381; logic tc381;
  // tile 381 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i381 (.a({ts364[0], ts363[1]}), .b({ts370[0], ts369[1]}), .cin(1'b0), .s(ts381), .cout(tc381));
  logic [1:0] ts382; logic tc382;
  // tile 382 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i382 (.a({ts365[0], ts364[1]}), .b({ts371[0], ts370[1]}), .cin(1'b0), .s(ts382), .cout(tc382));
  logic [1:0] ts383; logic tc383;
  // tile 383 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i383 (.a({ts366[0], ts365[1]}), .b({ts372[0], ts371[1]}), .cin(1'b0), .s(ts383), .cout(tc383));
  logic [1:0] ts384; logic tc384;
  // tile 384 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i384 (.a({ts367[0], ts366[1]}), .b({ts373[0], ts372[1]}), .cin(1'b0), .s(ts384), .cout(tc384));
  logic [1:0] ts385; logic tc385;
  // tile 385 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i385 (.a({ts368, ts367[1]}), .b({ts374, ts373[1]}), .cin(1'b0), .s(ts385), .cout(tc385));
  logic [1:0] ts386; logic tc386;
  // tile 386 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i386 (.a({1'b0, tc341}), .b({ts375[0], tc350}), .cin(1'b0), .s(ts386), .cout(tc386));
  logic [1:0] ts387; logic tc387;
  // tile 387 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i387 (.a({1'b0, tc342}), .b({ts376[0], ts375[1]}), .cin(1'b0), .s(ts387), .cout(tc387));
  logic [1:0] ts388; logic tc388;
  // tile 388 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i388 (.a({1'b0, tc343}), .b({ts377[0], ts376[1]}), .cin(1'b0), .s(ts388), .cout(tc388));
  logic [1:0] ts389; logic tc389;
  // tile 389 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i389 (.a({tc338, tc344}), .b({1'b0, ts377[1]}), .cin(1'b0), .s(ts389), .cout(tc389));
  logic [1:0] ts390; logic tc390;
  // tile 390 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i390 (.a({1'b0, tc355}), .b({tc364, 1'b0}), .cin(1'b0), .s(ts390), .cout(tc390));
  logic [1:0] ts391; logic tc391;
  // tile 391 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i391 (.a({1'b0, tc356}), .b({tc365, 1'b0}), .cin(1'b0), .s(ts391), .cout(tc391));
  logic [1:0] ts392; logic tc392;
  // tile 392 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i392 (.a({1'b0, tc357}), .b({tc366, 1'b0}), .cin(1'b0), .s(ts392), .cout(tc392));
  logic [1:0] ts393; logic tc393;
  // tile 393 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i393 (.a({1'b0, tc358}), .b({tc367, 1'b0}), .cin(1'b0), .s(ts393), .cout(tc393));
  logic [1:0] ts394; logic tc394;
  // tile 394 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i394 (.a({tc371, 1'b0}), .b({tc375, 1'b0}), .cin(1'b0), .s(ts394), .cout(tc394));
  logic [1:0] ts395; logic tc395;
  // tile 395 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i395 (.a({tc372, 1'b0}), .b({tc376, 1'b0}), .cin(1'b0), .s(ts395), .cout(tc395));
  logic [1:0] ts396; logic tc396;
  // tile 396 (compound_flagged_prefix, 2 bits) at level 16
  fam_prefix_brent_kung_w2_flagm_dual u_i396 (.a({tc373, 1'b0}), .b({tc377, 1'b0}), .cin(1'b0), .s(ts396), .cout(tc396));
  logic [1:0] ts397; logic tc397;
  // tile 397 (compound_flagged_prefix, 2 bits) at level 17
  fam_prefix_brent_kung_w2_flagm_dual u_i397 (.a({ts380[0], ts379[1]}), .b({tc339, 1'b0}), .cin(1'b0), .s(ts397), .cout(tc397));
  logic [1:0] ts398; logic tc398;
  // tile 398 (compound_flagged_prefix, 2 bits) at level 17
  fam_prefix_brent_kung_w2_flagm_dual u_i398 (.a({ts381[0], ts380[1]}), .b({tc340, 1'b0}), .cin(1'b0), .s(ts398), .cout(tc398));
  logic [1:0] ts399; logic tc399;
  // tile 399 (compound_flagged_prefix, 2 bits) at level 17
  fam_prefix_brent_kung_w2_flagm_dual u_i399 (.a({ts382[0], ts381[1]}), .b({ts386[0], 1'b0}), .cin(1'b0), .s(ts399), .cout(tc399));
  logic [1:0] ts400; logic tc400;
  // tile 400 (compound_flagged_prefix, 2 bits) at level 17
  fam_prefix_brent_kung_w2_flagm_dual u_i400 (.a({ts383[0], ts382[1]}), .b({ts387[0], ts386[1]}), .cin(1'b0), .s(ts400), .cout(tc400));
  logic [1:0] ts401; logic tc401;
  // tile 401 (compound_flagged_prefix, 2 bits) at level 17
  fam_prefix_brent_kung_w2_flagm_dual u_i401 (.a({ts384[0], ts383[1]}), .b({ts388[0], ts387[1]}), .cin(1'b0), .s(ts401), .cout(tc401));
  logic [1:0] ts402; logic tc402;
  // tile 402 (compound_flagged_prefix, 2 bits) at level 17
  fam_prefix_brent_kung_w2_flagm_dual u_i402 (.a({ts385[0], ts384[1]}), .b({ts389[0], ts388[1]}), .cin(1'b0), .s(ts402), .cout(tc402));
  logic ts403; logic tc403;
  // tile 403 (compound_flagged_prefix, 1 bits) at level 17
  fam_prefix_brent_kung_w1_flagm_dual u_i403 (.a({ts385[1]}), .b({ts389[1]}), .cin(1'b0), .s(ts403), .cout(tc403));
  logic [1:0] ts404; logic tc404;
  // tile 404 (compound_flagged_prefix, 2 bits) at level 17
  fam_prefix_brent_kung_w2_flagm_dual u_i404 (.a({ts390[0], tc363}), .b({1'b0, tc369}), .cin(1'b0), .s(ts404), .cout(tc404));
  logic [1:0] ts405; logic tc405;
  // tile 405 (compound_flagged_prefix, 2 bits) at level 17
  fam_prefix_brent_kung_w2_flagm_dual u_i405 (.a({ts391[0], ts390[1]}), .b({ts394[0], tc370}), .cin(1'b0), .s(ts405), .cout(tc405));
  logic [1:0] ts406; logic tc406;
  // tile 406 (compound_flagged_prefix, 2 bits) at level 17
  fam_prefix_brent_kung_w2_flagm_dual u_i406 (.a({ts392[0], ts391[1]}), .b({ts395[0], ts394[1]}), .cin(1'b0), .s(ts406), .cout(tc406));
  logic [1:0] ts407; logic tc407;
  // tile 407 (compound_flagged_prefix, 2 bits) at level 17
  fam_prefix_brent_kung_w2_flagm_dual u_i407 (.a({ts393[0], ts392[1]}), .b({ts396[0], ts395[1]}), .cin(1'b0), .s(ts407), .cout(tc407));
  logic ts408; logic tc408;
  // tile 408 (compound_flagged_prefix, 1 bits) at level 17
  fam_prefix_brent_kung_w1_flagm_dual u_i408 (.a({ts393[1]}), .b({ts396[1]}), .cin(1'b0), .s(ts408), .cout(tc408));
  logic [1:0] ts409; logic tc409;
  // tile 409 (compound_flagged_prefix, 2 bits) at level 17
  fam_prefix_brent_kung_w2_flagm_dual u_i409 (.a({tc382, 1'b0}), .b({tc386, 1'b0}), .cin(1'b0), .s(ts409), .cout(tc409));
  logic [1:0] ts410; logic tc410;
  // tile 410 (compound_flagged_prefix, 2 bits) at level 17
  fam_prefix_brent_kung_w2_flagm_dual u_i410 (.a({tc383, 1'b0}), .b({tc387, 1'b0}), .cin(1'b0), .s(ts410), .cout(tc410));
  logic [1:0] ts411; logic tc411;
  // tile 411 (compound_flagged_prefix, 2 bits) at level 17
  fam_prefix_brent_kung_w2_flagm_dual u_i411 (.a({tc384, 1'b0}), .b({tc388, 1'b0}), .cin(1'b0), .s(ts411), .cout(tc411));
  logic [1:0] ts412; logic tc412;
  // tile 412 (compound_flagged_prefix, 2 bits) at level 17
  fam_prefix_brent_kung_w2_flagm_dual u_i412 (.a({tc391, 1'b0}), .b({tc394, 1'b0}), .cin(1'b0), .s(ts412), .cout(tc412));
  logic [1:0] ts413; logic tc413;
  // tile 413 (compound_flagged_prefix, 2 bits) at level 17
  fam_prefix_brent_kung_w2_flagm_dual u_i413 (.a({tc392, 1'b0}), .b({tc395, 1'b0}), .cin(1'b0), .s(ts413), .cout(tc413));
  logic [1:0] ts414; logic tc414;
  // tile 414 (compound_flagged_prefix, 2 bits) at level 18
  fam_prefix_brent_kung_w2_flagm_dual u_i414 (.a({ts378[1], ts378[0]}), .b({tc360, 1'b0}), .cin(1'b0), .s(ts414), .cout(tc414));
  logic [1:0] ts415; logic tc415;
  // tile 415 (compound_flagged_prefix, 2 bits) at level 18
  fam_prefix_brent_kung_w2_flagm_dual u_i415 (.a({ts397[0], ts379[0]}), .b({tc361, 1'b0}), .cin(1'b0), .s(ts415), .cout(tc415));
  logic [1:0] ts416; logic tc416;
  // tile 416 (compound_flagged_prefix, 2 bits) at level 18
  fam_prefix_brent_kung_w2_flagm_dual u_i416 (.a({ts398[0], ts397[1]}), .b({tc362, 1'b0}), .cin(1'b0), .s(ts416), .cout(tc416));
  logic [1:0] ts417; logic tc417;
  // tile 417 (compound_flagged_prefix, 2 bits) at level 18
  fam_prefix_brent_kung_w2_flagm_dual u_i417 (.a({ts399[0], ts398[1]}), .b({ts404[0], 1'b0}), .cin(1'b0), .s(ts417), .cout(tc417));
  logic [1:0] ts418; logic tc418;
  // tile 418 (compound_flagged_prefix, 2 bits) at level 18
  fam_prefix_brent_kung_w2_flagm_dual u_i418 (.a({ts400[0], ts399[1]}), .b({ts405[0], ts404[1]}), .cin(1'b0), .s(ts418), .cout(tc418));
  logic [1:0] ts419; logic tc419;
  // tile 419 (compound_flagged_prefix, 2 bits) at level 18
  fam_prefix_brent_kung_w2_flagm_dual u_i419 (.a({ts401[0], ts400[1]}), .b({ts406[0], ts405[1]}), .cin(1'b0), .s(ts419), .cout(tc419));
  logic [1:0] ts420; logic tc420;
  // tile 420 (compound_flagged_prefix, 2 bits) at level 18
  fam_prefix_brent_kung_w2_flagm_dual u_i420 (.a({ts402[0], ts401[1]}), .b({ts407[0], ts406[1]}), .cin(1'b0), .s(ts420), .cout(tc420));
  logic [1:0] ts421; logic tc421;
  // tile 421 (compound_flagged_prefix, 2 bits) at level 18
  fam_prefix_brent_kung_w2_flagm_dual u_i421 (.a({ts403, ts402[1]}), .b({ts408, ts407[1]}), .cin(1'b0), .s(ts421), .cout(tc421));
  logic [1:0] ts422; logic tc422;
  // tile 422 (compound_flagged_prefix, 2 bits) at level 18
  fam_prefix_brent_kung_w2_flagm_dual u_i422 (.a({ts410[0], ts409[1]}), .b({ts412[0], tc390}), .cin(1'b0), .s(ts422), .cout(tc422));
  logic [1:0] ts423; logic tc423;
  // tile 423 (compound_flagged_prefix, 2 bits) at level 18
  fam_prefix_brent_kung_w2_flagm_dual u_i423 (.a({ts411[0], ts410[1]}), .b({ts413[0], ts412[1]}), .cin(1'b0), .s(ts423), .cout(tc423));
  logic [1:0] ts424; logic tc424;
  // tile 424 (compound_flagged_prefix, 2 bits) at level 18
  fam_prefix_brent_kung_w2_flagm_dual u_i424 (.a({1'b0, ts411[1]}), .b({1'b0, ts413[1]}), .cin(1'b0), .s(ts424), .cout(tc424));
  logic [1:0] ts425; logic tc425;
  // tile 425 (compound_flagged_prefix, 2 bits) at level 18
  fam_prefix_brent_kung_w2_flagm_dual u_i425 (.a({tc399, 1'b0}), .b({tc404, 1'b0}), .cin(1'b0), .s(ts425), .cout(tc425));
  logic [1:0] ts426; logic tc426;
  // tile 426 (compound_flagged_prefix, 2 bits) at level 18
  fam_prefix_brent_kung_w2_flagm_dual u_i426 (.a({tc400, 1'b0}), .b({tc405, 1'b0}), .cin(1'b0), .s(ts426), .cout(tc426));
  logic [1:0] ts427; logic tc427;
  // tile 427 (compound_flagged_prefix, 2 bits) at level 18
  fam_prefix_brent_kung_w2_flagm_dual u_i427 (.a({tc401, 1'b0}), .b({tc406, 1'b0}), .cin(1'b0), .s(ts427), .cout(tc427));
  logic [1:0] ts428; logic tc428;
  // tile 428 (compound_flagged_prefix, 2 bits) at level 18
  fam_prefix_brent_kung_w2_flagm_dual u_i428 (.a({tc402, 1'b0}), .b({tc407, 1'b0}), .cin(1'b0), .s(ts428), .cout(tc428));
  logic [1:0] ts429; logic tc429;
  // tile 429 (compound_flagged_prefix, 2 bits) at level 18
  fam_prefix_brent_kung_w2_flagm_dual u_i429 (.a({tc410, 1'b0}), .b({tc412, 1'b0}), .cin(1'b0), .s(ts429), .cout(tc429));
  logic [1:0] ts430; logic tc430;
  // tile 430 (compound_flagged_prefix, 2 bits) at level 18
  fam_prefix_brent_kung_w2_flagm_dual u_i430 (.a({tc411, 1'b0}), .b({tc413, 1'b0}), .cin(1'b0), .s(ts430), .cout(tc430));
  logic [1:0] ts431; logic tc431;
  // tile 431 (compound_flagged_prefix, 2 bits) at level 19
  fam_prefix_brent_kung_w2_flagm_dual u_i431 (.a({ts415[0], ts414[1]}), .b({tc378, 1'b0}), .cin(1'b0), .s(ts431), .cout(tc431));
  logic [1:0] ts432; logic tc432;
  // tile 432 (compound_flagged_prefix, 2 bits) at level 19
  fam_prefix_brent_kung_w2_flagm_dual u_i432 (.a({ts416[0], ts415[1]}), .b({tc379, 1'b0}), .cin(1'b0), .s(ts432), .cout(tc432));
  logic [1:0] ts433; logic tc433;
  // tile 433 (compound_flagged_prefix, 2 bits) at level 19
  fam_prefix_brent_kung_w2_flagm_dual u_i433 (.a({ts417[0], ts416[1]}), .b({tc380, 1'b0}), .cin(1'b0), .s(ts433), .cout(tc433));
  logic [1:0] ts434; logic tc434;
  // tile 434 (compound_flagged_prefix, 2 bits) at level 19
  fam_prefix_brent_kung_w2_flagm_dual u_i434 (.a({ts418[0], ts417[1]}), .b({tc381, 1'b0}), .cin(1'b0), .s(ts434), .cout(tc434));
  logic [1:0] ts435; logic tc435;
  // tile 435 (compound_flagged_prefix, 2 bits) at level 19
  fam_prefix_brent_kung_w2_flagm_dual u_i435 (.a({ts419[0], ts418[1]}), .b({ts422[0], ts409[0]}), .cin(1'b0), .s(ts435), .cout(tc435));
  logic [1:0] ts436; logic tc436;
  // tile 436 (compound_flagged_prefix, 2 bits) at level 19
  fam_prefix_brent_kung_w2_flagm_dual u_i436 (.a({ts420[0], ts419[1]}), .b({ts423[0], ts422[1]}), .cin(1'b0), .s(ts436), .cout(tc436));
  logic [1:0] ts437; logic tc437;
  // tile 437 (compound_flagged_prefix, 2 bits) at level 19
  fam_prefix_brent_kung_w2_flagm_dual u_i437 (.a({ts421[0], ts420[1]}), .b({ts424[0], ts423[1]}), .cin(1'b0), .s(ts437), .cout(tc437));
  logic ts438; logic tc438;
  // tile 438 (compound_flagged_prefix, 1 bits) at level 19
  fam_prefix_brent_kung_w1_flagm_dual u_i438 (.a({ts421[1]}), .b({ts424[1]}), .cin(1'b0), .s(ts438), .cout(tc438));
  logic [1:0] ts439; logic tc439;
  // tile 439 (compound_flagged_prefix, 2 bits) at level 19
  fam_prefix_brent_kung_w2_flagm_dual u_i439 (.a({ts427[0], ts426[1]}), .b({ts429[0], tc409}), .cin(1'b0), .s(ts439), .cout(tc439));
  logic [1:0] ts440; logic tc440;
  // tile 440 (compound_flagged_prefix, 2 bits) at level 19
  fam_prefix_brent_kung_w2_flagm_dual u_i440 (.a({ts428[0], ts427[1]}), .b({ts430[0], ts429[1]}), .cin(1'b0), .s(ts440), .cout(tc440));
  logic ts441; logic tc441;
  // tile 441 (compound_flagged_prefix, 1 bits) at level 19
  fam_prefix_brent_kung_w1_flagm_dual u_i441 (.a({ts428[1]}), .b({ts430[1]}), .cin(1'b0), .s(ts441), .cout(tc441));
  logic [1:0] ts442; logic tc442;
  // tile 442 (compound_flagged_prefix, 2 bits) at level 19
  fam_prefix_brent_kung_w2_flagm_dual u_i442 (.a({tc419, 1'b0}), .b({tc422, 1'b0}), .cin(1'b0), .s(ts442), .cout(tc442));
  logic [1:0] ts443; logic tc443;
  // tile 443 (compound_flagged_prefix, 2 bits) at level 19
  fam_prefix_brent_kung_w2_flagm_dual u_i443 (.a({tc420, 1'b0}), .b({tc423, 1'b0}), .cin(1'b0), .s(ts443), .cout(tc443));
  logic [1:0] ts444; logic tc444;
  // tile 444 (compound_flagged_prefix, 2 bits) at level 19
  fam_prefix_brent_kung_w2_flagm_dual u_i444 (.a({tc427, 1'b0}), .b({tc429, 1'b0}), .cin(1'b0), .s(ts444), .cout(tc444));
  logic [1:0] ts445; logic tc445;
  // tile 445 (compound_flagged_prefix, 2 bits) at level 20
  fam_prefix_brent_kung_w2_flagm_dual u_i445 (.a({ts433[0], ts432[1]}), .b({tc397, 1'b0}), .cin(1'b0), .s(ts445), .cout(tc445));
  logic [1:0] ts446; logic tc446;
  // tile 446 (compound_flagged_prefix, 2 bits) at level 20
  fam_prefix_brent_kung_w2_flagm_dual u_i446 (.a({ts434[0], ts433[1]}), .b({tc398, 1'b0}), .cin(1'b0), .s(ts446), .cout(tc446));
  logic [1:0] ts447; logic tc447;
  // tile 447 (compound_flagged_prefix, 2 bits) at level 20
  fam_prefix_brent_kung_w2_flagm_dual u_i447 (.a({ts435[0], ts434[1]}), .b({ts425[1], ts425[0]}), .cin(1'b0), .s(ts447), .cout(tc447));
  logic [1:0] ts448; logic tc448;
  // tile 448 (compound_flagged_prefix, 2 bits) at level 20
  fam_prefix_brent_kung_w2_flagm_dual u_i448 (.a({ts436[0], ts435[1]}), .b({ts439[0], ts426[0]}), .cin(1'b0), .s(ts448), .cout(tc448));
  logic [1:0] ts449; logic tc449;
  // tile 449 (compound_flagged_prefix, 2 bits) at level 20
  fam_prefix_brent_kung_w2_flagm_dual u_i449 (.a({ts437[0], ts436[1]}), .b({ts440[0], ts439[1]}), .cin(1'b0), .s(ts449), .cout(tc449));
  logic [1:0] ts450; logic tc450;
  // tile 450 (compound_flagged_prefix, 2 bits) at level 20
  fam_prefix_brent_kung_w2_flagm_dual u_i450 (.a({ts438, ts437[1]}), .b({ts441, ts440[1]}), .cin(1'b0), .s(ts450), .cout(tc450));
  logic [1:0] ts451; logic tc451;
  // tile 451 (compound_flagged_prefix, 2 bits) at level 20
  fam_prefix_brent_kung_w2_flagm_dual u_i451 (.a({ts442[0], tc418}), .b({1'b0, tc425}), .cin(1'b0), .s(ts451), .cout(tc451));
  logic [1:0] ts452; logic tc452;
  // tile 452 (compound_flagged_prefix, 2 bits) at level 20
  fam_prefix_brent_kung_w2_flagm_dual u_i452 (.a({ts443[0], ts442[1]}), .b({ts444[0], tc426}), .cin(1'b0), .s(ts452), .cout(tc452));
  logic [1:0] ts453; logic tc453;
  // tile 453 (compound_flagged_prefix, 2 bits) at level 20
  fam_prefix_brent_kung_w2_flagm_dual u_i453 (.a({1'b0, ts443[1]}), .b({1'b0, ts444[1]}), .cin(1'b0), .s(ts453), .cout(tc453));
  logic [1:0] ts454; logic tc454;
  // tile 454 (compound_flagged_prefix, 2 bits) at level 20
  fam_prefix_brent_kung_w2_flagm_dual u_i454 (.a({tc436, 1'b0}), .b({tc439, 1'b0}), .cin(1'b0), .s(ts454), .cout(tc454));
  logic [1:0] ts455; logic tc455;
  // tile 455 (compound_flagged_prefix, 2 bits) at level 20
  fam_prefix_brent_kung_w2_flagm_dual u_i455 (.a({tc437, 1'b0}), .b({tc440, 1'b0}), .cin(1'b0), .s(ts455), .cout(tc455));
  logic [1:0] ts456; logic tc456;
  // tile 456 (compound_flagged_prefix, 2 bits) at level 20
  fam_prefix_brent_kung_w2_flagm_dual u_i456 (.a({tc443, 1'b0}), .b({tc444, 1'b0}), .cin(1'b0), .s(ts456), .cout(tc456));
  logic [1:0] ts457; logic tc457;
  // tile 457 (compound_flagged_prefix, 2 bits) at level 21
  fam_prefix_brent_kung_w2_flagm_dual u_i457 (.a({ts431[1], ts431[0]}), .b({tc414, 1'b0}), .cin(1'b0), .s(ts457), .cout(tc457));
  logic [1:0] ts458; logic tc458;
  // tile 458 (compound_flagged_prefix, 2 bits) at level 21
  fam_prefix_brent_kung_w2_flagm_dual u_i458 (.a({ts445[0], ts432[0]}), .b({tc415, 1'b0}), .cin(1'b0), .s(ts458), .cout(tc458));
  logic [1:0] ts459; logic tc459;
  // tile 459 (compound_flagged_prefix, 2 bits) at level 21
  fam_prefix_brent_kung_w2_flagm_dual u_i459 (.a({ts446[0], ts445[1]}), .b({tc416, 1'b0}), .cin(1'b0), .s(ts459), .cout(tc459));
  logic [1:0] ts460; logic tc460;
  // tile 460 (compound_flagged_prefix, 2 bits) at level 21
  fam_prefix_brent_kung_w2_flagm_dual u_i460 (.a({ts447[0], ts446[1]}), .b({tc417, 1'b0}), .cin(1'b0), .s(ts460), .cout(tc460));
  logic [1:0] ts461; logic tc461;
  // tile 461 (compound_flagged_prefix, 2 bits) at level 21
  fam_prefix_brent_kung_w2_flagm_dual u_i461 (.a({ts448[0], ts447[1]}), .b({ts451[0], 1'b0}), .cin(1'b0), .s(ts461), .cout(tc461));
  logic [1:0] ts462; logic tc462;
  // tile 462 (compound_flagged_prefix, 2 bits) at level 21
  fam_prefix_brent_kung_w2_flagm_dual u_i462 (.a({ts449[0], ts448[1]}), .b({ts452[0], ts451[1]}), .cin(1'b0), .s(ts462), .cout(tc462));
  logic [1:0] ts463; logic tc463;
  // tile 463 (compound_flagged_prefix, 2 bits) at level 21
  fam_prefix_brent_kung_w2_flagm_dual u_i463 (.a({ts450[0], ts449[1]}), .b({ts453[0], ts452[1]}), .cin(1'b0), .s(ts463), .cout(tc463));
  logic ts464; logic tc464;
  // tile 464 (compound_flagged_prefix, 1 bits) at level 21
  fam_prefix_brent_kung_w1_flagm_dual u_i464 (.a({ts450[1]}), .b({ts453[1]}), .cin(1'b0), .s(ts464), .cout(tc464));
  logic [1:0] ts465; logic tc465;
  // tile 465 (compound_flagged_prefix, 2 bits) at level 21
  fam_prefix_brent_kung_w2_flagm_dual u_i465 (.a({ts455[0], ts454[1]}), .b({ts456[0], tc442}), .cin(1'b0), .s(ts465), .cout(tc465));
  logic ts466; logic tc466;
  // tile 466 (compound_flagged_prefix, 1 bits) at level 21
  fam_prefix_brent_kung_w1_flagm_dual u_i466 (.a({ts455[1]}), .b({ts456[1]}), .cin(1'b0), .s(ts466), .cout(tc466));
  logic [1:0] ts467; logic tc467;
  // tile 467 (compound_flagged_prefix, 2 bits) at level 21
  fam_prefix_brent_kung_w2_flagm_dual u_i467 (.a({tc448, 1'b0}), .b({tc451, 1'b0}), .cin(1'b0), .s(ts467), .cout(tc467));
  logic [1:0] ts468; logic tc468;
  // tile 468 (compound_flagged_prefix, 2 bits) at level 21
  fam_prefix_brent_kung_w2_flagm_dual u_i468 (.a({tc449, 1'b0}), .b({tc452, 1'b0}), .cin(1'b0), .s(ts468), .cout(tc468));
  logic [1:0] ts469; logic tc469;
  // tile 469 (compound_flagged_prefix, 2 bits) at level 22
  fam_prefix_brent_kung_w2_flagm_dual u_i469 (.a({ts458[0], ts457[1]}), .b({tc431, 1'b0}), .cin(1'b0), .s(ts469), .cout(tc469));
  logic [1:0] ts470; logic tc470;
  // tile 470 (compound_flagged_prefix, 2 bits) at level 22
  fam_prefix_brent_kung_w2_flagm_dual u_i470 (.a({ts459[0], ts458[1]}), .b({tc432, 1'b0}), .cin(1'b0), .s(ts470), .cout(tc470));
  logic [1:0] ts471; logic tc471;
  // tile 471 (compound_flagged_prefix, 2 bits) at level 22
  fam_prefix_brent_kung_w2_flagm_dual u_i471 (.a({ts460[0], ts459[1]}), .b({tc433, 1'b0}), .cin(1'b0), .s(ts471), .cout(tc471));
  logic [1:0] ts472; logic tc472;
  // tile 472 (compound_flagged_prefix, 2 bits) at level 22
  fam_prefix_brent_kung_w2_flagm_dual u_i472 (.a({ts461[0], ts460[1]}), .b({tc434, 1'b0}), .cin(1'b0), .s(ts472), .cout(tc472));
  logic [1:0] ts473; logic tc473;
  // tile 473 (compound_flagged_prefix, 2 bits) at level 22
  fam_prefix_brent_kung_w2_flagm_dual u_i473 (.a({ts462[0], ts461[1]}), .b({tc435, 1'b0}), .cin(1'b0), .s(ts473), .cout(tc473));
  logic [1:0] ts474; logic tc474;
  // tile 474 (compound_flagged_prefix, 2 bits) at level 22
  fam_prefix_brent_kung_w2_flagm_dual u_i474 (.a({ts463[0], ts462[1]}), .b({ts465[0], ts454[0]}), .cin(1'b0), .s(ts474), .cout(tc474));
  logic [1:0] ts475; logic tc475;
  // tile 475 (compound_flagged_prefix, 2 bits) at level 22
  fam_prefix_brent_kung_w2_flagm_dual u_i475 (.a({ts464, ts463[1]}), .b({ts466, ts465[1]}), .cin(1'b0), .s(ts475), .cout(tc475));
  logic [1:0] ts476; logic tc476;
  // tile 476 (compound_flagged_prefix, 2 bits) at level 22
  fam_prefix_brent_kung_w2_flagm_dual u_i476 (.a({1'b0, ts468[1]}), .b({1'b0, tc454}), .cin(1'b0), .s(ts476), .cout(tc476));
  logic [1:0] ts477; logic tc477;
  // tile 477 (compound_flagged_prefix, 2 bits) at level 22
  fam_prefix_brent_kung_w2_flagm_dual u_i477 (.a({tc463, 1'b0}), .b({tc465, 1'b0}), .cin(1'b0), .s(ts477), .cout(tc477));
  logic [1:0] ts478; logic tc478;
  // tile 478 (compound_flagged_prefix, 2 bits) at level 23
  fam_prefix_brent_kung_w2_flagm_dual u_i478 (.a({ts471[0], ts470[1]}), .b({tc445, 1'b0}), .cin(1'b0), .s(ts478), .cout(tc478));
  logic [1:0] ts479; logic tc479;
  // tile 479 (compound_flagged_prefix, 2 bits) at level 23
  fam_prefix_brent_kung_w2_flagm_dual u_i479 (.a({ts472[0], ts471[1]}), .b({tc446, 1'b0}), .cin(1'b0), .s(ts479), .cout(tc479));
  logic [1:0] ts480; logic tc480;
  // tile 480 (compound_flagged_prefix, 2 bits) at level 23
  fam_prefix_brent_kung_w2_flagm_dual u_i480 (.a({ts473[0], ts472[1]}), .b({tc447, 1'b0}), .cin(1'b0), .s(ts480), .cout(tc480));
  logic [1:0] ts481; logic tc481;
  // tile 481 (compound_flagged_prefix, 2 bits) at level 23
  fam_prefix_brent_kung_w2_flagm_dual u_i481 (.a({ts474[0], ts473[1]}), .b({ts467[1], ts467[0]}), .cin(1'b0), .s(ts481), .cout(tc481));
  logic [1:0] ts482; logic tc482;
  // tile 482 (compound_flagged_prefix, 2 bits) at level 23
  fam_prefix_brent_kung_w2_flagm_dual u_i482 (.a({ts475[0], ts474[1]}), .b({ts476[0], ts468[0]}), .cin(1'b0), .s(ts482), .cout(tc482));
  logic ts483; logic tc483;
  // tile 483 (compound_flagged_prefix, 1 bits) at level 23
  fam_prefix_brent_kung_w1_flagm_dual u_i483 (.a({ts475[1]}), .b({ts476[1]}), .cin(1'b0), .s(ts483), .cout(tc483));
  logic [1:0] ts484; logic tc484;
  // tile 484 (compound_flagged_prefix, 2 bits) at level 23
  fam_prefix_brent_kung_w2_flagm_dual u_i484 (.a({ts477[0], tc462}), .b({1'b0, tc467}), .cin(1'b0), .s(ts484), .cout(tc484));
  logic ts485; logic tc485;
  // tile 485 (compound_flagged_prefix, 1 bits) at level 23
  fam_prefix_brent_kung_w1_flagm_dual u_i485 (.a({ts477[1]}), .b({tc468}), .cin(1'b0), .s(ts485), .cout(tc485));
  logic [1:0] ts486; logic tc486;
  // tile 486 (compound_flagged_prefix, 2 bits) at level 24
  fam_prefix_brent_kung_w2_flagm_dual u_i486 (.a({ts469[1], ts469[0]}), .b({tc457, 1'b0}), .cin(1'b0), .s(ts486), .cout(tc486));
  logic [1:0] ts487; logic tc487;
  // tile 487 (compound_flagged_prefix, 2 bits) at level 24
  fam_prefix_brent_kung_w2_flagm_dual u_i487 (.a({ts478[0], ts470[0]}), .b({tc458, 1'b0}), .cin(1'b0), .s(ts487), .cout(tc487));
  logic [1:0] ts488; logic tc488;
  // tile 488 (compound_flagged_prefix, 2 bits) at level 24
  fam_prefix_brent_kung_w2_flagm_dual u_i488 (.a({ts479[0], ts478[1]}), .b({tc459, 1'b0}), .cin(1'b0), .s(ts488), .cout(tc488));
  logic [1:0] ts489; logic tc489;
  // tile 489 (compound_flagged_prefix, 2 bits) at level 24
  fam_prefix_brent_kung_w2_flagm_dual u_i489 (.a({ts480[0], ts479[1]}), .b({tc460, 1'b0}), .cin(1'b0), .s(ts489), .cout(tc489));
  logic [1:0] ts490; logic tc490;
  // tile 490 (compound_flagged_prefix, 2 bits) at level 24
  fam_prefix_brent_kung_w2_flagm_dual u_i490 (.a({ts481[0], ts480[1]}), .b({tc461, 1'b0}), .cin(1'b0), .s(ts490), .cout(tc490));
  logic [1:0] ts491; logic tc491;
  // tile 491 (compound_flagged_prefix, 2 bits) at level 24
  fam_prefix_brent_kung_w2_flagm_dual u_i491 (.a({ts482[0], ts481[1]}), .b({ts484[0], 1'b0}), .cin(1'b0), .s(ts491), .cout(tc491));
  logic [1:0] ts492; logic tc492;
  // tile 492 (compound_flagged_prefix, 2 bits) at level 24
  fam_prefix_brent_kung_w2_flagm_dual u_i492 (.a({ts483, ts482[1]}), .b({ts485, ts484[1]}), .cin(1'b0), .s(ts492), .cout(tc492));
  logic [1:0] ts493; logic tc493;
  // tile 493 (compound_flagged_prefix, 2 bits) at level 24
  fam_prefix_brent_kung_w2_flagm_dual u_i493 (.a({1'b0, tc470}), .b({tc478, 1'b0}), .cin(1'b0), .s(ts493), .cout(tc493));
  logic [1:0] ts494; logic tc494;
  // tile 494 (compound_flagged_prefix, 2 bits) at level 24
  fam_prefix_brent_kung_w2_flagm_dual u_i494 (.a({1'b0, tc471}), .b({tc479, 1'b0}), .cin(1'b0), .s(ts494), .cout(tc494));
  logic [1:0] ts495; logic tc495;
  // tile 495 (compound_flagged_prefix, 2 bits) at level 24
  fam_prefix_brent_kung_w2_flagm_dual u_i495 (.a({1'b0, tc472}), .b({tc480, 1'b0}), .cin(1'b0), .s(ts495), .cout(tc495));
  logic [1:0] ts496; logic tc496;
  // tile 496 (compound_flagged_prefix, 2 bits) at level 24
  fam_prefix_brent_kung_w2_flagm_dual u_i496 (.a({1'b0, tc473}), .b({tc481, 1'b0}), .cin(1'b0), .s(ts496), .cout(tc496));
  logic [1:0] ts497; logic tc497;
  // tile 497 (compound_flagged_prefix, 2 bits) at level 24
  fam_prefix_brent_kung_w2_flagm_dual u_i497 (.a({1'b0, tc474}), .b({tc482, 1'b0}), .cin(1'b0), .s(ts497), .cout(tc497));
  logic [1:0] ts498; logic tc498;
  // tile 498 (compound_flagged_prefix, 2 bits) at level 25
  fam_prefix_brent_kung_w2_flagm_dual u_i498 (.a({ts487[0], ts486[1]}), .b({tc469, 1'b0}), .cin(1'b0), .s(ts498), .cout(tc498));
  logic [1:0] ts499; logic tc499;
  // tile 499 (compound_flagged_prefix, 2 bits) at level 25
  fam_prefix_brent_kung_w2_flagm_dual u_i499 (.a({ts488[0], ts487[1]}), .b({ts493[0], 1'b0}), .cin(1'b0), .s(ts499), .cout(tc499));
  logic [1:0] ts500; logic tc500;
  // tile 500 (compound_flagged_prefix, 2 bits) at level 25
  fam_prefix_brent_kung_w2_flagm_dual u_i500 (.a({ts489[0], ts488[1]}), .b({ts494[0], ts493[1]}), .cin(1'b0), .s(ts500), .cout(tc500));
  logic [1:0] ts501; logic tc501;
  // tile 501 (compound_flagged_prefix, 2 bits) at level 25
  fam_prefix_brent_kung_w2_flagm_dual u_i501 (.a({ts490[0], ts489[1]}), .b({ts495[0], ts494[1]}), .cin(1'b0), .s(ts501), .cout(tc501));
  logic [1:0] ts502; logic tc502;
  // tile 502 (compound_flagged_prefix, 2 bits) at level 25
  fam_prefix_brent_kung_w2_flagm_dual u_i502 (.a({ts491[0], ts490[1]}), .b({ts496[0], ts495[1]}), .cin(1'b0), .s(ts502), .cout(tc502));
  logic [1:0] ts503; logic tc503;
  // tile 503 (compound_flagged_prefix, 2 bits) at level 25
  fam_prefix_brent_kung_w2_flagm_dual u_i503 (.a({ts492[0], ts491[1]}), .b({ts497[0], ts496[1]}), .cin(1'b0), .s(ts503), .cout(tc503));
  logic ts504; logic tc504;
  // tile 504 (compound_flagged_prefix, 1 bits) at level 25
  fam_prefix_brent_kung_w1_flagm_dual u_i504 (.a({ts492[1]}), .b({ts497[1]}), .cin(1'b0), .s(ts504), .cout(tc504));
  logic [1:0] ts505; logic tc505;
  // tile 505 (compound_flagged_prefix, 2 bits) at level 26
  fam_prefix_brent_kung_w2_flagm_dual u_i505 (.a({ts499[0], ts498[1]}), .b({1'b0, tc486}), .cin(1'b0), .s(ts505), .cout(tc505));
  logic [1:0] ts506; logic tc506;
  // tile 506 (compound_flagged_prefix, 2 bits) at level 26
  fam_prefix_brent_kung_w2_flagm_dual u_i506 (.a({ts500[0], ts499[1]}), .b({1'b0, tc487}), .cin(1'b0), .s(ts506), .cout(tc506));
  logic [1:0] ts507; logic tc507;
  // tile 507 (compound_flagged_prefix, 2 bits) at level 26
  fam_prefix_brent_kung_w2_flagm_dual u_i507 (.a({ts501[0], ts500[1]}), .b({1'b0, tc488}), .cin(1'b0), .s(ts507), .cout(tc507));
  logic [1:0] ts508; logic tc508;
  // tile 508 (compound_flagged_prefix, 2 bits) at level 26
  fam_prefix_brent_kung_w2_flagm_dual u_i508 (.a({ts502[0], ts501[1]}), .b({1'b0, tc489}), .cin(1'b0), .s(ts508), .cout(tc508));
  logic [1:0] ts509; logic tc509;
  // tile 509 (compound_flagged_prefix, 2 bits) at level 26
  fam_prefix_brent_kung_w2_flagm_dual u_i509 (.a({ts503[0], ts502[1]}), .b({1'b0, tc490}), .cin(1'b0), .s(ts509), .cout(tc509));
  logic [1:0] ts510; logic tc510;
  // tile 510 (compound_flagged_prefix, 2 bits) at level 26
  fam_prefix_brent_kung_w2_flagm_dual u_i510 (.a({ts504, ts503[1]}), .b({tc484, tc491}), .cin(1'b0), .s(ts510), .cout(tc510));
  logic [1:0] ts511; logic tc511;
  // tile 511 (compound_flagged_prefix, 2 bits) at level 26
  fam_prefix_brent_kung_w2_flagm_dual u_i511 (.a({1'b0, tc493}), .b({tc500, 1'b0}), .cin(1'b0), .s(ts511), .cout(tc511));
  logic [1:0] ts512; logic tc512;
  // tile 512 (compound_flagged_prefix, 2 bits) at level 26
  fam_prefix_brent_kung_w2_flagm_dual u_i512 (.a({1'b0, tc494}), .b({tc501, 1'b0}), .cin(1'b0), .s(ts512), .cout(tc512));
  logic [1:0] ts513; logic tc513;
  // tile 513 (compound_flagged_prefix, 2 bits) at level 26
  fam_prefix_brent_kung_w2_flagm_dual u_i513 (.a({1'b0, tc495}), .b({tc502, 1'b0}), .cin(1'b0), .s(ts513), .cout(tc513));
  logic [1:0] ts514; logic tc514;
  // tile 514 (compound_flagged_prefix, 2 bits) at level 26
  fam_prefix_brent_kung_w2_flagm_dual u_i514 (.a({1'b0, tc496}), .b({tc503, 1'b0}), .cin(1'b0), .s(ts514), .cout(tc514));
  logic [1:0] ts515; logic tc515;
  // tile 515 (compound_flagged_prefix, 2 bits) at level 27
  fam_prefix_brent_kung_w2_flagm_dual u_i515 (.a({ts506[0], ts505[1]}), .b({1'b0, tc498}), .cin(1'b0), .s(ts515), .cout(tc515));
  logic [1:0] ts516; logic tc516;
  // tile 516 (compound_flagged_prefix, 2 bits) at level 27
  fam_prefix_brent_kung_w2_flagm_dual u_i516 (.a({ts507[0], ts506[1]}), .b({ts511[0], tc499}), .cin(1'b0), .s(ts516), .cout(tc516));
  logic [1:0] ts517; logic tc517;
  // tile 517 (compound_flagged_prefix, 2 bits) at level 27
  fam_prefix_brent_kung_w2_flagm_dual u_i517 (.a({ts508[0], ts507[1]}), .b({ts512[0], ts511[1]}), .cin(1'b0), .s(ts517), .cout(tc517));
  logic [1:0] ts518; logic tc518;
  // tile 518 (compound_flagged_prefix, 2 bits) at level 27
  fam_prefix_brent_kung_w2_flagm_dual u_i518 (.a({ts509[0], ts508[1]}), .b({ts513[0], ts512[1]}), .cin(1'b0), .s(ts518), .cout(tc518));
  logic [1:0] ts519; logic tc519;
  // tile 519 (compound_flagged_prefix, 2 bits) at level 27
  fam_prefix_brent_kung_w2_flagm_dual u_i519 (.a({ts510[0], ts509[1]}), .b({ts514[0], ts513[1]}), .cin(1'b0), .s(ts519), .cout(tc519));
  logic ts520; logic tc520;
  // tile 520 (compound_flagged_prefix, 1 bits) at level 27
  fam_prefix_brent_kung_w1_flagm_dual u_i520 (.a({ts510[1]}), .b({ts514[1]}), .cin(1'b0), .s(ts520), .cout(tc520));
  logic [1:0] ts521; logic tc521;
  // tile 521 (compound_flagged_prefix, 2 bits) at level 27
  fam_prefix_brent_kung_w2_flagm_dual u_i521 (.a({tc507, 1'b0}), .b({tc511, 1'b0}), .cin(1'b0), .s(ts521), .cout(tc521));
  logic [1:0] ts522; logic tc522;
  // tile 522 (compound_flagged_prefix, 2 bits) at level 27
  fam_prefix_brent_kung_w2_flagm_dual u_i522 (.a({tc508, 1'b0}), .b({tc512, 1'b0}), .cin(1'b0), .s(ts522), .cout(tc522));
  logic [1:0] ts523; logic tc523;
  // tile 523 (compound_flagged_prefix, 2 bits) at level 27
  fam_prefix_brent_kung_w2_flagm_dual u_i523 (.a({tc509, 1'b0}), .b({tc513, 1'b0}), .cin(1'b0), .s(ts523), .cout(tc523));
  logic [1:0] ts524; logic tc524;
  // tile 524 (compound_flagged_prefix, 2 bits) at level 28
  fam_prefix_brent_kung_w2_flagm_dual u_i524 (.a({ts516[0], ts515[1]}), .b({1'b0, tc505}), .cin(1'b0), .s(ts524), .cout(tc524));
  logic [1:0] ts525; logic tc525;
  // tile 525 (compound_flagged_prefix, 2 bits) at level 28
  fam_prefix_brent_kung_w2_flagm_dual u_i525 (.a({ts517[0], ts516[1]}), .b({ts521[0], tc506}), .cin(1'b0), .s(ts525), .cout(tc525));
  logic [1:0] ts526; logic tc526;
  // tile 526 (compound_flagged_prefix, 2 bits) at level 28
  fam_prefix_brent_kung_w2_flagm_dual u_i526 (.a({ts518[0], ts517[1]}), .b({ts522[0], ts521[1]}), .cin(1'b0), .s(ts526), .cout(tc526));
  logic [1:0] ts527; logic tc527;
  // tile 527 (compound_flagged_prefix, 2 bits) at level 28
  fam_prefix_brent_kung_w2_flagm_dual u_i527 (.a({ts519[0], ts518[1]}), .b({ts523[0], ts522[1]}), .cin(1'b0), .s(ts527), .cout(tc527));
  logic [1:0] ts528; logic tc528;
  // tile 528 (compound_flagged_prefix, 2 bits) at level 28
  fam_prefix_brent_kung_w2_flagm_dual u_i528 (.a({ts520, ts519[1]}), .b({1'b0, ts523[1]}), .cin(1'b0), .s(ts528), .cout(tc528));
  logic [1:0] ts529; logic tc529;
  // tile 529 (compound_flagged_prefix, 2 bits) at level 28
  fam_prefix_brent_kung_w2_flagm_dual u_i529 (.a({tc517, 1'b0}), .b({tc521, 1'b0}), .cin(1'b0), .s(ts529), .cout(tc529));
  logic [1:0] ts530; logic tc530;
  // tile 530 (compound_flagged_prefix, 2 bits) at level 28
  fam_prefix_brent_kung_w2_flagm_dual u_i530 (.a({tc518, 1'b0}), .b({tc522, 1'b0}), .cin(1'b0), .s(ts530), .cout(tc530));
  logic [1:0] ts531; logic tc531;
  // tile 531 (compound_flagged_prefix, 2 bits) at level 28
  fam_prefix_brent_kung_w2_flagm_dual u_i531 (.a({tc519, 1'b0}), .b({tc523, 1'b0}), .cin(1'b0), .s(ts531), .cout(tc531));
  logic [1:0] ts532; logic tc532;
  // tile 532 (compound_flagged_prefix, 2 bits) at level 29
  fam_prefix_brent_kung_w2_flagm_dual u_i532 (.a({ts525[0], ts524[1]}), .b({1'b0, tc515}), .cin(1'b0), .s(ts532), .cout(tc532));
  logic [1:0] ts533; logic tc533;
  // tile 533 (compound_flagged_prefix, 2 bits) at level 29
  fam_prefix_brent_kung_w2_flagm_dual u_i533 (.a({ts526[0], ts525[1]}), .b({ts529[0], tc516}), .cin(1'b0), .s(ts533), .cout(tc533));
  logic [1:0] ts534; logic tc534;
  // tile 534 (compound_flagged_prefix, 2 bits) at level 29
  fam_prefix_brent_kung_w2_flagm_dual u_i534 (.a({ts527[0], ts526[1]}), .b({ts530[0], ts529[1]}), .cin(1'b0), .s(ts534), .cout(tc534));
  logic [1:0] ts535; logic tc535;
  // tile 535 (compound_flagged_prefix, 2 bits) at level 29
  fam_prefix_brent_kung_w2_flagm_dual u_i535 (.a({ts528[0], ts527[1]}), .b({ts531[0], ts530[1]}), .cin(1'b0), .s(ts535), .cout(tc535));
  logic ts536; logic tc536;
  // tile 536 (compound_flagged_prefix, 1 bits) at level 29
  fam_prefix_brent_kung_w1_flagm_dual u_i536 (.a({ts528[1]}), .b({ts531[1]}), .cin(1'b0), .s(ts536), .cout(tc536));
  logic [1:0] ts537; logic tc537;
  // tile 537 (compound_flagged_prefix, 2 bits) at level 29
  fam_prefix_brent_kung_w2_flagm_dual u_i537 (.a({tc526, 1'b0}), .b({tc529, 1'b0}), .cin(1'b0), .s(ts537), .cout(tc537));
  logic [1:0] ts538; logic tc538;
  // tile 538 (compound_flagged_prefix, 2 bits) at level 29
  fam_prefix_brent_kung_w2_flagm_dual u_i538 (.a({tc527, 1'b0}), .b({tc530, 1'b0}), .cin(1'b0), .s(ts538), .cout(tc538));
  logic [1:0] ts539; logic tc539;
  // tile 539 (compound_flagged_prefix, 2 bits) at level 30
  fam_prefix_brent_kung_w2_flagm_dual u_i539 (.a({ts533[0], ts532[1]}), .b({1'b0, tc524}), .cin(1'b0), .s(ts539), .cout(tc539));
  logic [1:0] ts540; logic tc540;
  // tile 540 (compound_flagged_prefix, 2 bits) at level 30
  fam_prefix_brent_kung_w2_flagm_dual u_i540 (.a({ts534[0], ts533[1]}), .b({ts537[0], tc525}), .cin(1'b0), .s(ts540), .cout(tc540));
  logic [1:0] ts541; logic tc541;
  // tile 541 (compound_flagged_prefix, 2 bits) at level 30
  fam_prefix_brent_kung_w2_flagm_dual u_i541 (.a({ts535[0], ts534[1]}), .b({ts538[0], ts537[1]}), .cin(1'b0), .s(ts541), .cout(tc541));
  logic [1:0] ts542; logic tc542;
  // tile 542 (compound_flagged_prefix, 2 bits) at level 30
  fam_prefix_brent_kung_w2_flagm_dual u_i542 (.a({ts536, ts535[1]}), .b({1'b0, ts538[1]}), .cin(1'b0), .s(ts542), .cout(tc542));
  logic [1:0] ts543; logic tc543;
  // tile 543 (compound_flagged_prefix, 2 bits) at level 30
  fam_prefix_brent_kung_w2_flagm_dual u_i543 (.a({tc534, 1'b0}), .b({tc537, 1'b0}), .cin(1'b0), .s(ts543), .cout(tc543));
  logic [1:0] ts544; logic tc544;
  // tile 544 (compound_flagged_prefix, 2 bits) at level 30
  fam_prefix_brent_kung_w2_flagm_dual u_i544 (.a({tc535, 1'b0}), .b({tc538, 1'b0}), .cin(1'b0), .s(ts544), .cout(tc544));
  logic [1:0] ts545; logic tc545;
  // tile 545 (compound_flagged_prefix, 2 bits) at level 31
  fam_prefix_brent_kung_w2_flagm_dual u_i545 (.a({ts540[0], ts539[1]}), .b({1'b0, tc532}), .cin(1'b0), .s(ts545), .cout(tc545));
  logic [1:0] ts546; logic tc546;
  // tile 546 (compound_flagged_prefix, 2 bits) at level 31
  fam_prefix_brent_kung_w2_flagm_dual u_i546 (.a({ts541[0], ts540[1]}), .b({ts543[0], tc533}), .cin(1'b0), .s(ts546), .cout(tc546));
  logic [1:0] ts547; logic tc547;
  // tile 547 (compound_flagged_prefix, 2 bits) at level 31
  fam_prefix_brent_kung_w2_flagm_dual u_i547 (.a({ts542[0], ts541[1]}), .b({ts544[0], ts543[1]}), .cin(1'b0), .s(ts547), .cout(tc547));
  logic ts548; logic tc548;
  // tile 548 (compound_flagged_prefix, 1 bits) at level 31
  fam_prefix_brent_kung_w1_flagm_dual u_i548 (.a({ts542[1]}), .b({ts544[1]}), .cin(1'b0), .s(ts548), .cout(tc548));
  logic [1:0] ts549; logic tc549;
  // tile 549 (compound_flagged_prefix, 2 bits) at level 31
  fam_prefix_brent_kung_w2_flagm_dual u_i549 (.a({tc541, 1'b0}), .b({tc543, 1'b0}), .cin(1'b0), .s(ts549), .cout(tc549));
  logic [1:0] ts550; logic tc550;
  // tile 550 (compound_flagged_prefix, 2 bits) at level 32
  fam_prefix_brent_kung_w2_flagm_dual u_i550 (.a({ts546[0], ts545[1]}), .b({1'b0, tc539}), .cin(1'b0), .s(ts550), .cout(tc550));
  logic [1:0] ts551; logic tc551;
  // tile 551 (compound_flagged_prefix, 2 bits) at level 32
  fam_prefix_brent_kung_w2_flagm_dual u_i551 (.a({ts547[0], ts546[1]}), .b({ts549[0], tc540}), .cin(1'b0), .s(ts551), .cout(tc551));
  logic [1:0] ts552; logic tc552;
  // tile 552 (compound_flagged_prefix, 2 bits) at level 32
  fam_prefix_brent_kung_w2_flagm_dual u_i552 (.a({ts548, ts547[1]}), .b({1'b0, ts549[1]}), .cin(1'b0), .s(ts552), .cout(tc552));
  logic [1:0] ts553; logic tc553;
  // tile 553 (compound_flagged_prefix, 2 bits) at level 32
  fam_prefix_brent_kung_w2_flagm_dual u_i553 (.a({tc547, 1'b0}), .b({tc549, 1'b0}), .cin(1'b0), .s(ts553), .cout(tc553));
  assign pp0 = (a[0] & b[0]);
  assign pp1 = (a[0] & b[1]);
  assign pp2 = (a[0] & b[2]);
  assign pp3 = (a[0] & b[3]);
  assign pp4 = (a[0] & b[4]);
  assign pp5 = (a[0] & b[5]);
  assign pp6 = (a[0] & b[6]);
  assign pp7 = (a[0] & b[7]);
  assign pp8 = (a[0] & b[8]);
  assign pp9 = (a[0] & b[9]);
  assign pp10 = (a[0] & b[10]);
  assign pp11 = (a[1] & b[0]);
  assign pp12 = (a[1] & b[1]);
  assign pp13 = (a[1] & b[2]);
  assign pp14 = (a[1] & b[3]);
  assign pp15 = (a[1] & b[4]);
  assign pp16 = (a[1] & b[5]);
  assign pp17 = (a[1] & b[6]);
  assign pp18 = (a[1] & b[7]);
  assign pp19 = (a[1] & b[8]);
  assign pp20 = (a[1] & b[9]);
  assign pp21 = (a[1] & b[10]);
  assign pp22 = (a[2] & b[0]);
  assign pp23 = (a[2] & b[1]);
  assign pp24 = (a[2] & b[2]);
  assign pp25 = (a[2] & b[3]);
  assign pp26 = (a[2] & b[4]);
  assign pp27 = (a[2] & b[5]);
  assign pp28 = (a[2] & b[6]);
  assign pp29 = (a[2] & b[7]);
  assign pp30 = (a[2] & b[8]);
  assign pp31 = (a[2] & b[9]);
  assign pp32 = (a[2] & b[10]);
  assign pp33 = (a[3] & b[0]);
  assign pp34 = (a[3] & b[1]);
  assign pp35 = (a[3] & b[2]);
  assign pp36 = (a[3] & b[3]);
  assign pp37 = (a[3] & b[4]);
  assign pp38 = (a[3] & b[5]);
  assign pp39 = (a[3] & b[6]);
  assign pp40 = (a[3] & b[7]);
  assign pp41 = (a[3] & b[8]);
  assign pp42 = (a[3] & b[9]);
  assign pp43 = (a[3] & b[10]);
  assign pp44 = (a[4] & b[0]);
  assign pp45 = (a[4] & b[1]);
  assign pp46 = (a[4] & b[2]);
  assign pp47 = (a[4] & b[3]);
  assign pp48 = (a[4] & b[4]);
  assign pp49 = (a[4] & b[5]);
  assign pp50 = (a[4] & b[6]);
  assign pp51 = (a[4] & b[7]);
  assign pp52 = (a[4] & b[8]);
  assign pp53 = (a[4] & b[9]);
  assign pp54 = (a[4] & b[10]);
  assign pp55 = (a[5] & b[0]);
  assign pp56 = (a[5] & b[1]);
  assign pp57 = (a[5] & b[2]);
  assign pp58 = (a[5] & b[3]);
  assign pp59 = (a[5] & b[4]);
  assign pp60 = (a[5] & b[5]);
  assign pp61 = (a[5] & b[6]);
  assign pp62 = (a[5] & b[7]);
  assign pp63 = (a[5] & b[8]);
  assign pp64 = (a[5] & b[9]);
  assign pp65 = (a[5] & b[10]);
  assign pp66 = (a[6] & b[0]);
  assign pp67 = (a[6] & b[1]);
  assign pp68 = (a[6] & b[2]);
  assign pp69 = (a[6] & b[3]);
  assign pp70 = (a[6] & b[4]);
  assign pp71 = (a[6] & b[5]);
  assign pp72 = (a[6] & b[6]);
  assign pp73 = (a[6] & b[7]);
  assign pp74 = (a[6] & b[8]);
  assign pp75 = (a[6] & b[9]);
  assign pp76 = (a[6] & b[10]);
  assign pp77 = (a[7] & b[0]);
  assign pp78 = (a[7] & b[1]);
  assign pp79 = (a[7] & b[2]);
  assign pp80 = (a[7] & b[3]);
  assign pp81 = (a[7] & b[4]);
  assign pp82 = (a[7] & b[5]);
  assign pp83 = (a[7] & b[6]);
  assign pp84 = (a[7] & b[7]);
  assign pp85 = (a[7] & b[8]);
  assign pp86 = (a[7] & b[9]);
  assign pp87 = (a[7] & b[10]);
  assign pp88 = (a[8] & b[0]);
  assign pp89 = (a[8] & b[1]);
  assign pp90 = (a[8] & b[2]);
  assign pp91 = (a[8] & b[3]);
  assign pp92 = (a[8] & b[4]);
  assign pp93 = (a[8] & b[5]);
  assign pp94 = (a[8] & b[6]);
  assign pp95 = (a[8] & b[7]);
  assign pp96 = (a[8] & b[8]);
  assign pp97 = (a[8] & b[9]);
  assign pp98 = (a[8] & b[10]);
  assign pp99 = (a[9] & b[0]);
  assign pp100 = (a[9] & b[1]);
  assign pp101 = (a[9] & b[2]);
  assign pp102 = (a[9] & b[3]);
  assign pp103 = (a[9] & b[4]);
  assign pp104 = (a[9] & b[5]);
  assign pp105 = (a[9] & b[6]);
  assign pp106 = (a[9] & b[7]);
  assign pp107 = (a[9] & b[8]);
  assign pp108 = (a[9] & b[9]);
  assign pp109 = (a[9] & b[10]);
  assign pp110 = (a[10] & b[0]);
  assign pp111 = (a[10] & b[1]);
  assign pp112 = (a[10] & b[2]);
  assign pp113 = (a[10] & b[3]);
  assign pp114 = (a[10] & b[4]);
  assign pp115 = (a[10] & b[5]);
  assign pp116 = (a[10] & b[6]);
  assign pp117 = (a[10] & b[7]);
  assign pp118 = (a[10] & b[8]);
  assign pp119 = (a[10] & b[9]);
  assign pp120 = (a[10] & b[10]);
  assign t121 = ts552[0] ^ ts553[0];
  assign t122 = ts552[0] & ts553[0];
  assign t123 = ts552[1] ^ ts553[1];
  assign t124 = ts552[1] & ts553[1];
  logic [21:0] row_s, row_c;
  assign row_s = {t122, tc551, ts551[1], ts551[0], ts550[1], ts550[0], ts545[0], ts539[0], ts532[0], ts524[0], ts515[0], ts505[0], ts498[0], ts486[0], ts457[0], ts414[0], ts360[0], ts293[0], ts221[0], ts150[0], ts76[0], ts1[0]};
  assign row_c = {t123, t121, tc546, tc550, tc545, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
  // hybrid final adder: regions [0, 7, 14, 22] of kinds ['ripple', 'skip', 'skip'] on the measured_tree_profile profile (delay_bound_boundary_enumeration)
  logic rg0_co;
  fam_adder_ripple_carry #(.W(7), .CHUNK(1), .FORM(0)) u_rg0 (.a(row_s[6:0]), .b(row_c[6:0]), .cin(1'b0), .s(p[6:0]), .cout(rg0_co));
  logic rg1_co;
  fam_adder_carry_skip_w7 u_rg1 (.a(row_s[13:7]), .b(row_c[13:7]), .cin(rg0_co), .s(p[13:7]), .cout(rg1_co));
  logic rg2_co;
  fam_adder_carry_skip_w8 u_rg2 (.a(row_s[21:14]), .b(row_c[21:14]), .cin(rg1_co), .s(p[21:14]), .cout(rg2_co));
endmodule


// segmented_grid (rectangular, depth 2): 2 x 1 segment products of 2 x 4 bits (booth_recoded_parallel) merged by shift_add_tree (merge adder manchester_carry_chain)
module fam_mul_segmented_grid_w3_u_pf3c3f225 (input logic [2:0] a, input logic [2:0] b, output logic [5:0] p);
  logic [3:0] ae; assign ae = {{(4-3){1'b0}}, a};
  logic [3:0] be; assign be = {{(4-3){1'b0}}, b};
  logic [3:0] sa00; assign sa00 = {{2{1'b0}}, ae[1:0]};
  logic [3:0] sb00; assign sb00 = be[3:0];
  logic [7:0] sp00;
  // segment product (0, 0): a segmented grid of depth 1
  fam_mul_segmented_grid_w3_u_pf3c3f225_g00 u_g00 (.a(sa00), .b(sb00), .p(sp00));
  logic [3:0] sa10; assign sa10 = {{2{1'b0}}, ae[3:2]};
  logic [3:0] sb10; assign sb10 = be[3:0];
  logic [7:0] sp10;
  // segment product (1, 0): a segmented grid of depth 1
  fam_mul_segmented_grid_w3_u_pf3c3f225_g10 u_g10 (.a(sa10), .b(sb10), .p(sp10));
  logic [9:0] t_sp00; assign t_sp00 = {{(10-8){1'b0}}, sp00} << 0;
  logic [9:0] t_sp10; assign t_sp10 = {{(10-8){1'b0}}, sp10} << 2;
  logic [10:0] tr0;
  // merge tree adder 0
  fam_adder_manchester_carry_chain #(.W(10), .SEG(2), .VARSKIP(1)) u1 (.a(t_sp00), .b(t_sp10), .cin(1'b0), .s(tr0[9:0]), .cout(tr0[10]));
  logic [9:0] full; assign full = tr0[9:0];
  assign p = full[5:0];
endmodule


// segmented_grid (rectangular, depth 1): 2 x 1 segment products of 2 x 4 bits (booth_recoded_parallel) merged by shift_add_tree (merge adder manchester_carry_chain)
module fam_mul_segmented_grid_w3_u_pf3c3f225_g00 (input logic [3:0] a, input logic [3:0] b, output logic [7:0] p);
  logic [3:0] ae; assign ae = a;
  logic [3:0] be; assign be = b;
  logic [3:0] sa00; assign sa00 = {{2{1'b0}}, ae[1:0]};
  logic [3:0] sb00; assign sb00 = be[3:0];
  logic [7:0] sp00;
  // segment product (0, 0) (booth_recoded_parallel)
  fam_mul_booth4_dadda_3_2_w4_u_p4789ec73 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [3:0] sa10; assign sa10 = {{2{1'b0}}, ae[3:2]};
  logic [3:0] sb10; assign sb10 = be[3:0];
  logic [7:0] sp10;
  // segment product (1, 0) (booth_recoded_parallel)
  fam_mul_booth4_dadda_3_2_w4_u_p4789ec73 u2 (.a(sa10), .b(sb10), .p(sp10));
  logic [9:0] t_sp00; assign t_sp00 = {{(10-8){1'b0}}, sp00} << 0;
  logic [9:0] t_sp10; assign t_sp10 = {{(10-8){1'b0}}, sp10} << 2;
  logic [10:0] tr0;
  // merge tree adder 0
  fam_adder_manchester_carry_chain #(.W(10), .SEG(2), .VARSKIP(1)) u3 (.a(t_sp00), .b(t_sp10), .cin(1'b0), .s(tr0[9:0]), .cout(tr0[10]));
  logic [9:0] full; assign full = tr0[9:0];
  assign p = full[7:0];
endmodule






// segmented_grid (rectangular, depth 1): 2 x 1 segment products of 2 x 4 bits (booth_recoded_parallel) merged by shift_add_tree (merge adder manchester_carry_chain)
module fam_mul_segmented_grid_w3_u_pf3c3f225_g10 (input logic [3:0] a, input logic [3:0] b, output logic [7:0] p);
  logic [3:0] ae; assign ae = a;
  logic [3:0] be; assign be = b;
  logic [3:0] sa00; assign sa00 = {{2{1'b0}}, ae[1:0]};
  logic [3:0] sb00; assign sb00 = be[3:0];
  logic [7:0] sp00;
  // segment product (0, 0) (booth_recoded_parallel)
  fam_mul_booth4_dadda_3_2_w4_u_p4789ec73 u1 (.a(sa00), .b(sb00), .p(sp00));
  logic [3:0] sa10; assign sa10 = {{2{1'b0}}, ae[3:2]};
  logic [3:0] sb10; assign sb10 = be[3:0];
  logic [7:0] sp10;
  // segment product (1, 0) (booth_recoded_parallel)
  fam_mul_booth4_dadda_3_2_w4_u_p4789ec73 u2 (.a(sa10), .b(sb10), .p(sp10));
  logic [9:0] t_sp00; assign t_sp00 = {{(10-8){1'b0}}, sp00} << 0;
  logic [9:0] t_sp10; assign t_sp10 = {{(10-8){1'b0}}, sp10} << 2;
  logic [10:0] tr0;
  // merge tree adder 0
  fam_adder_manchester_carry_chain #(.W(10), .SEG(2), .VARSKIP(1)) u3 (.a(t_sp00), .b(t_sp10), .cin(1'b0), .s(tr0[9:0]), .cout(tr0[10]));
  logic [9:0] full; assign full = tr0[9:0];
  assign p = full[7:0];
endmodule









module fam_prefix_arrival_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_w24 (input logic [23:0] a, input logic [23:0] b, input logic cin,
  output logic [23:0] s, output logic cout);
  // prefix graph: {'n': 24, 'levels': 5, 'size': 89, 'fanout': 5, 'tracks': 8, 'exact_split': True, 'valency': 2}
  logic [23:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [23:0] g0, p0;
  assign g0 = {gi[23:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_1_2, P_1_2, G_2_3, P_2_3, G_3_4, P_3_4, G_4_5, P_4_5, G_5_6, P_5_6, G_6_7, P_6_7, G_7_8, P_7_8, G_8_9, P_8_9, G_9_10, P_9_10, G_10_11, P_10_11, G_11_12, P_11_12, G_12_13, P_12_13, G_13_14, P_13_14, G_14_15, P_14_15, G_15_16, P_15_16, G_16_17, P_16_17, G_17_18, P_17_18, G_18_19, P_18_19, G_19_20, P_19_20, G_20_21, P_20_21, G_21_22, P_21_22, G_22_23, P_22_23, G_0_2, G_0_3, G_1_4, P_1_4, G_2_5, P_2_5, G_3_6, P_3_6, G_4_7, P_4_7, G_5_8, P_5_8, G_6_9, P_6_9, G_7_10, P_7_10, G_8_11, P_8_11, G_9_12, P_9_12, G_10_13, P_10_13, G_11_14, P_11_14, G_12_15, P_12_15, G_13_16, P_13_16, G_14_17, P_14_17, G_15_18, P_15_18, G_16_19, P_16_19, G_17_20, P_17_20, G_18_21, P_18_21, G_19_22, P_19_22, G_20_23, P_20_23, G_0_4, G_0_5, G_0_6, G_0_7, G_1_8, P_1_8, G_2_9, P_2_9, G_3_10, P_3_10, G_4_11, P_4_11, G_5_12, P_5_12, G_6_13, P_6_13, G_7_14, P_7_14, G_8_15, P_8_15, G_9_16, P_9_16, G_10_17, P_10_17, G_11_18, P_11_18, G_12_19, P_12_19, G_13_20, P_13_20, G_14_21, P_14_21, G_15_22, P_15_22, G_16_23, P_16_23, G_0_8, G_0_9, G_0_10, G_0_11, G_0_12, G_0_13, G_0_14, G_0_15, G_1_16, P_1_16, G_2_17, P_2_17, G_3_18, P_3_18, G_4_19, P_4_19, G_5_20, P_5_20, G_6_21, P_6_21, G_7_22, P_7_22, G_8_23, P_8_23, G_0_16, G_0_17, G_0_18, G_0_19, G_0_20, G_0_21, G_0_22, G_0_23;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_5_6 = g0[6] | (p0[6] & g0[5]);
  assign P_5_6 = p0[6] & p0[5];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_7_8 = g0[8] | (p0[8] & g0[7]);
  assign P_7_8 = p0[8] & p0[7];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_9_10 = g0[10] | (p0[10] & g0[9]);
  assign P_9_10 = p0[10] & p0[9];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_11_12 = g0[12] | (p0[12] & g0[11]);
  assign P_11_12 = p0[12] & p0[11];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_13_14 = g0[14] | (p0[14] & g0[13]);
  assign P_13_14 = p0[14] & p0[13];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_15_16 = g0[16] | (p0[16] & g0[15]);
  assign P_15_16 = p0[16] & p0[15];
  assign G_16_17 = g0[17] | (p0[17] & g0[16]);
  assign P_16_17 = p0[17] & p0[16];
  assign G_17_18 = g0[18] | (p0[18] & g0[17]);
  assign P_17_18 = p0[18] & p0[17];
  assign G_18_19 = g0[19] | (p0[19] & g0[18]);
  assign P_18_19 = p0[19] & p0[18];
  assign G_19_20 = g0[20] | (p0[20] & g0[19]);
  assign P_19_20 = p0[20] & p0[19];
  assign G_20_21 = g0[21] | (p0[21] & g0[20]);
  assign P_20_21 = p0[21] & p0[20];
  assign G_21_22 = g0[22] | (p0[22] & g0[21]);
  assign P_21_22 = p0[22] & p0[21];
  assign G_22_23 = g0[23] | (p0[23] & g0[22]);
  assign P_22_23 = p0[23] & p0[22];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_1_4 = G_3_4 | (P_3_4 & G_1_2);
  assign P_1_4 = P_3_4 & P_1_2;
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_3_6 = G_5_6 | (P_5_6 & G_3_4);
  assign P_3_6 = P_5_6 & P_3_4;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_5_8 = G_7_8 | (P_7_8 & G_5_6);
  assign P_5_8 = P_7_8 & P_5_6;
  assign G_6_9 = G_8_9 | (P_8_9 & G_6_7);
  assign P_6_9 = P_8_9 & P_6_7;
  assign G_7_10 = G_9_10 | (P_9_10 & G_7_8);
  assign P_7_10 = P_9_10 & P_7_8;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_9_12 = G_11_12 | (P_11_12 & G_9_10);
  assign P_9_12 = P_11_12 & P_9_10;
  assign G_10_13 = G_12_13 | (P_12_13 & G_10_11);
  assign P_10_13 = P_12_13 & P_10_11;
  assign G_11_14 = G_13_14 | (P_13_14 & G_11_12);
  assign P_11_14 = P_13_14 & P_11_12;
  assign G_12_15 = G_14_15 | (P_14_15 & G_12_13);
  assign P_12_15 = P_14_15 & P_12_13;
  assign G_13_16 = G_15_16 | (P_15_16 & G_13_14);
  assign P_13_16 = P_15_16 & P_13_14;
  assign G_14_17 = G_16_17 | (P_16_17 & G_14_15);
  assign P_14_17 = P_16_17 & P_14_15;
  assign G_15_18 = G_17_18 | (P_17_18 & G_15_16);
  assign P_15_18 = P_17_18 & P_15_16;
  assign G_16_19 = G_18_19 | (P_18_19 & G_16_17);
  assign P_16_19 = P_18_19 & P_16_17;
  assign G_17_20 = G_19_20 | (P_19_20 & G_17_18);
  assign P_17_20 = P_19_20 & P_17_18;
  assign G_18_21 = G_20_21 | (P_20_21 & G_18_19);
  assign P_18_21 = P_20_21 & P_18_19;
  assign G_19_22 = G_21_22 | (P_21_22 & G_19_20);
  assign P_19_22 = P_21_22 & P_19_20;
  assign G_20_23 = G_22_23 | (P_22_23 & G_20_21);
  assign P_20_23 = P_22_23 & P_20_21;
  assign G_0_4 = G_1_4 | (P_1_4 & g0[0]);
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  assign G_0_6 = G_3_6 | (P_3_6 & G_0_2);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_1_8 = G_5_8 | (P_5_8 & G_1_4);
  assign P_1_8 = P_5_8 & P_1_4;
  assign G_2_9 = G_6_9 | (P_6_9 & G_2_5);
  assign P_2_9 = P_6_9 & P_2_5;
  assign G_3_10 = G_7_10 | (P_7_10 & G_3_6);
  assign P_3_10 = P_7_10 & P_3_6;
  assign G_4_11 = G_8_11 | (P_8_11 & G_4_7);
  assign P_4_11 = P_8_11 & P_4_7;
  assign G_5_12 = G_9_12 | (P_9_12 & G_5_8);
  assign P_5_12 = P_9_12 & P_5_8;
  assign G_6_13 = G_10_13 | (P_10_13 & G_6_9);
  assign P_6_13 = P_10_13 & P_6_9;
  assign G_7_14 = G_11_14 | (P_11_14 & G_7_10);
  assign P_7_14 = P_11_14 & P_7_10;
  assign G_8_15 = G_12_15 | (P_12_15 & G_8_11);
  assign P_8_15 = P_12_15 & P_8_11;
  assign G_9_16 = G_13_16 | (P_13_16 & G_9_12);
  assign P_9_16 = P_13_16 & P_9_12;
  assign G_10_17 = G_14_17 | (P_14_17 & G_10_13);
  assign P_10_17 = P_14_17 & P_10_13;
  assign G_11_18 = G_15_18 | (P_15_18 & G_11_14);
  assign P_11_18 = P_15_18 & P_11_14;
  assign G_12_19 = G_16_19 | (P_16_19 & G_12_15);
  assign P_12_19 = P_16_19 & P_12_15;
  assign G_13_20 = G_17_20 | (P_17_20 & G_13_16);
  assign P_13_20 = P_17_20 & P_13_16;
  assign G_14_21 = G_18_21 | (P_18_21 & G_14_17);
  assign P_14_21 = P_18_21 & P_14_17;
  assign G_15_22 = G_19_22 | (P_19_22 & G_15_18);
  assign P_15_22 = P_19_22 & P_15_18;
  assign G_16_23 = G_20_23 | (P_20_23 & G_16_19);
  assign P_16_23 = P_20_23 & P_16_19;
  assign G_0_8 = G_1_8 | (P_1_8 & g0[0]);
  assign G_0_9 = G_2_9 | (P_2_9 & G_0_1);
  assign G_0_10 = G_3_10 | (P_3_10 & G_0_2);
  assign G_0_11 = G_4_11 | (P_4_11 & G_0_3);
  assign G_0_12 = G_5_12 | (P_5_12 & G_0_4);
  assign G_0_13 = G_6_13 | (P_6_13 & G_0_5);
  assign G_0_14 = G_7_14 | (P_7_14 & G_0_6);
  assign G_0_15 = G_8_15 | (P_8_15 & G_0_7);
  assign G_1_16 = G_9_16 | (P_9_16 & G_1_8);
  assign P_1_16 = P_9_16 & P_1_8;
  assign G_2_17 = G_10_17 | (P_10_17 & G_2_9);
  assign P_2_17 = P_10_17 & P_2_9;
  assign G_3_18 = G_11_18 | (P_11_18 & G_3_10);
  assign P_3_18 = P_11_18 & P_3_10;
  assign G_4_19 = G_12_19 | (P_12_19 & G_4_11);
  assign P_4_19 = P_12_19 & P_4_11;
  assign G_5_20 = G_13_20 | (P_13_20 & G_5_12);
  assign P_5_20 = P_13_20 & P_5_12;
  assign G_6_21 = G_14_21 | (P_14_21 & G_6_13);
  assign P_6_21 = P_14_21 & P_6_13;
  assign G_7_22 = G_15_22 | (P_15_22 & G_7_14);
  assign P_7_22 = P_15_22 & P_7_14;
  assign G_8_23 = G_16_23 | (P_16_23 & G_8_15);
  assign P_8_23 = P_16_23 & P_8_15;
  assign G_0_16 = G_1_16 | (P_1_16 & g0[0]);
  assign G_0_17 = G_2_17 | (P_2_17 & G_0_1);
  assign G_0_18 = G_3_18 | (P_3_18 & G_0_2);
  assign G_0_19 = G_4_19 | (P_4_19 & G_0_3);
  assign G_0_20 = G_5_20 | (P_5_20 & G_0_4);
  assign G_0_21 = G_6_21 | (P_6_21 & G_0_5);
  assign G_0_22 = G_7_22 | (P_7_22 & G_0_6);
  assign G_0_23 = G_8_23 | (P_8_23 & G_0_7);
  logic [24:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign c[15] = G_0_14;
  assign c[16] = G_0_15;
  assign c[17] = G_0_16;
  assign c[18] = G_0_17;
  assign c[19] = G_0_18;
  assign c[20] = G_0_19;
  assign c[21] = G_0_20;
  assign c[22] = G_0_21;
  assign c[23] = G_0_22;
  assign c[24] = G_0_23;
  assign s = pi_ ^ c[23:0];
  assign cout = c[24];
endmodule



// lzd_cell_tree (pair_cell, binary_count, valid flags propagated): the leading zeros of a 64-bit word

module fam_prefix_arrival_0_0_0_0_0_1_1_1_1_1_1_1_1_1_2_2_2_2_2_2_2_2_2_3_3_3_3_3_3_3_3_3_4_4_4_4_4_4_4_4_4_4_5_5_5_5_5_5_5_5_5_6_6_6_6_6_6_6_6_6_7_7_7_7_7_w65 (input logic [64:0] a, input logic [64:0] b, input logic cin,
  output logic [64:0] s, output logic cout);
  // prefix graph: {'n': 65, 'levels': 11, 'size': 250, 'fanout': 9, 'tracks': 7, 'exact_split': True, 'valency': 2}
  logic [64:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [64:0] g0, p0;
  assign g0 = {gi[64:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_1_2, P_1_2, G_2_3, P_2_3, G_3_4, P_3_4, G_5_6, P_5_6, G_6_7, P_6_7, G_7_8, P_7_8, G_8_9, P_8_9, G_9_10, P_9_10, G_10_11, P_10_11, G_11_12, P_11_12, G_12_13, P_12_13, G_14_15, P_14_15, G_15_16, P_15_16, G_16_17, P_16_17, G_17_18, P_17_18, G_18_19, P_18_19, G_19_20, P_19_20, G_20_21, P_20_21, G_21_22, P_21_22, G_23_24, P_23_24, G_24_25, P_24_25, G_25_26, P_25_26, G_26_27, P_26_27, G_27_28, P_27_28, G_28_29, P_28_29, G_29_30, P_29_30, G_30_31, P_30_31, G_32_33, P_32_33, G_33_34, P_33_34, G_34_35, P_34_35, G_35_36, P_35_36, G_36_37, P_36_37, G_37_38, P_37_38, G_38_39, P_38_39, G_39_40, P_39_40, G_40_41, P_40_41, G_42_43, P_42_43, G_43_44, P_43_44, G_44_45, P_44_45, G_45_46, P_45_46, G_46_47, P_46_47, G_47_48, P_47_48, G_48_49, P_48_49, G_49_50, P_49_50, G_51_52, P_51_52, G_52_53, P_52_53, G_53_54, P_53_54, G_54_55, P_54_55, G_55_56, P_55_56, G_56_57, P_56_57, G_57_58, P_57_58, G_58_59, P_58_59, G_60_61, P_60_61, G_61_62, P_61_62, G_62_63, P_62_63, G_63_64, P_63_64, G_0_2, G_0_3, G_1_4, P_1_4, G_3_5, P_3_5, G_5_8, P_5_8, G_6_9, P_6_9, G_7_10, P_7_10, G_8_11, P_8_11, G_9_12, P_9_12, G_10_13, P_10_13, G_12_14, P_12_14, G_14_17, P_14_17, G_15_18, P_15_18, G_16_19, P_16_19, G_17_20, P_17_20, G_18_21, P_18_21, G_19_22, P_19_22, G_21_23, P_21_23, G_23_26, P_23_26, G_24_27, P_24_27, G_25_28, P_25_28, G_26_29, P_26_29, G_27_30, P_27_30, G_28_31, P_28_31, G_30_32, P_30_32, G_32_35, P_32_35, G_33_36, P_33_36, G_34_37, P_34_37, G_35_38, P_35_38, G_36_39, P_36_39, G_37_40, P_37_40, G_38_41, P_38_41, G_40_42, P_40_42, G_42_45, P_42_45, G_43_46, P_43_46, G_44_47, P_44_47, G_45_48, P_45_48, G_46_49, P_46_49, G_47_50, P_47_50, G_49_51, P_49_51, G_51_54, P_51_54, G_52_55, P_52_55, G_53_56, P_53_56, G_54_57, P_54_57, G_55_58, P_55_58, G_56_59, P_56_59, G_58_60, P_58_60, G_60_63, P_60_63, G_61_64, P_61_64, G_0_4, G_0_5, G_1_6, P_1_6, G_3_7, P_3_7, G_5_12, P_5_12, G_6_13, P_6_13, G_8_14, P_8_14, G_10_15, P_10_15, G_12_16, P_12_16, G_14_21, P_14_21, G_15_22, P_15_22, G_17_23, P_17_23, G_19_24, P_19_24, G_21_25, P_21_25, G_23_30, P_23_30, G_24_31, P_24_31, G_26_32, P_26_32, G_28_33, P_28_33, G_30_34, P_30_34, G_32_39, P_32_39, G_33_40, P_33_40, G_34_41, P_34_41, G_36_42, P_36_42, G_38_43, P_38_43, G_40_44, P_40_44, G_42_49, P_42_49, G_43_50, P_43_50, G_45_51, P_45_51, G_47_52, P_47_52, G_49_53, P_49_53, G_51_58, P_51_58, G_52_59, P_52_59, G_54_60, P_54_60, G_56_61, P_56_61, G_58_62, P_58_62, G_0_6, G_0_7, G_0_8, G_0_9, G_1_10, P_1_10, G_3_11, P_3_11, G_0_12, G_0_13, G_6_17, P_6_17, G_8_18, P_8_18, G_10_19, P_10_19, G_12_20, P_12_20, G_15_26, P_15_26, G_17_27, P_17_27, G_19_28, P_19_28, G_21_29, P_21_29, G_24_35, P_24_35, G_26_36, P_26_36, G_28_37, P_28_37, G_30_38, P_30_38, G_32_44, P_32_44, G_34_45, P_34_45, G_36_46, P_36_46, G_38_47, P_38_47, G_40_48, P_40_48, G_43_54, P_43_54, G_45_55, P_45_55, G_47_56, P_47_56, G_49_57, P_49_57, G_52_63, P_52_63, G_54_64, P_54_64, G_0_10, G_0_11, G_0_14, G_0_15, G_3_16, P_3_16, G_0_17, G_0_18, G_0_19, G_0_21, G_8_24, P_8_24, G_12_25, P_12_25, G_17_33, P_17_33, G_21_34, P_21_34, G_24_42, P_24_42, G_28_43, P_28_43, G_32_51, P_32_51, G_36_52, P_36_52, G_40_53, P_40_53, G_45_61, P_45_61, G_49_62, P_49_62, G_0_16, G_0_20, G_0_22, G_3_23, P_3_23, G_0_24, G_0_25, G_0_26, G_0_28, G_12_32, P_12_32, G_17_41, P_17_41, G_24_50, P_24_50, G_32_59, P_32_59, G_40_60, P_40_60, G_0_23, G_0_27, G_0_29, G_0_30, G_3_31, P_3_31, G_0_32, G_0_33, G_0_34, G_0_36, G_12_40, P_12_40, G_0_41, G_17_49, P_17_49, G_24_58, P_24_58, G_0_31, G_0_35, G_0_37, G_0_38, G_3_39, P_3_39, G_0_40, G_0_42, G_0_43, G_0_45, G_0_49, G_0_50, G_0_58, G_0_39, G_0_44, G_0_46, G_0_47, G_3_48, P_3_48, G_0_51, G_0_52, G_0_54, G_0_59, G_0_48, G_0_53, G_0_55, G_0_56, G_3_57, P_3_57, G_0_60, G_0_61, G_0_63, G_0_57, G_0_62, G_0_64;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_5_6 = g0[6] | (p0[6] & g0[5]);
  assign P_5_6 = p0[6] & p0[5];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_7_8 = g0[8] | (p0[8] & g0[7]);
  assign P_7_8 = p0[8] & p0[7];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_9_10 = g0[10] | (p0[10] & g0[9]);
  assign P_9_10 = p0[10] & p0[9];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_11_12 = g0[12] | (p0[12] & g0[11]);
  assign P_11_12 = p0[12] & p0[11];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_15_16 = g0[16] | (p0[16] & g0[15]);
  assign P_15_16 = p0[16] & p0[15];
  assign G_16_17 = g0[17] | (p0[17] & g0[16]);
  assign P_16_17 = p0[17] & p0[16];
  assign G_17_18 = g0[18] | (p0[18] & g0[17]);
  assign P_17_18 = p0[18] & p0[17];
  assign G_18_19 = g0[19] | (p0[19] & g0[18]);
  assign P_18_19 = p0[19] & p0[18];
  assign G_19_20 = g0[20] | (p0[20] & g0[19]);
  assign P_19_20 = p0[20] & p0[19];
  assign G_20_21 = g0[21] | (p0[21] & g0[20]);
  assign P_20_21 = p0[21] & p0[20];
  assign G_21_22 = g0[22] | (p0[22] & g0[21]);
  assign P_21_22 = p0[22] & p0[21];
  assign G_23_24 = g0[24] | (p0[24] & g0[23]);
  assign P_23_24 = p0[24] & p0[23];
  assign G_24_25 = g0[25] | (p0[25] & g0[24]);
  assign P_24_25 = p0[25] & p0[24];
  assign G_25_26 = g0[26] | (p0[26] & g0[25]);
  assign P_25_26 = p0[26] & p0[25];
  assign G_26_27 = g0[27] | (p0[27] & g0[26]);
  assign P_26_27 = p0[27] & p0[26];
  assign G_27_28 = g0[28] | (p0[28] & g0[27]);
  assign P_27_28 = p0[28] & p0[27];
  assign G_28_29 = g0[29] | (p0[29] & g0[28]);
  assign P_28_29 = p0[29] & p0[28];
  assign G_29_30 = g0[30] | (p0[30] & g0[29]);
  assign P_29_30 = p0[30] & p0[29];
  assign G_30_31 = g0[31] | (p0[31] & g0[30]);
  assign P_30_31 = p0[31] & p0[30];
  assign G_32_33 = g0[33] | (p0[33] & g0[32]);
  assign P_32_33 = p0[33] & p0[32];
  assign G_33_34 = g0[34] | (p0[34] & g0[33]);
  assign P_33_34 = p0[34] & p0[33];
  assign G_34_35 = g0[35] | (p0[35] & g0[34]);
  assign P_34_35 = p0[35] & p0[34];
  assign G_35_36 = g0[36] | (p0[36] & g0[35]);
  assign P_35_36 = p0[36] & p0[35];
  assign G_36_37 = g0[37] | (p0[37] & g0[36]);
  assign P_36_37 = p0[37] & p0[36];
  assign G_37_38 = g0[38] | (p0[38] & g0[37]);
  assign P_37_38 = p0[38] & p0[37];
  assign G_38_39 = g0[39] | (p0[39] & g0[38]);
  assign P_38_39 = p0[39] & p0[38];
  assign G_39_40 = g0[40] | (p0[40] & g0[39]);
  assign P_39_40 = p0[40] & p0[39];
  assign G_40_41 = g0[41] | (p0[41] & g0[40]);
  assign P_40_41 = p0[41] & p0[40];
  assign G_42_43 = g0[43] | (p0[43] & g0[42]);
  assign P_42_43 = p0[43] & p0[42];
  assign G_43_44 = g0[44] | (p0[44] & g0[43]);
  assign P_43_44 = p0[44] & p0[43];
  assign G_44_45 = g0[45] | (p0[45] & g0[44]);
  assign P_44_45 = p0[45] & p0[44];
  assign G_45_46 = g0[46] | (p0[46] & g0[45]);
  assign P_45_46 = p0[46] & p0[45];
  assign G_46_47 = g0[47] | (p0[47] & g0[46]);
  assign P_46_47 = p0[47] & p0[46];
  assign G_47_48 = g0[48] | (p0[48] & g0[47]);
  assign P_47_48 = p0[48] & p0[47];
  assign G_48_49 = g0[49] | (p0[49] & g0[48]);
  assign P_48_49 = p0[49] & p0[48];
  assign G_49_50 = g0[50] | (p0[50] & g0[49]);
  assign P_49_50 = p0[50] & p0[49];
  assign G_51_52 = g0[52] | (p0[52] & g0[51]);
  assign P_51_52 = p0[52] & p0[51];
  assign G_52_53 = g0[53] | (p0[53] & g0[52]);
  assign P_52_53 = p0[53] & p0[52];
  assign G_53_54 = g0[54] | (p0[54] & g0[53]);
  assign P_53_54 = p0[54] & p0[53];
  assign G_54_55 = g0[55] | (p0[55] & g0[54]);
  assign P_54_55 = p0[55] & p0[54];
  assign G_55_56 = g0[56] | (p0[56] & g0[55]);
  assign P_55_56 = p0[56] & p0[55];
  assign G_56_57 = g0[57] | (p0[57] & g0[56]);
  assign P_56_57 = p0[57] & p0[56];
  assign G_57_58 = g0[58] | (p0[58] & g0[57]);
  assign P_57_58 = p0[58] & p0[57];
  assign G_58_59 = g0[59] | (p0[59] & g0[58]);
  assign P_58_59 = p0[59] & p0[58];
  assign G_60_61 = g0[61] | (p0[61] & g0[60]);
  assign P_60_61 = p0[61] & p0[60];
  assign G_61_62 = g0[62] | (p0[62] & g0[61]);
  assign P_61_62 = p0[62] & p0[61];
  assign G_62_63 = g0[63] | (p0[63] & g0[62]);
  assign P_62_63 = p0[63] & p0[62];
  assign G_63_64 = g0[64] | (p0[64] & g0[63]);
  assign P_63_64 = p0[64] & p0[63];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_1_4 = G_3_4 | (P_3_4 & G_1_2);
  assign P_1_4 = P_3_4 & P_1_2;
  assign G_3_5 = g0[5] | (p0[5] & G_3_4);
  assign P_3_5 = p0[5] & P_3_4;
  assign G_5_8 = G_7_8 | (P_7_8 & G_5_6);
  assign P_5_8 = P_7_8 & P_5_6;
  assign G_6_9 = G_8_9 | (P_8_9 & G_6_7);
  assign P_6_9 = P_8_9 & P_6_7;
  assign G_7_10 = G_9_10 | (P_9_10 & G_7_8);
  assign P_7_10 = P_9_10 & P_7_8;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_9_12 = G_11_12 | (P_11_12 & G_9_10);
  assign P_9_12 = P_11_12 & P_9_10;
  assign G_10_13 = G_12_13 | (P_12_13 & G_10_11);
  assign P_10_13 = P_12_13 & P_10_11;
  assign G_12_14 = g0[14] | (p0[14] & G_12_13);
  assign P_12_14 = p0[14] & P_12_13;
  assign G_14_17 = G_16_17 | (P_16_17 & G_14_15);
  assign P_14_17 = P_16_17 & P_14_15;
  assign G_15_18 = G_17_18 | (P_17_18 & G_15_16);
  assign P_15_18 = P_17_18 & P_15_16;
  assign G_16_19 = G_18_19 | (P_18_19 & G_16_17);
  assign P_16_19 = P_18_19 & P_16_17;
  assign G_17_20 = G_19_20 | (P_19_20 & G_17_18);
  assign P_17_20 = P_19_20 & P_17_18;
  assign G_18_21 = G_20_21 | (P_20_21 & G_18_19);
  assign P_18_21 = P_20_21 & P_18_19;
  assign G_19_22 = G_21_22 | (P_21_22 & G_19_20);
  assign P_19_22 = P_21_22 & P_19_20;
  assign G_21_23 = g0[23] | (p0[23] & G_21_22);
  assign P_21_23 = p0[23] & P_21_22;
  assign G_23_26 = G_25_26 | (P_25_26 & G_23_24);
  assign P_23_26 = P_25_26 & P_23_24;
  assign G_24_27 = G_26_27 | (P_26_27 & G_24_25);
  assign P_24_27 = P_26_27 & P_24_25;
  assign G_25_28 = G_27_28 | (P_27_28 & G_25_26);
  assign P_25_28 = P_27_28 & P_25_26;
  assign G_26_29 = G_28_29 | (P_28_29 & G_26_27);
  assign P_26_29 = P_28_29 & P_26_27;
  assign G_27_30 = G_29_30 | (P_29_30 & G_27_28);
  assign P_27_30 = P_29_30 & P_27_28;
  assign G_28_31 = G_30_31 | (P_30_31 & G_28_29);
  assign P_28_31 = P_30_31 & P_28_29;
  assign G_30_32 = g0[32] | (p0[32] & G_30_31);
  assign P_30_32 = p0[32] & P_30_31;
  assign G_32_35 = G_34_35 | (P_34_35 & G_32_33);
  assign P_32_35 = P_34_35 & P_32_33;
  assign G_33_36 = G_35_36 | (P_35_36 & G_33_34);
  assign P_33_36 = P_35_36 & P_33_34;
  assign G_34_37 = G_36_37 | (P_36_37 & G_34_35);
  assign P_34_37 = P_36_37 & P_34_35;
  assign G_35_38 = G_37_38 | (P_37_38 & G_35_36);
  assign P_35_38 = P_37_38 & P_35_36;
  assign G_36_39 = G_38_39 | (P_38_39 & G_36_37);
  assign P_36_39 = P_38_39 & P_36_37;
  assign G_37_40 = G_39_40 | (P_39_40 & G_37_38);
  assign P_37_40 = P_39_40 & P_37_38;
  assign G_38_41 = G_40_41 | (P_40_41 & G_38_39);
  assign P_38_41 = P_40_41 & P_38_39;
  assign G_40_42 = g0[42] | (p0[42] & G_40_41);
  assign P_40_42 = p0[42] & P_40_41;
  assign G_42_45 = G_44_45 | (P_44_45 & G_42_43);
  assign P_42_45 = P_44_45 & P_42_43;
  assign G_43_46 = G_45_46 | (P_45_46 & G_43_44);
  assign P_43_46 = P_45_46 & P_43_44;
  assign G_44_47 = G_46_47 | (P_46_47 & G_44_45);
  assign P_44_47 = P_46_47 & P_44_45;
  assign G_45_48 = G_47_48 | (P_47_48 & G_45_46);
  assign P_45_48 = P_47_48 & P_45_46;
  assign G_46_49 = G_48_49 | (P_48_49 & G_46_47);
  assign P_46_49 = P_48_49 & P_46_47;
  assign G_47_50 = G_49_50 | (P_49_50 & G_47_48);
  assign P_47_50 = P_49_50 & P_47_48;
  assign G_49_51 = g0[51] | (p0[51] & G_49_50);
  assign P_49_51 = p0[51] & P_49_50;
  assign G_51_54 = G_53_54 | (P_53_54 & G_51_52);
  assign P_51_54 = P_53_54 & P_51_52;
  assign G_52_55 = G_54_55 | (P_54_55 & G_52_53);
  assign P_52_55 = P_54_55 & P_52_53;
  assign G_53_56 = G_55_56 | (P_55_56 & G_53_54);
  assign P_53_56 = P_55_56 & P_53_54;
  assign G_54_57 = G_56_57 | (P_56_57 & G_54_55);
  assign P_54_57 = P_56_57 & P_54_55;
  assign G_55_58 = G_57_58 | (P_57_58 & G_55_56);
  assign P_55_58 = P_57_58 & P_55_56;
  assign G_56_59 = G_58_59 | (P_58_59 & G_56_57);
  assign P_56_59 = P_58_59 & P_56_57;
  assign G_58_60 = g0[60] | (p0[60] & G_58_59);
  assign P_58_60 = p0[60] & P_58_59;
  assign G_60_63 = G_62_63 | (P_62_63 & G_60_61);
  assign P_60_63 = P_62_63 & P_60_61;
  assign G_61_64 = G_63_64 | (P_63_64 & G_61_62);
  assign P_61_64 = P_63_64 & P_61_62;
  assign G_0_4 = G_1_4 | (P_1_4 & g0[0]);
  assign G_0_5 = G_3_5 | (P_3_5 & G_0_2);
  assign G_1_6 = G_5_6 | (P_5_6 & G_1_4);
  assign P_1_6 = P_5_6 & P_1_4;
  assign G_3_7 = G_6_7 | (P_6_7 & G_3_5);
  assign P_3_7 = P_6_7 & P_3_5;
  assign G_5_12 = G_9_12 | (P_9_12 & G_5_8);
  assign P_5_12 = P_9_12 & P_5_8;
  assign G_6_13 = G_10_13 | (P_10_13 & G_6_9);
  assign P_6_13 = P_10_13 & P_6_9;
  assign G_8_14 = G_12_14 | (P_12_14 & G_8_11);
  assign P_8_14 = P_12_14 & P_8_11;
  assign G_10_15 = G_14_15 | (P_14_15 & G_10_13);
  assign P_10_15 = P_14_15 & P_10_13;
  assign G_12_16 = G_15_16 | (P_15_16 & G_12_14);
  assign P_12_16 = P_15_16 & P_12_14;
  assign G_14_21 = G_18_21 | (P_18_21 & G_14_17);
  assign P_14_21 = P_18_21 & P_14_17;
  assign G_15_22 = G_19_22 | (P_19_22 & G_15_18);
  assign P_15_22 = P_19_22 & P_15_18;
  assign G_17_23 = G_21_23 | (P_21_23 & G_17_20);
  assign P_17_23 = P_21_23 & P_17_20;
  assign G_19_24 = G_23_24 | (P_23_24 & G_19_22);
  assign P_19_24 = P_23_24 & P_19_22;
  assign G_21_25 = G_24_25 | (P_24_25 & G_21_23);
  assign P_21_25 = P_24_25 & P_21_23;
  assign G_23_30 = G_27_30 | (P_27_30 & G_23_26);
  assign P_23_30 = P_27_30 & P_23_26;
  assign G_24_31 = G_28_31 | (P_28_31 & G_24_27);
  assign P_24_31 = P_28_31 & P_24_27;
  assign G_26_32 = G_30_32 | (P_30_32 & G_26_29);
  assign P_26_32 = P_30_32 & P_26_29;
  assign G_28_33 = G_32_33 | (P_32_33 & G_28_31);
  assign P_28_33 = P_32_33 & P_28_31;
  assign G_30_34 = G_33_34 | (P_33_34 & G_30_32);
  assign P_30_34 = P_33_34 & P_30_32;
  assign G_32_39 = G_36_39 | (P_36_39 & G_32_35);
  assign P_32_39 = P_36_39 & P_32_35;
  assign G_33_40 = G_37_40 | (P_37_40 & G_33_36);
  assign P_33_40 = P_37_40 & P_33_36;
  assign G_34_41 = G_38_41 | (P_38_41 & G_34_37);
  assign P_34_41 = P_38_41 & P_34_37;
  assign G_36_42 = G_40_42 | (P_40_42 & G_36_39);
  assign P_36_42 = P_40_42 & P_36_39;
  assign G_38_43 = G_42_43 | (P_42_43 & G_38_41);
  assign P_38_43 = P_42_43 & P_38_41;
  assign G_40_44 = G_43_44 | (P_43_44 & G_40_42);
  assign P_40_44 = P_43_44 & P_40_42;
  assign G_42_49 = G_46_49 | (P_46_49 & G_42_45);
  assign P_42_49 = P_46_49 & P_42_45;
  assign G_43_50 = G_47_50 | (P_47_50 & G_43_46);
  assign P_43_50 = P_47_50 & P_43_46;
  assign G_45_51 = G_49_51 | (P_49_51 & G_45_48);
  assign P_45_51 = P_49_51 & P_45_48;
  assign G_47_52 = G_51_52 | (P_51_52 & G_47_50);
  assign P_47_52 = P_51_52 & P_47_50;
  assign G_49_53 = G_52_53 | (P_52_53 & G_49_51);
  assign P_49_53 = P_52_53 & P_49_51;
  assign G_51_58 = G_55_58 | (P_55_58 & G_51_54);
  assign P_51_58 = P_55_58 & P_51_54;
  assign G_52_59 = G_56_59 | (P_56_59 & G_52_55);
  assign P_52_59 = P_56_59 & P_52_55;
  assign G_54_60 = G_58_60 | (P_58_60 & G_54_57);
  assign P_54_60 = P_58_60 & P_54_57;
  assign G_56_61 = G_60_61 | (P_60_61 & G_56_59);
  assign P_56_61 = P_60_61 & P_56_59;
  assign G_58_62 = G_61_62 | (P_61_62 & G_58_60);
  assign P_58_62 = P_61_62 & P_58_60;
  assign G_0_6 = G_1_6 | (P_1_6 & g0[0]);
  assign G_0_7 = G_3_7 | (P_3_7 & G_0_2);
  assign G_0_8 = G_5_8 | (P_5_8 & G_0_4);
  assign G_0_9 = G_6_9 | (P_6_9 & G_0_5);
  assign G_1_10 = G_7_10 | (P_7_10 & G_1_6);
  assign P_1_10 = P_7_10 & P_1_6;
  assign G_3_11 = G_8_11 | (P_8_11 & G_3_7);
  assign P_3_11 = P_8_11 & P_3_7;
  assign G_0_12 = G_5_12 | (P_5_12 & G_0_4);
  assign G_0_13 = G_6_13 | (P_6_13 & G_0_5);
  assign G_6_17 = G_14_17 | (P_14_17 & G_6_13);
  assign P_6_17 = P_14_17 & P_6_13;
  assign G_8_18 = G_15_18 | (P_15_18 & G_8_14);
  assign P_8_18 = P_15_18 & P_8_14;
  assign G_10_19 = G_16_19 | (P_16_19 & G_10_15);
  assign P_10_19 = P_16_19 & P_10_15;
  assign G_12_20 = G_17_20 | (P_17_20 & G_12_16);
  assign P_12_20 = P_17_20 & P_12_16;
  assign G_15_26 = G_23_26 | (P_23_26 & G_15_22);
  assign P_15_26 = P_23_26 & P_15_22;
  assign G_17_27 = G_24_27 | (P_24_27 & G_17_23);
  assign P_17_27 = P_24_27 & P_17_23;
  assign G_19_28 = G_25_28 | (P_25_28 & G_19_24);
  assign P_19_28 = P_25_28 & P_19_24;
  assign G_21_29 = G_26_29 | (P_26_29 & G_21_25);
  assign P_21_29 = P_26_29 & P_21_25;
  assign G_24_35 = G_32_35 | (P_32_35 & G_24_31);
  assign P_24_35 = P_32_35 & P_24_31;
  assign G_26_36 = G_33_36 | (P_33_36 & G_26_32);
  assign P_26_36 = P_33_36 & P_26_32;
  assign G_28_37 = G_34_37 | (P_34_37 & G_28_33);
  assign P_28_37 = P_34_37 & P_28_33;
  assign G_30_38 = G_35_38 | (P_35_38 & G_30_34);
  assign P_30_38 = P_35_38 & P_30_34;
  assign G_32_44 = G_40_44 | (P_40_44 & G_32_39);
  assign P_32_44 = P_40_44 & P_32_39;
  assign G_34_45 = G_42_45 | (P_42_45 & G_34_41);
  assign P_34_45 = P_42_45 & P_34_41;
  assign G_36_46 = G_43_46 | (P_43_46 & G_36_42);
  assign P_36_46 = P_43_46 & P_36_42;
  assign G_38_47 = G_44_47 | (P_44_47 & G_38_43);
  assign P_38_47 = P_44_47 & P_38_43;
  assign G_40_48 = G_45_48 | (P_45_48 & G_40_44);
  assign P_40_48 = P_45_48 & P_40_44;
  assign G_43_54 = G_51_54 | (P_51_54 & G_43_50);
  assign P_43_54 = P_51_54 & P_43_50;
  assign G_45_55 = G_52_55 | (P_52_55 & G_45_51);
  assign P_45_55 = P_52_55 & P_45_51;
  assign G_47_56 = G_53_56 | (P_53_56 & G_47_52);
  assign P_47_56 = P_53_56 & P_47_52;
  assign G_49_57 = G_54_57 | (P_54_57 & G_49_53);
  assign P_49_57 = P_54_57 & P_49_53;
  assign G_52_63 = G_60_63 | (P_60_63 & G_52_59);
  assign P_52_63 = P_60_63 & P_52_59;
  assign G_54_64 = G_61_64 | (P_61_64 & G_54_60);
  assign P_54_64 = P_61_64 & P_54_60;
  assign G_0_10 = G_1_10 | (P_1_10 & g0[0]);
  assign G_0_11 = G_3_11 | (P_3_11 & G_0_2);
  assign G_0_14 = G_8_14 | (P_8_14 & G_0_7);
  assign G_0_15 = G_10_15 | (P_10_15 & G_0_9);
  assign G_3_16 = G_12_16 | (P_12_16 & G_3_11);
  assign P_3_16 = P_12_16 & P_3_11;
  assign G_0_17 = G_6_17 | (P_6_17 & G_0_5);
  assign G_0_18 = G_8_18 | (P_8_18 & G_0_7);
  assign G_0_19 = G_10_19 | (P_10_19 & G_0_9);
  assign G_0_21 = G_14_21 | (P_14_21 & G_0_13);
  assign G_8_24 = G_19_24 | (P_19_24 & G_8_18);
  assign P_8_24 = P_19_24 & P_8_18;
  assign G_12_25 = G_21_25 | (P_21_25 & G_12_20);
  assign P_12_25 = P_21_25 & P_12_20;
  assign G_17_33 = G_28_33 | (P_28_33 & G_17_27);
  assign P_17_33 = P_28_33 & P_17_27;
  assign G_21_34 = G_30_34 | (P_30_34 & G_21_29);
  assign P_21_34 = P_30_34 & P_21_29;
  assign G_24_42 = G_36_42 | (P_36_42 & G_24_35);
  assign P_24_42 = P_36_42 & P_24_35;
  assign G_28_43 = G_38_43 | (P_38_43 & G_28_37);
  assign P_28_43 = P_38_43 & P_28_37;
  assign G_32_51 = G_45_51 | (P_45_51 & G_32_44);
  assign P_32_51 = P_45_51 & P_32_44;
  assign G_36_52 = G_47_52 | (P_47_52 & G_36_46);
  assign P_36_52 = P_47_52 & P_36_46;
  assign G_40_53 = G_49_53 | (P_49_53 & G_40_48);
  assign P_40_53 = P_49_53 & P_40_48;
  assign G_45_61 = G_56_61 | (P_56_61 & G_45_55);
  assign P_45_61 = P_56_61 & P_45_55;
  assign G_49_62 = G_58_62 | (P_58_62 & G_49_57);
  assign P_49_62 = P_58_62 & P_49_57;
  assign G_0_16 = G_3_16 | (P_3_16 & G_0_2);
  assign G_0_20 = G_12_20 | (P_12_20 & G_0_11);
  assign G_0_22 = G_15_22 | (P_15_22 & G_0_14);
  assign G_3_23 = G_17_23 | (P_17_23 & G_3_16);
  assign P_3_23 = P_17_23 & P_3_16;
  assign G_0_24 = G_8_24 | (P_8_24 & G_0_7);
  assign G_0_25 = G_12_25 | (P_12_25 & G_0_11);
  assign G_0_26 = G_15_26 | (P_15_26 & G_0_14);
  assign G_0_28 = G_19_28 | (P_19_28 & G_0_18);
  assign G_12_32 = G_26_32 | (P_26_32 & G_12_25);
  assign P_12_32 = P_26_32 & P_12_25;
  assign G_17_41 = G_34_41 | (P_34_41 & G_17_33);
  assign P_17_41 = P_34_41 & P_17_33;
  assign G_24_50 = G_43_50 | (P_43_50 & G_24_42);
  assign P_24_50 = P_43_50 & P_24_42;
  assign G_32_59 = G_52_59 | (P_52_59 & G_32_51);
  assign P_32_59 = P_52_59 & P_32_51;
  assign G_40_60 = G_54_60 | (P_54_60 & G_40_53);
  assign P_40_60 = P_54_60 & P_40_53;
  assign G_0_23 = G_3_23 | (P_3_23 & G_0_2);
  assign G_0_27 = G_17_27 | (P_17_27 & G_0_16);
  assign G_0_29 = G_21_29 | (P_21_29 & G_0_20);
  assign G_0_30 = G_23_30 | (P_23_30 & G_0_22);
  assign G_3_31 = G_24_31 | (P_24_31 & G_3_23);
  assign P_3_31 = P_24_31 & P_3_23;
  assign G_0_32 = G_12_32 | (P_12_32 & G_0_11);
  assign G_0_33 = G_17_33 | (P_17_33 & G_0_16);
  assign G_0_34 = G_21_34 | (P_21_34 & G_0_20);
  assign G_0_36 = G_26_36 | (P_26_36 & G_0_25);
  assign G_12_40 = G_33_40 | (P_33_40 & G_12_32);
  assign P_12_40 = P_33_40 & P_12_32;
  assign G_0_41 = G_17_41 | (P_17_41 & G_0_16);
  assign G_17_49 = G_42_49 | (P_42_49 & G_17_41);
  assign P_17_49 = P_42_49 & P_17_41;
  assign G_24_58 = G_51_58 | (P_51_58 & G_24_50);
  assign P_24_58 = P_51_58 & P_24_50;
  assign G_0_31 = G_3_31 | (P_3_31 & G_0_2);
  assign G_0_35 = G_24_35 | (P_24_35 & G_0_23);
  assign G_0_37 = G_28_37 | (P_28_37 & G_0_27);
  assign G_0_38 = G_30_38 | (P_30_38 & G_0_29);
  assign G_3_39 = G_32_39 | (P_32_39 & G_3_31);
  assign P_3_39 = P_32_39 & P_3_31;
  assign G_0_40 = G_12_40 | (P_12_40 & G_0_11);
  assign G_0_42 = G_24_42 | (P_24_42 & G_0_23);
  assign G_0_43 = G_28_43 | (P_28_43 & G_0_27);
  assign G_0_45 = G_34_45 | (P_34_45 & G_0_33);
  assign G_0_49 = G_17_49 | (P_17_49 & G_0_16);
  assign G_0_50 = G_24_50 | (P_24_50 & G_0_23);
  assign G_0_58 = G_24_58 | (P_24_58 & G_0_23);
  assign G_0_39 = G_3_39 | (P_3_39 & G_0_2);
  assign G_0_44 = G_32_44 | (P_32_44 & G_0_31);
  assign G_0_46 = G_36_46 | (P_36_46 & G_0_35);
  assign G_0_47 = G_38_47 | (P_38_47 & G_0_37);
  assign G_3_48 = G_40_48 | (P_40_48 & G_3_39);
  assign P_3_48 = P_40_48 & P_3_39;
  assign G_0_51 = G_32_51 | (P_32_51 & G_0_31);
  assign G_0_52 = G_36_52 | (P_36_52 & G_0_35);
  assign G_0_54 = G_43_54 | (P_43_54 & G_0_42);
  assign G_0_59 = G_32_59 | (P_32_59 & G_0_31);
  assign G_0_48 = G_3_48 | (P_3_48 & G_0_2);
  assign G_0_53 = G_40_53 | (P_40_53 & G_0_39);
  assign G_0_55 = G_45_55 | (P_45_55 & G_0_44);
  assign G_0_56 = G_47_56 | (P_47_56 & G_0_46);
  assign G_3_57 = G_49_57 | (P_49_57 & G_3_48);
  assign P_3_57 = P_49_57 & P_3_48;
  assign G_0_60 = G_40_60 | (P_40_60 & G_0_39);
  assign G_0_61 = G_45_61 | (P_45_61 & G_0_44);
  assign G_0_63 = G_52_63 | (P_52_63 & G_0_51);
  assign G_0_57 = G_3_57 | (P_3_57 & G_0_2);
  assign G_0_62 = G_49_62 | (P_49_62 & G_0_48);
  assign G_0_64 = G_54_64 | (P_54_64 & G_0_53);
  logic [65:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign c[15] = G_0_14;
  assign c[16] = G_0_15;
  assign c[17] = G_0_16;
  assign c[18] = G_0_17;
  assign c[19] = G_0_18;
  assign c[20] = G_0_19;
  assign c[21] = G_0_20;
  assign c[22] = G_0_21;
  assign c[23] = G_0_22;
  assign c[24] = G_0_23;
  assign c[25] = G_0_24;
  assign c[26] = G_0_25;
  assign c[27] = G_0_26;
  assign c[28] = G_0_27;
  assign c[29] = G_0_28;
  assign c[30] = G_0_29;
  assign c[31] = G_0_30;
  assign c[32] = G_0_31;
  assign c[33] = G_0_32;
  assign c[34] = G_0_33;
  assign c[35] = G_0_34;
  assign c[36] = G_0_35;
  assign c[37] = G_0_36;
  assign c[38] = G_0_37;
  assign c[39] = G_0_38;
  assign c[40] = G_0_39;
  assign c[41] = G_0_40;
  assign c[42] = G_0_41;
  assign c[43] = G_0_42;
  assign c[44] = G_0_43;
  assign c[45] = G_0_44;
  assign c[46] = G_0_45;
  assign c[47] = G_0_46;
  assign c[48] = G_0_47;
  assign c[49] = G_0_48;
  assign c[50] = G_0_49;
  assign c[51] = G_0_50;
  assign c[52] = G_0_51;
  assign c[53] = G_0_52;
  assign c[54] = G_0_53;
  assign c[55] = G_0_54;
  assign c[56] = G_0_55;
  assign c[57] = G_0_56;
  assign c[58] = G_0_57;
  assign c[59] = G_0_58;
  assign c[60] = G_0_59;
  assign c[61] = G_0_60;
  assign c[62] = G_0_61;
  assign c[63] = G_0_62;
  assign c[64] = G_0_63;
  assign c[65] = G_0_64;
  assign s = pi_ ^ c[64:0];
  assign cout = c[65];
endmodule





// lzd_cell_tree (pair_cell, binary_count, valid flags propagated): the leading zeros of a 8-bit word

module fam_prefix_arrival_0_0_0_1_1_1_1_1_1_2_2_2_2_2_2_3_3_3_3_3_4_4_4_4_4_4_5_5_5_5_5_5_6_6_6_w35 (input logic [34:0] a, input logic [34:0] b, input logic cin,
  output logic [34:0] s, output logic cout);
  // prefix graph: {'n': 35, 'levels': 8, 'size': 109, 'fanout': 5, 'tracks': 4, 'exact_split': True, 'valency': 2}
  logic [34:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [34:0] g0, p0;
  assign g0 = {gi[34:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_1_2, P_1_2, G_3_4, P_3_4, G_4_5, P_4_5, G_5_6, P_5_6, G_6_7, P_6_7, G_7_8, P_7_8, G_9_10, P_9_10, G_10_11, P_10_11, G_11_12, P_11_12, G_12_13, P_12_13, G_13_14, P_13_14, G_15_16, P_15_16, G_16_17, P_16_17, G_17_18, P_17_18, G_18_19, P_18_19, G_20_21, P_20_21, G_21_22, P_21_22, G_22_23, P_22_23, G_23_24, P_23_24, G_24_25, P_24_25, G_26_27, P_26_27, G_27_28, P_27_28, G_28_29, P_28_29, G_29_30, P_29_30, G_30_31, P_30_31, G_32_33, P_32_33, G_33_34, P_33_34, G_0_2, G_1_3, P_1_3, G_3_6, P_3_6, G_4_7, P_4_7, G_5_8, P_5_8, G_7_9, P_7_9, G_9_12, P_9_12, G_10_13, P_10_13, G_11_14, P_11_14, G_13_15, P_13_15, G_15_18, P_15_18, G_16_19, P_16_19, G_18_20, P_18_20, G_20_23, P_20_23, G_21_24, P_21_24, G_22_25, P_22_25, G_24_26, P_24_26, G_26_29, P_26_29, G_27_30, P_27_30, G_28_31, P_28_31, G_30_32, P_30_32, G_0_3, G_0_4, G_1_5, P_1_5, G_0_6, G_3_9, P_3_9, G_5_10, P_5_10, G_7_11, P_7_11, G_9_15, P_9_15, G_11_16, P_11_16, G_13_17, P_13_17, G_16_21, P_16_21, G_18_22, P_18_22, G_20_26, P_20_26, G_22_27, P_22_27, G_24_28, P_24_28, G_26_32, P_26_32, G_28_33, P_28_33, G_30_34, P_30_34, G_0_5, G_0_7, G_0_8, G_0_9, G_0_10, G_0_11, G_3_13, P_3_13, G_5_14, P_5_14, G_9_19, P_9_19, G_13_20, P_13_20, G_16_25, P_16_25, G_20_30, P_20_30, G_22_31, P_22_31, G_0_12, G_0_13, G_0_14, G_0_15, G_0_16, G_5_18, P_5_18, G_0_19, G_9_23, P_9_23, G_13_24, P_13_24, G_16_29, P_16_29, G_0_17, G_0_18, G_0_20, G_0_21, G_0_23, G_0_24, G_0_25, G_0_26, G_9_28, P_9_28, G_0_29, G_0_30, G_16_34, P_16_34, G_0_22, G_0_27, G_0_28, G_0_31, G_0_32, G_0_34, G_0_33;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_5_6 = g0[6] | (p0[6] & g0[5]);
  assign P_5_6 = p0[6] & p0[5];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_7_8 = g0[8] | (p0[8] & g0[7]);
  assign P_7_8 = p0[8] & p0[7];
  assign G_9_10 = g0[10] | (p0[10] & g0[9]);
  assign P_9_10 = p0[10] & p0[9];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_11_12 = g0[12] | (p0[12] & g0[11]);
  assign P_11_12 = p0[12] & p0[11];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_13_14 = g0[14] | (p0[14] & g0[13]);
  assign P_13_14 = p0[14] & p0[13];
  assign G_15_16 = g0[16] | (p0[16] & g0[15]);
  assign P_15_16 = p0[16] & p0[15];
  assign G_16_17 = g0[17] | (p0[17] & g0[16]);
  assign P_16_17 = p0[17] & p0[16];
  assign G_17_18 = g0[18] | (p0[18] & g0[17]);
  assign P_17_18 = p0[18] & p0[17];
  assign G_18_19 = g0[19] | (p0[19] & g0[18]);
  assign P_18_19 = p0[19] & p0[18];
  assign G_20_21 = g0[21] | (p0[21] & g0[20]);
  assign P_20_21 = p0[21] & p0[20];
  assign G_21_22 = g0[22] | (p0[22] & g0[21]);
  assign P_21_22 = p0[22] & p0[21];
  assign G_22_23 = g0[23] | (p0[23] & g0[22]);
  assign P_22_23 = p0[23] & p0[22];
  assign G_23_24 = g0[24] | (p0[24] & g0[23]);
  assign P_23_24 = p0[24] & p0[23];
  assign G_24_25 = g0[25] | (p0[25] & g0[24]);
  assign P_24_25 = p0[25] & p0[24];
  assign G_26_27 = g0[27] | (p0[27] & g0[26]);
  assign P_26_27 = p0[27] & p0[26];
  assign G_27_28 = g0[28] | (p0[28] & g0[27]);
  assign P_27_28 = p0[28] & p0[27];
  assign G_28_29 = g0[29] | (p0[29] & g0[28]);
  assign P_28_29 = p0[29] & p0[28];
  assign G_29_30 = g0[30] | (p0[30] & g0[29]);
  assign P_29_30 = p0[30] & p0[29];
  assign G_30_31 = g0[31] | (p0[31] & g0[30]);
  assign P_30_31 = p0[31] & p0[30];
  assign G_32_33 = g0[33] | (p0[33] & g0[32]);
  assign P_32_33 = p0[33] & p0[32];
  assign G_33_34 = g0[34] | (p0[34] & g0[33]);
  assign P_33_34 = p0[34] & p0[33];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_1_3 = g0[3] | (p0[3] & G_1_2);
  assign P_1_3 = p0[3] & P_1_2;
  assign G_3_6 = G_5_6 | (P_5_6 & G_3_4);
  assign P_3_6 = P_5_6 & P_3_4;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_5_8 = G_7_8 | (P_7_8 & G_5_6);
  assign P_5_8 = P_7_8 & P_5_6;
  assign G_7_9 = g0[9] | (p0[9] & G_7_8);
  assign P_7_9 = p0[9] & P_7_8;
  assign G_9_12 = G_11_12 | (P_11_12 & G_9_10);
  assign P_9_12 = P_11_12 & P_9_10;
  assign G_10_13 = G_12_13 | (P_12_13 & G_10_11);
  assign P_10_13 = P_12_13 & P_10_11;
  assign G_11_14 = G_13_14 | (P_13_14 & G_11_12);
  assign P_11_14 = P_13_14 & P_11_12;
  assign G_13_15 = g0[15] | (p0[15] & G_13_14);
  assign P_13_15 = p0[15] & P_13_14;
  assign G_15_18 = G_17_18 | (P_17_18 & G_15_16);
  assign P_15_18 = P_17_18 & P_15_16;
  assign G_16_19 = G_18_19 | (P_18_19 & G_16_17);
  assign P_16_19 = P_18_19 & P_16_17;
  assign G_18_20 = g0[20] | (p0[20] & G_18_19);
  assign P_18_20 = p0[20] & P_18_19;
  assign G_20_23 = G_22_23 | (P_22_23 & G_20_21);
  assign P_20_23 = P_22_23 & P_20_21;
  assign G_21_24 = G_23_24 | (P_23_24 & G_21_22);
  assign P_21_24 = P_23_24 & P_21_22;
  assign G_22_25 = G_24_25 | (P_24_25 & G_22_23);
  assign P_22_25 = P_24_25 & P_22_23;
  assign G_24_26 = g0[26] | (p0[26] & G_24_25);
  assign P_24_26 = p0[26] & P_24_25;
  assign G_26_29 = G_28_29 | (P_28_29 & G_26_27);
  assign P_26_29 = P_28_29 & P_26_27;
  assign G_27_30 = G_29_30 | (P_29_30 & G_27_28);
  assign P_27_30 = P_29_30 & P_27_28;
  assign G_28_31 = G_30_31 | (P_30_31 & G_28_29);
  assign P_28_31 = P_30_31 & P_28_29;
  assign G_30_32 = g0[32] | (p0[32] & G_30_31);
  assign P_30_32 = p0[32] & P_30_31;
  assign G_0_3 = G_1_3 | (P_1_3 & g0[0]);
  assign G_0_4 = G_3_4 | (P_3_4 & G_0_2);
  assign G_1_5 = G_4_5 | (P_4_5 & G_1_3);
  assign P_1_5 = P_4_5 & P_1_3;
  assign G_0_6 = G_3_6 | (P_3_6 & G_0_2);
  assign G_3_9 = G_7_9 | (P_7_9 & G_3_6);
  assign P_3_9 = P_7_9 & P_3_6;
  assign G_5_10 = G_9_10 | (P_9_10 & G_5_8);
  assign P_5_10 = P_9_10 & P_5_8;
  assign G_7_11 = G_10_11 | (P_10_11 & G_7_9);
  assign P_7_11 = P_10_11 & P_7_9;
  assign G_9_15 = G_13_15 | (P_13_15 & G_9_12);
  assign P_9_15 = P_13_15 & P_9_12;
  assign G_11_16 = G_15_16 | (P_15_16 & G_11_14);
  assign P_11_16 = P_15_16 & P_11_14;
  assign G_13_17 = G_16_17 | (P_16_17 & G_13_15);
  assign P_13_17 = P_16_17 & P_13_15;
  assign G_16_21 = G_20_21 | (P_20_21 & G_16_19);
  assign P_16_21 = P_20_21 & P_16_19;
  assign G_18_22 = G_21_22 | (P_21_22 & G_18_20);
  assign P_18_22 = P_21_22 & P_18_20;
  assign G_20_26 = G_24_26 | (P_24_26 & G_20_23);
  assign P_20_26 = P_24_26 & P_20_23;
  assign G_22_27 = G_26_27 | (P_26_27 & G_22_25);
  assign P_22_27 = P_26_27 & P_22_25;
  assign G_24_28 = G_27_28 | (P_27_28 & G_24_26);
  assign P_24_28 = P_27_28 & P_24_26;
  assign G_26_32 = G_30_32 | (P_30_32 & G_26_29);
  assign P_26_32 = P_30_32 & P_26_29;
  assign G_28_33 = G_32_33 | (P_32_33 & G_28_31);
  assign P_28_33 = P_32_33 & P_28_31;
  assign G_30_34 = G_33_34 | (P_33_34 & G_30_32);
  assign P_30_34 = P_33_34 & P_30_32;
  assign G_0_5 = G_1_5 | (P_1_5 & g0[0]);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_0_8 = G_5_8 | (P_5_8 & G_0_4);
  assign G_0_9 = G_3_9 | (P_3_9 & G_0_2);
  assign G_0_10 = G_5_10 | (P_5_10 & G_0_4);
  assign G_0_11 = G_7_11 | (P_7_11 & G_0_6);
  assign G_3_13 = G_10_13 | (P_10_13 & G_3_9);
  assign P_3_13 = P_10_13 & P_3_9;
  assign G_5_14 = G_11_14 | (P_11_14 & G_5_10);
  assign P_5_14 = P_11_14 & P_5_10;
  assign G_9_19 = G_16_19 | (P_16_19 & G_9_15);
  assign P_9_19 = P_16_19 & P_9_15;
  assign G_13_20 = G_18_20 | (P_18_20 & G_13_17);
  assign P_13_20 = P_18_20 & P_13_17;
  assign G_16_25 = G_22_25 | (P_22_25 & G_16_21);
  assign P_16_25 = P_22_25 & P_16_21;
  assign G_20_30 = G_27_30 | (P_27_30 & G_20_26);
  assign P_20_30 = P_27_30 & P_20_26;
  assign G_22_31 = G_28_31 | (P_28_31 & G_22_27);
  assign P_22_31 = P_28_31 & P_22_27;
  assign G_0_12 = G_9_12 | (P_9_12 & G_0_8);
  assign G_0_13 = G_3_13 | (P_3_13 & G_0_2);
  assign G_0_14 = G_5_14 | (P_5_14 & G_0_4);
  assign G_0_15 = G_9_15 | (P_9_15 & G_0_8);
  assign G_0_16 = G_11_16 | (P_11_16 & G_0_10);
  assign G_5_18 = G_15_18 | (P_15_18 & G_5_14);
  assign P_5_18 = P_15_18 & P_5_14;
  assign G_0_19 = G_9_19 | (P_9_19 & G_0_8);
  assign G_9_23 = G_20_23 | (P_20_23 & G_9_19);
  assign P_9_23 = P_20_23 & P_9_19;
  assign G_13_24 = G_21_24 | (P_21_24 & G_13_20);
  assign P_13_24 = P_21_24 & P_13_20;
  assign G_16_29 = G_26_29 | (P_26_29 & G_16_25);
  assign P_16_29 = P_26_29 & P_16_25;
  assign G_0_17 = G_13_17 | (P_13_17 & G_0_12);
  assign G_0_18 = G_5_18 | (P_5_18 & G_0_4);
  assign G_0_20 = G_13_20 | (P_13_20 & G_0_12);
  assign G_0_21 = G_16_21 | (P_16_21 & G_0_15);
  assign G_0_23 = G_9_23 | (P_9_23 & G_0_8);
  assign G_0_24 = G_13_24 | (P_13_24 & G_0_12);
  assign G_0_25 = G_16_25 | (P_16_25 & G_0_15);
  assign G_0_26 = G_20_26 | (P_20_26 & G_0_19);
  assign G_9_28 = G_24_28 | (P_24_28 & G_9_23);
  assign P_9_28 = P_24_28 & P_9_23;
  assign G_0_29 = G_16_29 | (P_16_29 & G_0_15);
  assign G_0_30 = G_20_30 | (P_20_30 & G_0_19);
  assign G_16_34 = G_30_34 | (P_30_34 & G_16_29);
  assign P_16_34 = P_30_34 & P_16_29;
  assign G_0_22 = G_18_22 | (P_18_22 & G_0_17);
  assign G_0_27 = G_22_27 | (P_22_27 & G_0_21);
  assign G_0_28 = G_9_28 | (P_9_28 & G_0_8);
  assign G_0_31 = G_22_31 | (P_22_31 & G_0_21);
  assign G_0_32 = G_26_32 | (P_26_32 & G_0_25);
  assign G_0_34 = G_16_34 | (P_16_34 & G_0_15);
  assign G_0_33 = G_28_33 | (P_28_33 & G_0_27);
  logic [35:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign c[15] = G_0_14;
  assign c[16] = G_0_15;
  assign c[17] = G_0_16;
  assign c[18] = G_0_17;
  assign c[19] = G_0_18;
  assign c[20] = G_0_19;
  assign c[21] = G_0_20;
  assign c[22] = G_0_21;
  assign c[23] = G_0_22;
  assign c[24] = G_0_23;
  assign c[25] = G_0_24;
  assign c[26] = G_0_25;
  assign c[27] = G_0_26;
  assign c[28] = G_0_27;
  assign c[29] = G_0_28;
  assign c[30] = G_0_29;
  assign c[31] = G_0_30;
  assign c[32] = G_0_31;
  assign c[33] = G_0_32;
  assign c[34] = G_0_33;
  assign c[35] = G_0_34;
  assign s = pi_ ^ c[34:0];
  assign cout = c[35];
endmodule






































































































































































































































module fam_prefix_brent_kung_w1_flagm_dual (input logic [0:0] a, input logic [0:0] b, input logic cin,
  output logic [0:0] s, output logic cout, output logic [0:0] s1, output logic [0:0] sm1);
  // prefix graph: {'n': 1, 'levels': 0, 'size': 0, 'fanout': 0, 'tracks': 0, 'exact_split': True, 'valency': 1}
  logic [0:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [0:0] g0, p0;
  assign g0 = gi | (pi_ & cin);
  assign p0 = pi_;
  logic [1:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign s = pi_ ^ c[0:0];
  assign cout = c[1];
  logic [0:0] g1, p1;
  assign g1 = gi | pi_;
  assign p1 = pi_;
  logic [1:0] c1;
  assign c1[0] = 1'b1;
  assign c1[1] = g1[0];
  assign s1 = pi_ ^ c1[0:0];
  logic [0:0] fm;
  assign fm[0] = 1'b1;
  assign sm1 = s ^ fm;
endmodule


module fam_prefix_brent_kung_w2_flagm_dual (input logic [1:0] a, input logic [1:0] b, input logic cin,
  output logic [1:0] s, output logic cout, output logic [1:0] s1, output logic [1:0] sm1);
  // prefix graph: {'n': 2, 'levels': 1, 'size': 1, 'fanout': 1, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [1:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [1:0] g0, p0;
  assign g0 = {gi[1:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, P_0_1;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign P_0_1 = p0[1] & p0[0];
  logic [2:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign s = pi_ ^ c[1:0];
  assign cout = c[2];
  logic [1:0] g1, p1;
  assign g1 = {gi[1:1], gi[0] | pi_[0]};
  assign p1 = pi_;
  logic H_0_1;
  assign H_0_1 = g1[1] | (p1[1] & g1[0]);
  logic [2:0] c1;
  assign c1[0] = 1'b1;
  assign c1[1] = g1[0];
  assign c1[2] = H_0_1;
  assign s1 = pi_ ^ c1[1:0];
  logic [1:0] fm;
  assign fm[0] = 1'b1;
  assign fm[1] = fm[0] & ~s[0];
  assign sm1 = s ^ fm;
endmodule




// The carry-propagate adder families of chiALU as parametric SystemVerilog.
// Every module has the one interface
//   #(parameter int W) (input [W-1:0] a, b, input cin, output [W-1:0] s, output cout)
// and computes s = a + b + cin exactly (cout the carry out of bit W-1), so the
// lane module of a seed can put any of them behind its add/sub/neg/abs/saturate
// ops. The family names are chialu/spaces/adder_spaces.py's; the parameters
// are the pins of a family's design choices the registry (families/__init__.py)
// maps. The blocked families (carry_skip, carry_select, carry_increment,
// sparse_prefix_hybrid), the end-around-carry, the truncated and the
// FPGA-chain families are generated by families/adder_ext.py around the
// library modules their slots name; the prefix families by families/prefix.py.

// ---------------------------------------------------------------- ripple_carry
// one full adder per bit, the carry rippling; CHUNK > 1 breaks the chain into
// chunks with an explicit carry wire between them (the chunk_width_bits choice).
// FORM is the full adder's logic: 0 generate_propagate (s = p ^ c, c' = g | p c),
// 1 two_half_adders_or (two half adders, the carries ORed), 2 xor_majority
// (s = a ^ b ^ c, c' = majority), 3 half_sum_mux_carry (c' = p ? c : a).









module fam_prefix_han_carlson_w13_ling3_sel (input logic [12:0] a, input logic [12:0] b, input logic cin,
  output logic [12:0] s, output logic cout);
  // prefix graph: {'n': 5, 'levels': 3, 'size': 5, 'fanout': 2, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [12:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [12:0] gc;
  assign gc = {gi[12:1], gi[0] | (pi_[0] & cin)};
  logic [4:0] g0, p0;
  assign g0[0] = gc[2] | gc[1] | (ti[1] & gc[0]);
  assign p0[0] = 1'b0;
  assign g0[1] = gc[5] | gc[4] | (ti[4] & gc[3]);
  assign p0[1] = ti[3] & ti[4] & ti[2];
  assign g0[2] = gc[8] | gc[7] | (ti[7] & gc[6]);
  assign p0[2] = ti[6] & ti[7] & ti[5];
  assign g0[3] = gc[11] | gc[10] | (ti[10] & gc[9]);
  assign p0[3] = ti[9] & ti[10] & ti[8];
  assign g0[4] = gc[12];
  assign p0[4] = ti[11];
  logic G_0_1, G_2_3, P_2_3, G_0_2, G_0_3, G_0_4;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  logic [5:0] bc;
  assign bc[0] = cin;
  assign bc[1] = ti[2] & g0[0];
  assign bc[2] = ti[5] & G_0_1;
  assign bc[3] = ti[8] & G_0_2;
  assign bc[4] = ti[11] & G_0_3;
  assign bc[5] = ti[12] & G_0_4;
  logic [3:0] r0_0;
  assign r0_0[0] = 1'b0;
  assign r0_0[1] = gc[0] | (pi_[0] & r0_0[0]);
  assign r0_0[2] = gc[1] | (pi_[1] & r0_0[1]);
  assign r0_0[3] = gc[2] | (pi_[2] & r0_0[2]);
  logic [3:0] r1_0;
  assign r1_0[0] = 1'b1;
  assign r1_0[1] = gc[0] | (pi_[0] & r1_0[0]);
  assign r1_0[2] = gc[1] | (pi_[1] & r1_0[1]);
  assign r1_0[3] = gc[2] | (pi_[2] & r1_0[2]);
  assign s[0] = pi_[0] ^ (bc[0] ? r1_0[0] : r0_0[0]);
  assign s[1] = pi_[1] ^ (bc[0] ? r1_0[1] : r0_0[1]);
  assign s[2] = pi_[2] ^ (bc[0] ? r1_0[2] : r0_0[2]);
  logic [3:0] r0_1;
  assign r0_1[0] = 1'b0;
  assign r0_1[1] = gc[3] | (pi_[3] & r0_1[0]);
  assign r0_1[2] = gc[4] | (pi_[4] & r0_1[1]);
  assign r0_1[3] = gc[5] | (pi_[5] & r0_1[2]);
  logic [3:0] r1_1;
  assign r1_1[0] = 1'b1;
  assign r1_1[1] = gc[3] | (pi_[3] & r1_1[0]);
  assign r1_1[2] = gc[4] | (pi_[4] & r1_1[1]);
  assign r1_1[3] = gc[5] | (pi_[5] & r1_1[2]);
  assign s[3] = pi_[3] ^ (bc[1] ? r1_1[0] : r0_1[0]);
  assign s[4] = pi_[4] ^ (bc[1] ? r1_1[1] : r0_1[1]);
  assign s[5] = pi_[5] ^ (bc[1] ? r1_1[2] : r0_1[2]);
  logic [3:0] r0_2;
  assign r0_2[0] = 1'b0;
  assign r0_2[1] = gc[6] | (pi_[6] & r0_2[0]);
  assign r0_2[2] = gc[7] | (pi_[7] & r0_2[1]);
  assign r0_2[3] = gc[8] | (pi_[8] & r0_2[2]);
  logic [3:0] r1_2;
  assign r1_2[0] = 1'b1;
  assign r1_2[1] = gc[6] | (pi_[6] & r1_2[0]);
  assign r1_2[2] = gc[7] | (pi_[7] & r1_2[1]);
  assign r1_2[3] = gc[8] | (pi_[8] & r1_2[2]);
  assign s[6] = pi_[6] ^ (bc[2] ? r1_2[0] : r0_2[0]);
  assign s[7] = pi_[7] ^ (bc[2] ? r1_2[1] : r0_2[1]);
  assign s[8] = pi_[8] ^ (bc[2] ? r1_2[2] : r0_2[2]);
  logic [3:0] r0_3;
  assign r0_3[0] = 1'b0;
  assign r0_3[1] = gc[9] | (pi_[9] & r0_3[0]);
  assign r0_3[2] = gc[10] | (pi_[10] & r0_3[1]);
  assign r0_3[3] = gc[11] | (pi_[11] & r0_3[2]);
  logic [3:0] r1_3;
  assign r1_3[0] = 1'b1;
  assign r1_3[1] = gc[9] | (pi_[9] & r1_3[0]);
  assign r1_3[2] = gc[10] | (pi_[10] & r1_3[1]);
  assign r1_3[3] = gc[11] | (pi_[11] & r1_3[2]);
  assign s[9] = pi_[9] ^ (bc[3] ? r1_3[0] : r0_3[0]);
  assign s[10] = pi_[10] ^ (bc[3] ? r1_3[1] : r0_3[1]);
  assign s[11] = pi_[11] ^ (bc[3] ? r1_3[2] : r0_3[2]);
  logic [1:0] r0_4;
  assign r0_4[0] = 1'b0;
  assign r0_4[1] = gc[12] | (pi_[12] & r0_4[0]);
  logic [1:0] r1_4;
  assign r1_4[0] = 1'b1;
  assign r1_4[1] = gc[12] | (pi_[12] & r1_4[0]);
  assign s[12] = pi_[12] ^ (bc[4] ? r1_4[0] : r0_4[0]);
  assign cout = bc[5];
endmodule



module fam_prefix_han_carlson_w8_ling (input logic [7:0] a, input logic [7:0] b, input logic cin,
  output logic [7:0] s, output logic cout);
  // prefix graph: {'n': 8, 'levels': 4, 'size': 12, 'fanout': 3, 'tracks': 2, 'exact_split': True, 'valency': 2}
  logic [7:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [7:0] g0, p0;
  assign g0 = {gi[7:1], gi[0] | cin};
  assign p0 = {ti[6:0], 1'b0};
  logic G_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_0_2, G_0_3, G_2_5, P_2_5, G_4_7, P_4_7, G_0_4, G_0_5, G_0_7, G_0_6;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_0_6 = g0[6] | (p0[6] & G_0_5);
  logic [8:0] c;
  assign c[0] = cin;
  assign c[1] = ti[0] & g0[0];
  assign c[2] = ti[1] & G_0_1;
  assign c[3] = ti[2] & G_0_2;
  assign c[4] = ti[3] & G_0_3;
  assign c[5] = ti[4] & G_0_4;
  assign c[6] = ti[5] & G_0_5;
  assign c[7] = ti[6] & G_0_6;
  assign c[8] = ti[7] & G_0_7;
  assign s = pi_ ^ c[7:0];
  assign cout = c[8];
endmodule


module fam_prefix_harris_l2f2_w27 (input logic [26:0] a, input logic [26:0] b, input logic cin,
  output logic [26:0] s, output logic cout);
  // prefix graph: {'n': 27, 'levels': 7, 'size': 45, 'fanout': 4, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [26:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [26:0] g0, p0;
  assign g0 = {gi[26:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_8_9, P_8_9, G_10_11, P_10_11, G_12_13, P_12_13, G_14_15, P_14_15, G_16_17, P_16_17, G_18_19, P_18_19, G_20_21, P_20_21, G_22_23, P_22_23, G_24_25, P_24_25, G_0_2, G_0_3, G_4_7, P_4_7, G_8_11, P_8_11, G_12_15, P_12_15, G_16_19, P_16_19, G_20_23, P_20_23, G_0_4, G_0_5, G_0_7, G_8_15, P_8_15, G_16_23, P_16_23, G_0_6, G_0_8, G_0_9, G_0_11, G_0_15, G_0_10, G_0_12, G_0_13, G_0_16, G_0_17, G_0_19, G_0_23, G_0_14, G_0_18, G_0_20, G_0_21, G_0_24, G_0_25, G_0_22, G_0_26;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_16_17 = g0[17] | (p0[17] & g0[16]);
  assign P_16_17 = p0[17] & p0[16];
  assign G_18_19 = g0[19] | (p0[19] & g0[18]);
  assign P_18_19 = p0[19] & p0[18];
  assign G_20_21 = g0[21] | (p0[21] & g0[20]);
  assign P_20_21 = p0[21] & p0[20];
  assign G_22_23 = g0[23] | (p0[23] & g0[22]);
  assign P_22_23 = p0[23] & p0[22];
  assign G_24_25 = g0[25] | (p0[25] & g0[24]);
  assign P_24_25 = p0[25] & p0[24];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_12_15 = G_14_15 | (P_14_15 & G_12_13);
  assign P_12_15 = P_14_15 & P_12_13;
  assign G_16_19 = G_18_19 | (P_18_19 & G_16_17);
  assign P_16_19 = P_18_19 & P_16_17;
  assign G_20_23 = G_22_23 | (P_22_23 & G_20_21);
  assign P_20_23 = P_22_23 & P_20_21;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign G_0_5 = G_4_5 | (P_4_5 & G_0_3);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_8_15 = G_12_15 | (P_12_15 & G_8_11);
  assign P_8_15 = P_12_15 & P_8_11;
  assign G_16_23 = G_20_23 | (P_20_23 & G_16_19);
  assign P_16_23 = P_20_23 & P_16_19;
  assign G_0_6 = g0[6] | (p0[6] & G_0_5);
  assign G_0_8 = g0[8] | (p0[8] & G_0_7);
  assign G_0_9 = G_8_9 | (P_8_9 & G_0_7);
  assign G_0_11 = G_8_11 | (P_8_11 & G_0_7);
  assign G_0_15 = G_8_15 | (P_8_15 & G_0_7);
  assign G_0_10 = g0[10] | (p0[10] & G_0_9);
  assign G_0_12 = g0[12] | (p0[12] & G_0_11);
  assign G_0_13 = G_12_13 | (P_12_13 & G_0_11);
  assign G_0_16 = g0[16] | (p0[16] & G_0_15);
  assign G_0_17 = G_16_17 | (P_16_17 & G_0_15);
  assign G_0_19 = G_16_19 | (P_16_19 & G_0_15);
  assign G_0_23 = G_16_23 | (P_16_23 & G_0_15);
  assign G_0_14 = g0[14] | (p0[14] & G_0_13);
  assign G_0_18 = g0[18] | (p0[18] & G_0_17);
  assign G_0_20 = g0[20] | (p0[20] & G_0_19);
  assign G_0_21 = G_20_21 | (P_20_21 & G_0_19);
  assign G_0_24 = g0[24] | (p0[24] & G_0_23);
  assign G_0_25 = G_24_25 | (P_24_25 & G_0_23);
  assign G_0_22 = g0[22] | (p0[22] & G_0_21);
  assign G_0_26 = g0[26] | (p0[26] & G_0_25);
  logic [27:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign c[15] = G_0_14;
  assign c[16] = G_0_15;
  assign c[17] = G_0_16;
  assign c[18] = G_0_17;
  assign c[19] = G_0_18;
  assign c[20] = G_0_19;
  assign c[21] = G_0_20;
  assign c[22] = G_0_21;
  assign c[23] = G_0_22;
  assign c[24] = G_0_23;
  assign c[25] = G_0_24;
  assign c[26] = G_0_25;
  assign c[27] = G_0_26;
  assign s = pi_ ^ c[26:0];
  assign cout = c[27];
endmodule
// selected EAC followed by an ordinary binary sum/carry decoder

// end_around_carry (mod_2n_plus_1_diminished_one, two_pass_prefix, harris, the incrementer prefix_and_incrementer): the carry-out re-enters as the carry-in


// carry_select: blocks [1, 2, 3, 3, 4] (delay_balanced_dp), full_duplicate, selects lookahead_tree

































module fam_prefix_kogge_stone_w13_ling2 (input logic [12:0] a, input logic [12:0] b, input logic cin,
  output logic [12:0] s, output logic cout);
  // prefix graph: {'n': 7, 'levels': 3, 'size': 14, 'fanout': 3, 'tracks': 3, 'exact_split': True, 'valency': 2}
  logic [12:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [12:0] gc;
  assign gc = {gi[12:1], gi[0] | (pi_[0] & cin)};
  logic [6:0] g0, p0;
  assign g0[0] = gc[1] | gc[0];
  assign p0[0] = 1'b0;
  assign g0[1] = gc[3] | gc[2];
  assign p0[1] = ti[2] & ti[1];
  assign g0[2] = gc[5] | gc[4];
  assign p0[2] = ti[4] & ti[3];
  assign g0[3] = gc[7] | gc[6];
  assign p0[3] = ti[6] & ti[5];
  assign g0[4] = gc[9] | gc[8];
  assign p0[4] = ti[8] & ti[7];
  assign g0[5] = gc[11] | gc[10];
  assign p0[5] = ti[10] & ti[9];
  assign g0[6] = gc[12];
  assign p0[6] = ti[11];
  logic G_0_1, G_1_2, P_1_2, G_2_3, P_2_3, G_3_4, P_3_4, G_4_5, P_4_5, G_5_6, P_5_6, G_0_2, G_0_3, G_1_4, P_1_4, G_2_5, P_2_5, G_3_6, P_3_6, G_0_4, G_0_5, G_0_6;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_5_6 = g0[6] | (p0[6] & g0[5]);
  assign P_5_6 = p0[6] & p0[5];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_1_4 = G_3_4 | (P_3_4 & G_1_2);
  assign P_1_4 = P_3_4 & P_1_2;
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_3_6 = G_5_6 | (P_5_6 & G_3_4);
  assign P_3_6 = P_5_6 & P_3_4;
  assign G_0_4 = G_1_4 | (P_1_4 & g0[0]);
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  assign G_0_6 = G_3_6 | (P_3_6 & G_0_2);
  logic [7:0] bc;
  assign bc[0] = cin;
  assign bc[1] = ti[1] & g0[0];
  assign bc[2] = ti[3] & G_0_1;
  assign bc[3] = ti[5] & G_0_2;
  assign bc[4] = ti[7] & G_0_3;
  assign bc[5] = ti[9] & G_0_4;
  assign bc[6] = ti[11] & G_0_5;
  assign bc[7] = ti[12] & G_0_6;
  logic [2:0] r_0;
  assign r_0[0] = bc[0];
  assign r_0[1] = gc[0] | (pi_[0] & r_0[0]);
  assign s[0] = pi_[0] ^ r_0[0];
  assign r_0[2] = gc[1] | (pi_[1] & r_0[1]);
  assign s[1] = pi_[1] ^ r_0[1];
  logic [2:0] r_1;
  assign r_1[0] = bc[1];
  assign r_1[1] = gc[2] | (pi_[2] & r_1[0]);
  assign s[2] = pi_[2] ^ r_1[0];
  assign r_1[2] = gc[3] | (pi_[3] & r_1[1]);
  assign s[3] = pi_[3] ^ r_1[1];
  logic [2:0] r_2;
  assign r_2[0] = bc[2];
  assign r_2[1] = gc[4] | (pi_[4] & r_2[0]);
  assign s[4] = pi_[4] ^ r_2[0];
  assign r_2[2] = gc[5] | (pi_[5] & r_2[1]);
  assign s[5] = pi_[5] ^ r_2[1];
  logic [2:0] r_3;
  assign r_3[0] = bc[3];
  assign r_3[1] = gc[6] | (pi_[6] & r_3[0]);
  assign s[6] = pi_[6] ^ r_3[0];
  assign r_3[2] = gc[7] | (pi_[7] & r_3[1]);
  assign s[7] = pi_[7] ^ r_3[1];
  logic [2:0] r_4;
  assign r_4[0] = bc[4];
  assign r_4[1] = gc[8] | (pi_[8] & r_4[0]);
  assign s[8] = pi_[8] ^ r_4[0];
  assign r_4[2] = gc[9] | (pi_[9] & r_4[1]);
  assign s[9] = pi_[9] ^ r_4[1];
  logic [2:0] r_5;
  assign r_5[0] = bc[5];
  assign r_5[1] = gc[10] | (pi_[10] & r_5[0]);
  assign s[10] = pi_[10] ^ r_5[0];
  assign r_5[2] = gc[11] | (pi_[11] & r_5[1]);
  assign s[11] = pi_[11] ^ r_5[1];
  logic [1:0] r_6;
  assign r_6[0] = bc[6];
  assign r_6[1] = gc[12] | (pi_[12] & r_6[0]);
  assign s[12] = pi_[12] ^ r_6[0];
  assign cout = bc[7];
endmodule


module fam_prefix_kogge_stone_w27_ling2 (input logic [26:0] a, input logic [26:0] b, input logic cin,
  output logic [26:0] s, output logic cout);
  // prefix graph: {'n': 14, 'levels': 4, 'size': 41, 'fanout': 4, 'tracks': 6, 'exact_split': True, 'valency': 2}
  logic [26:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [26:0] gc;
  assign gc = {gi[26:1], gi[0] | (pi_[0] & cin)};
  logic [13:0] g0, p0;
  assign g0[0] = gc[1] | gc[0];
  assign p0[0] = 1'b0;
  assign g0[1] = gc[3] | gc[2];
  assign p0[1] = ti[2] & ti[1];
  assign g0[2] = gc[5] | gc[4];
  assign p0[2] = ti[4] & ti[3];
  assign g0[3] = gc[7] | gc[6];
  assign p0[3] = ti[6] & ti[5];
  assign g0[4] = gc[9] | gc[8];
  assign p0[4] = ti[8] & ti[7];
  assign g0[5] = gc[11] | gc[10];
  assign p0[5] = ti[10] & ti[9];
  assign g0[6] = gc[13] | gc[12];
  assign p0[6] = ti[12] & ti[11];
  assign g0[7] = gc[15] | gc[14];
  assign p0[7] = ti[14] & ti[13];
  assign g0[8] = gc[17] | gc[16];
  assign p0[8] = ti[16] & ti[15];
  assign g0[9] = gc[19] | gc[18];
  assign p0[9] = ti[18] & ti[17];
  assign g0[10] = gc[21] | gc[20];
  assign p0[10] = ti[20] & ti[19];
  assign g0[11] = gc[23] | gc[22];
  assign p0[11] = ti[22] & ti[21];
  assign g0[12] = gc[25] | gc[24];
  assign p0[12] = ti[24] & ti[23];
  assign g0[13] = gc[26];
  assign p0[13] = ti[25];
  logic G_0_1, G_1_2, P_1_2, G_2_3, P_2_3, G_3_4, P_3_4, G_4_5, P_4_5, G_5_6, P_5_6, G_6_7, P_6_7, G_7_8, P_7_8, G_8_9, P_8_9, G_9_10, P_9_10, G_10_11, P_10_11, G_11_12, P_11_12, G_12_13, P_12_13, G_0_2, G_0_3, G_1_4, P_1_4, G_2_5, P_2_5, G_3_6, P_3_6, G_4_7, P_4_7, G_5_8, P_5_8, G_6_9, P_6_9, G_7_10, P_7_10, G_8_11, P_8_11, G_9_12, P_9_12, G_10_13, P_10_13, G_0_4, G_0_5, G_0_6, G_0_7, G_1_8, P_1_8, G_2_9, P_2_9, G_3_10, P_3_10, G_4_11, P_4_11, G_5_12, P_5_12, G_6_13, P_6_13, G_0_8, G_0_9, G_0_10, G_0_11, G_0_12, G_0_13;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_5_6 = g0[6] | (p0[6] & g0[5]);
  assign P_5_6 = p0[6] & p0[5];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_7_8 = g0[8] | (p0[8] & g0[7]);
  assign P_7_8 = p0[8] & p0[7];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_9_10 = g0[10] | (p0[10] & g0[9]);
  assign P_9_10 = p0[10] & p0[9];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_11_12 = g0[12] | (p0[12] & g0[11]);
  assign P_11_12 = p0[12] & p0[11];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_1_4 = G_3_4 | (P_3_4 & G_1_2);
  assign P_1_4 = P_3_4 & P_1_2;
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_3_6 = G_5_6 | (P_5_6 & G_3_4);
  assign P_3_6 = P_5_6 & P_3_4;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_5_8 = G_7_8 | (P_7_8 & G_5_6);
  assign P_5_8 = P_7_8 & P_5_6;
  assign G_6_9 = G_8_9 | (P_8_9 & G_6_7);
  assign P_6_9 = P_8_9 & P_6_7;
  assign G_7_10 = G_9_10 | (P_9_10 & G_7_8);
  assign P_7_10 = P_9_10 & P_7_8;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_9_12 = G_11_12 | (P_11_12 & G_9_10);
  assign P_9_12 = P_11_12 & P_9_10;
  assign G_10_13 = G_12_13 | (P_12_13 & G_10_11);
  assign P_10_13 = P_12_13 & P_10_11;
  assign G_0_4 = G_1_4 | (P_1_4 & g0[0]);
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  assign G_0_6 = G_3_6 | (P_3_6 & G_0_2);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_1_8 = G_5_8 | (P_5_8 & G_1_4);
  assign P_1_8 = P_5_8 & P_1_4;
  assign G_2_9 = G_6_9 | (P_6_9 & G_2_5);
  assign P_2_9 = P_6_9 & P_2_5;
  assign G_3_10 = G_7_10 | (P_7_10 & G_3_6);
  assign P_3_10 = P_7_10 & P_3_6;
  assign G_4_11 = G_8_11 | (P_8_11 & G_4_7);
  assign P_4_11 = P_8_11 & P_4_7;
  assign G_5_12 = G_9_12 | (P_9_12 & G_5_8);
  assign P_5_12 = P_9_12 & P_5_8;
  assign G_6_13 = G_10_13 | (P_10_13 & G_6_9);
  assign P_6_13 = P_10_13 & P_6_9;
  assign G_0_8 = G_1_8 | (P_1_8 & g0[0]);
  assign G_0_9 = G_2_9 | (P_2_9 & G_0_1);
  assign G_0_10 = G_3_10 | (P_3_10 & G_0_2);
  assign G_0_11 = G_4_11 | (P_4_11 & G_0_3);
  assign G_0_12 = G_5_12 | (P_5_12 & G_0_4);
  assign G_0_13 = G_6_13 | (P_6_13 & G_0_5);
  logic [14:0] bc;
  assign bc[0] = cin;
  assign bc[1] = ti[1] & g0[0];
  assign bc[2] = ti[3] & G_0_1;
  assign bc[3] = ti[5] & G_0_2;
  assign bc[4] = ti[7] & G_0_3;
  assign bc[5] = ti[9] & G_0_4;
  assign bc[6] = ti[11] & G_0_5;
  assign bc[7] = ti[13] & G_0_6;
  assign bc[8] = ti[15] & G_0_7;
  assign bc[9] = ti[17] & G_0_8;
  assign bc[10] = ti[19] & G_0_9;
  assign bc[11] = ti[21] & G_0_10;
  assign bc[12] = ti[23] & G_0_11;
  assign bc[13] = ti[25] & G_0_12;
  assign bc[14] = ti[26] & G_0_13;
  logic [2:0] r_0;
  assign r_0[0] = bc[0];
  assign r_0[1] = gc[0] | (pi_[0] & r_0[0]);
  assign s[0] = pi_[0] ^ r_0[0];
  assign r_0[2] = gc[1] | (pi_[1] & r_0[1]);
  assign s[1] = pi_[1] ^ r_0[1];
  logic [2:0] r_1;
  assign r_1[0] = bc[1];
  assign r_1[1] = gc[2] | (pi_[2] & r_1[0]);
  assign s[2] = pi_[2] ^ r_1[0];
  assign r_1[2] = gc[3] | (pi_[3] & r_1[1]);
  assign s[3] = pi_[3] ^ r_1[1];
  logic [2:0] r_2;
  assign r_2[0] = bc[2];
  assign r_2[1] = gc[4] | (pi_[4] & r_2[0]);
  assign s[4] = pi_[4] ^ r_2[0];
  assign r_2[2] = gc[5] | (pi_[5] & r_2[1]);
  assign s[5] = pi_[5] ^ r_2[1];
  logic [2:0] r_3;
  assign r_3[0] = bc[3];
  assign r_3[1] = gc[6] | (pi_[6] & r_3[0]);
  assign s[6] = pi_[6] ^ r_3[0];
  assign r_3[2] = gc[7] | (pi_[7] & r_3[1]);
  assign s[7] = pi_[7] ^ r_3[1];
  logic [2:0] r_4;
  assign r_4[0] = bc[4];
  assign r_4[1] = gc[8] | (pi_[8] & r_4[0]);
  assign s[8] = pi_[8] ^ r_4[0];
  assign r_4[2] = gc[9] | (pi_[9] & r_4[1]);
  assign s[9] = pi_[9] ^ r_4[1];
  logic [2:0] r_5;
  assign r_5[0] = bc[5];
  assign r_5[1] = gc[10] | (pi_[10] & r_5[0]);
  assign s[10] = pi_[10] ^ r_5[0];
  assign r_5[2] = gc[11] | (pi_[11] & r_5[1]);
  assign s[11] = pi_[11] ^ r_5[1];
  logic [2:0] r_6;
  assign r_6[0] = bc[6];
  assign r_6[1] = gc[12] | (pi_[12] & r_6[0]);
  assign s[12] = pi_[12] ^ r_6[0];
  assign r_6[2] = gc[13] | (pi_[13] & r_6[1]);
  assign s[13] = pi_[13] ^ r_6[1];
  logic [2:0] r_7;
  assign r_7[0] = bc[7];
  assign r_7[1] = gc[14] | (pi_[14] & r_7[0]);
  assign s[14] = pi_[14] ^ r_7[0];
  assign r_7[2] = gc[15] | (pi_[15] & r_7[1]);
  assign s[15] = pi_[15] ^ r_7[1];
  logic [2:0] r_8;
  assign r_8[0] = bc[8];
  assign r_8[1] = gc[16] | (pi_[16] & r_8[0]);
  assign s[16] = pi_[16] ^ r_8[0];
  assign r_8[2] = gc[17] | (pi_[17] & r_8[1]);
  assign s[17] = pi_[17] ^ r_8[1];
  logic [2:0] r_9;
  assign r_9[0] = bc[9];
  assign r_9[1] = gc[18] | (pi_[18] & r_9[0]);
  assign s[18] = pi_[18] ^ r_9[0];
  assign r_9[2] = gc[19] | (pi_[19] & r_9[1]);
  assign s[19] = pi_[19] ^ r_9[1];
  logic [2:0] r_10;
  assign r_10[0] = bc[10];
  assign r_10[1] = gc[20] | (pi_[20] & r_10[0]);
  assign s[20] = pi_[20] ^ r_10[0];
  assign r_10[2] = gc[21] | (pi_[21] & r_10[1]);
  assign s[21] = pi_[21] ^ r_10[1];
  logic [2:0] r_11;
  assign r_11[0] = bc[11];
  assign r_11[1] = gc[22] | (pi_[22] & r_11[0]);
  assign s[22] = pi_[22] ^ r_11[0];
  assign r_11[2] = gc[23] | (pi_[23] & r_11[1]);
  assign s[23] = pi_[23] ^ r_11[1];
  logic [2:0] r_12;
  assign r_12[0] = bc[12];
  assign r_12[1] = gc[24] | (pi_[24] & r_12[0]);
  assign s[24] = pi_[24] ^ r_12[0];
  assign r_12[2] = gc[25] | (pi_[25] & r_12[1]);
  assign s[25] = pi_[25] ^ r_12[1];
  logic [1:0] r_13;
  assign r_13[0] = bc[13];
  assign r_13[1] = gc[26] | (pi_[26] & r_13[0]);
  assign s[26] = pi_[26] ^ r_13[0];
  assign cout = bc[14];
endmodule



module fam_prefix_kogge_stone_w4 (input logic [3:0] a, input logic [3:0] b, input logic cin,
  output logic [3:0] s, output logic cout);
  // prefix graph: {'n': 4, 'levels': 2, 'size': 5, 'fanout': 2, 'tracks': 2, 'exact_split': True, 'valency': 2}
  logic [3:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [3:0] g0, p0;
  assign g0 = {gi[3:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_1_2, P_1_2, G_2_3, P_2_3, G_0_2, G_0_3;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  logic [4:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign s = pi_ ^ c[3:0];
  assign cout = c[4];
endmodule


// lzd_cell_tree (pair_cell, binary_count, valid flags propagated): the leading zeros of a 64-bit word

// lzd_cell_tree (pair_cell, binary_count, valid flags propagated): the leading zeros of a 64-bit word

// lzd_cell_tree (pair_cell, binary_count, valid flags propagated): the leading zeros of a 64-bit word

module fam_prefix_kogge_stone_w8_flag_dual (input logic [7:0] a, input logic [7:0] b, input logic cin,
  output logic [7:0] s, output logic cout, output logic [7:0] s1);
  // prefix graph: {'n': 8, 'levels': 3, 'size': 17, 'fanout': 3, 'tracks': 4, 'exact_split': True, 'valency': 2}
  logic [7:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [7:0] g0, p0;
  assign g0 = {gi[7:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, P_0_1, G_1_2, P_1_2, G_2_3, P_2_3, G_3_4, P_3_4, G_4_5, P_4_5, G_5_6, P_5_6, G_6_7, P_6_7, G_0_2, P_0_2, G_0_3, P_0_3, G_1_4, P_1_4, G_2_5, P_2_5, G_3_6, P_3_6, G_4_7, P_4_7, G_0_4, P_0_4, G_0_5, P_0_5, G_0_6, P_0_6, G_0_7, P_0_7;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign P_0_1 = p0[1] & p0[0];
  assign G_1_2 = g0[2] | (p0[2] & g0[1]);
  assign P_1_2 = p0[2] & p0[1];
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_3_4 = g0[4] | (p0[4] & g0[3]);
  assign P_3_4 = p0[4] & p0[3];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_5_6 = g0[6] | (p0[6] & g0[5]);
  assign P_5_6 = p0[6] & p0[5];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_0_2 = G_1_2 | (P_1_2 & g0[0]);
  assign P_0_2 = P_1_2 & p0[0];
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign P_0_3 = P_2_3 & P_0_1;
  assign G_1_4 = G_3_4 | (P_3_4 & G_1_2);
  assign P_1_4 = P_3_4 & P_1_2;
  assign G_2_5 = G_4_5 | (P_4_5 & G_2_3);
  assign P_2_5 = P_4_5 & P_2_3;
  assign G_3_6 = G_5_6 | (P_5_6 & G_3_4);
  assign P_3_6 = P_5_6 & P_3_4;
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_0_4 = G_1_4 | (P_1_4 & g0[0]);
  assign P_0_4 = P_1_4 & p0[0];
  assign G_0_5 = G_2_5 | (P_2_5 & G_0_1);
  assign P_0_5 = P_2_5 & P_0_1;
  assign G_0_6 = G_3_6 | (P_3_6 & G_0_2);
  assign P_0_6 = P_3_6 & P_0_2;
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign P_0_7 = P_4_7 & P_0_3;
  logic [8:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign s = pi_ ^ c[7:0];
  assign cout = c[8];
  logic [7:0] g1, p1;
  assign g1 = {gi[7:1], gi[0] | pi_[0]};
  assign p1 = pi_;
  logic H_0_1, H_1_2, Q_1_2, H_2_3, Q_2_3, H_3_4, Q_3_4, H_4_5, Q_4_5, H_5_6, Q_5_6, H_6_7, Q_6_7, H_0_2, H_0_3, H_1_4, Q_1_4, H_2_5, Q_2_5, H_3_6, Q_3_6, H_4_7, Q_4_7, H_0_4, H_0_5, H_0_6, H_0_7;
  assign H_0_1 = g1[1] | (p1[1] & g1[0]);
  assign H_1_2 = g1[2] | (p1[2] & g1[1]);
  assign Q_1_2 = p1[2] & p1[1];
  assign H_2_3 = g1[3] | (p1[3] & g1[2]);
  assign Q_2_3 = p1[3] & p1[2];
  assign H_3_4 = g1[4] | (p1[4] & g1[3]);
  assign Q_3_4 = p1[4] & p1[3];
  assign H_4_5 = g1[5] | (p1[5] & g1[4]);
  assign Q_4_5 = p1[5] & p1[4];
  assign H_5_6 = g1[6] | (p1[6] & g1[5]);
  assign Q_5_6 = p1[6] & p1[5];
  assign H_6_7 = g1[7] | (p1[7] & g1[6]);
  assign Q_6_7 = p1[7] & p1[6];
  assign H_0_2 = H_1_2 | (Q_1_2 & g1[0]);
  assign H_0_3 = H_2_3 | (Q_2_3 & H_0_1);
  assign H_1_4 = H_3_4 | (Q_3_4 & H_1_2);
  assign Q_1_4 = Q_3_4 & Q_1_2;
  assign H_2_5 = H_4_5 | (Q_4_5 & H_2_3);
  assign Q_2_5 = Q_4_5 & Q_2_3;
  assign H_3_6 = H_5_6 | (Q_5_6 & H_3_4);
  assign Q_3_6 = Q_5_6 & Q_3_4;
  assign H_4_7 = H_6_7 | (Q_6_7 & H_4_5);
  assign Q_4_7 = Q_6_7 & Q_4_5;
  assign H_0_4 = H_1_4 | (Q_1_4 & g1[0]);
  assign H_0_5 = H_2_5 | (Q_2_5 & H_0_1);
  assign H_0_6 = H_3_6 | (Q_3_6 & H_0_2);
  assign H_0_7 = H_4_7 | (Q_4_7 & H_0_3);
  logic [8:0] c1;
  assign c1[0] = 1'b1;
  assign c1[1] = g1[0];
  assign c1[2] = H_0_1;
  assign c1[3] = H_0_2;
  assign c1[4] = H_0_3;
  assign c1[5] = H_0_4;
  assign c1[6] = H_0_5;
  assign c1[7] = H_0_6;
  assign c1[8] = H_0_7;
  assign s1 = pi_ ^ c1[7:0];
endmodule




























module fam_prefix_ladner_fischer_w13 (input logic [12:0] a, input logic [12:0] b, input logic cin,
  output logic [12:0] s, output logic cout);
  // prefix graph: {'n': 13, 'levels': 5, 'size': 19, 'fanout': 3, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [12:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [12:0] g0, p0;
  assign g0 = {gi[12:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_8_9, P_8_9, G_10_11, P_10_11, G_0_2, G_0_3, G_4_7, P_4_7, G_8_11, P_8_11, G_0_4, G_0_5, G_0_7, G_0_6, G_0_8, G_0_9, G_0_11, G_0_10, G_0_12;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign G_0_5 = G_4_5 | (P_4_5 & G_0_3);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_0_6 = g0[6] | (p0[6] & G_0_5);
  assign G_0_8 = g0[8] | (p0[8] & G_0_7);
  assign G_0_9 = G_8_9 | (P_8_9 & G_0_7);
  assign G_0_11 = G_8_11 | (P_8_11 & G_0_7);
  assign G_0_10 = g0[10] | (p0[10] & G_0_9);
  assign G_0_12 = g0[12] | (p0[12] & G_0_11);
  logic [13:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign s = pi_ ^ c[12:0];
  assign cout = c[13];
endmodule


module fam_prefix_ladner_fischer_w14 (input logic [13:0] a, input logic [13:0] b, input logic cin,
  output logic [13:0] s, output logic cout);
  // prefix graph: {'n': 14, 'levels': 5, 'size': 22, 'fanout': 4, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [13:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [13:0] g0, p0;
  assign g0 = {gi[13:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_8_9, P_8_9, G_10_11, P_10_11, G_12_13, P_12_13, G_0_2, G_0_3, G_4_7, P_4_7, G_8_11, P_8_11, G_0_4, G_0_5, G_0_7, G_8_13, P_8_13, G_0_6, G_0_8, G_0_9, G_0_11, G_0_13, G_0_10, G_0_12;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign G_0_5 = G_4_5 | (P_4_5 & G_0_3);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_8_13 = G_12_13 | (P_12_13 & G_8_11);
  assign P_8_13 = P_12_13 & P_8_11;
  assign G_0_6 = g0[6] | (p0[6] & G_0_5);
  assign G_0_8 = g0[8] | (p0[8] & G_0_7);
  assign G_0_9 = G_8_9 | (P_8_9 & G_0_7);
  assign G_0_11 = G_8_11 | (P_8_11 & G_0_7);
  assign G_0_13 = G_8_13 | (P_8_13 & G_0_7);
  assign G_0_10 = g0[10] | (p0[10] & G_0_9);
  assign G_0_12 = g0[12] | (p0[12] & G_0_11);
  logic [14:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign s = pi_ ^ c[13:0];
  assign cout = c[14];
endmodule
// selected EAC followed by an ordinary binary sum/carry decoder

// end_around_carry (mod_2n_minus_1, two_pass_prefix, ladner_fischer, the incrementer prefix_and_incrementer): the carry-out re-enters as the carry-in





module fam_prefix_ladner_fischer_w27 (input logic [26:0] a, input logic [26:0] b, input logic cin,
  output logic [26:0] s, output logic cout);
  // prefix graph: {'n': 27, 'levels': 6, 'size': 48, 'fanout': 6, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [26:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [26:0] g0, p0;
  assign g0 = {gi[26:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_8_9, P_8_9, G_10_11, P_10_11, G_12_13, P_12_13, G_14_15, P_14_15, G_16_17, P_16_17, G_18_19, P_18_19, G_20_21, P_20_21, G_22_23, P_22_23, G_24_25, P_24_25, G_0_2, G_0_3, G_4_7, P_4_7, G_8_11, P_8_11, G_12_15, P_12_15, G_16_19, P_16_19, G_20_23, P_20_23, G_0_4, G_0_5, G_0_7, G_8_13, P_8_13, G_8_15, P_8_15, G_16_21, P_16_21, G_16_23, P_16_23, G_0_6, G_0_8, G_0_9, G_0_11, G_0_13, G_0_15, G_16_25, P_16_25, G_0_10, G_0_12, G_0_14, G_0_16, G_0_17, G_0_19, G_0_21, G_0_23, G_0_25, G_0_18, G_0_20, G_0_22, G_0_24, G_0_26;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_16_17 = g0[17] | (p0[17] & g0[16]);
  assign P_16_17 = p0[17] & p0[16];
  assign G_18_19 = g0[19] | (p0[19] & g0[18]);
  assign P_18_19 = p0[19] & p0[18];
  assign G_20_21 = g0[21] | (p0[21] & g0[20]);
  assign P_20_21 = p0[21] & p0[20];
  assign G_22_23 = g0[23] | (p0[23] & g0[22]);
  assign P_22_23 = p0[23] & p0[22];
  assign G_24_25 = g0[25] | (p0[25] & g0[24]);
  assign P_24_25 = p0[25] & p0[24];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_12_15 = G_14_15 | (P_14_15 & G_12_13);
  assign P_12_15 = P_14_15 & P_12_13;
  assign G_16_19 = G_18_19 | (P_18_19 & G_16_17);
  assign P_16_19 = P_18_19 & P_16_17;
  assign G_20_23 = G_22_23 | (P_22_23 & G_20_21);
  assign P_20_23 = P_22_23 & P_20_21;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign G_0_5 = G_4_5 | (P_4_5 & G_0_3);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_8_13 = G_12_13 | (P_12_13 & G_8_11);
  assign P_8_13 = P_12_13 & P_8_11;
  assign G_8_15 = G_12_15 | (P_12_15 & G_8_11);
  assign P_8_15 = P_12_15 & P_8_11;
  assign G_16_21 = G_20_21 | (P_20_21 & G_16_19);
  assign P_16_21 = P_20_21 & P_16_19;
  assign G_16_23 = G_20_23 | (P_20_23 & G_16_19);
  assign P_16_23 = P_20_23 & P_16_19;
  assign G_0_6 = g0[6] | (p0[6] & G_0_5);
  assign G_0_8 = g0[8] | (p0[8] & G_0_7);
  assign G_0_9 = G_8_9 | (P_8_9 & G_0_7);
  assign G_0_11 = G_8_11 | (P_8_11 & G_0_7);
  assign G_0_13 = G_8_13 | (P_8_13 & G_0_7);
  assign G_0_15 = G_8_15 | (P_8_15 & G_0_7);
  assign G_16_25 = G_24_25 | (P_24_25 & G_16_23);
  assign P_16_25 = P_24_25 & P_16_23;
  assign G_0_10 = g0[10] | (p0[10] & G_0_9);
  assign G_0_12 = g0[12] | (p0[12] & G_0_11);
  assign G_0_14 = g0[14] | (p0[14] & G_0_13);
  assign G_0_16 = g0[16] | (p0[16] & G_0_15);
  assign G_0_17 = G_16_17 | (P_16_17 & G_0_15);
  assign G_0_19 = G_16_19 | (P_16_19 & G_0_15);
  assign G_0_21 = G_16_21 | (P_16_21 & G_0_15);
  assign G_0_23 = G_16_23 | (P_16_23 & G_0_15);
  assign G_0_25 = G_16_25 | (P_16_25 & G_0_15);
  assign G_0_18 = g0[18] | (p0[18] & G_0_17);
  assign G_0_20 = g0[20] | (p0[20] & G_0_19);
  assign G_0_22 = g0[22] | (p0[22] & G_0_21);
  assign G_0_24 = g0[24] | (p0[24] & G_0_23);
  assign G_0_26 = g0[26] | (p0[26] & G_0_25);
  logic [27:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign c[15] = G_0_14;
  assign c[16] = G_0_15;
  assign c[17] = G_0_16;
  assign c[18] = G_0_17;
  assign c[19] = G_0_18;
  assign c[20] = G_0_19;
  assign c[21] = G_0_20;
  assign c[22] = G_0_21;
  assign c[23] = G_0_22;
  assign c[24] = G_0_23;
  assign c[25] = G_0_24;
  assign c[26] = G_0_25;
  assign c[27] = G_0_26;
  assign s = pi_ ^ c[26:0];
  assign cout = c[27];
endmodule


module fam_prefix_ladner_fischer_w28 (input logic [27:0] a, input logic [27:0] b, input logic cin,
  output logic [27:0] s, output logic cout);
  // prefix graph: {'n': 28, 'levels': 6, 'size': 52, 'fanout': 7, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [27:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [27:0] g0, p0;
  assign g0 = {gi[27:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_2_3, P_2_3, G_4_5, P_4_5, G_6_7, P_6_7, G_8_9, P_8_9, G_10_11, P_10_11, G_12_13, P_12_13, G_14_15, P_14_15, G_16_17, P_16_17, G_18_19, P_18_19, G_20_21, P_20_21, G_22_23, P_22_23, G_24_25, P_24_25, G_26_27, P_26_27, G_0_2, G_0_3, G_4_7, P_4_7, G_8_11, P_8_11, G_12_15, P_12_15, G_16_19, P_16_19, G_20_23, P_20_23, G_24_27, P_24_27, G_0_4, G_0_5, G_0_7, G_8_13, P_8_13, G_8_15, P_8_15, G_16_21, P_16_21, G_16_23, P_16_23, G_0_6, G_0_8, G_0_9, G_0_11, G_0_13, G_0_15, G_16_25, P_16_25, G_16_27, P_16_27, G_0_10, G_0_12, G_0_14, G_0_16, G_0_17, G_0_19, G_0_21, G_0_23, G_0_25, G_0_27, G_0_18, G_0_20, G_0_22, G_0_24, G_0_26;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_4_5 = g0[5] | (p0[5] & g0[4]);
  assign P_4_5 = p0[5] & p0[4];
  assign G_6_7 = g0[7] | (p0[7] & g0[6]);
  assign P_6_7 = p0[7] & p0[6];
  assign G_8_9 = g0[9] | (p0[9] & g0[8]);
  assign P_8_9 = p0[9] & p0[8];
  assign G_10_11 = g0[11] | (p0[11] & g0[10]);
  assign P_10_11 = p0[11] & p0[10];
  assign G_12_13 = g0[13] | (p0[13] & g0[12]);
  assign P_12_13 = p0[13] & p0[12];
  assign G_14_15 = g0[15] | (p0[15] & g0[14]);
  assign P_14_15 = p0[15] & p0[14];
  assign G_16_17 = g0[17] | (p0[17] & g0[16]);
  assign P_16_17 = p0[17] & p0[16];
  assign G_18_19 = g0[19] | (p0[19] & g0[18]);
  assign P_18_19 = p0[19] & p0[18];
  assign G_20_21 = g0[21] | (p0[21] & g0[20]);
  assign P_20_21 = p0[21] & p0[20];
  assign G_22_23 = g0[23] | (p0[23] & g0[22]);
  assign P_22_23 = p0[23] & p0[22];
  assign G_24_25 = g0[25] | (p0[25] & g0[24]);
  assign P_24_25 = p0[25] & p0[24];
  assign G_26_27 = g0[27] | (p0[27] & g0[26]);
  assign P_26_27 = p0[27] & p0[26];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_4_7 = G_6_7 | (P_6_7 & G_4_5);
  assign P_4_7 = P_6_7 & P_4_5;
  assign G_8_11 = G_10_11 | (P_10_11 & G_8_9);
  assign P_8_11 = P_10_11 & P_8_9;
  assign G_12_15 = G_14_15 | (P_14_15 & G_12_13);
  assign P_12_15 = P_14_15 & P_12_13;
  assign G_16_19 = G_18_19 | (P_18_19 & G_16_17);
  assign P_16_19 = P_18_19 & P_16_17;
  assign G_20_23 = G_22_23 | (P_22_23 & G_20_21);
  assign P_20_23 = P_22_23 & P_20_21;
  assign G_24_27 = G_26_27 | (P_26_27 & G_24_25);
  assign P_24_27 = P_26_27 & P_24_25;
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign G_0_5 = G_4_5 | (P_4_5 & G_0_3);
  assign G_0_7 = G_4_7 | (P_4_7 & G_0_3);
  assign G_8_13 = G_12_13 | (P_12_13 & G_8_11);
  assign P_8_13 = P_12_13 & P_8_11;
  assign G_8_15 = G_12_15 | (P_12_15 & G_8_11);
  assign P_8_15 = P_12_15 & P_8_11;
  assign G_16_21 = G_20_21 | (P_20_21 & G_16_19);
  assign P_16_21 = P_20_21 & P_16_19;
  assign G_16_23 = G_20_23 | (P_20_23 & G_16_19);
  assign P_16_23 = P_20_23 & P_16_19;
  assign G_0_6 = g0[6] | (p0[6] & G_0_5);
  assign G_0_8 = g0[8] | (p0[8] & G_0_7);
  assign G_0_9 = G_8_9 | (P_8_9 & G_0_7);
  assign G_0_11 = G_8_11 | (P_8_11 & G_0_7);
  assign G_0_13 = G_8_13 | (P_8_13 & G_0_7);
  assign G_0_15 = G_8_15 | (P_8_15 & G_0_7);
  assign G_16_25 = G_24_25 | (P_24_25 & G_16_23);
  assign P_16_25 = P_24_25 & P_16_23;
  assign G_16_27 = G_24_27 | (P_24_27 & G_16_23);
  assign P_16_27 = P_24_27 & P_16_23;
  assign G_0_10 = g0[10] | (p0[10] & G_0_9);
  assign G_0_12 = g0[12] | (p0[12] & G_0_11);
  assign G_0_14 = g0[14] | (p0[14] & G_0_13);
  assign G_0_16 = g0[16] | (p0[16] & G_0_15);
  assign G_0_17 = G_16_17 | (P_16_17 & G_0_15);
  assign G_0_19 = G_16_19 | (P_16_19 & G_0_15);
  assign G_0_21 = G_16_21 | (P_16_21 & G_0_15);
  assign G_0_23 = G_16_23 | (P_16_23 & G_0_15);
  assign G_0_25 = G_16_25 | (P_16_25 & G_0_15);
  assign G_0_27 = G_16_27 | (P_16_27 & G_0_15);
  assign G_0_18 = g0[18] | (p0[18] & G_0_17);
  assign G_0_20 = g0[20] | (p0[20] & G_0_19);
  assign G_0_22 = g0[22] | (p0[22] & G_0_21);
  assign G_0_24 = g0[24] | (p0[24] & G_0_23);
  assign G_0_26 = g0[26] | (p0[26] & G_0_25);
  logic [28:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign c[5] = G_0_4;
  assign c[6] = G_0_5;
  assign c[7] = G_0_6;
  assign c[8] = G_0_7;
  assign c[9] = G_0_8;
  assign c[10] = G_0_9;
  assign c[11] = G_0_10;
  assign c[12] = G_0_11;
  assign c[13] = G_0_12;
  assign c[14] = G_0_13;
  assign c[15] = G_0_14;
  assign c[16] = G_0_15;
  assign c[17] = G_0_16;
  assign c[18] = G_0_17;
  assign c[19] = G_0_18;
  assign c[20] = G_0_19;
  assign c[21] = G_0_20;
  assign c[22] = G_0_21;
  assign c[23] = G_0_22;
  assign c[24] = G_0_23;
  assign c[25] = G_0_24;
  assign c[26] = G_0_25;
  assign c[27] = G_0_26;
  assign c[28] = G_0_27;
  assign s = pi_ ^ c[27:0];
  assign cout = c[28];
endmodule




module fam_prefix_net_sklansky_w2 (input logic [1:0] g, input logic [1:0] p, input logic cin,
  output logic [1:0] c, output logic cout);
  // prefix graph: {'n': 2, 'levels': 1, 'size': 1, 'fanout': 1, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [1:0] g0, p0;
  assign g0 = {g[1:1], g[0] | (p[0] & cin)};
  assign p0 = p;
  logic G_0_1;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign cout = G_0_1;
endmodule




module fam_prefix_net_sklansky_w3 (input logic [2:0] g, input logic [2:0] p, input logic cin,
  output logic [2:0] c, output logic cout);
  // prefix graph: {'n': 3, 'levels': 2, 'size': 2, 'fanout': 1, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [2:0] g0, p0;
  assign g0 = {g[2:1], g[0] | (p[0] & cin)};
  assign p0 = p;
  logic G_0_1, G_0_2;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign cout = G_0_2;
endmodule




module fam_prefix_net_sklansky_w4 (input logic [3:0] g, input logic [3:0] p, input logic cin,
  output logic [3:0] c, output logic cout);
  // prefix graph: {'n': 4, 'levels': 2, 'size': 4, 'fanout': 2, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [3:0] g0, p0;
  assign g0 = {g[3:1], g[0] | (p[0] & cin)};
  assign p0 = p;
  logic G_0_1, G_2_3, P_2_3, G_0_2, G_0_3;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign cout = G_0_3;
endmodule




module fam_prefix_net_sklansky_w5 (input logic [4:0] g, input logic [4:0] p, input logic cin,
  output logic [4:0] c, output logic cout);
  // prefix graph: {'n': 5, 'levels': 3, 'size': 5, 'fanout': 2, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [4:0] g0, p0;
  assign g0 = {g[4:1], g[0] | (p[0] & cin)};
  assign p0 = p;
  logic G_0_1, G_2_3, P_2_3, G_0_2, G_0_3, G_0_4;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_2_3 = g0[3] | (p0[3] & g0[2]);
  assign P_2_3 = p0[3] & p0[2];
  assign G_0_2 = g0[2] | (p0[2] & G_0_1);
  assign G_0_3 = G_2_3 | (P_2_3 & G_0_1);
  assign G_0_4 = g0[4] | (p0[4] & G_0_3);
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign cout = G_0_4;
endmodule




module fam_prefix_sklansky_w1_v4 (input logic [0:0] a, input logic [0:0] b, input logic cin,
  output logic [0:0] s, output logic cout);
  // prefix graph: {'n': 1, 'levels': 0, 'size': 0, 'fanout': 0, 'tracks': 0, 'exact_split': True, 'valency': 1}
  logic [0:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [0:0] g0, p0;
  assign g0 = gi | (pi_ & cin);
  assign p0 = pi_;
  logic [1:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign s = pi_ ^ c[0:0];
  assign cout = c[1];
endmodule




module fam_prefix_sklansky_w2_v4 (input logic [1:0] a, input logic [1:0] b, input logic cin,
  output logic [1:0] s, output logic cout);
  // prefix graph: {'n': 2, 'levels': 1, 'size': 1, 'fanout': 1, 'tracks': 1, 'exact_split': True, 'valency': 2}
  logic [1:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [1:0] g0, p0;
  assign g0 = {gi[1:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  logic [2:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign s = pi_ ^ c[1:0];
  assign cout = c[2];
endmodule




module fam_prefix_sklansky_w3_v4 (input logic [2:0] a, input logic [2:0] b, input logic cin,
  output logic [2:0] s, output logic cout);
  // prefix graph: {'n': 3, 'levels': 1, 'size': 2, 'fanout': 2, 'tracks': 1, 'exact_split': False, 'valency': 3}
  logic [2:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [2:0] g0, p0;
  assign g0 = {gi[2:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_0_2;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_0_2 = g0[2] | (p0[2] & (g0[1] | (p0[1] & g0[0])));
  logic [3:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign s = pi_ ^ c[2:0];
  assign cout = c[3];
endmodule




module fam_prefix_sklansky_w4_v4 (input logic [3:0] a, input logic [3:0] b, input logic cin,
  output logic [3:0] s, output logic cout);
  // prefix graph: {'n': 4, 'levels': 1, 'size': 3, 'fanout': 3, 'tracks': 1, 'exact_split': False, 'valency': 4}
  logic [3:0] gi, pi_, ti;
  assign gi = a & b;
  assign pi_ = a ^ b;
  assign ti = a | b;
  logic [3:0] g0, p0;
  assign g0 = {gi[3:1], gi[0] | (pi_[0] & cin)};
  assign p0 = pi_;
  logic G_0_1, G_0_2, G_0_3;
  assign G_0_1 = g0[1] | (p0[1] & g0[0]);
  assign G_0_2 = g0[2] | (p0[2] & (g0[1] | (p0[1] & g0[0])));
  assign G_0_3 = g0[3] | (p0[3] & (g0[2] | (p0[2] & (g0[1] | (p0[1] & g0[0])))));
  logic [4:0] c;
  assign c[0] = cin;
  assign c[1] = g0[0];
  assign c[2] = G_0_1;
  assign c[3] = G_0_2;
  assign c[4] = G_0_3;
  assign s = pi_ ^ c[3:0];
  assign cout = c[4];
endmodule



// -------------------------------------------------------------- barrel_mux_tree
// ceil(AW / K) stages of 2^K:1 muxes (RADIX_LOG2 = K; 0 selects one full-width
// stage of W:1 muxes). DIR: 0 mirrored_datapath (a left and a right datapath,
// the result selected by the direction), 1 data_reversal (a right operation is
// a left one on the reversed word), 2 amount_negation (one left rotator; a right
// operation rotates by W - amt, a shift merges the fill through the keep mask).
// ORDER: 0 small_shift_first, 1 large_shift_first. ONE_HOT: the stages' select
// encoding.
module fam_shift_barrel_mux_tree #(parameter int W = 16, parameter int RADIX_LOG2 = 1, parameter int ONE_HOT = 0,
                                   parameter int DIR = 1, parameter int ORDER = 0, parameter int STICKY = 0)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic [2:0] op, output logic [W-1:0] y, output logic sticky);
  localparam int AW = $clog2(W);
  localparam int K = (RADIX_LOG2 == 0 || RADIX_LOG2 > AW) ? AW : RADIX_LOG2;
  localparam int NS = (AW + K - 1) / K;
  wire right = (op == 3'd1) || (op == 3'd2) || (op == 3'd4);
  wire rot = (op == 3'd3) || (op == 3'd4);
  wire arith = (op == 3'd2);
  wire fill = arith & a[W-1];
  logic [W-1:0] mask;
  fam_shift_keep_mask #(.W(W), .STICKY(STICKY)) u_mask (.a(a), .amt(amt), .right(right), .rot(rot), .mask(mask), .sticky(sticky));
  genvar s, i;
  generate
    if (DIR == 1) begin : reversed
      logic [W-1:0] rev_in, x, back;
      for (i = 0; i < W; i = i + 1) begin : rv
        assign rev_in[i] = a[W-1-i];
      end
      assign x = right ? rev_in : a;
      logic [W-1:0] st [0:NS];
      assign st[0] = x;
      for (s = 0; s < NS; s = s + 1) begin : stage
        localparam int G = ORDER ? (NS - 1 - s) : s;          // the digit this stage consumes
        localparam int KB = (G * K + K <= AW) ? K : AW - G * K;
        fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(0), .ONE_HOT(ONE_HOT))
          u (.x(st[s]), .digit(amt[G*K +: KB]), .rot(rot), .fill(fill), .y(st[s+1]));
      end
      for (i = 0; i < W; i = i + 1) begin : rb
        assign back[i] = st[NS][W-1-i];
      end
      assign y = right ? back : st[NS];
    end else if (DIR == 0) begin : mirrored
      logic [W-1:0] lft [0:NS];
      logic [W-1:0] rgt [0:NS];
      assign lft[0] = a;
      assign rgt[0] = a;
      for (s = 0; s < NS; s = s + 1) begin : stage
        localparam int G = ORDER ? (NS - 1 - s) : s;
        localparam int KB = (G * K + K <= AW) ? K : AW - G * K;
        fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(0), .ONE_HOT(ONE_HOT))
          ul (.x(lft[s]), .digit(amt[G*K +: KB]), .rot(rot), .fill(1'b0), .y(lft[s+1]));
        fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(1), .ONE_HOT(ONE_HOT))
          ur (.x(rgt[s]), .digit(amt[G*K +: KB]), .rot(rot), .fill(fill), .y(rgt[s+1]));
      end
      assign y = right ? rgt[NS] : lft[NS];
    end else begin : negated
      // one left rotator; a right operation is a left rotation by W - amt, and a shift takes
      // its fill through the keep mask (zero and overflow flags fall out of the mask)
      logic [AW-1:0] lamt;
      assign lamt = right ? (W - amt) : amt;
      logic [W-1:0] st [0:NS];
      assign st[0] = a;
      for (s = 0; s < NS; s = s + 1) begin : stage
        localparam int G = ORDER ? (NS - 1 - s) : s;
        localparam int KB = (G * K + K <= AW) ? K : AW - G * K;
        fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(0), .ONE_HOT(ONE_HOT))
          u (.x(st[s]), .digit(lamt[G*K +: KB]), .rot(1'b1), .fill(1'b0), .y(st[s+1]));
      end
      assign y = (st[NS] & mask) | ({W{fill}} & ~mask);
    end
  endgenerate
endmodule




// ---------------------------------------------------------------- butterfly_network
// a rotator on a switch network of lg(W) stages of W/2 two-input switches, stage
// l pairing the bits at distance D = 2^l inside every block of 2D, each switch
// under its own control. On the inverse butterfly (NETWORK = 0, small distance
// first) a rotate right by k over a 2D-block whose two halves are already
// rotated by k mod D swaps the pair (i, i+D) at the block-local index i when
// i >= D - (k mod D), and every pair when bit l of k is set (Hilewitz and Lee's
// rotation on the ibfly). The butterfly (NETWORK = 1) is the same stages in the
// reverse order, which composes the inverse permutation, so it takes the controls
// of a rotation by W - k. The shifts merge a mask as the masked family does; a
// left amount is W - amt. The network needs a power-of-two width.
module fam_shift_butterfly_network #(parameter int W = 16, parameter int NETWORK = 0, parameter int STICKY = 0)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic [2:0] op, output logic [W-1:0] y, output logic sticky);
  localparam int AW = $clog2(W);
  wire right = (op == 3'd1) || (op == 3'd2) || (op == 3'd4);
  wire rot = (op == 3'd3) || (op == 3'd4);
  wire arith = (op == 3'd2);
  wire fill = arith & a[W-1];
  logic [AW-1:0] k0, k;                              // the right-rotation amount, and the controls' amount
  assign k0 = right ? amt : (W - amt);
  assign k = NETWORK ? (W - k0) : k0;
  logic [W-1:0] st [0:AW];
  assign st[0] = a;
  genvar s, i;
  generate
    for (s = 0; s < AW; s = s + 1) begin : stage
      localparam int L = NETWORK ? (AW - 1 - s) : s;   // the switch distance of this stage: 2^L
      localparam int D = 1 << L;
      logic [AW-1:0] kmod;                             // k mod D (the low L bits of k)
      if (L == 0) begin : k0_
        assign kmod = '0;
      end else begin : kl
        assign kmod = {{(AW - L){1'b0}}, k[L-1:0]};
      end
      for (i = 0; i < W; i = i + 1) begin : bit_
        localparam int J = i % (2 * D);              // the block-local index
        if (J < D) begin : sw
          // the switch of the pair (i, i+D): crossed when J >= D - (k mod D), inverted by bit L of k
          wire ctrl = ((J >= D - kmod) ^ k[L]);
          assign st[s+1][i] = ctrl ? st[s][i+D] : st[s][i];
          assign st[s+1][i+D] = ctrl ? st[s][i] : st[s][i+D];
        end
      end
    end
  endgenerate
  logic [W-1:0] mask;
  fam_shift_keep_mask #(.W(W), .STICKY(STICKY)) u_mask (.a(a), .amt(amt), .right(right), .rot(rot), .mask(mask), .sticky(sticky));
  assign y = rot ? st[AW] : ((st[AW] & mask) | ({W{fill}} & ~mask));
endmodule






// ---------------------------------------------------------------------- funnel
// a window of the word beside itself (a rotate), beside zeros (a left shift) or
// beside its fill (a right shift), and a W-bit slice selected at the position by
// ceil((AW + 1) / K) stages of 2^K:1 muxes (RADIX_LOG2 = K, the window mux radix).
// AMT_PRE: 1 subtract_from_n (a left operation reads the slice at W - amt of a
// 2W-bit window), 0 ones_complement_for_right (the window is 2W - 1 bits and a
// left operation reads the slice at ~amt = W - 1 - amt, which needs W a power of
// two; at another width the position is W - 1 - amt).
module fam_shift_funnel #(parameter int W = 16, parameter int RADIX_LOG2 = 1, parameter int AMT_PRE = 1, parameter int STICKY = 0)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic [2:0] op, output logic [W-1:0] y, output logic sticky);
  localparam int AW = $clog2(W);
  localparam int WW = AMT_PRE ? 2 * W : 2 * W - 1;               // the window width
  localparam int PW = AW + 1;                                    // the position width
  localparam int K = (RADIX_LOG2 == 0 || RADIX_LOG2 > PW) ? PW : RADIX_LOG2;
  localparam int NS = (PW + K - 1) / K;
  wire rot = (op == 3'd3) || (op == 3'd4);
  wire left = (op == 3'd0) || (op == 3'd3);
  wire right = ~left;
  wire arith = (op == 3'd2);
  wire fill = arith & a[W-1];
  logic [W-1:0] mask;
  fam_shift_keep_mask #(.W(W), .STICKY(STICKY)) u_mask (.a(a), .amt(amt), .right(right), .rot(rot), .mask(mask), .sticky(sticky));
  logic [WW-1:0] win;
  logic [PW-1:0] pos;
  genvar s;
  generate
    if (AMT_PRE) begin : subtract
      // {hi, lo}: a left operation by k reads the slice at W - k (0 reads the low word for a
      // rotate and the high for a shift), a right one at k
      assign win = rot ? {a, a} : (left ? {a, {W{1'b0}}} : {{W{fill}}, a});
      assign pos = left ? ((amt == 0) ? {PW{1'b0}} : (W - amt)) : {1'b0, amt};
    end else begin : complement
      // a 2W - 1-bit window: a left operation by k reads the slice at W - 1 - k, which is the
      // one's complement of k when W is a power of two
      assign win = rot ? (left ? {a, a[W-1:1]} : {a[W-2:0], a}) : (left ? {a, {(W-1){1'b0}}} : {{(W-1){fill}}, a});
      if ((W & (W - 1)) == 0) begin : pow2
        assign pos = left ? {1'b0, ~amt} : {1'b0, amt};
      end else begin : other
        assign pos = left ? (W - 1 - amt) : {1'b0, amt};
      end
    end
    // the slice: the window shifted right by the position through the mux stages, the low W bits
    logic [WW-1:0] st [0:NS];
    assign st[0] = win;
    for (s = 0; s < NS; s = s + 1) begin : stage
      localparam int KB = (s * K + K <= PW) ? K : PW - s * K;
      fam_shift_stage #(.W(WW), .K(KB), .SH(s * K), .RIGHT(1), .ONE_HOT(0))
        u (.x(st[s]), .digit(pos[s*K +: KB]), .rot(1'b0), .fill(1'b0), .y(st[s+1]));
    end
    if (AMT_PRE) begin : y_sub
      assign y = (left & (amt == 0)) ? a : st[NS][W-1:0];
    end else begin : y_cpl
      assign y = st[NS][W-1:0];
    end
  endgenerate
endmodule



// ----------------------------------------------------------- the keep mask
// mask[i] = 1 where a shift keeps the input bit that lands at i (a rotate keeps
// every bit): the thermometer of the amount for the direction. sticky is the OR
// of the input bits a shift moves out (the low amt bits of a right shift, the
// top amt bits of a left one; none for a rotate), read through the mask of the
// opposite direction, in parallel with the datapath.
module fam_shift_keep_mask #(parameter int W = 16, parameter int STICKY = 1)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic right, input logic rot,
   output logic [W-1:0] mask, output logic sticky);
  logic [W-1:0] kept_in;
  genvar i;
  generate
    for (i = 0; i < W; i = i + 1) begin : mk
      assign mask[i] = rot | (right ? (i < W - amt) : (i >= amt));
      assign kept_in[i] = rot | (right ? (i >= amt) : (i < W - amt));
    end
  endgenerate
  assign sticky = STICKY ? |(a & ~kept_in) : 1'b0;
endmodule




// ------------------------------------------------------------------ masked_merged
// a left rotator (the `rotator` slot's barrel: R_RADIX_LOG2, R_ONE_HOT, R_ORDER)
// plus a mask that turns the rotation into a shift by merging in the fill bits.
// MASKGEN: 0 thermometer_decode (one thermometer per direction, selected), 1
// two_thermometer_and (a low and a high bound thermometer ANDed), 2 lut (a table
// over the direction and the amount). MERGE: 0 and_or_merge, 1 per_bit_mux.
module fam_shift_masked_merged #(parameter int W = 16, parameter int MASKGEN = 0, parameter int MERGE = 0,
                                 parameter int R_RADIX_LOG2 = 1, parameter int R_ONE_HOT = 0, parameter int R_ORDER = 0, parameter int STICKY = 0)
  (input logic [W-1:0] a, input logic [$clog2(W)-1:0] amt, input logic [2:0] op, output logic [W-1:0] y, output logic sticky);
  localparam int AW = $clog2(W);
  localparam int K = (R_RADIX_LOG2 == 0 || R_RADIX_LOG2 > AW) ? AW : R_RADIX_LOG2;
  localparam int NS = (AW + K - 1) / K;
  wire right = (op == 3'd1) || (op == 3'd2) || (op == 3'd4);
  wire rot = (op == 3'd3) || (op == 3'd4);
  wire arith = (op == 3'd2);
  wire fill = arith & a[W-1];
  // rotate left by amt (a right operation by k is a left rotation by W - k)
  logic [AW-1:0] lamt;
  assign lamt = right ? (W - amt) : amt;
  logic [W-1:0] st [0:NS];
  assign st[0] = a;
  genvar s, i;
  logic [W-1:0] mask;                 // 1 where the rotated bit is kept
  generate
    for (s = 0; s < NS; s = s + 1) begin : stage
      localparam int G = R_ORDER ? (NS - 1 - s) : s;
      localparam int KB = (G * K + K <= AW) ? K : AW - G * K;
      fam_shift_stage #(.W(W), .K(KB), .SH(G * K), .RIGHT(0), .ONE_HOT(R_ONE_HOT))
        u (.x(st[s]), .digit(lamt[G*K +: KB]), .rot(1'b1), .fill(1'b0), .y(st[s+1]));
    end
    if (MASKGEN == 0) begin : thermo
      for (i = 0; i < W; i = i + 1) begin : mk
        assign mask[i] = right ? (i < W - amt) : (i >= amt);
      end
    end else if (MASKGEN == 1) begin : two_thermo
      // the field kept lies between a low and a high bound: [amt, W-1] for a left shift,
      // [0, W-1-amt] for a right one; each bound is a thermometer, the mask their AND. The
      // high bound is signed: a right amount at or past W (an amount code W leaves the whole
      // word when W is below a power of two) puts it below zero, and no bit is kept
      logic [AW:0] lo;
      logic signed [AW+1:0] hi;
      assign lo = right ? {(AW+1){1'b0}} : {1'b0, amt};
      assign hi = right ? ($signed(W - 1) - $signed({2'b00, amt})) : $signed(W - 1);
      logic [W-1:0] ge_lo, le_hi;
      for (i = 0; i < W; i = i + 1) begin : mk
        assign ge_lo[i] = (i >= lo);
        assign le_hi[i] = (hi >= 0) && (i <= hi);
      end
      assign mask = ge_lo & le_hi;
    end else begin : lut
      // the mask read from a table over the direction and the amount
      logic [AW:0] idx;
      assign idx = {right, amt};
      logic [W-1:0] tab [0:2*(1<<AW)-1];
      for (i = 0; i < 2 * (1 << AW); i = i + 1) begin : t
        localparam int RT = i >> AW;
        localparam int AM = i & ((1 << AW) - 1);
        genvar j;
        for (j = 0; j < W; j = j + 1) begin : bt
          assign tab[i][j] = RT ? (j < W - AM) : (j >= AM);
        end
      end
      assign mask = tab[idx];
    end
  endgenerate
  logic [W-1:0] mask_unused;
  fam_shift_keep_mask #(.W(W), .STICKY(STICKY)) u_sticky (.a(a), .amt(amt), .right(right), .rot(rot), .mask(mask_unused), .sticky(sticky));
  generate
    if (MERGE == 0) begin : and_or
      assign y = rot ? st[NS] : ((st[NS] & mask) | ({W{fill}} & ~mask));
    end else begin : per_bit
      for (i = 0; i < W; i = i + 1) begin : mx
        assign y[i] = (rot | mask[i]) ? st[NS][i] : fill;
      end
    end
  endgenerate
endmodule

// The shifter families of chiALU. One interface:
//   #(parameter int W) (input [W-1:0] a, input [AW-1:0] amt, input [2:0] op, output [W-1:0] y)
// op: 0 shl, 1 shr_logical, 2 shr_arith, 3 rol, 4 ror; amt is below W.
// Every family has `output sticky`, the OR of the bits a shift moves out (0 for a rotate), built
// when STICKY = 1 (the sticky_collect choice; an alignment shifter asks for it) and tied to 0
// otherwise; a consumer that does not collect it leaves the port unconnected.

// ------------------------------------------------------------------ one mux stage
// One stage of a shifter: the K-bit digit of the amount selects among R = 2^K
// candidates, candidate d being the input displaced by d * 2^SH to the left
// (RIGHT = 0) or to the right (RIGHT = 1), the vacated bits taken from the
// other end under `rot` or from `fill`. ONE_HOT = 1 decodes the digit to R
// select lines and forms the mux as an AND-OR (the select_encoding choice);
// ONE_HOT = 0 indexes the candidates by the binary digit.
module fam_shift_stage #(parameter int W = 16, parameter int K = 1, parameter int SH = 0,
                         parameter int RIGHT = 0, parameter int ONE_HOT = 0)
  (input logic [W-1:0] x, input logic [K-1:0] digit, input logic rot, input logic fill, output logic [W-1:0] y);
  localparam int R = 1 << K;
  localparam int D = 1 << SH;
  logic [W*R-1:0] cand;                       // candidate d at [d*W +: W]
  genvar d, i;
  generate
    for (d = 0; d < R; d = d + 1) begin : c
      for (i = 0; i < W; i = i + 1) begin : b
        localparam int S = d * D;             // the displacement of this candidate
        if (S >= W) begin : far
          // a displacement past the word: a rotate wraps it (mod W), a shift clears the word
          localparam int IDX = ((RIGHT ? (i + S) : (i - S)) % W + W) % W;
          assign cand[d*W + i] = rot ? x[IDX] : fill;
        end else if (RIGHT) begin : r
          if (i + S < W) begin : in_
            assign cand[d*W + i] = x[i + S];
          end else begin : out_
            assign cand[d*W + i] = rot ? x[i + S - W] : fill;
          end
        end else begin : l
          if (i >= S) begin : in_
            assign cand[d*W + i] = x[i - S];
          end else begin : out_
            assign cand[d*W + i] = rot ? x[W - S + i] : fill;
          end
        end
      end
    end
    if (ONE_HOT) begin : onehot
      logic [R-1:0] sel;
      for (d = 0; d < R; d = d + 1) begin : dec
        assign sel[d] = (digit == d);
      end
      for (i = 0; i < W; i = i + 1) begin : orb
        logic [R-1:0] t;
        for (d = 0; d < R; d = d + 1) begin : and_
          assign t[d] = sel[d] & cand[d*W + i];
        end
        assign y[i] = |t;
      end
    end else begin : binary
      assign y = cand[digit*W +: W];
    end
  endgenerate
endmodule
